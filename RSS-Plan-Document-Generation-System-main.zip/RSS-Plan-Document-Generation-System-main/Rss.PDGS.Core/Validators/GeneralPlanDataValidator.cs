﻿using FluentValidation;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Validators
{
    public class GeneralPlanDataValidator :FluentValidation.AbstractValidator<GeneralPlanDataModel>
    {

        public GeneralPlanDataValidator()
        {
            RuleFor(x => (Lookup.PlanTypes)x.PlanTypeLookupId).IsInEnum();

            RuleFor(x => x.PlanStateCode).NotEmpty();

            RuleFor(x => x.IsAddASFToPlan).NotEmpty();

            RuleFor(x => x.PPANumber).NotNull().WithMessage("Not Null");
            RuleFor(x => x.PPANumber).GreaterThanOrEqualTo(0).WithMessage("Greater than or equal to 0");
            RuleFor(x => x.PPANumber).LessThanOrEqualTo(999).WithMessage("LessThanEqualto_999");

            RuleFor(x => x.RVPName).NotEmpty();
            RuleFor(x => x.RVPName).Length(0, 30);

            RuleFor(x => x.DVPName).NotEmpty();
            RuleFor(x => x.DVPName).Length(0, 30);
            RuleFor(x => x.DVPName).Matches("^[a-zA-Z]+$").When(x => x.DVPName != null).WithMessage("Please remove unwanted character");

            RuleFor(x => x.IRONWilshireLeafHouseForThePlan).NotEmpty();

            RuleFor(x => x.OtherNonIRONWilshireFeePercentage).NotNull();
            RuleFor(x => x.OtherNonIRONWilshireFeePercentage).GreaterThanOrEqualTo(0.00m);
            RuleFor(x => x.OtherNonIRONWilshireFeePercentage).LessThanOrEqualTo(1000.00m);
            

            RuleFor(x => x.TPAPPAPercentage).NotNull();
            RuleFor(x => x.TPAPPAPercentage).GreaterThanOrEqualTo(0.00m);
            RuleFor(x => x.TPAPPAPercentage).LessThan( 1000.00m);

            RuleFor(x => x.IsCustomCompensationNeeded).NotEmpty();
            //not required
            RuleFor(x => x.AdvisorTotalCostOfComp).NotEmpty().When(x => x.IsCustomCompensationNeeded == false);
            RuleFor(x => x.AdvisorTotalCostOfComp).GreaterThanOrEqualTo(0).WithMessage("Greater than or equal to 0").When(x => x.IsCustomCompensationNeeded == false);

            RuleFor(x => x.IsFeeBasedAdvisor).NotEmpty().When(x => x.IsCustomCompensationNeeded == false); ;
            RuleFor(x => x.CompensationTableLookupId).NotEmpty().When(x => x.IsCustomCompensationNeeded == false); ;
            RuleFor(x => x.TableCostPercentage).NotEmpty().When(x => x.IsCustomCompensationNeeded == false); ;
            RuleFor(x => x.TableCostPercentage).GreaterThanOrEqualTo(0).WithMessage("Greater than or equal to 0").When(x => x.IsCustomCompensationNeeded == false);
            RuleFor(x => x.AddOnTrailerPercentage).NotEmpty().When(x => x.IsCustomCompensationNeeded == false); ;
            RuleFor(x => x.AddOnTrailerPercentage).GreaterThanOrEqualTo(0).WithMessage("Greater than or equal to 0").When(x => x.IsCustomCompensationNeeded == false); ;

        }
    }
}
