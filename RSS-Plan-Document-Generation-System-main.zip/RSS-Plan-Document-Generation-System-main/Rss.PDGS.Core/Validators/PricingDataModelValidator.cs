﻿using FluentValidation;
using FluentValidation.Results;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL;
using Rss.PDGS.DAL.BLL;
using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Validators
{
    public class PricingDataModelValidator : FluentValidation.AbstractValidator<PricingDataModel>
    {
        IPlanProposalDATA planProposalDATA;
        IPlanTypeDATA planTypeDATA;
        public PricingDataModelValidator(IDalFactory dalFactory)
        {
            this.planTypeDATA = dalFactory.CreatePlanTypeDATA();
            this.planProposalDATA = dalFactory.CreatePlanProposalDATA();
            RuleFor(x => x.ProposalPricingLookupId).NotEmpty();
            RuleFor(x => (Lookup.ProposalPricingType)x.ProposalPricingLookupId).IsInEnum();

            RuleFor(x => (x.TakeOverAmount + x.FlowAmount)).GreaterThan(0).WithMessage("TakeOverAmount + FlowAmount should be greater than zero.");

            RuleFor(x => x.NumberOfParticipantsWithBalance).GreaterThan(1);

            RuleFor(x => x.FixedProductGrossRate).GreaterThan(0.01m).When(x=>x.FixedProductLookupId != (int) Lookup.FixedProductType.Not_Applicable);

            RuleFor(x => x.RateQuarterStartDate).Must((x) => 
            x.Date == new DateTime(DateTime.Now.Year, 1, 1) ||
            x.Date == new DateTime(DateTime.Now.Year, 4, 1) ||
            x.Date == new DateTime(DateTime.Now.Year, 7, 1) ||
            x.Date == new DateTime(DateTime.Now.Year, 10, 1));

            RuleFor(x => x.RateQuarterEndDate).Must((x) => 
            x.Date == new DateTime(DateTime.Now.Year, 3, 31) ||
            x.Date == new DateTime(DateTime.Now.Year, 6, 30) ||
            x.Date == new DateTime(DateTime.Now.Year, 9, 30) ||
            x.Date == new DateTime(DateTime.Now.Year, 12, 31));

            RuleFor(x => (Lookup.Compensation_CDSC) x.CompensationLookupId).IsInEnum();
        }

        public override ValidationResult Validate(ValidationContext<PricingDataModel> context)
        {
            var proposal = planProposalDATA.GetByPlanProposalId(context.InstanceToValidate.PlanProposalId);
            
            if (proposal?.GeneralPlanData == null || proposal.GeneralPlanData.PlanTypeLookupId == 0)
                return base.Validate(context);

            var planTypeData = planTypeDATA.GetByPlayTypeLookupId(proposal.GeneralPlanData.PlanTypeLookupId);
            Lookup.PlanTypes selectedPlanType = (Lookup.PlanTypes)proposal.GeneralPlanData.PlanTypeLookupId;

            if (!planTypeData.IsAdvidorFixed && (Lookup.FixedProductType)context.InstanceToValidate.FixedProductLookupId == Lookup.FixedProductType.Advisor_Fixed)
                return new ValidationResult(new List<ValidationFailure>(){ 
                    new ValidationFailure
                    (nameof(PricingDataModel.FixedProductLookupId), 
                    $"Cannot have {Lookup.FixedProductType.Advisor_Fixed}",
                    Lookup.FixedProductType.Advisor_Fixed)});

            if (!planTypeData.IsFixedSelectAllowed && (Lookup.FixedProductType)context.InstanceToValidate.FixedProductLookupId == Lookup.FixedProductType.Fixed_Select)
                return new ValidationResult(new List<ValidationFailure>(){
                    new ValidationFailure
                    (nameof(PricingDataModel.FixedProductLookupId),
                    $"Cannot have {Lookup.FixedProductType.Fixed_Select}",
                    Lookup.FixedProductType.Fixed_Select)});

            return base.Validate(context);
        }
    }
}
