﻿using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.ExtentionMethods
{
    public static partial class MappingExtensions
    {
        public static void Map(this PricingDataModel model, IPricingData dbData)
        {
            if (model == null || dbData == null) return;

            model.PlanProposalId = dbData.PlanProposalId;
            model.ProposalPricingLookupId = dbData.ProposalPricingLookupId;
            model.IsStartupPlan = dbData.IsStartupPlan;
            model.IsFoundationRequired = dbData.IsFoundationRequired;
            model.TakeOverAmount = dbData.TakeOverAmount;
            model.FlowAmount = dbData.FlowAmount;
            model.NumberOfParticipantsWithBalance = dbData.NumberOfParticipantsWithBalance;
            model.FixedProductLookupId = dbData.FixedProductLookupId;
            model.FixedProductGrossRate = dbData.FixedProductGrossRate;
            model.RateQuarterStartDate = dbData.RateQuarterStartDate;
            model.RateQuarterEndDate = dbData.RateQuarterEndDate;
            model.AdvisorCompensationPercentage = dbData.AdvisorCompensationPercentage;
            model.IsFeeBasedAdvisor = dbData.IsFeeBasedAdvisor;
            model.CompensationLookupId = dbData.CompensationLookupId;
            model.TableCostPercentage = dbData.TableCostPercentage;
            model.AddOnTrailerPercentage = dbData.AddOnTrailerPercentage;

        }

        public static void Map(this IPricingData dbData, PricingDataModel model)
        {
            if (model == null || dbData == null) return;

            dbData.PlanProposalId = model.PlanProposalId;
            dbData.ProposalPricingLookupId = model.ProposalPricingLookupId;
            dbData.IsStartupPlan = model.IsStartupPlan;
            dbData.IsFoundationRequired = model.IsFoundationRequired;
            dbData.TakeOverAmount = model.TakeOverAmount;
            dbData.FlowAmount = model.FlowAmount;
            dbData.NumberOfParticipantsWithBalance = model.NumberOfParticipantsWithBalance;
            dbData.FixedProductLookupId = model.FixedProductLookupId;
            dbData.FixedProductGrossRate = model.FixedProductGrossRate;
            dbData.RateQuarterStartDate = model.RateQuarterStartDate;
            dbData.RateQuarterEndDate = model.RateQuarterEndDate;
            dbData.AdvisorCompensationPercentage = model.AdvisorCompensationPercentage;
            dbData.IsFeeBasedAdvisor = model.IsFeeBasedAdvisor;
            dbData.CompensationLookupId = model.CompensationLookupId;
            dbData.TableCostPercentage = model.TableCostPercentage;
            dbData.AddOnTrailerPercentage = model.AddOnTrailerPercentage;

        }
    }
}
