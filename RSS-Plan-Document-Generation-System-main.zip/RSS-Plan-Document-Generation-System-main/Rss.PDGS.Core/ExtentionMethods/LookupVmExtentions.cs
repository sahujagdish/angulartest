﻿using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.ExtentionMethods
{
    public static partial class MappingExtensions
    {
        public static void MapFromLookup(this LookupVm vm, Lookup lookup)
        {
            vm.LookupId = lookup.LookupId;
            vm.GroupName = lookup.GroupName;
            vm.SortOrder = lookup.SortOrder.HasValue ? lookup.SortOrder.Value : 0;
            vm.Description = lookup.Description;
            vm.Value = lookup.Value;
        }

        public static void MapToLookup(this LookupVm vm, Lookup lookup)
        {
            lookup.LookupId = vm.LookupId;
            lookup.GroupName = vm.GroupName;
            lookup.SortOrder = vm.SortOrder;
            lookup.Description = vm.Description;
            lookup.Value = vm.Value;
        }
    }
}
