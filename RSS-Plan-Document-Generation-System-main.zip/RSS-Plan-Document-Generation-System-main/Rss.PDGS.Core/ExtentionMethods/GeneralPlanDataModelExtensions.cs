﻿using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.ExtentionMethods
{
    public static partial class MappingExtensions
    {
        /// <summary>
        ///  It is going to Take data from Database object and Add these to the model
        /// </summary>
        /// <param name="model"></param>
        /// <param name="data"></param>
        public static void Map(this GeneralPlanDataModel model, GeneralPlanData data)
        {
            model.PlanProposalId =data.PlanProposalId;
            model.PlanTypeLookupId = data.PlanTypeLookupId;
            model.PlanStateCode = data.PlanStateCode;
            model.IsAddASFToPlan = data.IsAddASFToPlan;
            model.PPANumber = data.PPANumber;
            model.RVPName = data.RVPName;
            model.DVPName = data.DVPName;
            model.IRONWilshireLeafHouseForThePlan = data.IRONWilshireLeafHouseForThePlan;
            model.OtherNonIRONWilshireFeePercentage = data.OtherNonIRONWilshireFeePercentage;
            model.TPAPPAPercentage = data.TPAPPAPercentage;
            model.IsCustomCompensationNeeded = data.IsCustomCompensationNeeded;
            model.AdvisorTotalCostOfComp = data.AdvisorTotalCostOfComp;
            model.IsFeeBasedAdvisor = data.IsFeeBasedAdvisor;
            model.CompensationTableLookupId = data.CompensationTableLookupId;
            model.TableCostPercentage = data.TableCostPercentage;
            model.AddOnTrailerPercentage = data.AddOnTrailerPercentage;
        }
        /// <summary>
        ///     It is going to Take data from the model and update in Database Object
        /// </summary>
        /// <param name="table"></param>
        /// <param name="data"></param>
        public static void Map(this GeneralPlanData data,GeneralPlanDataModel table)
        {
            //                          table/table = model/data  
            data.PlanProposalId = table.PlanProposalId;
            data.PlanTypeLookupId = table.PlanTypeLookupId;
            data.PlanStateCode = table.PlanStateCode;
            data.IsAddASFToPlan = table.IsAddASFToPlan;
            data.PPANumber = table.PPANumber;
            data.RVPName = table.RVPName;
            data.DVPName = table.DVPName;
            data.IRONWilshireLeafHouseForThePlan = table.IRONWilshireLeafHouseForThePlan;
            data.OtherNonIRONWilshireFeePercentage = table.OtherNonIRONWilshireFeePercentage;
            data.TPAPPAPercentage = table.TPAPPAPercentage;
            data.IsCustomCompensationNeeded = table.IsCustomCompensationNeeded;
            data.AdvisorTotalCostOfComp = table.AdvisorTotalCostOfComp;
            data.IsFeeBasedAdvisor = table.IsFeeBasedAdvisor;
            data.CompensationTableLookupId = table.CompensationTableLookupId;
            data.TableCostPercentage = table.TableCostPercentage;
            data.AddOnTrailerPercentage = table.AddOnTrailerPercentage;
        }   
    }
}
