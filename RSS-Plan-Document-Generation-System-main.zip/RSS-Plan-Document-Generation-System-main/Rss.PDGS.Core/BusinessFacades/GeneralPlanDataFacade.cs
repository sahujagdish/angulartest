﻿using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.ExtentionMethods;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.BusinessFacades
{
    public class GeneralPlanDataFacade : IGeneralPlanDataFacade
    {
        public long SaveGeneralPlanData( GeneralPlanDataModel data)
        {
            PlanProposal planProposal = PlanProposal.GetByPlanProposalId(data.PlanProposalId);
            if (planProposal == null)
                return 0;
            GeneralPlanData? oldData = planProposal.GeneralPlanData;
            GeneralPlanData temp;
            if (oldData == null)
            {
                temp =  new GeneralPlanData();
                data.Map(temp);          
                temp.Save("Atanu");
                return temp.GeneralPlanId;
            }
            else
            {
                data.Map(oldData);
                oldData.Save("Atanu");
                return oldData.GeneralPlanId;
            }
        }
        
        public GeneralPlanDataModel GetGeneralPlanData(long planProposalId)
        {
            GeneralPlanData? data = GeneralPlanData.GetByPlanProposalId(planProposalId);
            GeneralPlanDataModel? temp=null;
            if (data != null)
            {
                temp = new GeneralPlanDataModel();
                temp.Map(data);
            }
            return temp;
        }
    }
}
