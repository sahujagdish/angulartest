﻿using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.BusinessFacades
{
    public class ProposalFacade : IProposalFacade
    {
        public void CreateProposal(NewProposal newProposal)
        {
            //Generate new proposal number 
            int proposalNumber = 1;

            PlanProposal planProposal = new PlanProposal();
            planProposal.Name = newProposal.Name;
            planProposal.AdvisorName = newProposal.AdvisorName;
            planProposal.ProposalNumber = proposalNumber;
            planProposal.OrganizationId = newProposal.OrganizationId;
            planProposal.Save(newProposal.UserName);
        }
    }
}
