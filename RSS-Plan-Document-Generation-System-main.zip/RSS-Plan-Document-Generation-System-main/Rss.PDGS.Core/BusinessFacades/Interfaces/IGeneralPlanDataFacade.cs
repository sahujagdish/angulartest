﻿using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.BusinessFacades.Interfaces
{
    public interface IGeneralPlanDataFacade
    {
        /// <summary>
        ///     This is going to Save or Update the data from General Plan Data according to this Situation.
        /// </summary>
        /// <param name="value"> This is the value we have to save or update </param>
        /// <returns> Return Id of General Plan Data</returns>
        public long SaveGeneralPlanData(GeneralPlanDataModel dataToSave);
        /// <summary>
        ///     This is going to Return General Plan Data for Particular Provider using ProposalID
        /// </summary>
        /// <param name="PlanProposalId"> Every Proposal has only one general Plan data which we can get using this.</param>
        /// <returns> Return ID of General plan data  for particular proposal </returns>
        public GeneralPlanDataModel GetGeneralPlanData(long PlanProposalId);
    }
}
