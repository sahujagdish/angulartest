﻿using Rss.PDGS.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.BusinessFacades.Interfaces
{
    public interface ILookupFacade
    {
        List<LookupVm> GetLookups(string groupName);

        List<LookupVm> GetAllLookups();
    }
}
