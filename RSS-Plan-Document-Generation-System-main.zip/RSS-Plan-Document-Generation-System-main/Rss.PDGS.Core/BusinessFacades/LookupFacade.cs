﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.ExtentionMethods;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;

namespace Rss.PDGS.Core.BusinessFacades
{
    public class LookupFacade : ILookupFacade
    {
        public List<LookupVm> GetAllLookups()
        {
            return GetLookupsInternal();
        }

        public List<LookupVm> GetLookups(string groupName)
        {
            List<LookupVm> lookups = null;
            if (string.IsNullOrEmpty(groupName))
            {
                lookups = new List<LookupVm>();
            }
            else
            {
                lookups = GetLookupsInternal(groupName);
            }
            return lookups;
        }

        private List<LookupVm> GetLookupsInternal(string groupName = null)
        {
            List<LookupVm> lookups = new List<LookupVm>();
            foreach (var lookup in Lookup.GetAll())
            {
                if (!string.IsNullOrEmpty(groupName) && lookup.GroupName.ToLower() != groupName.ToLower())
                {
                    continue;
                }

                LookupVm lookupVm = new LookupVm();
                lookupVm.MapFromLookup(lookup);
                lookups.Add(lookupVm);
            }

            return lookups;
        }
    }
}
