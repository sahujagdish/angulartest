﻿using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.ExtentionMethods;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL;
using Rss.PDGS.DAL.BLL;
using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.BusinessFacades
{
    public class PricingDataFacade : IPricingDataFacade
    {
        IDalFactory dalFactory;
        IBllFactory bllFactory;
        IModelFactory modelFactory;

        public PricingDataFacade(IDalFactory dalFactory , IBllFactory bllFactory, 
            IModelFactory modelFactory)
        {
            this.dalFactory = dalFactory;
            this.bllFactory = bllFactory;
            this.modelFactory = modelFactory;
        }

        public PricingDataModel GetPricingData(long planProposalId)
        {
            var pricing = dalFactory.CreatePricingDataDATA().GetByPlanProposalId(planProposalId);
            var pricingModel = modelFactory.CreatePricingDataModel();
            pricingModel.Map(pricing);
            return pricingModel;
        }

        public long SavePricingData(PricingDataModel pricingModel)
        {
            var data = dalFactory.CreatePlanProposalDATA();
            var planProposal = dalFactory.CreatePlanProposalDATA().GetByPlanProposalId(pricingModel.PlanProposalId);
            if (planProposal == null)
                return 0;

            var priceData = planProposal.PricingData;

            if (priceData == null)
                priceData = bllFactory.CreatePricingData();

            priceData.Map(pricingModel);
            priceData.Save("sampleUser");
            return priceData.PricingDataId;
        }
    }
}
