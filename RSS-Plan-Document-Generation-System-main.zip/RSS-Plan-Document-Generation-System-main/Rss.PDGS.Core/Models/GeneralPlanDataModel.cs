﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Models
{
    public class GeneralPlanDataModel
    {
        public  long PlanProposalId { get; set; }
        public int PlanTypeLookupId { get; set; } //Assumption
        public string? PlanStateCode { get; set; } //Assumption

        
        public bool? IsAddASFToPlan { get; set; }
        public int PPANumber { get; set; }

        
        public string? RVPName { get; set; } 

        public string? DVPName { get; set; } 
        
        public string? IRONWilshireLeafHouseForThePlan { get; set; } //Assumption
        public decimal OtherNonIRONWilshireFeePercentage { get;set;}
       
        public decimal TPAPPAPercentage { get; set; }
        public bool IsCustomCompensationNeeded { get; set; }    //control below
        public decimal? AdvisorTotalCostOfComp { get; set; }  
        public bool? IsFeeBasedAdvisor { get; set; }  
        public int? CompensationTableLookupId { get; set; } //Assumptions
        public decimal?  TableCostPercentage { get; set; } 
        public decimal? AddOnTrailerPercentage { get; set; } 
    }
}
