﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Models
{
    public class LookupVm
    {
        public int LookupId
        {
            get;
            set;
        }

        public string GroupName
        {
            get;
            set;
        }

        public string Value
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public int SortOrder
        {
            get;
            set;
        }
    }
}
