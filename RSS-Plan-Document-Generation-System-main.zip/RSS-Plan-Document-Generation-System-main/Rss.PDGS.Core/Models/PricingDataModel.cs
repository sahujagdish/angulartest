﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Models
{
    public class PricingDataModel
    {
        public DateTime AddDate { get; set; }
        public decimal AddOnTrailerPercentage { get; set; }
        public decimal AdvisorCompensationPercentage { get; set; }
        public int CompensationLookupId { get; set; }
        public decimal FixedProductGrossRate { get; set; }
        public int FixedProductLookupId { get; set; }
        public decimal FlowAmount { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsFeeBasedAdvisor { get; set; }
        public bool IsFoundationRequired { get; set; }
        public bool IsStartupPlan { get; set; }
        public int NumberOfParticipantsWithBalance { get; set; }
        public long PlanProposalId { get; set; }
        public int ProposalPricingLookupId { get; set; }
        public DateTime RateQuarterEndDate { get; set; }
        public DateTime RateQuarterStartDate { get; set; }
        public decimal TableCostPercentage { get; set; }
        public decimal TakeOverAmount { get; set; }
    }
}
