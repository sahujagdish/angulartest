﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Models
{
    public interface IModelFactory
    {
        PricingDataModel CreatePricingDataModel();
    }

    public class ModelFactory : IModelFactory
    {
        public PricingDataModel CreatePricingDataModel()
        {
            return new PricingDataModel();
        }
    }
}
