﻿using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.DAL
{
    public interface IBllFactory
    {
        IPricingData CreatePricingData();
    }

    public class BllFactory : IBllFactory
    {
        public IPricingData CreatePricingData()
        {
            return new PricingData();
        }
    }
}
