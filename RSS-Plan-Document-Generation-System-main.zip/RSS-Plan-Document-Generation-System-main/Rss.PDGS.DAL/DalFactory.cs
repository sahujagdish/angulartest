﻿using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.DAL
{
    public interface IDalFactory
    {
        IPricingDataDATA CreatePricingDataDATA();
        IPlanProposalDATA CreatePlanProposalDATA();
        IPlanTypeDATA CreatePlanTypeDATA();
    }

    public class DalFactory : IDalFactory
    {
        public IPlanProposalDATA CreatePlanProposalDATA()
        {
            return new PlanProposalDATA();
        }

        public IPricingDataDATA CreatePricingDataDATA()
        {
            return new PricingDataDATA();
        }

        public IPlanTypeDATA CreatePlanTypeDATA()
        {
            return new PlanTypeDATA();
        }
    }
}
