/// -----------------------------------------------------------------------------
/// Project	 : Rss.PDGS.DAL
/// Namespace: Rss.PDGS.DAL.BLL
/// Class	 : BusinessObjectBase
/// Filename : BusinessObjectBase.generated.cs
/// Copyright: SS&C 2022
///
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for BusinessObjectBase.
/// </summary>
///
/// <remarks>
/// </remarks>
/// -----------------------------------------------------------------------------
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
using Wmsi.Utilities.DataAccess;
using Rss.PDGS.DAL.DAL;

namespace Rss.PDGS.DAL.BLL
{
	/// <summary>
	/// Abstract class for all Business Objects
	/// </summary>
	[Serializable, DataContract]
    public abstract partial class BusinessObjectBase : ObjectBase
    {
		private static string[] m_NoDataMemberColumnNames = new string[] { "AddBy", "AddDate", "ModifiedBy", "ModifiedDate", "IsDeleted" };
        private bool m_IsNew = true;

		#region Properties
		/// <summary>
		/// Gets the array of global ColumnName that excluded from DataContracts. For example "AddBy", "AddDate", etc.
		/// </summary>
		public static string[] NoDataMemberColumnNames
		{
			get { return m_NoDataMemberColumnNames; }
		}
		
		/// <summary>
		/// Gets the value indicating if object is new
		/// </summary>
        public bool IsNew 
		{ 
			get { return m_IsNew; }
			protected internal set { m_IsNew = value; }
		}

		/// <summary>
		/// Gets modified indicator. Similarly to IPropertyNotify interface each property sets value of IsModified property.
		/// Property is modified even if original value re-assigned 
		/// </summary>
		public bool IsModified { get; protected set; }
        #endregion

        #region Methods
        public abstract void Save(string savedBy);
        public override string ToString()
        {
            System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();
            foreach (System.Reflection.PropertyInfo pi in this.GetType().GetProperties())
            {
                stringBuilder.AppendFormat("P:{0} V:{1}|", pi.Name, pi.GetValue(this, null));
            }
            return stringBuilder.ToString();
        }
		
		/// <summary>
		/// Copy properties defined by propertyMappings list from source instance to destination
		/// </summary>
		internal static void Copy<T>(T source, T destination, IEnumerable<IPropertyMap<T>> propertyMappings)
			where T: BusinessObjectBase
		{
			foreach (var map in propertyMappings)
			{
				map.CopyValue(source, destination);
			}
		}
		#endregion
    }
}
