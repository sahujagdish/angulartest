﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rss.PDGS.Core.Models;
using Rss.PDGS.Core.ExtentionMethods;
using Rss.PDGS.DAL.BLL;

namespace Rss.PDGS.Core.Tests.ExtentionMethods
{
    internal class GeneralPlanDataModelExtensionTest
    {
        [Test]
        public void MapFromLookupTest()
        {
            GeneralPlanDataModel model = new GeneralPlanDataModel()
            {
                PlanProposalId = 24,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };

            GeneralPlanData data = new GeneralPlanData();
            model.Map(data);
            Assert.AreEqual(data.PlanProposalId, model.PlanProposalId);
            Assert.AreEqual(data.PlanTypeLookupId, model.PlanTypeLookupId);
            Assert.AreEqual(data.PlanStateCode, model.PlanStateCode);
            Assert.AreEqual(data.IsAddASFToPlan, model.IsAddASFToPlan);
            Assert.AreEqual(data.PPANumber, model.PPANumber);
            Assert.AreEqual(data.RVPName, model.RVPName);
            Assert.AreEqual(data.DVPName, model.DVPName);
            Assert.AreEqual(data.IRONWilshireLeafHouseForThePlan, model.IRONWilshireLeafHouseForThePlan);
            Assert.AreEqual(data.OtherNonIRONWilshireFeePercentage, model.OtherNonIRONWilshireFeePercentage);
            Assert.AreEqual(data.TPAPPAPercentage, model.TPAPPAPercentage);
            Assert.AreEqual(data.IsCustomCompensationNeeded, model.IsCustomCompensationNeeded);
            Assert.AreEqual(data.AdvisorTotalCostOfComp, model.AdvisorTotalCostOfComp);
            Assert.AreEqual(data.IsFeeBasedAdvisor, model.IsFeeBasedAdvisor);
            Assert.AreEqual(data.TableCostPercentage, model.TableCostPercentage);
            Assert.AreEqual(data.AddOnTrailerPercentage, model.AddOnTrailerPercentage);

        }

        [Test]
        public void MapToLookupTest()
        {
            GeneralPlanData model = new GeneralPlanData()
            {
                PlanProposalId = 24,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };

            GeneralPlanDataModel data = new GeneralPlanDataModel();
            data.Map(model);
            Assert.AreEqual(data.PlanProposalId, model.PlanProposalId);
            Assert.AreEqual(data.PlanTypeLookupId, model.PlanTypeLookupId);
            Assert.AreEqual(data.PlanStateCode, model.PlanStateCode);
            Assert.AreEqual(data.IsAddASFToPlan, model.IsAddASFToPlan);
            Assert.AreEqual(data.PPANumber, model.PPANumber);
            Assert.AreEqual(data.RVPName, model.RVPName);
            Assert.AreEqual(data.DVPName, model.DVPName);
            Assert.AreEqual(data.IRONWilshireLeafHouseForThePlan, model.IRONWilshireLeafHouseForThePlan);
            Assert.AreEqual(data.OtherNonIRONWilshireFeePercentage, model.OtherNonIRONWilshireFeePercentage);
            Assert.AreEqual(data.TPAPPAPercentage, model.TPAPPAPercentage);
            Assert.AreEqual(data.IsCustomCompensationNeeded, model.IsCustomCompensationNeeded);
            Assert.AreEqual(data.AdvisorTotalCostOfComp, model.AdvisorTotalCostOfComp);
            Assert.AreEqual(data.IsFeeBasedAdvisor, model.IsFeeBasedAdvisor);
            Assert.AreEqual(data.TableCostPercentage, model.TableCostPercentage);
            Assert.AreEqual(data.AddOnTrailerPercentage, model.AddOnTrailerPercentage);

        }
    }
}
