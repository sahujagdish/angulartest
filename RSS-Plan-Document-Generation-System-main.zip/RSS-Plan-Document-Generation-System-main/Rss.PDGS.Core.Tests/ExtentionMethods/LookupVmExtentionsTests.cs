﻿using NUnit.Framework;
using Rss.PDGS.Core.Models;
using Rss.PDGS.Core.ExtentionMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rss.PDGS.DAL.BLL;

namespace Rss.PDGS.Core.Tests.ExtentionMethods
{
    internal class LookupVmExtentionsTests
    {
        [Test]
        public void MapToLookupTest()
        {
            LookupVm vm = new LookupVm() { Description = "Description", GroupName = "TestGroupName", LookupId = 123, SortOrder = 1, Value = "TestValue" };
            Lookup lookup = new Lookup();
            vm.MapToLookup(lookup);

            Assert.AreEqual(lookup.Description, vm.Description);
            Assert.AreEqual(lookup.GroupName, vm.GroupName);
            Assert.AreEqual(lookup.LookupId, vm.LookupId); 
            Assert.AreEqual(lookup.SortOrder, vm.SortOrder);
            Assert.AreEqual(lookup.Value, vm.Value);

        }

        [Test]
        public void MapFromLookupTest()
        {
            Lookup lookup = new Lookup() { Description = "Description", GroupName = "TestGroupName", Value = "TestValue", LookupId = 123, SortOrder = 1 };
            LookupVm vm = new LookupVm();
            vm.MapFromLookup(lookup);

            Assert.AreEqual(vm.Description, lookup.Description);
            Assert.AreEqual(vm.GroupName, lookup.GroupName);
            Assert.AreEqual(vm.Value, lookup.Value);
            Assert.AreEqual(vm.LookupId, lookup.LookupId);
            Assert.AreEqual(vm.SortOrder, lookup.SortOrder);
            
        }
    }
}
