﻿using AutoFixture;
using AutoFixture.Kernel;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using Rss.PDGS.Core.ExtentionMethods;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Tests.ExtentionMethods
{
    public class PricingDataModelUnitTest
    {
        [Test]
        public void Verify_model_to_data()
        {
            var fixture = new Fixture();
            fixture.Customizations.Add(
                new TypeRelay(
                    typeof(Rss.PDGS.DAL.BLL.IPricingData),
                    typeof(PricingData)));

            var empty = new PricingDataModel();
            var model = fixture.Create<IPricingData>();
            
            MappingExtensions.Map(empty, model);

            empty.Should().BeEquivalentTo(model, (x) =>
            {
                x.Excluding(y => y.AddBy)
                .Excluding(y => y.AddDate)
                .Excluding(y => y.ModifiedBy)
                .Excluding(y => y.ModifiedDate)
                .Excluding(y => y.PricingDataId);
                return x;
            });
        }

        [Test]
        public void Verify_data_to_model()
        {
            var fixture = new Fixture();
            fixture.Customizations.Add(
                new TypeRelay(
                    typeof(Rss.PDGS.DAL.BLL.IPricingData),
                    typeof(PricingData)));

            var model = fixture.Create<PricingDataModel>();
            var empty = Mock.Of<IPricingData>();

            MappingExtensions.Map(empty, model);

            empty.Should().BeEquivalentTo(model, (x) =>
            {
                x.Excluding(y => y.AddDate)
                .Excluding(y => y.IsDeleted);
                return x;
            });
        }
    }
}
