﻿using AutoFixture;
using FluentAssertions;
using FluentValidation.TestHelper;
using Moq;
using NUnit.Framework;
using Rss.PDGS.Core.Models;
using Rss.PDGS.Core.Validators;
using Rss.PDGS.DAL;
using Rss.PDGS.DAL.BLL;
using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Tests.Validators
{
    public class PricingDataModelValidatorUnitTests
    {
        IPlanProposalDATA planProposalDATA;
        IPlanTypeDATA planTypeDATA;
        Fixture fixture;
        IDalFactory dalFactory;

        [SetUp]
        public void Setup()
        {
            planProposalDATA = Mock.Of<IPlanProposalDATA>();
            planTypeDATA = Mock.Of<IPlanTypeDATA>();

            dalFactory = Mock.Of<IDalFactory>(x =>
            x.CreatePlanProposalDATA() == planProposalDATA &&
            x.CreatePlanTypeDATA() == planTypeDATA);
        }

        public PricingDataModelValidatorUnitTests()
        {
            fixture = new Fixture();
        }

        public PricingDataModel CreateModel()
        {
            return new PricingDataModel()
            {
                ProposalPricingLookupId = (int)Lookup.ProposalPricingType.Flexible_Advantage,
                TakeOverAmount = 5,
                FlowAmount = 5,
                NumberOfParticipantsWithBalance = 5,
                FixedProductLookupId = (int)Lookup.FixedProductType.Advisor_Fixed,
                FixedProductGrossRate = 0.05m,
                RateQuarterStartDate = new DateTime(DateTime.Now.Year, 1, 1),
                RateQuarterEndDate = new DateTime(DateTime.Now.Year, 3, 31),
                CompensationLookupId = (int)Lookup.Compensation_CDSC._405
            };
        }

        public PricingDataModelValidator CreateSut()
        {
            return new PricingDataModelValidator(dalFactory);
        }

        [Test]
        public void Valid_if_all_values_correct()
        {
            var model = CreateModel();
            var sut = CreateSut();
            sut.TestValidate(model).ShouldNotHaveAnyValidationErrors();
        }

        [Test]
        public void Test_AddOnTrailerPercentage()
        {
            var model = CreateModel();
            model.ProposalPricingLookupId = 0;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.ProposalPricingLookupId);
        }

        [Test]
        public void Test_TakeOver_FlowAmount()
        {
            var model = CreateModel();
            model.TakeOverAmount = 0;
            model.FlowAmount = 0;
            var sut = CreateSut();
            sut.TestValidate(model).Errors[0].ErrorMessage.
                Should().Be("TakeOverAmount + FlowAmount should be greater than zero.");
        }

        [Test]
        public void Test_NumberOfParticipantsWithBalance()
        {
            var model = CreateModel();
            model.NumberOfParticipantsWithBalance = 0;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.NumberOfParticipantsWithBalance);
        }

        [Test]
        public void Test_FixedProductLookup_IsAdvidorFixed_NotAllowed()
        {
            IPlanType planType = Mock.Of<IPlanType>(x=>x.IsFixedSelectAllowed == true);
            IPlanProposal proposal = Mock.Of<IPlanProposal>(x=>x.GeneralPlanData == Mock.Of<IGeneralPlanData>(x=>x.PlanTypeLookupId == fixture.Create<int>()));

            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).Returns(proposal);
            Mock.Get(planTypeDATA).Setup(x => x.GetByPlayTypeLookupId(It.IsAny<int>())).Returns(planType);

            var model = CreateModel();
            model.FixedProductLookupId = (int) Lookup.FixedProductType.Advisor_Fixed;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.FixedProductLookupId);
        }

        [Test]
        public void Test_FixedProductLookup_IsFixedSelectAllowed_NotAllowed()
        {
            IPlanType planType = Mock.Of<IPlanType>(x => x.IsAdvidorFixed == true);
            IPlanProposal proposal = Mock.Of<IPlanProposal>(x => x.GeneralPlanData == Mock.Of<IGeneralPlanData>(x => x.PlanTypeLookupId == fixture.Create<int>()));

            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).Returns(proposal);
            Mock.Get(planTypeDATA).Setup(x => x.GetByPlayTypeLookupId(It.IsAny<int>())).Returns(planType);

            var model = CreateModel();
            model.FixedProductLookupId = (int)Lookup.FixedProductType.Fixed_Select;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.FixedProductLookupId);
        }

        [Test]
        public void Test_FixedProductLookup_NotApplicable_Should_Pass()
        {
            IPlanType planType = Mock.Of<IPlanType>(x => x.IsAdvidorFixed == true && x.IsFixedSelectAllowed == true);
            IPlanProposal proposal = Mock.Of<IPlanProposal>(x => x.GeneralPlanData == Mock.Of<IGeneralPlanData>(x => x.PlanTypeLookupId == fixture.Create<int>()));

            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).Returns(proposal);
            Mock.Get(planTypeDATA).Setup(x => x.GetByPlayTypeLookupId(It.IsAny<int>())).Returns(planType);

            var model = CreateModel();
            model.FixedProductLookupId = (int)Lookup.FixedProductType.Not_Applicable;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldNotHaveValidationErrorFor(x => x.FixedProductLookupId);
        }

        [Test]
        public void Test_FixedProductGrossRate()
        {
            var model = CreateModel();
            model.FixedProductGrossRate = 0;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.FixedProductGrossRate);
        }

        [Test]
        public void Test_RateQuarterStartDate()
        {
            var model = CreateModel();
            model.RateQuarterStartDate = new DateTime(DateTime.Now.Year, 1, 20);
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.RateQuarterStartDate);
        }

        [Test]
        public void Test_RateQuarterEndDate()
        {
            var model = CreateModel();
            model.RateQuarterEndDate = new DateTime(DateTime.Now.Year, 1, 20);
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.RateQuarterEndDate);
        }

        [Test]
        public void Test_CompensationLookupId()
        {
            var model = CreateModel();
            model.CompensationLookupId = 0;
            var sut = CreateSut();
            sut.TestValidate(model).ShouldHaveValidationErrorFor(x => x.CompensationLookupId);
        }
    }
}
