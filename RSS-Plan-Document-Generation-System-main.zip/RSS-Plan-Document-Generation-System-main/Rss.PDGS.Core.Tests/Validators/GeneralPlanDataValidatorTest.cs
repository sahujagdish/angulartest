﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using FluentValidation;
using FluentValidation.TestHelper;
using Rss.PDGS.Core.Validators;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;

namespace Rss.PDGS.Core.Tests.Validators
{
    internal class GeneralPlanDataValidatorTest
    {
        private GeneralPlanDataValidator validator;
        private GeneralPlanDataModel models;
        public void setupModel()
        {
            models = new GeneralPlanDataModel()
            {
                PlanProposalId = 24,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };
        }
        [SetUp]
        public void Setup()
        {
            validator = new GeneralPlanDataValidator();

            models = new GeneralPlanDataModel()
            {
                PlanProposalId = 24,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };
        }

        [Test]
        public void Plantype()
        {
            setupModel();
            models.PlanTypeLookupId = 0;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.PlanTypeLookupId);
        }
        [Test]
        public void PlanStateCode()
        {
            setupModel();
            models.PlanStateCode = null;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.PlanStateCode);
        }
        
        [Test]
        public void PPA()
        {
            setupModel();
            models.PPANumber = -1;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.PPANumber);
        }
        [Test]
        public void RVP()
        {
            setupModel();
            models.RVPName = null;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.RVPName);
        }
        [Test]
        public void DVP()
        {
            setupModel();
            models.DVPName = null;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.DVPName);
        }
        [Test]
        public void IRON_Wilshire_LeafHouse()
        {
            setupModel();
            models.IRONWilshireLeafHouseForThePlan = null;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.IRONWilshireLeafHouseForThePlan);
        }
        [Test]
        public void Other_NonIRON_WilshireFee()
        {
            setupModel();
            models.OtherNonIRONWilshireFeePercentage = -12;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.OtherNonIRONWilshireFeePercentage);
        }
        [Test]
        public void TPA_PPACharge()
        {
            setupModel();
            models.TPAPPAPercentage = -12;
            var result = validator.TestValidate(models);
            result.ShouldHaveValidationErrorFor(models => models.TPAPPAPercentage);
        }

        


    }
}
