﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rss.PDGS.DAL.BLL;
using Moq;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.BusinessFacades;
using System.Configuration;
using System.Diagnostics;
using Wmsi.Utilities.DataAccess;
using System.IO;

namespace Rss.PDGS.Core.Tests.BusinessFacades
{
    [TestFixture]
    internal class LookupFacadeTests : CoreTestsBase
    {
        private ILookupFacade _lookupFacade;
        [SetUp]
        public void Setup()
        {
            _lookupFacade = new LookupFacade();

        }

        [Test]
        public void GetAllLookupsTest()
        {
            var allLookups = _lookupFacade.GetAllLookups();
            Assert.IsNotNull(allLookups);
            var allLookups2 = Lookup.GetAll();
            Assert.AreEqual(allLookups.Count, allLookups2.Count);
        }

        [Test]
        public void GetLookUpsByGroupNameTest()
        {
            string groupName = LookupGroup.YesNo.ToString();
            var lookupsResult = _lookupFacade.GetLookups(groupName);
            Assert.IsNotNull(lookupsResult);
            var allLookups = _lookupFacade.GetAllLookups();
            Assert.AreEqual(allLookups.Where(x => x.GroupName.ToLower() == groupName.ToLower()).Count(), lookupsResult.Count);

            lookupsResult = _lookupFacade.GetLookups(null);
            Assert.IsNotNull(lookupsResult);
            Assert.AreEqual(lookupsResult.Count, 0);

            lookupsResult = _lookupFacade.GetLookups(string.Empty);
            Assert.IsNotNull(lookupsResult);
            Assert.AreEqual(lookupsResult.Count, 0);

        }
    }
}
