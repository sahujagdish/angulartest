﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rss.PDGS.DAL.BLL;
using Moq;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.BusinessFacades;
using System.Configuration;
using System.Diagnostics;
using Wmsi.Utilities.DataAccess;
using System.IO;
using Rss.PDGS.Core.Models;

namespace Rss.PDGS.Core.Tests.BusinessFacades
{
    [TestFixture]
    internal class GeneralPlanDataFacadeTests : CoreTestsBase
    {
        private IGeneralPlanDataFacade _generalPlanDataFacade;
        [SetUp]
        public void Setup()
        {
            _generalPlanDataFacade = new GeneralPlanDataFacade();

        }
        [Test]
        public void SaveGeneralPlanDataTest()
        {
            GeneralPlanDataModel model = new GeneralPlanDataModel()
            {
                PlanProposalId = 99,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };
            long newGeneralPlanId = _generalPlanDataFacade.SaveGeneralPlanData(model);
            //Assert.IsNotNull(newGeneralPlanId);
            Assert.AreEqual(newGeneralPlanId, 0);

            model.PlanProposalId = 24;
            newGeneralPlanId = _generalPlanDataFacade.SaveGeneralPlanData(model);
            Assert.AreNotEqual(0, newGeneralPlanId);
        }

        [Test]
        public void GetGeneralPlanDataTest()
        {
            
            long newGeneralPlanId = _generalPlanDataFacade.GetGeneralPlanData(24).PlanProposalId;
            Assert.AreEqual(newGeneralPlanId, 24);
            Assert.AreNotEqual(0, newGeneralPlanId);

            GeneralPlanDataModel temp = _generalPlanDataFacade.GetGeneralPlanData(1);
            Assert.IsNull(temp);
        }

    }
}
