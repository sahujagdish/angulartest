﻿using AutoFixture;
using FluentAssertions;
using Moq;
using NUnit.Framework;
using Rss.PDGS.Core.BusinessFacades;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL.BLL;
using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Tests.BusinessFacades
{
    public class PricingDataFacadeTests : BaseUnitTest
    {
        [SetUp]
        public override void Setup() 
        {
            base.Setup();
        }

        public PricingDataFacade CreateSut()
        {
            return new PricingDataFacade(dalFactory, bllFactory,modelfactory);
        }

        [Test]
        public void SavePricingData_GetByPlanProposalId_returns_null_so_exit_with_zero()
        {
            var pricingDataFacade = CreateSut();
            var id = pricingDataFacade.SavePricingData(new Models.PricingDataModel());
            id.Should().Be(0);
        }

        [Test]
        public void PlanProposal_null_pricingData_calls_CreatePricingData()
        {
            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).Returns(Mock.Of<IPlanProposal>());          
            var sut = CreateSut();
            sut.SavePricingData(fixture.Create<PricingDataModel>());
            Mock.Get(bllFactory).Verify(x=>x.CreatePricingData(),Times.Once());
        }

        [Test]
        public void SavePricingData_calls_map()
        {
            var sink = Mock.Of<IPricingData>();
            var model = fixture.Create<PricingDataModel>();
            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).
                Returns(Mock.Of<IPlanProposal>(x=>x.PricingData == sink));
            var sut = CreateSut();
            var id = sut.SavePricingData(model);
            sink.FixedProductLookupId.Should().Be(model.FixedProductLookupId);
        }

        [Test]
        public void SavePricingData_calls_save()
        {
            var data = Mock.Of<IPricingData>();
            Mock.Get(bllFactory).Setup(x=>x.CreatePricingData()).Returns(data);

            Mock.Get(planProposalDATA).Setup(x => x.GetByPlanProposalId(It.IsAny<long>())).Returns(Mock.Of<IPlanProposal>());
            var sut = CreateSut();
            sut.SavePricingData(fixture.Create<PricingDataModel>());
            Mock.Get(data).Verify(x => x.Save(It.IsAny<string>()), Times.Once());
        }

        [Test]
        public void GetPricingData_calls_CreatePricingDataDATA() 
        {
            Mock.Get(dalFactory).Setup(x=>x.CreatePricingDataDATA()).Returns(Mock.Of<IPricingDataDATA>());
            var sut = CreateSut();
            sut.GetPricingData(fixture.Create<long>());
            Mock.Get(dalFactory).Verify(x => x.CreatePricingDataDATA(), Times.Once);
        }

        [Test]
        public void GetPricingData_calls_GetByPlanProposalId() 
        {
            var data = Mock.Of<IPricingDataDATA>();
            Mock.Get(dalFactory).Setup(x => x.CreatePricingDataDATA()).Returns(data);
            var sut = CreateSut();
            sut.GetPricingData(fixture.Create<long>());
            Mock.Get(data).Verify(x => x.GetByPlanProposalId(It.IsAny<long>()), Times.Once);
        }

        [Test]
        public void GetPricingData_calls_CreatePricingDataModel() 
        {
            Mock.Get(dalFactory).Setup(x => x.CreatePricingDataDATA()).Returns(Mock.Of<IPricingDataDATA>());
            var sut = CreateSut();
            sut.GetPricingData(fixture.Create<long>());
            Mock.Get(modelfactory).Verify(x => x.CreatePricingDataModel(), Times.Once);
        }

        public void GetPricingData_calls_map_and_verify_returned_object()
        {
            var pricingData = fixture.Create<IPricingData>();
            Mock.Get(modelfactory).Setup(x => x.CreatePricingDataModel()).Returns(Mock.Of<PricingDataModel>());
            Mock.Get(dalFactory).Setup(x => x.CreatePricingDataDATA()).Returns
                (Mock.Of<IPricingDataDATA>(q => q.GetByPlanProposalId(It.IsAny<long>()) == pricingData));
            var sut = CreateSut();
            var model = sut.GetPricingData(fixture.Create<long>());
            model.FixedProductGrossRate.Should().Be(pricingData.FixedProductGrossRate);
        }
    }
}
