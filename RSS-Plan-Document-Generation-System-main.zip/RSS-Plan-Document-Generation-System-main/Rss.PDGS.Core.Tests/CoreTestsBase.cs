﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wmsi.Utilities.DataAccess;

namespace Rss.PDGS.Core.Tests
{
    internal class CoreTestsBase
    {
        public CoreTestsBase()
        {
           // DbConnectionOptions.SetConnectionString("Rss.PDGS.Database", @"Data Source=(localdb)\ProjectModels;Initial Catalog=Rss.PDGS.Database;Integrated Security=True");
        }
    }
}
