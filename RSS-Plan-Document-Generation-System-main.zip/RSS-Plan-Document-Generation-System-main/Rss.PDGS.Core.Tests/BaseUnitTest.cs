﻿using AutoFixture;
using Moq;
using Rss.PDGS.Core.Models;
using Rss.PDGS.DAL;
using Rss.PDGS.DAL.BLL;
using Rss.PDGS.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Core.Tests
{
    public class BaseUnitTest
    {
        protected IDalFactory dalFactory;
        protected IBllFactory bllFactory;
        protected IModelFactory modelfactory;
        protected Fixture fixture;
        protected IPlanProposalDATA planProposalDATA;

        public virtual void Setup()
        {
            fixture = new Fixture();

            planProposalDATA = Mock.Of<IPlanProposalDATA>();

            dalFactory = Mock.Of<IDalFactory>(x=>x.CreatePlanProposalDATA() == planProposalDATA);
            bllFactory = Mock.Of<IBllFactory>(x=>x.CreatePricingData() == Mock.Of<IPricingData>());
            modelfactory = Mock.Of<IModelFactory>();
            
        }
    }
}
