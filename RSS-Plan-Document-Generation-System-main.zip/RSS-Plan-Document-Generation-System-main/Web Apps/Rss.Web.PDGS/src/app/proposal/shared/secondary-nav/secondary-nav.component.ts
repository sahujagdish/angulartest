import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from 'src/app/core/resource.service';

@Component({
  selector: 'app-secondary-nav',
  templateUrl: './secondary-nav.component.html'
})
export class SecondaryNavComponent extends BaseComponent implements OnInit {
  secondaryNav: any;

  constructor(private resourceService: ResourceService) { 
    super();
    this.secondaryNav=[];
   }

  ngOnInit(): void {
    this.resourceService.getResource('proposal.secondary-nav').then(value => this.secondaryNav = value);
  }
}