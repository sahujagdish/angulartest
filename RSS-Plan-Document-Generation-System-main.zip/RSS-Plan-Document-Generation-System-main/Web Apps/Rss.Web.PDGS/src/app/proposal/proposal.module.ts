import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProposalRoutingModule } from './proposal-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CoreModule } from '../core/core.module';
import { SummaryComponent } from './summary/summary.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { CommunicationLogComponent } from './communication-log/communication-log.component';
import { StatusHistoryComponent } from './summary/status-history/status-history.component';
import { OtherSystemVerificationComponent } from './summary/other-system-verification/other-system-verification.component';
import { PlanRelatedDocumentsComponent } from './summary/plan-related-documents/plan-related-documents.component';
import { SummaryDataCollectionComponent}  from './summary/data-collection/data-collection.component';
import { ProposalComponent } from './summary/data-collection/proposal/proposal.component';
import { LegalComponent } from './summary/data-collection/legal/legal.component';
import { PlanSetupComponent } from './summary/data-collection/plan-setup/plan-setup.component';
import { PlanInformationComponent } from './summary/data-collection/legal/plan-information/plan-information.component';
import { ProductServiceInformationComponent } from './summary/data-collection/legal/product-service-information/product-service-information.component';
import { AdditionalPlanInformationComponent } from './summary/data-collection/legal/additional-plan-information/additional-plan-information.component';
import { AdditionalServiceInformationComponent } from './summary/data-collection/legal/additional-service-information/additional-service-information.component';
import { ProposalHistoryComponent } from './summary/status-history/proposal-history/proposal-history.component';
import { BinderHistoryComponent } from './summary/status-history/binder-history/binder-history.component';
import { CurrentProviderInformationComponent } from './summary/data-collection/legal/current-provider-information/current-provider-information.component';
import { DataComponent } from './summary/data-collection/plan-setup/data/data.component';
import { SecondaryNavComponent } from './shared/secondary-nav/secondary-nav.component';
import { PricingOutputComponent } from './summary/data-collection/proposal/pricing-output/pricing-output.component';

@NgModule({
  declarations: [
    DashboardComponent,
    SummaryComponent,
    SearchResultsComponent,
    CommunicationLogComponent,
    StatusHistoryComponent,
    OtherSystemVerificationComponent,
    PlanRelatedDocumentsComponent,
    SummaryDataCollectionComponent,
    ProposalComponent,
    LegalComponent,
    PlanSetupComponent,
    PlanInformationComponent,
    ProductServiceInformationComponent,
    AdditionalPlanInformationComponent,
    AdditionalServiceInformationComponent,
    ProposalHistoryComponent,
    BinderHistoryComponent,
    CurrentProviderInformationComponent,
    DataComponent,
    SecondaryNavComponent,
    PricingOutputComponent
  ],
  imports: [
    CommonModule,
    ProposalRoutingModule,
    CoreModule
  ]  
})
export class ProposalModule { }