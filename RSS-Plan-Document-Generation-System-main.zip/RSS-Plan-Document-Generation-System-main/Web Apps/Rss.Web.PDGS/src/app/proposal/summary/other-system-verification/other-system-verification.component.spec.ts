import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherSystemVerificationComponent } from './other-system-verification.component';

describe('OtherSystemVerificationComponent', () => {
  let component: OtherSystemVerificationComponent;
  let fixture: ComponentFixture<OtherSystemVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherSystemVerificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherSystemVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
