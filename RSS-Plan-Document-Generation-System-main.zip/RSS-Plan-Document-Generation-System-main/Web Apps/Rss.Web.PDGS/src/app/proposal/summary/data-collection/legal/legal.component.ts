import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-legal',
  templateUrl: './legal.component.html'
})
export class LegalComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }

}
