import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-additional-service-information',
  templateUrl: './additional-service-information.component.html'
})
export class AdditionalServiceInformationComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}