import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html'
})
export class DataComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}