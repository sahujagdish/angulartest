import { Component, OnInit } from '@angular/core';
import { DenyComponent } from './../../../../core/modals/deny/deny.component';
import { MdbModalService } from 'mdb-angular-ui-kit/modal';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from 'src/app/core/resource.service';

@Component({
  selector: 'app-binder-history',
  templateUrl: './binder-history.component.html'
})
export class BinderHistoryComponent extends BaseComponent implements OnInit {

  constructor(private modalService: MdbModalService, private resourceService: ResourceService) { 
    super();
   }

  ngOnInit(): void {
  }

  openModal() {
    this.modalService.open(DenyComponent, {
      modalClass: 'modal-dialog-centered',
      data: {
        resourceId: 'proposal.summary.modal'
      }
    });
  }
}