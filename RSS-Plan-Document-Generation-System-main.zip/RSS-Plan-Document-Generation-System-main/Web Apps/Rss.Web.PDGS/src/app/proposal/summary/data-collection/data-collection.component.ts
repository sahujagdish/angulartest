import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from 'src/app/core/resource.service';

@Component({
  selector: 'app-summary-data-collection',
  templateUrl: './data-collection.component.html'
})
export class SummaryDataCollectionComponent extends BaseComponent implements OnInit {

  proposal: string;
  legal: string;
  planSetup: string;

  constructor(private resourceService: ResourceService) { 
    super();

    this.proposal='';
    this.legal='';
    this.planSetup='';
   }

  ngOnInit(): void {
    this.resourceService.getResource('buttons.proposal').then(value => this.proposal = value);
    this.resourceService.getResource('buttons.legal').then(value => this.legal = value);
    this.resourceService.getResource('buttons.plan-setup').then(value => this.planSetup = value);
  }
}