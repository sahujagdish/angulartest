import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proposal-history',
  templateUrl: './proposal-history.component.html'
})
export class ProposalHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}