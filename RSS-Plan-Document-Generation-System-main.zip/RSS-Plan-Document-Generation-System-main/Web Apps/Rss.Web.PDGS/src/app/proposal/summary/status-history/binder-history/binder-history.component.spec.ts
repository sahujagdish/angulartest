import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BinderHistoryComponent } from './binder-history.component';

describe('BinderHistoryComponent', () => {
  let component: BinderHistoryComponent;
  let fixture: ComponentFixture<BinderHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BinderHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BinderHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
