import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductServiceInformationComponent } from './product-service-information.component';

describe('ProductServiceInformationComponent', () => {
  let component: ProductServiceInformationComponent;
  let fixture: ComponentFixture<ProductServiceInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductServiceInformationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductServiceInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
