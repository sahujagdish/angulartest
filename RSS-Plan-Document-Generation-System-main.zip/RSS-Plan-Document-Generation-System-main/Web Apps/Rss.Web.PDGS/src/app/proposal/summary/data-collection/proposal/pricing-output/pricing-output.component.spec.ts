import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PricingOutputComponent } from './pricing-output.component';

describe('PricingOutputComponent', () => {
  let component: PricingOutputComponent;
  let fixture: ComponentFixture<PricingOutputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PricingOutputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingOutputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
