import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-product-service-information',
  templateUrl: './product-service-information.component.html'
})
export class ProductServiceInformationComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}