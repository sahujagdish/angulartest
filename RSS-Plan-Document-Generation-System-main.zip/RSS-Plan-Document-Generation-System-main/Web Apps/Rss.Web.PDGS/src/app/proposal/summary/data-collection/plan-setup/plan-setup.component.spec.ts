import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanSetupComponent } from './plan-setup.component';

describe('PlanSetupComponent', () => {
  let component: PlanSetupComponent;
  let fixture: ComponentFixture<PlanSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
