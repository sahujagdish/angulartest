import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-additional-plan-information',
  templateUrl: './additional-plan-information.component.html'
})
export class AdditionalPlanInformationComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}