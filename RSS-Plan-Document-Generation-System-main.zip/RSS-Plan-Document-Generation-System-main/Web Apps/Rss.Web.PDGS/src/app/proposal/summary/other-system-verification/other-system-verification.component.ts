import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-system-verification',
  templateUrl: './other-system-verification.component.html'
})
export class OtherSystemVerificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
