import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalServiceInformationComponent } from './additional-service-information.component';

describe('AdditionalServiceInformationComponent', () => {
  let component: AdditionalServiceInformationComponent;
  let fixture: ComponentFixture<AdditionalServiceInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdditionalServiceInformationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalServiceInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
