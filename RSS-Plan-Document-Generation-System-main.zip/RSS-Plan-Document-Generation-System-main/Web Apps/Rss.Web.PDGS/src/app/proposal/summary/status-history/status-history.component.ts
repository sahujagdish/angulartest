import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-status-history',
  templateUrl: './status-history.component.html'
})
export class StatusHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}