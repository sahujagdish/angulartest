import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentProviderInformationComponent } from './current-provider-information.component';

describe('CurrentProviderInformationComponent', () => {
  let component: CurrentProviderInformationComponent;
  let fixture: ComponentFixture<CurrentProviderInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentProviderInformationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentProviderInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
