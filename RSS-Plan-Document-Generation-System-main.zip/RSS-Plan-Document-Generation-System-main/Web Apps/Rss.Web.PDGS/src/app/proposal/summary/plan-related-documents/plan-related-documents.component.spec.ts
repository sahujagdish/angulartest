import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanRelatedDocumentsComponent } from './plan-related-documents.component';

describe('PlanRelatedDocumentsComponent', () => {
  let component: PlanRelatedDocumentsComponent;
  let fixture: ComponentFixture<PlanRelatedDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanRelatedDocumentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanRelatedDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
