import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-related-documents',
  templateUrl: './plan-related-documents.component.html'
})
export class PlanRelatedDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
