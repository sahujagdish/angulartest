import { Component, OnInit } from '@angular/core';
import { DenyComponent } from './../../core/modals/deny/deny.component';
import { MdbModalService } from 'mdb-angular-ui-kit/modal';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from 'src/app/core/resource.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html'
})
export class SummaryComponent extends BaseComponent implements OnInit {
  
  dataCollection: string;
  statusHistory: string;
  otherSystemVerification: string;
  planRelatedDocs: string;

  secondaryNav: any;


  constructor(private modalService: MdbModalService, private resourceService: ResourceService) { 
   // this.modalRef: any;
    super();
    this.dataCollection='';
    this.statusHistory='';
    this.otherSystemVerification='';
    this.planRelatedDocs='';
    this.secondaryNav=[];
  }

  ngOnInit(): void {
    this.resourceService.getResource('proposal.data-collection.pageTitle').then(value => this.dataCollection = value);
    this.resourceService.getResource('proposal.status-history.pageTitle').then(value => this.statusHistory = value);
    this.resourceService.getResource('proposal.other-system-verification.pageTitle').then(value => this.otherSystemVerification = value);
    this.resourceService.getResource('proposal.plan-related-documents.pageTitle').then(value => this.planRelatedDocs = value);
    this.resourceService.getResource('proposal.secondary-nav').then(value => this.secondaryNav = value);
  }
  
  openModal() {
    this.modalService.open(DenyComponent, {
      modalClass: 'modal-dialog-centered',
      data: {
        resourceId: 'proposal.summary.modal'
      }
    });
  }
}