import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-output',
  templateUrl: './pricing-output.component.html'
})
export class PricingOutputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}