import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../core/auth/auth.guard';
import { CommunicationLogComponent } from './communication-log/communication-log.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { SummaryComponent } from './summary/summary.component';

const routes: Routes = [
  {
    path: '',
    component: DashboardComponent, canActivate: [AuthGuard]
  },
  {
    path: 'search-results', component: SearchResultsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'data-collection', component: SummaryComponent, canActivate: [AuthGuard]
  },
  {
    path: 'communication-log', component: CommunicationLogComponent, canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProposalRoutingModule { }