import { NgModule } from '@angular/core';
import { CommonModule as AngularCommon } from '@angular/common';

import { CommonRoutingModule } from './common-routing.module';
import { DocumentViewerComponent } from './document-viewer/document-viewer.component';
import { CoreModule } from '../core/core.module';


@NgModule({
  declarations: [
    DocumentViewerComponent
  ],
  imports: [
    AngularCommon,
    CommonRoutingModule,
    CoreModule
  ]
})
export class CommonModule { }
