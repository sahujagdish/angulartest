import { Component, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-user-role',
  templateUrl: './user-role.component.html'
})
export class UserRoleComponent extends BaseComponent implements OnInit {

  constructor() {
    super()
   }

  ngOnInit(): void {
    //throw new Error('test');
  }

}
