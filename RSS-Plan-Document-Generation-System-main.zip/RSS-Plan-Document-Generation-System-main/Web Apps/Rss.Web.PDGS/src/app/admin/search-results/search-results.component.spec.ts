import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSearchResultsComponent } from './search-results.component';

describe('SearchResultsComponent', () => {
  let component: AdminSearchResultsComponent;
  let fixture: ComponentFixture<AdminSearchResultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminSearchResultsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
