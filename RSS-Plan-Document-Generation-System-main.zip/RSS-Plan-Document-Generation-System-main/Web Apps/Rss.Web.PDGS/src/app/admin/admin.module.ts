import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { CoreModule } from '../core/core.module';
import { UserRoleComponent } from './user-role/user-role.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminSearchResultsComponent } from './search-results/search-results.component';


@NgModule({
  declarations: [
    UserRoleComponent,
    DashboardComponent,
    AdminSearchResultsComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    CoreModule
  ]
})
export class AdminModule { }
