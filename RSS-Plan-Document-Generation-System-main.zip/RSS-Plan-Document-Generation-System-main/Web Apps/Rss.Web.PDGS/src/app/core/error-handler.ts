import { ErrorHandler as AngularErrorHandler, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StatusCodes } from 'http-status-codes'

@Injectable()
export class ErrorHandler extends AngularErrorHandler {

  constructor(private router: Router) {
    super();
   }

    
   handleError(error: any) : void {
    switch (error.status) {
      case StatusCodes.UNAUTHORIZED:
        this.router.navigateByUrl('/unauthorized');
        break;

      case StatusCodes.FORBIDDEN:
        this.router.navigateByUrl('/unauthorized');
        break;

      case StatusCodes.NOT_FOUND:
        this.router.navigateByUrl('/not-implemented');
        break;

      default:
        this.router.navigateByUrl('/unexpected-error');
        break;
    }

    // TODO: log error 
    super.handleError(error);
  }
}
