import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ResourceService {
  private resources: Promise<any>;

  constructor(httpClient: HttpClient) { 
    this.resources = httpClient.get("assets/resources.json")
      .toPromise(); 
  }

  getResource(id: string) : Promise<string> {
    return this.resources.then(data => {
      if(id) {
        let value = id.split('.').reduce((prev, curr) => prev ? prev[curr] : null, data || self);
        if(value) {
          return value;
        }
      }

      return id;
    });
  }
}
