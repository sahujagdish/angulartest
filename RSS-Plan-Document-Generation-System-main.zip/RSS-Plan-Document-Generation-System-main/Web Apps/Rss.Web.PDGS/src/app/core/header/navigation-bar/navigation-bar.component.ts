import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html'
})
export class NavigationBarComponent extends BaseComponent implements OnInit {

  @Input('nav-generate-button')
  navGenerateButton: boolean =  false;

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}