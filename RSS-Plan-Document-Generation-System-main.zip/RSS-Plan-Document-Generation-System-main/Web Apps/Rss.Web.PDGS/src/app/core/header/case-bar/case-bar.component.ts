import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';

@Component({
  selector: 'app-case-bar',
  templateUrl: './case-bar.component.html'
})
export class CaseBarComponent extends BaseComponent implements OnInit {
  @Input('hide-case-bar')
  hideCaseBar: boolean = false;

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }

}
