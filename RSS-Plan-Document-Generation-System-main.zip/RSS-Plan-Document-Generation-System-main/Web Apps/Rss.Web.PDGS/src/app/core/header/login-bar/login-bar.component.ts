import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-bar',
  templateUrl: './login-bar.component.html'
})
export class LoginBarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
