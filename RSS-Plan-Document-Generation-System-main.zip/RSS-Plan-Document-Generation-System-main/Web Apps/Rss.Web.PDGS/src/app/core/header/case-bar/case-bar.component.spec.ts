import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseBarComponent } from './case-bar.component';

describe('CaseBarComponent', () => {
  let component: CaseBarComponent;
  let fixture: ComponentFixture<CaseBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
