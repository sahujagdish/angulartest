import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent extends BaseComponent implements OnInit {
  @Input('generate-button')
  generateButton: boolean = false;

  @Input('hide-case-bar')
  hideCaseBar: boolean = false;
  
  navGenerateButton: boolean = false;
  headerCaseBar: boolean = false;

  constructor() {
    super();
   }

  ngOnInit(): void {
    this.navGenerateButton = this.generateButton;
    this.headerCaseBar = this.hideCaseBar;
  }
}