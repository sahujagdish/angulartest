import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ResourceService } from '../resource.service';

@Component({
  selector: 'app-popover',
  templateUrl: './popover.component.html'
})
export class PopoverComponent extends BaseComponent implements OnInit {

  popOverValue: string;

  constructor(private resourceService: ResourceService) { 
    super();
    this.popOverValue = '';
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.popOver').then(value => this.popOverValue = value);
  }
}