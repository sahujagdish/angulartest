import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';

export interface Person {
  name: string;
  position: string;
  office: string;
  age: number;
  startDate: string;
  salary: string;
  name1: string;
  position1: string;
  office1: string;
  age1: number;
  startDate1: string;
  salary1: string;
}
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html'
})
export class TableComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
  }

  headers = ['Name', 'Position', 'Office', 'Age', 'Start Date', 'Salary', 'Name1', 'Position1', 'Office1', 'Age1', 'Start Date1', 'Salary1'];

  dataSource: Person[] = [
    {
      name: 'Tiger Nixon',
      position: 'System Architect',
      office: 'Edinburgh',
      age: 61,
      startDate: '2011/04/25',
      salary: '$320,800',
      name1: 'Tiger Nixon',
      position1: 'System Architect',
      office1: 'Edinburgh',
      age1: 61,
      startDate1: '2011/04/25',
      salary1: '$320,800'
    },
    {
      name: 'Sonya Frost',
      position: 'Software Engineer',
      office: 'Edinburgh',
      age: 23,
      startDate: '2008/12/13',
      salary: '$103,600',
      name1: 'Sonya Frost',
      position1: 'Software Engineer',
      office1: 'Edinburgh',
      age1: 23,
      startDate1: '2008/12/13',
      salary1: '$103,600'
    }
  ];

  ngOnInit(): void {
  }

}