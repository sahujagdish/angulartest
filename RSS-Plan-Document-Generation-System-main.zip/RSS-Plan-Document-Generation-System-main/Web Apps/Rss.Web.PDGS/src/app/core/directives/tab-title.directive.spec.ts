import { TabTitleDirective } from './tab-title.directive';

describe('TabTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new TabTitleDirective();
    expect(directive).toBeTruthy();
  });
});
