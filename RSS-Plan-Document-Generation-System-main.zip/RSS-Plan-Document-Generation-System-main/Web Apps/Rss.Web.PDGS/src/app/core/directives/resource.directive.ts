import { Directive, ElementRef, Input, OnInit } from '@angular/core';
import { ResourceService } from '../resource.service';

@Directive({
  selector: '[resource-id]'
})
export class ResourceDirective implements OnInit {

  @Input('resource-id') 
  resourceId: string = '';
 
  constructor(private el: ElementRef, private resourceService: ResourceService) { }
  
  ngOnInit(): void {
    this.resourceService
      .getResource(this.resourceId)
      .then(value => this.el.nativeElement.innerHTML = value);
  }
}
