import { Directive, ElementRef, Input } from '@angular/core';
import { ResourceService } from '../resource.service';

@Directive({
  selector: '[tab-title-id]'
})
export class TabTitleDirective {

  @Input('tab-title-id') 
  tabTitleId: string = '';
 
  constructor(private el: ElementRef, private resourceService: ResourceService) { }
  
  ngOnInit(): void {
      this.resourceService
      .getResource(this.tabTitleId)
      .then(value => {
        this.el.nativeElement.setAttribute('title',value);
      });
  }
}