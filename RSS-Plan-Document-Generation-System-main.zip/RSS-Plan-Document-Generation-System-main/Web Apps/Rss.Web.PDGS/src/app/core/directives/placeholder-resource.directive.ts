import { Directive, ElementRef, HostBinding, Input, OnInit } from '@angular/core';
import { ResourceService } from '../resource.service';

@Directive({
  selector: '[placeholder-resource-id]'
})

export class PlaceholderResourceDirective implements OnInit {

  @Input('placeholder-resource-id') 
  resourcePhId: string = '';

  @HostBinding('placeholder')
  placeHolder: string='';
 
  constructor(private el: ElementRef, private resourceService: ResourceService) { }
  
  ngOnInit(): void {
    this.resourceService
      .getResource(this.resourcePhId)
      .then(value => {
        this.el.nativeElement.setAttribute('placeholder',value);
      });
  }
}