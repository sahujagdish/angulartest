import { PlaceholderResourceDirective } from './placeholder-resource.directive';

describe('PlaceholderResourceDirective', () => {
  it('should create an instance', () => {
    const directive = new PlaceholderResourceDirective();
    expect(directive).toBeTruthy();
  });
});
