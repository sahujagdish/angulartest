import { ResourceDirective } from './resource.directive';

describe('ResourceDirective', () => {
  it('should create an instance', () => {
    const directive = new ResourceDirective();
    expect(directive).toBeTruthy();
  });
});
