import { Component, Input, OnInit } from '@angular/core';
import { ResourceService } from '../resource.service';

@Component({
  selector: 'app-resource',
  templateUrl: './app-resource.component.html'
})
export class AppResourceComponent implements OnInit {

  @Input('id') 
  resourceId: string = '';

  value: string;

  constructor(private resourceService: ResourceService) { 
    this.value = '';
  }

  ngOnInit(): void {
    this.resourceService
      .getResource(this.resourceId)
      .then(value => this.value = value);
  }
}
