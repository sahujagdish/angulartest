import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-date-input',
  templateUrl: './date-input.component.html'
})
export class DateInputComponent extends BaseComponent implements OnInit {

  mdbDatePlaceholder: string;

  constructor(private resourceService: ResourceService) { 
    super();
    this.mdbDatePlaceholder = '';
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.placeHolder').then(value => this.mdbDatePlaceholder = value);
  }
}