import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioVerticalComponent } from './radio-vertical.component';

describe('RadioVerticalComponent', () => {
  let component: RadioVerticalComponent;
  let fixture: ComponentFixture<RadioVerticalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RadioVerticalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioVerticalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
