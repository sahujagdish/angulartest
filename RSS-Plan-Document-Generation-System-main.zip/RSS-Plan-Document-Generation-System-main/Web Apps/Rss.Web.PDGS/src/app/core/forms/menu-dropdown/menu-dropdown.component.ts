import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-menu-dropdown',
  templateUrl: './menu-dropdown.component.html'
})
export class MenuDropdownComponent  extends BaseComponent implements OnInit {

  menuItems: any;

  constructor(private resourceService: ResourceService) { 
    super();
    this.menuItems=[];
   }

  ngOnInit(): void {
    this.resourceService.getResource('admin.search-menu.menu-items').then(value => this.menuItems = value);
  }
}