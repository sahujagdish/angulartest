import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-radio-vertical',
  templateUrl: './radio-vertical.component.html'
})
export class RadioVerticalComponent extends BaseComponent implements OnInit {

  radioValues: any;

  constructor(private resourceService: ResourceService) { 
    super();
    this.radioValues=[];
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.values').then(value => this.radioValues = value);
  }
}