import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-textarea-input',
  templateUrl: './textarea-input.component.html'
})
export class TextareaInputComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
   }

  ngOnInit(): void {
  }
}