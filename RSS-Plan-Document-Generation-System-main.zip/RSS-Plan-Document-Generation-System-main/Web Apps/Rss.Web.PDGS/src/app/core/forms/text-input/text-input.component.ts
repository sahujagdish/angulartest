import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';

@Component({
  selector: 'app-text-input',
  templateUrl: './text-input.component.html'
})
export class TextInputComponent extends BaseComponent implements OnInit {

  hasError: boolean = false;

  constructor() { 
    super();
   }

  ngOnInit(): void {
    this.hasError = false;
  }
}