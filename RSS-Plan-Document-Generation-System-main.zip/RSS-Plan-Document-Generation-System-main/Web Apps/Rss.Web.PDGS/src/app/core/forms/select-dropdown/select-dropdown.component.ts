import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MdbSelectComponent } from 'mdb-angular-ui-kit/select';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-select-dropdown',
  templateUrl: './select-dropdown.component.html'
})
export class SelectDropdownComponent extends BaseComponent implements OnInit {
  options = [
    { value: '1', label: 'One' },
    { value: '2', label: 'Two' },
    { value: '3', label: 'Three' },
    { value: '4', label: 'Four' },
    { value: '5', label: 'Five' },
    { value: '6', label: 'Six' },
    { value: '7', label: 'Seven' },
    { value: '8', label: 'Eight' }
  ];

  mdbSelectPlaceholder: string;

  constructor(private resourceService: ResourceService) { 
    super();
    this.mdbSelectPlaceholder = '';
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.placeHolder').then(value => this.mdbSelectPlaceholder = value);
  }
}