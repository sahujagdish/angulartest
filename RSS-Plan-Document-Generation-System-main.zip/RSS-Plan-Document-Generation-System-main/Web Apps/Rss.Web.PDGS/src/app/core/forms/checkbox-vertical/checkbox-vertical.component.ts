import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-checkbox-vertical',
  templateUrl: './checkbox-vertical.component.html'
})
export class CheckboxVerticalComponent extends BaseComponent implements OnInit {

  checkboxValues: any;

  constructor(private resourceService: ResourceService) { 
    super();
    this.checkboxValues=[];
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.values').then(value => this.checkboxValues = value);
  }
}