import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { CurrencyMaskInputMode } from 'ngx-currency';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-currency-input',
  templateUrl: './currency-input.component.html'
})
export class CurrencyInputComponent extends BaseComponent implements OnInit {
  @ViewChild('currencyInput', { static: true }) currencyInput: any;
  currencyPlaceholder: string;

  public ngxCurrencyOptions = {
    align: 'left',
    prefix: '$',
    precision: 0,
    thousands: ',',
    decimal: '.',
    allowNegative: true,
    allowZero: true,
    nullable: true,
    max: 1,
    inputMode: CurrencyMaskInputMode.NATURAL
  };

  currencyValue = null;

  constructor(private formBuilder: FormBuilder, private resourceService: ResourceService) { 
    super();
    this.currencyPlaceholder='';
  }

  ngOnInit(): void {
    this.resourceService.getResource('common.placeholders.currency').then(value => this.currencyPlaceholder = value);
    this.resourceService.getResource('mask.currency.precision').then(value => this.ngxCurrencyOptions.precision = Number(value));
    this.resourceService.getResource('mask.currency.max').then(value => this.ngxCurrencyOptions.max = Number(value));
  }
}