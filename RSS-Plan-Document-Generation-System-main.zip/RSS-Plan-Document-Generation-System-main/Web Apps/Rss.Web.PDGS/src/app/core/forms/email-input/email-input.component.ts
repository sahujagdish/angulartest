import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-email-input',
  templateUrl: './email-input.component.html'
})
export class EmailInputComponent  extends BaseComponent implements OnInit {
  @Input('label-title')
  labelTitleId: string = '';

  labelTitle: string;

  constructor(private resourceService: ResourceService) { 
    super();
    this.labelTitle='';
   }

  ngOnInit(): void {
    this.resourceService .getResource(this.labelTitleId).then(value => this.labelTitle = value);
  }
}