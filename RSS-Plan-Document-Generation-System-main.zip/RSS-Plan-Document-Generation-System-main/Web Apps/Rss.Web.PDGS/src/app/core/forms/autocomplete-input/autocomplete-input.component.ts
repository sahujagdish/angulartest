import { Component, Input, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-autocomplete-input',
  templateUrl: './autocomplete-input.component.html'
})
export class AutocompleteInputComponent extends BaseComponent implements OnInit {
  @Input('label-title')
  labelTitleId: string = '';
  labelTitleIdValue: string;

  searchText = new Subject<string>();
  results: Observable<string[]>;
  notFound = false;

  data = ['One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight'];

  constructor(private resourceService: ResourceService) {
    super();
    this.labelTitleIdValue = '';
    this.results = this.searchText.pipe(
      startWith(''),
      map((value: string) => this.filter(value))
    );
  }

  ngOnInit(): void {
    this.resourceService.getResource(this.labelTitleId).then(labelTitleIdValue => this.labelTitleIdValue = labelTitleIdValue);
  }

  filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.data.filter((item: string) => item.toLowerCase().includes(filterValue));
  }
}