import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioHorizontalComponent } from './radio-horizontal.component';

describe('RadioHorizontalComponent', () => {
  let component: RadioHorizontalComponent;
  let fixture: ComponentFixture<RadioHorizontalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RadioHorizontalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioHorizontalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
