import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from '../../resource.service';
@Component({
  selector: 'app-multi-select-dropdown',
  templateUrl: './multi-select-dropdown.component.html'
})
export class MultiSelectDropdownComponent extends BaseComponent implements OnInit {
  options = [
    { value: '1', label: 'One' },
    { value: '2', label: 'Two' },
    { value: '3', label: 'Three' },
    { value: '4', label: 'Four' },
    { value: '5', label: 'Five' },
    { value: '6', label: 'Six' },
    { value: '7', label: 'Seven' },
    { value: '8', label: 'Eigth' },
  ];

  @Input('label-title')
  labelTitleId: string = '';

  @Input('select-default')
  selectTitleId: string = '';

  labelTitleIdValue: string;
  selectTitleIdValue: string;

  mdbSelectPlaceholder: string;

  constructor(private resourceService: ResourceService) { 
    super();
    this.labelTitleIdValue='';
    this.selectTitleIdValue='';
    this.mdbSelectPlaceholder='';
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.labelTitleId).then(labelTitleIdValue => this.labelTitleIdValue = labelTitleIdValue);
    this.resourceService.getResource(this.selectTitleId).then(selectTitleIdValue => this.selectTitleIdValue = selectTitleIdValue);
    this.resourceService.getResource(this.resourceId + '.placeHolder').then(value => this.mdbSelectPlaceholder = value);
  }
}