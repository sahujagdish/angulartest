import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { CurrencyMaskInputMode } from 'ngx-currency';
import { BaseComponent } from 'src/app/core/base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-percent-input',
  templateUrl: './percent-input.component.html'
})
export class PercentInputComponent extends BaseComponent implements OnInit {
  @ViewChild('percentInput', { static: true }) percentInput: any;
  percentPlaceholder: string;

  public ngxPercentOptions = {
    align: 'left',
    prefix: '',
    suffix: '%',
    precision: 0,
    thousands: '',
    decimal: '.',
    allowNegative: false,
    nullable: true,
    max: 1,
    inputMode: CurrencyMaskInputMode.NATURAL
  };

  percentValue = null;

  constructor(private formBuilder: FormBuilder, private resourceService: ResourceService) { 
    super();
    this.percentPlaceholder=''
  }

  ngOnInit(): void {
    this.resourceService.getResource('common.placeholders.percent').then(value => this.percentPlaceholder = value);
    this.resourceService.getResource('mask.percent.precision').then(value => this.ngxPercentOptions.precision = Number(value));
    this.resourceService.getResource('mask.percent.max').then(value => this.ngxPercentOptions.max = Number(value));
  }
}