import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxVerticalComponent } from './checkbox-vertical.component';

describe('CheckboxVerticalComponent', () => {
  let component: CheckboxVerticalComponent;
  let fixture: ComponentFixture<CheckboxVerticalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckboxVerticalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxVerticalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
