import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ResourceService } from '../../resource.service';

@Component({
  selector: 'app-checkbox-horizontal',
  templateUrl: './checkbox-horizontal.component.html'
})
export class CheckboxHorizontalComponent extends BaseComponent implements OnInit {

  checkboxValues: any;

  constructor(private resourceService: ResourceService) { 
    super();
    this.checkboxValues=[];
   }

  ngOnInit(): void {
    this.resourceService.getResource(this.resourceId + '.values').then(value => this.checkboxValues = value);
  }
}