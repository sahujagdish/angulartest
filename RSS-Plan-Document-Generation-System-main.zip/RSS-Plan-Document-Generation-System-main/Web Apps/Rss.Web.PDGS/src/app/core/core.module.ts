import { ErrorHandler as AngularErrorHandler, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnexpectedErrorComponent } from './unexpected-error/unexpected-error.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { MaintenanceModeComponent } from './maintenance-mode/maintenance-mode.component';
import { NotImplementedComponent } from './not-implemented/not-implemented.component';
import { CoreRoutingModule } from './core-routing.module';
import { ErrorHandler } from './error-handler';
import { ResourceDirective } from './directives/resource.directive';
import { AppResourceComponent } from './app-resource/app-resource.component';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MdbAccordionModule } from 'mdb-angular-ui-kit/accordion';
import { MdbAutocompleteModule } from 'mdb-angular-ui-kit/autocomplete';
import { MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import { MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MdbDatepickerModule } from 'mdb-angular-ui-kit/datepicker';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbPopoverModule } from 'mdb-angular-ui-kit/popover';
import { MdbRadioModule } from 'mdb-angular-ui-kit/radio';
import { MdbScrollspyModule } from 'mdb-angular-ui-kit/scrollspy';
import { MdbSelectModule } from 'mdb-angular-ui-kit/select';
import { MdbSmoothScrollModule } from 'mdb-angular-ui-kit/smooth-scroll';
import { MdbStickyModule } from 'mdb-angular-ui-kit/sticky';
import { MdbTableModule } from 'mdb-angular-ui-kit/table';
import { MdbTabsModule } from 'mdb-angular-ui-kit/tabs';
import { MdbTooltipModule } from 'mdb-angular-ui-kit/tooltip';
import { MdbValidationModule } from 'mdb-angular-ui-kit/validation';
import { LoginBarComponent } from './header/login-bar/login-bar.component';
import { NavigationBarComponent } from './header/navigation-bar/navigation-bar.component';
import { TextInputComponent } from './forms/text-input/text-input.component';
import { RadioHorizontalComponent } from './forms/radio-horizontal/radio-horizontal.component';
import { RadioVerticalComponent } from './forms/radio-vertical/radio-vertical.component';
import { CheckboxHorizontalComponent } from './forms/checkbox-horizontal/checkbox-horizontal.component';
import { CheckboxVerticalComponent } from './forms/checkbox-vertical/checkbox-vertical.component';
import { SelectDropdownComponent } from './forms/select-dropdown/select-dropdown.component';
import { CaseBarComponent } from './header/case-bar/case-bar.component';
import { TableComponent } from './table/table.component';
import { NgxCurrencyModule } from "ngx-currency";
import { CurrencyInputComponent } from './forms/currency-input/currency-input.component';
import { FormsModule } from "@angular/forms";
import { PercentInputComponent } from './forms/percent-input/percent-input.component';
import { MultiSelectDropdownComponent } from './forms/multi-select-dropdown/multi-select-dropdown.component';
import { TextareaInputComponent } from './forms/textarea-input/textarea-input.component';
import { EmailInputComponent } from './forms/email-input/email-input.component';
import { AutocompleteInputComponent } from './forms/autocomplete-input/autocomplete-input.component';
import { DenyComponent } from './modals/deny/deny.component';
import { RemoveComponent } from './modals/remove/remove.component';
import { PlaceholderResourceDirective } from './directives/placeholder-resource.directive';
import { MenuDropdownComponent } from './forms/menu-dropdown/menu-dropdown.component';
import { PopoverComponent } from './popover/popover.component';
import { TabTitleDirective } from './directives/tab-title.directive';
import { DateInputComponent } from './forms/date-input/date-input.component';
import { NumberInputComponent } from './forms/number-input/number-input.component';

@NgModule({
  declarations: [
    UnexpectedErrorComponent,
    UnauthorizedComponent,
    MaintenanceModeComponent,
    NotImplementedComponent,
    ResourceDirective,
    AppResourceComponent,
    HeaderComponent,
    FooterComponent,
    LoginBarComponent,
    NavigationBarComponent,
    TextInputComponent,
    RadioHorizontalComponent,
    RadioVerticalComponent,
    CheckboxHorizontalComponent,
    CheckboxVerticalComponent,
    SelectDropdownComponent,
    CaseBarComponent,
    TableComponent,
    CurrencyInputComponent,
    PercentInputComponent,
    MultiSelectDropdownComponent,
    TextareaInputComponent,
    EmailInputComponent,
    AutocompleteInputComponent,
    DenyComponent,
    RemoveComponent,
    PlaceholderResourceDirective,
    MenuDropdownComponent,
    PopoverComponent,
    DateInputComponent,
    NumberInputComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    CoreRoutingModule,
    MdbAccordionModule,
    MdbAutocompleteModule,
    MdbCheckboxModule,
    MdbCollapseModule,
    MdbDropdownModule,
    MdbDatepickerModule,
    MdbFormsModule,
    MdbModalModule,
    MdbPopoverModule,
    MdbRadioModule,
    MdbScrollspyModule,
    MdbSelectModule,
    MdbSmoothScrollModule,
    MdbStickyModule,
    MdbTableModule,
    MdbTabsModule,
    MdbTooltipModule,
    MdbValidationModule,
    NgxCurrencyModule,
    FormsModule
  ],
  exports: [
    UnexpectedErrorComponent,
    UnauthorizedComponent,
    MaintenanceModeComponent,
    ResourceDirective,
    AppResourceComponent,
    HeaderComponent,
    FooterComponent,
    LoginBarComponent,
    NavigationBarComponent,
    TextInputComponent,
    RadioHorizontalComponent,
    RadioVerticalComponent,
    CheckboxHorizontalComponent,
    CheckboxVerticalComponent,
    SelectDropdownComponent,
    CaseBarComponent,
    TableComponent,
    MdbAccordionModule,
    MdbAutocompleteModule,
    MdbCheckboxModule,
    MdbCollapseModule,
    MdbDropdownModule,
    MdbDatepickerModule,
    MdbFormsModule,
    MdbModalModule,
    MdbPopoverModule,
    MdbRadioModule,
    MdbScrollspyModule,
    MdbSelectModule,
    MdbSmoothScrollModule,
    MdbStickyModule,
    MdbTableModule,
    MdbTabsModule,
    MdbTooltipModule,
    MdbValidationModule,
    NgxCurrencyModule,
    CurrencyInputComponent,
    PercentInputComponent,
    FormsModule,
    MultiSelectDropdownComponent,
    TextareaInputComponent,
    EmailInputComponent,
    DenyComponent,
    RemoveComponent,
    PlaceholderResourceDirective,
    MenuDropdownComponent,
    AutocompleteInputComponent,
    PopoverComponent,
    DateInputComponent,
    NumberInputComponent
  ],
  providers: [
    { provide: AngularErrorHandler, useClass: ErrorHandler } 
  ]
})
export class CoreModule { }
