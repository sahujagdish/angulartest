import { OnDestroy, Component, Input } from '@angular/core';
import { Observable, Subject, MonoTypeOperatorFunction } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    template: ''
})
export class BaseComponent implements OnDestroy {
    private ngDestroyed$ = new Subject<void>();

    ngOnDestroy() {
        this.ngDestroyed$.next();
    } 
    
    /** Wrap for takeUntil */
    protected unsubscribeOnDestroy<T>(): MonoTypeOperatorFunction<T> {
        return (input$: Observable<T>) => input$.pipe(takeUntil(this.ngDestroyed$));
    }

    /** Get unique Id to be used for the Html Element 
     * @param id desired id suffix
    */
   getId(id: string): string {
        if (!id) {
        throw Error('the [id] paramenter is null or empty');
        }

        id = window.location.pathname.substring(1).replace(/\//g, '-') + '-' + id;
        return id;
    }

    @Input('resource-prefix') 
    resourceId: string = '';

    getResourceValue(id: string): string {
        return this.resourceId+'.'+id;
    }

    getResourceNumber(id: number): string {
        return this.resourceId+'.'+id;
    }
}