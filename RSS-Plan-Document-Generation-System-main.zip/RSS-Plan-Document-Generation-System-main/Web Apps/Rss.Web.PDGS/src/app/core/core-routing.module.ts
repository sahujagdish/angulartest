import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaintenanceModeComponent } from './maintenance-mode/maintenance-mode.component';
import { NotImplementedComponent } from './not-implemented/not-implemented.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { UnexpectedErrorComponent } from './unexpected-error/unexpected-error.component';

const routes: Routes = [
  { path: 'unexpected-error', component: UnexpectedErrorComponent },
  { path: 'not-implemented', component: NotImplementedComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: 'app-maintenance', component: MaintenanceModeComponent },
  { path: '**', component: NotImplementedComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoreRoutingModule { }
