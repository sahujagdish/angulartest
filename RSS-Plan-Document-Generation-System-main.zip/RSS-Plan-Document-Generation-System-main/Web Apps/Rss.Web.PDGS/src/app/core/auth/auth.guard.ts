import { Injectable, OnDestroy } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { AuthService, LOGIN_PATH } from './auth.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild, OnDestroy {
  private isAuthenticated: boolean;
  private subscription: Subscription;
  
  constructor(
    authService: AuthService,
    private router: Router
  ) {
      this.isAuthenticated = false;
      this.subscription = authService.isAuthenticated$.subscribe(value => this.isAuthenticated = value);
  }

  ngOnDestroy() {
      this.subscription.unsubscribe();
  }
  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this.isAuthenticated) {
      // TODO: additinal auth checks
      return true;
    }

    return this.router.createUrlTree(
      [LOGIN_PATH], {
      queryParams: {
        returnUrl: state.url
      }
    });
  }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    if (this.isAuthenticated) {
      // TODO: additinal auth checks
      return true;
    }

    return false;
  }
  
}
