import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

export const LOGIN_PATH: string = 'login';
export const LOGOUT_PATH: string = 'logout';
export const SESSION_EXPIRED_PATH: string = 'session-expired';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
    // TODO: implement login
    private _isAuthenticated = new BehaviorSubject<boolean>(true);

  constructor() { 
  }

  /**
   * Return is User authenticated indicator.
   */
  public get isAuthenticated$(): Observable<boolean> {
    return this._isAuthenticated.asObservable();
  }
}
