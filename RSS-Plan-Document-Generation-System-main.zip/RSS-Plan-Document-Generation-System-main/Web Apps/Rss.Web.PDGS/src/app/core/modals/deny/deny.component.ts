import { Component, OnInit } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';
import { BaseComponent } from '../../base-component';

@Component({
  selector: 'app-deny',
  templateUrl: './deny.component.html'
})
export class DenyComponent extends BaseComponent implements OnInit {
  public denyMessage: string;
  maxChars = 100;

  constructor(public modalRef: MdbModalRef<DenyComponent>) {
    super();
    this.denyMessage='';
  }

  ngOnInit(): void {

  }
}