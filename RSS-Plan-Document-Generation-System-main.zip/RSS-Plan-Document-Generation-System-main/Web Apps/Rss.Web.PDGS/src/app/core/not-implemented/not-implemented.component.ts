import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '../base-component';

@Component({
  selector: 'app-not-implemented',
  templateUrl: './not-implemented.component.html'
})
export class NotImplementedComponent extends BaseComponent implements OnInit {

  constructor(private router: Router) { 
    super();
  }

  ngOnInit(): void {
  }

  get url(): string {
    return this.router.url;
  }  
}
