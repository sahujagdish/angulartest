﻿CREATE TABLE [dbo].[PlanProposalStatus]
(
	[PlanProposalStatusId] BIGINT NOT NULL PRIMARY KEY IDENTITY(1, 1),
	[PlanProposalId]	BIGINT NOT NULL,
	[PlanProposalStatusLookupId] INT NOT NULL,
	[ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
	CONSTRAINT [FK_PlanProposalStatus_PlanProposal_PlanProposalId] FOREIGN KEY ([PlanProposalId]) REFERENCES [dbo].[PlanProposal] ([PlanProposalId])
)
