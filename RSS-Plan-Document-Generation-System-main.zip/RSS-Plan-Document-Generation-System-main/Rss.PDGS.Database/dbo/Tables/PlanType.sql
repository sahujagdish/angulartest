﻿CREATE TABLE [dbo].[PlanType]
(	
	[PlayTypeLookupId] INT NOT NULL PRIMARY KEY ,
	[IsFixedSelectAllowed]  BIT  DEFAULT ((0)) NOT NULL,
	[IsAdvidorFixed]  BIT  DEFAULT ((0)) NOT NULL,
)
