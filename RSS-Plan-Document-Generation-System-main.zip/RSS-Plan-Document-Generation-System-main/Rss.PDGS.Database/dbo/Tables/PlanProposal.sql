﻿CREATE TABLE [dbo].[PlanProposal]
(
	[PlanProposalId]         BIGINT         NOT NULL IDENTITY(1, 1),
    [OrganizationId] BIGINT         NOT NULL,
    [Name]           NVARCHAR (100)  NOT NULL,
    [AdvisorName]    NVARCHAR (100) NULL,
    [ProposalNumber]     INT    NOT NULL ,  
    [ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
    PRIMARY KEY CLUSTERED ([PlanProposalId] ASC),
    CONSTRAINT [FK_PlanProposal_Organization_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organization] ([OrganizationId]),
    CONSTRAINT [UC_PlanProposal_ProposalId] UNIQUE ([ProposalNumber])
)
