﻿CREATE TABLE [dbo].[Lookup] (
    [LookupId]    INT           NOT NULL,
    [GroupName]   VARCHAR (50)  NOT NULL,
    [Value]       VARCHAR (75)  NULL,
    [Description] VARCHAR (150) NULL,
    [SortOrder]   INT           NULL,
    [IsDeleted]   BIT           CONSTRAINT [DF_Lookup_IsDeleted] DEFAULT ((0)) NOT NULL,
    [AddDate]     DATETIME      CONSTRAINT [DF_Lookup_AddDate] DEFAULT (getdate()) NOT NULL,
    [AddBy]       VARCHAR (55)  NOT NULL,
    CONSTRAINT [PK_Lookup] PRIMARY KEY NONCLUSTERED ([LookupId] ASC) WITH (FILLFACTOR = 80),
    CONSTRAINT [IX_Lookup_GroupNameAndValue] UNIQUE CLUSTERED ([GroupName] ASC, [Value] ASC) WITH (FILLFACTOR = 80)
);
