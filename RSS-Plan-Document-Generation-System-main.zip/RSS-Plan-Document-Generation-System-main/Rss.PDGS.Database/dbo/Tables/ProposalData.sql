﻿CREATE TABLE [dbo].[ProposalData]
(
	[ProposalDataId]         BIGINT         NOT NULL IDENTITY(1, 1),
    [PlanProposalId] BIGINT         NOT NULL,
    [ProposalDataLookupId]           NVARCHAR (100)  NOT NULL,
    [Data]   NVARCHAR(MAX) NOT NULL,
    [ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
    PRIMARY KEY CLUSTERED ([ProposalDataId] ASC),
    CONSTRAINT [FK_ProposalData_PlanProposal_PlanProposalId] FOREIGN KEY ([PlanProposalId]) REFERENCES [dbo].[PlanProposal] ([PlanProposalId]),
)
