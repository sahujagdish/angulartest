﻿CREATE TABLE [dbo].[DocumentBinder]
(
	[DocumentBinderId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[PlanProposalId] BIGINT NOT NULL,
	[DocumentId] BIGINT NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[Content] VARBINARY NOT NULL,
	[ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
	CONSTRAINT [FK_DocumentBinder_PlanProposal_PlanId] FOREIGN KEY ([PlanProposalId]) REFERENCES [dbo].[PlanProposal] ([PlanProposalId]),
	CONSTRAINT [FK_DocumentBinder_DocumentId] FOREIGN KEY ([DocumentId]) REFERENCES [dbo].[Document] ([DocumentId])
)
