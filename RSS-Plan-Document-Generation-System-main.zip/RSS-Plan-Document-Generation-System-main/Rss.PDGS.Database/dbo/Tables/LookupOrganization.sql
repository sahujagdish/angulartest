﻿CREATE TABLE [dbo].[LookupOrganization]
(
	[LookupId]      INT           NOT NULL,
    [OrganizationId]         BIGINT           NOT NULL,
    [Description]   VARCHAR (50)  NOT NULL,
    [ExternalValue] VARCHAR (100) NULL,
    [AddDate]       DATETIME      DEFAULT (getdate()) NOT NULL,
    [AddBy]         VARCHAR (55)  NOT NULL,
    [IsDeleted]     BIT           DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_LookupOrganization] PRIMARY KEY CLUSTERED ([LookupId] ASC, [OrganizationId] ASC) WITH (FILLFACTOR = 80),
    CONSTRAINT [FK_LookupOrganization_Organization_OrganizationId] FOREIGN KEY ([OrganizationId]) REFERENCES [dbo].[Organization] ([OrganizationId]),
    CONSTRAINT [FK_LookupOrganization_Lookup_LookupId] FOREIGN KEY ([LookupId]) REFERENCES [dbo].[Lookup] ([LookupId])
    );
