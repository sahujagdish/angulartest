﻿CREATE TABLE [dbo].[Document]
(
	[DocumentId] BIGINT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[PlanProposalId] BIGINT NOT NULL,
	[Name] NVARCHAR(100) NOT NULL,
	[Content] VARBINARY NOT NULL,
	[ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
	CONSTRAINT [FK_Document_PlanProposal_PlanProposalId] FOREIGN KEY ([PlanProposalId]) REFERENCES [dbo].[PlanProposal] ([PlanProposalId])
)
