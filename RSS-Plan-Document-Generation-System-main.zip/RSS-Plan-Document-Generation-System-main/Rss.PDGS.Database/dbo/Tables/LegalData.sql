﻿CREATE TABLE [dbo].[LegalData]
(
	[LegalDataId]         BIGINT         NOT NULL IDENTITY(1, 1),
    [PlanProposalId] BIGINT         NOT NULL,
    [LegalDataLookupId]           NVARCHAR (100)  NOT NULL,
    [Data]   NVARCHAR(MAX) NOT NULL,
    [ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
    PRIMARY KEY CLUSTERED ([LegalDataId] ASC),
    CONSTRAINT [FK_LegalData_PlanProposal_PlanProposalId] FOREIGN KEY ([PlanProposalId]) REFERENCES [dbo].[PlanProposal] ([PlanProposalId]),
)
