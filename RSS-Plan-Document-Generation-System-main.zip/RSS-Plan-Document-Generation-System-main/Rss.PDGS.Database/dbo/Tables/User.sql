﻿CREATE TABLE [dbo].[User]
(
	[UserId] BIGINT NOT NULL PRIMARY KEY IDENTITY(1, 1), 
    [OrganizationId] BIGINT NOT NULL, 
    [Name] NVARCHAR(50) NOT NULL, 
    [ExternalUserId] NVARCHAR(50) NOT NULL,
    [ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       DEFAULT (getdate()) NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       DEFAULT (getdate()) NOT NULL,
    [IsDeleted]      BIT            DEFAULT ((0)) NOT NULL,
)
