﻿insert into PlanProposal values(1,'TestProposal1','TestAdvisor1',1,'TestModified1',getdate(),'AtanuAdded',getdate(),0);
insert into PlanProposal values(1,'TestProposal2','TestAdvisor2',2,'TestModified2',getdate(),'AtanuAdded',getdate(),0);
insert into PlanProposal values(1,'TestProposal3','TestAdvisor3',3,'TestModified3',getdate(),'AtanuAdded',getdate(),0);
insert into PlanProposal values(1,'TestProposal4','TestAdvisor4',4,'TestModified4',getdate(),'AtanuAdded',getdate(),0);
insert into PlanProposal values(1,'TestProposal5','TestAdvisor5',5,'TestModified5',getdate(),'AtanuAdded',getdate(),0);