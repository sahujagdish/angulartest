﻿-- =============================================
-- Initialize Lookup Table
-- =============================================

Merge Into dbo.[Lookup] AS Target 
Using (Values
	-- YesNo
	(1, 'YesNo', 'No', 'No', 1, getDate(), 'srbondapalli', 0),
	(2, 'YesNo', 'Yes', 'Yes', 2, getDate(), 'srbondapalli', 0),
	
	--Proposal Pricing
	(3, 'ProposalPricingType', 'Flexible Advantage', 'Flexible Advantage', 1, getDate(), 'srbondapalli', 0),
	(4, 'ProposalPricingType', 'Exchange', 'Exchange', 2, getDate(), 'srbondapalli', 0),

		--Fixed product
	(5, 'FixedProductType', 'Fixed Select', 'Fixed Select', 1, getDate(), 'srbondapalli', 0),
	(6, 'FixedProductType', 'Advisor Fixed', 'Advisor Fixed', 2, getDate(), 'srbondapalli', 0),
	(7, 'FixedProductType', 'Not Applicable', 'Not Applicable', 3, getDate(), 'srbondapalli', 0),

	-- Proposal Data
	(8, 'ProposalData', 'GeneralPlanData', 'GeneralPlanData', 1, getDate(), 'srbondapalli', 0),
	
	--Plan Type
	(10, 'PlanTypes', '1', '401(k)', 1, getDate(), 'atanu', 0),
	(11, 'PlanTypes', '2', '403(b) Group Controlled', 2, getDate(), 'atanu', 0),
	(12, 'PlanTypes', '3', '401(a)', 3, getDate(), 'atanu', 0),
	(13, 'PlanTypes', '4', 'DB and Cash Balance', 4, getDate(), 'atanu', 0),
	(14, 'PlanTypes', '5', '457 Non-Profit', 5, getDate(), 'atanu', 0),
	(15, 'PlanTypes', '6', '457(b) Governmental', 6, getDate(), 'atanu', 0),
	(16, 'PlanTypes', '7', 'Other/Combo', 7, getDate(), 'atanu', 0),
	(17, 'PlanTypes', '8', '403(b) Individual Controlled', 8, getDate(), 'atanu', 0),
	(18, 'PlanTypes', '9', '457(f) For-Profit', 9, getDate(), 'atanu', 0),
	-- IRON / Wilshire / LeafHouse for the
	(20, 'IRON_Wilshire', '1', 'Wilshire 3(38) - ProAccount & FS Required', 1, getDate(), 'atanu', 0),
	(21, 'IRON_Wilshire', '2', 'IRON 3(38) Fiduciary & Models', 2, getDate(), 'atanu', 0),
	(22, 'IRON_Wilshire', '3', 'IRON 3(38) Fiduciary - No Models', 3, getDate(), 'atanu', 0),
	(23, 'IRON_Wilshire', '4', '<DB> IRON 3(38) Fiduciary - No Models', 4, getDate(), 'atanu', 0),
	(24, 'IRON_Wilshire', '5', '<Foundation> IRON Fiduciary 3(38)', 5, getDate(), 'atanu', 0),
	(25, 'IRON_Wilshire', '6', 'Wilshire 3(21)', 6, getDate(), 'atanu', 0),
	(26, 'IRON_Wilshire', '7', 'IRON Fiduciary 3(21)', 7, getDate(), 'atanu', 0),
	(27, 'IRON_Wilshire', '8', 'LeafHouse 3(38) - No Models', 8, getDate(), 'atanu', 0),
	(28, 'IRON_Wilshire', '9', 'LeafHouse 3(38) & Models', 9, getDate(), 'atanu', 0),
	(29, 'IRON_Wilshire', '10', 'Leafhouse 3(21)', 10, getDate(), 'atanu', 0),
	--Compensation Table & CDSC
	(30, 'Compensation_CDSC', '405', '405', 1, getDate(), 'atanu', 0),
	(31, 'Compensation_CDSC', '406', '406', 2, getDate(), 'atanu', 0),
	(32, 'Compensation_CDSC', '407', '407', 3, getDate(), 'atanu', 0),
	(33, 'Compensation_CDSC', '408', '408', 4, getDate(), 'atanu', 0),
	(34, 'Compensation_CDSC', '409', '409', 5, getDate(), 'atanu', 0),
	(35, 'Compensation_CDSC', '410', '410', 6, getDate(), 'atanu', 0),
	(36, 'Compensation_CDSC', '411', '411', 7, getDate(), 'atanu', 0),
	(37, 'Compensation_CDSC', '412', '412', 8, getDate(), 'atanu', 0),
	(38, 'Compensation_CDSC', '413', '413', 9, getDate(), 'atanu', 0),
	(39, 'Compensation_CDSC', '414', '414', 10, getDate(), 'atanu', 0),
	(40, 'Compensation_CDSC', '415', '415', 11, getDate(), 'atanu', 0),
	(41, 'Compensation_CDSC', '416', '416', 12, getDate(), 'atanu', 0),
	(42, 'Compensation_CDSC', '417', '417', 13, getDate(), 'atanu', 0),
	(43, 'Compensation_CDSC', '418', '418', 14, getDate(), 'atanu', 0),
	(44, 'Compensation_CDSC', '419', '419', 15, getDate(), 'atanu', 0),
	(45, 'Compensation_CDSC', '420', '420', 16, getDate(), 'atanu', 0)
	)
	As Source ([LookupId], [GroupName], [Value], [Description], [SortOrder], [AddDate], [AddBy], [IsDeleted])
On Target.[LookupId] = Source.[LookupId]
When MATCHED Then 
	Update Set 
		[GroupName] = Source.[GroupName],
		[Value] = Source.[Value],
		[Description] = Source.[Description],
		[SortOrder] = Source.[SortOrder],
		[IsDeleted] = Source.[IsDeleted]
When Not Matched By Target Then 
	Insert ([LookupId], [GroupName], [Value], [Description], [SortOrder], [AddDate], [AddBy], [IsDeleted])
	Values ([LookupId], [GroupName], [Value], [Description], [SortOrder], getDate(), [AddBy], [IsDeleted])
When Not Matched By Source Then 
Delete;
