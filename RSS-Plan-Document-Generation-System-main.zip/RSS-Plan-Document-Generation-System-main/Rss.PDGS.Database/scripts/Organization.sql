﻿insert into Organization values('SSNC',1,'Atanu',getDate(),'AtanuAdded',getdate(),0);
/*
 [OrganizationId] BIGINT         IDENTITY (1, 1) NOT NULL,
    [Name]           NVARCHAR (100) NOT NULL,
    [IsActive]       BIT            NOT NULL,
    [ModifiedBy]     NVARCHAR (50)  NOT NULL,
    [ModifiedDate]   DATETIME       NOT NULL,
    [AddBy]          NVARCHAR (50)  NOT NULL,
    [AddDate]        DATETIME       NOT NULL,
    [IsDeleted]      BIT            NOT NULL
    */