# RSS-Plan-Document-Generation-System
Plan Proposal and Legal Documents Generation System

The UI portion of the project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 13.0.2.

## Code scaffolding

Angular UI split into few following modules:
 - Core (this module contains core classes and components used by all other modules)
 - Common (contains common/shared components and services for feature modules like Proposal and Legal)
 - Admin (Application Administration UI feature)
 - Proposal (Plan Proposal UI feature)
 - Legal (Legal Document generation UI feature)

Types and root Services most likely should be in Core module and components like Grid, Dynamic Forms etc should be in Common module (this module might split if need be for load time improvements)  

To add types to the particular module run following command in the root of the Web Application "\Web Apps\Rss.Web.PDGS\":
```
ng generate <type> <Module>/<typeName> --module=<Module>
``` 

for example:
 - ng generate component Core/NotImplemented --module=Core
 - ng generate directive Core/Directives/Resource --module=Core
 - ng generate component Common/Header --module=Common
 - ng generate service Proposal/Pricing --module=Proposal

Resources for the application stored under assets/resources.json and loaded at runtime. The resource file structure should map to type declaration in the module. Property names are in lower case camel notation.
For example, Header component located in Common module, thus any resources for Header component will be stored like follows:
```
{
  "common": {
     "header": {
	"somePropertyName": "value"
     }
  }
}
```
Styles are in theme folder:
 - variables.sccs (declaration of global variables)
 - main.sccs (global style sheet)

## Logging
Sentry logging is configured.
can be found at : https://sentry.ssnc-corp.cloud/organizations/sentry/issues/?project=106#welcome

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
