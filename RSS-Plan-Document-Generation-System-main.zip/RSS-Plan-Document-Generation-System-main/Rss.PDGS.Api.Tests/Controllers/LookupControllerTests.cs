﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.BusinessFacades;
using Rss.PDGS.Api.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Rss.PDGS.Core.Models;
using Microsoft.AspNetCore.Http;

namespace Rss.PDGS.Api.Tests.Controllers
{
    internal class LookupControllerTests
    {

        [SetUp]
        public void Setup()
        {


        }

        [Test]
        public void GetAllLookups()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetAllLookups()).Returns(new List<LookupVm> { new LookupVm { } });

            LookupController _controller = new LookupController(mockLookupFacade.Object);
            IActionResult result = _controller.Get();

            Assert.IsInstanceOf(typeof(OkObjectResult), result);
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(okResult?.StatusCode, StatusCodes.Status200OK);
            var content = okResult?.Value as IEnumerable<LookupVm>;
            Assert.IsNotNull(content);
        }

        [Test]
        public void GetLookupsNullObjectNotFoundTest()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetLookups(It.IsAny<string>())).Returns(() =>
            {
                return null;
            });

            LookupController _controller = new LookupController(mockLookupFacade.Object);

            IActionResult result = _controller.Get("YesNo");
            Assert.IsInstanceOf(typeof(NotFoundResult), result);
        }

        [Test]
        public void GetLookupsEmptyObjectNotFoundTest()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetLookups(It.IsAny<string>())).Returns(() =>
            {
                return new List<LookupVm>();
            });

            LookupController _controller = new LookupController(mockLookupFacade.Object);

            IActionResult result = _controller.Get("YesNo");
            Assert.IsInstanceOf(typeof(NotFoundResult), result);
        }

        [Test]
        public void GetLookupsBadRequestTest()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetLookups(It.IsAny<string>())).Returns(() =>
            {
                return new List<LookupVm>();
            });

            LookupController _controller = new LookupController(mockLookupFacade.Object);

            IActionResult result = _controller.Get(null);
            Assert.IsInstanceOf(typeof(BadRequestResult), result);
        }

        [Test]
        public void GetLookupsEmptyGroupNameBadRequestTest()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetLookups(It.IsAny<string>())).Returns(() =>
            {
                return new List<LookupVm>() { new LookupVm() };
            });

            LookupController _controller = new LookupController(mockLookupFacade.Object);

            IActionResult result = _controller.Get("");
            Assert.IsInstanceOf(typeof(BadRequestResult), result);
        }

        [Test]
        public void GetLookupsOkRequestTest()
        {
            var mockLookupFacade = new Mock<ILookupFacade>();
            mockLookupFacade.Setup(x => x.GetLookups(It.IsAny<string>())).Returns(() =>
            {
                return new List<LookupVm>() { new LookupVm() };
            });

            LookupController _controller = new LookupController(mockLookupFacade.Object);

            IActionResult result = _controller.Get("YesNo");
            Assert.IsInstanceOf(typeof(OkObjectResult), result);
            OkObjectResult okObjectResult = (OkObjectResult)result;
            Assert.IsNotNull(okObjectResult);
            Assert.IsInstanceOf(typeof(IEnumerable<LookupVm>), okObjectResult?.Value);
            IEnumerable<LookupVm>? lookups = okObjectResult?.Value as IEnumerable<LookupVm>;
            Assert.AreNotEqual(0, lookups?.Count());
        }

    }
}
