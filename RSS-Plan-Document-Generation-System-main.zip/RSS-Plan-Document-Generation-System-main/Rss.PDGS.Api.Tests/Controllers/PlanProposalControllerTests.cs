﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.BusinessFacades;
using Rss.PDGS.Api.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Rss.PDGS.Core.Models;
using Microsoft.AspNetCore.Http;
using Rss.PDGS.DAL.BLL;

namespace Rss.PDGS.Api.Tests.Controllers
{
    internal class PlanProposalControllerTests
    {

        [SetUp]
        public void Setup()
        {


        }

        public PlanProposalController CreateSut()
        {
            return new PlanProposalController(Mock.Of<IGeneralPlanDataFacade>(),
                Mock.Of<IPricingDataFacade>());
        }

        [Test]
        public void SaveGeneralPlan()
        {
            GeneralPlanDataModel model = new GeneralPlanDataModel()
            {
                PlanProposalId = 99,
                PlanTypeLookupId = (int)Lookup.PlanTypes._4,
                PlanStateCode = "st",
                IsAddASFToPlan = true,
                PPANumber = 1,
                RVPName = "TEST",
                DVPName = "TEST",
                IRONWilshireLeafHouseForThePlan = "TEST",
                OtherNonIRONWilshireFeePercentage = 0,
                TPAPPAPercentage = 0,
                IsCustomCompensationNeeded = true,
                AdvisorTotalCostOfComp = 0,
                IsFeeBasedAdvisor = true,
                CompensationTableLookupId = 0,
                TableCostPercentage = 0,
                AddOnTrailerPercentage = 0
            };
            


            // Arrange
            var controller = CreateSut();

            // Act
            ActionResult<long> actionResult = controller.SaveGeneralPlan(model);
            Assert.NotNull(actionResult);
            Assert.AreEqual(0, actionResult.Value);

            model.PlanProposalId = 24;
             actionResult = controller.SaveGeneralPlan(model);
            Assert.NotNull(actionResult);

            // Assert
            // Assert.IsInstanceOf(actionResult.GetType(), typeof(NotFoundResult));

            ActionResult<GeneralPlanDataModel> actionResultFound = controller.GetGeneralPlan(24);
            Assert.NotNull(actionResultFound);
        }
        
        [Test]
        public void GetGeneralPlanNotFound()
        {
            // Arrange
            var controller = CreateSut();

            // Act
            ActionResult<GeneralPlanDataModel> actionResult = controller.GetGeneralPlan(99);

            // Assert
            // Assert.IsInstanceOf(actionResult.GetType(), typeof(NotFoundResult));
            Assert.NotNull(actionResult);

            ActionResult<GeneralPlanDataModel> actionResultFound = controller.GetGeneralPlan(24);
            Assert.NotNull(actionResultFound);
        }

    }
}
