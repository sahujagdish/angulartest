﻿using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Moq;
using NUnit.Framework;
using Rss.PDGS.Api.Controllers;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rss.PDGS.Api.Tests.Controllers
{
    public class PricingDataControllerUnitTest
    {
        Fixture fixture;
        IPricingDataFacade pricingDataFacade;

        public PricingDataControllerUnitTest()
        {
            fixture = new Fixture();
        }

        [SetUp]
        public void Setup()
        {
            pricingDataFacade = Mock.Of<IPricingDataFacade>();
        }

        public PlanProposalController CreateSut()
        {
            return new PlanProposalController(Mock.Of<IGeneralPlanDataFacade>(), pricingDataFacade);
        }

        [Test]
        public void SavePricingPlan_calls_SavePricingData()
        {
            var model = fixture.Create<PricingDataModel>();
            var controller = CreateSut();
                        
            controller.SavePricingPlan(model);
            Mock.Get(pricingDataFacade).Verify(x => x.SavePricingData(It.IsAny<PricingDataModel>()), Times.Once);
        }

        [Test]
        public void SavePricingPlan_IdNotReturned_Raises_BadRequest()
        {
            Mock.Get(pricingDataFacade).Setup(x => x.SavePricingData(It.IsAny<PricingDataModel>())).Returns(0);
            var model = fixture.Create<PricingDataModel>();
            var controller = CreateSut();

            var result = controller.SavePricingPlan(model);
            result.Should().NotBeNull();
            result.Value.Should().Be(0);
            var statusCodeObj = result.Result as IStatusCodeActionResult;
            statusCodeObj.Should().NotBeNull();
            statusCodeObj.StatusCode.Should().Be(StatusCodes.Status400BadRequest);
        }

        [Test]
        public void SavePricingPlan_IdReturned_Raises_Success()
        {
            Mock.Get(pricingDataFacade).Setup(x => x.SavePricingData(It.IsAny<PricingDataModel>())).Returns(fixture.Create<int>());
            var model = fixture.Create<PricingDataModel>();
            var controller = CreateSut();

            var result = controller.SavePricingPlan(model);
            result.Should().NotBeNull();
            var statusCodeObj = result.Result as ObjectResult;
            statusCodeObj.Should().NotBeNull();
            statusCodeObj.StatusCode.Should().Be(StatusCodes.Status200OK);
            statusCodeObj.Value.Should().NotBe(0);
        }

        [Test]
        public void GetPricingData_CanReturn_NotFound()
        {
            var controller = CreateSut();

            var result = controller.GetGeneralPlan(fixture.Create<int>());
            var statusCodeObj = result.Result as IStatusCodeActionResult;
            statusCodeObj.StatusCode.Should().Be(StatusCodes.Status404NotFound);
        }

        [Test]
        public void GetPricingData_CanReturn_Found_Object()
        {
            var model = fixture.Create<PricingDataModel>();
            Mock.Get(pricingDataFacade).Setup(x => x.GetPricingData(It.IsAny<long>())).Returns(model);
            var controller = CreateSut();

            var result = controller.GetPricingData(fixture.Create<int>());
            var statusCodeObj = result.Result as ObjectResult;
            statusCodeObj.StatusCode.Should().Be(StatusCodes.Status200OK);
            statusCodeObj.Value.Should().Be(model);
        }

        [Test]
        public void GetPricingData_Empty_should_return_empty_model()
        {
            var controller = CreateSut();

            var result = controller.GetEmptyPricingModel();
            var statusCodeObj = result.Result as ObjectResult;
            statusCodeObj.StatusCode.Should().Be(StatusCodes.Status200OK);
            statusCodeObj.Value.Should().BeOfType<PricingDataModel>();
        }
    }
}
