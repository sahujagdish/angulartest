using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.OpenApi.Models;
using Rss.PDGS.Api;
using Rss.PDGS.Core.BusinessFacades;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.Models;
using Rss.PDGS.Core.Validators;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

new Installer().Install(builder.Services);
builder.Services.AddControllers().AddFluentValidation();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen( c => 
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "pldgs", Version = "v1" });
    c.ResolveConflictingActions(x => x.First());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        string swaggerJsonBasePath = string.IsNullOrWhiteSpace(c.RoutePrefix) ? ".." : "..";
        c.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/v1/swagger.json", $"pldgs v1");
        c.RoutePrefix = "";
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
