﻿using FluentValidation;
using Rss.PDGS.Core.BusinessFacades;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.Models;
using Rss.PDGS.Core.Validators;
using Rss.PDGS.DAL;

namespace Rss.PDGS.Api
{
    public class Installer
    {
        public void Install(IServiceCollection serviceDescriptors)
        {
            serviceDescriptors.AddScoped<ILookupFacade, LookupFacade>();
            serviceDescriptors.AddScoped<IGeneralPlanDataFacade, GeneralPlanDataFacade>();
            serviceDescriptors.AddScoped<IPricingDataFacade, PricingDataFacade>();

            serviceDescriptors.AddScoped<IDalFactory, DalFactory>();
            serviceDescriptors.AddScoped<IBllFactory, BllFactory>();
            serviceDescriptors.AddScoped<IModelFactory, ModelFactory>();

            serviceDescriptors.AddTransient<IValidator<GeneralPlanDataModel>, GeneralPlanDataValidator>();
            serviceDescriptors.AddTransient<IValidator<PricingDataModel>, PricingDataModelValidator>();
        }
    }
}
