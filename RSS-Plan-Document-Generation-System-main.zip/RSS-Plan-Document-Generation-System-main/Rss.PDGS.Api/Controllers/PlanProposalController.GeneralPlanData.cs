﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rss.PDGS.Core.Models;
using Microsoft.AspNetCore.Http;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.DAL.BLL;
namespace Rss.PDGS.Api.Controllers
{
    public partial class PlanProposalController
    {
        /// <summary>
        ///  This is made for the UI developer so that they can use this object to send data 
        /// </summary>
        /// <returns>Empty Object</returns>
        [ProducesResponseType(typeof(GeneralPlanDataModel), 200, Type = typeof(GeneralPlanDataModel))]
        [HttpGet("general-plan-data/model-empty")]
        public ActionResult<GeneralPlanDataModel> GetEmptyGeneralPlanModel()
        {
            return Ok(new GeneralPlanDataModel());
        }

        /// <summary>
        ///     This is going to Return General Plan Data for Particular Provider using ProposalID
        /// </summary>
        /// <param name="PlanProposalId"> Every Proposal has only one general Plan data which we can get using this.</param>
        /// <returns> Return ID of General plan data  for particular proposal </returns>
        [ProducesResponseType(typeof(GeneralPlanDataModel), 200, Type = typeof(GeneralPlanDataModel))]
        [ProducesResponseType(typeof(string), 404, Type = typeof(string))]

        [HttpGet("general-plan-data/{PlanProposalId}")]
        public ActionResult<GeneralPlanDataModel> GetGeneralPlan(long PlanProposalId)
        {

            GeneralPlanDataModel dataToSend = generalPlanFacade.GetGeneralPlanData(PlanProposalId);
            if (dataToSend == null)
                return NotFound();
            return Ok(dataToSend);
        }


        /// <summary>
        ///     This is going to Save or Update the data from General Plan Data according to this Situation. If proposal is not there then It will not save
        /// </summary>
        /// <param name="value"> This is the value we have to save or update </param>
        /// <returns> Return Id of General Plan Data</returns>
        [ProducesResponseType(typeof(long), 200, Type = typeof(long))]
        [ProducesResponseType(typeof(string), 404, Type = typeof(string))]
        [HttpPost("general-plan-data")]
        public ActionResult<long> SaveGeneralPlan([FromBody] GeneralPlanDataModel value)
        {
            long dataToSend = generalPlanFacade.SaveGeneralPlanData(value);
            if (dataToSend == 0)
                return BadRequest("Invalid PlanProposal Id");
            return Ok(dataToSend);

        }
    }
}
