﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.Core.Models;

namespace Rss.PDGS.Api.Controllers
{
    [Route("lookup")]
    [ApiController]
    public class LookupController : ControllerBase
    {
        private ILookupFacade _lookupFacade;
        IPricingDataFacade pricingDataFacade;
        public LookupController(ILookupFacade lookupFacade)
        {
            this._lookupFacade = lookupFacade;
        }

        [ProducesResponseType(typeof(int), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(int), StatusCodes.Status400BadRequest)]    
        [ProducesResponseType(typeof(int), 200, Type = typeof(IEnumerable<LookupVm>))]
        [HttpGet]
        public IActionResult Get([FromQuery] string groupName = "all")
        {
            if (string.IsNullOrEmpty(groupName))
                return BadRequest();

            if (groupName.ToLowerInvariant() == "all")
                return Ok(_lookupFacade.GetAllLookups());

            var result = _lookupFacade.GetLookups(groupName);
            if (result == null || result?.Count == 0)
                return NotFound();

            return Ok(result);
        }
    }
}
