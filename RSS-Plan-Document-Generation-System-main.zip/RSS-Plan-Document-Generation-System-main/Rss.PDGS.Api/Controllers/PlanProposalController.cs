﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rss.PDGS.Core.BusinessFacades.Interfaces;

namespace Rss.PDGS.Api.Controllers
{
    [Route("plan-proposal")]
    [ApiController]
    public partial class PlanProposalController : ControllerBase
    {
        private IGeneralPlanDataFacade generalPlanFacade;
        private IPricingDataFacade pricingDataFacade;
        public PlanProposalController(IGeneralPlanDataFacade generalPlanFacade, 
            IPricingDataFacade pricingFacade)
        {
            this.pricingDataFacade = pricingFacade;
            this.generalPlanFacade = generalPlanFacade;
        }
    }
}
