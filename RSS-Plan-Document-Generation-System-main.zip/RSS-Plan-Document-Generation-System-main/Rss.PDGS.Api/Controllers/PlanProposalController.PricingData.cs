﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Rss.PDGS.Core.Models;
using Microsoft.AspNetCore.Http;
using Rss.PDGS.Core.BusinessFacades.Interfaces;
using Rss.PDGS.DAL.BLL;
namespace Rss.PDGS.Api.Controllers
{
    public partial class PlanProposalController
    {
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PricingDataModel))]
        [HttpGet("pricing-data/model-empty")]
        public ActionResult<PricingDataModel> GetEmptyPricingModel()
        {
            return Ok(new PricingDataModel());
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PricingDataModel))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpGet("pricing-data/{PlanProposalId}")]
        public ActionResult<PricingDataModel> GetPricingData(long PlanProposalId)
        {

            PricingDataModel dataToSend = pricingDataFacade.GetPricingData(PlanProposalId);
            if (dataToSend == null)
                return NotFound();
            return Ok(dataToSend);
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(long))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpPost("pricing-data")]
        public ActionResult<long> SavePricingPlan([FromBody] PricingDataModel value)
        {
            long dataToSend = pricingDataFacade.SavePricingData(value);
            if (dataToSend == 0)
                return BadRequest("Invalid PlanProposal Id");
            return Ok(dataToSend);
        }
    }
}
