import { Injectable } from '@angular/core';
import { UploadLogoComponent } from '../../../logos/upload-logo.component';
import { ReplaceLogoComponent } from '../../../logos/replace-logo.component';
import { AssignLogoComponent } from '../../../logos/assign-logo.component';
import { AssignMessageComponent } from '../../../messages/assign-message.component';
import { CreateMessageComponent } from '../../../messages/create-message.component';
import { UpdateMessageComponent } from '../../../messages/update-message.component';
import { AddMessageOptionsComponent } from '../../../messages/add-message-options.component';
import { AddPlanMessageFromLibraryComponent } from '../../../messages/add-plan-message-from-library.component';
import { PlanMessagesViewallComponent } from '../../../plans/plan-messages-viewall.component';
import { ChangePlanLogoOptionsComponent } from '../../../logos/change-plan-logo-options.component';
import { ChangePlanLogoFromLibraryComponent } from '../../../logos/change-plan-logo-from-library.component';
import { ChangePlanLogoFromUploadComponent } from '../../../logos/change-plan-logo-from-upload.component';
import { RemoveMessagePlanAssignmentComponent } from '../../../messages/remove-message-plan-assignment.component';
import { RemoveLogoPlanAssignmentComponent } from '../../../logos/remove-logo-plan-assignment.component';

@Injectable({
    providedIn: 'root'
})
export class ModalLoaderService {

    constructor() { }

    getComponent(componentName: string) {
        switch (componentName) {
            case 'UploadLogoComponent':
                return UploadLogoComponent;
                break;
            case 'ReplaceLogoComponent':
                return ReplaceLogoComponent;
                break;
            case 'AssignLogoComponent':
                return AssignLogoComponent;
                break;
            case 'AssignMessageComponent':
                return AssignMessageComponent;
                break;
            case 'CreateMessageComponent':
                return CreateMessageComponent;
                break;
            case 'AddPlanMessageFromLibraryComponent':
                return AddPlanMessageFromLibraryComponent;
                break;
            case 'UpdateMessageComponent':
                return UpdateMessageComponent;
                break;
            case 'PlanMessagesViewallComponent':
                return PlanMessagesViewallComponent;
                break;
            case 'AddMessageOptionsComponent':
                return AddMessageOptionsComponent;
                break;
            case 'ChangePlanLogoOptionsComponent':
                return ChangePlanLogoOptionsComponent;
                break;
            case 'ChangePlanLogoFromLibraryComponent':
                return ChangePlanLogoFromLibraryComponent;
                break;
            case 'ChangePlanLogoFromUploadComponent':
                return ChangePlanLogoFromUploadComponent;
                break;
            case 'RemoveMessagePlanAssignmentComponent':
                return RemoveMessagePlanAssignmentComponent;
                break;
            case 'RemoveLogoPlanAssignmentComponent':
                return RemoveLogoPlanAssignmentComponent;
                break;               
            default:
                return '';
                break;
        }
    }
}
