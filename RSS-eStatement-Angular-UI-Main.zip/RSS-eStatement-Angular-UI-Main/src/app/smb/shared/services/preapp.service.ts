import { Injectable, Inject } from '@angular/core';
import { AppcacheService } from './appcache.service';
// import { OverviewService, OVERVIEW_SERVICE } from './overview.service';
import { Everything } from '../model/everything';
import { EverythingService } from './everything.service';
import { HttpParams } from '@angular/common/http';

import { environment } from '../../../../environments/environment';
// import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class PreAppService {

    private provId = "";
    everything: Everything[] = [];




  //   yourArray.forEach(function (arrayItem) {
  //     var x = arrayItem.prop1 + 2;
  //     console.log(x);
  // });
    User:any;
    constructor(private _everythingService: EverythingService, private __appCacheService: AppcacheService) {
      this.User = JSON.parse(String(sessionStorage.getItem("User")));
      this.provId = this.User.ProviderID;
     }



    load() {
        // return new Promise((resolve) => {

          return this._everythingService.getEverything(this.provId).subscribe(
            (res => {

                const status = res.status;
                console.log('Status Code: ' + status);
                this.everything = res.body;
                // console.log('Here is EVERYTHING: ' + JSON.stringify(res.body));
                console.log('Here is the providerId value: ' + res.body[0].providerId);
                console.log(res.body.length);


                 for (var j = 0; j < res.body.length; j++) {
                    // console.log(res.body[j].planName1);
                    this.__appCacheService.setAppCache('planName1', res.body[j].planName1);
                    this.__appCacheService.setAppCache('planName1', res.body[j].planName1);
                    this.__appCacheService.setAppCache('planName2', res.body[j].planName2);
                    this.__appCacheService.setAppCache('externalPlanId', res.body[j].externalPlanId);
                    this.__appCacheService.setAppCache('logoId', res.body[j].logoId);
                    this.__appCacheService.setAppCache('thumbnail', res.body[j].thumbnail);
                    this.__appCacheService.setAppCache('message1Id', res.body[j].message1Id);
                    this.__appCacheService.setAppCache('message1', res.body[j].message1);
                    this.__appCacheService.setAppCache('message2Id', res.body[j].message2Id);
                    this.__appCacheService.setAppCache('message2', res.body[j].message2);
                    this.__appCacheService.setAppCache('message3Id', res.body[j].message3Id);
                    this.__appCacheService.setAppCache('message3', res.body[j].message3);
                    this.__appCacheService.setAppCache('message4Id', res.body[j].message4Id);
                    this.__appCacheService.setAppCache('message4', res.body[j].message4);
                    this.__appCacheService.setAppCache('message5Id', res.body[j].message5Id);
                    this.__appCacheService.setAppCache('message5', res.body[j].message5);
                  }

                  const tempAppcache = this.__appCacheService.getAppCache();


                  // console.log('Dumping appcache:');
                  // console.log(JSON.stringify(tempAppcache));

                  // console.log('AppCache planName1 : ' + tempAppcache.planName1);


                      // this.__appCacheService.setAppCache('providerId', this.everything.providerId);
                      //
            }));

        }
}
