import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpClient, HttpRequest, HttpHandler } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { switchMap, catchError } from 'rxjs/operators';
import { ErrorHandlingService } from './error/error-handling.service';

@Injectable({
    providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {

    constructor(private injector: Injector, private _errorHandlingService: ErrorHandlingService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        if (sessionStorage.getItem('token')) {
            //     let myHttpClient: HttpClient = this.injector.get(HttpClient);
            //     let myWithCredentials = true;
            //     let requestBody = {"username" : environment.User, "clientid" : environment.ProviderID };

            //     return myHttpClient.post(environment.tokenURL, requestBody).pipe(

            //         catchError(this._errorHandlingService.handleHttpErrorResponse),
            //         switchMap(                    
            //             resp => {
            //                 if (resp['success']) {
            //                     let access_token = sessionStorage.setItem('auth', resp['access_token']);
            //                     let tokenizedReq = req.clone({
            //                         setHeaders: {
            //                             Authorization: 'Bearer ' + access_token
            //                         }
            //                     });
            //                     return next.handle(tokenizedReq);
            //                 }
            //                 else {
            //                     return next.handle(req);
            //                 }
            //             }
            //         )
            //     );
            // } else {

            let access_token = sessionStorage.getItem('token');
            let tokenizedReq = req.clone({
                setHeaders: {
                    Authorization: 'Bearer ' + access_token
                }
            });
           return next.handle(tokenizedReq);
        }
        return next.handle(req);
    }

}
