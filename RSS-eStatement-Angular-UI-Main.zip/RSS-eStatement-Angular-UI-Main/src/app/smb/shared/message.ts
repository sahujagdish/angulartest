export class Message {
  providerId: string;
  messageId: string;
  messageName: string;
  originalMessage: string;

  constructor (providerId: string, messageName: string, messageId: string, originalMessage: string) {
    this.providerId = providerId;
    this.messageId = messageId;
    this.messageName = messageName;
    this.originalMessage = originalMessage;
  }

  // constructor(obj?: any) {
  //     this.providerId = obj && obj.providerId || null;
  //     this.messageName = obj && obj.messageName || '';
  //     this.messageId = obj && obj.messageId || '';
  //     this.originalMessage = obj && obj.originalMessage || '';
  //   }


  // messageCustomerId: string;
  // messageName: string;
  // messageContent: string;

  // constructor (messageId: string, logoId: string, thumbnail: string) {
  //   this.providerId = providerId;
  //   this.logoId = logoId;
  //   this.thumbnail = thumbnail;
  // }
}
