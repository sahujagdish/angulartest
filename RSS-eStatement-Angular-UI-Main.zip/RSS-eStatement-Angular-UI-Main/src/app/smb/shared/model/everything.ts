export class Everything {
  providerId: string;
  planName1: string;
  planName2: string;
  externalPlanId: string;
  logoId: string;
  thumbnail: string;
  message1Id: string;
  message1: string;
  message1Name: string;
  message2Id: string;
  message2: string;
  message2Name: string;
  message3Id: string;
  message3: string;
  message3Name: string;
  message4Id: string;
  message4: string;
  message4Name: string;
  message5Id: string;
  message5: string;
  message5Name: string;


  constructor (providerId: string
      , planName1: string
      , planName2: string
      , externalPlanId: string
      , logoId: string
      , thumbnail: string
      , message1Id: string
      , message1: string
      , message1Name: string
      , message2Id: string
      , message2: string
      , message2Name: string
      , message3Id: string
      , message3: string
      , message3Name: string
      , message4Id: string
      , message4: string
      , message4Name: string
      , message5Id: string
      , message5: string
      , message5Name: string) {
    this.providerId = providerId;
    this.planName1 = planName1;
    this.planName2 = planName2;
    this.externalPlanId = externalPlanId;
    this.logoId = logoId;
    this.thumbnail = thumbnail;
    this.message1Id = message1Id;
    this.message1 = message1;
    this.message1Name = message1Name;
    this.message2Id = message2Id;
    this.message2 = message2;
    this.message2Name = message2Name;
    this.message3Id = message3Id;
    this.message3 = message3;
    this.message3Name = message3Name;
    this.message4Id = message4Id;
    this.message4 = message4;
    this.message4Name = message4Name;
    this.message5Id = message5Id;
    this.message5 = message5;
    this.message5Name = message5Name;
  }
}
