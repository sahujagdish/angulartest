export enum MyEventType {
    UploadComplete = 'UploadComplete',
    DeleteComplete = 'DeleteComplete',
    AssignLogoComplete = 'AssignLogoComplete',
    ReplaceLogoComplete = 'ReplaceLogoComplete',
    DeletePlanLogoComplete = 'DeletePlanLogoComplete',
    CreateMessageComplete = 'CreateMessageComplete',
    UpdateMessageComplete = 'UpdateMessageComplete',
    DeleteMessageComplete = 'DeleteMessageComplete',
    DeletePlanMessageComplete = 'DeletePlanMessageComplete',
    AssignMessageComplete = 'AssignMessageComplete',
    CreatePlanComplete = 'CreatePlanComplete',
    UpdatePlanComplete = 'UpdatePlanComplete',
    DeletePlanComplete = 'DeletePlanComplete',
    AssignPlanComplete = 'AssignPlanComplete',
    RemoveAssignMessageComplete = 'RemoveAssignMessageComplete',
    RemoveAssignLogoComplete = 'RemoveAssignLogoComplete'
}
