import { MyEventType } from './myenums.enum';

export interface MyEvent {
    type: MyEventType;
    success: boolean;
    message: string;
}