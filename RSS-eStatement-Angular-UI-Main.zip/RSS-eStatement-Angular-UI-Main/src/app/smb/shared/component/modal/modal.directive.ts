import { Directive, Input, OnInit, ComponentRef, ElementRef, HostListener, Renderer2, ApplicationRef, EmbeddedViewRef, Injector, ComponentFactoryResolver } from '@angular/core';
import { ModalComponent } from './modal.component'

@Directive({
    selector: '[appModal]'
})
export class ModalDirective implements OnInit {
    @Input() componentName: string;
    @Input() componentData: string;
    @Input() componentData2: any ;
    @HostListener('click', ['$event'])

    /* modal create */
    openModal() {
        this.createModalDialog(ModalComponent);
    }

    constructor(
        private el: ElementRef,
        private ren: Renderer2,
        private appRef: ApplicationRef,
        private injector: Injector,
        private componentFactoryResolver: ComponentFactoryResolver
    ) { }

    ngOnInit(){

    }

    createModalDialog(modalDialogComponent) {
        debugger;
        // Create a component reference from the component
        const modalDialogComponentRef = this.componentFactoryResolver.resolveComponentFactory(modalDialogComponent).create(this.injector);
        // Attach component to the appRef so that it's inside the ng component tree
        this.appRef.attachView(modalDialogComponentRef.hostView);
        // Get DOM element from component
        const domElem = (modalDialogComponentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
        // Append DOM element to the body..must append to body not this directive ViewComponent or modal will display within dom where directive is
        this.ren.appendChild(document.body, domElem);
        //document.body.appendChild(domElem);
        // pass in modal content component name..any data...and destroy listener
        modalDialogComponentRef.instance['componentName'] = this.componentName;
        modalDialogComponentRef.instance['componentData'] = this.componentData;
        modalDialogComponentRef.instance['componentData2'] = this.componentData2;
        modalDialogComponentRef.instance['destroyEvent'].subscribe(
            e => {
                if (e) {
                    this.myDestroy(modalDialogComponentRef)
                }
            }
        );

        return modalDialogComponentRef;
    }

    myDestroy(modalDialogComponentRef){
        this.appRef.detachView(modalDialogComponentRef.hostView);
        modalDialogComponentRef.destroy();
    }

}
