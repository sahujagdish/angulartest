export class TestMessage {
  providerId: string;
  messageName: string;
  messageId: string;
  originalMessage: string;
}
