import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  recipientName: string = '';
  chosenRecipient: string = '';

  constructor() { }

  ngOnInit() {
  }

  openModalWindow(data: any): string {
    console.log(data);
    alert('You clicked on ' + data.target.dataset.whatever);
    this.recipientName = data.target.dataset.whatever;
    this.chosenRecipient = this.recipientName;

    return this.recipientName;
  }

}
