import { Component, OnInit, AfterViewInit } from '@angular/core';
import { SpinnerService } from './shared/services/spinner-service.service';
import { Subject } from 'rxjs';
import { AppcacheService } from './shared/services/appcache.service';
// import { AppCacheModel } from './shared/model/appCache.model';
import { environment } from '../../environments/environment';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';

declare var $: any;

@Component({
  selector: 'smb-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'smb';
  theDate = new Date();
  theYear = this.theDate.getFullYear();
  private appCache;
  spinnerColor = 'primary';
  spinnerMode : ProgressSpinnerMode = 'indeterminate';
  spinnerValue = 50;
  isLoading: Subject<boolean>;
  User:any;
  constructor (private _appCacheService: AppcacheService, private spinnerService: SpinnerService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this._appCacheService.setAppCache('providerId', this.User.ProviderID);
    this.appCache = this._appCacheService.getAppCache();

  }


  ngOnInit(): void {
    this.isLoading = this.spinnerService.isLoading;
    // providerId will be taken from the JWT that will be created when loggging into eStatements...this is just being hard-coded for local development
    
    // if (environment.env === 'local' && !window["myProvID"]) {
    //     this._appCacheService.setAppCache('providerId', environment.providerId);
    // }
    // else
    // {
    //     this._appCacheService.setAppCache('providerId', window["myProvID"]);
    // }    

	//this.isLoading.next(this.spinnerService.isLoading);

  }

  ngAfterViewInit(): void {
    $(document).ready( () => {
      // Show or hide the sticky footer button
      $(window).scroll( () => {
        if ($(this).scrollTop() > 25) {
          $('.go-top').fadeIn(200);
        } else {
          $('.go-top').fadeOut(200);
        }
      });

      // Animate the scroll to top
      $('.go-top').click(function (event) {
        event.preventDefault();

        $('html, body').animate({ scrollTop: 0 }, 300);
      });
    });

    $(function () {
      // Need to initialize tooltips
      $('[data-tooltip="true"]').tooltip();
    });



  }



}
