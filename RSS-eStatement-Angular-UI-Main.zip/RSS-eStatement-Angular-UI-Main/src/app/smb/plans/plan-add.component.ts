import { Component, OnInit } from '@angular/core';
import { Plan } from '../shared/plan';
import { PlanService } from './plan.service';

@Component({
  // selector: 'app-plan-add',
  templateUrl: './plan-add.component.html',
  styleUrls: ['./plan-add.component.css']
})
export class PlanAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
