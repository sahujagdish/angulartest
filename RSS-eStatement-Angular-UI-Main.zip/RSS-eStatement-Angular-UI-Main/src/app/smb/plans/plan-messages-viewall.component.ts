import { Component, OnInit, AfterViewChecked, Input, EventEmitter, Output } from '@angular/core';
import { EverythingService } from '../shared/services/everything.service';
import { Everything } from '../shared/model/everything';
import { Plan } from '../shared/plan';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';

declare var jQuery: any;

declare var $: any;

@Component({
  selector: 'app-plan-messages-viewall',
  templateUrl: './plan-messages-viewall.component.html',
  styleUrls: ['./plan-messages-viewall.component.css']
})
export class PlanMessagesViewallComponent implements OnInit, AfterViewChecked {
  @Input() componentData: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  private appCache;
  provId: any;
  errorMessage: string;
  filteredPlans: Everything[] = [];
  plans: Everything[] = [];
  _listFilter: string;

  constructor(private _everythingService: EverythingService, private _appCacheService: AppcacheService) {
    this.provId = _appCacheService.getAppCache().providerId;
    // this.filteredPlans = this.plans;
    this._listFilter = this.componentData;
  }

  ngOnInit() {

    this._everythingService.getEverything(this.provId)

    .subscribe(
      resp => {
        this.plans = resp.body;
        this.plans.forEach((t, i) => {

          if (t.externalPlanId === this.componentData) {
              this.filteredPlans.push(t);
          }

        });

        //this.filteredPlans = this.performFilter(this.componentData);
      }
      ,
      error => this.errorMessage = <any>error
    );

  }


  performFilter(filterBy: string): Everything[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.plans.filter((plan: Everything) =>
          plan.externalPlanId.toLocaleLowerCase().indexOf(this.componentData) !== -1);
  }

  shortenMessage() {

      $.shorten.setDefaults({
          namespace: 'shorten',
          chars: 100,
          ellipses: '...',
          more: '<p>SHOW MORE</p>',
          less: '<p>SHOW LESS</p>'
      });

      $('.addReadMore').shorten();

  }


  closeModal() {
    this.closeEvent.emit(true);
  }

  ngAfterViewChecked(): any {
      // commenting out the call to shortenMessage as the 3rd. party node_modules\jquery-shorten tool is stripping out formatting.
      // this.shortenMessage();
}

}


