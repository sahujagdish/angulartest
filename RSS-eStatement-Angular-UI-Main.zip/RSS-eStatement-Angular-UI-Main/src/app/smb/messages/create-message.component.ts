import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { Message } from '../shared/message';
import { MessageService } from './message.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';


@Component({
  selector: 'app-create-message',
  templateUrl: './create-message.component.html',
  styleUrls: ['./create-message.component.css']
})

export class  CreateMessageComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  @Input() componentData2: string = '';
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  // currentAssignMessageCompleteSubscription: Subscription;
  currentMessagesSubscription: Subscription;
  currentCreateMessageCompleteSubscription: Subscription;
  currentMessageAssignmentCompleteSubscription: Subscription;

  // provId = environment.providerId;
  provId: any;
  errorMessage: string;
  messages: Message[] = [];
  clientId: number;
  editorValue: string = '';
  fullPage: false;
  CkeditorConfig = {};
  uneditedOriginalMessage: string;
  newMessageId: string = '';
  newMessageName: string = '';
  ExternalPlanID: string = '';
  MessageLocation: string = '';


  constructor(private _messageService: MessageService, _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {

      this.provId = _appCacheService.getAppCache().providerId;

      this.CkeditorConfig = {
        height: 400,
        disableNativeSpellChecker: false,
        allowedContent: true,
        disableAutoInline: true,
        //extraPlugins: 'sourcedialog',
        //removePlugins: 'sourcearea',
        toolbar: [
            { name: 'editing', groups: ['find', 'selection'], items: ['Find', 'Replace', '-', 'SelectAll', '-'] },
            { name: 'basicstyles', groups: ['basicstyles', 'cleanup'], items: ['Bold', 'Italic', 'Underline', '-', 'RemoveFormat'] }
        ]
    };



    }



    ngOnInit(): void {
      (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).disabled = true;


        // setup subscription for CreateMessageComplete event. When true emit close event for modal or do something else if false
        this.currentCreateMessageCompleteSubscription = this._myEventsService.currentMessageCreateComplete.subscribe(
           (createMessageComplete: MyEvent) => {
               if (createMessageComplete.success) {
                  window.alert(createMessageComplete.message);
                  this.closeModal();
               } else {
                   window.alert(createMessageComplete.message);
               }
           }
        );


        // subscribe to logos observable which will be emitted from service and set return to local logos
        this.currentMessagesSubscription = this._messageService.messages.subscribe(messages => {
          this.messages = messages;
        });

        // call to get messages. Service will handle if it needs to call the server or not
        this._messageService.getAllMessages(this.provId);


        // setup subscription for AssignMessageComplete event. When true emit close event for modal or do something else if false
        this.currentMessageAssignmentCompleteSubscription = this._myEventsService.currentMessageAssignmentComplete.subscribe(
            (assignMessageComplete: MyEvent) => {
                if (assignMessageComplete.success) {
                  window.alert(assignMessageComplete.message);
                  // alert('About to close modal...');
                  this.closeModal();
                } else {
                    window.alert(assignMessageComplete.message);
                }
            }
         );


        if (this.componentData !== '' && this.componentData2 !== '') {
            this.ExternalPlanID = this.componentData;
            this.MessageLocation = this.componentData2;
        }


   }

//    ngAfterViewChecked(): any {
//     (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).disabled = true;
//     }


    saveNewMessage() {
        // console.log('New Message ID: ' + this.newMessageId);
        // console.log('New Message Name: ' + this.newMessageName);
        // console.log('New Message Text: ' + this.editorValue);

        var re = /&nbsp;/gi;
        var str = this.editorValue
        var msg = str.replace(re, ' ');

        // if (this.editorValue.length > 0 && this.newMessageId.length > 0) {
        //   this._messageService.addMessage(this.provId, this.newMessageId, this.newMessageName, msg);
        // } else {
        //   alert ('Please enter a message');
        // }


        if (this.editorValue.length > 0 && this.newMessageId.length > 0) {

            if (this.newMessageId.indexOf(' ') === -1) {

                let MessageIdIsUnique = true;
                // Ensure the new logoid is unique
                this.messages.forEach((t, i) => {

                  if (t.messageId.toLocaleLowerCase() === this.newMessageId.trim().toLocaleLowerCase()) {
                      alert('The Message ID you entered is already being used. Please enter a unique Message ID value.');
                      MessageIdIsUnique = false;
                  }

                });

                if (MessageIdIsUnique) {
                  if (!this.ExternalPlanID && !this.MessageLocation) {
                      this._messageService.addMessage(this.provId, this.newMessageId.trim(), this.newMessageName.trim(), msg);
                  } else {
                      this._messageService.addMessageAndAssign(this.provId, this.newMessageId.trim(), this.newMessageName.trim(), msg, this.ExternalPlanID, this.MessageLocation);
                  }
                  // this.closeModal();
                }

              } else {
                alert('Message ID cannot contain spaces.');
              }

          } else {
                alert ('Please enter a message');
          }


    }


    saveNewMessageAndAssign() {
        alert('In saveNewMessageAndAssign!');
    }

    toggleNewSaveButton() {
      // Enable/disable Save button

      if (this.newMessageId.length > 0) {
        // if (this.newMessageId.length > 0 && this.editorValue.length > 0) {
            // (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).style.color = '#43A047';
            (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).disabled = false;

        } else {
            (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).disabled = true;
            // (<HTMLFormElement>document.getElementById('saveNewMsgBtn')).style.color = '#C7C2C2';
        }
    }


    onSubmit(editMessageForm) {
        console.log('editeMessageForm: ' + editMessageForm);
        alert('Form submitted!');
    }

    closeModal() {
          this.closeEvent.emit(true);
      }

    ngOnDestroy() {
        this.currentCreateMessageCompleteSubscription.unsubscribe();
        this.currentMessageAssignmentCompleteSubscription.unsubscribe();
    }




 }

