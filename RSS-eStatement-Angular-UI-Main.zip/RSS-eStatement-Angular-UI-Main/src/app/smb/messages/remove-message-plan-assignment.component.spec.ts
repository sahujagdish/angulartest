/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { RemoveMessagePlanAssignmentComponent } from './remove-message-plan-assignment.component';

describe('RemoveMessagePlanAssignmentComponent', () => {
  let component: RemoveMessagePlanAssignmentComponent;
  let fixture: ComponentFixture<RemoveMessagePlanAssignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveMessagePlanAssignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveMessagePlanAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
