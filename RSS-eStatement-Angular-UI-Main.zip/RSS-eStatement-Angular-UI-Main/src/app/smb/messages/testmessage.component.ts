import { Component, OnInit,  AfterViewChecked} from '@angular/core';
import { TestMessage } from '../shared/testmessage';
import { TestmessageService } from './testmessage.service';
//import { JsonPipe } from '@angular/common/src/pipes/json_pipe';
import {MatTooltipModule} from '@angular/material/tooltip';

@Component({
  selector: 'app-testmessage',
  templateUrl: './testmessage.component.html',
  styleUrls: ['./testmessage.component.css']
})
export class TestmessageComponent implements OnInit {
  errorMessage: string;
  messages: TestMessage[] = [];
  // testMessage1 = 'This is my Angular test message 1.';
  testMessage1 = {'Message': '<p>This is a test message being updated from Angular via a PUT</p>'};

  // bodyObj = {
  //   testMessage1: 'This is my Angular test message 1.'
  // };
  deleteMessage1 = 'RETIRE';
  newMessage = {
    'Message': '<p>This is a new message being added via Angular via a POST</p>'
  };

  authData = {
    'client_id' : '11'
    , 'Grant_Type' : 'password'
    , 'Username' : 'admindemo'
    , 'Password' : 'Admindemo1'
    , 'Refresh_Token' : '7f0d5c56-6298-4cca-8fb2-02d030bc86b5'
  };

  newMessageName = 'Retirement 101';

  constructor(private _testmessageService: TestmessageService) { }

  ngOnInit() {



    this._testmessageService.getMessages().subscribe(
      resp => {
        const status = resp.status;
        console.log('Status Code: ' + status);
        this.messages = resp.body;
      },
      error => this.errorMessage = <any>error
    );


  }

  addMessage() {
    this._testmessageService.addMessage(this.newMessage).subscribe(
        res => console.log(res)
      );
  }

  getAuthToken () {
    console.log('Calling getAuthenticationToken...');
    this._testmessageService.getAuthenticationToken(this.authData).subscribe(
      res => {
        console.log('getAuthToken Response: ' + JSON.stringify(res));
        console.log('Here is the token: ' + res.result.access_token);
      }
    );
  }

  updateMessage() {
    this._testmessageService.updateMessage(this.testMessage1).subscribe(
        res => console.log(res)
       );
  }



  deleteMessage() {
    this._testmessageService.deleteMessage(this.deleteMessage1).subscribe(
        res => console.log(res)
      );
  }

}
