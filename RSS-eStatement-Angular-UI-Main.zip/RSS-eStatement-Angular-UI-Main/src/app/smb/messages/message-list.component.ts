import { Component, OnInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { DatePipe, formatDate} from '@angular/common';
// import { Router } from '@angular/router';
import {MatRadioModule} from '@angular/material/radio';
import { Message } from '../shared/message';
import { Plan } from '../shared/plan';
import { MessageService } from './message.service';
import { PlanService } from '../plans/plan.service';
//import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';
//import { JsonPipe } from '@angular/common/src/pipes/json_pipe';
import { environment } from '../../../environments/environment';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import * as FileSaver from 'file-saver';
import { SpinnerService } from '../shared/services/spinner-service.service';

declare var jQuery: any;

declare var $: any;

@Component({
    // selector: 'app-message-list',
    templateUrl: './message-list.component.html',
    styleUrls: ['./message-list.component.css']
})

export class MessageListComponent implements OnInit, AfterViewChecked, OnDestroy {
    // provId = environment.providerId;
    provId: any;
    errorMessage: string;
    _listFilter: string;
    filteredMessages: Message[] = [];
    messages: Message[] = [];
    _messagesToDelete: any = [];
    _messageIdToDelete: any = [];
    clientId: number;
    editorValue: string = '';
    fullPage: false;
    CkeditorConfig = {};
    myToken: any;
    mySessionToken: any;
    theDate = new Date();
    theYear = this.theDate.getFullYear();
    _planListFilter: string;
    filteredPlans: Plan[] = [];
    plans: Plan[] = [];
    uneditedOriginalMessage: string;
    newMessageId: string = '';
    newMessageName: string = '';
    currentPlansSubscription: Subscription;
    currentMessagesSubscription: Subscription;
    currentMessagesDeleteCompleteSubscription: Subscription;
    currentCreateMessageCompleteSubscription: Subscription;
    currentUpdateMessageCompleteSubscription: Subscription;
    currentMessageAssignmentCompleteSubscription: Subscription;
    currentRemoveMessageAssignmentCompleteSubscription: Subscription;


    constructor(private _messageService: MessageService
        //, private localStorage: LocalStorageService
        , private _planService: PlanService, _appCacheService: AppcacheService
        , private _myEventsService: MyEventsService
        , private spinnerService: SpinnerService) {

        this.provId = _appCacheService.getAppCache().providerId;
        this.filteredMessages = this.messages;
        this.listFilter = '';
        this.uneditedOriginalMessage = '';


        // Version with spell checker (albeit, with ads)
        // this.CkeditorConfig = {
        //     height: 400,
        //     toolbar: [
        //       { name: 'editing', groups: [ 'find', 'selection', 'spellchecker' ], items: [ 'Find', 'Replace', '-',  'SelectAll', '-', 'Scayt' ] },
        //       { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold', 'Italic', 'Underline', '-', 'RemoveFormat' ] }
        //   ]
        // };

        // Version without spell checker
        // this.CkeditorConfig = {
        //     height: 400,
        //     toolbar: [
        //         { name: 'editing', groups: ['find', 'selection'], items: ['Find', 'Replace', '-', 'SelectAll', '-'] },
        //         { name: 'basicstyles', groups: ['basicstyles', 'cleanup'], items: ['Bold', 'Italic', 'Underline', '-', 'RemoveFormat'] }
        //     ]
        // };
    }

    // just a test setting a session token
    // @SessionStorage() MessageBoardSessionToken: string = `thisismysessiontoken123-12345`;


    // sessionStorage.getItem('MessageBoardSessionToken');

    ngOnInit(): void {
        // call to get messages. Service will handle if it needs to call the server or not
        this._messageService.getAllMessages(this.provId);

        // subscribe to logos observable which will be emitted from service and set return to local logos
        this.currentMessagesSubscription = this._messageService.messages.subscribe(messages => {
          this.messages = messages;
          this.filteredMessages = messages;
      });

        // setup subscription for MessageDeleteComplete event.
        this.currentMessagesDeleteCompleteSubscription = this._myEventsService.currentMessageDeleteComplete.subscribe(
          (deleteMessageComplete: MyEvent) => {
              if (deleteMessageComplete.success) {
                  window.alert(deleteMessageComplete.message);
              } else {
                  window.alert(deleteMessageComplete.message);
              }
              this._listFilter = ''; // clear out the search box
              this.filteredMessages = this.messages;
            }
          );



        // setup subscription for CreateMessageComplete event to clear out the search box
        this.currentCreateMessageCompleteSubscription = this._myEventsService.currentMessageCreateComplete.subscribe(
          (createMessageComplete: MyEvent) => {
            this._listFilter = ''; // clear out the search box
            this.filteredMessages = this.messages;
          }
       );

        // setup subscription for UpdateMessageComplete event to clear out the search box
        this.currentUpdateMessageCompleteSubscription = this._myEventsService.currentMessageUpdateComplete.subscribe(
          (updateMessageComplete: MyEvent) => {
            this._listFilter = ''; // clear out the search box
            this.filteredMessages = this.messages;
          }
        );


       // setup subscription for AssignMessageComplete event. When true emit close event for modal or do something else if false
       this.currentMessageAssignmentCompleteSubscription = this._myEventsService.currentMessageAssignmentComplete.subscribe(
        (assignMessageComplete: MyEvent) => {
           // this._listFilter = ''; // clear out the search box
           // this.filteredMessages = this.messages;
        }
       );
    
       // setup subscription for RemoveAssignMessageComplete event.
       this.currentRemoveMessageAssignmentCompleteSubscription = this._myEventsService.currentMessageRemoveAssignmentComplete.subscribe(
        (removeAssignMessageComplete: MyEvent) => {
           // this._listFilter = ''; // clear out the search box
           // this.filteredMessages = this.messages;
        }
       );
     






      // subscribe to plans observable which will be emitted from service and set return to local plans
      this.currentPlansSubscription = this._planService.plans.subscribe(plans => {
            this.plans = plans
            this.filteredPlans = plans;
        });


      //call to get plans. Service will handle if it needs to call the server or not
      this._planService.getAllPlans(this.provId);


      // get the JWT token from LocalStorage
      // this.myToken = localStorage.getItem('myJWToken');
      // console.log(this.myToken);

      // get the JWT token from LocalStorage
      // this.mySessionToken = sessionStorage.getItem('myJWT');
      // console.log(this.mySessionToken);

        // (<HTMLFormElement>document.getElementById('DeleteMessagesButton')).disabled = true;

    }

    ngAfterViewChecked(): any {
        // commenting out the call to shortenMessage as the 3rd. party node_modules\jquery-shorten tool is stripping out formatting.
        // this.shortenMessage();
    }

    shortenMessage() {

        //  alert('before shorten in shortenMessage');

        $.shorten.setDefaults({
            namespace: 'shorten',
            chars: 300,
            ellipses: '...',
            more: '<p>SHOW MORE</p>',
            less: '<p>SHOW LESS</p>'
        });

        $('.addReadMore').shorten();
        //  alert('after shorten in shortenMessage');
    }


    get listFilter(): string {
        return this._listFilter;
    }

    set listFilter(value: string) {
        this._listFilter = value;
        this.filteredMessages = this._listFilter ? this.performFilter(this.listFilter) : this.messages;
    }

    get planListFilter(): string {
        return this._planListFilter;
    }

    set planListFilter(value: string) {
        this._planListFilter = value;
        this.filteredPlans = this._planListFilter ? this.performPlanFilter(this._planListFilter) : this.plans;
    }


    performFilter(filterBy: string): Message[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.messages.filter((message: Message) =>
            // Need to first check for messageName being NULL to avoid an error because it isn't a required field and may be NULL
            (message.messageName !== null && message.messageName.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (message.messageId !== null && message.messageId.toLocaleLowerCase().indexOf(filterBy) !== -1));
    }

    performPlanFilter(filterBy: string): Plan[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.plans.filter((plan: Plan) =>
            (plan.planName1  !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
    }


    removeChosenMessage(data: any) {
        // alert(data.target.parentElement.value);
        const confirmMessageRemoval = confirm('Are you sure you wish to delete Message ID ' + data + '?\n\nDeleting this message will remove it from any plans to which it is currently assigned.' );

        if (confirmMessageRemoval === true) {
           this._messageService.deleteMessage(this.provId, data);
          // Need to add code to refresh the display
          //alert('Message has been deleted!');
        }
      }


    onSubmit(editMessageForm) {
        console.log('editeMessageForm: ' + editMessageForm);
        alert('Form submitted!');
    }

    ngOnDestroy() {
        this.currentMessagesSubscription.unsubscribe();
        this.currentPlansSubscription.unsubscribe();
        this.currentMessagesDeleteCompleteSubscription.unsubscribe();
        this.currentCreateMessageCompleteSubscription.unsubscribe();
        this.currentMessageAssignmentCompleteSubscription.unsubscribe();
        this.currentUpdateMessageCompleteSubscription.unsubscribe();
        this.currentRemoveMessageAssignmentCompleteSubscription.unsubscribe();        
    }

    OnDownloadMessageAssignmentReport() : void
    {   
        this.spinnerService.show();
        this._messageService.planMessageAssignmentReport( this.provId ).subscribe(
            res => {
                this.spinnerService.hide();
                var blob = new Blob( [res], { type: 'application/application/pdf' }); 
                FileSaver.saveAs( blob, 'PlanMessageAssignment-' + formatDate(new Date(), 'yyyy-MM-dd-hh-mm', 'en') + '.pdf'); 
            }
        );
    }
}
