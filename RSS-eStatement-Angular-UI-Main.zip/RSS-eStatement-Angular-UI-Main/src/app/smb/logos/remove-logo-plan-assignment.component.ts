import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { LogoService } from './logo.service';
import { Plan } from '../shared/plan';
import { PlanService } from '../plans/plan.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { ErrorHandlingService } from '../shared/services/error/error-handling.service';
import { catchError } from 'rxjs/operators';
import { SpinnerService } from '../shared/services/spinner-service.service';

@Component({
    selector: 'app-remove-logo-plan-assignment',
    templateUrl: './remove-logo-plan-assignment.component.html',
    styleUrls: ['./remove-logo-plan-assignment.component.css']
})
export class RemoveLogoPlanAssignmentComponent implements OnInit, OnDestroy {
    @Input() componentData: string;
    @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    currentRemoveAssignLogoCompleteSubscription: Subscription;
    private appCache;
    provId: any;
    chosenLogoId: string;
    filteredPlans: Plan[] = [];
    plans: Plan[] = [];
    _planListFilter: string;
    _plansToRemoveLogo: any = [];
    _plansToRemoveLogoDisplay: any = [];

    // [{'PlanName1': '', 'PlanName2': '', 'PlanID': ''}];

    constructor(private _LogoService: LogoService, private _planService: PlanService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService, private _errorHandlingService: ErrorHandlingService, private spinnerService: SpinnerService) {
        this.appCache = this._appCacheService.getAppCache();
        this.provId = this.appCache.providerId;
        this.filteredPlans = this.plans;
        this.planListFilter = '';
    }

    ngOnInit() {
        this.spinnerService.show();
        // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
        this.currentRemoveAssignLogoCompleteSubscription = this._myEventsService.currentLogoRemoveAssignmentComplete.subscribe(
            (removeAssignLogoComplete: MyEvent) => {
                if (removeAssignLogoComplete.success) {
                  window.alert(removeAssignLogoComplete.message);
                  this.closeModal();
                } else {
                    window.alert(removeAssignLogoComplete.message);
                }
            }
        );

        this.chosenLogoId = this.componentData;

        // call to get plans. Service will handle if it needs to call the server or not
        this._planService.getLogoPlans(this.provId, this.chosenLogoId).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe((resp: any) => {
          this.plans = resp.body;
          this.filteredPlans = resp.body;
          this.spinnerService.hide();
        });
    }

    get planListFilter(): string {
        return this._planListFilter;
    }

    set planListFilter(value: string) {
        this._planListFilter = value;
        this.filteredPlans = this._planListFilter ? this.performPlanFilter(this.planListFilter) : this.plans;
    }

    performPlanFilter(filterBy: string): Plan[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.plans.filter((plan: Plan) =>
            (plan.planName1  !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
    }

    removeLogoFromPlans(): void {

        const confirmRemoveLogoToPlans = confirm('Are you sure you wish to remove Logo ID ' + this.chosenLogoId + ' from the selected plan(s)?');

        if (confirmRemoveLogoToPlans === true) {
              this._LogoService.planLogoRemoval(this.provId, this.chosenLogoId, this._plansToRemoveLogo);
        }
    }

    updateLogoPlansList(PlanName1, PlanName2, PlanID): void {

        if (this._plansToRemoveLogo.indexOf(PlanID) === -1) {
              this._plansToRemoveLogo.push(PlanID);
              this._plansToRemoveLogoDisplay.push(
                {'PlanName1': PlanName1,'PlanName2': PlanName2,'PlanID': PlanID}
              );
        }

        this.toggleSubmitButton();
    }

    RemovePlanFromAssignmentList(planID) {

      const removePlanIndex = this._plansToRemoveLogo.indexOf(planID);

      if (removePlanIndex > -1) {
          this._plansToRemoveLogo.splice(removePlanIndex, 1);
          this._plansToRemoveLogoDisplay.splice(removePlanIndex, 1);
        }
        this.toggleSubmitButton();
    }


    toggleSubmitButton() {
        if (this._plansToRemoveLogoDisplay.length > 0) {
          (<HTMLFormElement>document.getElementById('RemoveLogoToPlansBtn')).disabled = false;
        } else {
          (<HTMLFormElement>document.getElementById('RemoveLogoToPlansBtn')).disabled = true;
      }
    }

    SelectAllPlans() {
        for (let i = 0; i < this.plans.length; i++) {
            this.updateLogoPlansList(this.plans[i].planName1, this.plans[i].planName2, this.plans[i].externalPlanId);
        }
    }

    clearCheckboxes() {
        for (let x = 0; x < document.getElementsByTagName('input').length; x++) {
            if (document.getElementsByTagName('input').item(x).type === 'checkbox') {
                document.getElementsByTagName('input').item(x).checked = false;
                // return true;
            }
        }
    }

    closeModal() {
        this.closeEvent.emit(true);
    }

    ngOnDestroy() {
        this.currentRemoveAssignLogoCompleteSubscription.unsubscribe();        
    }

}
