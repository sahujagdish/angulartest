/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ChangePlanLogoFromLibraryComponent } from './change-plan-logo-from-library.component';

describe('ChangePlanLogoFromLibraryComponent', () => {
  let component: ChangePlanLogoFromLibraryComponent;
  let fixture: ComponentFixture<ChangePlanLogoFromLibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangePlanLogoFromLibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePlanLogoFromLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
