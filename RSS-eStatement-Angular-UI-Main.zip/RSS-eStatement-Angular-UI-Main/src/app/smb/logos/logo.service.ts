import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { catchError, tap, map } from 'rxjs/operators';
import { Logo } from '../shared/logo';
import { environment } from '../../../environments/environment';
import { ErrorHandlingService } from '../shared/services/error/error-handling.service';
import { MyEventType } from '../shared/model/myenums.enum';
import { MyEventsService } from '../shared/services/events/myevents.service';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + sessionStorage.getItem('token')
    })
};

@Injectable({
    providedIn: 'root'
})

// This service will CRUD the local dataStore in sync with REST calls
// This will allow us to just use from local memory dataStore and only pull once from server
export class LogoService {
    logos: Observable<Logo[]>;
    private _logos: BehaviorSubject<Logo[]>;
    private logoUrl: string;
    logoReplacement: Logo;
    // private _logoReplacement: BehaviorSubject<Logo>;
    private dataStore: {
        logos: Logo[]
    };

    constructor(private _http: HttpClient, private _errorHandlingService: ErrorHandlingService, private _myEventsService: MyEventsService) {
        this.logoUrl = environment.MMApiURL;
        this.dataStore = { logos: [] };
        // Observable Logo source...Use BehaviorSubject so value is available immediatly when subscribed too and after next is called.
        this._logos = <BehaviorSubject<Logo[]>>new BehaviorSubject([]);
        // this._logoReplacement = <BehaviorSubject<Logo>>new BehaviorSubject({});
        // Observable Logo stream
        this.logos = this._logos.asObservable();
        // this.logoReplacement = this._logoReplacement.asObservable();
    }

    getAllLogos(provId: any) {
        // if local observable source is empty...call to get from server..Otherwise its already available in observable stream
        if (!this._logos.getValue().length) {
            this._http.get<Logo[]>(this.logoUrl + 'logos/' + provId, { observe: 'response' }).pipe(
                catchError(this._errorHandlingService.handleHttpErrorResponse)
            ).subscribe(resp => {
                const status = resp.status;
                console.log('getAllLogos Status Code: ' + status);
                // Need to use spread operator to create a copy of itself. Otherwise the value of logos is still actually the same and view doesnt refresh
                this.dataStore.logos = [...this.dataStore.logos];
                // set logos data returned to dataStore
                this.dataStore.logos = resp.body;
                //create a copy and emit to observable
                this._logos.next(Object.assign({}, this.dataStore).logos);
            }
            );
        }
    }

    getProviderLogo(provId: any) {
        return this._http.get<any>(this.logoUrl + 'logos/' + provId + "/plevel");
    }

    sendProviderLogo(provId: any, logoId: any) {
        return this._http.post(this.logoUrl + 'logos/' + provId + "/" + logoId + "/plevel", "");
    }

    deleteProviderLogo(provId: any) {
        return this._http.post(this.logoUrl + 'logos/' + provId + "/plevel/delete", '');
    }

    getSpecificLogo(LogoToReplace, provId): Observable<Logo> {
        // if local observable source is empty...call to get from server..Otherwise its already available in observable stream

        if (this._logos.getValue().length) {
            this.dataStore.logos.forEach((t, i) => {
                if (t.logoId === LogoToReplace) {
                    console.log('Logo to replace:');
                    console.log(JSON.stringify(t));
                    this.logoReplacement = t;
                }

            });

        }

        return of(this.logoReplacement);
    }

    // Potential way to pull from the REST service instead of the data service after the initial load (if needed)
    // getAllLogosFromServer(provId: any) {
    //    this._logo.next([]);
    //    this.getAllLogos(provId);
    // }

    upload(file: File, provId, newLogoId): any {
        const input = new FormData();
        input.append('file', file, file.name);
        this._http.post<Logo>(this.logoUrl + 'logos/' + provId + '?id=' + newLogoId, input).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response from upload Logo: ' + resp);
                // Need to use spread operator to create a copy of itself. Otherwise the value of logos is still actually the same and view doesnt refresh
                this.dataStore.logos = [...this.dataStore.logos];
                // push new logo to dataStore that was returned from server
                this.dataStore.logos.push(resp);
                //create a copy and emit to observable
                this._logos.next(Object.assign({}, this.dataStore).logos);
                this._myEventsService.triggerMyEvent(true, MyEventType.UploadComplete, 'Logo has been uploaded!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.UploadComplete, 'Logo upload has failed!');
            }
        );
    }


    uploadAndAssignToPlan(file: File, provId, newLogoId, externalPlanID): any {
        const planToAddLogo: any = [];
        planToAddLogo.push(externalPlanID);

        // let resp = await this._http.post<any>(this.messageUrl + 'msgs/' + provId + '?id=' + newMessageId, JSON.stringify(newMsg), httpOptions).toPromise();
        // console.log('Response creating message in addMessageAndAssign: ' + JSON.stringify(resp));
        const input = new FormData();
        input.append('file', file, file.name);
        this._http.post<Logo>(this.logoUrl + 'logos/' + provId + '?id=' + newLogoId, input).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response from upload Logo: ' + resp);
                // Need to use spread operator to create a copy of itself. Otherwise the value of logos is still actually the same and view doesnt refresh
                this.dataStore.logos = [...this.dataStore.logos];
                // push new logo to dataStore that was returned from server
                this.dataStore.logos.push(resp);
                //create a copy and emit to observable
                this._logos.next(Object.assign({}, this.dataStore).logos);
                // this._myEventsService.triggerMyEvent(true, MyEventType.UploadComplete, 'Logo has been uploaded!');

                this.planLogoAssignment(provId, newLogoId, planToAddLogo);
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.UploadComplete, 'Logo upload has failed!');
            }
        );
    }


    replaceLogo(file: File, provId, logoId): any {
        const input = new FormData();
        input.append('file', file, file.name);
        this._http.put<Logo>(this.logoUrl + 'logos/' + provId + '?id=' + logoId, input).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response from replaceLogo: ' + JSON.stringify(resp));
                // Need to use spread operator to create a copy of itself. Otherwise the value of logos is
                // still actually the same and view doesnt refresh
                this.dataStore.logos = [...this.dataStore.logos];
                // push new logo to dataStore that was returned from server
                // this.dataStore.logos.push(resp);
                // remove original logo from dataStore and replace with the updated logo
                this.dataStore.logos.forEach((t, i) => {
                    if (t.logoId === logoId) {
                        // this.dataStore.logos.splice(i, 1, resp);
                        this.dataStore.logos.splice(i, 1);
                        this.dataStore.logos.push(resp);
                    }
                });
                // create a copy and emit to observable
                this._logos.next(Object.assign({}, this.dataStore).logos);
                this._myEventsService.triggerMyEvent(true, MyEventType.ReplaceLogoComplete, 'Logo has been replaced!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.ReplaceLogoComplete, 'Logo replace has failed!');
            }
        );
    }

    planLogoAssignment(provId, logoId, planIds) {

        this._http.post<any>(this.logoUrl + 'logos/' + provId + '/plans?id=' + logoId, JSON.stringify(planIds), httpOptions).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response for assigning logo to plan(s): ' + resp);
                this._myEventsService.triggerMyEvent(true, MyEventType.AssignLogoComplete, 'Logo has been assigned to selected plan(s)!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.AssignLogoComplete, 'Logo assignment has failed!');
            }
        );

    }

    planLogoRemoval(provId, logoId, planIds) {
        this._http.post<any>(this.logoUrl + 'logos/' + provId + '/' + logoId + '/plans/delete', JSON.stringify(planIds), httpOptions).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                this._myEventsService.triggerMyEvent(true, MyEventType.RemoveAssignLogoComplete, 'Logo has been removed from selected plan(s)!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.RemoveAssignLogoComplete, 'Logo removal has failed!');
            }
        );
    }

    deleteLogo(provId, logoID) {
        this._http.post(this.logoUrl + 'logos/' + provId + '/delete?id=' + logoID, '').pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response for deleting a logo: ' + resp);
                // Need to use spread operator to create a copy of itself. Otherwise the value of logos is still actually the same and view doesnt refresh
                this.dataStore.logos = [...this.dataStore.logos];
                // remove logo from dataStore that was deleted from server
                this.dataStore.logos.forEach((t, i) => {
                    if (t.logoId === logoID) {
                        this.dataStore.logos.splice(i, 1);
                    }
                });
                //create a copy and emit to observable
                this._logos.next(Object.assign({}, this.dataStore).logos);
                this._myEventsService.triggerMyEvent(true, MyEventType.DeleteComplete, 'Logo has been deleted!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.DeleteComplete, 'Logo delete has failed!');
            }
        );
    }


    deletePlanLogo(provId, planID, logoID) {
        this._http.post(this.logoUrl + 'logos/' + provId + '/' + planID + '/delete', '').pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
            resp => {
                console.log('Response for deleting a plan logo: ' + resp);
                // Need to use spread operator to create a copy of itself. Otherwise the value of plans is still actually the same and view doesnt refresh
                //this.dataStore.everything = [...this.dataStore.everything];
                // remove logo from dataStore that was deleted from server
                // this.dataStore.everything.forEach((t, i) => {
                //     if (t.externalPlanId === planID) {
                //         this.dataStore.everything[i].logoId = '';
                //     }
                // });
                // create a copy and emit to observable
                // this._everything.next(Object.assign({}, this.dataStore).everything);
                this._myEventsService.triggerMyEvent(true, MyEventType.DeletePlanLogoComplete, 'Plan logo has been deleted!');
            },
            err => {
                this._myEventsService.triggerMyEvent(false, MyEventType.DeletePlanLogoComplete, 'Plan logo delete has failed!');
            }
        );
    }


    GetPlanLogoAssignmentReport(provId: number) {
        return this._http.get(this.logoUrl + 'logos/' + provId + '/Report', { responseType: 'blob' });
    }

}

