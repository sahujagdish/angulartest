import { Component, OnInit, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { formatDate} from '@angular/common';
import { Logo } from '../shared/logo';
import { LogoService } from './logo.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import * as FileSaver from 'file-saver';
import { SpinnerService } from '../shared/services/spinner-service.service';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';

@Component({
    // selector: 'app-logo-list',
    templateUrl: './logo-list.component.html',
    styleUrls: ['./logo-list.component.css']
})
export class LogoListComponent implements OnInit, OnDestroy {
    private appCache;
    provId: any;
    errorMessage: string;
    _listFilter: string;
    filteredLogos: Logo[] = [];
    logos: Logo[] = [];
    _logosToDelete: any = [];
    _logoIdToDelete: any = [];
    theDate = new Date();
    theYear = this.theDate.getFullYear();
    _newLogoId: string;
    selectedLogoToUpload: null;
    newLogoId: string;
    ProviderLogo:Logo;
    SelectedLogoID="";
    isEdit:boolean=false;
    currentLogosSubscription: Subscription;
    currentDeleteCompleteSubscription: Subscription;
    currentAssignLogoCompleteSubscription: Subscription;
    currentUploadCompleteSubscription: Subscription;
    currentLogoReplacementCompleteSubscription: Subscription;
    spinnerColor = 'primary';
    spinnerMode:ProgressSpinnerMode = 'indeterminate';
    spinnerValue = 50;
    isLoading=true;
    @ViewChild('fileInput') fileInput: any;
    @ViewChild('cancelButton') cancelButton: any;


    constructor(private _LogoService: LogoService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService,private spinnerService: SpinnerService) {
        this.appCache = this._appCacheService.getAppCache();
        this.provId = this.appCache.providerId;
        // this.provId = _appCacheService.getAppCache().providerId;
        this.filteredLogos = this.logos;
        this.listFilter = '';
        this.newLogoId = '';
    }

    ngOnInit(): void {

        // Call to get logos. Service will handle if it needs to call the server or not
        this._LogoService.getAllLogos(this.provId);

        // subscribe to logos observable which will be emitted from service and set return to local logos
        this.currentLogosSubscription = this._LogoService.logos.subscribe(logos => {
            this.logos = logos;
            this.filteredLogos = logos;

            this._LogoService.getProviderLogo(this.provId).subscribe(resp=>{
                this.ProviderLogo = this.filteredLogos.filter(ele=>ele.logoId==resp.logoId)[0];
                if(this.ProviderLogo!=null){
                    this.SelectedLogoID = this.ProviderLogo.logoId;
                }
                this.isLoading=false;
                console.log(this.SelectedLogoID); 

                //;
              },(error:any)=>{
                this.isLoading=false;
                  
              });
        });


         // setup subscription for DeleteComplete event.
         this.currentDeleteCompleteSubscription = this._myEventsService.currentLogoDeleteComplete.subscribe(
              (deleteComplete: MyEvent) => {
                  if (deleteComplete.success) {
                      window.alert(deleteComplete.message);
                  }
                  else {
                      window.alert(deleteComplete.message);
                  }
                  this._listFilter = ''; // clear out the search box
                  this.filteredLogos = this.logos;
              }
          );



          // setup subscription for UploadComplete event. Clear out the search box.
        this.currentUploadCompleteSubscription = this._myEventsService.currentLogoUploadComplete.subscribe(
              (uploadComplete: MyEvent) => {
                this._listFilter = ''; // clear out the search box
                this.filteredLogos = this.logos;
              }
          );



          // setup subscription for AssignLogoComplete event. Clear out the search box.
          this.currentAssignLogoCompleteSubscription = this._myEventsService.currentAssignLogoComplete.subscribe(
            (assignLogoComplete: MyEvent) => {
              this._listFilter = ''; // clear out the search box
              this.filteredLogos = this.logos;
            }
          );


          // setup subscription for LogoReplacementComplete event. Clear out the search box.
          this.currentLogoReplacementCompleteSubscription = this._myEventsService.currentLogoReplacementComplete.subscribe(
            (replaceLogoComplete: MyEvent) => {
              this._listFilter = ''; // clear out the search box
              this.filteredLogos = this.logos;
            }
          );

    }

    editProviderLogo(){
        this.isEdit = true;
    }

    addProviderLogo(){
        if(this.SelectedLogoID!=""){
            this.isLoading=true;
     
            if(this.ProviderLogo==null){
        this._LogoService.sendProviderLogo(this.provId,this.SelectedLogoID).subscribe(resp=>{
            console.log(resp);
            this.ProviderLogo = this.filteredLogos.filter(ele=>ele.logoId==this.SelectedLogoID)[0];
            this.isLoading=false;
        });
        
        }else{
            if(this.ProviderLogo.logoId != this.SelectedLogoID){
                this._LogoService.sendProviderLogo(this.provId,this.SelectedLogoID).subscribe(resp=>{
                    console.log(resp);
                    this.ProviderLogo = this.filteredLogos.filter(ele=>ele.logoId==this.SelectedLogoID)[0];
                    this.isEdit = false;
                    this.isLoading=false;
                });     
            }
        }
    }
    }

    deleteProviderLogo(){
        this.isLoading = true;
        if(this.ProviderLogo!=null){
            this._LogoService.deleteProviderLogo(this.provId).subscribe(resp=>{
                this.ProviderLogo = null;
                this.isEdit=false;
                this.isLoading=false;
                this.SelectedLogoID="";
            })
        }
    }

    closeProviderLogo(){
        this.isEdit = false;
    }


    get listFilter(): string {
        return this._listFilter;
    }

    set listFilter(value: string) {
        this._listFilter = value;
        this.filteredLogos = this._listFilter ? this.performFilter(this.listFilter) : this.logos;
    }

    performFilter(filterBy: string): Logo[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.logos.filter((logo: Logo) =>
            logo.logoId.toLocaleLowerCase().indexOf(filterBy) !== -1);
        // || this.logos.filter(deleteThese => this._logosToDelete));
    }




    removeChosenLogo(data: any) {
        // const confirmLogoRemoval = confirm('Are you sure you wish to delete LogoID ' + data.target.parentElement.value + '?\n\nDeleting this logo will remove it from any plans to which it is currently assigned.');
        const confirmLogoRemoval = confirm('Are you sure you wish to delete LogoID ' + data + '?\n\nDeleting this logo will remove it from any plans to which it is currently assigned.');

        if (confirmLogoRemoval === true) {
            // this._LogoService.deleteLogo(this.provId, data.target.parentElement.value);
            this._LogoService.deleteLogo(this.provId, data);
        }
    }


    ngOnDestroy() {
        this.currentLogosSubscription.unsubscribe();
        this.currentDeleteCompleteSubscription.unsubscribe();
        this.currentAssignLogoCompleteSubscription.unsubscribe();
        this.currentUploadCompleteSubscription.unsubscribe();
        this.currentLogoReplacementCompleteSubscription.unsubscribe();
    }

    OnDownloadLogoAssignmentReport() : void
    {  
        this.spinnerService.show();
        this._LogoService.GetPlanLogoAssignmentReport( this.provId ).subscribe(
            res => {
                this.spinnerService.hide();
                var blob = new Blob( [res], { type: 'application/application/pdf' }); 
                FileSaver.saveAs( blob, 'PlanLogoAssignment-' + formatDate(new Date(), 'yyyy-MM-dd-hh-mm', 'en') + '.pdf'); 
            }
        );
    }
}
