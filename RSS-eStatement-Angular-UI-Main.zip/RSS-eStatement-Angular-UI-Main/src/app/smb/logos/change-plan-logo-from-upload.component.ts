import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-plan-logo-from-upload',
  templateUrl: './change-plan-logo-from-upload.component.html',
  styleUrls: ['./change-plan-logo-from-upload.component.css']
})
export class ChangePlanLogoFromUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
