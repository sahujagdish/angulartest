import { Component, OnInit, Input, EventEmitter, Output, OnDestroy} from '@angular/core';
import { AppcacheService } from '../shared/services/appcache.service';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';

@Component({
  selector: 'app-change-plan-logo-options',
  templateUrl: './change-plan-logo-options.component.html',
  styleUrls: ['./change-plan-logo-options.component.css']
})
export class ChangePlanLogoOptionsComponent implements OnInit {
  @Input() componentData: string;
  @Input() componentData2: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  private appCache;
  provId: any;
  errorMessage: string;
  ExternalPlanID: string = '';
  LogoID: string = '';


  constructor( _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {
    this.provId = _appCacheService.getAppCache().providerId;
  }

  ngOnInit() {
    this.ExternalPlanID = this.componentData;
    this.LogoID = this.componentData2;
  }


  closeModal() {
    this.closeEvent.emit(true);
  }

}




