import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { Logo } from '../shared/logo';
import { LogoService } from './logo.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { SpinnerService } from '../shared/services/spinner-service.service';

@Component({
    selector: 'app-uploadlogo',
    templateUrl: './upload-logo.component.html',
    styleUrls: ['./upload-logo.component.css']
})
export class UploadLogoComponent implements OnInit, OnDestroy {
    @Input() componentData: string;
    private appCache;
    private allowedFileTypes: Array<string> = ["image/bmp","image/jpg","image/jpeg","image/tif","image/tiff"];
    provId: any;
    logos: Logo[] = [];
    _newLogoId: string;
    newLogoId: string;
    selectedLogoToUpload: File;
    @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    //@Input('cancelButton') cancelButton: any;
    currentUploadCompleteSubscription: Subscription;
    currentLogosSubscription: Subscription;
    currentAssignLogoCompleteSubscription: Subscription;

    constructor(private _LogoService: LogoService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService, private spinnerService: SpinnerService) {
        this.appCache = this._appCacheService.getAppCache();
        this.provId = this.appCache.providerId;
        this.newLogoId = '';
    }

    ngOnInit() {
        (<HTMLFormElement>document.getElementById('uploadButton')).disabled = true;
        (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#C7C2C2';
        // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
        this.currentUploadCompleteSubscription = this._myEventsService.currentLogoUploadComplete.subscribe(
            (uploadComplete: MyEvent) => {
                this.spinnerService.hide();
                if (uploadComplete.success) {
                    window.alert(uploadComplete.message);
                    this.closeModal();
                }
                else {
                    window.alert(uploadComplete.message);
                }
            }
        );



      // setup subscription for assignLogoComplete event. When true emit close event for modal or do something else if false
      this.currentAssignLogoCompleteSubscription = this._myEventsService.currentAssignLogoComplete.subscribe(
        (assignLogoComplete: MyEvent) => {
            if (assignLogoComplete.success) {
                this.spinnerService.hide();
                //  this.closeEvent.emit(true);
                this.closeModal();
            } else {
                // window.alert(assignLogoComplete.message);
            }
        }
      );


        // subscribe to logos observable which will be emitted from service and set return to local logos
        this.currentLogosSubscription = this._LogoService.logos.subscribe(logos => {
            this.logos = logos;
        });

        // Call to get logos. Service will handle if it needs to call the server or not
        this._LogoService.getAllLogos(this.provId);

    }

    toggleUploadButton() {
        this._newLogoId = this.newLogoId;
        if (this._newLogoId.length > 0 && this.selectedLogoToUpload) {
            // (<HTMLFormElement>document.getElementById('uploadButton')).hidden = false;
            // #43A047
            (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#43A047';
            (<HTMLFormElement>document.getElementById('uploadButton')).disabled = false;

        } else {
            (<HTMLFormElement>document.getElementById('uploadButton')).disabled = true;
            (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#C7C2C2';
        }
    }

    onFileSelected(event) {
        this.selectedLogoToUpload = null;
        let mySelectedLogoToUpload = event.target.files[0];
        let fileSize = mySelectedLogoToUpload.size; //size in bytes
        let fileType = mySelectedLogoToUpload.type;
        let fileName = mySelectedLogoToUpload.name;
        let message = "";
        if (fileSize/1024/1024 > 10) { //If file larger than 10 MB
            message = "File must be smaller than 10 MB.";
        }
        if(this.allowedFileTypes.indexOf(fileType) == -1){
            if(message.length)
                message += "\n";
            message += "File must be a .tif, .jpg, .jpeg or .bmp";
        }
        // Check for whitespace in filename
        let reWhiteSpace = new RegExp(/\s/);
        if(reWhiteSpace.test(fileName)){
          if(message.length)
              message += "\n";
          message += "File name cannot contain spaces. Please remove any spaces and try again.";
        }
        if(!message.length)
            this.selectedLogoToUpload = mySelectedLogoToUpload;
        else
            alert(message);

        this.toggleUploadButton();
    }


    uploadLogo(): any {
        if (this.newLogoId.trim() === '') {
            alert('Please enter a LOGO ID');
        } else if (!this.selectedLogoToUpload) {
            alert('Please select a logo to upload');
        } else {
          let LogoIdIsUnique = true;
          // Ensure the new logoid is unique
          this.logos.forEach((t, i) => {

            if (t.logoId.toLocaleLowerCase() === this.newLogoId.trim().toLocaleLowerCase()) {
                alert('The Logo ID you entered is already being used. Please enter a unique Logo ID value.');
                LogoIdIsUnique = false;
            }

          });


          if (LogoIdIsUnique) {
            this.spinnerService.show();
            if (this.componentData) {
                // upload new logo and assign to plan
                this._LogoService.uploadAndAssignToPlan(this.selectedLogoToUpload, this.provId, this.newLogoId.trim(), this.componentData);
            } else {
                // currentUploadCompleteSubscription in ngOnit handles UploadComplete event
                this._LogoService.upload(this.selectedLogoToUpload, this.provId, this.newLogoId.trim());
            }
          }

        }

    }


    closeModal() {
        this.closeEvent.emit(true);
    }

    ngOnDestroy() {
        this.currentUploadCompleteSubscription.unsubscribe();
        this.currentAssignLogoCompleteSubscription.unsubscribe();
    }


}
