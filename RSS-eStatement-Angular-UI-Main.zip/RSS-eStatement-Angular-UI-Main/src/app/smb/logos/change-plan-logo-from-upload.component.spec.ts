/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ChangePlanLogoFromUploadComponent } from './change-plan-logo-from-upload.component';

describe('ChangePlanLogoFromUploadComponent', () => {
  let component: ChangePlanLogoFromUploadComponent;
  let fixture: ComponentFixture<ChangePlanLogoFromUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangePlanLogoFromUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePlanLogoFromUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
