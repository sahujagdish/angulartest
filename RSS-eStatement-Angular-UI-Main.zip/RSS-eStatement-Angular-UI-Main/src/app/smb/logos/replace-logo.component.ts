import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Logo } from '../shared/logo';
import { LogoService } from './logo.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { async } from '@angular/core/testing';
import { ArrayType } from '@angular/compiler/src/output/output_ast';
import { SpinnerService } from '../shared/services/spinner-service.service';


@Component({
  selector: 'app-replace-logo',
  templateUrl: './replace-logo.component.html',
  styleUrls: ['./replace-logo.component.css']
})

export class ReplaceLogoComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  private appCache;
  private allowedFileTypes: Array<string> = ["image/bmp","image/jpg","image/jpeg","image/tif","image/tiff"];
  provId: any;
  _newLogoId: string;
  newLogoId: string;
  LogoToReplace: string = '';
  logos: Logo[] = [];
  bytes: any = [];
  uints: any;
  base64: any;
  ReplacementLogo: any;
  selectedLogoToUpload: File;
  currentLogosSubscription: Subscription;
  currentLogoReplacementCompleteSubscription: Subscription;

  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  //@Input('cancelButton') cancelButton: any;
  // currentUploadCompleteSubscription: Subscription;
  

  constructor(private _LogoService: LogoService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService
    , private sanitizer: DomSanitizer, private spinnerService: SpinnerService) {
      this.appCache = this._appCacheService.getAppCache();
      this.provId = this.appCache.providerId;
      this.newLogoId = '';
  }

  ngOnInit() {
      (<HTMLFormElement>document.getElementById('uploadButton')).disabled = true;
      (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#C7C2C2';
      // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
      this.currentLogoReplacementCompleteSubscription = this._myEventsService.currentLogoReplacementComplete.subscribe(
          (replaceLogoComplete: MyEvent) => {
              this.spinnerService.hide();
              if (replaceLogoComplete.success) {
                  window.alert(replaceLogoComplete.message);
                  this.closeModal();
              } else {
                  window.alert(replaceLogoComplete.message);
              }
          }
      );


       // subscribe to logos observable which will be emitted from service and set return to local logos
        this.currentLogosSubscription = this._LogoService.logos.subscribe(logos => {
            this.logos = logos
            // this.filteredLogos = logos;
        });
    
        // Call to get logos. Service will handle if it needs to call the server or not
        // this._LogoService.getAllLogos(this.provId);


        // get the logo being replaced
        this._LogoService.getSpecificLogo(this.componentData,this.provId)
          .subscribe(resp => {
              console.log('Thumbnail data:')
              console.log(JSON.stringify(resp));
              this.LogoToReplace = JSON.stringify(resp.thumbnail);
              var re = /"/gi;
              var str = this.LogoToReplace
              this.LogoToReplace = str.replace(re, '');

              this.LogoToReplace = 'data:image/jpeg;base64,' + this.LogoToReplace;
              this.ReplacementLogo = this.sanitizer.bypassSecurityTrustResourceUrl(this.LogoToReplace);

            }
          );
  }

  toggleUploadButton() {
      if (this.selectedLogoToUpload) {
          // (<HTMLFormElement>document.getElementById('uploadButton')).hidden = false;
          // #43A047
          (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#43A047';
          (<HTMLFormElement>document.getElementById('uploadButton')).disabled = false;

      } else {
          (<HTMLFormElement>document.getElementById('uploadButton')).disabled = true;
          (<HTMLFormElement>document.getElementById('uploadButton')).style.color = '#C7C2C2';
      }
  }

  onFileSelected(event) {
    this.selectedLogoToUpload = null;
    let mySelectedLogoToUpload = event.target.files[0];
    let fileSize = mySelectedLogoToUpload.size; //size in bytes
    let fileType = mySelectedLogoToUpload.type;
    let fileName = mySelectedLogoToUpload.name;
    let message = "";
    if (fileSize/1024/1024 > 10) { //If file larger than 10 MB
        message = "File must be smaller than 10 MB.";
    }
    if(this.allowedFileTypes.indexOf(fileType) == -1){
        if(message.length)
            message += "\n";
        message += "File must be a .tif, .jpg, .jpeg or .bmp";
    }
    // Check for whitespace in filename
    let reWhiteSpace = new RegExp(/\s/);
    if(reWhiteSpace.test(fileName)){
      if(message.length)
          message += "\n";
      message += "File name cannot contain spaces. Please remove any spaces and try again.";
    }
    if(!message.length)
        this.selectedLogoToUpload = mySelectedLogoToUpload;
    else    
        alert(message);
        
    this.toggleUploadButton();
  }


  replaceLogo(): any {
      if (!this.selectedLogoToUpload) {
          alert('Please select a logo to upload');
      } else {          
          this.spinnerService.show();
          // currentUploadCompleteSubscription in ngOnit handles UploadComplete event
          this._LogoService.replaceLogo(this.selectedLogoToUpload, this.provId, this.componentData);
      }

  }

  closeModal() {
      this.closeEvent.emit(true);
  }

  ngOnDestroy() {
      this.currentLogoReplacementCompleteSubscription.unsubscribe();
  }


}
