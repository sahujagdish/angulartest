import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorPageComponent } from './E-Statement-Participant-Site/components/error/error-page/error-page.component';

var routes: Routes = [
  {path:'error',component:ErrorPageComponent},
  {path:'',loadChildren:()=>import('./E-Statement-Participant-Site/e-statement-participant-app.module').then(m=>m.EStatementParticipantModule)},
];
//routes = routes.concat(EStatementParticipantroute);
@NgModule({
  imports: [RouterModule.forRoot(routes,{onSameUrlNavigation: 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
