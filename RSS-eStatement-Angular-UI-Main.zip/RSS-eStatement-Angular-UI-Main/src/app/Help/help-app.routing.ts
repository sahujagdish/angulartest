import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { HelpComponent } from './help.component';
import { HelpScreenComponent } from './components/help-screen/help-screen.component';

const routes: Routes = [
             { path: ':page', component: HelpComponent, children: [
                    { path: '', component: HelpScreenComponent }
                ]
            }
];
//routes = routes.concat(EStatementParticipantroute);

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class HelpRoute { }
