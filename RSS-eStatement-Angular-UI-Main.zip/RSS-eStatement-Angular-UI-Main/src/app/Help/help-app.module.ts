import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from '../app-routing.module';
import {MatIconModule} from '@angular/material/icon';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatTreeModule} from '@angular/material/tree';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { HelpScreenComponent } from './components/help-screen/help-screen.component';
import { HelpComponent } from './help.component';
import { HelpRoute } from './help-app.routing';


@NgModule({
  declarations: [HelpComponent,HelpScreenComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatIconModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatTreeModule,
    MatCheckboxModule 
    ,MatProgressBarModule ,
    MatTableModule,
    MatDialogModule ,
    RouterModule,
    HelpRoute
  ],
  exports:[
   
  ]
})
export class HelpModule { }