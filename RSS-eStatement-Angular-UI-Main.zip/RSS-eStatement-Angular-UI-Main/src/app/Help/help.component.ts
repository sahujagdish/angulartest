import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HelpScreen } from './models/HelpScreenData';
import { OAuthService } from 'angular-oauth2-oidc';
import { HelpScreenComponent } from './components/help-screen/help-screen.component';
import { authConfig } from '../config/auth.config';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  provider!:String;
  
  helpScreen:any = HelpScreen;
  ToggleHelp:boolean=false;;
  page:string="";
  User:any;
  //ActiveLink:number=0;
  constructor(private router:ActivatedRoute,public route:Router,private oauthService: OAuthService) {
    this.provider = String(router.snapshot.parent!.paramMap.get('participant'));
    this.page = String(this.router.snapshot.paramMap.get('page'));
    this.User = JSON.parse(String(sessionStorage.getItem("User"))); 

    this.ToggleHelp = HelpScreen.ToggleHelp;
   }
  ngOnInit(): void {
    this.config();
  }


  public config(){
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin();
    this.oauthService.setupAutomaticSilentRefresh();
  }

  navigate(linkIndex:number,Page:string){
    this.helpScreen.ActiveLink=linkIndex;
   // this.route.routeReuseStrategy.shouldReuseRoute = () => false;
   // this.route.onSameUrlNavigation = 'reload';
    
   this.route.navigate(["../../Help",Page],{relativeTo:this.router});
    
    //location.reload();
  }

  logout() { this.oauthService.logOut(); }


  toggleHelpSection(){
    console.log(this.ToggleHelp);
    if(this.ToggleHelp){
      this.route.navigate(["../../"+this.User!.Role+"/welcome-page"],{relativeTo:this.router});
      this.ToggleHelp = false;
      HelpScreen.ToggleHelp = this.ToggleHelp;
    }else{
      this.route.navigate(["../Help/Intro"],{relativeTo:this.router});
      this.ToggleHelp = true;
      HelpScreen.ToggleHelp = this.ToggleHelp;
    }
  }

}
