import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpScreenComponent } from './help-screen.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

describe('HelpScreenComponent', () => {
  let component: HelpScreenComponent;
  let fixture: ComponentFixture<HelpScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HelpScreenComponent ]
      ,imports:[HttpClientModule,RouterTestingModule
      ],
      providers:[
        {
          provide: ActivatedRoute, useValue: {
            params: { participant: 'nyha' },
            snapshot: {
              pathFromRoot:[
                {},
                {},
                {
                  params: {
                    participant: 'nyha'
                  },
                  paramMap: {
                    get(name: string): string {
                      return 'nyha';
                    }
                  }
                }
              ],
              paramMap: {
                get(name: string): string {
                  return 'nyha';
                }
              }
            },
          }
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    sessionStorage.setItem("User",'{"userid":"Admin","ProviderID":126,"ProviderName":"ABG Houston","UUID":"114EABC8-AA97-9AD9-B1465E9462AAAD3D","Role":"admin","Provider":"null"}');
    fixture = TestBed.createComponent(HelpScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
