import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { user_repot } from '../../models/ObjectHelper';
import { ReportService } from '../../services/report-service/report.service';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';
import { IColumnInfo, TableComponent } from '../table/table.component';
import { IUser, Role } from '../../models/User';
import { PlanDropDownComponent } from '../plan-drop-down/plan-drop-down.component';

@Component({
  selector: 'app-user-report',
  templateUrl: './user-report.component.html',
  styleUrls: ['./user-report.component.css']
})
export class UserReportComponent implements OnInit {
  ColumnList: Array<IColumnInfo> = [
    { Property: "FirstName", Header: "First Name", SortProperty: "fname" },
    { Property: "LastName", Header: "Last Name", SortProperty: "lname" },
    { Property: "SSN", Header: "SSN", SortProperty: "ssn" },
    { Property: "Email", Header: "Email", SortProperty: "email" },
    { Property: "StatusName", Header: "Status", SortProperty: "statusName" },
    { Property: "PlanNumber", Header: "Plan Code", SortProperty: "planNumber" }];

  errorStatus: boolean = false;
  userObject: any;
  provider!: string;
  userForm: FormGroup = new FormGroup({
    statusCode: new FormControl(''),
    planName: new FormControl(''),
    lastName: new FormControl(''),
  })

  user: IUser;
  userRole = Role;
  statusCode: any[] = [];
  initialLoad: boolean = true;
  userDataService: any;
  userDownloadService: any;

  constructor(public route: Router, public router: ActivatedRoute, private report_service: ReportService,
    private security_service: SecurityService, download_service: DownloadService) {

    this.userDataService = report_service.getUserReports;
    this.userDownloadService = download_service.downloadUserReport;

    this.provider = String(this.router.snapshot.paramMap.get("participant"));
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
    if (this.user.Role === Role.Sponsor)
      this.ColumnList = [
        { Property: "FirstName", Header: "First Name", SortProperty: "fname" },
        { Property: "LastName", Header: "Last Name", SortProperty: "lname" },
        { Property: "SSN", Header: "SSN", SortProperty: "ssn" },
        { Property: "Email", Header: "Email", SortProperty: "email" },
        { Property: "StatusName", Header: "Status", SortProperty: "statusName" }];
  }

  ngOnInit(): void {
    this.getStatusCode();
  }

  resetUserReports(table: TableComponent, planDropdown: PlanDropDownComponent) {
    this.initialLoad = true;
    table.ResetTable();
    this.userForm.reset();
    planDropdown.clearPlanText();
    this.userForm.setValue({
      statusCode: '',
      planName: '',
      lastName: ''
    });
  }

  getStatusCode() {
    this.report_service.getStatusCode(true, false, false).toPromise().then(resp => {
      this.statusCode = resp;
    }, error => {
      this.errorStatus = true;
    })
  }

  getUserReports(table: TableComponent) {
    this.userObject = user_repot;
    this.userObject.StatusCode = this.userForm.value.statusCode;
    if (this.user.Role !== Role.Sponsor)
      this.userObject.PlanNumber = this.userForm.value.planName;
    this.userObject.LastName = this.userForm.value.lastName;
    this.userObject.ProvID = this.security_service.getClients();
    this.userObject.ProviderID = this.user.ProviderID;
    this.userObject.SortField = 'lname'
    this.userObject.ISID = this.user.Role === Role.Sponsor ? this.user.userid : 0;
    table.InitLoadData(this.userObject);
  }

  handleTableError(event) {
    this.errorStatus = true;
  }
}
