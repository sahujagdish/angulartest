import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../services/security-service/security.service';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FAQComponent implements OnInit {

  Question: any[] = []
  constructor(private service: SecurityService,private utility_service:UtilityService) { }

  ngOnInit(): void {
    this.getPromoText();
  }


  getPromoText(){
    this.utility_service.getLandingPageData(this.service.getProvider().Id,"FAQ Text").then(resp=>{
      console.log("FAQ")

      for(var ele of resp){
        if(ele.Active==true)
          this.Question.push(ele);
        
      }
    }).catch(error=>{

    })
  }

  createID(index: number) {
    return "question" + (index + 1);
  }

  scrollToElement(ele: any): void {
    let element = document.getElementById(ele);
    element!.scrollIntoView({ behavior: "smooth", block: "start", inline: "nearest" });
  }

}
