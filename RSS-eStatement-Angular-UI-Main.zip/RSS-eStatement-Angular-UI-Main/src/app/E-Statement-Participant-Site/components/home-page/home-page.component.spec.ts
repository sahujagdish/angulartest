import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomePageComponent } from './home-page.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('HomePageComponent', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomePageComponent ],
      imports:[HttpClientModule,RouterTestingModule
      ]
      
    })
    .compileComponents();
  });

  beforeEach(() => {
    sessionStorage.setItem("User",'{"userid":"Admin","ProviderID":126,"ProviderName":"ABG Houston","UUID":"114EABC8-AA97-9AD9-B1465E9462AAAD3D","Role":"admin","Provider":"null"}');
    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
