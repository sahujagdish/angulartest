import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../services/security-service/security.service';
import { Links } from '../../models/Links';
import { Subject, Observable } from 'rxjs';
import { OAuthService } from 'angular-oauth2-oidc';
import { ProfileService } from '../../services/profile-service/profile.service';
import { HelpScreen } from '../../../Help/models/HelpScreenData';
import { authConfig } from '../../../config/auth.config';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { Roles } from '../../models/ObjectHelper';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: [ './home-page.component.css']
})
export class HomePageComponent implements OnInit {

  provider!: string;
  user!: string;
  User:any;
  ToggleHelp: boolean = false;
  Links: any[] = [];
  ActiveLink: number = -1;

  userActivity: any;
  userInactive: Subject<any> = new Subject();

  
  userActivityalert: any;
  userInactivealert: Subject<any> = new Subject();

  UserState:string="start";

  SessionEndTimer = 900000;
  SessionAlertTimer = 600000;
  role:string;
  curentpageUrl:string="";
  isHomepage:boolean;
  loginSuccess:boolean = false;
  //ActiveLink:number=0;
  constructor(private CurrentPage: Router,private router: ActivatedRoute, public route: Router, private service: SecurityService,private oauthService: OAuthService,private profile_service:ProfileService) {
    this.user = atob(String(sessionStorage.getItem("Role")));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  
    if(router.snapshot.params.user==undefined){
      this.oauthService.logOut();
      this.route.navigateByUrl(this.User.Provider+"/Home");
      sessionStorage.clear();
    }

 
    this.setTimeout();
    
    //Session Timeout Alert
    this.userInactivealert.subscribe(()=>{
      this.UserState="confirm";
      if(confirm("Session will expire soon. Do you want to extend it")){
        this.UserState="resume";
        clearTimeout(this.userActivity);
        clearTimeout(this.userActivityalert);
        this.setTimeout();
      }else{
       // console.log("Cancel");
      this.UserState="resume";
      }
    })

    //Session timed out
    this.userInactive.subscribe(() => {
      this.UserState="end";
      alert("Session has expired!");
      this.logout();
      sessionStorage.removeItem("SessionActive");
    });

    if (Links.get(this.user) != undefined) {
      this.service.setUserType(this.user);
    } else {
      this.route.navigate(["/error"]);
    }
  }
  ngOnInit(): void {
    
    this.getProfile();

    this.curentpageUrl=this.CurrentPage.url.split('/')[this.CurrentPage.url.split('/').length-1];

    if(this.CurrentPage.url.split('/')[this.CurrentPage.url.split('/').length-1]=="welcome-page"){
      this.isHomepage=false;
    }else{
      this.isHomepage=true;
    }
  }

  getProfile(){
    this.profile_service.getProfiles(this.User.ProviderID,true).toPromise().then(resp=>{
      let ProfileID:number = resp[0].ProfileID;
      this.User.ProfileId = String(ProfileID);
      if(this.User.userid == ''){
        this.getUserData();
      }else{
        this.getSideLinks();
      }
      }).catch(error=>{
        this.invalidLogin("Unable to Load Profiles");
      })
  }

  getUserData(){
    let token = this.oauthService.getAccessToken();
    let tokenObject = JSON.parse(atob(token.split('.')[1]));
    let userid = tokenObject.preferred_username;
    this.role=this.User.Role;
    this.service.getUserDetails(userid,this.User.Role,this.User.ProviderID).toPromise().then(resp=>{
      let id = resp.UserId;
      if(id!="0"){
      this.User.userid = String(id);
      this.User.HideSensitivePlans = resp.HideSensitivePlans;
      this.User.IsInternalUser = resp.IsInternalUser;
      sessionStorage.setItem("User",JSON.stringify(this.User));
      this.getSideLinks();
      }else{
        this.invalidLogin("User doesnot exisit for "+this.User.Role+" role");
      }
    })
  }

  getSideLinks(){
    let role = this.User.Role;
    console.log(role);
    switch(role){
      case Roles.Adminstrator:
        this.service.getAdminLinks(this.User.ProviderID,this.User.ProfileId).toPromise().then(resp=>{
          console.log(resp);
          let links:any[] = resp;
          this.Links = links.filter(link=>link.LinkURL!="");
          //this.Links = Links.get(this.service.getUserType());
          this.service.setLinks(this.Links);
          this.getProviderSettings();
        }).catch(error=>{
          this.invalidLogin("Unable to Load Side Bar Links");
        })
          break;
      case Roles.Participant:
        this.service.getParLinks(this.User.ProviderID).toPromise().then(resp=>{
          console.log(resp);
          let links:any[] = resp;
          this.Links = links.filter(link=>link.LinkURL!="");
          this.service.setLinks(this.Links);
          //this.Links = Links.get(this.service.getUserType());
          this.getProviderSettings();
        }).catch(error=>{
          this.invalidLogin("Unable to Load Side Bar Links");
        })
          break;
      case Roles.Sponsor:
        this.service.getSponLinks(this.User.ProviderID,this.User.userid).toPromise().then(resp=>{
          console.log(resp);
          let links:any[] = resp;
          this.Links = links.filter(link=>link.LinkURL!="");
          this.service.setLinks(this.Links);
          //this.Links = Links.get(this.service.getUserType());
          this.getProviderSettings();
        }).catch(error=>{
          this.invalidLogin("Unable to Load Side Bar Links");
        })
          break;
    }
    
  }

  getProviderSettings(){
    this.profile_service.getProviderDetails(this.User.ProviderID).toPromise().then(resp=>{
      this.service.setProviderSettings(resp);
      this.loginSuccess = true;
      this.updateTimeStamp();
    }).catch(error=>{
      this.invalidLogin("Unable to Load Provider Settings");
    })
  }

  setTimeout() {
    let state = sessionStorage.getItem("SessionActive");
    if(state!=undefined && state=="true"){
      //console.log("World");
    this.userActivity = setTimeout(() => this.userInactive.next(undefined), this.SessionEndTimer);
    this.userActivityalert = setTimeout(() => this.userInactivealert.next(undefined), this.SessionAlertTimer); 
    }
  }

  invalidLogin(Message:string){
    this.loginSuccess = false;
    alert(Message);
    this.oauthService.logOut();
    sessionStorage.clear();
    this.route.navigateByUrl(this.service.getClients() + "/Home");
  }


  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  @HostListener('document:click')
  @HostListener('document:wheel')
  refreshUserStateKeys() {
    //console.log(this.UserState);
    if(this.UserState!="confirm"){
     // console.log("Hello");
    clearTimeout(this.userActivity);
    clearTimeout(this.userActivityalert);
    this.setTimeout();
    }
  }

  change(index: number) {
    this.ActiveLink = index;
  }

  toggleHelpSection() {
    HelpScreen.ToggleHelp = true;
    this.route.navigate(["../Help/Intro"], { relativeTo: this.router });
  }
  toggleHomeSection(){
    console.log(this.ToggleHelp);
      this.route.navigate([this.User!.Role+"/welcome-page"],{relativeTo:this.router});
  }

  logout() {
    this.oauthService.logOut();;
    sessionStorage.clear();
    //this.route.navigateByUrl(this.service.getClients() + "/Home");
  }

  updateTimeStamp(){
    if(this.User!=undefined){
      this.service.updateTimeStamp(this.User.userid,this.User.Role).toPromise().then(resp=>{
        
      }).catch(error=>{
        this.invalidLogin("Unable to Update Login TimeStamp");
      })
    }
  }

  onclickEv(){
    if(this.CurrentPage.url.split('/')[this.CurrentPage.url.split('/').length-1]=="welcome-page"){
      this.isHomepage=false;
    }else{
      this.isHomepage=true;
    }
  }

}
