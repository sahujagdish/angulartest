import { NgModule } from '@angular/core';
import { AccessParticipantInformationComponent } from '../access-participant-information/access-participant-information.component';
import { HomePageComponent } from './home-page.component';
import { StatementRepositoryComponent } from '../statement-repository/statement-repository.component';
import { EditParticipantComponent } from '../../modals/edit-participant/edit-participant.component';
import { ChangePasswordComponent } from '../change-password/change-password.component';
import { EnterProcessInformationComponent } from '../../modals/enter-process-information/enter-process-information.component';
import { ViewStatementsComponent } from '../view-statements/view-statements.component';
import { AuditReportComponent } from '../audit-report/audit-report.component';
import { UserReportComponent } from '../user-report/user-report.component';
import { StaffAccessComponent } from '../staff-access/staff-access.component';
import { StaffProfilesComponent } from '../staff-profiles/staff-profiles.component';
import { SummaryReportComponent } from '../summary-report/summary-report.component';
import { SiteTextComponent } from '../site-text/site-text.component';
import { OrderedSiteTextComponent } from '../ordered-site-text/ordered-site-text.component';
import { StatementPrintApprovalComponent } from '../statement-print-approval/statement-print-approval.component';
import { AddOrderedSiteTextComponent } from '../../modals/add-ordered-site-text/add-ordered-site-text.component';
import { WelcomeComponent } from '../welcome/welcome.component';
import { MyDocumentsComponent } from '../my-documents/my-documents.component';
import { ViewCommunicationComponent } from '../view-communication/view-communication.component';
import { PersonalizedInformationComponent } from '../personalized-information/personalized-information.component';
import { UnsubscribeComponent } from '../unsubscribe/unsubscribe.component';
import { UnsubscribeEDeliveryComponent } from '../unsubscribe-edelivery/unsubscribe-edelivery.component';
import { FAQComponent } from '../faq/faq.component';
import { UpdateProfileComponent } from '../update-profile/update-profile.component';
import { DisclosureComponent } from '../disclosure/disclosure.component';
import { NewsletterComponent } from '../newsletter/newsletter.component';
import { ApproveComponent } from '../../modals/approve/approve.component';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { HomePageRoute } from './home-page.routing';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HttpInterceptorService } from '../../services/Interceptors/Http-Interceptor.interceptor';
import { SponsorAccessModule } from '../sponsor-access/sponsor-access.module';
import {TableComponent} from '../../components/table/table.component';
import {PlanDropDownComponent} from '../../components/plan-drop-down/plan-drop-down.component';
@NgModule({
    declarations: [
        HomePageComponent,
        AccessParticipantInformationComponent,
        StatementRepositoryComponent,
        EditParticipantComponent,
        ChangePasswordComponent,
        EnterProcessInformationComponent,
        ViewStatementsComponent,
        AuditReportComponent,
        UserReportComponent,
        StaffAccessComponent,
        StaffProfilesComponent,
        SummaryReportComponent,
        SiteTextComponent,
        OrderedSiteTextComponent,
        StatementPrintApprovalComponent,
        AddOrderedSiteTextComponent,
        WelcomeComponent,
        MyDocumentsComponent,
        ViewCommunicationComponent,
        PersonalizedInformationComponent,
        UnsubscribeComponent,
        UnsubscribeEDeliveryComponent,
        FAQComponent,
        UpdateProfileComponent, 
        DisclosureComponent, 
        NewsletterComponent, 
        ApproveComponent,
        TableComponent,
        PlanDropDownComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        HomePageRoute,
        MatIconModule,
        MatExpansionModule,
        MatSlideToggleModule,
        MatCheckboxModule,
        MatDialogModule,
        RouterModule,
        CKEditorModule,
        MatAutocompleteModule,
        MatGridListModule,
        MatProgressSpinnerModule,
        SponsorAccessModule
    ],
    exports: [
        CKEditorModule,
        RouterModule
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true },
        DatePipe
    ]
})
export class HomePageModule { }