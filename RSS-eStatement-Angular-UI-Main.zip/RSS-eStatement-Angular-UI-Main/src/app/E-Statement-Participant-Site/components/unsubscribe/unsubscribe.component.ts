import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent implements OnInit {

  unSubscribed: boolean = false;
  cancelled:boolean = false;
  provider:any;
  defaultMessage:string='Are you sure you wish to unsubscribe?';
  isLoading:boolean = false;
  user:any;
  constructor(private participant_service:ParticipantService,private security_service:SecurityService,private route:Router,private routing:ActivatedRoute) { 
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
    this.provider = security_service.getProviderSettings(); 
  }

  ngOnInit(): void {
  }

  unsubscribe() {
    let message = this.provider.UnsubscribeMsg!=''?this.provider.UnsubscribeMsg:this.defaultMessage;
    message = message.replace(/<\/?[^>]+(>|$)/g, "");
    if(confirm(message)){
      this.isLoading=true;
    this.participant_service.unsubscribe(this.user.userid,this.user.ProviderID).toPromise().then(resp=>{
      this.isLoading=false;
      this.unSubscribed = true;
    }).catch(error=>{
      this.isLoading=false;
      alert("Unable to Unsubscribe ,"+error.error.Message);
    })
  } 
  }

  cancel(){
    this.route.navigate(["../view-Statements"],{relativeTo: this.routing});
  }

}
