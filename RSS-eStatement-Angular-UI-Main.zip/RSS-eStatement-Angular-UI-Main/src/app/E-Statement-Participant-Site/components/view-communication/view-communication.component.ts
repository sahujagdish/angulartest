import { Component, OnInit } from '@angular/core';
import { Documents, statement_admin, statement_par, statement_spon, HeaderType } from '../../models/ObjectHelper';
import { Router, ActivatedRoute } from '@angular/router';
import { SecurityService } from '../../services/security-service/security.service';
import { StatementService } from '../../services/statement-service/statement.service';
import { DownloadService } from '../../services/download-service/download.service';

@Component({
  selector: 'app-view-communication',
  templateUrl: './view-communication.component.html',
  styleUrls: ['./view-communication.component.css']
})
export class ViewCommunicationComponent implements OnInit {

  Statements: any=null;
  ProviderId: string = "";
  User: any;
  PartID: string = "";
  UUID: string = "";
  constructor(private route: Router, private router: ActivatedRoute, private security_service: SecurityService, private statement_service: StatementService, private download_service: DownloadService) {
    this.ProviderId = this.security_service.getClients();
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.UUID = String(router.snapshot.queryParamMap.get("uid"));
    this.PartID = String(router.snapshot.queryParamMap.get("partid"));
  }

  ngOnInit(): void {
    this.getViewStatementData(this.User.Role);
  }

  getViewStatementData(Role: string) {
    switch (Role) {
      case "admin":
        this.getStatementDataforAdmin(this.UUID, this.PartID, this.User.Provider);
        break;
      case "par":
        this.getStatementDataforPar(this.User.userid, this.User.Provider);
        break;
      case "spon":
        this.getStatementDataforSpon(this.User.Provider, this.UUID, this.User.ISIN);
        break;
    }
  }

  getStatementDataforAdmin(UUID: string, PartID: string, Provider: string) {
    let statementObject = statement_admin;
    statementObject.UID = UUID;
    statementObject.VirtualDir = Provider;
    this.statement_service.getStatementsDataAdmin(statementObject).toPromise().then(resp => {
      this.Statements = resp;
    }).catch(error => {
      throw new Error(error.error.message);
    })
  }
  getStatementDataforPar(PartID: string, Provider: string) {
    let statementObject = statement_par;
    statementObject.ParticipantId = Number(PartID);
    statementObject.VirtualDir = Provider;
    this.statement_service.getStatementsDataPar(statementObject).toPromise().then(resp => {
      if(resp.Header==HeaderType.Communication){
        this.Statements = resp;
        }else{
          this.Statements.BlockList=[];
        }
    }).catch(error => {
      throw new Error(error.error.message);
    })
  }
  getStatementDataforSpon(ProviderID: string, UID: string, SpadID: string) {
    let statementObject = statement_spon;
    statementObject.ProviderId = Number(ProviderID);
    statementObject.UID = UID;
    statementObject.SpadId = Number(SpadID);
    this.statement_service.getStatementsDataSpon(statementObject).toPromise().then(resp => {
      
    }).catch(error => {
    })
  }
  getStatement(downloadQuery: string,fileName:string) {
    if (downloadQuery != "") {
      this.download_service.downloadViewStatementPDF(downloadQuery).toPromise().then(resp => {
        this.exportToFile(fileName,resp); 

      }).catch(error => {

      })
    } else {
      alert("No Statement File Available");
    }
  }


  back() {
    this.route.navigate(["../../access-participant-info"], { relativeTo: this.router });
  }

  exportToFile(filename: string,csvContent: any) {

    const blob = new Blob([csvContent], { type: csvContent.type });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }


}
