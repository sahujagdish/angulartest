import { Component, OnInit } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { UtilityService } from '../../services/utility-service/utility.service';
import { StatementService } from '../../services/statement-service/statement.service';
import { planlist, planeNotification, eNotification, saveTextObject } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-site-text',
  templateUrl: './site-text.component.html',
  styleUrls: ['./site-text.component.css']
})
export class SiteTextComponent implements OnInit {

  public editor = ClassicEditor;
  editorText: string = "";
  utilityHeader: string = "";
  notificationType: string = "default";

  eNotificationData: any = null;
  planDetails: any = [];

  planENotification: FormGroup = new FormGroup({
    planid: new FormControl('', [Validators.required]),
    FromAddress: new FormControl('', [Validators.required, Validators.email]),
    FromName: new FormControl('', [Validators.required])
  })

  user: any;
  siteTextUtilities: any[] = [];
  siteTextUtilitiesType: string[] = [];

  successfull: boolean = false;
  onSuccessText: string = "";
  error: boolean = false;
  onErrorText: string = "";

  unSubscribeEmailSubject: string = "Hello";
  constructor(private service: UtilityService, private statement_service: StatementService, private participantService: ParticipantService) {
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getSiteTextData();
    this.planENotification.get("planid")!.valueChanges.subscribe(value=>{
      if(value!=""){
        this.getENotificationData();
      }
    })
    //this.getENotificationData();
  }

  getENotificationData() {
    let planid = String(this.planENotification.get("planid")!.value).replace(String(this.user.Provider).toUpperCase(), "");
    let externalPlanId = this.notificationType == 'default' ? "default" : planid;
    this.statement_service.getENotificationData(this.user.ProviderID, externalPlanId).subscribe(resp => {
      if (resp[0].Success) {
        this.eNotificationData = resp;
        this.editorText = this.eNotificationData[0].Data.value;
        if (this.notificationType == 'plan') {
          this.planENotification.patchValue({
            FromAddress: this.eNotificationData[1].Data.value,
            FromName: this.eNotificationData[2].Data.value
          });
        }
      }
    }, error => {
      this.error = true;
      this.onSuccessText = "An Error Occuered while Loading " + this.utilityHeader;
    })

  }

  PlanSelected() {
    //this.getENotificationData();
  }

  getPlans() {
    let plan_list = planlist;
    plan_list.ProviderID = this.user.ProviderID;
    plan_list.AdminID = this.user.userid;
    this.participantService.getPlanList(plan_list, "").subscribe(resp => {
      this.planDetails = resp;
      
      //this.getENotificationData();
    }, error => {
      this.error = true;
      this.onSuccessText = "An Error Occuered while Loading Plans";
    })
  }

  reseteNotification() {
    this.getENotificationData();

  }
  resetUnsubscribe() {
    this.setOtherPage();
  }
  resetUnsubscribeEmail() {
    this.setUnSubscribeEmail();
  }

  //          Getting links at first time we click on Site text
  getSiteTextData() {
    this.service.getSiteTextUtilities(this.user.ProviderID, this.user.ProfileId).then(resp => {
      this.siteTextUtilities = resp;

      let utilities: Set<string> = new Set<string>();
      this.siteTextUtilities.forEach(data => {
        utilities.add(data.Label);
      })


      this.siteTextUtilitiesType = Array.from(utilities);

    }).catch(error => {
      this.error = true;
      this.onSuccessText = "An Error Occuered while Loading " + this.utilityHeader;
    });
  }

  UtilitySelected(event: any) {
    this.editorText = "";
    this.utilityHeader = event.target.value;
    if (this.utilityHeader == "eNotification") {
      this.getENotificationData();
    } else
      if (this.utilityHeader == "Unsubscribe Email") {
        this.setUnSubscribeEmail();
      } else {
        this.setOtherPage();
      }
  }

  setUnSubscribeEmail() {
    this.siteTextUtilities.forEach(ele => {

      if (ele.Label == "Unsubscribe Email" && ele.Name == "subject") {
        this.unSubscribeEmailSubject = ele.Value;
      }
      if (ele.Label == "Unsubscribe Email" && ele.Name == "content") {
        this.editorText = ele.Value;
      }
    })
  }

  setOtherPage() {
    this.siteTextUtilities.forEach(ele => {
      if (ele.Label == this.utilityHeader && ele.Name == "content") {
        this.editorText = ele.Value;
      }
    })
  }

  NotificationTypeSelected(event: any) {
    this.notificationType = event.target.value;
    if (event.target.value == 'plan' ){
        this.getPlans(); 
    }
    else{
      this.planENotification.reset();

    this.getENotificationData();

    }

  }


  save(type: string) {
    let planObject = saveTextObject;

    if (type == "Unsubscribe Email") {
      if (this.unSubscribeEmailSubject != '') {
        planObject.ProviderId = this.user.ProviderID;
        planObject.Type = this.utilityHeader;
        planObject.Text = this.editorText;
        planObject.Subject = this.unSubscribeEmailSubject;

        this.service.saveText(planObject).then(resp => {
          this.successfull = true;
          this.onSuccessText = this.utilityHeader + " Updated Successfully"
        }).catch(error => {
          this.error = true;
          this.onSuccessText = "An Error Occuered while Updating " + this.utilityHeader;
        })
      }

    } else {
      planObject.ProviderId = this.user.ProviderID;
      planObject.Type = this.utilityHeader;
      planObject.Text = this.editorText;
      this.service.saveText(planObject).then(resp => {
        this.successfull = true;
        this.onSuccessText = this.utilityHeader + " Updated Successfully"
      }).catch(error => {
        this.error = true;
        this.onSuccessText = "An Error Occuered while Updating " + this.utilityHeader;
      })
    }


  }


  saveData() {    //for eNotification only
    //alert(this.notificationType)
    /*
    if(this.planENotification.valid){
      alert("valid");
    }else{
      if(this.planENotification.value.planid){
        alert("invalid");

        alert(this.planENotification.value.planid)
      }
    }
    return;
    */
    if (this.notificationType == "plan") {
      if (this.planENotification.valid) {
        let planObject = planeNotification;
        planObject.utilityType = this.eNotificationData.fieldLabel;
        planObject.fromaddress = this.planENotification.value.FromAddress;
        planObject.fromname = this.planENotification.value.FromName;
        planObject.emailbody = this.editorText;
        let planid = String(this.planENotification.value.planid).replace(String(this.user.Provider).toUpperCase(), "");
        this.statement_service.sendENotificationPlanData(this.user.ProviderID, planid, planObject).subscribe(resp => {
          this.successfull = true;
          this.onSuccessText = this.utilityHeader + " Updated Successfully"
        }, error => {
          this.error = true;
          this.onSuccessText = "An Error Occuered while Updating " + this.utilityHeader;
        })
      }else{
      }
    } else {
      let planObject = eNotification;
      planObject.utilityType = this.eNotificationData.fieldLabel;
      planObject.emailbody = this.editorText;
      this.statement_service.sendENotificationData(this.user.ProviderID, planObject).subscribe(resp => {
        this.successfull = true;
        this.onSuccessText = this.utilityHeader + " Updated Successfully"
      }, error => {

        this.error = true;
        this.onSuccessText = "An Error Occuered while Updating " + this.utilityHeader;
      })
    }
  }



}
