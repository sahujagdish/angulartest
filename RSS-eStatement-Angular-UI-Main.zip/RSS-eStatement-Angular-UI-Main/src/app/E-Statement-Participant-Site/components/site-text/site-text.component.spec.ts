import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteTextComponent } from './site-text.component';

describe('SiteTextComponent', () => {
  let component: SiteTextComponent;
  let fixture: ComponentFixture<SiteTextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SiteTextComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
