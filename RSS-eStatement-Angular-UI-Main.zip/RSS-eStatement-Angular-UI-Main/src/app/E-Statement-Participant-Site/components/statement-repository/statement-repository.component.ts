import { Component, OnInit } from '@angular/core';
import { downloadPDF, FileStoreType, SearchCode } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';
import { environment } from '../../../../environments/environment';
import { SearchStatementRepo } from '../../models/StatementSeach';
import { identifierModuleUrl } from '@angular/compiler';
import { Role } from '../../models/User';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-statement-repository',
  templateUrl: './statement-repository.component.html',
  styleUrls: ['./statement-repository.component.css']
})
export class StatementRepositoryComponent implements OnInit {

  statementPdf: any = [];

  searchOption: string = "";
  searchValue: string = "";

  searchStatementForm: FormGroup = undefined;

  isSearchValueTouched = false;
  User: any;
  totalCount: number = 0;
  pageSize: number = environment.pagesize;
  startIndex: number = 0;
  totalPage: number = 0;
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.pageSize;

  selectedIndex: number = -1;
  loadingStatement: boolean = false;
  sponsor: string = "";

  errorStatus: boolean = false;
  errorText: string = "";
  initialLoad: boolean = true;

  sortDirection = "ASC";
  sortType = "";

  selectedOption(index: number) {
    this.selectedIndex = index;
  }

  constructor(private service: ParticipantService, private security_service: SecurityService, private download_service: DownloadService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    if (this.User.Role == Role.Sponsor) {
      this.searchOption = SearchCode.LastName;
      this.loadSponsorDetails();
    } else {
      this.searchOption = "";
    }
  }

  resetSearch() {
    if (this.User.Role == Role.Sponsor) {
      this.searchOption = SearchCode.LastName;
      this.loadSponsorDetails();
    } else {
      this.searchOption = "";
    }
    this.searchValue = "";

    this.loadingStatement = false;
    this.statementPdf.length = 0;
    this.initialLoad = true;
  }

  loadSponsorDetails() {
    this.service.loadSponsorData(this.User.userid).toPromise().then(sponsorData => {
      this.sponsor = sponsorData;
      console.log(sponsorData);
    }).catch(error => {
      alert("Unable to Load Sponsor Name");
    })
  }

  search() {
    this.loadingStatement = true;
    var search = new SearchStatementRepo();
    if (this.searchOption == SearchCode.PlanName) {
      search.SearchRequest.PlanName = this.searchValue;
      search.SSIdentRequest.PlanName = this.searchValue;
      search.SSIdentRequest.SearchBy = "pName";
    }
    if (this.searchOption == SearchCode.PlanCode) {
      search.SearchRequest.PlanName = this.searchValue;
      search.SSIdentRequest.PlanName = this.searchValue;
      search.SSIdentRequest.SearchBy = "pCode";
    }
    if (this.searchOption == SearchCode.LastName) {
      search.SearchRequest.LName = this.searchValue;
      search.SSIdentRequest.SearchBy = "pLName";
    }

    search.SearchRequest.ProvID = this.security_service.getClients();
    search.SSIdentRequest.ProvID = search.SearchRequest.ProvID;
    search.SearchRequest.ProviderID = this.User.ProviderID;
    search.SearchRequest.SpadID = this.User.Role == Role.Sponsor ? Number(this.User.userid) : 0;
    search.SearchRequest.AdminID = this.User.Role == Role.Administrator ? this.User.userid : 0;
    search.SearchRequest.IsSponsor = this.User.Role == Role.Sponsor ? true : false;
    search.SSIdentRequest.IsSponsor = this.User.Role == Role.Sponsor ? true : false;
    search.SSIdentRequest.Start = this.startIndex;
    search.SSIdentRequest.Limit = this.pageSize;

    this.service.getStatements(search, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
      this.totalCount = Number(resp.TotalCount);
      this.statementPdf = resp.List;
      console.log(this.statementPdf);
      this.loadingStatement = false;
      if (this.initialLoad) {
        this.setupPage();
      } else {
        this.totalPage = Math.ceil(this.totalCount / this.pageSize);
      }
      this.initialLoad = false;

    }, error => {
      alert("Unable to Load Statements");
      this.loadingStatement = false;
    })

  }

  setupPage() {
    this.startIndex = 0;
    this.pageSize = environment.pagesize;
    this.endIndex = this.startIndex + this.pageSize;
    //this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);    
    this.totalPage = Math.ceil(this.totalCount / this.pageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;
  }




  downloadPDF() {
    let fileName = this.statementPdf[this.selectedIndex].PartialFileName;
    this.download_service.downloadStatementPDF(fileName, FileStoreType.IndividualPDF_Path).toPromise().then(resp => {
      this.exportToFile(fileName, resp);
    }).catch(error => {
      alert("Unable to download PDF");
    })
  }

  exportToFile(filename: string, csvContent: any) {

    const blob = new Blob([csvContent], { type: csvContent.type });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      //debugger;
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      //this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);
      this.currentPage++;
      this.search();
    }
  }



  FirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = 1;
      this.search();
    }
  }
  previousPage() {
    if (this.currentPage > 1) {
      //debugger;
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      //this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);
      this.currentPage--;
      this.search();
    }
  }

  LastPage() {
    // debugger;
    if (this.currentPage < this.totalPage) {
      this.startIndex = ((this.totalPage * this.pageSize) - this.pageSize);
      this.endIndex = (this.totalPage * this.pageSize);

      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = this.totalPage;
      this.search();
    }
  }

  sortParticipant(PropertyName: string) {
    this.sortType = PropertyName;
    if (this.sortDirection == "ASC") {
      this.sortDirection = "DES";
    } else {
      this.sortDirection = "ASC";
    }
    switch (PropertyName) {
      case 'Statement Files':
        if (this.sortDirection == "ASC") {
          this.statementPdf.sort((a, b) => (a.FileName < b.FileName ? -1 : 1));
        } else {
          this.statementPdf.sort((a, b) => (a.FileName > b.FileName ? -1 : 1));
        }
        break;
      case 'Date Submitted':
        if (this.sortDirection == "ASC") {
          this.statementPdf.sort((a, b) => (a.DateSubmitted < b.DateSubmitted ? -1 : 1));
        } else {
          this.statementPdf.sort((a, b) => (a.DateSubmitted > b.DateSubmitted ? -1 : 1));
        }
        break;
    }
  }



}
