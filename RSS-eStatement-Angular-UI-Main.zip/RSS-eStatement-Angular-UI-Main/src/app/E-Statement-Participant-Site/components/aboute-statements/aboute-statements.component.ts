import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../services/security-service/security.service';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-aboute-statements',
  templateUrl: './aboute-statements.component.html',
  styleUrls: ['./aboute-statements.component.css']
})
export class AbouteStatementsComponent implements OnInit {

  StatementText:any[]=[];

  constructor(private service: SecurityService,private utility_service:UtilityService) { }

  ngOnInit(): void {
    this.getPromoText();
  }


  getPromoText(){
    this.utility_service.getLandingPageData(this.service.getProvider().Id,"About eStatements Text").then(resp=>{
       for(var ele of resp){
         if(ele.Active==true)
            this.StatementText.push(ele);
       }
    }).catch(error=>{

    })
  }
}
