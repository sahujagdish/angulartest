import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { SummaryService } from '../../services/summary-service/summary.service';
import { downloadPDF, FileStoreType, Roles } from '../../models/ObjectHelper';
import { environment } from '../../../../environments/environment';
import { DownloadService } from '../../services/download-service/download.service';
import { SecurityService } from '../../services/security-service/security.service';

interface summaryReport {
  sponsorID: number, //SPON_ID
  sponsorName: string, //SPON_Name
  sponsorCode: string, //SPON_Num
  planCode: string,//PLAN_plan_num
  status: boolean,//SPON_Active
}
@Component({
  selector: 'app-summary-report',
  templateUrl: './summary-report.component.html',
  styleUrls: ['./summary-report.component.css']
})
export class SummaryReportComponent implements OnInit {

  summaryReport: any[] = [];
  sponsorSummaryReport: any[] = [];
  filteredSummaryReport: any[] = [];
  role: string = 'sponsor';

  pageSize: number = environment.pagesize;

  startIndex: number = 0;
  totalPage: number = Math.ceil(this.summaryReport.length / this.pageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.pageSize;
  selectedIndex: number = -1;


  sortDirection = "ASC";
  sortType: string = "";
  selectedReportIndex: number = -1;


  provider!: string;
  user: any;

  statementPdf: any = [];
  initialLoad: boolean = true;
  loadingSummaryReport: boolean = false;
  reloadObject: any;
  isRelodable: boolean = false;
  reports:any=[];
  partialFileName:string='';
  searchSponsorForm = new FormGroup({
    planCode: new FormControl(''),
    sponsorName: new FormControl(''),
    sponsorCode: new FormControl(''),
    sponsorActive: new FormControl(''),
  });
  constructor(public route: Router, public router: ActivatedRoute, private summary_service: SummaryService,private download_service:DownloadService) {
    this.provider = String(this.router.snapshot.paramMap.get("participant"));
  }

  ngOnInit(): void {
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
    this.role = this.user.Role;
    if(this.role==Roles.Sponsor)
      this.getSummaryData();
  }

  getSummaryData() {

    this.loadingSummaryReport = true;
    if (this.role == Roles.Adminstrator) {
      const dataToSend = {
        providerID: this.user.ProviderID,
        sponsorID: 0,
        planCode: "",
        sponsorName: "",
        sponsorCode: "",
        sponsorActive: "",
        start: 0,
        limit: 20,
        psortField: "sponsorName",
        sortDir: "ASC",
        phideSensitivePlans: false,
      }
      this.summaryReport = [];
      this.summary_service.getSponsorSearch(dataToSend).then(res => {
        this.initialLoad = false;
        this.loadingSummaryReport = false;
        this.summaryReport = res;
        this.filteredSummaryReport = this.summaryReport.slice(this.startIndex, this.endIndex);
        this.totalPage = Math.ceil(this.summaryReport.length / this.pageSize);
        this.currentPage = this.totalPage > 0 ? 1 : 0;
        this.loadingSummaryReport = false;

      })
    } else {
        this.summary_service.getSponsorNewSummaryReport(this.user.ProviderID, this.user.userid).then(res => {
        console.log(res);
        this.initialLoad = false;
        this.sponsorSummaryReport = res;
        console.clear()
        console.log(res)
        this.loadingSummaryReport = false;
      })
    }
  }

  selectedOption(index: number, spon_id: number) {
    this.partialFileName='';
    this.selectedIndex = index;
    this.selectedReportIndex = -1;
    var dataToSend = {
      ProviderID: this.user.ProviderID,
      SponsorID: spon_id,
      Start: 0,
      Limit: this.pageSize,
    }
    this.summary_service.getSummaryReport(dataToSend).then(res => {
      dataToSend.Limit=Number(res.TotalCount);
      this.recall(dataToSend);
    });
    
  }

  recall(dataToSend:any){
    this.summary_service.getSummaryReport(dataToSend).then(res => {
      console.log(res);
      this.reports=res.List;
    });
  }

  downloadSummaryReport() {
    let downloadPDFObject = downloadPDF;
    downloadPDFObject.FileName = this.statementPdf[this.selectedIndex].FILE_NAME;
    downloadPDFObject.Date = this.statementPdf[this.selectedIndex].DATESUBMITTED;
    downloadPDFObject.ProviderId = 63;
    this.summary_service.downloadSummaryReport(downloadPDFObject).toPromise().then(resp => {
      var blob = new Blob([resp], { type: "application/pdf" });
      var link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = downloadPDFObject.FileName + ".pdf";
      link.click();
    }).catch(error => {

    })
  }

  resetSearch() {
    this.startIndex = 0;
    this.initialLoad = true;
    this.loadingSummaryReport = false;
    this.filteredSummaryReport.length = 0;
    this.searchSponsorForm.setValue({
      planCode: '',
      sponsorName: '',
      sponsorCode: '',
      sponsorActive: ''
    });
  }


  

  
  summaryReportNextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      console.log("end" + this.endIndex);
      console.log("start" + this.startIndex);
      console.log("pagesize" + this.pageSize);
      this.currentPage++;
      this.reSearchSponsor();
    }
  }



  summaryReportPreviousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      this.currentPage--;
      this.reSearchSponsor();
    }

  }

  summaryReportFirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      this.currentPage = 1;
      this.reSearchSponsor();
    }

  }

  summaryReportLastPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = ((this.totalPage * this.pageSize) - this.pageSize);
      this.endIndex = (this.totalPage * this.pageSize);

      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = this.totalPage;
      this.currentPage = this.totalPage;
      this.reSearchSponsor();
    }

  }



  sort(propertyName: string) {
    this.sortType = propertyName;
    if (this.sortDirection == "ASC") {
      this.sortDirection = "DES";
      switch (propertyName) {
        case 'PCode':
          this.filteredSummaryReport.sort((a, b) => (a.plan_plan_num < b.plan_plan_num ? -1 : 1));
          break;
        case 'SPName':
          this.filteredSummaryReport.sort((a, b) => (a.spon_name < b.spon_name ? -1 : 1));
          break;
        case 'Status':
          this.filteredSummaryReport.sort((a, b) => (a.spon_active < b.spon_active ? -1 : 1));
          break;
        case 'SPCode':
          this.filteredSummaryReport.sort((a, b) => (a.spon_num < b.spon_num ? -1 : 1));
          break;
      }
    } else {
      this.sortDirection = "ASC";
      switch (propertyName) {
        case 'PCode':
          this.filteredSummaryReport.sort((a, b) => (a.plan_plan_num > b.plan_plan_num ? -1 : 1));
          break;
        case 'SPName':
          this.filteredSummaryReport.sort((a, b) => (a.spon_name > b.spon_name ? -1 : 1));
          break;
        case 'Status':
          this.filteredSummaryReport.sort((a, b) => (a.spon_active > b.spon_active ? -1 : 1));
          break;
        case 'SPCode':
          this.filteredSummaryReport.sort((a, b) => (a.spon_num > b.spon_num ? -1 : 1));
          break;
      }
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      console.log("end" + this.endIndex);
      console.log("start" + this.startIndex);
      console.log("pagesize" + this.pageSize);
      this.currentPage++;
      this.reSearchSponsor();
    }
  }



  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      this.currentPage--;
      this.reSearchSponsor();
    }

  }

  FirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      this.currentPage = 1;
      this.reSearchSponsor();
    }

  }

  LastPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = ((this.totalPage * this.pageSize) - this.pageSize);
      this.endIndex = (this.totalPage * this.pageSize);

      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = this.totalPage;
      this.currentPage = this.totalPage;
      this.reSearchSponsor();
    }

  }
  sponsorSearch() {
    this.initialLoad = true;
    this.loadingSummaryReport=true
    const dataToSend = {
      ProviderID: this.user.ProviderID,
      sponsorID: 0,
      PlanCode: this.searchSponsorForm.value.planCode,
      SponsorName: this.searchSponsorForm.value.sponsorName,
      SponsorCode: this.searchSponsorForm.value.sponsorCode,
      SponsorActive: this.searchSponsorForm.value.sponsorActive,
      Start: this.startIndex,
      Limit: this.pageSize,
      SortField: "sponsorName",
      SortDir: "ASC",
      HideSensitivePlans: false,
    }
    this.isRelodable = false;
    this.reloadObject = dataToSend;
    this.summaryReport = [];
    this.summary_service.getSponsorSearch(dataToSend).then(res => {
      this.initialLoad = false;
      this.totalPage = Math.ceil(res.TotalCount / this.pageSize);
      if (res.TotalCount > 0)
        this.currentPage = 1;
      this.summaryReport = res.List;
      console.clear()
      console.log(this.summaryReport)
      this.filteredSummaryReport = res.List;
      this.setupPage();
      if (Number(res.TotalCount) == 0)
        this.currentPage = 0;
      this.isRelodable = true;
      this.initialLoad = false;
      this.loadingSummaryReport=false;
    }, (error: any) => {
      console.log(error)
      this.loadingSummaryReport=false;

    })

  }
  reloadSearchSponsor() { // on Reload button Upper
    if (this.isRelodable) {
      this.loadingSummaryReport=true;
      this.initialLoad = true;
      this.isRelodable = false;
    this.summaryReport = [];
    this.summary_service.getSponsorSearch(this.reloadObject).then(res => {
      this.summaryReport = res.List;
      this.totalPage = Math.ceil(res.TotalCount / this.pageSize);
      this.filteredSummaryReport = res.List;
      this.isRelodable = true;
      this.initialLoad = false;
      this.loadingSummaryReport=false;

      }, (error: any) => {
        console.log(error)
        this.loadingSummaryReport=false;
  
      });

    }
  }

  reSearchSponsor() {
    this.loadingSummaryReport=true;

    this.initialLoad = true;
    this.isRelodable = false;
    let search= this.reloadObject;
    search.Start = this.startIndex;
      search.Limit = this.pageSize;
    this.summaryReport = [];
    this.summary_service.getSponsorSearch(search).then(res => {
      this.summaryReport = res.List;
      this.filteredSummaryReport = res.List;
      if (Number(res.TotalCount)== 0)
          this.currentPage = 0;
      this.isRelodable = true;
      this.initialLoad = false;
      this.loadingSummaryReport=false;

    }, (error: any) => {
      console.log(error)
      this.loadingSummaryReport=false;

    })
  }

  setupPage() {
    this.startIndex = 0;
    this.pageSize = environment.pagesize;
    this.endIndex = this.startIndex + this.pageSize;

  }
  download(){
    let fileName = this.partialFileName;
    this.download_service.downloadStatementPDF(this.partialFileName,FileStoreType.SummaryReportPath).toPromise().then(resp => {
      this.exportToFile(fileName, resp);
    })
  }
  downloadFile(partialFileName:string){
    this.download_service.downloadStatementPDF(partialFileName,FileStoreType.SummaryReportPath).toPromise().then(resp => {
      this.exportToFile(partialFileName, resp);
    })
  }
  clickedReport(partialFileName:string,index:number){
    this.selectedReportIndex = index;
    this.partialFileName=partialFileName;
  }
  

  exportToFile(filename: string,csvContent: any) {

    const blob = new Blob([csvContent], { type: csvContent.type });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

}
