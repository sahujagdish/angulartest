import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SecurityService } from '../../services/security-service/security.service';
import { StatementService } from '../../services/statement-service/statement.service';
import { statement_admin, statement_par, statement_spon, HeaderType, Roles } from '../../models/ObjectHelper';
import { DownloadService } from '../../services/download-service/download.service';

@Component({
  selector: 'app-view-statements',
  templateUrl: './view-statements.component.html',
  styleUrls: ['./view-statements.component.css']
})
export class ViewStatementsComponent implements OnInit {

  statements: any = null;
  providerId: string = "";
  user: any;
  partID: string = "";
  uid: string = "";
  error: boolean = false;
  isLoading: boolean = true;
  @Input() back: Function = () => { };
  constructor(private route: Router, private router: ActivatedRoute, private security_service: SecurityService,
    private statement_service: StatementService, private download_service: DownloadService) {
    this.providerId = this.security_service.getClients();
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
    this.uid = String(router.snapshot.queryParamMap.get("uid"));
    this.partID = String(router.snapshot.queryParamMap.get("partid"));
  }

  ngOnInit(): void {
    if(this.user.Role == Roles.Participant){

      this.getViewStatementData(this.user.Role);

    }
  }

  getViewStatementData(Role: string) {
    
      switch (Role) {
        case Roles.Adminstrator:
          
          this.getStatementDataforAdmin(this.uid, this.partID, this.user.Provider);
          break;
        case Roles.Participant:
          
          this.getStatementDataforPar(this.user.userid, this.user.Provider);
          break;
        case Roles.Sponsor:
          
          this.getStatementDataforSpon(this.user.ProviderID, this.uid, this.user.userid);
          break;
      }
  }

  getStatementDataforAdmin(uid: string, partID: string, provider: string) {
    let statementObject = statement_admin;
    statementObject.UID = uid;
    statementObject.VirtualDir = provider;
    this.statement_service.getStatementsDataAdmin(statementObject).toPromise().then(resp => {
      this.statements = resp;
      this.isLoading = false;
    }).catch(error => {
      this.isLoading = false;
      alert("Unable to Load Statements , " + error.error.message);
    })
  }
  getStatementDataforPar(partID: string, provider: string) {
    let statementObject = statement_par;
    statementObject.ParticipantId = Number(partID);
    statementObject.VirtualDir = provider;
    this.statement_service.getStatementsDataPar(statementObject).toPromise().then(resp => {
      if (resp.LinkTitle === HeaderType.Statements) {
        this.statements = resp;
      } else {
        this.statements.BlockList = [];
      }
      this.isLoading = false;
    }).catch(error => {
      this.isLoading = false;
      alert("Unable to Load Statements , " + error.error.message);
    })
  }
  getStatementDataforSpon(providerID: string, uid: string, spadID: string) {
    let statementObject = statement_spon;
    statementObject.ProviderId = Number(providerID);
    statementObject.UID = uid;
    statementObject.SpadId = Number(spadID);
    this.statement_service.getStatementsDataSpon(statementObject).toPromise().then(resp => {
      this.isLoading = false;
      this.statements = resp;
    }).catch(error => {
      this.isLoading = false;
      alert("Unable to Load Statements , " + error.error.message);
    })
  }

  getStatement(downloadQuery: string, fileName: string) {
    if (downloadQuery != "") {
      this.isLoading = true;
      this.download_service.downloadViewStatementPDF(downloadQuery).toPromise().then(resp => {
        this.isLoading = false;
        this.exportToFile(fileName, resp);
      }).catch(error => {
        this.isLoading = false;
        alert("Unable to Download PDF , " + error.error.message);
      })
    } else {
      alert("No Statement File Available");
    }
  }


  exportToFile(filename: string, csvContent: any) {

    const blob = new Blob([csvContent], { type: csvContent.type });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }
}
