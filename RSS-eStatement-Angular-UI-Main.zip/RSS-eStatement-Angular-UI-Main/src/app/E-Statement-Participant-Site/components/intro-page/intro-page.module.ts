import { NgModule } from '@angular/core';
import { IntroPageComponent } from './intro-page.component';
import { AboutComponent } from '../about/about.component';
import { AbouteStatementsComponent } from '../aboute-statements/aboute-statements.component';
import { AbouteCommunicationsComponent } from '../aboute-communications/aboute-communications.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginRoute } from './intro-page.routing';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { HomePageModule } from '../home-page/home-page.module';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HttpInterceptorService } from '../../services/Interceptors/Http-Interceptor.interceptor';

@NgModule({
    declarations: [
        IntroPageComponent,
        AboutComponent, 
        AbouteStatementsComponent, 
        AbouteCommunicationsComponent ],
    imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule,
      HttpClientModule,
      LoginRoute,
      MatIconModule,
      MatExpansionModule,
      MatSlideToggleModule,
      MatCheckboxModule,
      MatDialogModule ,
      RouterModule,
      CKEditorModule,
      MatAutocompleteModule,
      MatGridListModule,
      MatProgressSpinnerModule,
      HomePageModule
    ],
    exports:[
      CKEditorModule,
      RouterModule
    ],
    providers: [ 
      { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService,multi:true},
    ]
  })
  export class LoginModule { }