import { Routes, RouterModule } from '@angular/router';
import { IntroPageComponent } from './intro-page.component';
import { AboutComponent } from '../about/about.component';
import { AbouteStatementsComponent } from '../aboute-statements/aboute-statements.component';
import { AbouteCommunicationsComponent } from '../aboute-communications/aboute-communications.component';
import { FAQComponent } from '../faq/faq.component';
import { NgModule } from '@angular/core';
import { NewsletterComponent } from '../newsletter/newsletter.component';

const routes: Routes = [
    {path:'',component:IntroPageComponent,children:[
            {path:'',component:AboutComponent},
            {path:'About-eStatements',component:AbouteStatementsComponent},
            {path:'About-eCommunications',component:AbouteCommunicationsComponent},
            {path:'faq',component:FAQComponent},
            {path:'newsletter',component:NewsletterComponent},
    ]}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginRoute { }
