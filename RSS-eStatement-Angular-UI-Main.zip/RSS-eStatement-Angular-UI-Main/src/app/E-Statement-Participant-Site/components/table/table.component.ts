import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

enum RequestStatus {
  Idel = 1,
  Loading,
  Done,
  Error,
}
enum SortOrder {
  Asc = 1,
  Des
}
export interface IColumnInfo { Property: string, Header: string, SortProperty: string }

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  @Input() ColumnList: Array<IColumnInfo>;
  @Input() PageSize: number = 6;

  @Input() onDataBinding = (data: Array<any>) => data;
  @Input() DataService: any;
  @Input() DownloadService: any;
  @Input() DownloadButtonLabel: string;

  @Output() onDataLoaded = new EventEmitter<Array<any>>();
  @Output() onSelectedIndexChange = new EventEmitter<Array<number>>();
  @Output() onSelectedItemChange = new EventEmitter<Array<any>>();
  @Output() onError = new EventEmitter<string>();

  RequestData: any;

  startIndex: number = 0;
  endIndex: number = this.startIndex + this.PageSize;
  totalDataCount: number;
  totalPage: number;
  currentPage: number = 0;
  selectedIndex: Array<number> = [];
  selectedItem: Array<number> = [];

  Status: RequestStatus;
  SortDirection: SortOrder;
  SortProperty: string = "";

  DataSet: any[] = [];
  FilteredData: any[] = [];

  SortOrder = SortOrder;
  RequestStatus = RequestStatus;

  constructor() { }

  ngOnInit(): void {
    this.ResetTable();
  }

  ResetTable() {
    this.Status = RequestStatus.Idel;
    this.startIndex = 0;
    this.endIndex = this.startIndex + this.PageSize;
    this.totalPage = Math.ceil(this.DataSet.length / this.PageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;
    this.FilteredData = []
    this.DataSet = [];
    this.ResetSelected();
  }

  ResetSelected() {
    this.selectedIndex = [];
    this.selectedItem = [];
  }

  NextPage() {
    if (this.currentPage < this.totalPage && this.Status !== RequestStatus.Loading) {
      this.ResetSelected();
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.currentPage++;
      const datalist = this.DataSet.slice(this.startIndex, this.startIndex + this.PageSize);
      if (datalist.indexOf(null) >= 0)
        this.LoadData();
      else
        this.FilteredData = datalist
    }
  }

  PreviousPage() {
    if (this.currentPage > 1 && this.Status !== RequestStatus.Loading) {
      this.ResetSelected();
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.currentPage--;
      const datalist = this.DataSet.slice(this.startIndex, this.startIndex + this.PageSize);
      if (datalist.indexOf(null) >= 0)
        this.LoadData();
      else
        this.FilteredData = datalist
    }
  }

  FirstPage() {
    if (this.currentPage > 1 && this.Status !== RequestStatus.Loading) {
      this.ResetSelected();
      this.startIndex = 0
      this.endIndex = this.startIndex + this.PageSize;
      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = 1;
      const datalist = this.DataSet.slice(this.startIndex, this.startIndex + this.PageSize);
      if (datalist.indexOf(null) >= 0)
        this.LoadData();
      else
        this.FilteredData = datalist
    }
  }

  LastPage() {
    if (this.currentPage < this.totalPage && this.Status !== RequestStatus.Loading) {
      this.ResetSelected();
      this.endIndex = (this.DataSet.length);
      this.startIndex = (this.PageSize * (this.totalPage - 1));
      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = this.totalPage;
      const datalist = this.DataSet.slice(this.startIndex, this.startIndex + this.PageSize);
      if (datalist.indexOf(null) >= 0)
        this.LoadData();
      else
        this.FilteredData = datalist
    }
  }

  Reload() {
    if (this.Status !== RequestStatus.Loading) {
      this.LoadData();
      this.ResetSelected();
    }
  }

  SelectedOption(event, index: number, item: any) {
    if (event.ctrlKey) {
      const i = this.selectedIndex.indexOf(index)
      if (i >= 0) {
        this.selectedIndex.splice(i, 1);
        this.selectedItem.splice(i, 1);
      }
      else {
        this.selectedIndex.push(index);
        this.selectedItem.push(item);
      }
      this.onSelectedIndexChange.emit(this.selectedIndex);
      this.onSelectedItemChange.emit(this.selectedItem);
    }
  }

  async InitLoadData(payload) {
    this.RequestData = payload;
    this.ResetTable()
    this.currentPage = 1;
    return await this.LoadData();
  }

  async LoadData() {
    this.Status = RequestStatus.Loading;
    let reqDate = { ...this.RequestData };
    reqDate.Start = this.startIndex;
    reqDate.Limit = this.PageSize * 5;
    if (this.SortDirection)
      reqDate.SortDirection = this.SortDirection == SortOrder.Asc ? "asc" : "desc";
    if (this.SortProperty)
      reqDate.SortField = this.SortProperty;

    if (this.startIndex > 0 && (this.startIndex + this.PageSize) >= this.totalDataCount) {
      reqDate.Start = this.totalDataCount - (this.PageSize * 5);
      reqDate.Limit = this.totalDataCount;
    }

    try {
      const res = await this.DataService(reqDate, String(sessionStorage.getItem("token"))).toPromise();
      this.Status = RequestStatus.Done;

      this.totalDataCount = res.TotalCount;
      this.totalPage = Math.ceil(res.TotalCount / this.PageSize);

      while (this.DataSet.length < res.TotalCount) {
        this.DataSet.push(null);
      }
      const data = this.onDataBinding(res.List);
      for (let index = 0; index < data.length; index++) {
        this.DataSet[reqDate.Start + index] = data[index];
      }

      this.FilteredData = this.DataSet.slice(this.startIndex, this.startIndex + this.PageSize);

      if (res.TotalCount == 0)
        this.currentPage = 0;

      this.onDataLoaded.emit(res.List);
    } catch (error) {
      this.Status = RequestStatus.Error;
      this.onError.emit("Error occure while loading data");
    }
  }

  sort(PropertyName: string) {
    this.ResetSelected();
    this.DataSet = [];
    this.SortProperty = PropertyName;
    if (this.SortDirection === SortOrder.Asc) {
      this.SortDirection = SortOrder.Des;
    } else {
      this.SortDirection = SortOrder.Asc;
    }
    this.LoadData();
  }

  async donwloadAsCsv() {
    try {
      let reqDate = { ...this.RequestData };
      reqDate.Start = 0;
      reqDate.Limit = this.totalDataCount;
      const resp = await this.DownloadService(reqDate).toPromise();
      let report = atob(resp.FileContents);
      this.exportToCsv((resp.FileDownloadName == "" ? "Report.csv" : resp.FileDownloadName), report);
    }
    catch (error) {
      this.onError.emit("Error occure while donwload data");
    }
  }

  exportToCsv(filename: string, csvContent: string) {

    const blob = new Blob([csvContent], { type: 'application/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }
}
