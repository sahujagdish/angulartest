import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../services/security-service/security.service';
import { Links } from '../../models/Links';
import { Message } from '../../models/WelcomeMessage';
import { OAuthService } from 'angular-oauth2-oidc';
import { CommonService } from '../../services/common.service';
import { participant, Roles } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  links: any[] = [];
  welcomeMessages: any[] = [];
  userType: string = "";
  user: any;
  lastlogintime: string;
  provider: string;
  lastLoginDate: Date;
  lastLoginSring: string;
  isAm: string;
  name: string="";
 
  constructor(private security_service: SecurityService, private oauthService: OAuthService, private commonService: CommonService, private participant_service: ParticipantService) {
    this.userType = this.security_service.getUserType();
    this.user = JSON.parse(String(sessionStorage.getItem("User")));

 

    if (this.user.LastLogin == '') {
      this.getUserData();
    } else {
      this.lastLoginDate = new Date(this.user.LastLogin)
      this.lastLoginSring = this.user.LastLogin != '' ? this.commonService.formatDateinmonthDayformat(this.lastLoginDate) : '';
      this.isAm = this.lastLoginDate.getHours() < 12 ? "AM" : "PM";
    }
    this.setName();
  }
  setName(){
    if (this.userType == Roles.Adminstrator) {
      this.provider = this.user.ProviderName;
    }else if(this.userType == Roles.Sponsor){
      this.participant_service.loadSponsorData(this.user.userid).subscribe(resp => {
        console.log("Spon");
        console.log(resp);
        this.provider = resp

      })
    }
    else{
      var edit = participant;
      edit.providerID = this.user.ProviderID;
      edit.ParticipantID = this.user.userid;
      this.participant_service.getParticipantData(edit, String(sessionStorage.getItem("token"))).subscribe(resp => {
        this.provider = resp["FName"]+" "+ resp["LName"];
      })
    }
  }

  formatDate() {

  }

  ngOnInit(): void {
    this.links = this.security_service.getLinks();
    let Messages = Message.get(this.security_service.getUserType());
    Messages.forEach((message: any) => {
      if (this.links.filter(link => link.LinkURL.includes(message.Link)).length > 0) {
        this.welcomeMessages.push(message);
      }
    });
  }

  getUserData() {
    let token = this.oauthService.getAccessToken();
    let tokenObject = JSON.parse(atob(token.split('.')[1]));
    let userid = tokenObject.preferred_username;

    this.security_service.getUserDetails(userid, this.user.Role, this.user.ProviderID).toPromise().then(resp => {
      this.user.userid = String(resp.UserId);
      this.user.LastLogin = String(resp.UserLastLogin);
      sessionStorage.setItem("User", JSON.stringify(this.user));
      this.lastLoginDate = new Date(this.user.LastLogin)
      this.lastLoginSring = this.user.LastLogin != '' ? this.commonService.formatDateinmonthDayformat(this.lastLoginDate) : '';
      this.isAm = this.lastLoginDate.getHours() < 12 ? "AM" : "PM";
      //this.provider = this.user.ProviderName;
    })
  }
}
