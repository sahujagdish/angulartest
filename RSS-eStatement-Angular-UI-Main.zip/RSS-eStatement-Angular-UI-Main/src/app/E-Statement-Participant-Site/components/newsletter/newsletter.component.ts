import { Component, OnInit } from '@angular/core';
import { Documents } from '../../models/ObjectHelper';
import { UtilityService } from '../../services/utility-service/utility.service';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-newsletter',
  templateUrl: './newsletter.component.html',
  styleUrls: ['./newsletter.component.css']
})
export class NewsletterComponent implements OnInit {


  newsLetters: any[] = []
  user:any;
  constructor(private service:UtilityService,private securityService:SecurityService) { 
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getNewsLetters();
  }

  getNewsLetters(){
    var security=this.securityService.getProviderSettings();
    this.service.getNewsletters(this.securityService.getProvider().Id).then(resp=>{
      this.newsLetters=resp;
     
      
    }).catch(error=>{

    })
  }

  openLetter(fileName:string):string{
    var security=this.securityService.getProviderSettings();
    console.clear();
    console.log(fileName)
    console.log(security.CustomNews);
    console.log(security)
    if(security.CustomNews==false){
       return security.NewsLetterPath+"news/"+fileName;
    }else{
      return security.NewsLetterPath+security.VirtualDir+"/"+fileName;
    }
  }

}
