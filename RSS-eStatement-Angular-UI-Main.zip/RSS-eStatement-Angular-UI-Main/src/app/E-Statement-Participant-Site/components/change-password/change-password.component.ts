import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import { SecurityService } from '../../services/security-service/security.service';
import { Md5 } from 'ts-md5/dist/md5';
import { changePasswordObject, Roles, SiteRole } from '../../models/ObjectHelper';
import {CustomValidations} from '../../models/CustomValidation';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  passwordControl!: FormGroup;
  passwordChangeStatus: boolean = false;
  errorMessage: string = "";
  passwordObject: any = {};

  user: any;
  constructor(private security_service: SecurityService) {
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.passwordObject=changePasswordObject;
    this.passwordObject.UUId = this.user.UUID;
    this.passwordControl = new FormGroup({
      currentPassword: new FormControl('',[Validators.required]),
      newPassword: new FormControl('', [Validators.required, Validators.minLength(8), CustomValidations.checkPasswordsCustom]),
      confirmPassword: new FormControl('',[Validators.required,CustomValidations.checkPasswordsCustom])
    }, { validators: this.checkPasswords });
  }

  checkPasswords: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
    let pass = group.get('newPassword')!.value;
    
    let confirmPass = group.get('confirmPassword')!.value;
    
    return pass === confirmPass ? null : { "notSame": true }
  }
  
  samePassword: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    let confirmPass = control!.value;
    let  pass= String(this.passwordControl.value('newPassword')!.value);
    console.clear();
    console.log(pass);
    console.log(confirmPass);
    
    var aa= pass === confirmPass ? null : { notSame: true };
    console.log(aa)
    return pass === confirmPass ? null : { "notTheSame": true }
  }
  

  changePassword() {
    if (this.passwordControl.valid) {
      this.passwordObject.Current_pass = new Md5().appendStr(this.passwordControl.value.currentPassword).end();
      this.passwordObject.New_pass = new Md5().appendStr(this.passwordControl.value.newPassword).end();
      this.passwordObject.UniqueId=this.user.userid;
      let role = "";
      switch (this.user.Role) {
        case Roles.Adminstrator:
          role = SiteRole.Admin;
          break;
        case Roles.Participant:
          role = SiteRole.Par;
          break;
        case Roles.Sponsor:
          role = SiteRole.Spon;
          break;
      }
      this.passwordObject.TargetType = role;
      this.security_service.changePassword(this.passwordObject, String(sessionStorage.getItem("token"))).then(response => {
        this.passwordChangeStatus = true;
      }).catch(error => {
        this.errorMessage = error.error;
        this.passwordChangeStatus = false;
      });
    }

  }

}
