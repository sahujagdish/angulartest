import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbouteCommunicationsComponent } from './aboute-communications.component';

describe('AbouteCommunicationsComponent', () => {
  let component: AbouteCommunicationsComponent;
  let fixture: ComponentFixture<AbouteCommunicationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbouteCommunicationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbouteCommunicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
