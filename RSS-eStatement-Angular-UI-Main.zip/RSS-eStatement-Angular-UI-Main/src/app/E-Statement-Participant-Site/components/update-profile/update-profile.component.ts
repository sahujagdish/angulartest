import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, AbstractControl, ValidationErrors, Validators } from '@angular/forms';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { participant, profilesPart, Roles } from '../../models/ObjectHelper';
import { environment } from '../../../../environments/environment';
import { profile, newSponsorObject, sponAdminObject } from '../../models/ObjectHelper'
import { Md5 } from 'ts-md5';
import { CustomValidations } from '../../models/CustomValidation';
import { SponsorService } from '../../services/sponsor-service/sponsor.service';
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  profileForm!: FormGroup;
  profileObject: any;
  isUpdated: boolean = false;
  errorStatus: boolean = false;
  user: any;
  isReady: boolean = false;
  sponsor: any = {};

  constructor(private participant_service: ParticipantService, private sponsor_service: SponsorService) {
    this.user = JSON.parse(String(sessionStorage.getItem("User")));

  }

  ngOnInit(): void {

    if (this.user.Role == Roles.Participant) {
      var edit = participant;
      edit.providerID = this.user.ProviderID;
      edit.ParticipantID = this.user.userid;

      this.participant_service.getParticipantData(edit, String(sessionStorage.getItem("token"))).subscribe(resp => {
        this.profileObject = resp;

        this.setupProfile(this.profileObject);
      }, error => {
        this.errorStatus = true;
      })
    }
    else if (this.user.Role == Roles.Sponsor) {
      this.sponsor_service.getSponsor(this.user.userid).then(resp => {
        /*
      {
        "ControlID": 28,
        "ControlName": "Acme, Inc.",
        "Active": true,
        "Updated": false
      }
      */
        console.clear();
        console.log("GetSponsor")
        console.log(resp);

        console.log(this.sponsor = resp)
        this.sponsor_service.getSponsorAdministrators(this.sponsor.ControlID, this.sponsor.Active, this.user.ProviderID).then(resp2 => {
          this.profileObject = resp2[0];
          console.log("SponsorAdministrators")
          console.log(this.profileObject);
          this.setupProfile(this.profileObject);
          //this.getProfiles();
        }).catch(error => {
          alert("Unable to load Administrators");
        })


      }).catch(error => {
        alert("Unable to Load Sponsor Details");
      });


    }

  }


  setupProfile(profileObject: any) {

    this.isReady = false;
    if (this.user.Role == Roles.Participant) {
      this.profileForm = new FormGroup({
        fname: new FormControl(profileObject.FName == undefined ? '' : profileObject.FName, [Validators.required]),
        mi: new FormControl(profileObject.MI == undefined ? '' : profileObject.MI),
        lname: new FormControl(profileObject.LName == undefined ? '' : profileObject.LName, [Validators.required]),
        email: new FormControl(profileObject.EMail == undefined ? '' : profileObject.EMail, [Validators.required, Validators.email]),
        userid: new FormControl(profileObject.UserID == undefined ? '' : profileObject.UserID),
        password: new FormControl(profileObject.password == undefined ? '' : profileObject.password, [CustomValidations.checkPasswordsCustom]),
        confirmpass: new FormControl(profileObject.password == undefined ? '' : profileObject.password, [CustomValidations.checkPasswordsCustom]),
      }, { validators: this.checkPasswords });
    } else if (this.user.Role == Roles.Sponsor) {
      this.profileForm = new FormGroup({
        fname: new FormControl(profileObject.SpadFName == undefined ? '' : profileObject.SpadFName, [Validators.required]),
        lname: new FormControl(profileObject.ControlName == undefined ? '' : profileObject.ControlName, [Validators.required]),
        email: new FormControl(profileObject.SpadEMail == undefined ? '' : profileObject.SpadEMail, [Validators.required, Validators.email]),
        userid: new FormControl(profileObject.SpadUserID == undefined ? '' : profileObject.SpadUserID),
        password: new FormControl("Placeholder1!", [CustomValidations.checkPasswordsCustom]),
        confirmpass: new FormControl("Placeholder1!", [CustomValidations.checkPasswordsCustom]),
      }, { validators: this.checkPasswords });
    }
    this.isReady = true;
  }

  samePassword: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
    let confirmPass = control!.value;
    let pass = String(this.profileForm.value('password')!.value);
    console.clear();
    console.log(pass);
    console.log(confirmPass);

    var aa = pass === confirmPass ? null : { notSame: true };
    console.log(aa)
    return pass === confirmPass ? null : { "notTheSame": true }
  }
  checkPasswords: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
    let pass = group.get('password')!.value;
    let confirmPass = group.get('confirmpass')!.value
    return pass === confirmPass ? null : { notSame: true }
  }

  updateProfile() {



    if (this.profileForm.valid) {
      if (this.user.Role == Roles.Participant) {
        const md5 = new Md5();
        this.profileForm.value.password = md5.appendStr(String(this.profileForm.value.password)).end()
        this.participant_service.updateParticipant(this.setupProfileObject(), String(sessionStorage.getItem("token"))).toPromise().then(resp => {
          this.isUpdated = true;
          alert("Profile Updated Successfully");

        }).catch(error => {
          this.errorStatus = true;
        });
      } else if (this.user.Role == Roles.Sponsor) {   
        
        this.setupProfileObject();
        this.sponsor_service.updateSponsorAdmin(this.profileObject, this.user.ProviderID).then(resp => {
          alert("Profile Updated Successfully");
          this.isUpdated = true;

        }).catch(error => {
          alert("Unable to Update Profile , " + error.error);
        })
      }
    }
    else {
    }

  }

  setupProfileObject() {
    if (this.user.Role == Roles.Participant) {
      var profiles = profilesPart;
      var updatedprofile = this.profileForm.value;
      profiles.fname = updatedprofile.fname;
      profiles.mi = updatedprofile.mi;
      profiles.lname = updatedprofile.lname;
      profiles.email = updatedprofile.email;
      profiles.password = updatedprofile.password;
      profiles.statuscode = this.profileObject.StatusCode;

      profiles.part_id = this.user.userid;
      profiles.acctnumber = this.profileObject.AcctNumber;
      profiles.setAdmin = false;
      profiles.uuid = this.user.PartUUID;

      return profiles;
    }
    else {
      let SponsorObject = this.profileForm.value;
        this.profileObject.SpadFName=SponsorObject.fname;
        this.profileObject.ControlName=SponsorObject.lname;
        this.profileObject.SpadEMail=SponsorObject.email;
        this.profileObject.SpadPassword= new Md5().appendStr(SponsorObject.password).end();
        if (this.profileObject.ControlID != 0) {
          this.profileObject.Updated = true;
        }
      return this.profileObject;
    }
  }

  reset() {
    this.ngOnInit();
  }

}
