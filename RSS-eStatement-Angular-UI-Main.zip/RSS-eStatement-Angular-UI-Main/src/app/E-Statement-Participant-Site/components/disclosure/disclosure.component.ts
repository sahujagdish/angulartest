import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../../services/profile-service/profile.service';

@Component({
  selector: 'app-disclosure',
  templateUrl: './disclosure.component.html',
  styleUrls: ['./disclosure.component.css']
})
export class DisclosureComponent implements OnInit {
  user: any;
  userData:any
  msg:any;
  constructor(private provider:ProfileService) {
    this.user = JSON.parse(String(sessionStorage.getItem("User")))
   }

  ngOnInit(): void {
    this.provider.getProviderDetails(this.user.ProviderID).subscribe(resp => {
      this.userData = resp;
      this.msg=this.userData.AcceptMsg;
      console.log(this.msg);
    }, error => {
      
    })
  }

}
