import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../../services/security-service/security.service';

@Component({
  selector: 'app-sponsor-form',
  templateUrl: './sponsor-form.component.html',
  styleUrls: ['./sponsor-form.component.css']
})
export class SponsorFormComponent implements OnInit {

  sMode: any;
  value: string = "add"
  User: any;
  constructor() {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
  }

}
