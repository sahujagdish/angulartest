import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';import { SponsorSearchComponent } from './sponsor-search/sponsor-search.component';
import { SponsorAccessComponent } from './sponsor-access.component';
import { SponsorReportComponent } from './sponsor-report/sponsor-report.component';
import { SponsorLinksComponent } from './sponsor-links/sponsor-links.component';
import { SponsorProfileComponent } from './sponsor-profile/sponsor-profile.component';
import { SponsorAdministratorComponent } from './sponsor-administrator/sponsor-administrator.component';
import { SponsorFormComponent } from './sponsor-form/sponsor-form.component';


const routes: Routes = [
    {path:'',component:SponsorAccessComponent,children:[
        {path:'search',component:SponsorSearchComponent},
        {path:'report',component:SponsorReportComponent},
        {path:'sponsor-links',component:SponsorLinksComponent},
        {path:'sponsor-profile',component:SponsorProfileComponent},
        {path:'sponsor-admin',component:SponsorAdministratorComponent},
        {path:'sponsor-form',component:SponsorFormComponent},
        {path:'',redirectTo:'search',pathMatch:'full'}
    ]}
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SponsorAccessRoute { }
