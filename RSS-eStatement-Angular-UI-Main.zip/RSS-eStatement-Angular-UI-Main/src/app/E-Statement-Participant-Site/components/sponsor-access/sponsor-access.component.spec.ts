import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SponsorAccessComponent } from './sponsor-access.component';

describe('SponsorAccessComponent', () => {
  let component: SponsorAccessComponent;
  let fixture: ComponentFixture<SponsorAccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SponsorAccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SponsorAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
