import { Component, OnInit } from '@angular/core';
import { SponsorAccessService } from '../sponsor-service/sponsor.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SponsorReportColumns } from '../../../models/SponsorReportColumns';

@Component({
  selector: 'app-sponsor-report',
  templateUrl: './sponsor-report.component.html',
  styleUrls: ['./sponsor-report.component.css']
})
export class SponsorReportComponent implements OnInit {

  
  aColumns:any=[];
  action:string="";
  Sponsor:any=undefined;
  searchResponse:any=undefined;
  data:any[]=[];
  filteredSponsorData:any[]=[];
  pageSize: number = 10;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.data.length / this.pageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.pageSize;
  selectedIndex: number = -1;

  constructor(private route:Router,private sponsor_service:SponsorAccessService,private router:ActivatedRoute) {
    this.action = this.router.snapshot.queryParamMap.get('action');
    console.log(this.action);
  }

 

  ngOnInit(): void {
    this.searchResponse = this.sponsor_service.getSearchResults();
    this.aColumns = SponsorReportColumns.getColumns(this.searchResponse.ColumnType);
    this.data =  this.searchResponse.Data;
    if(this.data.length<=100){
      this.setupPage();
      }else{
        alert("Maximum of 100 Maximum result number has been exceeded, please try again with a more refined search");
        this.route.navigate(["../search"],{relativeTo: this.router});
      }
  }


  redirectTo(index:number){
    console.log("Redirecting...");
    if(this.action == "links"){
      this.route.navigate(["../sponsor-links"],{relativeTo: this.router,queryParams:{spon_id:btoa(this.filteredSponsorData[index].SponID)}});
    }

    if(this.action == "profiles"){
      this.route.navigate(["../sponsor-profile"],{relativeTo: this.router,queryParams:{spon_id:btoa(this.filteredSponsorData[index].SponID)}});
    }

    if(this.action == "admins"){
      this.route.navigate(["../sponsor-admin"],{relativeTo: this.router,queryParams:{spon_id:btoa(this.filteredSponsorData[index].SponID)}});
    }
  }


  setupPage() {
    this.startIndex = 0;
    this.pageSize = 10;
    this.filteredSponsorData = this.data.slice(this.startIndex, this.endIndex);
    this.totalPage = Math.ceil(this.data.length / this.pageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      console.log(this.startIndex+","+this.endIndex);
      this.filteredSponsorData = this.data.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      console.log(this.startIndex+","+this.endIndex);
      this.filteredSponsorData = this.data.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }
  }

  FirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      console.log(this.startIndex+","+this.endIndex);
      this.filteredSponsorData = this.data.slice(this.startIndex, this.endIndex);
      this.currentPage=1;
    }
  }

  LastPage() {
    if ( this.currentPage < this.totalPage) {
      this.endIndex = (this.data.length);
      this.startIndex = (this.pageSize*(this.totalPage-1));
      console.log(this.startIndex+","+this.endIndex);
      this.filteredSponsorData = this.data.slice(this.startIndex, this.endIndex);
      this.currentPage=this.totalPage;
    }
  }

  selectedOption(option: any, index: number) {
    this.selectedIndex = index;
  }



}
