import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SponsorReportComponent } from './sponsor-report.component';

describe('SponsorReportComponent', () => {
  let component: SponsorReportComponent;
  let fixture: ComponentFixture<SponsorReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SponsorReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SponsorReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
