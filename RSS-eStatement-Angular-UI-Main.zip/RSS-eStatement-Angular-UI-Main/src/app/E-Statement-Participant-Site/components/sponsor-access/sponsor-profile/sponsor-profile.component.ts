import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SponsorService } from '../../../services/sponsor-service/sponsor.service';
import { newProfile, OperationType, sponsorProfileObject, SponsorProfileOptions } from '../../../models/ObjectHelper';
import { SponsorLinkState } from '../../../models/ObjectHelper';
import { SponsorAccessService } from '../sponsor-service/sponsor.service';

@Component({
  selector: 'app-sponsor-profile',
  templateUrl: './sponsor-profile.component.html',
  styleUrls: ['./sponsor-profile.component.css']
})
export class SponsorProfileComponent implements OnInit {

  links: any[] = [];
  User: any;
  sponID: number = 0;
  sponsor: any = undefined;
  profiles: any[] = [];
  selectedProfile: any = {};
  selectedProfileName: string = "";
  profileSelectedLinks: any[] = [];
  selectedProfileLinkObject: any = undefined;
  operationState: string = SponsorLinkState.initiated;
  operationType: string = "";
  isNewProfileAdded: boolean = false;

  isLoadingLinks: boolean = true;

  constructor(private route: Router, private sponsorAccessservice: SponsorAccessService, private sponsor_service: SponsorService, private router: ActivatedRoute) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.sponID = Number(atob(this.router.snapshot.queryParamMap.get('spon_id')));
  }

  ngOnInit(): void {
    this.SetupPage()
  }

  SetupPage() {
    this.setupProfiles(this.sponID, SponsorProfileOptions.Active);
  }

  setupProfiles(sponID: number, isProfileActive: string) {
    this.sponsor_service.getProfiles(sponID, isProfileActive).then(resp => {
      this.profiles = resp;
      this.getSponsor(sponID);
    })
  }

  getSponsor(sponID: number) {
    this.sponsor_service.getSponsor(sponID).then(resp => {
      this.sponsor = resp;
      this.getLinks(sponID);
    }).catch(error => {
      alert("Unable to Load Sponsor Details");
    });
  }

  getLinks(sponID: number) {
    this.sponsor_service.getProfileAllLinks(sponID).then(resp => {
      this.links = resp;
      this.isLoadingLinks = false;
    }).catch(error => {
      alert("Unable to Load Links");
    });
  }

  getSelectedLinks(sponID: number, ProfileID: string) {
    this.sponsor_service.getProfileSelectedLinks(sponID, ProfileID).then(resp => {
      this.selectedProfileLinkObject = resp[0];
      this.profileSelectedLinks = this.selectedProfileLinkObject.SponsorLinkIDs;
      this.isLoadingLinks = false;
    });
  }

  getNewProfileObject() {
    let newProfileObject = sponsorProfileObject;
    newProfileObject.ControlName = this.selectedProfileName;
    newProfileObject.Updated = false;
    let links: any[] = [];
    this.links.forEach(link => links.push({ SpliID: link.SpliID, Active: false }));
    newProfileObject.SponsorLinkIDs = links;
    return newProfileObject;
  }

  AddNewProfile() {
    let Profile = newProfile;
    Profile.SppSponID = this.sponID;
    Profile.SppfName = "New Profile";
    this.profiles.push(Profile);
    this.selectedProfileName = Profile.SppfName;
  }

  getLink(SpliID: number) {
    if (this.profileSelectedLinks.length > 0) {
      let link = this.profileSelectedLinks.filter(value => value.SpliID == SpliID)[0];
      return link != undefined ? link.Active : false;
    } else {
      return false;
    }
  }

  updateLink(isChecked: any, SpliID: number) {

    if (this.profileSelectedLinks.length > 0) {
      let link = this.profileSelectedLinks.filter(value => value.SpliID == SpliID)[0];
      link.Active = isChecked;
    }
  }

  onProfileSelected() {
    this.isLoadingLinks = true;
    this.selectedProfile = this.profiles.filter(profile => profile.SppfName == this.selectedProfileName)[0];
    this.getSelectedLinks(this.sponID, this.selectedProfile.SppfID);
  }

  addProfile() {
    this.operationType = OperationType.Add;
    if (this.isNewProfileAdded == false) {
      this.AddNewProfile();
      this.selectedProfileLinkObject = this.getNewProfileObject();
      this.profileSelectedLinks = this.selectedProfileLinkObject.SponsorLinkIDs
      console.log(this.selectedProfileLinkObject);
      this.isNewProfileAdded = true;
    }
  }

  updateProfile() {
    this.operationType = OperationType.Update;
    if (this.selectedProfileName != "") {
      this.selectedProfileLinkObject.ControlName = this.selectedProfileName;
      this.selectedProfileLinkObject.Updated = true;
      console.log(this.selectedProfileLinkObject);
      this.sponsor_service.updateSponsorProfile(this.selectedProfileLinkObject, String(this.sponID)).then(resp => {
        this.operationState = SponsorLinkState.success;
        this.isNewProfileAdded = false;
      }).catch(error => {
        this.operationState = SponsorLinkState.failed;
      })
    }
  }

  deleteProfile() {
    if (confirm("Are you sure you want to delete the profile")) {
      this.operationType = OperationType.Delete;
      if (this.selectedProfileLinkObject.ControlID != 0) {
        this.selectedProfileLinkObject.Active = false;
        console.log(this.selectedProfileLinkObject);
        this.sponsor_service.updateSponsorProfile(this.selectedProfileLinkObject, String(this.sponID)).then(resp => {
          this.operationState = SponsorLinkState.success;
        }).catch(error => {
          this.operationState = SponsorLinkState.failed;
        })
      }
      console.log(this.selectedProfileLinkObject);
    }
  }




}
