import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SponsorLinkState } from '../../../models/ObjectHelper';
import { SponsorService } from '../../../services/sponsor-service/sponsor.service';
import { SponsorAccessService } from '../sponsor-service/sponsor.service';

@Component({
  selector: 'app-sponsor-links',
  templateUrl: './sponsor-links.component.html',
  styleUrls: ['./sponsor-links.component.css']
})
export class SponsorLinksComponent implements OnInit {

  links: any[] = [];
  User: any;
  sponID: number = 0;
  sponsor: any = undefined;
  selectedLinkObject: any = undefined;
  selectedLinks: any[] = [];
  isLoading: boolean = true;
  isSelected: boolean = true;
  updateSuccess: string = SponsorLinkState.initiated;

  constructor(private route: Router, private sponsorAccessService: SponsorAccessService, private sponsor_service: SponsorService, private router: ActivatedRoute) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.sponID = Number(atob(this.router.snapshot.queryParamMap.get('spon_id')));
    console.log(this.sponID);
  }

  ngOnInit(): void {
    this.SetupPage();
  }

  SetupPage() {
    this.setupSponsor(this.sponID);
  }

  setupSponsor(sponID: number) {
    this.sponsor_service.getSponsor(sponID).then(resp => {
      this.sponsor = resp;
      this.getLinks(this.User.ProviderID);
    }).catch(error => {
      alert("Unable to Load Sponsor Details");
      this.isLoading = false;
    });
  }

  getLinks(ProviderID: string) {
    this.sponsor_service.getAllLinks(ProviderID).then(resp => {
      this.links = resp;
      this.getSelectedLinks(this.sponID, this.User.ProviderID);
    }).catch(error => {
      alert("Unable to Load Links");
      this.isLoading = false;
    });
  }

  getSelectedLinks(sponID: number, ProviderID: string) {
    this.sponsor_service.getSponsorSelectedLinks(sponID, ProviderID).then(resp => {
      this.selectedLinkObject = resp[0];
      this.selectedLinks = this.selectedLinkObject.SponsorLinkIDs;
      this.isLoading = false;
    }).catch(error => {
      alert("Unable to Load Selected Links");
      this.isLoading = false;
    });
  }

  getLink(SpliID: number) {
    let link = this.selectedLinks.filter(value => value.SpliID == SpliID)[0];
    return link.Active;
  }

  updateLink(event: any, SpliID: number) {
    let link = this.selectedLinks.filter(value => value.SpliID == SpliID)[0];
    link.Active = event.target.checked;
  }

  UpdateLinks() {
    this.selectedLinkObject.Updated = true;
    this.sponsor_service.updateSponsorLinks(this.selectedLinkObject).then(resp => {
      this.updateSuccess = SponsorLinkState.success;
    }).catch(error => {
      this.updateSuccess = SponsorLinkState.failed;
    })
  }


}
