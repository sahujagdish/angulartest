import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SponsorAccessService {

  private SponsorForm:any={
    SearchResult:{},
    searchForm:{}
  }

  constructor() { }

  getSponsorSearchObject(){
    return  this.SponsorForm.searchForm;
  }

  setSponsorSearchObject(SearchObject:any){
    this.SponsorForm.searchForm = SearchObject;
  }

  getSponsorObject(){
    return this.SponsorForm;
  }

  setSponsorObject(Form:any){
    this.SponsorForm = Form;
  }

  setSearchResults(SearchResponse:any){
    this.SponsorForm.SearchResult = SearchResponse;
  }
  getSearchResults(){
    return this.SponsorForm.SearchResult;
  }



}
