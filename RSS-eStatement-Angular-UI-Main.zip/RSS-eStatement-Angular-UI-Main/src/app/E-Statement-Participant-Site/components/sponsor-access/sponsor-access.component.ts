import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SponsorAccessService } from './sponsor-service/sponsor.service';

@Component({
  selector: 'app-sponsor-access',
  templateUrl: './sponsor-access.component.html'
})
export class SponsorAccessComponent implements OnInit {

  User:any;
  constructor(private sponsorService:SponsorAccessService,private router:ActivatedRoute,private route:Router) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
  }


 

  

}
