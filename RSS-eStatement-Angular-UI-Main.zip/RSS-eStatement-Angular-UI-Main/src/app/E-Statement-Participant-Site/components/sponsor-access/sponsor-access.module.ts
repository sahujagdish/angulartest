import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SponsorAccessRoute } from './sponsor-access.routing';
import { SponsorSearchComponent } from './sponsor-search/sponsor-search.component';
import { SponsorAccessComponent } from './sponsor-access.component';
import { SponsorReportComponent } from './sponsor-report/sponsor-report.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SponsorLinksComponent } from './sponsor-links/sponsor-links.component';
import { SponsorProfileComponent } from './sponsor-profile/sponsor-profile.component';
import { SponsorAdministratorComponent } from './sponsor-administrator/sponsor-administrator.component';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SponsorFormComponent } from './sponsor-form/sponsor-form.component';
import { BackButtonComponent } from "../back-button/back-button.component";


@NgModule({
  declarations: [
    SponsorSearchComponent,
    SponsorAccessComponent,
    SponsorReportComponent,
    SponsorLinksComponent,
    SponsorProfileComponent,
    SponsorAdministratorComponent,
    SponsorFormComponent,
    BackButtonComponent
  ],
  imports: [
    CommonModule,
    SponsorAccessRoute,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatCheckboxModule
  ]
})
export class SponsorAccessModule { }
