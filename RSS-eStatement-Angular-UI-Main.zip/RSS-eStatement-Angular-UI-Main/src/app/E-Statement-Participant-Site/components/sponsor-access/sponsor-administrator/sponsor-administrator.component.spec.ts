import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SponsorAdministratorComponent } from './sponsor-administrator.component';

describe('SponsorAdministratorComponent', () => {
  let component: SponsorAdministratorComponent;
  let fixture: ComponentFixture<SponsorAdministratorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SponsorAdministratorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SponsorAdministratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
