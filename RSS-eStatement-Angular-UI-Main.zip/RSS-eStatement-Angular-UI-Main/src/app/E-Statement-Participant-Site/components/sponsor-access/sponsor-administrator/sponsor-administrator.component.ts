import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Md5 } from 'ts-md5';
import { Color, newSponsorObject, sponAdminValidation } from '../../../models/ObjectHelper';
import { SponsorService } from '../../../services/sponsor-service/sponsor.service';
import { SponsorAccessService } from '../sponsor-service/sponsor.service';

@Component({
  selector: 'app-sponsor-administrator',
  templateUrl: './sponsor-administrator.component.html',
  styleUrls: ['./sponsor-administrator.component.css']
})
export class SponsorAdministratorComponent implements OnInit {

  User: any;
  SponID: number = 0;
  Sponsor: any = {};
  SponsorForm: FormGroup;
  SponsorAdminID: any[] = [];
  Profiles: any[] = [];
  isNewSponsorID: boolean = true;
  selectedControlID: string = "";
  selectedProfile: any = {};
  isDataLoading: boolean = true;

  @ViewChild('passwordstrength') passwordstrength: ElementRef;
  @ViewChild('password_strengthLowerString') password_strengthLowerString: ElementRef;
  @ViewChild('password_strengthUpperString') password_strengthUpperString: ElementRef;
  @ViewChild('password_strengthNumber') password_strengthNumber: ElementRef;
  @ViewChild('password_strengthSpecial') password_strengthSpecial: ElementRef;
  @ViewChild('password_match') password_match: ElementRef;

  constructor(private route: Router, private sponsorAccessservice: SponsorAccessService, private router: ActivatedRoute, private sponsor_service: SponsorService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.SponID = Number(atob(this.router.snapshot.queryParamMap.get('spon_id')));
  }

  ngOnInit(): void {
    this.SetupForm();
    this.getSponsor(this.SponID);
  }

  getSponsorAdministartors() {
    this.sponsor_service.getSponsorAdministrators(this.SponID, this.Sponsor.Active, this.User.ProviderID).then(resp => {
      this.SponsorAdminID = resp;
      this.getProfiles();
    }).catch(error => {
      alert("Unable to load Administrators");
      this.isDataLoading = false;
    })
  }

  SetupForm() {
    let formGenerationObject = newSponsorObject;
    this.SponsorForm = this.generateFormGroup(formGenerationObject);
    console.log(this.SponsorForm);
  }

  generateFormGroup(formGenerationObject: any) {
    let Form = {};
    let validations:Map<string,ValidatorFn[]> = sponAdminValidation;
    let SponsorFormMap = new Map(Object.entries(formGenerationObject));
    SponsorFormMap.forEach((value, key) => {
      Form[key] = new FormControl(value,validations.get(key));
    })
    let form = new FormGroup(Form);
    return form;
  }

  

  Back() {
    this.route.navigate(["../search"], { relativeTo: this.router });
  }

  getSponsor(SponID: number) {
    this.sponsor_service.getSponsor(SponID).then(resp => {
      this.Sponsor = resp;
      this.getSponsorAdministartors();
    }).catch(error => {
      alert("Unable to Load Sponsor Details");
      this.isDataLoading = false;
    });
  }

  updateForm(UpdatedObject: any) {
    this.SponsorForm.patchValue(UpdatedObject);
  }

  generateNewProfile() {
    let newProfileObject = newSponsorObject;
    newProfileObject.ControlName = "New";
    newProfileObject.SpadFName = "Record"
    newProfileObject.SpadSponId = this.SponID;
    this.SponsorForm.patchValue(newProfileObject);
    this.SponsorAdminID.push(newProfileObject);
    this.selectedProfile = newProfileObject;
    this.selectedControlID = String(newProfileObject.ControlID);
  }

  getProfiles() {
    this.sponsor_service.getProfiles(this.SponID, this.Sponsor.Active).then(resp => {
      this.Profiles = resp;
      this.isDataLoading = false;
    }).catch(error => {
      alert("Unable to Load Profiles");
      this.isDataLoading = false;
    })
  }

  onProfileSelected(event: any) {
    this.selectedProfile = this.SponsorAdminID.filter(adminObjects => adminObjects.ControlID == event)[0];
    this.selectedControlID = event;
    this.updateForm(this.selectedProfile);
  }

  refresh() {
    this.getSponsor(this.SponID);
  }

  CheckPasswordStrength() {
    
    let password = this.SponsorForm.get('SpadPassword').value;
      //if textBox is empty
      if(password.length==0){
        this.passwordstrength.nativeElement.innerHTML = "";        
      }

      //Regular Expressions
      var regex = new Array();
      regex.push("[A-Z]"); //For Uppercase Alphabet
      regex.push("[a-z]"); //For Lowercase Alphabet
      regex.push("[0-9]"); //For Numeric Digits
      regex.push("[!@#$%\^&*()_+\-=]"); //For Special Characters

      let passed = 0;
      //Validation for each Regular Expression
      for (var i = 0; i < regex.length; i++) {
          if((new RegExp (regex[i])).test(password)){
            console.log(passed);
              passed++;
          }
      }

      //Display of Status
      var color = "";
      var passwordStrength = "";
      //Validation for Length of Password
      if(passed > 2 && password.length > 8){
        passed++;
      }

      if((new RegExp ("[a-z]")).test(password)){       
        this.password_strengthLowerString.nativeElement.style.color = Color.Green;    
      } else {
        this.password_strengthLowerString.nativeElement.style.color = Color.Red;
      }

      if((new RegExp ("[A-Z]")).test(password)){        
        this.password_strengthUpperString.nativeElement.style.color = Color.Green;    
      } else {
        this.password_strengthUpperString.nativeElement.style.color = Color.Red;
      }

      if((new RegExp ("[0-9]")).test(password)){        
        this.password_strengthNumber.nativeElement.style.color = Color.Green;    
      } else {
        this.password_strengthNumber.nativeElement.style.color = Color.Red;
      }

      if((new RegExp ("[$@$!%*#?&]")).test(password)){        
        this.password_strengthSpecial.nativeElement.style.color = Color.Green;    
      } else {
        this.password_strengthSpecial.nativeElement.style.color = Color.Red;
      }

      if(password.length > 8){        
        this.password_match.nativeElement.style.color = Color.Green;    
      } else {
        this.password_match.nativeElement.style.color = Color.Red;
      }

      switch(passed){
          case 0:
              break;
          case 1:
              passwordStrength = "Password is Weak.";
              color = Color.Red;
              break;
          case 2:
            passwordStrength = "Password is Weak.";
            color = Color.Red;
            break;
          case 3:
            passwordStrength = "Password is Good.";
            color = Color.Orange;
            break;
          case 4:
              passwordStrength = "Password is Strong.";
              color = Color.Green;
              break;
          case 5:
              passwordStrength = "Password is Strong.";
              color = Color.DarkGreen;
              break;
      }
      this.passwordstrength.nativeElement.innerHTML = passwordStrength;
      this.passwordstrength.nativeElement.style.color = color;
      console.log(passed);
      return passed;
  }

  Add() {
    let user = this.SponsorAdminID.filter(userid => userid.ControlID == 0);
    if (this.selectedControlID == "" || user.length == 0) {
      this.generateNewProfile();
    }
  }

  Save() {
    if (this.SponsorForm.valid) {
      let SponsorObject = this.SponsorForm.value;
      if (SponsorObject.ControlID != 0) {
        SponsorObject.Updated = true;
      }
      SponsorObject.SpadPassword=new Md5().appendStr(SponsorObject.SpadPassword).end()
      this.sponsor_service.updateSponsorAdmin(SponsorObject, this.User.ProviderID).then(resp => {
        alert("Profile Updated Successfully");
        this.refresh();
      }).catch(error => {
        alert("Unable to Update Profile , "+error.error);
      })
    }else{
      this.SponsorForm.markAllAsTouched();
    }

  }
  Delete() {
    if (confirm("Are you sure you want to delete the profile")) {
   
        let SponsorObject = this.SponsorForm.value;
        SponsorObject.Active = false;
        this.sponsor_service.updateSponsorAdmin(SponsorObject, this.User.ProviderID).then(resp => {
          alert("Profile Deleted Successfully");
          this.refresh();
        }).catch(error => {
          alert("Unable to Delete Profile");
        })
      
    }
  }

}
