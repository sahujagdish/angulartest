import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SponsorSearchComponent } from './sponsor-search.component';

describe('SponsorSearchComponent', () => {
  let component: SponsorSearchComponent;
  let fixture: ComponentFixture<SponsorSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SponsorSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SponsorSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
