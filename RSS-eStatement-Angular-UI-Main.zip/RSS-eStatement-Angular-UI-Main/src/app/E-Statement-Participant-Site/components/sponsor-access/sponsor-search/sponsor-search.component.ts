import { Component, OnInit, Input, Output } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { EventEmitter } from 'events';
import { SponsorAccessService } from '../sponsor-service/sponsor.service';
import { ActivatedRoute, Router } from '@angular/router';
import { sponsorAccessSearch } from '../../../models/ObjectHelper';
import { SponsorService } from '../../../services/sponsor-service/sponsor.service';

@Component({
  selector: 'app-sponsor-search',
  templateUrl: './sponsor-search.component.html',
  styleUrls: ['./sponsor-search.component.css']
})
export class SponsorSearchComponent implements OnInit {

  searchFor:string="search";
  searchForm!:FormGroup;

  action:string="links";
  User:any;

  constructor(private sponsorAccessService:SponsorAccessService,private routing:ActivatedRoute,private route:Router,private sponsorService:SponsorService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
   }

  ngOnInit(): void {
    this.searchForm = new FormGroup({
      planNum:new FormControl("",[Validators.maxLength(12)]),
      sponName:new FormControl("",[Validators.maxLength(30)]),
      sponNum:new FormControl("",[Validators.maxLength(12)]),
      isSponActive:new FormControl("",[])
    },{validators:this.ValidateFields});
    this.HideControl();
  }

  HideControl(){
    if(this.searchFor!='summaryrpt'){
      this.searchForm.get('planNum').disable();
    }
  }

  ValidateFields:ValidatorFn = (group: AbstractControl): ValidationErrors | null=>{
    let error = {"EmptyFields":true};
    let formGroup:FormGroup = group as FormGroup;
    Object.keys(formGroup.controls).forEach(groupControl=>{
      let control = formGroup.get(groupControl);
      if(control.value!=""){
        error = null;
      }
    })
    return error;
  }

  reset(){
    this.searchForm.reset();
  }

  search(){
    
    console.log(this.searchForm);
    if(this.searchFor!='summaryrpt'){
    
    if(this.searchForm.valid){
    let searchformObject = this.searchForm.value;
    let searchObject = sponsorAccessSearch;
    searchObject.PlanNum = searchformObject.planNum;
    searchObject.ProviderID = this.User.ProviderID;
    searchObject.SponName = searchformObject.sponName;
    searchObject.SponNum = searchformObject.sponNum;
    searchObject.IsHideSensitivePlans = this.User.HideSensitivePlans;
    searchObject.IsSponActive = (searchformObject.isSponActive=="true" || searchformObject.isSponActive=="");
    searchObject.ISID = 0;

    console.log(searchObject);
    this.sponsorService.searchSponsor(searchObject).then(response=>{
      this.sponsorAccessService.setSponsorSearchObject(searchObject);

      this.sponsorAccessService.setSearchResults(response);
      this.route.navigate(["../report"],{relativeTo: this.routing,queryParams:{action:this.action}});
    }).catch(error=>{
      alert("Unable to Search Sponsors");
    })
   
    }else{
      this.searchForm.markAllAsTouched();
    }
  }else{
    this.route.navigateByUrl(this.User.Provider+"/"+this.User.Role+"/summaryReport");
  }
  }
}
