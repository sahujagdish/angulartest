import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnsubscribeEDeliveryComponent } from './unsubscribe-edelivery.component';

describe('UnsubscribeEDeliveryComponent', () => {
  let component: UnsubscribeEDeliveryComponent;
  let fixture: ComponentFixture<UnsubscribeEDeliveryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnsubscribeEDeliveryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnsubscribeEDeliveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
