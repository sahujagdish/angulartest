import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../../services/participant-service/participant.service';

@Component({
  selector: 'app-unsubscribe-edelivery',
  templateUrl: './unsubscribe-edelivery.component.html',
  styleUrls: ['./unsubscribe-edelivery.component.css']
})
export class UnsubscribeEDeliveryComponent implements OnInit {

  Unsubscribed:boolean = false;
  User:any;
  constructor(private participant_service:ParticipantService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }


  ngOnInit(): void {
  }

  unsubscribe() {
    this.participant_service.unsubscribe(this.User.userid,this.User.ProviderID).toPromise().then(resp=>{
      this.Unsubscribed = true;
    })
    
  }


}
