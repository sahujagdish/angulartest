import { Component, OnInit } from '@angular/core';
import { resetFakeAsyncZone } from '@angular/core/testing';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Md5 } from 'ts-md5';
import { CustomValidations } from '../../models/CustomValidation';
import { RegisterParticipant } from '../../models/RegisterParticipant';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  
  registerForm:FormGroup=undefined;
  isLoading:boolean = false;
  isSuccessfull:boolean = false;
  captcha:any = undefined;
  captchaText:string="";
  constructor(private securityService:SecurityService,private participantService:ParticipantService,private sanitizer:DomSanitizer) {  
  }

  ngOnInit(): void {
    this.setupForm();
    this.getCaptchaDetails();
  }

  setupForm(){
    this.registerForm = new FormGroup({
      FName: new FormControl('',[Validators.required]),
      MI: new FormControl(''),
      LName: new FormControl('',[Validators.required]),
      SSN: new FormControl('',[Validators.required,Validators.minLength(11),Validators.pattern('^[0-9-]+$')]),
      Email: new FormControl('',[Validators.required,Validators.email]),
      UserID: new FormControl('',[Validators.required,Validators.minLength(6),Validators.maxLength(10),Validators.pattern("(?=.*?[0-9])(?=.*?[A-Za-z]).+")]),
      Password: new FormControl('',[Validators.required,CustomValidations.checkPasswordsCustom]),
      ConfirmPassword: new FormControl('',[Validators.required,CustomValidations.checkPasswordsCustom]),
      Captcha:new FormControl('',[Validators.required])
    },{validators:[CustomValidations.comparePassword("Password","ConfirmPassword")]});  

    this.appendSSN("SSN");  
  }

  appendSSN(ssnControlName:string){
    let prevval = "";
    let ssnControl = this.registerForm.get(ssnControlName)!;
    ssnControl.valueChanges.subscribe(resp => {
      let currentval = resp;
      if (resp.length == 3 || resp.length == 6) {
        if (currentval.length >= prevval.length) {
          resp = resp + "-";
          ssnControl.setValue(resp);
        }
      }
      prevval = currentval;
    });
  }

  getCaptchaDetails(){
    this.securityService.getCaptchaDetails().subscribe(resp=>{
      let body = resp.body as Blob;
      let objectURL = URL.createObjectURL(body);       
      this.captcha = this.sanitizer.bypassSecurityTrustUrl(objectURL);
      this.captchaText = resp.headers.get("captchatext");
    })
  }

  checkCaptchaValidity(){
      let captchaControl:AbstractControl|null = this.registerForm.get("Captcha");
      let uservalue = captchaControl!.value;
      if(uservalue!=""){
      this.securityService.validateCaptcha(uservalue,this.captchaText).toPromise().then(resp=>{
        if(resp){
          captchaControl.setErrors(null)
        }else{
          captchaControl.setErrors({"invalidCaptcha":true});
          this.getCaptchaDetails();
        }
      });
    }
  }

  save(){
    this.checkCaptchaValidity();
    if(this.registerForm.valid){
      this.isLoading = true;
        let groupValue = this.registerForm.value;
        let participant  = new RegisterParticipant();
        participant.ssn = groupValue.SSN;
        participant.account_number = groupValue.SSN;
        participant.fname = groupValue.FName;
        participant.mi = groupValue.MI;
        participant.lname = groupValue.LName;
        participant.email = groupValue.Email;
        participant.userid = groupValue.UserID;
        participant.password =  String(new Md5().appendStr(groupValue.Password).end());
        participant.providerid = this.securityService.getProvider().Id;
        this.participantService.createParticipant(participant).toPromise().then(resp=>{
          this.isLoading = false;
          this.isSuccessfull = true
        }).catch(error=>{
          this.isLoading = false;
          console.error(error);
          let message = error.error.Message!=undefined?error.error.Message:"";
          alert("Unable to Register Participant , "+message);
          this.reset();
        })
    }else{
      this.registerForm.markAllAsTouched();
    }
  }


  reset(){
    console.log(this.registerForm);
    this.registerForm.reset();
    this.registerForm.markAsUntouched(); 
    this.getCaptchaDetails();  
  }


}
