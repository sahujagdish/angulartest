import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EditParticipantComponent } from '../../modals/edit-participant/edit-participant.component';
import { EnterProcessInformationComponent } from '../../modals/enter-process-information/enter-process-information.component';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { search, participant, planlist } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { SecurityService } from '../../services/security-service/security.service';
import { SearchStatementRepo } from '../../models/StatementSeach';
import { Role } from '../../models/User';
import { ViewStatementsComponent } from '../view-statements/view-statements.component';

@Component({
  selector: 'app-access-participant-information',
  templateUrl: './access-participant-information.component.html',
  styleUrls: ['./access-participant-information.component.css']
})
export class AccessParticipantInformationComponent implements OnInit {

  participantStatement: any[] = [];
  filteredParticipantStatement: any[] = [];

  participantProcess: any[] = [];
  filteredParticipantProcess: any[] = [];

  planList: any[] = [];
  filteredPlanList: any[] = [];

  pageSize: number = environment.pagesize;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.participantStatement.length / this.pageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.pageSize;
  selectedIndex: number = -1;

  provider!: string;

  selectedItemVar: number = -1;
  SearchForm!: FormGroup;

  sortDirection = "ASC";
  sortType = "";

  errorStatus: boolean = false;
  loadingPartStatement: boolean = false;
  user: any;
  initialLoad: boolean = true;
  reloadObject: any;
  isRelodable: boolean = false;
  displayToggle: string = "Participant to Process";
  selectedParticipant: number = 0;
  showStatement: boolean = false;
  processAll:boolean = false;
  totalCount:number=0;
  hasStatementRepo:boolean = true;

  constructor(public dialog: MatDialog, public route: Router, public router: ActivatedRoute,
    private participantService: ParticipantService, private securityService: SecurityService) {
    this.provider = String(this.router.snapshot.parent!.paramMap.get("participant"));
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }


  ngOnInit(): void {
    this.SearchForm = new FormGroup({
      SSN: new FormControl('', [Validators.maxLength(11), Validators.minLength(11), Validators.pattern('^[0-9-]+$')]),
      Lname: new FormControl(''),
      Pname: new FormControl('')
    }, { validators: this.checkEmpty });

    let prevval = "";

    this.SearchForm.valueChanges.subscribe(resp => {
      let currentval = resp.SSN;
      if (resp.SSN.length == 3 || resp.SSN.length == 6) {
        if (currentval.length >= prevval.length) {
          resp.SSN = resp.SSN + "-";
          this.SearchForm.setValue(resp);
        }
      }
      prevval = currentval;
    });
    this.checkStatementRepo();
    this.setupPage();
    this.onChange();
  }
  checkEmpty: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
    let ssnN = group.get('SSN')!.value;
    let LnameN = group.get('Lname')!.value;
    let PnameN = group.get('Pname')!.value;
    if (ssnN || LnameN || PnameN) {
      return null;
    }

    return { "requiredAny": true }
  }

  onChange() {
    if (this.user.Role == 'spon') {
      this.getSponList();
    } else {
      this.getPlanList();
    }
  }

  getPlanList() {
    let plan_list = planlist;
    plan_list.PlanName = this.SearchForm.value.Pname;
    plan_list.ProviderID = this.user.ProviderID;
    plan_list.AdminID = this.user.userid;
    this.participantService.getPlanList(plan_list, String(sessionStorage.getItem("token"))).subscribe(resp => {
      this.planList = resp;

    }, error => {
      this.errorStatus = true;
    })
  }

  getSponList() {
    this.participantService.getSponPlanName(this.user.userid).toPromise().then(resp => {
      this.SearchForm.patchValue({
        Pname: resp[0].PlanNumber
      });
    }).catch(error => {

    })
  }

  filter() {
    this.filteredPlanList = this.planList.filter(plan => plan.PlanName.toUpperCase().includes(this.SearchForm.value.Pname.toUpperCase()));
  }

  setupPage() {
    this.startIndex = 0;
    this.pageSize = environment.pagesize;
    this.endIndex = this.startIndex + this.pageSize;

  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      console.log("end" + this.endIndex);
      console.log("start" + this.startIndex);
      console.log("pagesize" + this.pageSize);
      this.currentPage++;
      this.reSearch();
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      this.currentPage--;
      this.reSearch();
    }

  }

  FirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      this.currentPage = 1;
      this.reSearch();
    }

  }

  LastPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = ((this.totalPage * this.pageSize) - this.pageSize);
      this.endIndex = (this.totalPage * this.pageSize);

      console.log(this.startIndex + "," + this.endIndex);
      this.currentPage = this.totalPage;
      this.currentPage = this.totalPage;
      this.reSearch();
    }

  }

  selectedOption(option: any, index: number) {
    this.selectedIndex = index;
  }

  planDisplayFn(value: any) {

    if (value == '') {
      return '';
    }
    let retval = value ? this.planList.find(plan => plan.PlanNumber.toUpperCase() === value).PlanName : undefined;
    return retval;

  }

  selectedItem(option: any, index: number) {
    this.selectedItemVar = index;
  }

  add() {
    let uid = this.participantProcess.filter(value=>value.UID == this.filteredParticipantStatement[this.selectedIndex].UID);
    if (uid.length==0 && this.selectedIndex != -1) {
      this.participantProcess.push(this.filteredParticipantStatement[this.selectedIndex]);
      this.selectedParticipant++;
    }
  }



  addPage() {
    this.filteredParticipantStatement.forEach(ele => {
      let uid = this.participantProcess.filter(value=>value.UID == ele.UID);
      if (uid.length==0) {
        this.participantProcess.push(ele);
        this.selectedParticipant++;
      }
    })
  }


  ProcessAll(event: any) {

    this.processAll = event.checked;
    if (event.checked) {
      this.displayToggle = "Excluded Participant"
    } else {
      this.displayToggle = "Participant to Process";

    }
  }

  resetSearch() {
    this.initialLoad = true;
    this.participantStatement.length = 0;
    this.filteredParticipantStatement.length = 0;
    this.setupPage();
    this.loadingPartStatement = false;
    this.SearchForm.setValue({
      SSN: '',
      Lname: '',
      Pname: ''
    });
  }

  


  search() {
    if (this.SearchForm.value.SSN != '' || this.SearchForm.value.Pname != '' || this.SearchForm.value.Lname) {
      this.loadingPartStatement = true;
      this.setupPage();
      let Search = new SearchStatementRepo().SearchRequest;
      Search.PartID = this.SearchForm.value.SSN;
      Search.LName = this.SearchForm.value.Lname;
      Search.PlanName = this.SearchForm.value.Pname;
      Search.ProviderID = this.securityService.getProvider().Id;
      Search.ProvID = this.securityService.getClients();
      Search.IsSponsor = this.user.Role == Role.Sponsor ? true : false;
      Search.SpadID = this.user.Role == Role.Sponsor ? this.user.userid : 0;
      Search.AdminID = this.user.Role == Role.Administrator ? this.user.userid : 0;
      Search.Start = this.startIndex;
      Search.Limit = this.pageSize;
      this.isRelodable = false;
      this.reloadObject = Search;
      this.participantService.search(Search, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
        this.initialLoad = false;
        this.totalCount = resp.TotalCount;
        this.totalPage = Math.ceil(resp.TotalCount / this.pageSize);
        if (resp.TotalCount > 0)
          this.currentPage = 1;
        this.participantStatement = resp.List;
        console.log("ParticipantStatement");
        console.log(this.participantStatement);
        this.filteredParticipantStatement = resp.List;
        this.setupPage();
        if (Number(resp.TotalCount) == 0)
          this.currentPage = 0;

        this.isRelodable = true;
        this.loadingPartStatement = false;
      }, (error: any) => {
        this.errorStatus = true;
      })
    } else {
      alert("Please Enter Search Value");
    }
  }

  reSearch() {
    this.loadingPartStatement = true;
    let Search = this.reloadObject;
    Search.Start = this.startIndex;
    Search.Limit = this.pageSize;
    this.isRelodable = false;
    this.reloadObject = Search;
    this.participantService.search(Search, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
      this.initialLoad = false;
      this.participantStatement = resp.List;
      console.log("ParticipantStatement");
      console.log(this.participantStatement);
      this.filteredParticipantStatement = resp.List;
      if (Number(resp.TotalCount) == 0)
        this.currentPage = 0;

      this.isRelodable = true;
      this.loadingPartStatement = false;
    }, (error: any) => {
      this.errorStatus = true;
    })

  }

  
 checkStatementRepo(){
  let links:any[]=this.securityService.getLinks();
  let statementRepoLink = links.filter(value=>value.LinkText=="Statement Repository");
  this.hasStatementRepo = statementRepoLink.length>0;
}


  reload() {

    if (this.isRelodable) {
      this.loadingPartStatement = true;
      this.participantService.search(this.reloadObject, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
        this.initialLoad = false;
        this.participantStatement = resp.list;
        this.totalPage = Math.ceil(resp.TotalCount / this.pageSize);
        this.filteredParticipantStatement = resp.List;
        this.setupPage();

        if (Number(resp.TotalCount) === 0)
          this.currentPage = 0;
        this.loadingPartStatement = false;
      }, error => {
        this.errorStatus = true;

        this.loadingPartStatement = false;
      })
    }


  }

  

  EditPar() {
    this.participantService.isEditable(true, this.user.ProviderID, this.user.Provider, this.filteredParticipantStatement[this.selectedIndex].UID, String(sessionStorage.getItem("token"))).toPromise()
      .then((resp: any) => {
        if (resp.is_editable) {
          var edit = participant;
          edit.uid = this.filteredParticipantStatement[this.selectedIndex].UID;
          edit.parUUID = resp.participant_UUID;
          edit.providerID = this.user.ProviderID;

          this.participantService.getParticipantData(edit, String(sessionStorage.getItem("token"))).subscribe(resp => {
            let dialogRap = this.dialog.open(EditParticipantComponent, { data: { partcipant: resp, uuid: edit.uid } });
            dialogRap.afterClosed().toPromise().then(resp => {
              this.reload();
            })
          }, (error: any) => {
            this.errorStatus = true;
          })



        } else {
          alert("Participant Not Editable");
        }
      }).catch((error: any) => {
        this.errorStatus = true;

      })

  }


  sortParticipant(PropertyName: string) {
    this.sortType = PropertyName;
    if (this.sortDirection == "ASC") {
      this.sortDirection = "DES";
    } else {
      this.sortDirection = "ASC";
    }
    switch (PropertyName) {
      case 'First Name':
        if (this.sortDirection == "ASC") {
          this.filteredParticipantStatement.sort((a, b) => (a.FName < b.FName ? -1 : 1));
        } else {
          this.filteredParticipantStatement.sort((a, b) => (a.FName > b.FName ? -1 : 1));
        }
        break;
      case 'Last Name':
        if (this.sortDirection == "ASC") {
          this.filteredParticipantStatement.sort((a, b) => (a.LName < b.LName ? -1 : 1));
        } else {
          this.filteredParticipantStatement.sort((a, b) => (a.LName > b.LName ? -1 : 1));
        }
        break;
      case 'SSN':
        if (this.sortDirection == "ASC") {
          this.filteredParticipantStatement.sort((a, b) => (a.PartId < b.PartId ? -1 : 1));
        } else {
          this.filteredParticipantStatement.sort((a, b) => (a.PartId > b.PartId ? -1 : 1));
        }
        break;
      case 'Plan Code':
        if (this.sortDirection == "ASC") {
          this.filteredParticipantStatement.sort((a, b) => (a.PlanNum < b.PlanNum ? -1 : 1));
        } else {
          this.filteredParticipantStatement.sort((a, b) => (a.PlanNum > b.PlanNum ? -1 : 1));
        }
        break;
    }
  }
  /*
  partID  part_id
  ASC DESC
  lname
  */
  sortParticipantProcess(PropertyName: string) {
    switch (PropertyName) {
      case 'First Name':
        this.filteredParticipantProcess.sort((a, b) => (a.FName < b.FName ? -1 : 1));
        break;
      case 'Last Name':
        this.filteredParticipantProcess.sort((a, b) => (a.LName < b.LName ? -1 : 1));
        break;
      case 'SSN':
        this.filteredParticipantProcess.sort((a, b) => (a.PartId < b.PartId ? -1 : 1));
        break;
      case 'Plan Code':
        this.filteredParticipantProcess.sort((a, b) => (a.PlanNum < b.PlanNum ? -1 : 1));
        break;
    }
  }

  getAllData() {
    let search = new SearchStatementRepo().SearchRequest;
    search.ProviderID = this.securityService.getProvider().Id;
    search.ProvID = this.securityService.getClients();
    search.IsSponsor = this.user.Role == Role.Sponsor ? true : false;
    search.SpadID = this.user.Role == Role.Sponsor ? this.user.userid : 0;
    search.AdminID = this.user.Role == Role.Administrator ? this.user.userid : 0;
    search.Start = this.startIndex;
    search.Limit = 0;
    search.PlanName = this.SearchForm.value.Pname;
    return this.participantService.search(search, String(sessionStorage.getItem("token"))).toPromise();
  }

  ProcessInfo() {
    if (this.participantProcess.length > 0 || this.processAll) {
      if (this.processAll) {
        this.getAllData().then((resp: any) => {
          let allParticipantData: any[] = resp.List;
          let planNum = allParticipantData[0].PlanNum;
          let invalidPlanNumFound:boolean = null;
          this.participantProcess.forEach(value=>{ 
            console.log(allParticipantData.indexOf(value.UID));
            if(value.PlanNum == planNum){
              allParticipantData.splice(allParticipantData.indexOf(value.UID),1);
            }else{
              invalidPlanNumFound = true;
            }
          });
          
          if(allParticipantData.length>0 && invalidPlanNumFound==null){
            this.openPopUp(allParticipantData, this.participantProcess, this.processAll);
          }else{ 

              if(allParticipantData.length==0){
                alert("No Participant Selected for Processing ");
              }
            
              if(invalidPlanNumFound==true){
                alert("Participant With Invalid Plan Name is ");
              }
            }
        })
      } else {
        this.openPopUp([], this.participantProcess, this.processAll);
      }
    }else{
      alert("No Participant Selected for Processing");
    }
  }

  openPopUp(allParticipantData: any[], processParticipantData: any[], processAll: boolean) {
    this.dialog.open(EnterProcessInformationComponent, {
      data: {
        allData: allParticipantData,
        processStatement: processParticipantData,
        processAll: processAll
      },
      disableClose:true
    });
  }

  viewStatement(viewStatement: ViewStatementsComponent) {
    this.showStatement = true;
    viewStatement.uid = this.filteredParticipantStatement[this.selectedIndex].UID,
      viewStatement.partID = this.filteredParticipantStatement[this.selectedIndex].ParticipantId,
      viewStatement.getViewStatementData(this.user.Role);
  }

  hideViewStatement = () => {
    this.showStatement = false;
  }
  removeAll() {
    this.participantProcess = [];
    this.selectedParticipant = 0;
  }

  remove() {
    if (this.participantProcess.length > 0) {
      this.participantProcess.splice(this.selectedItemVar, 1);
      this.selectedParticipant--;
    }
  }

  

}
