import { Component, OnInit,Output,EventEmitter, Input, ViewChild } from '@angular/core';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { planlist } from '../../models/ObjectHelper';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-plan-drop-down',
  templateUrl: './plan-drop-down.component.html',
  styleUrls: ['./plan-drop-down.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi:true,
      useExisting: PlanDropDownComponent
    }
  ]
})
export class PlanDropDownComponent implements OnInit,ControlValueAccessor  {
  
  onChange = (planNumber) => {};
  onTouched = () => {};

  touched = false;
  disabled = false;
  
  filteredPlanList: any[] = [];
  planList: any[] = [];
  
  user:any;

  planName:string="";
  planNumber:string="";

  onPlanListLoad:EventEmitter<Array<any>> =new EventEmitter<Array<any>>();
  onPlanSelectionChange:EventEmitter<any> =new EventEmitter<any>();
  onError:EventEmitter<string> =new EventEmitter<string>();
  
  @Input() onDisplayPlanOption = (plan: any) =>  plan.PlanName;

  @Input() onDataBinding = (planList: Array<any>) => planList;
  @ViewChild('planText') inputPlan;
  constructor(private participantService: ParticipantService) { 
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.loadPlanList("");
  }

  async loadPlanList(planName) {
    try {
      let plan_list = planlist;
      plan_list.PlanName = planName;
      plan_list.ProviderID = this.user.ProviderID;
      plan_list.AdminID = this.user.userid;
      const res = await this.participantService.getPlanList(plan_list, String(sessionStorage.getItem("token"))).toPromise();
      this.planList = this.onDataBinding(res);
      this.filteredPlanList = this.planList;
      this.onPlanListLoad.emit(this.planList);
    } catch (error) {
      this.onError.emit("Error occure while loading plan list");
    }
  }
  

  clearPlanText(){
    this.planName="";
    this.inputPlan.nativeElement.value = "";
    this.onChange("");

  }

  filterPlan(event) {
    if (!this.disabled) {
      const filterText = event.target.value
      this.filteredPlanList = filterText? this.planList
      .filter(plan => plan.PlanName.toUpperCase().includes(filterText.toUpperCase()))
      :this.planList;
      if(!filterText){
        this.onChange("");
      }
    }
  }

  handlePlanChange(event){
    this.markAsTouched();
    const plan=event.option.value;
    if (!this.disabled) {
      this.planName=plan.PlanName;
      this.planNumber=plan.PlanNumber;
      this.onChange(plan.PlanNumber)
      this.onPlanSelectionChange.emit();
    }
  }

  writeValue(planNumber: any): void {
    this.planNumber=planNumber;
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  markAsTouched() {
    if (!this.touched) {
      this.onTouched();
      this.touched = true;
    }
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

}
