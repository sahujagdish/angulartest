import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanDropDownComponent } from './plan-drop-down.component';

describe('PlanDropDownComponent', () => {
  let component: PlanDropDownComponent;
  let fixture: ComponentFixture<PlanDropDownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanDropDownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanDropDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
