import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddOrderedSiteTextComponent } from '../../modals/add-ordered-site-text/add-ordered-site-text.component';
import { Router, ActivatedRoute } from '@angular/router';
import { StatementService } from '../../services/statement-service/statement.service';
import { approval_list, deleteObject, StatusFilter } from '../../models/ObjectHelper';
import { ApproveComponent } from '../../modals/approve/approve.component';
import { SecurityService } from '../../services/security-service/security.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-statement-print-approval',
  templateUrl: './statement-print-approval.component.html',
  styleUrls: ['./statement-print-approval.component.css']
})
export class StatementPrintApprovalComponent implements OnInit {

  statementPrintDataSet: any[] = [];
  statementPrintData: any[] = [];
  filteredStatementPrintData: any[] = [];

  pageSize: number = environment.pagesize;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.statementPrintData.length / this.pageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.pageSize;
  selectedIndex: number = -1;

  provider!: string;
  user: any;

  planData: any[] = [];
  filteredPlanData: any[] = [];

  sortDirection = "ASC";
  sortType: string = "";

  filterOptions: string = "All";

  startIndex1: number = 0;
  totalPage1: number = Math.ceil(this.planData.length / this.pageSize);
  currentPage1: number = this.totalPage > 0 ? 1 : 0;
  endIndex1: number = this.startIndex + this.pageSize;
  selectedIndex1: number = -1;
  startLimit: number = 0;
  endLimit: number = 100;
  filterOption: string[] = [];
  loadingStatementPrintData: boolean = false;
  loadingPlanData: boolean = false;

  isProofGenerated: boolean = false;
  approvalObject: any;//= approval_list;
  selectAll: boolean = false;
  isDeveloped: boolean = false;
  constructor(public dialog: MatDialog, public route: Router, public router: ActivatedRoute, private statement_service: StatementService, private security_service: SecurityService) {
    this.provider = String(this.router.snapshot.paramMap.get("participant"));
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.approvalObject = {
      Start: 0,
      Limit: 5,
      SortDirection: "ASC",
      SortField: "",
      ProvId: "",
      StatusFilter: "All",
      Year: 0,
      Quarter: 0
    }

    this.initGetData();
  }

  initGetData() {
    this.loadingStatementPrintData = true;
    if (this.startLimit == 0) {
      this.statementPrintData = [];
    }

    this.approvalObject.ProvId = this.security_service.getClients();
    this.approvalObject.Start = this.startLimit;
    this.approvalObject.Limit = this.endLimit;
    this.statement_service.getApprovalList(this.approvalObject).subscribe(resp => {

      let list: any[] = resp.list;
      let approvalid: any[] = [];
      this.totalPage = Math.ceil(resp.TotalCount / this.pageSize);
      console.log(this.totalPage);
      list.forEach(ele => {
        let status = (ele.Status == 'UnApproved' ? StatusFilter.Unapproved : ele.Status);
        let optionExist: boolean = this.filterOption.filter(opt => opt == status).length > 0;
        if (optionExist == false) {
          this.filterOption.push(status);
        }
        var approveDate = ele.Status == StatusFilter.Approved ? ele.ApprovedDate : "";
        this.statementPrintData.push({
          ZIP_FileName: ele.ZIP_FileName,
          DateSent: ele.DateSent,
          Status: status,
          Proof_date: "N/A",
          Reports: [],
          ApproverId: ele.ApproverId,
          approverDate: approveDate
        });
        approvalid.push(ele.ApproverId);
      });


      this.statement_service.getApprovalInfo(approvalid).toPromise().then(resp => {
        let report = resp[0];
        let proof_date = new Map(Object.entries(report.proofDates))//report.proofDates;
        let report_types = new Map(Object.entries(report.reportTypes));

        proof_date.forEach((value, key) => {
          let i = this.statementPrintData.findIndex(ele => ele.ApproverId == key);
          if (i != -1) {
            let statementObject = this.statementPrintData[i];
            statementObject.Proof_date = value;
            this.statementPrintData[i] = statementObject;
          }
        });

        report_types.forEach((value, key) => {
          let i = this.statementPrintData.findIndex(ele => ele.ApproverId == key);
          if (i != -1) {
            let statementObject = this.statementPrintData[i];
            let report: any = value;
            statementObject.Reports = report.length > 0 ? report : [];
            this.statementPrintData[i] = statementObject;
          }
        })



        console.log(this.statementPrintData);

        this.setupPage();
        this.loadingStatementPrintData = false;

      }).catch(error => {
        this.loadingStatementPrintData = false;
        alert("Unable to Load Data .Please refresh the grid again.");
      });


    }, error => {
      console.error(error.message);
      alert("Unable to Load Data .Please refresh the grid again.");
    })
  }
  setupPage2() {
    this.startIndex = 0;
    this.pageSize = environment.pagesize;
    this.endIndex = this.startIndex + this.pageSize;

  }
  getData() { // Replacing
    this.loadingStatementPrintData = true;
    if (this.startLimit == 0) {
      this.statementPrintData = [];
    }
    this.setupPage2();
    this.approvalObject.ProvId = this.security_service.getClients();
    this.approvalObject.Start = this.startIndex;
    this.approvalObject.Limit = this.pageSize;
    this.statement_service.getApprovalList(this.approvalObject).subscribe(resp => {
      this.totalPage = Math.ceil(resp.TotalCount / this.pageSize);
      if (resp.TotalCount > 0)
        this.currentPage = 1;
      let list: any[] = resp.list;
      let approvalid: any[] = [];

      list.forEach(ele => {
        let status = (ele.Status == 'UnApproved' ? StatusFilter.Unapproved : ele.Status);
        let optionExist: boolean = this.filterOption.filter(opt => opt == status).length > 0;
        if (optionExist == false) {
          this.filterOption.push(status);
        }
        var approveDate = ele.Status == StatusFilter.Approved ? ele.ApprovedDate : "";
        this.statementPrintData.push({
          ZIP_FileName: ele.ZIP_FileName,
          DateSent: ele.DateSent,
          Status: status,
          Proof_date: "N/A",
          Reports: [],
          ApproverId: ele.ApproverId,
          approverDate: approveDate
        });
        approvalid.push(ele.ApproverId);
      });


      this.statement_service.getApprovalInfo(approvalid).toPromise().then(resp => {
        let report = resp[0];
        let proof_date = new Map(Object.entries(report.proofDates))//report.proofDates;
        let report_types = new Map(Object.entries(report.reportTypes));

        proof_date.forEach((value, key) => {
          let i = this.statementPrintData.findIndex(ele => ele.ApproverId == key);
          if (i != -1) {
            let statementObject = this.statementPrintData[i];
            statementObject.Proof_date = value;
            this.statementPrintData[i] = statementObject;
          }
        });

        report_types.forEach((value, key) => {
          let i = this.statementPrintData.findIndex(ele => ele.ApproverId == key);
          if (i != -1) {
            let statementObject = this.statementPrintData[i];
            let report: any = value;
            statementObject.Reports = report.length > 0 ? report : [];
            this.statementPrintData[i] = statementObject;
          }
        });
        console.log(this.statementPrintData);

      }).catch(error => {
        this.loadingStatementPrintData = false;
        alert("Unable to Load Data .Please refresh the grid again.");
      });
      this.setupPage();
      this.loadingStatementPrintData = false;

    }, error => {
      console.error(error.message);
      alert("Unable to Load Data .Please refresh the grid again.");
    })
  }


  setupPage() {
    this.statementPrintDataSet = this.statementPrintData;
    this.filteredStatementPrintData = this.statementPrintDataSet.slice(this.startIndex, this.endIndex);
    this.totalPage = this.totalPage == 0 ? Math.ceil(this.statementPrintDataSet.length / this.pageSize) : this.totalPage;
    if (this.startLimit == 0) {
      this.currentPage = this.totalPage > 0 ? 1 : 0;
    }

  }

  setupPlanPage() {
    this.filteredPlanData = this.planData.slice(this.startIndex1, this.endIndex1);
    this.totalPage1 = Math.ceil(this.planData.length / this.pageSize);
    this.currentPage1 = this.totalPage1 > 0 ? 1 : 0;

  }

  generateLink(reportType: string, id: string) {
    this.statement_service.extractReport(id, reportType).toPromise().then(resp => {
      this.exportToFile(reportType, resp.type, resp);
    })
  }


  selectedOption(index: number) {
    this.selectedIndex = index;
    this.selectAll = false;
    this.isProofGenerated = this.filteredStatementPrintData[this.selectedIndex].Proof_date != ""
    this.filteredPlanData = [];

    if (String(this.filteredStatementPrintData[index].Status) == StatusFilter.Unapproved) {
      this.loadingPlanData = true;
      this.statement_service.getPlans(this.filteredStatementPrintData[this.selectedIndex].ApproverId).toPromise().then(resp => {
        this.planData = resp;
        this.setupPlanPage();
        this.loadingPlanData = false;
      }).catch(error => {

        this.loadingPlanData = false;
      })
    }
  }

  selectedOptionPlans(index: number) {
    this.selectedIndex1 = index;
  }

  isGenerateProof() {
    return;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.pageSize;
      this.currentPage++;

      if ((this.endIndex) >= this.endLimit) {
        this.startLimit = this.endLimit;
        this.endLimit += this.endLimit;
        this.initGetData();
      } else {
        this.filteredStatementPrintData = this.statementPrintDataSet.slice(this.startIndex, this.endIndex);
      }
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.pageSize;
      this.filteredStatementPrintData = this.statementPrintDataSet.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }

  }

  FirstPage() {
    if (this.currentPage > 1) {
      this.startIndex = 0
      this.endIndex = this.startIndex + this.pageSize;
      console.log(this.startIndex + "," + this.endIndex);
      this.filteredStatementPrintData = this.statementPrintDataSet.slice(this.startIndex, this.endIndex);
      this.currentPage = 1;
    }
  }

  LastPage() {
    if (this.currentPage < this.totalPage) {
      this.endIndex = (this.statementPrintDataSet.length);
      this.startIndex = (this.pageSize * (this.totalPage - 1));
      console.log(this.startIndex + "," + this.endIndex);
      this.filteredStatementPrintData = this.statementPrintDataSet.slice(this.startIndex, this.endIndex);
      this.currentPage = this.totalPage;
    }
  }

  refresh() {
    this.setupPage2();
    this.initGetData();
  }
  filterData() {
    let val = this.filterOptions;
    this.approvalObject.StatusFilter = String(this.filterOptions == StatusFilter.Unapproved ? 'UnApproved' : this.filterOptions);
    this.initGetData();
  }

  sort(propertyName: string) {
    this.sortType = propertyName;
    if (this.sortDirection == "ASC") {
      this.sortDirection = "DES";
      switch (propertyName) {
        case 'ZIP_FileName':
          this.filteredStatementPrintData.sort((a, b) => (a.ZIP_FileName < b.ZIP_FileName ? -1 : 1));
          break;
        case 'DateSent':
          this.filteredStatementPrintData.sort((a, b) => (a.DateSent < b.DateSent ? -1 : 1));
          break;
        case 'Status':
          this.filteredStatementPrintData.sort((a, b) => (a.Status < b.Status ? -1 : 1));
          break;
        case 'Proof':
          this.filteredStatementPrintData.sort((a, b) => (a.Proof < b.Proof ? -1 : 1));
          break;
      }
    } else {
      this.sortDirection = "ASC";
      switch (propertyName) {
        case 'ZIP_FileName':
          this.filteredStatementPrintData.sort((a, b) => (a.ZIP_FileName > b.ZIP_FileName ? -1 : 1));
          break;
        case 'DateSent':
          this.filteredStatementPrintData.sort((a, b) => (a.DateSent > b.DateSent ? -1 : 1));
          break;
        case 'Status':
          this.filteredStatementPrintData.sort((a, b) => (a.Status > b.Status ? -1 : 1));
          break;
        case 'Proof':
          this.filteredStatementPrintData.sort((a, b) => (a.Proof > b.Proof ? -1 : 1));
          break;
      }
    }
  }
  checkDisabled() {
    if (this.selectedIndex >= 0) {
      return !(String(this.filteredStatementPrintData[this.selectedIndex].Status) == StatusFilter.Unapproved);
    } else {
      return true;
    }

  }

  openApproveDialogue() {
    if (this.selectedIndex != -1 && !(String(this.filteredStatementPrintData[this.selectedIndex].Status) == StatusFilter.Approved)) {

      this.dialog.open(ApproveComponent, {
        width: '700px', data: {
          approvalId: this.filteredStatementPrintData[this.selectedIndex].ApproverId
        }
      });
    }
  }

  selectAllPlanData() {

    if (this.selectAll) {
      for (var i = 0; i < this.planData.length; i++) {
        this.planData[i].IsDeleted = true;
      }
    } else {
      for (var i = 0; i < this.planData.length; i++) {
        this.planData[i].IsDeleted = false;
      }
    }
  }


  deleteExtractPlan() {
    if (confirm("Are you sure you want to Delete/Restore ?")) {

      let deletePlan = this.planData.filter(ele => ele.IsDeleted == true);
      let deleteoptions: any[] = [];
      deletePlan.forEach(ele => {
        deleteoptions.push(ele.ExternalPlanId);
      })
      let deletePlanObject = deleteObject;
      deletePlanObject.ApprovalId = this.filteredStatementPrintData[this.selectedIndex].ApproverId;
      deletePlanObject.ExtractPlansToDelete = deleteoptions;

      this.statement_service.deletePlans(deletePlanObject).toPromise().then(resp => {
        alert("Approval Delete/Restore Successfully");
      }).catch(error => {

      })

    }


  }

  delete() {
    if (confirm("Are you sure you want to delete?")) {

      this.statement_service.delete(this.filteredStatementPrintData[this.selectedIndex].ApproverId, this.user.UUID).toPromise().then(resp => {
        alert("Approval Deleted Successfully");
        this.refresh();
      }).catch(error => {
        alert("Unable to delete the Plan");
      });
    }
  }

  generateProof() {
    this.statement_service.generateProof(this.filteredStatementPrintData[this.selectedIndex].ApproverId).toPromise().then(resp => {
      alert("Your proof will be available shortly. Please refresh the grid to check for an updated Proof timestamp.");
    }).catch(error => {
      console.error(error);
      alert("Unable to Generate Proof");
    });

  }

  nextPlanPage() {
    if (this.currentPage1 < this.totalPage1) {
      this.startIndex1 = this.endIndex1;
      this.endIndex1 = this.startIndex1 + this.pageSize;
      this.filteredPlanData = this.planData.slice(this.startIndex1, this.endIndex1);
      this.currentPage1++;
    }
  }

  previousPlanPage() {
    if (this.currentPage1 > 1) {
      this.endIndex1 = this.startIndex1;
      this.startIndex1 = this.startIndex1 - this.pageSize;
      this.filteredPlanData = this.planData.slice(this.startIndex1, this.endIndex1);
      this.currentPage1--;
    }

  }

  refreshPlans() {
    this.selectedOption(this.selectedIndex);
  }

  exportToFile(filename: string, type: string, csvContent: string) {

    const blob = new Blob([csvContent], { type: type });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }


}
