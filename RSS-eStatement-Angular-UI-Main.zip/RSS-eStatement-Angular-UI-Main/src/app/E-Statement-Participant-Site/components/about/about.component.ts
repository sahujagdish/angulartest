import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../../services/utility-service/utility.service';
import { SecurityService } from '../../services/security-service/security.service';
import { ProfileService } from '../../services/profile-service/profile.service';
import { findIndex } from 'rxjs/operators';
import { identifierModuleUrl } from '@angular/compiler';
import {  SampleText } from '../../models/ObjectHelper';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {


  promoText: any[] = []
  Communication: any[] = []
  Sample: any[] = []


  constructor(private service: SecurityService,private utility_service:UtilityService,private profile_service:ProfileService) { }

  ngOnInit(): void {
    this.getPromoText();
  }

  getProviderDetails(ProviderID:string){
    this.profile_service.getProviderDetails(ProviderID).toPromise().then(resp=>{
      let SampleStatementIndex = 0;
      SampleStatementIndex = this.Sample.findIndex(value=>value.SampleText==SampleText.ViewSampleeStatement);
      let SampleNewsletterIndex=1;
      SampleNewsletterIndex = this.Sample.findIndex(value=>value.SampleText==SampleText.ViewSampleNewsletter);

      console.log(this.service.getProvider());
      this.Sample[SampleStatementIndex].SampleURL = resp.SamplePath +"News/"+this.Sample[SampleStatementIndex].SampleURL;
    })
  }

  calculateRowheight(){
    return "72vh";
  }

  getCommunicationData(){
    this.utility_service.getPromoText(this.service.getProvider().Id).then(resp=>{
      this.Communication = resp;
    })
  }

  getSampleLinkData(){
    this.utility_service.getSampleText(this.service.getProvider().Id).then(resp=>{
        this.Sample = resp;
        this.getProviderDetails(this.service.getProvider().Id);
      })
  }

  getPromoText(){
    this.utility_service.getLandingPageData(this.service.getProvider().Id,"Promo Text").then(resp=>{
      for(var ele of resp)
        if(ele.Active==true)
          this.promoText.push(ele);
      this.getCommunicationData()
      this.getSampleLinkData();
    }).catch(error=>{

    })
  }


}
