import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';
import { JsonPipe } from '@angular/common';
import { ProfileService } from '../../services/profile-service/profile.service';
import { existingUser, update_user, add_user, Color } from '../../models/ObjectHelper';
import { SecurityService } from '../../services/security-service/security.service';
import { Md5 } from 'ts-md5';
//import {}  from '../../services/CustomValidators/conditionRequired'
@Component({
  selector: 'app-staff-access',
  templateUrl: './staff-access.component.html',
  styleUrls: ['./staff-access.component.css']
})
export class StaffAccessComponent implements OnInit {

  staffaccess!: FormGroup;
  Users: any[] = [];
  User: any = {};
  Profiles: any[] = [];
  HasSensitivePlans: boolean;
  ProviderID: number;
  selectedUser: any = null;
  @ViewChild('passwordstrength') passwordstrength: ElementRef;
  @ViewChild('password_match') password_match: ElementRef;
  @ViewChild('password_strengthLowerString') password_strengthLowerString: ElementRef;
  @ViewChild('password_strengthUpperString') password_strengthUpperString: ElementRef;
  @ViewChild('password_strengthNumber') password_strengthNumber: ElementRef;
  @ViewChild('password_strengthSpecial') password_strengthSpecial: ElementRef;
  @ViewChild('password_strengthLength') password_strengthLength: ElementRef;

  password = new RegExp("(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)");

  constructor(private service: SecurityService, private profile_service: ProfileService, private renderer: Renderer2) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.HasSensitivePlans = this.service.getProviderSettings().hasSensitivePlans;
  }

  ngOnInit(): void {

    this.ProviderID = this.User.ProviderID;

    this.staffaccess = new FormGroup({
      lname: new FormControl('', Validators.required),
      fname: new FormControl('', Validators.required),
      userid: new FormControl('', [Validators.required, Validators.maxLength(10)]),
      password: new FormControl('', Validators.required),
      profileid: new FormControl('', Validators.required),
      HideSensitivePlans: new FormControl(false),
      InternalUser: new FormControl(false, this.ConditionallyRequiredValidator),
      dtnumber: new FormControl('')
    });
    this.getUsers(this.ProviderID);
  }

  ViewRecords(event: any) {
    let value = event.target.value;
    this.selectedUser = this.Users.filter(ele => ele.ControlId == value)[0];
    this.FillForm();
  }

  ConditionallyRequiredValidator(formControl: AbstractControl) {
    if (!formControl.parent) {
      return null;
    }

    formControl.parent.get('InternalUser').valueChanges
      .subscribe(InternalUser => {
        formControl.parent.get('InternalUser').updateValueAndValidity({ emitEvent: false });
        formControl.parent.get('dtnumber').updateValueAndValidity({ emitEvent: false });

        if (formControl.parent.get('InternalUser').value == true) {
          formControl.parent.get('dtnumber').setValidators([Validators.required]);
        } else {
          formControl.parent.get('dtnumber').setValidators([]);
        }
      });
  }

  FillForm() {
    this.staffaccess.patchValue({
      lname: this.selectedUser.ControlName,
      fname: this.selectedUser.FirstName,
      userid: this.selectedUser.UserId,
      password: this.selectedUser.Password,
      profileid: this.selectedUser.ProfileId,
      HideSensitivePlans: this.selectedUser.HideSensitivePlans,
      InternalUser: this.selectedUser.IsInternalUser,
      dtnumber: this.selectedUser.DTNumber
    })
  }

  getUsers(ProviderID: number) {
    this.Users = [];
    this.profile_service.getUsers(String(ProviderID), true, this.HasSensitivePlans).subscribe(resp => {
      this.Users = resp;
      this.getProfiles(String(ProviderID), true);
    }, error => {
      throw new Error(error.error.message);
    })
  }

  getProfiles(ProviderId: string, Active: boolean) {
    this.Profiles = [];
    this.profile_service.getProfiles(ProviderId, Active).subscribe(resp => {
      this.Profiles = resp;
    }, error => {
      throw new Error(error.message);
    })
  }

  Add() {
    this.selectedUser = null;
    this.staffaccess.setValue({
      lname: "",
      fname: "",
      userid: "",
      password: "",
      profileid: "",
      HideSensitivePlans: false,
      InternalUser: false,
      dtnumber: ""
    })
  }

  Update() {
    this.validateStaffAccessFields();
    let strength = 0;

    //console.log(this.staffaccess!.get('password').hasError('required'));

    let password:any = this.staffaccess.get('password');

    if (!password.hasError('required')) {
      if(password!.value == 'PLACEHOLDERVALUE1!') {
        strength = 3;        
      } else {
        strength = this.CheckPasswordStrength();
      }          
    }  
    
    if(this.staffaccess.valid && strength < 3 && password.value.length < 8){
      alert("Password did not match minimum requirement");
      return;
    } 

    if (this.staffaccess.valid && strength > 2) {
      if (this.selectedUser == null) {
        let Add_User = add_user;
        let values = this.staffaccess.value;
        this.profile_service.getAdministratorUserExists(values.userid).toPromise().then(resp => {
          if (resp.length > 0) {
            alert('Username already Exists');
          } else {
            Add_User.control_name = values.lname;
            Add_User.fname = values.fname;
            Add_User.userid = values.userid;
            Add_User.userPassword = new Md5().appendStr(values.password).end();
            Add_User.profileid = values.profileid;
            Add_User.hasSensitivePlans = this.HasSensitivePlans;
            Add_User.hidesensitiveplans = values.HideSensitivePlans;
            Add_User.InternalUser = this.User.IsInternalUser;
            Add_User.isinternaluser = values.InternalUser;
            Add_User.dtnumber = values.dtnumber;
            Add_User.ProviderID = this.ProviderID;
            console.log("adding user Date:")
            console.log(Add_User);
            //    alert(this.ProviderID)
            console.log("user end")
            this.profile_service.AddUser(Add_User).toPromise().then(resp => {
              alert("User Added Successfully");
              this.getUsers(this.ProviderID);
              this.Add();
              this.staffaccess.reset();
            }).catch(error => {
              alert("Unable to Add User.");
            })
          }
        })
      } else {
        let Update_User = update_user
        let values = this.staffaccess.value;
        Update_User.control_id = this.selectedUser.ControlId;
        Update_User.failedAuthAttempts = 0;
        Update_User.control_name = values.lname;
        Update_User.fname = values.fname;
        Update_User.userid = values.userid;
        Update_User.password = values.password;
        Update_User.profileid = values.profileid;
        Update_User.hasSensitivePlans = this.HasSensitivePlans;
        Update_User.hidesensitiveplans = values.HideSensitivePlans;
        Update_User.InternalUser = this.User.IsInternalUser;
        Update_User.isInternalUser = values.InternalUser;
        Update_User.dtnumber = values.dtnumber;
        this.profile_service.updateUser(Update_User, String(this.ProviderID)).toPromise().then(resp => {
          alert("User Updated Successfully");
          this.getUsers(this.ProviderID);
          this.Add();
          this.staffaccess.reset();
        }).catch(error => {
          if (error.error.text == "updated") {
            alert("User Updated Successfully");
            this.getUsers(this.ProviderID);
          } else {
            alert("Unable to Update User" + error.message);
          }
        })
      }
    }
  }

  Delete() {
    if (confirm('Are you sure you want to delete this record?')) {
      this.profile_service.DeleteUser(this.selectedUser.ControlId).toPromise()
      alert("User Deleted Successfully");
      this.getUsers(this.ProviderID);
      this.Add();
    }
  }

  CheckPasswordStrength() {

    let password = this.staffaccess.get('password').value;
    //if textBox is empty
    if (password.length == 0) {
      this.passwordstrength.nativeElement.innerHTML = "";
    }

    //Regular Expressions
    var regex = new Array();
    regex.push("[A-Z]"); //For Uppercase Alphabet
    regex.push("[a-z]"); //For Lowercase Alphabet
    regex.push("[0-9]"); //For Numeric Digits
    regex.push("[$@$!%^*#?&][^0-9]"); //For Special Characters

    let passed = 0;
    debugger;
    //Validation for each Regular Expression
    for (var i = 0; i < regex.length; i++) {
      if ((new RegExp(regex[i])).test(password)) {
        console.log(passed);
        passed++;
      }
    }

    //Display of Status
    var color = "";
    var passwordStrength = "";
    //Validation for Length of Password
    if (passed > 2 && password.length > 8) {
      this.password_match.nativeElement.style.color = Color.Green;
      passed++;
    } else {
      this.password_match.nativeElement.style.color = Color.Red;
    }

    if ((new RegExp("[a-z]")).test(password)) {
      this.password_strengthLowerString.nativeElement.style.color = Color.Green;
    } else {
      this.password_strengthLowerString.nativeElement.style.color = Color.Red;
    }

    if ((new RegExp("[A-Z]")).test(password)) {
      this.password_strengthUpperString.nativeElement.style.color = Color.Green;
    } else {
      this.password_strengthUpperString.nativeElement.style.color = Color.Red;
    }

    if ((new RegExp("[0-9]")).test(password)) {
      this.password_strengthNumber.nativeElement.style.color = Color.Green;
    } else {
      this.password_strengthNumber.nativeElement.style.color = Color.Red;
    }

    if ((new RegExp("[$@$!%^*#?&]")).test(password)) {
      this.password_strengthSpecial.nativeElement.style.color = Color.Green;
    } else {
      this.password_strengthSpecial.nativeElement.style.color = Color.Red;
    }

    switch (passed) {
      case 0:
        break;
      case 1:
        passwordStrength = "Password is Weak.";
        color = Color.Red;
        break;
      case 2:
        passwordStrength = "Password is Weak.";
        color = Color.Red;
        break;
      case 3:
        passwordStrength = "Password is Good.";
        color = Color.Orange;
        break;
      case 4:
        passwordStrength = "Password is Strong.";
        color = Color.Green;
        break;
      case 5:
        passwordStrength = "Password is Strong.";
        color = Color.DarkGreen;
        break;
    }
    this.passwordstrength.nativeElement.innerHTML = passwordStrength;
    this.passwordstrength.nativeElement.style.color = color;
    console.log(passed);
    return passed;
  }

  validateStaffAccessFields() {
    Object.keys(this.staffaccess.controls).forEach(field => {
      const control = this.staffaccess.get(field);

      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      }
    });
  }
}
