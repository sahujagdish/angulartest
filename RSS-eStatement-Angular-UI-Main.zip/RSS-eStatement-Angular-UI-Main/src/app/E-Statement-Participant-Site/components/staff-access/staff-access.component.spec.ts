import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffAccessComponent } from './staff-access.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('StaffAccessComponent', () => {
  let component: StaffAccessComponent;
  let fixture: ComponentFixture<StaffAccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffAccessComponent ],
      imports:[HttpClientModule,RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
