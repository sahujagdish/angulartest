import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ReportService } from '../../services/report-service/report.service';
import { audit_repot, planlist } from '../../models/ObjectHelper';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { IColumnInfo, TableComponent } from '../table/table.component';
import { DatePipe } from '@angular/common';
import { IUser, Role } from '../../models/User';
import { PlanDropDownComponent } from '../plan-drop-down/plan-drop-down.component';

@Component({
  selector: 'app-audit-report',
  templateUrl: './audit-report.component.html',
  styleUrls: ['./audit-report.component.css']
})
export class AuditReportComponent implements OnInit {

  ColumnList: Array<IColumnInfo> = [
    { Property: "AuditDate", Header: "Date", SortProperty: "auditDate" },
    { Property: "FirstName", Header: "First Name", SortProperty: "fname" },
    { Property: "LastName", Header: "Last Name", SortProperty: "lname" },
    { Property: "SSN", Header: "SSN", SortProperty: "ssn" },
    { Property: "AuditDescription", Header: "Audit Report", SortProperty: "auditDesc" },
    { Property: "PlanNumber", Header: "Plan Code", SortProperty: "planNumber" }];

  FilteredPlanList: any[] = [];
  PlanList: any[] = [];

  errorStatus: boolean = false;
  AuditObject: any;

  AuditDataService: any;
  AuditDownloadService: any;
  AuditTypes: any[] = [];

  Provider!: string;
  dt = new Date();
  toDate = this.datePipe.transform(this.dt, 'yyyy-MM-dd');
  fromDt = this.dt.setDate(this.dt.getDate() - 7);
  fromDate = this.datePipe.transform(this.dt, 'yyyy-MM-dd');

  AuditForm: FormGroup = new FormGroup({
    auditType: new FormControl(0),
    planName: new FormControl(''),
    lastName: new FormControl(''),
    ssn: new FormControl('', [Validators.maxLength(11), Validators.minLength(11), Validators.pattern('^[0-9-]+$')]),
    from: new FormControl(this.fromDate),
    to: new FormControl(this.toDate)
  })

  User: IUser = null;

  constructor(public datePipe: DatePipe, public route: Router, public router: ActivatedRoute,
    private report_service: ReportService, download_service: DownloadService,private securityService:SecurityService) {
    this.AuditDataService = report_service.getAuditReports;
    this.AuditDownloadService = download_service.downloadAuditReport;
    this.Provider = String(this.router.snapshot.paramMap.get("participant"));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    if (this.User.Role === Role.Sponsor)
      this.ColumnList = [
        { Property: "AuditDate", Header: "Date", SortProperty: "auditDate" },
        { Property: "FirstName", Header: "First Name", SortProperty: "fname" },
        { Property: "LastName", Header: "Last Name", SortProperty: "lname" },
        { Property: "SSN", Header: "SSN", SortProperty: "ssn" },
        { Property: "AuditDescription", Header: "Audit Type", SortProperty: "auditDesc" }
      ];
  }

  ngOnInit(): void {
    this.loadAuditTypes();
    let prevval = "";
    this.AuditForm.valueChanges.subscribe(resp => {
      let currentval = resp.ssn;
      if (resp.ssn.length == 3 || resp.ssn.length == 6) {
        if (currentval.length >= prevval.length) {
          resp.ssn = resp.ssn + "-";
          this.AuditForm.setValue(resp);
        }
      }
      prevval = currentval;
    });
  }

  resetSearch(table: TableComponent, planDropdown: PlanDropDownComponent = null) {
    table.ResetTable();
    planDropdown?.clearPlanText();
    this.AuditForm.setValue({
      auditType: 0,
      planName: '',
      lastName: '',
      ssn: '',
      from: this.fromDate,
      to: this.toDate
    });
  }


  async getAuditReports(table: TableComponent) {
    if (!this.AuditForm.value.from || !this.AuditForm.value.to!) {
      alert("Please Input To and From Date");
      return;
    }
    if (this.AuditForm.value.auditType < 0 && !this.AuditForm.value.lastName && !this.AuditForm.value.ssn) {
      alert(`You must select either an "Audit Type" or provide "Last Name" or an "SSN".`);
      return;
    }
    this.AuditObject = audit_repot;
    this.AuditObject.AuditCode = this.AuditForm.value.auditType;
    this.AuditObject.PlanNumber = this.AuditForm.value.planName;
    this.AuditObject.LastName = this.AuditForm.value.lastName;
    this.AuditObject.SSN = this.AuditForm.value.ssn;
    this.AuditObject.StartDate = this.AuditForm.value.from;
    this.AuditObject.EndDate = this.AuditForm.value.to;
    this.AuditObject.ProvID = this.User.Provider;
    this.AuditObject.ProviderID = this.User.ProviderID;
    this.AuditObject.ISID = this.User.Role === Role.Sponsor ? this.User.userid : 0;
    await table.InitLoadData(this.AuditObject);
  }

  loadAuditTypes() {
    let provider = this.securityService.getProviderSettings();
    this.report_service.getAuditType(provider.Accept, provider.ValidationCode, provider.AssetRetention, provider.Handshake).toPromise().then(resp => {
      this.AuditTypes = resp;
    });
  }

  handleTableError(event) {
    this.errorStatus = true;
  }

  handlePlanDataBinding = (planList) => {
    return [{ PlanName: "All", PlanNumber: "" }, ...planList];
  }
}
