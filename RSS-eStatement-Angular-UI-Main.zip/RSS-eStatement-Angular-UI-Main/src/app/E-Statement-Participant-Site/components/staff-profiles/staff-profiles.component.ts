import { Component, OnInit } from '@angular/core';
import { debug } from 'console';
import { ProfileService } from '../../services/profile-service/profile.service';

@Component({
  selector: 'app-staff-profiles',
  templateUrl: './staff-profiles.component.html',
  styleUrls: ['./staff-profiles.component.css']
})
export class StaffProfilesComponent implements OnInit {

  User: any;

  Profiles: any[] = [];
  LinksRow1: any[] = [];
  LinksRow2: any[] = [];

  selectedLinks: any[] = [];
  selectedProfileID: string = "";
  selectedProfileType: string = "";

  Successfull: boolean = false;
  onSuccessText: string = "";
  Error: boolean = false;
  onErrorText: string = "";

  constructor(private profile_service: ProfileService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getProfiles(this.User.ProviderID, true);
  }



  getProfiles(ProviderId: string, Active: boolean) {
    this.Profiles=[];
    this.profile_service.getProfiles(ProviderId, Active).subscribe(resp => {
      debugger;
      this.Profiles = resp;
      this.getAllLinks(ProviderId);
    }, error => {
      throw new Error(error.message);
    })
  }

  getAllLinks(ProviderID: string) {
    this.LinksRow1=[];
    this.LinksRow2=[];
    this.profile_service.getAllLinks(ProviderID).subscribe((resp: any[]) => {
      let mid = Math.floor(resp.length / 2);
      //First Half
      for (let i = 0; i < mid; i++) {
        this.LinksRow1.push(resp[i]);
      }
      //Second Half
      for (let j = mid; j < resp.length; j++) {
        this.LinksRow2.push(resp[j]);
      }

    }, error => {
      throw new Error(error.message);
    })
  }

  getLinks() {
    this.profile_service.getLinks(this.User.ProviderID, this.selectedProfileID).subscribe(resp => {
      this.selectedLinks = resp;
    }, error => {
      throw new Error(error.error.message);
    })
  }

  setChecked(selectedLinks: any[], Links: any[]) {
    for (let i = 0; i < selectedLinks.length; i++) {
      let links = selectedLinks[i];
      let link = Links.filter(ele => ele.LinkObject.LinkID == links.PRLI_LinkID);
      if (link.length > 0) {
        let index = Links.indexOf(link[0]);
        link[0].Selected = true;
        Links[index] = link[0];
      }
    }

    return Links;

  }

  isChecked(link: any) {
    let avallink = this.selectedLinks.filter(ele => ele.PRLI_LinkID == link.LinkID);
    return avallink.length > 0;
  }

  selectProfile(event: any) {
    this.selectedProfileID = event.target.value;
    this.selectedProfileType = this.Profiles.filter(ele => ele.ProfileID == this.selectedProfileID)[0].ProfileName;
    this.getLinks();
  }

  AddNewLink() {
    this.selectedProfileType = "";
    this.selectedProfileID = "";
    this.selectedLinks = [];
  }

  deleteProfile() {
    if (this.selectedProfileID != "") {
      if(confirm('Are you sure you want to delete this record?')){
      this.profile_service.deleteProfileLinks(this.selectedProfileID).toPromise().then(resp => {
        this.profile_service.deleteProfile(this.selectedProfileID).subscribe(resp => {
          // this.Successfull=true;
          this.onSuccessText = "Profile Deleted Successfully";
          alert(this.onSuccessText);
          this.onErrorText = "";
          ////////////////////////////////////////////////////////////////////////////////////////////////////////
          this.getProfiles(this.User.ProviderID, true);
          this.AddNewLink();
          
        }, error => {
         // this.Error = true;
          this.onErrorText = "Error in Updating Profile";
          alert(this.Error);
        })
      }).catch(error => {

      })

    }
    }
  }

  // New Added

  AddProfile() {
    this.profile_service.getProfileObject().toPromise().then(resp => {
      let ProfileObject: any = resp;
      ProfileObject.ProviderID = this.User.ProviderID;
      ProfileObject.ProfileName = this.selectedProfileType;
      console.log(ProfileObject);
      this.profile_service.addProfile(ProfileObject).toPromise().then(resp => {
        this.setLinksForNewProfile();
      });
      //
    });



    // this.profile_service.addProfile();
    //this.profile_service.updateProfileLinks();

  }

  setLinksForNewProfile() {
    this.profile_service.getLastProfileID(this.User.ProviderID).toPromise().then(resp => {
      let max_profile_ID = resp;
      let links: string[] = [];
      this.selectedLinks.forEach(link => {
        links.push(String(link.PRLI_LinkID));
      })
      links.push("1");
      links.push("2");
      console.log(links);
      this.profile_service.updateProfileLinks(String(max_profile_ID), links).toPromise().then(resp => {
        this.Profiles.push({ ProfileID: 0, ProfileName: this.selectedProfileType });
        // this.Successfull=true;
        this.onSuccessText = "Profile Added Successfully";
        this.onErrorText = "";
        alert(this.onSuccessText);;
        this.getProfiles(this.User.ProviderID, true);
        this.AddNewLink();
      })
    }).catch(error => {

     // this.Error = true;
      this.onErrorText = "Error in Adding Profile";
      alert(this.Error);
    })
  }

  isSelected(linkID: any, checked: boolean) {
    let link = this.selectedLinks.filter(ele => ele.PRLI_LinkID == linkID);
    if (checked) {
      this.selectedLinks.push({
        PRLI_LinkID: linkID
      });
    } else {
      if (link != undefined) {
        this.selectedLinks.splice(this.selectedLinks.indexOf(link[0]), 1);

      }
    }

    console.log(this.selectedLinks);
  }

  UpdateProfile() {
    this.onErrorText = "";
    debugger;
    if (this.selectedProfileType == "") {
      this.onErrorText = "Profile is required";
    }

    if (this.selectedLinks.length == 0) {
      if (this.onErrorText == "") 
        this.onErrorText = "Atleast one link should be selected";
      else
        this.onErrorText = this.onErrorText + "\nAtleast one link should be selected";
    }

    if(this.onErrorText != ""){
      alert(this.onErrorText);      
      return;
    }

    if (this.selectedProfileType != "") {

      if (this.selectedProfileID == "") {
        let val = this.Profiles.filter(ele => ele.ProfileName == this.selectedProfileType);
        if (val.length == 0) {
          this.AddProfile();
          //this.AddNewLink();
        } else {
          alert("Profile Already exists");
        }
      } else {
        this.profile_service.updateProfile(this.selectedProfileID, this.selectedProfileType, this.User.ProviderID).toPromise().then(resp => {
          this.setupLinksForExisitingProfile();
        });
      }
    }
  }


  setupLinksForExisitingProfile() {
    let links: string[] = [];
    this.selectedLinks.forEach(link => {
      links.push(String(link.PRLI_LinkID));
    })

    if (!links.includes("1")) {
      links.push("1");
    }

    if (!links.includes("2")) {
      links.push("2");
    }

    this.profile_service.deleteProfileLinks(this.selectedProfileID).toPromise().then(resp => {
      this.profile_service.updateProfileLinks(this.selectedProfileID, links).toPromise().then(resp => {
        //this.Successfull=true;
        this.onSuccessText = "Profile Updated Successfully";
        this.onErrorText = "";
        alert(this.onSuccessText);
      }).catch(error => {
        //this.Error = true;
        this.onErrorText = "";
        this.onErrorText = "Error in Updating Profile";
        alert(this.Error);
      })
    }).catch(error => {

    })


  }

}
