import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffProfilesComponent } from './staff-profiles.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('StaffProfilesComponent', () => {
  let component: StaffProfilesComponent;
  let fixture: ComponentFixture<StaffProfilesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffProfilesComponent ],
      imports:[HttpClientModule,RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
