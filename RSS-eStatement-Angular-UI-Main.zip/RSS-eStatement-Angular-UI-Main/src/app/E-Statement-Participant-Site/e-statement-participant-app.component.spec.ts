import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EStatementPaticipantAppComponent } from './e-statement-participant-app.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('EStatementPaticipantAppComponent', () => {
  let component: EStatementPaticipantAppComponent;
  let fixture: ComponentFixture<EStatementPaticipantAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EStatementPaticipantAppComponent ],
      imports:[HttpClientModule,RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EStatementPaticipantAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
