import { Component, OnInit, Inject } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { UtilityService } from '../../services/utility-service/utility.service';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-add-ordered-site-text',
  templateUrl: './add-ordered-site-text.component.html',
  styleUrls: ['./add-ordered-site-text.component.css']
})
export class AddOrderedSiteTextComponent implements OnInit {

  public Editor = ClassicEditor;
  EditorForm: any = {
    editorText: '',
    Header: '',
    Active: false
  };

  constructor(public dialogRef: MatDialogRef<AddOrderedSiteTextComponent>, private utility_service: UtilityService, @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  ngOnInit(): void {

    if (this.data != null) {
      this.setupForm();
    }
  }

  setupForm() {
    this.EditorForm.editorText = this.data.Body;
    this.EditorForm.Header = this.data.Header;
    this.EditorForm.Active = this.data.Active;
  }

  add() {
    this.dialogRef.close({ event: "ADD", data: this.EditorForm });
  }



}
