import { Component, OnInit, Inject } from '@angular/core';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { dates, FileSize, FileType, ProccessUserType, ProcessInfo, Roles } from '../../models/ObjectHelper';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AbstractControl, Form, FormArray, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-enter-process-information',
  templateUrl: './enter-process-information.component.html',
  styleUrls: ['./enter-process-information.component.css']
})
export class EnterProcessInformationComponent implements OnInit {

  dates: any = dates;
  UserData: any[] = [];
  statements: string[] = [];
  response: any = null;
  user: any;
  allParticipantData: any[] = [];
  processData: any = {};
  processStatementForm: FormGroup;
  processAll: boolean = false;
  selectedDateArray: any[] = [];
  isProcessing:Boolean = false;

  constructor(private dialogRef: MatDialogRef<EnterProcessInformationComponent>, private participantService: ParticipantService, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.UserData = this.data.processStatement;
    this.allParticipantData = this.data.allData;
    this.processAll = this.data.processAll;
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
    console.log(this.UserData)
    console.log(this.allParticipantData);
    console.log((this.UserData.length>1 && this.processAll==false)|| (this.allParticipantData.length>1 && this.processAll==true));
    console.log((this.UserData.length==1 && this.processAll==false) || (this.allParticipantData.length==1 && this.processAll==true));

  }

  ngOnInit(): void {

    this.setDateObject();
    this.getDates();
    this.setupForm();

    if ((this.UserData.length==1 && this.processAll==false) || (this.allParticipantData.length==1 && this.processAll==true)) {
      this.processStatementForm.get("fileSize")!.setValue(FileSize.Single, { emitEvent: false });
    }

  }

  setDateObject() {
    var uuids: any[] = [];
    var plan_num: any[] = [];
    let alluids: any[] = [];
    let allplan_nums: any[] = [];

    this.UserData.forEach(data => {
      uuids.push(data.UID);
      plan_num.push(data.PlanNum);
    });

    this.processData.u_uds = uuids
    this.processData.plan_num = plan_num;

    if (this.processAll) {
      this.allParticipantData.forEach(data => {
        alluids.push(data.UID);
        allplan_nums.push(data.PlanNum);
      });

      this.dates.u_uds = alluids;
      this.dates.plan_num = allplan_nums;

    } else {

      this.dates.u_uds = uuids;
      this.dates.plan_num = plan_num;

    }
  }



  setupForm() {
    this.processStatementForm = new FormGroup({
      statementDates: new FormControl('', [Validators.required]),
      fileSize: new FormControl('', [Validators.required]),
      fileType: new FormControl('', [Validators.required]),
      email: new FormArray([])
    });

    let emailArray = this.processStatementForm.get("email") as FormArray;
    for (let i = 0; i < 5; i++) {
      emailArray.push(new FormControl('',[Validators.email]));
    }

    console.log(this.processStatementForm);

    if ((this.UserData.length==1 && this.processAll==false) || (this.allParticipantData.length==1 && this.processAll==true)) {
      this.setupStatementDateChanger(this.processStatementForm.get("statementDates")!);
    }
  }

  setupStatementDateChanger(control: AbstractControl) {
    control.valueChanges.subscribe(value => {
      if(value==""){
        this.selectedDateArray=[];
      }
      this.appendDate(value, control);
    })
  }

  getDates() {
    this.participantService.getDates(this.dates, String(sessionStorage.getItem("token"))).subscribe((resp: any[]) => {
      resp.forEach(dates => {
        this.statements.push(String(dates).split('T')[0])
      })
    })
  }

  ProcessInformation() {
    if (this.processStatementForm.valid) {
      this.isProcessing = true;
      var process = ProcessInfo;
      let formData = this.processStatementForm.value;
      let emailString:string = formData.email.join(' ').trim().split(' ').toString();
      process.Uids = this.processData.u_uds;
      process.PlanNumList = this.processData.plan_num.toString();
      process.PlanNum = this.dates.plan_num[this.dates.plan_num.length - 1];
      process.Email = emailString;
      process.ProvId = String(this.user.ProviderID);
      process.ProviderId = Number(this.user.ProviderID);
      process.StatementDates = formData.statementDates;
      process.IsOutputToFTP = formData.fileType == FileType.FTP ? true : false;
      process.IsSingleFile = formData.fileSize == FileSize.Single ? true : false;
      process.SpadId = this.user.Role == Roles.Sponsor ? this.user.userid : 0;
      process.AdminId = this.user.Role == Roles.Adminstrator ? this.user.userid : 0;
      process.IsProcessAll = this.processAll;
      process.UserType = this.user.Role==Roles.Sponsor?ProccessUserType.Sponsor:ProccessUserType.Administrator;

      this.participantService.processStatements(process, String(sessionStorage.getItem("token"))).toPromise().then(resp => {
        this.response = resp.Message;
        if(resp.Success == false){
          this.response = "Unable to Process Statements . "+resp.Message;
        }
        if(resp.Success && resp.IsMailSent==false){
          this.response = this.response +"Unable to Send Mail";
        }
        this.isProcessing = false;
        alert(this.response);
        this.dialogRef.close();
      }).catch(error => {
        this.response = error.error.Message;
        this.isProcessing = false;
        alert(this.response);
        this.dialogRef.close();
      })


    } else {
      this.processStatementForm.markAllAsTouched();
    }

  }

  appendDate(value: any, control: AbstractControl) {
    if (value != undefined && value != "") {
      if (!this.selectedDateArray.includes(value)) {
        this.selectedDateArray.push(value);
      } else {
        this.selectedDateArray.splice(this.selectedDateArray.indexOf(value), 1);
      }
      let dateString = "";
      this.selectedDateArray.forEach((date: any, index: number) => {
        dateString += (index > 0 ? " , " : "") + date;
      });

      control.setValue(dateString, { emitEvent: false });
    }
  }

  closeDialogue() {
    this.dialogRef.close();
  }

}
