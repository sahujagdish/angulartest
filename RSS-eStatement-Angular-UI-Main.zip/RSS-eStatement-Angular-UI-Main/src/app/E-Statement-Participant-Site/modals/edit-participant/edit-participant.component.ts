import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-participant',
  templateUrl: './edit-participant.component.html',
  styleUrls: ['./edit-participant.component.css']
})
export class EditParticipantComponent implements OnInit {

  participantData: any;
  participantForm!: FormGroup;
  constructor(private dialogRef: MatDialogRef<EditParticipantComponent>, private participantService: ParticipantService, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.participantData = this.data.partcipant;
    this.participantForm = new FormGroup({
      fname: new FormControl(this.participantData.FName == undefined ? "" : this.participantData.FName,[Validators.required]),
      mi: new FormControl(this.participantData.MI == undefined ? "" : this.participantData.MI),
      lname: new FormControl(this.participantData.LName == undefined ? "" : this.participantData.LName,[Validators.required]),
      email: new FormControl(this.participantData.EMail == undefined ? "" : this.participantData.EMail,[Validators.required,Validators.email]),
      password: new FormControl(this.participantData.password == undefined ? "" : this.participantData.password),
      statuscode: new FormControl(this.participantData.statusname == undefined ? "" : this.participantData.statusname),
      part_id: new FormControl(this.participantData.ParticipantID == undefined ? 0 : this.participantData.ParticipantID),
      acctnumber: new FormControl(this.participantData.AcctNumber == undefined ? "" : this.participantData.AcctNumber),
      setAdmin: new FormControl(true),
      uuid: new FormControl(this.data.uuid == undefined ? "" : this.data.uuid)
    })
  }

  saveInformation() {
    if(this.participantForm.valid){
    this.participantService.updateParticipant(this.participantForm.value, String(sessionStorage.getItem("token"))).toPromise().then(resp => {
      alert("Participant Data Updated Successfully");
      this.dialogRef.close();
      
    })
  }
  }

}
