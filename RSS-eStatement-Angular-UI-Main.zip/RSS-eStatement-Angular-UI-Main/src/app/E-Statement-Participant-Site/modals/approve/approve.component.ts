import { Component, OnInit, Inject } from '@angular/core';
import { StatementService } from '../../services/statement-service/statement.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {

  statementData: string = "<PRE>";
  approvalID: string = "";
  user: any;
  isProcessing: boolean = false;
  error: any = null;
  constructor(private statement_service: StatementService, @Inject(MAT_DIALOG_DATA) public data: any, private security_service: SecurityService, private dialogRef: MatDialogRef<ApproveComponent>) {
    this.approvalID = this.data.approvalId;
    this.user = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {

    this.statement_service.getDataAuditExtractReport(this.approvalID).subscribe(resp => {
      this.statementData += resp;
      this.statementData += "</PRE>";
    }, error => {

    })

  }


  Approve() {
    this.isProcessing = true;
    this.statement_service.approve(this.approvalID, this.security_service.getClients(), this.user.userid).subscribe(resp => {
      alert("The file was approved successfully.");
      this.dialogRef.close();
    }, error => {
      this.error = error;
      this.isProcessing = false;
    })
  }



  print() {
    const popupWin: any | null = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(this.statementData + `
    <button onClick="window.print()" style="margin-left:32px; border:1px grey solid; border-radius:4px;background-color:white;padding:8px 32px;">Print</button>
    `);
    popupWin.document.close();
  }

}
