import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getOrderedTextUtilities(ProviderId: string, ProfileId: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.orderedTextUtilities + "?ProviderId=" + ProviderId + "&ProfileId=" + ProfileId, '').toPromise();
  }
  getOrderedTextUtilitiesOptions(ProviderId: string, ProfileId: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.orderedTextUtilitiesoptions + "?ProviderId=" + ProviderId + "&ProfileId=" + ProfileId, '').toPromise();
  }
  saveOrderedTextUtilities(ProviderId: string, type: string, text: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.save_orderedtext, {
      ProviderId: ProviderId,
      Type: type,
      Text: text
    }).toPromise();
  }
  
  getSiteTextUtilities(ProviderId: string, ProfileId: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.siteTextUtilities + "?ProviderId=" + ProviderId + "&ProfileId=" + ProfileId, '').toPromise();
  }

  saveText(SaveTextObject:any){
    return this.http.post<any[]>(this.eStatementURL + URL.save_text,SaveTextObject).toPromise();
  }

  getLandingPageData(ProviderId:string,Link:string){
    return this.http.post<any[]>(this.eStatementURL + URL.landing_page_data+"?providerId="+ProviderId+"&link="+Link,"").toPromise();
  }

  getNewsletters(ProviderID:string,Platform:string="0"){
    return this.http.post<any[]>(this.eStatementURL + URL.newsletter+"?providerId="+ProviderID+"&platform="+Platform,"").toPromise();
  }
  

  getPromoText(ProviderId:string){
    return this.http.get<any[]>(this.eStatementURL + URL.PromoLinks + "?ProviderID=" + ProviderId).toPromise();
  }

  getSampleText(ProviderId:string){
    return this.http.get<any[]>(this.eStatementURL + URL.SampleLinks + "?ProviderID=" + ProviderId).toPromise();
  }

}


