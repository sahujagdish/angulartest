import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class StatementService {

  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getApprovalList(ApprovalObject: any) {
    return this.http.post<any>(this.eStatementURL + URL.approval_list, ApprovalObject);
  }

  getApprovalInfo(approvalArray: any[]) {
    return this.http.post<any[]>(this.eStatementURL + URL.approval_info, approvalArray);
  }

  getPlans(approvalId: string) {
    return this.http.get<any[]>(this.eStatementURL + URL.plans + "/" + approvalId + "/plans");
  }

  generateProof(approvalId: string) {
    return this.http.get<any[]>(this.eStatementURL + URL.generateProof + "/" + approvalId + "/generateProof");
  }

  extractReport(approvalId: string, reportType: string) {
    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.get<any>(this.eStatementURL + URL.extract_report + "/" + approvalId + "/reports/" + reportType,requestOptions);
  }

  deletePlans(DeleteObject: any) {
    return this.http.post<any>(this.eStatementURL + URL.delete_plan, DeleteObject);
  }

  checkAuditReportPath(ApproverID:string,ProvID:string){
    return this.http.post<any>(this.eStatementURL + URL.audit_report_path+"?approvalId="+ApproverID+"&provId="+ProvID,"");
    }

  delete(approvalId: string, deleteBy: string) {
    return this.http.post<any>(this.eStatementURL + URL.delete + "?approvalId=" + approvalId + "&deleteBy=" + deleteBy, "");
  }

  approve(approvalId: string, provID: string, approvedBy: string) {
    return this.http.post<any>(this.eStatementURL + URL.approve + "?approvalId=" + approvalId + "&provId=" + provID + "&approvedBy=" + approvedBy, "");
  }

  getDataAuditExtractReport(approvalId: string) {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    const requestOptions: Object = {
      headers: headers,
      responseType: 'text'
    }
    return this.http.get<String>(this.MMAPIURL + URL.dataExtractReport + "/" + approvalId + "/reports/1", requestOptions);
  }

  getENotificationData(providerId:string,externalPlanId:string="default"){
    let query = externalPlanId=="default"?"":("?externalPlanId="+externalPlanId)
    return this.http.get<any[]>(this.eStatementURL + URL.e_notification+"/"+providerId+query);  
  }
  sendENotificationPlanData(providerId:string,Planid:string,PlanObject:any){
    return this.http.post<any[]>(this.eStatementURL + URL.e_notification+"/"+providerId+"/enotification/settings/"+Planid,PlanObject);     
  }

  sendENotificationData(providerId:string,PlanObject:any){
    return this.http.put<any[]>(this.eStatementURL + URL.e_notification+"/"+providerId+"/provider",PlanObject);     
  }

  getStatementsDataAdmin(StatementObject:any){
    return this.http.post<any>(this.eStatementURL + URL.statement+"/admin",StatementObject);       
  }
  
  getStatementsDataPar(StatementObject:any){
    return this.http.post<any>(this.eStatementURL + URL.statement+"/participant",StatementObject);       
  }
  
  getStatementsDataSpon(StatementObject:any){
    return this.http.post<any>(this.eStatementURL + URL.statement+"/sponsor",StatementObject);       
  }

  downloadStatementFile(FilePath:string){
    return this.http.get<any>(this.eStatementURL + URL.downloadFile+"?partialFileName="+FilePath);         
  }

  
}
