import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class DownloadService {
  
  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  downloadStatementPDF = (PartialFileName:string,FileStoreType:string) => {

    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.get<any>(this.eStatementURL + URL.download_statement+"?partialFileName="+PartialFileName+"&storeType="+FileStoreType,requestOptions);
  }

  downloadAuditReport = (AuditObject: any) => {
    return this.http.post<any>(this.eStatementURL + URL.download_Audit_Report, AuditObject);
  }

  downloadUserReport = (UserObject: any) => {
    return this.http.post<any>(this.eStatementURL + URL.download_User_Report, UserObject);
  }

  
  downloadViewStatementPDF = (query: any) => {

    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.get<any>(this.eStatementURL + URL.download_statement+"?"+query, requestOptions);
  }
}
