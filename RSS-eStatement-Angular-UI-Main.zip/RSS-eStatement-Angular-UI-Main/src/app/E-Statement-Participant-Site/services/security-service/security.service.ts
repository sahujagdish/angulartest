import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { URL } from '../../models/URLHelper';
import { environment } from '../../../../environments/environment';
import { isGeneratedFile } from '@angular/compiler/src/aot/util';
import { Roles, SiteRole } from '../../models/ObjectHelper';
import { retry } from 'rxjs-compat/operator/retry';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {

  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  private Client: string = "";
  private UserType: string = "";
  private Provider: any = {}; 
  private ProviderSettings:any={};
  private Role:any=""; 
  public CurrentPage:any="";
  private Links:any[]=[];
  constructor(private http: HttpClient) { }


  //API calls

  changePassword(passwordObject: any, token: string) {
    return this.http.post(this.eStatementURL + URL.changePassword, passwordObject).toPromise();
  }

  AuthToken(tokenObject: any) {
    return this.http.post<any>(this.eStatementURL + URL.auth, tokenObject,{responseType:'json'});
  }

  CheckActiveProvider(ProviderID: string) {
    return this.http.post<any>(this.eStatementURL + URL.validate_provider + "?provider=" + ProviderID, "");
  }

  GetAssignedProviderSites(ProviderID: string){
    return this.http.post<any[]>(this.eStatementURL + URL.provider_assigned_site + "?provider=" + ProviderID, "");   
  }

  getUserDetails(UserId:string,Role:string,ProviderID:string){
    let role = "";
    switch(Role){
      case Roles.Adminstrator:
            role=SiteRole.Admin;
            break;
      case Roles.Participant:
            role=SiteRole.Par;
            break;
      case Roles.Sponsor:
            role=SiteRole.Spon;
            break;              
    }
    return this.http.post<any>(this.eStatementURL + URL.user_details + "?userid=" + UserId+"&role="+role+"&providerId="+ProviderID,"");   
  }

  getAdminLinks(ProviderID:string,ProfileID:string){
    return this.http.get<any>(this.eStatementURL + URL.admin_links + "?providerId=" + ProviderID+"&profileId="+ProfileID);   
  }

  getParLinks(ProviderID:string){
    return this.http.get<any>(this.eStatementURL + URL.par_links + "?providerId=" + ProviderID);   
  }

  getSponLinks(ProviderID:string,spadId:string){
    return this.http.get<any>(this.eStatementURL + URL.spon_links+"?providerId=" + ProviderID+"&spadId="+spadId);   
  }

  updateTimeStamp(userid:string,Role:string){
    let role = "";
    switch(Role){
      case Roles.Adminstrator:
            role=SiteRole.Admin;
            break;
      case Roles.Participant:
            role=SiteRole.Par;
            break;
      case Roles.Sponsor:
            role=SiteRole.Spon;
            break;              
    }
    return this.http.post<any>(this.eStatementURL + URL.lastLogin+"?id=" + userid+"&role="+role,"");   
  }

  getCaptchaDetails(){
    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'image/png',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob',
      observe:'response'
    }

    let captchaCount = environment.captchaLength;
    return this.http.get<any>(this.eStatementURL + URL.captchaProvider+"?capchaCount="+captchaCount,requestOptions);   

  }

  validateCaptcha(inputValue:string,captchaValue:string){
    return this.http.get<boolean>(this.eStatementURL + URL.captchaValidator+"?inputCaptcha="+inputValue+"&captchaCode="+captchaValue);   
  }


  //Getter Setter functions

  getRole(){
    return this.Role;
  }

  setRole(role:string){
    this.Role = role;
  }

  getClients() {
    return this.Client;
  }
  getUserType() {
    return this.UserType;
  }

  getProvider() {
    return this.Provider;
  }

  setProvider(provider: any) {
    this.Provider = provider;
  }

  getProviderSettings() {
    return this.ProviderSettings;
  }

  setProviderSettings(providerSettings: any) {
    this.ProviderSettings = providerSettings;
  }
  setClients(Client: string) {
    this.Client = Client;
  }
  setUserType(UserType: string) {
    this.UserType = UserType;
  }

 

  setLinks(Links:any[]){
    this.Links = Links;
  }
  getLinks(){
    return this.Links;
  }

}
