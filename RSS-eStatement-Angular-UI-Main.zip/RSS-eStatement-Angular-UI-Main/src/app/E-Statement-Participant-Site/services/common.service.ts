import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
  })
export class CommonService {
    formateDate(datetime:any){   
        let date = new Date(datetime);
        var isPM = date.getHours() >= 12;
        return ("0" + date.getDate()).slice(-2) + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" +
        date.getFullYear() + " " + ("0" + date.getHours()).slice(-2) + ":" + ("0" + date.getMinutes()).slice(-2)+ " " +  (isPM ? ' PM' : 'AM');
    }
    formatDateinmonthDayformat(lastLoginDate:Date):string{
    var month:string[] = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    var weekday:string[] = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

        return String(weekday[lastLoginDate.getDay()]+" "+month[lastLoginDate.getMonth()]+" "+lastLoginDate.getDate()+", "+ lastLoginDate.getFullYear());
    }
}