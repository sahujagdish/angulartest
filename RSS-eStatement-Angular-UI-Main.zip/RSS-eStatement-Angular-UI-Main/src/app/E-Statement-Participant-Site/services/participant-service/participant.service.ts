import { Injectable } from '@angular/core';
import { URL } from '../../models/URLHelper';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  search(searchSettings: any, token: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.search, searchSettings);
  }

  isEditable(useSSN: boolean, providerID: string, provID: string, uuid: string, token: string) {
    return this.http.post<any>(this.eStatementURL + URL.editable + "?useSSN=" + useSSN + "&providerid=" + providerID + "&provid=" + provID + "&uid=" + uuid, '');
  }

  getDates(Dates: any, token: any) {
    return this.http.post<any[]>(this.eStatementURL + URL.dates, Dates);
  }

  getParticipantData(ParticipantObject: any, token: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.participant, ParticipantObject);
  }

  updateParticipant(ParticipantObject: any, token: string) {
    return this.http.patch(this.eStatementURL + URL.participant, ParticipantObject);
  }
  processStatements(ProcessObject: any, token: string) {
    return this.http.post<any>(this.eStatementURL + URL.process, ProcessObject);
  }

  getStatements(SearchObject: any, token: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.ss_ident_partid, SearchObject);
  }

  updateProfile(ProfileObject: any, token: string) {
    return this.http.put(this.eStatementURL + URL.participant, ProfileObject);
  }

  getPlanList(PlanList: any, token: string) {
    return this.http.post<any[]>(this.eStatementURL + URL.plan_list, PlanList);
  }

  getSponPlanName(ISID:string){
    return this.http.post<any[]>(this.eStatementURL + URL.sponsor_plan_list+"?ISID="+ISID,"");
  }

  unsubscribe(ParticipantID:string,providerID:string){
    return this.http.post<any>(this.eStatementURL + URL.participant_unsubscribe+"?iPID="+ParticipantID+"&providerId="+providerID, "");  
  }

  loadSponsorData(SPAD_ID:string){
    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'text/plain',
          'responseType': 'text'
        }
      ),
      responseType: 'text'
    }
    return this.http.get<string>(this.eStatementURL + URL.sponsor_name+"?spadID="+SPAD_ID,requestOptions);  
  }

  /* Register Page Services */

  createParticipant(participantObject:any){
    return this.http.put<any>(this.eStatementURL + URL.participant, participantObject);  
  }

}
