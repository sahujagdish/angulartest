import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class SponsorService {

  private eStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  /* Service Calls for Sponsor Search Section */
  
  searchSponsor(SearchObject){
    return this.http.post<any>(this.eStatementURL+URL.sponsor_select,SearchObject).toPromise();
  }

  /* Service Calls for Sponsor Links Section */

  getAllLinks(ProviderID:string){
    return this.http.get<any>(this.eStatementURL+URL.sponsor_all_links+"?providerId="+ProviderID).toPromise();
  }
  
  getSponsor(SponID:number){
    return this.http.get<any>(this.eStatementURL+URL.sponsor+"?spon_id="+SponID).toPromise();
  }

  getSponsorSelectedLinks(SponID:number,ProviderID:string){
    return this.http.get<any>(this.eStatementURL+URL.selected_links+"?spon_id="+SponID+"&providerId="+ProviderID).toPromise();
  }

  updateSponsorLinks(LinkObject:any){
    return this.http.post<any>(this.eStatementURL+URL.update_links,LinkObject).toPromise();
  }

  /* Service Calls for Sponsor Profiles Section */
   
  getProfiles(SponID:number,isProfileActive:string){
    return this.http.get<any>(this.eStatementURL+URL.sponsor_profile+"?sppf_spon_id="+SponID+"&boolCondition="+isProfileActive).toPromise();
  }

  getProfileAllLinks(SponID:number){
    return this.http.get<any>(this.eStatementURL+URL.sponsor_profile_allLinks+"?spad_spon_id="+SponID).toPromise();
  }

  getProfileSelectedLinks(SponID:number,ProfileID:string){
    return this.http.get<any>(this.eStatementURL+URL.sponsor_profile_selectedLinks+"?sponId="+SponID+"&sppfId="+ProfileID).toPromise();
  }

  updateSponsorProfile(ProfileObject:any,sponID:string){
    return this.http.post<any>(this.eStatementURL+URL.update_profile+"?sponID="+sponID,ProfileObject).toPromise();
  }

  /* Service Calls for Sponsor Administrator */

  getSponsorAdministrators(SponID,IsSponActive,ProviderID){
    return this.http.post<any>(this.eStatementURL+URL.sponsor_admin,
      {
        SponID:SponID,
        IsSponActive:IsSponActive,
        ProviderID:ProviderID
      }).toPromise();   
  }

  updateSponsorAdmin(AdminObject:any,providerID:string){
    return this.http.put<any>(this.eStatementURL+URL.sponsor_admin+"?providerId="+providerID,AdminObject).toPromise();
  }


}
