import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export class CustomValidations{

    static checkPasswordsCustom: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
      let pass = control!.value;
      let count: number = 0;
     if(pass!='' && pass!=null){
      if (pass.match('[A-Z]'))
        count++;
      if (pass.match('[a-z]'))
        count++;
      if (pass.match('[0-9]'))
        count++;
      if (pass.match('\\W+'))
        count++;
      if(pass=="")
        return null;
     }
  
      if (count<3) {
        return { "customPattern": true };
      } else {
        return null;
      }
  
    }

      static comparePassword(passwordControlName:string,confirmPasswordControlName:string){
        return (group: AbstractControl): ValidationErrors | null => {
        let pass = group.get(passwordControlName)!.value;
        let confirmPass = group.get(confirmPasswordControlName)!.value;
        return pass === confirmPass ? null : { "notSame": true }
      }
    }
}