export interface IUser{
    userid: string;
    Role: string;
    Provider: string;
    ProviderID: number;
} 
export class AdminUser implements IUser {
    userid: string = "";
    Role!: string;
    Provider!: string;
    ProviderID: number = 0;
    ProviderName: string = "";
    LastLogin: string;
    UUID: string ;
    ProfileId: string;
    IsInternalUser:boolean = false;
    HideSensitivePlans:boolean=false;
}

export class ParUser implements IUser {
    Role!: string;
    Provider!: string;
    ProviderID: number = 0;
    ProviderName: string = "";
    PartUUID:string;
    PartId:string;
    LastLogin: string;
    userid:string
}

export class SponUser implements IUser {
    Role!: string;
    Provider!: string;
    ProviderID: number = 0;
    ProviderName: string = "";
    UID:string;
    ISIN:string;
    PlanID:string;
    LastLogin: string;
    userid:string
}

export const Role = {
    Administrator: "admin",
    Participant: "par",
    Sponsor: "spon"
}
