import { ValidatorFn, Validators } from "@angular/forms"
import { CustomValidations } from "./CustomValidation"

export let search = {
  ProvID: "",
  SPartID: "",
  Lname: "",
  SponPlans: "",
  PlanName: "",
  BSponsor: true,
  ProviderID: 0,
  ISID: 0,
  Start: 0,
  Limit: 20,
  SortField: "lname",
  SortDir: "ASC",
  AdminID: 0,
  SpadID: 0,
  SpadSponID: 0,
  UseSSNPin: 0,
  BAssetRetention: true,
  BSuperSponsor: true,
  AccessCode: "",
  AgentID: "",
  HideSensitivePlans: true
}

export let dates = {
  prov_id: "nyha",
  u_uds: [],
  plan_num: []
}

export let participant = {
  providerID: 63,
  useSSNPin: 2,
  uid: "",
  parUUID: "",
  ParticipantID: 0,
}

export let ProcessInfo = {
  Uids: [],
  ProviderId: 0,
  StatementDates: "",
  IsOutputToFTP: false,
  IsProcessAll: false,
  IsSingleFile: false,
  Email: "",
  SpadId: 0,
  AdminId: 0,
  PlanNum: "",
  PlanNumList: "",
  ProvId: "",
  NeptuneCustNo: "",
  UserType: "",
  IsSuperSponsor: false,
  AssetRetention: false,
  HideSensitivePlans: false,
  UseSSNPin: 0,
  PartId: "",
  FirstName: "",
  LastName: "",
  NameList: "",
  AgentID: ""
}

export let audit_repot = {
  ProviderID: "",
  AuditCode: 0,
  StartDate: "",
  EndDate: "",
  QueryType: "report",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  SSN: "",
  AccountNumber: "",
  Start: 0,
  Limit: 20,
  SortField: "auditDate",
  SortDirection: "DESC",
  HideSensitivePlans: 0,
  ProvID: ""
}


export let user_repot = {
  ProviderID: "",
  StatusCode: "",
  QueryType: "report",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  Start: 0,
  Limit: 20,
  SortField: "lname",
  SortDirection: "DESC",
  HideSensitivePlans: 0,
  ProvID: ""
}

export let profile = {
  ssn: "",
  account_number: "",
  fname: "",
  mi: "",
  lname: "",
  email: "",
  userid: "",
  password: "",
  statuscode: "",
  vcode: "",
  participantuuid: "",
  providerid: 0,
  isRegSite: true
}
export let profilesPart = {
  fname: "",
  mi: "",
  lname: "",
  email: "",
  password: "",
  statuscode: "sring",
  part_id: 0,
  acctnumber: "",
  setAdmin: true,
  uuid: ""
}

export let planlist = {
  ProviderID: 0,
  AdminID: 0,
  PlanName: "",
  HideSensitivePlans: false
}

export let statementlist = {
  Start: 0,
  Limit: 20,
  SortDirection: "ASC",
  SortField: "Lname",
  ProvID: 0,
  UseSSNPin: 0,
  PartID: "",
  LastName: "",
  SponsorPlans: "",
  PlanName: "",
  IsSponsor: true,
  IsAssetRetention: true,
  ProviderID: 0,
  IsSuperSponsor: true,
  AccessCode: "",
  AgentID: "",
  ISID: 0,
  HideSensitivePlans: 0,
  TotalCount: 0
}

export let approval_list = {
  Start: 0,
  Limit: 5,
  SortDirection: "ASC",
  SortField: "",
  ProvId: "",
  StatusFilter: "All",
  Year: 0,
  Quarter: 0
}

export let deleteObject = {
  ApprovalId: 0,
  ExtractPlansToDelete: [""]
}

export interface Documents {
  Name: string;
  documents: any[];
}

export let planeNotification = {
  utilityType: "",
  emailbody: "",
  fromaddress: "",
  fromname: ""
}

export let existingUser = {
  userid: "",
  userPassword: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  isInternalUser: true,
  fname: "",
  profileid: 0,
  ProviderID: 0,
  hidesensitiveplans: true,
  isinternaluser: true,
  hasSensitivePlans: true
}

export let saveText = {
  ProviderId: 0,
  Type: "",
  Subject: "",
  Text: "",
  IPId: 0
}

export let eNotification = {
  utilityType: "",
  emailbody: ""
}

export let statement_admin = {
  UID: "",
  VirtualDir: "",
}

export let statement_par = {
  VirtualDir: "",
  ParticipantId: 0
}

export let statement_spon = {
  ProviderId: 0,
  SpadId: 0,
  UID: ""
}

export let downloadPDF = {
  ProviderId: 0,
  PlanNum: "",
  UID: "",
  PartId: "",
  Date: "",
  FileName: ""
}

export let downloadAudit = {
  ProviderID: 0,
  AuditCode: 0,
  StartDate: "",
  EndDate: "",
  QueryType: "",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  SSN: "",
  AccountNumber: "",
  Start: 0,
  Limit: 0,
  SortField: "",
  SortDirection: "",
  HideSensitivePlans: 0,
  ProvID: "",
  UseSSNPin: 0
}

export let saveTextObject = {
  ProviderId: 0,
  Type: "",
  Subject: "",
  Text: "",
  IPId: 0
}


export let update_user = {
  control_id: 0,
  userid: "",
  password: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  isInternalUser: true,
  fname: "",
  profileid: 0,
  hidesensitiveplans: true,
  passwordEditByAdmin: true,
  InternalUser: true,
  hasSensitivePlans: false
}

export let add_user: any = {
  userid: "",
  userPassword: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  InternalUser: true,
  fname: "",
  profileid: 0,
  ProviderID: 0,
  hidesensitiveplans: true,
  isinternaluser: true,
  hasSensitivePlans: false
}


export enum FileStoreType {
  DefaultFolder = 'DefaultFolder',
  IndividualPDF_Path = 'IndividualPDF_Path',
  PDF_Path = 'PDF_Path',
  AuditReportsDirPath = 'AuditReportsDirPath',
  SummaryReportPath = 'SummaryReportPath'
}

export enum ProccessUserType {
  Administrator = "admin",
  Sponsor = "sponsor"
}

export enum StatusFilter {
  Unapproved = 'Unapproved',
  Approved = 'Approved'
}

export enum HeaderType {
  Statements = 'Statement',
  Communication = 'View Communication',
  PersonalizedInformation = 'Personalized Information',
  MyDocuments = 'Documents'
}

export enum SearchCode {
  PlanName = 'PN',
  PlanCode = 'PC',
  LastName = 'PLN'
}

export enum SampleText {
  ViewSampleeStatement = "View Sample eStatement",
  ViewSampleNewsletter = "View Sample Newsletter"
}

export enum Roles {
  Adminstrator = 'admin',
  Participant = 'par',
  Sponsor = 'spon'
}

export enum SiteRole {
  Admin = 'administrator',
  Par = 'participant',
  Spon = 'sponsor'
}

export enum Color {
  Green = "Green",
  Red = "Red",
  Orange = "Orange",
  DarkGreen = "darkgreen"
}

export let changePasswordObject: any = {
  UniqueId: 0,
  Current_pass: "",
  New_pass: "",
  InitialLogin: true,
  TargetType: ""
}
export enum SponsorType {
  One = 1,
  Two = 2,
  Three = 2,
}

export enum SponsorLinkState {
  initiated = "init",
  success = "success",
  failed = "failed"
}

export enum OperationType {
  Add = "Add",
  Update = "Update",
  Delete = "Delete"
}

export enum SponsorProfileOptions {
  Active = "True",
  InActive = "False",
  Skip = "Skip"
}

export enum FileSize {
  Single = "single",
  Multiple = "multiple"
}


export enum FileType {
  Repository = "repo",
  FTP = "ftp"
}

export let sponsorAccessSearch = {
  SpadID: 0,
  PlanNum: "",
  ProviderID: 0,
  SponName: "",
  SponNum: "",
  IsSponActive: true,
  IsHideSensitivePlans: true,
  ISID: 0
}

export let sponsorProfileObject = {
  ControlID: 0,
  ControlName: "string",
  Active: true,
  Updated: true,
  SponsorLinkIDs: []
}

export let sponsorProfileLinkObject = {
  SpliID: 0,
  Active: true
}

export let newProfile = {
  SppfID: 0,
  SppfName: "",
  SppSponID: 0,
  Active: true,
  Updated: true
}

export let sponAdminObject = {
  SponID: 0,
  IsSponActive: true,
  ProviderID: 0
}

export let newSponsorObject = {
  ControlID: 0,
  SpadUserID: "",
  SpadPassword: "",
  ControlName: "",
  DTNumber: "",
  IsInternalUser: false,
  SpadFName: "",
  SpadSppfID: null,
  SpadNum: "",
  SpadEMail: "",
  Updated: true,
  Active: true,
  SpadAgentID: "",
  SpadSponId: 0
}


export let sponAdminValidation: Map<string, ValidatorFn[]> = new Map([
  ["ControlName", [Validators.required]],
  ["SpadFName", [Validators.required]],
  ["SpadEMail", [Validators.required, Validators.email]],
  ["SpadUserID", [Validators.required]],
  ["SpadPassword", [Validators.required]],
  ["SpadSppfID", [Validators.required]],
])

