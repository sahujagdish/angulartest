export class RegisterParticipant{
    ssn= "";
    account_number="";
    fname= "";
    mi= "";
    lname= "";
    email= "";
    userid= "";
    password= "";
    statuscode= "";
    vcode= "";
    participantuuid= "";
    providerid= 0;
    isRegSite= true;
  }