export class SearchStatementRepo {
  
    SSIdentRequest= {
      SearchBy: "",
      PartList: [],
      PlanName: "",
      ProvID: "",
      IsSponsor: false,
      Start: 0,
      Limit: 0
    }
    SearchRequest= {
      ProvID: "",
      PartID: "",
      LName: "",
      PlanName: "",
      IsSponsor: false,
      ProviderID: 0,
      Start: 0,
      Limit: 0,
      SortField: "lname",
      SortDir: "ASC",
      AdminID: 0,
      SpadID: 0,
      UseSSNPin: 0, //autofilled
      IsAssetRetention: false, //autofilled
      IsSuperSponsor: false, //autofilled
      AccessCode: "", //not required
      AgentID: "", //autofilled
      SpadSponID: 0, //autofilled
      HideSensitivePlans: false, //autofilled
      SponPlans: ""
    }
  }
  