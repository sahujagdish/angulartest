import { SponsorType } from "./ObjectHelper";

export class SponsorReportColumns{
    
    private static SponsorTwo = [
        "Sponsor Name",
        "Sponsor Code",
        "Status"
    ];

    private static SponsorThree = [
        "Sponsor Name",
        "Sponsor Code",
        "Plan Code",
        "Status"
    ]

    private static SponsorOne = SponsorReportColumns.SponsorTwo;
    
    static getColumns(Type:number){
        let Columns=[];
        switch(Type){
            case SponsorType.One:
                Columns =  this.SponsorOne;
                break;
            case SponsorType.Two:
                Columns = this.SponsorTwo;
                break;
            case SponsorType.Three:
                Columns = this.SponsorThree;
                break;
        }
        return Columns;
    }

}