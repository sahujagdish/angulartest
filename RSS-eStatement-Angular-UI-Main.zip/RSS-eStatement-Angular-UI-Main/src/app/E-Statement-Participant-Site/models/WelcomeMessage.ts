export let AdminMessage: any[] = [
    { Link: "access-participant-info", Message: "Access the participant information and request & view the statement for a particular participant." },
    { Link: "auditReport", Message: "View and download the Audit report." },
    { Link: "userReport", Message: "View and download the User report." },
    { Link: "staffAccess", Message: "Create the Staff Profile and provide access to the staff." },
    { Link: "staffProfiles", Message: "Manage Staff Profiles" },
    { Link: "summaryReport", Message: "View and download the Summary report." },
    { Link: "sponsor-access", Message: "Manage Sponsor Access." },
    { Link: "statement-print-approval", Message: "View and approve the Proof." },
    { Link: "siteText", Message: "Manage Site text." },
    { Link: "orderedSiteText", Message: "Manage Ordered Site Text." },
    { Link: "statement-repo", Message: "View and download Participant Statements." },
    { Link: "message-board", Message: "Manage Message Board." }

]/*
access-participant-info
auditReport
userReport
staffAccess
staffProfiles
summaryReport
sponsor-access
statement-print-approval
siteText
orderedSiteText
statement-repo
message-board
*/
export let ParMessage: any[] = [
    { Link: "view-Statements", Message: "View the Statements." },
    { Link: "update-profile", Message: "Update Profile." },
    { Link: "unsubscribe", Message: "Unsubscribe from Electronic Statement service." },
    { Link: "newsletter", Message: "View the Newsletters." },
    { Link: "disclosure", Message: "View the Disclosure." },
    { Link: "faq", Message: "View the Frequently Asked Questions." },

]
/*
view-Statements
update-profile
unsubscribe
newsletter
disclosure
faq
*/
export let SponMessage: any[] = [
    { Link: "access-participant-info", Message: "Access the participant information and request & view the statement for a particular participant." },
    { Link: "summaryReport", Message: "View and download the Summary Report." },
    { Link: "update-profile", Message: "Update Profile" },
    { Link: "auditReport", Message: "View and download the Audit Report." },
    { Link: "userReport", Message: "View and download the User Report." },
    { Link: "statement-repo", Message: "View and download Participant Statements." },

]
/*
access-participant-info
summaryReport
update-profile
auditReport
userReport
statement-repo
*/



export let Message: Map<string, any> = new Map([
    ["admin", AdminMessage],
    ["par", ParMessage],
    ["spon", SponMessage]
])
