import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {MatIconModule} from '@angular/material/icon';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatTreeModule} from '@angular/material/tree';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { EStatementPaticipantAppComponent } from './e-statement-participant-app.component';
import { IntroPageComponent } from './components/intro-page/intro-page.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import {MatDialogModule} from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { HelpModule } from '../Help/help-app.module';
import { EStatementParticipantRoute } from './e-statement-participant-app.routing';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { HttpInterceptorService } from './services/Interceptors/Http-Interceptor.interceptor';
import {MatGridListModule} from '@angular/material/grid-list';
import { RegisterComponent } from './components/register/register.component';
import { AboutComponent } from './components/about/about.component';
import { AbouteStatementsComponent } from './components/aboute-statements/aboute-statements.component';
import { AbouteCommunicationsComponent } from './components/aboute-communications/aboute-communications.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { OAuthModule } from 'angular-oauth2-oidc';
import { HomePageModule } from './components/home-page/home-page.module';
import { LoginModule } from './components/intro-page/intro-page.module';
import { ErrorPageComponent } from './components/error/error-page/error-page.component';
import { SmbAppModule } from '../smb/smb.app.module';
import { SponsorAccessModule } from './components/sponsor-access/sponsor-access.module';

@NgModule({
  declarations: [EStatementPaticipantAppComponent, RegisterComponent, ErrorPageComponent ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    EStatementParticipantRoute,
    MatIconModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    MatDialogModule ,
    RouterModule,
    CKEditorModule,
    HelpModule ,
    MatAutocompleteModule,
    MatGridListModule,
    MatProgressSpinnerModule,
    HomePageModule,
    LoginModule,
    SmbAppModule,
    OAuthModule.forRoot()
  ],
  exports:[
    CKEditorModule,
    RouterModule
  ],
  providers: [ 
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService,multi:true},
  ]
})
export class EStatementParticipantModule { }