import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderedSiteTextComponent } from '../components/ordered-site-text/ordered-site-text.component';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { UtilityService } from '../services/utility-service/utility.service';
import { Observable } from 'rxjs';
import data from './TestData.json'
describe('OrderedSiteTextComponent', () => {
  let component: OrderedSiteTextComponent;
  let fixture: ComponentFixture<OrderedSiteTextComponent>;
  let spy: any;
  let service: UtilityService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OrderedSiteTextComponent],
      imports: [MatDialogModule, BrowserAnimationsModule, HttpClientModule]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderedSiteTextComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(UtilityService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load ordered Site Text Utilities Data', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      expect(component.UtilitiesData.length).toBeGreaterThan(0);
      expect(component.UtilitiesData.length).toEqual(data.TestData.OrderedSiteText.orderedTextUtilities.length);
    })
  })

  it('should load Utilities Types', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      expect(component.UtilitiesType).toBeGreaterThan(0);
      expect(component.UtilitiesType.length).toEqual(3);
    })
  })

  it('should select Data from table', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      component.selectedType = data.TestData.OrderedSiteText.orderedTextUtilities[0].Type
      component.orderedUtilitySelect();
      expect(component.FilteredUtilitiesData.length).toEqual(1);
    });

  })

  it('should move up', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      component.selectedType = data.TestData.OrderedSiteText.orderedTextUtilities[1].Type
      component.orderedUtilitySelect();
      let TestData = component.FilteredUtilitiesData[1];
      component.moveUp();
      expect(component.FilteredUtilitiesData[0]).toEqual(TestData);
    });
  })

  it('should move down', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      component.selectedType = data.TestData.OrderedSiteText.orderedTextUtilities[1].Type
      component.orderedUtilitySelect();
      let TestData = component.FilteredUtilitiesData[0];
      component.moveDown();
      expect(component.FilteredUtilitiesData[1]).toEqual(TestData);
    });
  })


  it('should not move up', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      component.selectedType = data.TestData.OrderedSiteText.orderedTextUtilities[1].Type
      component.orderedUtilitySelect();
      let TestData = component.FilteredUtilitiesData[0];
      component.moveUp();
      expect(component.FilteredUtilitiesData[0]).toEqual(TestData);
    });
  })

  it('should not move down', () => {
    spy = spyOn(service, "getOrderedTextUtilities").and.returnValue(Promise.resolve(data.TestData.OrderedSiteText.orderedTextUtilities));
    component.loadOrderedTextUtilities();
    expect(spy).toHaveBeenCalled();
    fixture.whenStable().then(() => {
      component.selectedType = data.TestData.OrderedSiteText.orderedTextUtilities[1].Type
      component.orderedUtilitySelect();
      let TestData = component.FilteredUtilitiesData[1];
      component.moveDown();
      expect(component.FilteredUtilitiesData[1]).toEqual(TestData);
    });
  })
});
