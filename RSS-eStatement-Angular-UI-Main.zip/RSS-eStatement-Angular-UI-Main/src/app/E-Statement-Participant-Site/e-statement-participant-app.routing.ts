import { Routes } from '@angular/router';
import { EStatementPaticipantAppComponent } from './e-statement-participant-app.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ErrorPageComponent } from './components/error/error-page/error-page.component';
import { RegisterComponent } from './components/register/register.component';

const routes: Routes = [
    {
        path: ':participant', component: EStatementPaticipantAppComponent, children: [
            { path: 'Home', loadChildren: () => import('./components/intro-page/intro-page.module').then(m => m.LoginModule)},
            { path: 'Register', component: RegisterComponent },
            { path: ':user', loadChildren: () => import('./components/home-page/home-page.module').then(m => m.HomePageModule) },
            { path: 'Help', loadChildren: () => import('../Help/help-app.module').then(m => m.HelpModule) },
            

        ]
    },
    
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EStatementParticipantRoute { }
