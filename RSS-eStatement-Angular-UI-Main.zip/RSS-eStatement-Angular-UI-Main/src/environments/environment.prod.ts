export const environment = {
  production: true,
  pagesize:6,
  captchaLength:6,
  env:'prod',
  MMAPI:"http://hdlt0912.ad.dstsystems.com/mmapi/",
  eStatementAPI:"http://10-222-98-98.ssnc-corp.cloud/estatementapi/"
};
