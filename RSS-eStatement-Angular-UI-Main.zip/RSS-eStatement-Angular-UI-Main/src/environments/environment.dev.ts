export const environment = {
    production: true,
    pagesize:6,
    captchaLength:6,
    env:'dev',
    MMAPI:"https://qa1.newkirkone.com/mmapi/",
    eStatementAPI:"http://10-222-98-98.ssnc-corp.cloud/estatementapi/",
    MMApiURL: 'https://qa1.newkirkone.com/mmapi/api/v1/statement/',
    sessionJWT: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbmRlbW8iLCJqdGkiOiIwMmQxNjhjYy1mYzE3LTQ2ZmQtOGExYy0zNWJlZDE2MGIwNzciLCJuYW1laWQiOiIxMTRFQUM5My1BMTBELTdEOEQtMUZENy0yNjlDMjc4N0IwM0EiLCJleHAiOjE1NTk3NTE2OTMsImlzcyI6Ind3dy5uZXdraXJrb25lLmNvbSIsImF1ZCI6Ind3dy5uZXdraXJrb25lLmNvbSJ9.YDqa4-SQrOGlSMbu2W2vzAW-hcr-wE5XLZolMhf2pqw',
    providerId: 63
  };
  