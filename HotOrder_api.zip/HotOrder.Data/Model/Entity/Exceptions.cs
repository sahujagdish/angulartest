﻿using System;
using System.Collections.Generic;

namespace HotOrder.Data.Model.Entity
{
    public partial class Exceptions : ICloneable
    {
        public Exceptions()
        {
            Exceptiondetails = new HashSet<Exceptiondetails>();
        }

        public int Id { get; set; }
        public bool Status { get; set; }
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public DateTime Desireddeliverydatetime { get; set; }
        public string Hotweightrollcount { get; set; }
        public int Exceptionreasonid { get; set; }
        public int Customerserviceemailid { get; set; }
        public string Afterhoursreceivername { get; set; }
        public string Afterhoursreceiverphone { get; set; }
        public bool Rollstransferfromanothersoli { get; set; }
        public bool Modeshiftrequired { get; set; }
        public string Shiftedmode { get; set; }
        public string Modeforbalance { get; set; }
        public string Requestcomments { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
        public bool Planningteamnotified { get; set; }
        public virtual ICollection<Exceptiondetails> Exceptiondetails { get; set; }
        public object Clone()
        {
            Exceptions exceptions = (Exceptions)this.MemberwiseClone();
            exceptions.Exceptiondetails = new List<Exceptiondetails>(Exceptiondetails);
            return exceptions;
        }
    }
}
