﻿namespace HotOrder.Data.Model.Entity
{
    public class OtherConfig
    {
        public int Id { get; set; }
        public bool IsEnable { get; set; }
    }
}
