﻿using System;

namespace HotOrder.Data.Model.Entity
{
    public partial class Exceptionreasons
    {
        public int Id { get; set; }
        public string Exceptionreason { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
    }
}
