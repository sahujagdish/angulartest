﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace HotOrder.Data.Model
{
    public static class ModelBuilderExtension
    {
        private static DateTime GetCSTNow()
        {
            DateTime cstNow;
            try
            {
                TimeZoneInfo cstZone = null;
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                else
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("America/Chicago");

                cstNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cstZone);
            }
            catch (TimeZoneNotFoundException ex)
            {
                cstNow = DateTime.UtcNow;
            }
            catch (InvalidTimeZoneException ex)
            {
                cstNow = DateTime.UtcNow;
            }
            return cstNow;
        }

        public static void seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Mills>().HasData(
               new Mills { Id = 1, Millnumber = "0241", Millname = "Texarkana", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
               new Mills { Id = 2, Millnumber = "0525", Millname = "Prosperity", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
               new Mills { Id = 3, Millnumber = "0660", Millname = "Augusta", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" }
            );

            modelBuilder.Entity<Ordertypes>().HasData(
              new Ordertypes { Id = 1, Ordertype = "ZKB", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
              new Ordertypes { Id = 2, Ordertype = "ZDOM", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
              new Ordertypes { Id = 3, Ordertype = "ZEXP", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" }
           );

            modelBuilder.Entity<Mailinglist>().HasData(
             new Mailinglist { Millid = 1, Ordertypeid = 1, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate = GetCSTNow(), Createdby = "Jagdish" },
             new Mailinglist { Millid = 2, Ordertypeid = 2, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate = GetCSTNow(), Createdby = "Jagdish" },
             new Mailinglist { Millid = 3, Ordertypeid = 3, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate = GetCSTNow(), Createdby = "Jagdish" }
            );

            modelBuilder.Entity<Exceptionreasons>().HasData(
                new Exceptionreasons {Exceptionreason = "Customer Need", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
                new Exceptionreasons { Exceptionreason = "Delayed Production/Product Availability", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
                new Exceptionreasons { Exceptionreason = "Mode Shift", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
                new Exceptionreasons { Exceptionreason = "New Business", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" },
                new Exceptionreasons { Exceptionreason = "Trial Order", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" }
            );

            modelBuilder.Entity<Customerserviceemails>().HasData(
                new Customerserviceemails {Customerserviceemail = "gpicare@graphicpkg.com", Createddate = GetCSTNow(), Createdby = "Jagdish", Modifieddate = GetCSTNow(), Modifiedby = "Jagdish" }
            );
        }
    }
}
