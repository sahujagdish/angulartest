﻿using HotOrder.Data.Model.Entity;
using HotOrder.Data.Model.Mapping;
using Microsoft.EntityFrameworkCore;

namespace HotOrder.Data.Model
{
    public partial class HotOrderContext : DbContext
    {
        public HotOrderContext()
        {
        }

        public HotOrderContext(DbContextOptions<HotOrderContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Customerserviceemails> Customerserviceemails { get; set; }
        public virtual DbSet<Exceptiondetails> Exceptiondetails { get; set; }
        public virtual DbSet<Exceptionreasons> Exceptionreasons { get; set; }
        public virtual DbSet<Exceptions> Exceptions { get; set; }
        public virtual DbSet<Mailinglist> Mailinglist { get; set; }
        public virtual DbSet<Mills> Mills { get; set; }
        public virtual DbSet<Ordertypes> Ordertypes { get; set; }
        public virtual DbSet<OtherConfig> OtherConfig { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //optionsBuilder.UseSqlServer(Setting.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new MailinglistMap());
            modelBuilder.ApplyConfiguration(new MillsMap());
            modelBuilder.ApplyConfiguration(new OrdertypesMap());
            modelBuilder.ApplyConfiguration(new CustomerserviceemailsMap());
            modelBuilder.ApplyConfiguration(new ExceptiondetailsMap());
            modelBuilder.ApplyConfiguration(new ExceptionreasonsMap());
            modelBuilder.ApplyConfiguration(new ExceptionsMap());
            modelBuilder.ApplyConfiguration(new OtherConfigMap());
            modelBuilder.Entity<Exceptiondetails>()
                .HasOne(x => x.Exception)
                .WithMany(x => x.Exceptiondetails)
                .OnDelete(DeleteBehavior.Cascade);

            OnModelCreatingPartial(modelBuilder);

            //modelBuilder.seed();
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
