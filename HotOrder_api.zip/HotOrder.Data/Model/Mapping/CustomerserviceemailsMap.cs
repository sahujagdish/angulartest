﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class CustomerserviceemailsMap : IEntityTypeConfiguration<Customerserviceemails>
    {
        public void Configure(EntityTypeBuilder<Customerserviceemails> builder)
        {
            builder.ToTable("customerserviceemails");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createdby)
                    .IsRequired()
                    .HasColumnName("createdby")
                    .HasMaxLength(50)
                    .IsUnicode(false);

            builder.Property(e => e.Createddate)
                    .HasColumnName("createddate")
                    .HasColumnType("datetime");

            builder.Property(e => e.Customerserviceemail)
                    .IsRequired()
                    .HasColumnName("customerserviceemail")
                    .HasMaxLength(200)
                    .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                    .HasColumnName("modifiedby")
                    .HasMaxLength(50)
                    .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                    .HasColumnName("modifieddate")
                    .HasColumnType("datetime");

        }
    }
}
