﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class MailinglistMap : IEntityTypeConfiguration<Mailinglist>
    {
        public void Configure(EntityTypeBuilder<Mailinglist> builder)
        {
            builder.ToTable("mailinglist");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime")
                .IsRequired();

            builder.Property(e => e.Executionteamdl)
                .HasColumnName("executionteamdl")
                .HasMaxLength(500)
                .IsUnicode(false);

            builder.Property(e => e.Millid).HasColumnName("millid");

            builder.Property(e => e.Modifiedby)
                .HasColumnName("modifiedby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                .HasColumnName("modifieddate")
                .HasColumnType("datetime");

            builder.Property(e => e.Ordertypeid).HasColumnName("ordertypeid");

            builder.Property(e => e.Planningteamdl)
                .HasColumnName("planningteamdl")
                .HasMaxLength(500)
                .IsUnicode(false);

            builder.HasOne(d => d.Mill)
                .WithMany(p => p.Mailinglist)
                .HasForeignKey(d => d.Millid)
                .HasConstraintName("FK_mailinglist_mills");

            builder.HasOne(d => d.Ordertype)
                .WithMany(p => p.Mailinglist)
                .HasForeignKey(d => d.Ordertypeid)
                .HasConstraintName("FK_mailinglist_ordertypes");
        }
    }
}
