﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class ExceptionsMap : IEntityTypeConfiguration<Exceptions>
    {
        public void Configure(EntityTypeBuilder<Exceptions> builder)
        {
            builder.ToTable("exceptions");

            builder.HasComment("");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Afterhoursreceivername)
                .IsRequired()
                .HasColumnName("afterhoursreceivername")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Afterhoursreceiverphone)
                .IsRequired()
                .HasColumnName("afterhoursreceiverphone")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime");

            builder.Property(e => e.Customerserviceemailid).HasColumnName("customerserviceemailid");

            builder.Property(e => e.Desireddeliverydatetime)
                .HasColumnName("desireddeliverydatetime")
                .HasColumnType("datetime");

            builder.Property(e => e.Exceptionreasonid).HasColumnName("exceptionreasonid");

            builder.Property(e => e.Hotweightrollcount)
                .IsRequired()
                .HasColumnName("hotweightrollcount")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Lineitemnumber)
                .IsRequired()
                .HasColumnName("lineitemnumber")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.Modeforbalance)
                .HasColumnName("modeforbalance")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Modeshiftrequired).HasColumnName("modeshiftrequired");

            builder.Property(e => e.Modifiedby)
                .HasColumnName("modifiedby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                .HasColumnName("modifieddate")
                .HasColumnType("datetime");

            builder.Property(e => e.Requestcomments)
                .HasColumnName("requestcomments")
                .IsUnicode(false);

            builder.Property(e => e.Rollstransferfromanothersoli).HasColumnName("rollstransferfromanothersoli");

            builder.Property(e => e.Salesordernumber)
                .IsRequired()
                .HasColumnName("salesordernumber")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Shiftedmode)
                .HasColumnName("shiftedmode")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Status)
                .HasColumnName("status")
                .HasComment("True = Open; False = Closed. An entry while being created is marked \"Open\" by default.");

            builder.Property(e => e.Planningteamnotified)
                .HasColumnName("planningteamnotified");

        }
    }
}
