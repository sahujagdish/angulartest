﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class OtherConfigMap : IEntityTypeConfiguration<OtherConfig>
    {
        public void Configure(EntityTypeBuilder<OtherConfig> builder)
        {
            builder.Property(e => e.IsEnable).HasColumnName("isenable");
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.ToTable("otherconfig");
        }
    }
}
