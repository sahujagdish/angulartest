﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class MillsMap : IEntityTypeConfiguration<Mills>
    {
        public MillsMap()
        {

        }

        public void Configure(EntityTypeBuilder<Mills> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime")
                .IsRequired();

            builder.Property(e => e.Millname)
                .IsRequired()
                .HasColumnName("millname")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Millnumber)
                .IsRequired()
                .HasColumnName("millnumber")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                .HasColumnName("modifiedby")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                .HasColumnName("modifieddate")
                .HasColumnType("datetime")
                ;

            builder.ToTable("mills");
        }
    }
}
