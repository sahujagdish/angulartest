﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class ExceptiondetailsMap : IEntityTypeConfiguration<Exceptiondetails>
    {
        public void Configure(EntityTypeBuilder<Exceptiondetails> builder)
        {
            builder.ToTable("exceptiondetails");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.AccountExecutive)
                .HasColumnName("ACCOUNT_EXECUTIVE")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Arktx)
                .HasColumnName("ARKTX")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Cdd)
                .HasColumnName("CDD")
                .HasColumnType("date");

            builder.Property(e => e.ConfirmQty)
                .HasColumnName("CONFIRM_QTY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ContainerId)
                .HasColumnName("CONTAINER_ID")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime");

            builder.Property(e => e.CustPo)
                .HasColumnName("CUST_PO")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.DelApptDateEarly)
                .HasColumnName("DEL_APPT_DATE_EARLY")
                .HasColumnType("date");

            builder.Property(e => e.DelApptTimeEarly).HasColumnName("DEL_APPT_TIME_EARLY");

            builder.Property(e => e.DelWindow)
                .HasColumnName("DEL_WINDOW")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Eped)
                .HasColumnName("EPED")
                .HasColumnType("date");

            builder.Property(e => e.Exceptionid).HasColumnName("exceptionid");

            builder.Property(e => e.Gewei)
                .HasColumnName("GEWEI")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Hasexception).HasColumnName("hasexception");


            builder.Property(e => e.Lineitemnumber)
                .HasColumnName("lineitemnumber")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.Mad)
                .HasColumnName("MAD")
                .HasColumnType("date");

            builder.Property(e => e.Matnr)
                .HasColumnName("MATNR")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                .HasColumnName("modifiedby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                .HasColumnName("modifieddate")
                .HasColumnType("datetime");

            builder.Property(e => e.OrderType)
                .HasColumnName("ORDER_TYPE")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.OrderUnits)
                .HasColumnName("ORDER_UNITS")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.OrderUnitsUom)
                .HasColumnName("ORDER_UNITS_UOM")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.PgiDate)
                .HasColumnName("PGI_DATE")
                .HasColumnType("date");

            builder.Property(e => e.PickupApptDateErly)
                .HasColumnName("PICKUP_APPT_DATE_ERLY")
                .HasColumnType("date");

            builder.Property(e => e.PickupApptTimeErly).HasColumnName("PICKUP_APPT_TIME_ERLY");

            builder.Property(e => e.PlannedDelivQty)
                .HasColumnName("PLANNED_DELIV_QTY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ProdConfirmPct)
                .HasColumnName("PROD_CONFIRM_PCT")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ProdQty)
                .HasColumnName("PROD_QTY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Salesordernumber)
                .HasColumnName("salesordernumber")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Scacd)
                .HasColumnName("SCACD")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShipFrom)
                .HasColumnName("SHIP_FROM")
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.ShipProdPct)
                .HasColumnName("SHIP_PROD_PCT")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.ShipQty)
                .HasColumnName("SHIP_QTY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Shipto)
                .HasColumnName("SHIPTO")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoCity)
                .HasColumnName("SHIPTO_CITY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoCountry)
                .HasColumnName("SHIPTO_COUNTRY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoName)
                .HasColumnName("SHIPTO_NAME")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoState)
                .HasColumnName("SHIPTO_STATE")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoStreet)
                .HasColumnName("SHIPTO_STREET")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.ShiptoZipcd)
                .HasColumnName("SHIPTO_ZIPCD")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Soldto)
                .HasColumnName("SOLDTO")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.SoldtoCity)
                .HasColumnName("SOLDTO_CITY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.SoldtoCountry)
                .HasColumnName("SOLDTO_COUNTRY")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.SoldtoName)
                .HasColumnName("SOLDTO_NAME")
                .IsUnicode(false);

            builder.Property(e => e.SoldtoState)
                .HasColumnName("SOLDTO_STATE")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.SoldtoStreet)
                .HasColumnName("SOLDTO_STREET")
                .IsUnicode(false);

            builder.Property(e => e.SoldtoZipcd)
                .HasColumnName("SOLDTO_ZIPCD")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.Sto)
                .HasColumnName("STO")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.Property(e => e.StoShipment)
                .HasColumnName("STO_SHIPMENT")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Tknum)
                .HasColumnName("TKNUM")
                .HasMaxLength(20)
                .IsUnicode(false);

            builder.Property(e => e.Vrkme)
                .HasColumnName("VRKME")
                .HasMaxLength(200)
                .IsUnicode(false);

            builder.HasOne(d => d.Exception)
                .WithMany(p => p.Exceptiondetails)
                .HasForeignKey(d => d.Exceptionid)
                .HasConstraintName("FK_exceptiondetails_exceptions");
        }
    }
}
