﻿using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HotOrder.Data.Model.Mapping
{
    public class ExceptionreasonsMap : IEntityTypeConfiguration<Exceptionreasons>
    {
        public void Configure(EntityTypeBuilder<Exceptionreasons> builder)
        {
            builder.ToTable("exceptionreasons");

            builder.Property(e => e.Id).HasColumnName("id");

            builder.Property(e => e.Createdby)
                .IsRequired()
                .HasColumnName("createdby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Createddate)
                .HasColumnName("createddate")
                .HasColumnType("datetime");

            builder.Property(e => e.Exceptionreason)
                .IsRequired()
                .HasColumnName("exceptionreason")
                .IsUnicode(false);

            builder.Property(e => e.Modifiedby)
                .IsRequired()
                .HasColumnName("modifiedby")
                .HasMaxLength(50)
                .IsUnicode(false);

            builder.Property(e => e.Modifieddate)
                .HasColumnName("modifieddate")
                .HasColumnType("datetime");
        }
    }
}
