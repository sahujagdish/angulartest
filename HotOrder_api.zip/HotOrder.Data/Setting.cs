﻿namespace HotOrder.Data
{
    public static class Setting
    {
        public static string ConnectionString { get; set; }
    }
}
