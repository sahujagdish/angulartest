﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HotOrder.Data.Migrations
{
    public partial class casadeDeleteExceptionDetail : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_exceptiondetails_exceptions",
                table: "exceptiondetails");

            migrationBuilder.AddForeignKey(
                name: "FK_exceptiondetails_exceptions",
                table: "exceptiondetails",
                column: "exceptionid",
                principalTable: "exceptions",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_exceptiondetails_exceptions",
                table: "exceptiondetails");

            migrationBuilder.AddForeignKey(
                name: "FK_exceptiondetails_exceptions",
                table: "exceptiondetails",
                column: "exceptionid",
                principalTable: "exceptions",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
