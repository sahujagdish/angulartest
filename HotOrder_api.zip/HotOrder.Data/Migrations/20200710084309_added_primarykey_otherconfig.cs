﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HotOrder.Data.Migrations
{
    public partial class added_primarykey_otherconfig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id",
                table: "otherconfig",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_otherconfig",
                table: "otherconfig",
                column: "id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_otherconfig",
                table: "otherconfig");

            migrationBuilder.DropColumn(
                name: "id",
                table: "otherconfig");
        }
    }
}
