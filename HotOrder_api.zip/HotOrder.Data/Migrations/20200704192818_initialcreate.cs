﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace HotOrder.Data.Migrations
{
    public partial class initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "customerserviceemails",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    customerserviceemail = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customerserviceemails", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "exceptionreasons",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    exceptionreason = table.Column<string>(unicode: false, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_exceptionreasons", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "exceptions",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    status = table.Column<bool>(nullable: false, comment: "True = Open; False = Closed. An entry while being created is marked \"Open\" by default."),
                    salesordernumber = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    lineitemnumber = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    desireddeliverydatetime = table.Column<DateTime>(type: "datetime", nullable: false),
                    hotweightrollcount = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    exceptionreasonid = table.Column<int>(nullable: false),
                    customerserviceemailid = table.Column<int>(nullable: false),
                    afterhoursreceivername = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    afterhoursreceiverphone = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    rollstransferfromanothersoli = table.Column<bool>(nullable: false),
                    modeshiftrequired = table.Column<bool>(nullable: false),
                    shiftedmode = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    modeforbalance = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    requestcomments = table.Column<string>(unicode: false, nullable: true),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    planningteamnotified = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_exceptions", x => x.id);
                },
                comment: "");

            migrationBuilder.CreateTable(
                name: "mills",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    millnumber = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    millname = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 200, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mills", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ordertypes",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ordertype = table.Column<string>(unicode: false, maxLength: 10, nullable: false),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ordertypes", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "exceptiondetails",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    exceptionid = table.Column<int>(nullable: true),
                    hasexception = table.Column<bool>(nullable: true),
                    salesordernumber = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    lineitemnumber = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    TKNUM = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    STO_SHIPMENT = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ORDER_TYPE = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    ACCOUNT_EXECUTIVE = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    ARKTX = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    CDD = table.Column<DateTime>(type: "date", nullable: true),
                    CONFIRM_QTY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    CONTAINER_ID = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    CUST_PO = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    DEL_APPT_DATE_EARLY = table.Column<DateTime>(type: "date", nullable: true),
                    DEL_APPT_TIME_EARLY = table.Column<TimeSpan>(nullable: true),
                    DEL_WINDOW = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    EPED = table.Column<DateTime>(type: "date", nullable: true),
                    GEWEI = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    MAD = table.Column<DateTime>(type: "date", nullable: true),
                    MATNR = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    ORDER_UNITS = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    ORDER_UNITS_UOM = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    PGI_DATE = table.Column<DateTime>(type: "date", nullable: true),
                    PICKUP_APPT_DATE_ERLY = table.Column<DateTime>(type: "date", nullable: true),
                    PICKUP_APPT_TIME_ERLY = table.Column<TimeSpan>(nullable: true),
                    PLANNED_DELIV_QTY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    PROD_CONFIRM_PCT = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    PROD_QTY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SCACD = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIP_FROM = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    SHIP_PROD_PCT = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SHIP_QTY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_CITY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_COUNTRY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_NAME = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_STATE = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_STREET = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SHIPTO_ZIPCD = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SOLDTO = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SOLDTO_CITY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SOLDTO_COUNTRY = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SOLDTO_NAME = table.Column<string>(unicode: false, nullable: true),
                    SOLDTO_STATE = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    SOLDTO_STREET = table.Column<string>(unicode: false, nullable: true),
                    SOLDTO_ZIPCD = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    STO = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    VRKME = table.Column<string>(unicode: false, maxLength: 200, nullable: true),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_exceptiondetails", x => x.id);
                    table.ForeignKey(
                        name: "FK_exceptiondetails_exceptions",
                        column: x => x.exceptionid,
                        principalTable: "exceptions",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "mailinglist",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    millid = table.Column<int>(nullable: true),
                    ordertypeid = table.Column<int>(nullable: true),
                    planningteamdl = table.Column<string>(unicode: false, maxLength: 500, nullable: true),
                    executionteamdl = table.Column<string>(unicode: false, maxLength: 500, nullable: true),
                    createdby = table.Column<string>(unicode: false, maxLength: 50, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mailinglist", x => x.id);
                    table.ForeignKey(
                        name: "FK_mailinglist_mills",
                        column: x => x.millid,
                        principalTable: "mills",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_mailinglist_ordertypes",
                        column: x => x.ordertypeid,
                        principalTable: "ordertypes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_exceptiondetails_exceptionid",
                table: "exceptiondetails",
                column: "exceptionid");

            migrationBuilder.CreateIndex(
                name: "IX_mailinglist_millid",
                table: "mailinglist",
                column: "millid");

            migrationBuilder.CreateIndex(
                name: "IX_mailinglist_ordertypeid",
                table: "mailinglist",
                column: "ordertypeid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "customerserviceemails");

            migrationBuilder.DropTable(
                name: "exceptiondetails");

            migrationBuilder.DropTable(
                name: "exceptionreasons");

            migrationBuilder.DropTable(
                name: "mailinglist");

            migrationBuilder.DropTable(
                name: "exceptions");

            migrationBuilder.DropTable(
                name: "mills");

            migrationBuilder.DropTable(
                name: "ordertypes");
        }
    }
}
