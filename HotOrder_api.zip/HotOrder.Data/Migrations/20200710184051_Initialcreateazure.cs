﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HotOrder.Data.Migrations
{
    public partial class Initialcreateazure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
