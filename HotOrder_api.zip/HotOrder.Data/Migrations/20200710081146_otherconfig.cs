﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace HotOrder.Data.Migrations
{
    public partial class otherconfig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "otherconfig",
                columns: table => new
                {
                    isenable = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "otherconfig");
        }
    }
}
