﻿using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HotOrderConsole
{
    public interface IScheduler
    {
        void process(string[] args);
    }

    public  class Scheduler : IScheduler
    {
        ILogger<Scheduler> logger;
        //IConfiguration config;

        public Scheduler(ILogger<Scheduler> _logger)
        {
            logger = _logger;
           // config = _config;
        }

        public void process(string[] args)
        {
            if (args[0] == "nightlyrun")
            {
                nightlyrun();
            }
            else if (args[0] == "notifyhotorderstatus")
            {
                notifyhotorderstatus();
            }
            else if (args[0] == "updateexceptiondetails")
            {
                updateexceptiondetails();
            }
        }


        public void nightlyrun()
        {

            try
            {
                logger.LogInformation("nightlyrun start - " + DateTime.Now);

                Task<string> token = Tokencredential.GetToken();
                string setting = ConfigurationManager.AppSettings["url"] + "nightlyrun";

                using (var client = new HttpClient())
                {
                    var httpRequestMessage = new HttpRequestMessage
                    {
                        Method = System.Net.Http.HttpMethod.Get,
                        RequestUri = new Uri(setting),
                        Headers =
                    {
                        { HttpRequestHeader.Authorization.ToString(), "Bearer " + token.Result}
                    }
                    };
                    var response = client.SendAsync(httpRequestMessage).Result;
                }

                logger.LogInformation("nightlyrun end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler nightlyrun" + ex.Message);
            }
        }

        public void notifyhotorderstatus()
        {
            try
            {
                logger.LogInformation("notifyhotorderstatus start - " + DateTime.Now);
                Task<string> token = Tokencredential.GetToken();
                string setting = ConfigurationManager.AppSettings["url"] + "notifyhotorderstatus";

                using (var client = new HttpClient())
                {
                    var httpRequestMessage = new HttpRequestMessage
                    {
                        Method = System.Net.Http.HttpMethod.Get,
                        RequestUri = new Uri(setting),
                        Headers =
                    {
                        { HttpRequestHeader.Authorization.ToString(), "Bearer " + token.Result}
                    }
                    };
                    var response = client.SendAsync(httpRequestMessage).Result;
                }

                logger.LogInformation("notifyhotorderstatus end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler notifyhotorderstatus " + ex.Message);
            }
        }

        public void updateexceptiondetails()
        {
            try
            {
                logger.LogInformation("updateexceptiondetails start - " + DateTime.Now);
                Task<string> token = Tokencredential.GetToken();                
                string setting = ConfigurationManager.AppSettings["url"] + "updateexceptiondetails";

                using (var client = new HttpClient())
                {
                    var httpRequestMessage = new HttpRequestMessage
                    {
                        Method = System.Net.Http.HttpMethod.Get,
                        RequestUri = new Uri(setting),
                        Headers =
                    {
                        { HttpRequestHeader.Authorization.ToString(), "Bearer " + token.Result}
                    }
                    };
                    var response = client.SendAsync(httpRequestMessage).Result;
                }

                logger.LogInformation("updateexceptiondetails end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler updateexceptiondetails " + ex.Message);
            }
        }
    }

    static class Tokencredential
    {
        public async static Task<string> GetToken()
        {
            try
            {
                HttpClient client = new HttpClient();
                var response1 = await client.RequestTokenAsync(new ClientCredentialsTokenRequest
                {
                    Address = "https://gpi.my.idaptive.app/oauth2/token/oauthcustomapp",
                    ClientId = "hotapiuser@graphicpkg.com",
                    ClientSecret = @"ksN>c.q\M392jwU_psI3d^>n}o-&;?pJ,}BLf:+A",
                    Scope = "oauth",
                    GrantType = "client_credentials"
                });

                return response1.AccessToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
