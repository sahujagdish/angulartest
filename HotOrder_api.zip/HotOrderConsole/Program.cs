﻿using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Sinks.RollingFile;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace HotOrderConsole
{
    public class Program
    {

        static void Main(string[] args)
        {

            Log.Logger = new LoggerConfiguration().WriteTo.File("consoleapp.log").CreateLogger();

            var services = new ServiceCollection();
            ConfigureServices(services);

            ServiceProvider serviceProvider = services.BuildServiceProvider();
            {
                Scheduler app = serviceProvider.GetService<Scheduler>();
                string[] obj = new string[3];
                obj[0] = "nightlyrun";
                app.process(obj);
            }

            static void ConfigureServices(ServiceCollection services)
            {
                services.AddTransient<Scheduler>();

                var serilogLogger = new LoggerConfiguration()
                .WriteTo.RollingFile("hotorderlog.txt")
                .CreateLogger();

                services.AddLogging(builder =>
                {
                    builder.SetMinimumLevel(LogLevel.Information);
                    builder.AddSerilog(logger: serilogLogger, dispose: true);
                });
            }
        }
    }
}