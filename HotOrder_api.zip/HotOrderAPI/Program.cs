using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;

namespace ShipmentExceptionAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

                var configuration = new ConfigurationBuilder()
                  .AddJsonFile($"appsettings.{environment}.json")                
                .AddEnvironmentVariables()
                .Build();

                Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();


                CreateHostBuilder(args).Build().Run();
                Log.Information("Application starting up");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Application failed to start properly");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((context, config) =>
            {
                var root = config.Build();
                //config.AddAzureKeyVault($"https://{root["KeyVault:Vault"]}.vault.azure.net/", root["KeyVault:ClientId"], root["KeyVault:ClientSecret"]);
            })
            .UseSerilog()
            .ConfigureWebHostDefaults(webBuilder =>
            {
                try
                {
                    webBuilder
                    .UseStartup<Startup>();
                }
                catch (Exception ex)
                {
                    Log.Error(ex.Message);
                }
            });
    }
}
