using HotOrder.Data.Model;
using HotOrder.Service;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using ShipmentExceptionAPI.Helper;
using System;

namespace ShipmentExceptionAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddDbContext<HotOrderContext>(options =>
                     // options.UseSqlServer(Configuration.GetValue<string>("sqlconnection")),
                      options.UseSqlServer(Configuration["ConnectionStrings:sqlconnection"]),
              ServiceLifetime.Transient);

            //var context = services.BuildServiceProvider()
            //          .GetService<HotOrderContext>();
            var roles = new string[1];
            services.AddTransient<IMillsService, MillsService>();
            services.AddTransient<IOrderTypeService, OrderTypeService>();
            services.AddTransient<IMailingListService, MailingListService>();
            services.AddTransient<IHotOrderExceptionService, HotOrderExceptionService>();
            services.AddTransient<ISchedulerService, SchedulerService>();
            services.AddTransient<ISoliShipmentDetail, SoliShipmentDetail>();
            services.AddSingleton<IMailerService, MailerService>();
            services.AddSingleton<IUtilities, Utilities>();            
            services.AddScoped<CheckAuthToken>( x => new CheckAuthToken(roles));
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //"http://localhost:4200"
            app.UseCors(options => options.WithOrigins("*").AllowAnyMethod().AllowAnyHeader());


            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.All
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseSerilogRequestLogging();

            app.UseRouting();

            app.UseAuthorization();



            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
