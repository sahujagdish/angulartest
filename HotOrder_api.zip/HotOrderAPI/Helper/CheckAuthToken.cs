﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Http;
using System.Net.Http.Headers;
using Microsoft.Extensions.Primitives;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Net.Http.Headers;
using Serilog;
using System.IO;
using System.Net.Http;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using IdentityModel.Client;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using HotOrder.BusinessModel;

namespace ShipmentExceptionAPI.Helper
{
    public class CheckAuthToken : ActionFilterAttribute //Attribute, //AuthorizationFilterAttribute
    {
        private readonly string[] allowedroles;

        public CheckAuthToken(params string[] roles)
        {
            allowedroles = roles[0].Split(",");
        }

        public static TokenData ValidateAndDecode(string access_token)
        {
            string result = string.Empty;
            HttpResponseMessage response;
            TokenData tokenData = new TokenData();
            var keyValues = new List<KeyValuePair<string, string>>();
            keyValues.Add(new KeyValuePair<string, string>("token", access_token));
            using (var client = new HttpClient())
            {
                var httpRequestMessage = new HttpRequestMessage
                {
                    Method = System.Net.Http.HttpMethod.Post,
                    RequestUri = new Uri("https://gpi.my.idaptive.app/oauth2/introspect/oauthcustomserverapp"),
                    Headers =
                    {
                        { HttpRequestHeader.Authorization.ToString(), "Bearer " + access_token},
                        { HttpRequestHeader.Accept.ToString(), "application/x-www-form-urlencoded" },
                    },
                    Content = new FormUrlEncodedContent(keyValues)
                };
                response = client.SendAsync(httpRequestMessage).Result;
                result = response.Content.ReadAsStringAsync().Result;
            }


            dynamic idaptiveresponse = JObject.Parse(result);
            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                //if (idaptiveresponse["error"].ToString() == "access_denied") { 
                tokenData.active = false;
                return tokenData;
                //}
            }
            else if (!Convert.ToBoolean(idaptiveresponse["active"].ToString()))
            {
                tokenData.active = false;
                return tokenData;
            }
            else
            {
                if (idaptiveresponse["unique_name"].ToString().ToLower() == "hotapiuser@graphicpkg.com")
                {
                    tokenData.user = "Timer Job";
                    tokenData.role = "admin";
                }
                else
                {
                    tokenData.user = idaptiveresponse["unique_name"].ToString().ToLower();
                    tokenData.username = idaptiveresponse["firstname"].ToString().ToLower();
                    List<string> groups = new List<string>(idaptiveresponse["groups"].ToString().ToLower().Replace(" ", string.Empty).Split(","));
                    if (groups.Contains("gpi-hot-admin"))
                        tokenData.role = "admin";
                    else
                    {
                        if (groups.Contains("gpi-hot-user"))
                            tokenData.role = "user";
                        else
                            tokenData.role = "nonuser";
                    }
                }
            }
            return tokenData;
        }     

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            // bool isauthorize = false;
            StringValues[] str;
            string token = "";
            List<string> userandrole = null;
            try
            {
                var items = context.HttpContext.Request.Headers.ToDictionary(header => header.Key, header => new[] { header.Value }, StringComparer.OrdinalIgnoreCase);
                var haskey = items.TryGetValue("Authorization", out str);
                if (haskey == true)
                {
                    var tokenval = items.Where(x => x.Key == "Authorization").FirstOrDefault();
                    token = tokenval.Value[0];

                    TokenData tokenData = new TokenData();
                    tokenData = ValidateAndDecode(token.Substring(7));
                    
                    if (tokenData.active == false)
                    {
                        Log.Error("Unauthorized access. No valid token found");
                        updateresponsestatus(ref context);
                    } else
                    {
                        context.HttpContext.Items.Add("username", tokenData.username);

                        if (context.ActionArguments.Count > 0)
                        {
                            var contextmodel = context.ActionArguments.Select(x => x.Value).FirstOrDefault();

                            if (contextmodel.GetType().BaseType == typeof(BaseModel))
                            {
                                var model = (BaseModel)contextmodel;
                                model.Createdby = tokenData.username;
                                model.Modifiedby = tokenData.username;
                            }
                        }
                    }
                    
                    if (!allowedroles.Contains(tokenData.role))
                    {
                        Log.Error("Unauthorized access. No valid token found");
                        updateresponsestatus(ref context);
                    } 


                }
                else
                {
                    Log.Error("Unauthorized access. No valid token found");
                    updateresponsestatus(ref context);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw ex;
            }
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {

        }

        private void updateresponsestatus(ref ActionExecutingContext context)
        {
            byte[] resp = Encoding.UTF8.GetBytes("unauthorised access. No valid token found");
            context.HttpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
            context.HttpContext.Response.Body.WriteAsync(resp);
            context.Result = new EmptyResult();
        }       
    }

    public class TokenData
    {
        public bool active { get; set; } = true;
        public string user { get; set; }
        public string username { get; set; }
        public string role { get; set; }
    }   
}


    