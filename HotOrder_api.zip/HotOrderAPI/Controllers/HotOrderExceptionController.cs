﻿using HotOrder.BusinessModel;
using HotOrder.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipmentExceptionAPI.Helper;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace HotOrderAPI.Controllers
{
    [ApiController]
    [Route("api/v1")]
    [CheckAuthToken("admin,user")]
    public class HotOrderExceptionController : ControllerBase
    {
        IHotOrderExceptionService hotOrderExceptionService;
        ILogger<HotOrderExceptionController> logger;
        IConfiguration config;
        ISoliShipmentDetail soliShipmentDetail;

        public HotOrderExceptionController(IHotOrderExceptionService _hotOrderExceptionService, ISoliShipmentDetail _soliShipmentDetail, ILogger<HotOrderExceptionController> _logger, IConfiguration _config)
        {
            hotOrderExceptionService = _hotOrderExceptionService;
            logger = _logger;
            config = _config;
            soliShipmentDetail = _soliShipmentDetail;
        }

        [Route("OtherConfig")]
        public IActionResult GetOtherConfig()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.GetOtherConfig()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetOtherConfig");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("EnableOtherConfig")]
        public IActionResult EnableOtherConfig([FromBody] bool isEnable)
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.EnableOtherConfig(isEnable)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "EnableOtherConfig");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("ExceptionReason")]
        public IActionResult GetExceptionReason()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.GetExceptionReason()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetExceptionReason");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("CustomerServiceEmails")]
        public IActionResult GetCustomerServiceEmails()
        {
            try
            {

                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.GetCustomerServiceEmails()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetCustomerServiceEmails");
                return StatusCode(500, "internal server error");
            }
        }

        //[HttpGet]
        //[Route("Export")]
        //public ActionResult Export([FromQuery] string exceptionids)
        //{
        //    try
        //    {
        //        string[] ids = exceptionids.Split(",");

        //        int[] nums = new int[ids.Length];

        //        for (int i = 0; i < ids.Length; i++)
        //        {
        //            nums[i] = int.Parse(ids[i]);
        //        }

        //        // HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
        //        var dtExport = hotOrderExceptionService.ExportException(nums);
        //        //result.Content = new StreamContent(dtExport);                
        //        //result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment") {FileName = "Hotorder.xlsx" };
        //        //result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        //        //return result;
        //        return new FileStreamResult(dtExport, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.LogError(ex, "Export");
        //        return null; // StatusCode(500, "internal server error");
        //    }

        //}

        [HttpPost]
        [Route("ExceptionDetailList")]
        public IActionResult GetExceptionDetailList([FromBody] LookupModel lookupModel)
        {
            try
            {               
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.GetExceptionDetailList(lookupModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetExceptionDetailList");
                return StatusCode(500, "internal server error");
            }
        }

        [Route("ExceptionDetail/{id}")]
        public IActionResult GetExceptionDetail(int id)
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.GetExceptionDetail(id)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetExceptionDetail");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("InsertUpdateExceptionDetail")]
        public IActionResult InsertUpdateExceptionDetail([FromBody] InputExceptionModel inputExceptionModel)
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(hotOrderExceptionService.InsertUpdateExceptionDetail(config.GetValue<string>("ShipmentExceptionUrl"), config.GetValue<string>("defaultemail"), inputExceptionModel)));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "InsertUpdateExceptionDetail");

                return StatusCode(500, "internal server error");
            }
        }

        [HttpPost]
        [Route("DeleteException/{id}")]
        public IActionResult DeleteException(int id)
        {
            try
            {
                return Ok(hotOrderExceptionService.DeleteException(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteException");
                return StatusCode(500, "internal server error");
            }
        }

        [HttpGet]
        [Route("Export")]
        //download file api
        public IActionResult GetFile([FromQuery] string exceptionids)
        {
            //Create HTTP Response.  
            string[] ids = exceptionids.Split(",");

            int[] nums = new int[ids.Length];

            for (int i = 0; i < ids.Length; i++)
            {
                nums[i] = int.Parse(ids[i]);
            }  
            var dtExport = hotOrderExceptionService.ExportException(nums);
           
            return File(dtExport, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","HotOrderTool.xlsx");
        }
    }
}
