﻿using HotOrder.BusinessModel;
using HotOrder.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ShipmentExceptionAPI.Helper;
using System;
using System.Net.Http;

namespace ShipmentExceptionAPI.Controllers
{
    //public class BufferedSingleFileUploadPhysical
    //{
    //    [Required]
    //    [Display(Name = "File")]
    //    public IFormFile FormFile { get; set; }

    //    [Display(Name = "Note")]
    //    [StringLength(50, MinimumLength = 0)]
    //    public string Note { get; set; }
    //}

    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    [CheckAuthToken("admin")]
    public class MillsController : ControllerBase
    {
        private readonly IMillsService millsService;
        private readonly ILogger<MillsController> logger;
        IConfiguration config;

        //private readonly string[] _permittedExtensions = { ".txt" };
        //private readonly long _fileSizeLimit;

        //[BindProperty]
        //public BufferedSingleFileUploadPhysical FileUpload { get; set; }       
        public MillsController(IMillsService _millsService, ILogger<MillsController> _logger, IConfiguration _config)
        {

            // _fileSizeLimit = config.GetValue<long>("FileSizeLimit");
            config = _config;

            millsService = _millsService;
            logger = _logger;

        }

        //[HttpPost]
        //[Route("Upload")]
        //public int Upload()
        //{
        //    var formFileContent = Common.ProcessFormFile<BufferedSingleFileUploadPhysical>(
        //             FileUpload.FormFile, _permittedExtensions,
        //             _fileSizeLimit);

        //    return 1;
        //}

        
        [Route("Mills")]
        public IActionResult GetMills()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(millsService.GetMills()));
            }           
            catch (Exception ex)
            {
                logger.LogError(ex, "GetMills");
                return StatusCode(500, "internal server error");

            }
        }

        [HttpPost]
        [Route("GetMillsDetail")]
        public IActionResult GetMillsDetail([FromBody] LookupModel lookupModel)
        {
            ModelPaged<MillsModel> mills = new ModelPaged<MillsModel>();
            try
            {
                mills = millsService.GetMillsDetail(lookupModel);
                return Ok(JsonConvert.SerializeObject(mills));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "GetMills");
                return StatusCode(500, "internal server error");
            }
        }

        //[Route("Mill/{id}")]
        //public MillsModel GetMill(int id)
        //{
        //    MillsModel millsModel = new MillsModel();
        //    try
        //    {
        //        millsModel = millsService.GetMill(id);
        //    }
        //    catch (Exception ex)
        //    {
        //        logger.LogError(ex, "GetMill");
        //    }
        //    return millsModel;
        //}

       
        [HttpPost]
        [Route("InsertUpdateMill")]
        public IActionResult InsertUpdateMill(MillsModel millsModel)
        {
            try
            {
                return Ok(millsService.InsertUpdateMill(millsModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "InsertUpdateMill");
                return StatusCode(500, "internal server error");
            }
        }
       
        [HttpPost]
        [Route("DeleteMill/{id}")]
        public IActionResult DeleteMill(int id)
        {
            try
            {
                return Ok(millsService.DeleteMill(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "DeleteMill");
                return StatusCode(500, "internal server error");
            }
        }
    }
}
