﻿using HotOrder.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ShipmentExceptionAPI.Helper;
using System;

namespace HotOrderAPI.Controllers
{
    [ApiController]
    [Route("api/v1")]
    [CheckAuthToken("admin")]
    public class SchedulerController : ControllerBase
    {
        ISchedulerService schedulerService;
        ILogger<SchedulerController> logger;
        IConfiguration config;
        ISoliShipmentDetail soliShipmentDetail;

        public SchedulerController(ISchedulerService _schedulerService, ILogger<SchedulerController> _logger, IConfiguration _config, ISoliShipmentDetail _soliShipmentDetail)
        {
            soliShipmentDetail = _soliShipmentDetail;
            schedulerService = _schedulerService;
            logger = _logger;
            config = _config;
        }
       
        [HttpGet]
        [Route("nightlyrun")]

        public void nightlyrun()
        {
            try
            {
                schedulerService.NightlyRun(config.GetValue<string>("ShipmentExceptionUrl"), soliShipmentDetail);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "NightlyRun");
            }
        }

        [HttpGet]
        [Route("notifyhotorderstatus")]
        public void NotifyHotOrderStatus()
        {
            try
            {
                schedulerService.NotifyHotOrderStatus(config.GetValue<string>("ShipmentExceptionUrl"));
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "NotifyHotOrderStatus");
            }
        }

        [HttpGet]
        [Route("updateexceptiondetails")]
        public void UpdateExceptiondetails()
        {
            try
            {
                schedulerService.UpdateExceptiondetails(config.GetValue<string>("ShipmentExceptionUrl"), soliShipmentDetail);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "UpdateExceptiondetails");
            }
        }

    }
}
