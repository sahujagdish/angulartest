﻿using HotOrder.Data.Model;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;

namespace HotOrderTestProject
{
    public class ConnectionFactory : IDisposable
    {


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        public HotOrderContext CreateContextForInMemory()
        {
            var option = new DbContextOptionsBuilder<HotOrderContext>().UseInMemoryDatabase(databaseName: "Test_Database").Options;

            var context = new HotOrderContext(option);
            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }

            return context;
        }

        public HotOrderContext CreateContextForSQLite()
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();

            var option = new DbContextOptionsBuilder<HotOrderContext>().UseSqlite(connection).Options;

            var context = new HotOrderContext(option);

            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }

            return context;
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
