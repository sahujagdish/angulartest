﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using HotOrder.Service;
using HotOrderTestProject.Helper;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Moq;
using System.Linq;
using System.IO.IsolatedStorage;

namespace HotOrderTestProject
{
    public class HotOrderExceptionServiceTest : TestClassBase
    {
        HotOrderContext context;       

        public HotOrderExceptionServiceTest()
        {            
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_HotOrderExceptionService_Test_Data(context);
        }       

        [Fact, TestPriority(11)]
        public void EnableOtherConfig_ExpectedBehavior()
        {
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();

            var utilities = new Mock<IUtilities>();
            //utilities.Setup(x => x.GetCSTNow()).Returns(sOLIList);
            var mailerService = new Mock<IMailerService>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.EnableOtherConfig(true);
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(11)]
        public void InsertUpdateExceptionDetail_Email()
        {

            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.EnableOtherConfig(true);
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(11)]
        public void GetOtherConfig_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.GetOtherConfig();
            Assert.IsType<bool>(result);
        }

        [Fact, TestPriority(11)]
        public void GetExceptionReason_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.GetExceptionReason();
            Assert.Equal(3, result.Count);
        }

        [Fact, TestPriority(11)]
        public void GetCustomerServiceEmails_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.GetCustomerServiceEmails();
            Assert.Equal(2, result.Count);
        }

        [Fact, TestPriority(11)]
        public void DeleteException_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.DeleteException(1);
            Assert.True(int.Parse(result) > 0);
        }

        [Fact, TestPriority(11)]
        public void GetExceptionDetail_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.GetExceptionDetail(1);
            Assert.NotNull(result);
        }

        [Fact, TestPriority(11)]
        public void GetExceptionDetailList_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            LookupModel lookupModel = new LookupModel();
            lookupModel.SortColumnName = "Salesordernumber";
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            var result = query.GetExceptionDetailList(lookupModel);
            Assert.NotNull(result);
        }

        [Fact, TestPriority(11)]
        public void ExportException_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();
            var mailerService = new Mock<IMailerService>();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities.Object);
            int[] excep = new int[1] {1};
            var result = query.ExportException(excep);
            Console.WriteLine(result);
            Assert.NotNull(result);
        }


        [Fact, TestPriority(1)]
        public void InsertUpdateExceptionDetail_ExpectedBehavior()
        {
            var mailerService = new Mock<IMailerService>();
            InputExceptionModel inputExceptionModel = new InputExceptionModel();
            inputExceptionModel.Id = 0;
            inputExceptionModel.Status = true;
            inputExceptionModel.Salesordernumber = "0101001844";
            inputExceptionModel.Lineitemnumber = "000010";
            inputExceptionModel.Desireddeliverydatetime = DateTime.Now.AddDays(1);
            inputExceptionModel.Desireddeliverytime = "11:00";
            inputExceptionModel.Hotweightrollcount = "1";
            inputExceptionModel.Exceptionreasonid = 1;
            inputExceptionModel.Customerserviceemailid = 1;
            inputExceptionModel.Afterhoursreceivername = "Ramesh";
            inputExceptionModel.Afterhoursreceiverphone = "(943)222-2345";
            inputExceptionModel.Rollstransferfromanothersoli = true;
            inputExceptionModel.OrderDetailList = new List<OrderDetail> {                                                     
                                                    new OrderDetail{ VBELN = "0101001761",POSNR = "000020"},
                                                    new OrderDetail{ VBELN = "0101001766",POSNR = "000020"}};
            inputExceptionModel.Modeshiftrequired = true;
            inputExceptionModel.Shiftedmode = "Shiftedmode1";
            inputExceptionModel.Requestcomments = "Requestcomments12";

            LookupModel lookupModel = new LookupModel();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            mailerService.Setup(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            IUtilities utilities = new Utilities();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities);
            string shipmenturl = "http://gpiptcdwmis1.na.graphicpkg.pri:18555/GPI/SoliShipmentDetail/fetch";
            string defaultemail = "aa@aa.com";

            SOLIList sOLIList = new SOLIList();

            sOLIList.ET_DETAILS = new[] {
                new SOLIDetail {
                    STO_SHIPMENT = "",
                    SOLDTO_CITY = "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "3171.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "1.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "99.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "100.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000010",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "3133.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "3133.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001844",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "158550.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "50.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "75.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "18.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "21931.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "119054.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001761",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003936",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003936",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-05-20",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:16:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003949",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "",
                    PGI_DATE =  "0000-00-00",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-16",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "13:34:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "8.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                }
            };

            soliShipmentDetail.Setup(x => x.GetShipmentData(It.IsAny<string>(), It.IsAny<OrderData>())).Returns(sOLIList);

            var result = query.InsertUpdateExceptionDetail(shipmenturl, defaultemail, inputExceptionModel);

            Assert.True(int.Parse(result) > 0);
        }

        [Fact, TestPriority(1)]
        public void InsertUpdateExceptionDetail_primaryortransfersolinotpresent_ExpectedBehavior()
        {
            var mailerService = new Mock<IMailerService>();
            InputExceptionModel inputExceptionModel = new InputExceptionModel();
            inputExceptionModel.Id = 0;
            inputExceptionModel.Status = true;
            inputExceptionModel.Salesordernumber = "0101001844";
            inputExceptionModel.Lineitemnumber = "000020";
            inputExceptionModel.Desireddeliverydatetime = DateTime.Now.AddDays(1);
            inputExceptionModel.Desireddeliverytime = "11:00";
            inputExceptionModel.Hotweightrollcount = "1";
            inputExceptionModel.Exceptionreasonid = 1;
            inputExceptionModel.Customerserviceemailid = 1;
            inputExceptionModel.Afterhoursreceivername = "Ramesh";
            inputExceptionModel.Afterhoursreceiverphone = "(943)222-2345";
            inputExceptionModel.Rollstransferfromanothersoli = true;
            inputExceptionModel.OrderDetailList = new List<OrderDetail> {
                                                    new OrderDetail{ VBELN = "0101001761",POSNR = "000020"},
                                                    new OrderDetail{ VBELN = "0101001766",POSNR = "000020"}};
            inputExceptionModel.Modeshiftrequired = true;
            inputExceptionModel.Shiftedmode = "Shiftedmode1";
            inputExceptionModel.Requestcomments = "Requestcomments12";

            LookupModel lookupModel = new LookupModel();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            mailerService.Setup(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            IUtilities utilities = new Utilities();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities);
            string shipmenturl = "http://gpiptcdwmis1.na.graphicpkg.pri:18555/GPI/SoliShipmentDetail/fetch";
            string defaultemail = "aa@aa.com";
            SOLIList sOLIList = new SOLIList();

            sOLIList.ET_DETAILS = new[] {
                new SOLIDetail {
                    STO_SHIPMENT = "",
                    SOLDTO_CITY = "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "3171.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "1.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "99.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "100.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000010",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "3133.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "3133.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001844",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "158550.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "50.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "75.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "18.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "21931.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "119054.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001761",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003936",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003936",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-05-20",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:16:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003949",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "",
                    PGI_DATE =  "0000-00-00",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-16",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "13:34:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "8.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                }
            };

            soliShipmentDetail.Setup(x => x.GetShipmentData(It.IsAny<string>(), It.IsAny<OrderData>())).Returns(sOLIList);

            var result = query.InsertUpdateExceptionDetail(shipmenturl, defaultemail, inputExceptionModel);

            Assert.Equal("primaryortransfersolinotpresent", result);
        }

        [Fact, TestPriority(1)]
        public void InsertUpdateExceptionDetail_salesorderandlineitemnumberexists_ExpectedBehavior()
        {
            var mailerService = new Mock<IMailerService>();
            InputExceptionModel inputExceptionModel = new InputExceptionModel();
            inputExceptionModel.Id = 0;
            inputExceptionModel.Status = true;
            inputExceptionModel.Salesordernumber = "0101001761";
            inputExceptionModel.Lineitemnumber = "000010";
            inputExceptionModel.Desireddeliverydatetime = DateTime.Now.AddDays(1);
            inputExceptionModel.Desireddeliverytime = "11:00";
            inputExceptionModel.Hotweightrollcount = "1";
            inputExceptionModel.Exceptionreasonid = 1;
            inputExceptionModel.Customerserviceemailid = 1;
            inputExceptionModel.Afterhoursreceivername = "Ramesh";
            inputExceptionModel.Afterhoursreceiverphone = "(943)222-2345";
            inputExceptionModel.Rollstransferfromanothersoli = true;
            inputExceptionModel.OrderDetailList = new List<OrderDetail> {
                                                    new OrderDetail{ VBELN = "0101001761",POSNR = "000020"},
                                                    new OrderDetail{ VBELN = "0101001766",POSNR = "000020"}};
            inputExceptionModel.Modeshiftrequired = true;
            inputExceptionModel.Shiftedmode = "Shiftedmode1";
            inputExceptionModel.Requestcomments = "Requestcomments12";

            LookupModel lookupModel = new LookupModel();
            var soliShipmentDetail = new Mock<ISoliShipmentDetail>();
            mailerService.Setup(x => x.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Verifiable();
            IUtilities utilities = new Utilities();
            var query = new HotOrderExceptionService(context, soliShipmentDetail.Object, mailerService.Object, utilities);
            string shipmenturl = "http://gpiptcdwmis1.na.graphicpkg.pri:18555/GPI/SoliShipmentDetail/fetch";
            string defaultemail = "aa@aa.com";

            SOLIList sOLIList = new SOLIList();

            sOLIList.ET_DETAILS = new[] {
                new SOLIDetail {
                    STO_SHIPMENT = "",
                    SOLDTO_CITY = "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "3171.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "1.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "99.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "100.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000010",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "3133.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "3133.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001844",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-10 +12",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "158550.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-18",
                    ORDER_UNITS =  "50.000",
                    SHIPTO_NAME =  "MALNOVE INC OF NEBRASKA",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "75.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-22",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZDOM",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "18.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000010556",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1181",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "21931.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "13434 F ST",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                    CUST_PO =  "Test for MultiOrigin",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "119054.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001761",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003936",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003936",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-05-20",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:16:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003938",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "CLNC003938",
                    PGI_DATE =  "2019-05-08",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-04",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "00:24:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "1.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                },
                new SOLIDetail {
                    STO_SHIPMENT =  "",
                    SOLDTO_CITY =  "OMAHA",
                    DEL_WINDOW =  "-25 +03",
                    SHIPTO_COUNTRY =  "US",
                    CONFIRM_QTY =  "36380.000",
                    SHIP_FROM =  "0241",
                    STO =  "",
                    MAD =  "2019-05-09",
                    ORDER_UNITS =  "10.000",
                    SHIPTO_NAME =  "GRATTON WAREHOUSE",
                    ORDER_UNITS_UOM =  "RL",
                    TKNUM =  "3000003949",
                    ACCOUNT_EXECUTIVE =  "BRETT WADE",
                    SHIPTO_CITY =  "OMAHA",
                    SOLDTO_ZIPCD =  "68137-1181",
                    PROD_CONFIRM_PCT =  "26.000",
                    SHIPTO_STATE =  "NE",
                    SOLDTO =  "0000010556",
                    CDD =  "2019-05-13",
                    CONTAINER_ID =  "",
                    PGI_DATE =  "0000-00-00",
                    PICKUP_APPT_DATE_ERLY =  "0000-00-00",
                    SOLDTO_STREET =  "13434 F ST",
                    SOLDTO_COUNTRY =  "US",
                    ORDER_TYPE =  "ZKB",
                    GEWEI =  "LB",
                    SHIP_PROD_PCT =  "67.000",
                    MATNR =  "000000000100033181",
                    VRKME =  "RL",
                    SHIPTO =  "0000614494",
                    POSNR =  "000020",
                    SHIPTO_ZIPCD =  "68137-1228",
                    SCACD =  "CLNC",
                    SHIP_QTY =  "6266.000",
                    DEL_APPT_DATE_EARLY =  "2019-06-16",
                    PICKUP_APPT_TIME_ERLY =  "00:00:00",
                    SHIPTO_STREET =  "11005 E CIR",
                    EPED =  "0000-00-00",
                    ARKTX =  "199#,EVEREST FCB 18PT,35W,70D",
                    CUST_PO =  "testing",
                    SOLDTO_STATE =  "NE",
                    PROD_QTY =  "9399.000",
                    DEL_APPT_TIME_EARLY =  "13:34:00",
                    VBELN =  "0101001766",
                    PLANNED_DELIV_QTY =  "8.000",
                    SOLDTO_NAME =  "MALNOVE INC OF NEBRASKA"
                }
            };

            soliShipmentDetail.Setup(x => x.GetShipmentData(It.IsAny<string>(), It.IsAny<OrderData>())).Returns(sOLIList);

            var result = query.InsertUpdateExceptionDetail(shipmenturl, defaultemail, inputExceptionModel);

            Assert.Equal("salesorderandlineitemnumberexists", result);
        }

        private void Seed_HotOrderExceptionService_Test_Data(HotOrderContext context)
        {
            var mills = new[]
           {
                new Mills{Millnumber = "0241", Millname="Texkarna", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" , Modifiedby="jagdish",Modifieddate=DateTime.Now},
                new Mills{Millnumber = "0660", Millname="Augusta", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now },
                new Mills{Millnumber = "0661", Millname="Reigelwood", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now }
            };
            context.Mills.AddRange(mills);
            context.SaveChanges();

            var ordertypes = new[]
            {
                new Ordertypes{Ordertype = "ZDOM", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" , Modifiedby="jagdish",Modifieddate=UtilitiesTest.GetCSTNow()},
                new Ordertypes{Ordertype = "ZKB", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" , Modifiedby="jagdish",Modifieddate=UtilitiesTest.GetCSTNow()},
                new Ordertypes{Ordertype = "ZEXP", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" , Modifiedby="jagdish",Modifieddate=UtilitiesTest.GetCSTNow()}
            };
            context.Ordertypes.AddRange(ordertypes);
            context.SaveChanges();

            var mailinglist = new[]
            {
                new Mailinglist{Millid = 1, Ordertypeid = 1, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now },
                new Mailinglist{Millid = 1, Ordertypeid = 2, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" , Modifiedby="jagdish",Modifieddate=DateTime.Now},
                new Mailinglist{Millid = 2, Ordertypeid = 3,  Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now }
            };
            context.Mailinglist.AddRange(mailinglist);

            var exceptionreasonsList = new[]
           {
                new Exceptionreasons{Id=1, Exceptionreason = "Customer Need", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now },
                new Exceptionreasons{Id=2, Exceptionreason = "Delayed Production/Product Availability", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=UtilitiesTest.GetCSTNow() },
                new Exceptionreasons{Id=3, Exceptionreason = "Mode Shift", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=DateTime.Now },
            };
            context.Exceptionreasons.AddRange(exceptionreasonsList);

            var customerserviceemailsList = new[]
            {
                new Customerserviceemails{Id=1, Customerserviceemail = "texkarma@graphicpakaging.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate= UtilitiesTest.GetCSTNow() },
                new Customerserviceemails{Id=2, Customerserviceemail = "texkarma1@graphicpakaging.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate= UtilitiesTest.GetCSTNow() }               
            };
            context.Customerserviceemails.AddRange(customerserviceemailsList);

            context.OtherConfig.AddRange(new OtherConfig { IsEnable = true });

            var exception = new[]
            {
                new Exceptions{ Id = 1,Salesordernumber="0101001761", Lineitemnumber="000010", Status= true,                    
                    Exceptionreasonid=1, Hotweightrollcount="1", Rollstransferfromanothersoli=true, Modeshiftrequired=true, Shiftedmode="struck", Modeforbalance="12345",
                    Requestcomments="comments", Afterhoursreceivername="john", Afterhoursreceiverphone="(757) 452-8933", Customerserviceemailid = 1, 
                    Desireddeliverydatetime=DateTime.Now.AddDays(1),Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish",Modifieddate=UtilitiesTest.GetCSTNow(),
                    Exceptiondetails = new List<Exceptiondetails>{ 
                        new Exceptiondetails{
                            Exceptionid=1,
                            Hasexception = true,
                            StoShipment = "",
                            SoldtoCity = "OMAHA",
                            DelWindow = "-10 +12",
                            ShiptoCountry = "US",
                            ConfirmQty = "3171.000",
                            ShipFrom = "0241",
                            Sto = "",
                            Mad = DateTime.Now,
                            OrderUnits = "1.000",
                            ShiptoName = "MALNOVE INC OF NEBRASKA",
                            OrderUnitsUom =  "RL",
                            Tknum = "3000003938",
                            AccountExecutive = "BRETT WADE",
                            ShiptoCity = "OMAHA",
                            SoldtoZipcd = "68137-1181",
                            ProdConfirmPct = "99.000",
                            ShiptoState = "NE",
                            Soldto =  "0000010556",
                            Cdd =  DateTime.Now,
                            ContainerId =  "CLNC003938",
                            PgiDate =  DateTime.Now,
                            PickupApptDateErly = DateTime.Now,
                            SoldtoStreet =  "13434 F ST",
                            SoldtoCountry =  "US",
                            OrderType =  "ZDOM",
                            Gewei =  "LB",
                            ShipProdPct =  "100.000",
                            Matnr =  "000000000100033181",
                            Vrkme =  "RL",
                            Shipto =  "0000010556",
                            Lineitemnumber =  "000010",
                            ShiptoZipcd =  "68137-1181",
                            Scacd =  "CLNC",
                            ShipQty =  "3133.000",
                            DelApptDateEarly =  DateTime.Now,
                            PickupApptTimeErly =  new TimeSpan(),
                            ShiptoStreet =  "13434 F ST",
                            Eped =  DateTime.Now,
                            Arktx =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                            CustPo =  "Test for MultiOrigin",
                            SoldtoState =  "NE",
                            ProdQty =  "3133.000",
                            DelApptTimeEarly = new TimeSpan(),
                            Salesordernumber =  "0101001844",
                            PlannedDelivQty =  "1.000",
                            SoldtoName =  "MALNOVE INC OF NEBRASKA",
                            Createdby="agdish",
                            Createddate=DateTime.Now,
                            Modifiedby="jagdish",
                            Modifieddate=DateTime.Now
                            },
                        new Exceptiondetails{
                        Hasexception = true,
                        StoShipment = "",
                        SoldtoCity = "OMAHA",
                        DelWindow = "-10 +12",
                        ShiptoCountry = "US",
                        ConfirmQty = "3171.000",
                        ShipFrom = "0241",
                        Sto = "",
                        Mad = DateTime.Now,
                        OrderUnits = "1.000",
                        ShiptoName = "MALNOVE INC OF NEBRASKA",
                        OrderUnitsUom =  "RL",
                        Tknum = "3000003938",
                        AccountExecutive = "BRETT WADE",
                        ShiptoCity = "OMAHA",
                        SoldtoZipcd = "68137-1181",
                        ProdConfirmPct = "99.000",
                        ShiptoState = "NE",
                        Soldto =  "0000010556",
                        Cdd =  DateTime.Now,
                        ContainerId =  "CLNC003938",
                        PgiDate =  DateTime.Now,
                        PickupApptDateErly = DateTime.Now,
                        SoldtoStreet =  "13434 F ST",
                        SoldtoCountry =  "US",
                        OrderType =  "ZDOM",
                        Gewei =  "LB",
                        ShipProdPct =  "100.000",
                        Matnr =  "000000000100033181",
                        Vrkme =  "RL",
                        Shipto =  "0000010556",
                        Lineitemnumber =  "000010",
                        ShiptoZipcd =  "68137-1181",
                        Scacd =  "CLNC",
                        ShipQty =  "3133.000",
                        DelApptDateEarly =  DateTime.Now,
                        PickupApptTimeErly =  new TimeSpan(),
                        ShiptoStreet =  "13434 F ST",
                        Eped =  DateTime.Now,
                        Arktx =  "199#,EVEREST FCB 18PT,30 1/2W,70D",
                        CustPo =  "Test for MultiOrigin",
                        SoldtoState =  "NE",
                        ProdQty =  "3133.000",
                        DelApptTimeEarly = new TimeSpan(),
                        Salesordernumber =  "0101001761",
                        PlannedDelivQty =  "1.000",
                        SoldtoName =  "MALNOVE INC OF NEBRASKA",
                        Createdby="agdish",
                        Createddate=DateTime.Now,
                        Modifiedby="jagdish",
                        Modifieddate=DateTime.Now
                        }
                    }
                }
            };
            context.Exceptions.AddRange(exception);
            context.SaveChanges();
        }
    }
}
