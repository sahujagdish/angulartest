using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using HotOrder.Service;
using HotOrderTestProject.Helper;
using Xunit;

namespace HotOrderTestProject
{    
    public class MillsServiceTests : TestClassBase
    {
        HotOrderContext context;
        public MillsServiceTests()
        {
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_MillsService_Test_Data(context);
        }

        [Fact, TestPriority(1)]
        public void GetMillsDetail_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            LookupModel lookupModel = new LookupModel();
            var query = new MillsService(context, utilities);
            var result = query.GetMillsDetail(lookupModel);
            Assert.Equal(3, result.PagedDataModel.Count);
        }


        [Fact, TestPriority(2)]
        public void InsertUpdateMill_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MillsService(context, utilities);
            MillsModel millsModel = new MillsModel();
            millsModel.MillId = 0;
            millsModel.Millnumber = "0999";
            millsModel.Millname = "Florida";
            millsModel.Createdby = "jagdish";
            millsModel.Createddate = UtilitiesTest.GetCSTNow();
            // Act
            var result = service.InsertUpdateMill(
                millsModel);
            // Assert
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(3)]
        public void InsertUpdateMill_millexists_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MillsService(context, utilities);
            MillsModel millsModel = new MillsModel();
            millsModel.MillId = 0;
            millsModel.Millnumber = "7108";
            millsModel.Millname = "CedarRiver";
            millsModel.Createdby = "jagdish";
            millsModel.Createddate = UtilitiesTest.GetCSTNow();
            // Act
            var result = service.InsertUpdateMill(millsModel);
            // Assert
            Assert.Equal("millexists", result);
        }

        [Fact, TestPriority(4)]
        public void GetMills_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            var service = new MillsService(context, utilities);
            // Act
            var result = service.GetMills();

            // Assert
            Assert.Equal(3, result.Count);
        }

        [Fact, TestPriority(5)]
        public void DeleteMill_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MillsService(context, utilities);
            int id = 1;

            // Act
            var result = service.DeleteMill(
                id);  

            // Assert
            Assert.Equal(1, int.Parse(result));
        }

        private void Seed_MillsService_Test_Data(HotOrderContext context)
        {
            var mills = new[]
            {
                new Mills{Millnumber = "7108", Millname="CedarRiver", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mills{Millnumber = "0660", Millname="Augusta", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mills{Millnumber = "0661", Millname="Reigelwood", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" }
            };

            context.Mills.AddRange(mills);
            context.SaveChanges();
        }


    }

}
