﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotOrderTestProject.Helper
{
    public class UtilitiesTest
    {
        public static DateTime GetCSTNow()
        {
            DateTime cstNow;
            try
            {
                TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                cstNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cstZone);
            }
            catch
            {
                cstNow = DateTime.UtcNow;
            }
            return cstNow;
        }
    }
}
