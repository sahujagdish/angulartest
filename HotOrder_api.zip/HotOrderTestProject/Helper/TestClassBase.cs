﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HotOrderTestProject.Helper
{    
    [TestCaseOrderer("HotOrderTestProject.Helper.TestCaseOrderer", "HotOrderTestProject")]    
    public abstract class TestClassBase
    {
    }
}
