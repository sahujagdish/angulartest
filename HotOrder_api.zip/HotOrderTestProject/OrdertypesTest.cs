﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using HotOrder.Service;
using HotOrderTestProject.Helper;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace HotOrderTestProject
{    
    public class OrdertypesTest : TestClassBase
    {
        HotOrderContext context;
        public OrdertypesTest()
        {
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_OrdertypesService_Test_Data(context);
        }

        [Fact, TestPriority(6)]
        public void GetOrderTypeList_ExpectedBehavior()
        {
            IUtilities util = new Utilities();
            // Arrange
            LookupModel lookupModel = new LookupModel();
            var query = new OrderTypeService(context, util);
            var result = query.GetOrderTypeList(lookupModel);
            Assert.Equal(3, result.PagedDataModel.Count);
        }


        [Fact, TestPriority(7)]
        public void InsertUpdateOrdetypes_ExpectedBehavior()
        {
            IUtilities util = new Utilities();
            // Arrange
            var service = new OrderTypeService(context, util);
            OrderTypesModel orderTypesModel = new OrderTypesModel();
            orderTypesModel.OrdertypeId = 0;
            orderTypesModel.Ordertype = "ECO";            
            orderTypesModel.Createdby = "jagdish";
            orderTypesModel.Createddate = util.GetCSTNow();
            // Act
            var result = service.InsertUpdateOrderType(orderTypesModel);
            // Assert
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(8)]
        public void InsertUpdateOrdetypes_ordertypeexists_ExpectedBehavior()
        {
            IUtilities util = new Utilities();
            // Arrange
            var service = new OrderTypeService(context, util);
            OrderTypesModel orderTypesModel = new OrderTypesModel();
            orderTypesModel.OrdertypeId = 1;
            orderTypesModel.Ordertype = "ZDOM";
            orderTypesModel.Createdby = "jagdish";
            orderTypesModel.Createddate = util.GetCSTNow();
            // Act
            var result = service.InsertUpdateOrderType(orderTypesModel);
            // Assert
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(9)]
        public void GetOrdetypes_ExpectedBehavior()
        {
            IUtilities util = new Utilities();
            var service = new OrderTypeService(context, util);
            // Act
            var result = service.GetOrderTypes();
            // Assert
            Assert.Equal(3, result.Count);
        }

        [Fact, TestPriority(10)]
        public void DeleteMill_ExpectedBehavior()
        {
            var utilities = new Mock<IUtilities>();

            IUtilities util = new Utilities();
            
            // Arrange
            var service = new OrderTypeService(context, util);
            int id = 1;

            // Act
            var result = service.DeleteOrderType(id);

            // Assert
            Assert.Equal(1, int.Parse(result));
        }

        private void Seed_OrdertypesService_Test_Data(HotOrderContext context)
        {
            var ordertypes = new[]
            {
                new Ordertypes{Ordertype = "ZDOM", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Ordertypes{Ordertype = "ZKB", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Ordertypes{Ordertype = "ZEXP", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" }
            };

            context.Ordertypes.AddRange(ordertypes);
            context.SaveChanges();
        }


    }
}
