﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using HotOrder.Service;
using HotOrderTestProject.Helper;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

[assembly:CollectionBehavior(DisableTestParallelization = true)]

namespace HotOrderTestProject
{    
    public class MailingListServiceTest : TestClassBase
    {
        HotOrderContext context;
        public MailingListServiceTest()
        {
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_MailinglistService_Test_Data(context);
        }

        [Fact, TestPriority(11)]
        public void GetMailingList_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            LookupModel lookupModel = new LookupModel();
            lookupModel.SortColumnName = "Millnumber";
            var query = new MailingListService(context, utilities);
            var result = query.GetMailingList(lookupModel);
            Assert.Equal(3, result.PagedDataModel.Count);
        }


        [Fact, TestPriority(12)]
        public void InsertUpdateMailingList_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MailingListService(context, utilities);
            MailingListModel mailingListModel = new MailingListModel();
            mailingListModel.OrdertypeId = 1;
            mailingListModel.MillId = 2;
            mailingListModel.Planningteamdl = "jagdish.sahu@graphicpkg.com";
            mailingListModel.Executionteamdl = "jagdish.sahu@graphicpkg.com";
            mailingListModel.Createdby = "jagdish";
            mailingListModel.Createddate = UtilitiesTest.GetCSTNow();
            // Act
            var result = service.InsertUpdateMailingList(mailingListModel);
            // Assert
            Assert.Equal("1", result);
        }

        [Fact, TestPriority(13)]
        public void InsertUpdateMailingList_CombinationAllreadyExists_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MailingListService(context, utilities);
            MailingListModel mailingListModel = new MailingListModel();
            mailingListModel.OrdertypeId = 2;
            mailingListModel.MillId = 1;
            mailingListModel.Planningteamdl = "jagdish.sahu@graphicpkg.com";
            mailingListModel.Executionteamdl = "jagdish.sahu@graphicpkg.com";
            mailingListModel.Createdby = "jagdish";
            mailingListModel.Createddate = UtilitiesTest.GetCSTNow();
            // Act
            var result = service.InsertUpdateMailingList(mailingListModel);
            // Assert
            Assert.Equal("CombinationAllreadyExists", result);
        }

        [Fact, TestPriority(14)]
        public void DeleteMailingList_ExpectedBehavior()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            var service = new MailingListService(context, utilities);
            int id = 1;
            // Act
            var result = service.DeleteMailingList(id);
            // Assert
            Assert.Equal(1, int.Parse(result));
        }

        private void Seed_MailinglistService_Test_Data(HotOrderContext context)
        {
            var mills = new[]
           {
                new Mills{Millnumber = "7108", Millname="CedarRiver", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mills{Millnumber = "0660", Millname="Augusta", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mills{Millnumber = "0661", Millname="Reigelwood", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" }
            };
            context.Mills.AddRange(mills);
            context.SaveChanges();

            var ordertypes = new[]
            {
                new Ordertypes{Ordertype = "ZDOM", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Ordertypes{Ordertype = "ZKB", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Ordertypes{Ordertype = "ZEXP", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" }
            };
            context.Ordertypes.AddRange(ordertypes);
            context.SaveChanges();

            var mailinglist = new[]
            {
                new Mailinglist{Millid = 1, Ordertypeid = 1, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mailinglist{Millid = 1, Ordertypeid = 2, Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" },
                new Mailinglist{Millid = 2, Ordertypeid = 3,  Planningteamdl = "jagdish.sahu@graphicpkg.com", Executionteamdl = "jagdish.sahu@graphicpkg.com", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish" }
            };

            context.Mailinglist.AddRange(mailinglist);
            context.SaveChanges();
        }
    }
}
