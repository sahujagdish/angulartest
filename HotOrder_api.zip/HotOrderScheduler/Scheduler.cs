using IdentityModel.Client;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using ILogger = Microsoft.Extensions.Logging.ILogger;
//using ILogger = Serilog.ILogger;

namespace HotOrderScheduler
{
    public class Scheduler
    {
        ILogger<Scheduler> logger;
        IConfiguration config;

        public Scheduler(ILogger<Scheduler> _logger, IConfiguration _config)
        {
            logger = _logger;
            config = _config;
            
        }

        //00:00 (Midnight)
        [FunctionName("nightlyrun")]
        public async void nightlyrun([TimerTrigger("0 */1 * * * *")] TimerInfo myTimer, ILogger log)
        {
            HttpClient client = new HttpClient();

            try
            {
                log.LogInformation("nightlyrun start - " + DateTime.Now);

                Task<string> token = Tokencredential.GetToken();
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Result);
                string setting = config["url"] + "nightlyrun";                
                client.GetAsync($"{setting}");
                log.LogInformation("nightlyrun end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler nightlyrun" + ex.Message);
            }
        }

        //6 AM and 2 PM CST
        [FunctionName("notifyhotorderstatus")]
        public void notifyhotorderstatus([TimerTrigger("0 */1 * * * *")] TimerInfo myTimer, ILogger log)
        {
            HttpClient client = new HttpClient();
            try
            {
                log.LogInformation("notifyhotorderstatus start - " + DateTime.Now);                
                Task<string> token = Tokencredential.GetToken();
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Result);
                string setting = config["url"] + "notifyhotorderstatus";
                var response = client.GetAsync($"{setting}");
                log.LogInformation("notifyhotorderstatus end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler notifyhotorderstatus " + ex.Message);
            }
        }

        // Every 30 minutes
        [FunctionName("updateexceptiondetails")]
        public async void updateexceptiondetails([TimerTrigger("0 */1 * * * *")] TimerInfo myTimer, ILogger log)
        {
            HttpClient client = new HttpClient();
            try
            {
                log.LogInformation("updateexceptiondetails start - " + DateTime.Now);               
                Task<string> token = Tokencredential.GetToken();
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token.Result);
                string setting = config["url"] + "updateexceptiondetails";
                var response = client.GetAsync($"{setting}");
                log.LogInformation("updateexceptiondetails end - " + DateTime.Now);
            }
            catch (Exception ex)
            {
                logger.LogError("scheduler updateexceptiondetails " + ex.Message);
            }
        }
    }


    static class Tokencredential
    {
        public async static Task<string> GetToken()
        {
            try
            {
                HttpClient client = new HttpClient();
                var response1 = await client.RequestTokenAsync(new ClientCredentialsTokenRequest
                {
                    Address = "https://gpi.my.idaptive.app/oauth2/token/oauthcustomapp",
                    ClientId = "hotapiuser@graphicpkg.com",
                    ClientSecret = @"ksN>c.q\M392jwU_psI3d^>n}o-&;?pJ,}BLf:+A",
                    Scope = "oauth",
                    GrantType = "client_credentials"
                });

                return response1.AccessToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
