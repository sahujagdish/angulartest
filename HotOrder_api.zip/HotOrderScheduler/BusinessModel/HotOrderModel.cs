﻿using System.Collections.Generic;

namespace HotOrderScheduler.BusinessModel
{
    class HotOrderModel
    {
    }

    public class ShpDet
    {
        public string TKNUM { get; set; }
    }
    public class OrderDetail
    {
        public string VBELN { get; set; }
        public string POSNR { get; set; }
    }

    public class Orders
    {
        public List<OrderDetail> IT_ORDERS { get; set; }
        public List<ShpDet> IT_SHIPNO { get; set; }
    }

    public class OrderData
    {
        public Orders Orders { get; set; }
    }


    public class SOLIList
    {
        public SOLIDetail[] ET_DETAILS { get; set; }
    };


    public class SOLIDetail
    {
        public string STO_SHIPMENT { get; set; }
        public string SOLDTO_CITY { get; set; }
        public string DEL_WINDOW { get; set; }
        public string SHIPTO_COUNTRY { get; set; }
        public string CONFIRM_QTY { get; set; }
        public string SHIP_FROM { get; set; }
        public string STO { get; set; }
        public string MAD { get; set; }
        public string ORDER_UNITS { get; set; }
        public string SHIPTO_NAME { get; set; }
        public string ORDER_UNITS_UOM { get; set; }
        public string TKNUM { get; set; }
        public string ACCOUNT_EXECUTIVE { get; set; }
        public string SHIPTO_CITY { get; set; }
        public string SOLDTO_ZIPCD { get; set; }
        public string PROD_CONFIRM_PCT { get; set; }
        public string SHIPTO_STATE { get; set; }
        public string SOLDTO { get; set; }
        public string CDD { get; set; }
        public string CONTAINER_ID { get; set; }
        public string PGI_DATE { get; set; }
        public string PICKUP_APPT_DATE_ERLY { get; set; }
        public string SOLDTO_STREET { get; set; }
        public string SOLDTO_COUNTRY { get; set; }
        public string ORDER_TYPE { get; set; }
        public string GEWEI { get; set; }
        public string SHIP_PROD_PCT { get; set; }
        public string MATNR { get; set; }
        public string VRKME { get; set; }
        public string SHIPTO { get; set; }
        public string POSNR { get; set; }
        public string SHIPTO_ZIPCD { get; set; }
        public string SCACD { get; set; }
        public string SHIP_QTY { get; set; }
        public string DEL_APPT_DATE_EARLY { get; set; }
        public string PICKUP_APPT_TIME_ERLY { get; set; }
        public string SHIPTO_STREET { get; set; }
        public string EPED { get; set; }
        public string ARKTX { get; set; }
        public string CUST_PO { get; set; }
        public string SOLDTO_STATE { get; set; }
        public string PROD_QTY { get; set; }
        public string DEL_APPT_TIME_EARLY { get; set; }
        public string VBELN { get; set; }
        public string PLANNED_DELIV_QTY { get; set; }
        public string SOLDTO_NAME { get; set; }
    }
}
