﻿using HotOrderScheduler;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.AzureTableStorage.KeyGenerator;
using System;

[assembly: WebJobsStartup(typeof(Startup))]

namespace HotOrderScheduler
{
    public class Startup : IWebJobsStartup
    {
        public void Configure(IWebJobsBuilder builder)
        {
            // var storage = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));

            var config = new ConfigurationBuilder()
            .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables()
            .Build();

            builder.Services.AddLogging(
                lb => lb.AddSerilog(
                        new LoggerConfiguration()
                            .WriteTo.Console()
                            .WriteTo.File("C:\\\\Demos\\Logs1\\Logs.txt")
                            .WriteTo.AzureTableStorage("DefaultEndpointsProtocol=https;AccountName=usazr3intdevsa001hot;AccountKey=fZcc8P/AZrBwFdX5GmvWgtVMxRqiVpuseJ5rDGb+jwML6PCnWBGqff6cSlJD1mkWi6CstZOTSWgs7WNValyJ/g==;EndpointSuffix=core.windows.net", LogEventLevel.Verbose, null, "hotorderserilog", false, null, null, new MyKeyGenerator())
                            .CreateLogger(),
                        dispose: true)); ;
        }
    }

    public class MyKeyGenerator : IKeyGenerator
    {
        string IKeyGenerator.GeneratePartitionKey(LogEvent logEvent)
        {
            return (DateTime.MaxValue.Ticks - logEvent.Timestamp.Ticks).ToString().Substring(0, 9);
        }

        string IKeyGenerator.GenerateRowKey(LogEvent logEvent, string suffix)
        {
            return (DateTime.MaxValue.Ticks - logEvent.Timestamp.Ticks).ToString() + "." + Guid.NewGuid().ToString();
        }
    }
}
