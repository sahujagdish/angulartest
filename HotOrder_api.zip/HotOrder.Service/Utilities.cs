﻿using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Runtime.InteropServices;

namespace HotOrder.Service
{
    public interface IUtilities
    {
        string PrefixZero(string str, int digits);
        DateTime GetCSTNow();
        // int ToInt32(string s)

    }
    public class Utilities : IUtilities
    {
        public string PrefixZero(string str, int digits)
        {
            try
            {
                string zero = "0000000000000000000000000000";
                int length = str.Length;
                int diff = digits - length;
                string z = "";
                if (diff < 0)
                {
                    z = str.Substring(0, digits);
                }
                else
                {
                    z = zero.Substring(1, diff);
                    z = z + str;
                }


                Log.Information(z);
                return z;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DateTime GetCSTNow()
        {
            DateTime cstNow;
            try
            {
                TimeZoneInfo cstZone = null;
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                else
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("America/Chicago");
                    
                cstNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cstZone);
            }
            catch (TimeZoneNotFoundException ex)
            {
                cstNow = DateTime.UtcNow;
                Log.Error(ex.Message);
            }
            catch (InvalidTimeZoneException ex)
            {
                cstNow = DateTime.UtcNow;
                Log.Error(ex.Message);
                //Log using what ever logging mechanism that you are saving time in Utc, because, the registry data on the Central Standard Time zone has been corrupted.
            }
            return cstNow;

        }

        //public int ToInt32(string s)
        //{
        //    try
        //    {
        //        return int.Parse(s);
        //    }
        //    catch
        //    {
        //    }
        //    return 0;
        //}       


    }


    public static class UtilityExtn
    {
        public static decimal Number(this string s)
        {
            try
            {
                return Math.Round(Convert.ToDecimal(s), 0, MidpointRounding.ToZero);
            }
            catch
            {
            }
            return 0;
        }

        public static List<T> Clone<T>(this List<T> listToClone) where T : ICloneable
        {
            return listToClone.Select(item => (T)item.Clone()).ToList();
        }
    }
}
