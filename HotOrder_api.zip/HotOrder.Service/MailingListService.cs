﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HotOrder.Service
{
    public interface IMailingListService
    {
        ModelPaged<MailingListModel> GetMailingList(LookupModel LookupModel);
        MailingListModel GetMailingList(int id);
        string InsertUpdateMailingList(MailingListModel MailingListModel);
        string DeleteMailingList(int id);
    }

    public class MailingListService : IMailingListService
    {
        HotOrderContext context;
        IUtilities utilities;
        public MailingListService(HotOrderContext _context, IUtilities _utilities)
        {
            context = _context;
            utilities = _utilities;
        }

        public ModelPaged<MailingListModel> GetMailingList(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var query = from mll in context.Mailinglist.AsQueryable().Include(m => m.Mill).Include(o => o.Ordertype)
                        select new MailingListModel
                        {
                            Id = mll.Id,
                            OrdertypeId = mll.Ordertypeid.Value,
                            Ordertype = mll.Ordertype.Ordertype,
                            MillId = mll.Millid.Value,
                            Executionteamdl = mll.Executionteamdl,
                            Planningteamdl = mll.Planningteamdl,
                            Millnumber = mll.Mill.Millnumber,
                            Millname = mll.Mill.Millname,
                            Createdby = mll.Createdby,
                            Createddate = mll.Createddate,
                            Modifiedby = mll.Modifiedby,
                            Modifieddate = mll.Modifieddate
                        };

            var propertyInfo = typeof(MailingListModel).GetProperty(lookupModel.SortColumnName);
            var result = new List<MailingListModel>();

            if (lookupModel.SortOrder == "ASC")
                result = query.ToList().OrderBy(x => propertyInfo.GetValue(x, null)).ToList();
            else
                result = query.ToList().OrderByDescending(x => propertyInfo.GetValue(x, null)).ToList();

            var ml = new ModelPaged<MailingListModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return ml;
        }

        public MailingListModel GetMailingList(int id)
        {
            return context.Mailinglist.Where(x => x.Id == id).Select(x =>
               new MailingListModel
               {
                   Id = x.Id,
                   OrdertypeId = x.Ordertypeid.Value,
                   Ordertype = x.Ordertype.Ordertype,
                   MillId = x.Millid.Value,
                   Executionteamdl = x.Executionteamdl,
                   Planningteamdl = x.Planningteamdl,
                   Millnumber = x.Mill.Millnumber,
                   Millname = x.Mill.Millname,
                   Createdby = x.Createdby,
                   Createddate = x.Createddate,
                   Modifiedby = x.Modifiedby,
                   Modifieddate = x.Modifieddate
               }).FirstOrDefault();
        }

        public string InsertUpdateMailingList(MailingListModel mailingListModel)
        {
            Mailinglist mailingListExists = context.Mailinglist.Where(x => x.Id == mailingListModel.Id).FirstOrDefault();

            Mailinglist similarListInOtherId = context.Mailinglist
                    .Where(x => (x.Ordertypeid == mailingListModel.OrdertypeId && x.Millid == mailingListModel.MillId && x.Id != mailingListModel.Id)).FirstOrDefault();

            if (similarListInOtherId != null)
            {
                return "CombinationAllreadyExists";
            }

            DateTime cst = utilities.GetCSTNow();

            if (mailingListExists != null)
            {
                mailingListExists.Ordertypeid = mailingListModel.OrdertypeId;
                mailingListExists.Millid = mailingListModel.MillId;
                mailingListExists.Executionteamdl = mailingListModel.Executionteamdl;
                mailingListExists.Planningteamdl = mailingListModel.Planningteamdl;
                mailingListExists.Modifiedby = mailingListModel.Modifiedby;
                mailingListExists.Modifieddate = cst;
                context.Mailinglist.Attach(mailingListExists);
                context.Entry(mailingListExists).State = EntityState.Modified;
            }
            else
            {
                context.Mailinglist.Add(
                new Mailinglist()
                {
                    Ordertypeid = mailingListModel.OrdertypeId,
                    Millid = mailingListModel.MillId,
                    Executionteamdl = mailingListModel.Executionteamdl,
                    Planningteamdl = mailingListModel.Planningteamdl,
                    Createdby = mailingListModel.Createdby,
                    Createddate = cst,
                    Modifiedby = mailingListModel.Createdby,
                    Modifieddate = cst
                });
            }

            return Convert.ToString(context.SaveChanges());
        }

        public string DeleteMailingList(int id)
        {
            Mailinglist MailingListExists = context.Mailinglist.Where(x => x.Id == id).FirstOrDefault();

            if (MailingListExists != null)
            {
                context.Mailinglist.Remove(MailingListExists);
                return Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }
    }
}
