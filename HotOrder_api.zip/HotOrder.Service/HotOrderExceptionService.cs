﻿using ClosedXML.Excel;
using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace HotOrder.Service
{
    public interface IHotOrderExceptionService
    {
        List<CommonModel> GetExceptionReason();
        List<CommonModel> GetCustomerServiceEmails();
        ModelPaged<ExceptionListModel> GetExceptionDetailList(LookupModel lookupModel);
        ExceptionModel GetExceptionDetail(int id);
        string InsertUpdateExceptionDetail(string shipmentURL, string defaultemail, InputExceptionModel inputExceptionModel);
        string DeleteException(int id);
        string EnableOtherConfig(bool isEnable);
        bool GetOtherConfig();
        Stream ExportException(int[] exception);
        void EmailtoGPITeam(int id, string defaultemail);
    }
    public class HotOrderExceptionService : IHotOrderExceptionService
    {
        HotOrderContext context;
        ISoliShipmentDetail soliShipmentDetail;
        IUtilities utilities;
        IMailerService mailerService;
        public HotOrderExceptionService(HotOrderContext _context, ISoliShipmentDetail _soliShipmentDetail, IMailerService _mailerService, IUtilities _utilities)
        {
            context = _context;
            soliShipmentDetail = _soliShipmentDetail;
            mailerService = _mailerService;
            utilities = _utilities;
        }

        public string EnableOtherConfig(bool isEnable)
        {
            OtherConfig otherConfig = context.OtherConfig.FirstOrDefault();
            if (otherConfig != null)
            {
                otherConfig.IsEnable = isEnable;
                context.OtherConfig.Update(otherConfig);
                this.context.Entry(otherConfig).State = EntityState.Modified;
            }
            return Convert.ToString(context.SaveChanges());
        }

        public bool GetOtherConfig()
        {
            return context.OtherConfig.Select(x => x.IsEnable).FirstOrDefault();
        }

        public List<CommonModel> GetExceptionReason()
        {
            return context.Exceptionreasons.Select(
              x => new CommonModel()
              {
                  Id = x.Id,
                  Name = x.Exceptionreason
              }
            ).ToList();
        }

        public List<CommonModel> GetCustomerServiceEmails()
        {
            return context.Customerserviceemails.Select(
              x => new CommonModel()
              {
                  Id = x.Id,
                  Name = x.Customerserviceemail
              }
            ).ToList();
        }

        public string DeleteException(int id)
        {
            Exceptions exceptionexists = context.Exceptions.Where(x => x.Id == id).FirstOrDefault();
            context.Exceptions.Remove(exceptionexists);
            return Convert.ToString(context.SaveChanges());
        }

        public ExceptionModel GetExceptionDetail(int id)
        {
            // EmailtoGPITeam();


            var result = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Id == id).Select(x =>
                  new ExceptionModel()
                  {
                      Id = x.Id,
                      Salesordernumber = x.Salesordernumber,
                      Lineitemnumber = x.Lineitemnumber,
                      Desireddeliverydatetime = x.Desireddeliverydatetime,
                      Hotweightrollcount = x.Hotweightrollcount,
                      Exceptionreasonid = x.Exceptionreasonid,
                      Customerserviceemailid = x.Customerserviceemailid,
                      Afterhoursreceivername = x.Afterhoursreceivername,
                      Afterhoursreceiverphone = x.Afterhoursreceiverphone,
                      Rollstransferfromanothersoli = x.Rollstransferfromanothersoli,
                      Modeshiftrequired = x.Modeshiftrequired,
                      Shiftedmode = x.Shiftedmode,
                      Modeforbalance = x.Modeforbalance,
                      Requestcomments = x.Requestcomments,
                      Createdby = x.Createdby,
                      Createddate = x.Createddate,
                      Modifiedby = x.Modifiedby,
                      Modifieddate = x.Modifieddate,
                      //TransferSoli = x.Rollstransferfromanothersoli == true ? x.Exceptiondetails.Where(e => e.Hasexception == true && !(e.Salesordernumber == x.Salesordernumber && e.Lineitemnumber == x.Lineitemnumber))
                      //.Select(e => new TransferSoliModel()
                      //{
                      //    Lineitemnumber = e.Lineitemnumber,
                      //    Salesordernumber = e.Salesordernumber
                      //}).ToList() : new List<TransferSoliModel>(),
                      Exceptiondetails = x.Exceptiondetails.Select(e => new ExceptiondetailsModel()
                      {
                          Isprimary = (e.Exception.Salesordernumber == e.Salesordernumber && e.Exception.Lineitemnumber == e.Lineitemnumber),
                          Hasexception = e.Hasexception,
                          AccountExecutive = e.AccountExecutive,
                          Arktx = e.Arktx,
                          Cdd = e.Cdd,
                          ConfirmQty = e.ConfirmQty,
                          ContainerId = e.ContainerId,
                          CustPo = e.CustPo,
                          DelApptDateEarly = e.DelApptDateEarly,
                          DelApptTimeEarly = e.DelApptTimeEarly,
                          DelWindow = e.DelWindow,
                          Eped = e.Eped,
                          Gewei = e.Gewei,
                          Lineitemnumber = e.Lineitemnumber,
                          Mad = e.Mad,
                          Matnr = e.Matnr,
                          OrderType = e.OrderType,
                          OrderUnits = e.OrderUnits,
                          OrderUnitsUom = e.OrderUnitsUom,
                          PgiDate = e.PgiDate,
                          PickupApptDateErly = e.PickupApptDateErly,
                          PickupApptTimeErly = e.PickupApptTimeErly,
                          PlannedDelivQty = e.PlannedDelivQty,
                          ProdConfirmPct = e.ProdConfirmPct,
                          ProdQty = e.ProdQty,
                          Salesordernumber = e.Salesordernumber,
                          Scacd = e.Scacd,
                          ShipFrom = context.Mills.Where(m => m.Millnumber == e.ShipFrom).Select(m => m.Millname).FirstOrDefault() == null ? e.ShipFrom : context.Mills.Where(m => m.Millnumber == e.ShipFrom).Select(m => m.Millname).FirstOrDefault(),
                          ShipProdPct = e.ShipProdPct,
                          ShipQty = e.ShipQty,
                          Shipto = e.Shipto,
                          ShiptoCity = e.ShiptoCity,
                          ShiptoCountry = e.ShiptoCountry,
                          ShiptoName = e.ShiptoName,
                          ShiptoState = e.ShiptoState,
                          ShiptoStreet = e.ShiptoStreet,
                          ShiptoZipcd = e.ShiptoZipcd,
                          Soldto = e.Soldto,
                          SoldtoCity = e.SoldtoCity,
                          SoldtoCountry = e.SoldtoCountry,
                          SoldtoName = e.SoldtoName,
                          SoldtoState = e.SoldtoState,
                          SoldtoStreet = e.SoldtoStreet,
                          SoldtoZipcd = e.SoldtoZipcd,
                          Sto = e.Sto,
                          StoShipment = e.StoShipment,
                          Tknum = e.Tknum,
                          Vrkme = e.Vrkme
                      }).OrderBy(e => e.Tknum).ThenBy(e => e.Isprimary).ThenBy(e => e.Hasexception).ToList()
                  }
               ).FirstOrDefault();

            if (result != null)
            {
                if (result.Rollstransferfromanothersoli)
                {
                    result.TransferSoli = result.Exceptiondetails.Where(e => e.Hasexception == true && !(e.Salesordernumber == result.Salesordernumber && e.Lineitemnumber == result.Lineitemnumber))
                      .Select(e => new TransferSoliModel()
                      {
                          Lineitemnumber = e.Lineitemnumber,
                          Salesordernumber = e.Salesordernumber
                      }).ToList();
                }
                else
                {
                    result.TransferSoli = new List<TransferSoliModel>();
                }
            }
            return result;
        }

        public Stream ExportException(int[] exception)
        {
            try
            {
                List<ExportModel> lst = DatatoExport(exception);

                Export converter = new Export();
                MemoryStream stream = new MemoryStream();
                DataTable dt = converter.ToDataTable(lst);

                if(dt.Rows.Count > 0) {
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        var ws = wb.Worksheets.Add("HotOrders");
                        ws.FirstCell().InsertTable(dt).Theme = XLTableTheme.None;
                        ws.FirstRow().Style.Fill.BackgroundColor = XLColor.Black;
                        ws.FirstRow().Style.Font.FontColor = XLColor.White;
                        ws.FirstRow().Style.Font.Bold = true;

                        ws.Tables.FirstOrDefault().ShowAutoFilter = false;

                        IXLRows nonEmptyDataRows = ws.RowsUsed();
                        foreach (var dataRow in nonEmptyDataRows)
                        {
                            string hasexception = Convert.ToString(dataRow.Cell(60).Value);
                            string isprimary = Convert.ToString(dataRow.Cell(59).Value);

                            if (isprimary.ToLower() == "true" && hasexception.ToLower() == "true")
                            {
                                dataRow.Style.Fill.BackgroundColor = XLColor.Yellow;
                            }
                            else if (isprimary.ToLower() == "false" && hasexception.ToLower() == "true")
                            {
                                dataRow.Style.Fill.BackgroundColor = XLColor.LightGoldenrodYellow;
                            }
                            else if (hasexception.ToLower() == "false")
                            {
                                dataRow.Style.Fill.BackgroundColor = XLColor.White;
                            }
                        }

                        ws.Columns(59, 61).Delete();
                        stream = Export.GetWorkbookStream(wb);
                    }
                }
                else
                {
                    stream = null;
                }
                return stream;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ExportModel> DatatoExport(int[] exception)
        {
            var result = from e in context.Exceptiondetails
                         join ex in context.Exceptions on e.Exceptionid equals ex.Id
                         join er in context.Exceptionreasons on ex.Exceptionreasonid equals er.Id
                         join cs in context.Customerserviceemails on ex.Customerserviceemailid equals cs.Id
                         join m in context.Mills on e.ShipFrom equals m.Millnumber into ml
                         from mills in ml.DefaultIfEmpty()
                         where exception != null ? exception.Contains(ex.Id) : 1 == 1
                         select
                            new ExportModel()
                            {
                                Salesordernumber = e.Salesordernumber,
                                Lineitemnumber = e.Lineitemnumber,
                                CustPo = e.CustPo,
                                ShipmentNumber = e.Tknum,
                                Desireddeliverydatetime = e.Exception.Desireddeliverydatetime,
                                Hotweightrollcount = e.Exception.Hotweightrollcount,
                                Exceptionreason = er.Exceptionreason,
                                Customerserviceemail = cs.Customerserviceemail,
                                Afterhoursreceivername = ex.Afterhoursreceivername,
                                Afterhoursreceiverphone = ex.Afterhoursreceiverphone,
                                Shiftedmode = ex.Shiftedmode,
                                Modeforbalance = ex.Modeforbalance,
                                Requestcomments = ex.Requestcomments,
                                AccountExecutive = e.AccountExecutive,
                                Arktx = e.Arktx,
                                Cdd = e.Cdd,
                                ConfirmQty = e.ConfirmQty,
                                ContainerId = e.ContainerId,
                                Createdby = ex.Createdby,
                                Createddate = ex.Createddate,
                                DelApptDateEarly = e.DelApptDateEarly,
                                DelApptTimeEarly = e.DelApptTimeEarly,
                                DelWindow = e.DelWindow,
                                Eped = e.Eped,
                                Gewei = e.Gewei,
                                Mad = e.Mad,
                                Matnr = e.Matnr,
                                OrderType = e.OrderType,
                                OrderUnits = e.OrderUnits,
                                OrderUnitsUom = e.OrderUnitsUom,
                                PgiDate = e.PgiDate,
                                PickupApptDateErly = e.PickupApptDateErly,
                                PickupApptTimeErly = e.PickupApptTimeErly,
                                PlannedDelivQty = e.PlannedDelivQty,
                                ProdConfirmPct = e.ProdConfirmPct,
                                ProdQty = e.ProdQty,
                                Scacd = e.Scacd,
                                ShipFrom = mills.Millname != null ? mills.Millname : e.ShipFrom,
                                ShipProdPct = e.ShipProdPct,
                                ShipQty = e.ShipQty,
                                Shipto = e.Shipto,
                                ShiptoCity = e.ShiptoCity,
                                ShiptoCountry = e.ShiptoCountry,
                                ShiptoName = e.ShiptoName,
                                ShiptoState = e.ShiptoState,
                                ShiptoStreet = e.ShiptoStreet,
                                ShiptoZipcd = e.ShiptoZipcd,
                                Soldto = e.Soldto,
                                SoldtoCity = e.SoldtoCity,
                                SoldtoCountry = e.SoldtoCountry,
                                SoldtoName = e.SoldtoName,
                                SoldtoState = e.SoldtoState,
                                SoldtoStreet = e.SoldtoStreet,
                                SoldtoZipcd = e.SoldtoZipcd,
                                Sto = e.Sto,
                                StoShipment = e.StoShipment,
                                Vrkme = e.Vrkme,
                                Id = e.Exception.Id,
                                isPrimary = e.Salesordernumber == ex.Salesordernumber && e.Lineitemnumber == ex.Lineitemnumber ? true : false,
                                Hasexception = e.Hasexception.Value
                            };

            return result.OrderByDescending(e => e.Id).ThenBy(e => e.ShipmentNumber).ThenByDescending(e => e.isPrimary).ThenByDescending(e => e.Hasexception).ToList();
        }

        public ModelPaged<ExceptionListModel> GetExceptionDetailList(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var query = context.Exceptions
                        .Where(e => e.Status == true)
                        .Select(e => new ExceptionListModel
                        {
                            Id = e.Id,
                            Salesordernumber = e.Salesordernumber,
                            Lineitemnumber = e.Lineitemnumber,
                            Desireddeliverydatetime = e.Desireddeliverydatetime,
                            Createdby = e.Createdby,
                            Createddate = e.Createddate,
                            Modifiedby = e.Modifiedby,
                            Modifieddate = e.Modifieddate,
                        });

            var result = new List<ExceptionListModel>();
            result = query.ToList();
            result.ForEach(x =>
             {
                 var exp = context.Exceptiondetails.OrderBy(e => e.Salesordernumber).ThenBy(e => e.Lineitemnumber).Where(e => e.Exceptionid == x.Id && e.Hasexception == true
                  && e.Salesordernumber == x.Salesordernumber && e.Lineitemnumber == x.Lineitemnumber).Take(1).FirstOrDefault();
                 if (exp != null)
                 {

                     var mills = context.Mills.Where(m => m.Millnumber == exp.ShipFrom).Select(m => m.Millname).FirstOrDefault();

                     x.EPED = exp.Eped;
                     x.ShipmentNumber = exp.Tknum;
                     x.ShipFrom = mills == null ? exp.ShipFrom : mills;
                     x.SoldName = exp.SoldtoName + "  " + exp.SoldtoStreet + " " + exp.SoldtoCity + " " + exp.SoldtoState + " " + exp.SoldtoCountry + " " + exp.SoldtoZipcd;
                 }
             });

            var propertyInfo = typeof(ExceptionListModel).GetProperty(lookupModel.SortColumnName);


            if (lookupModel.SortOrder == "ASC")
                result = result.ToList().OrderBy(x => propertyInfo.GetValue(x, null)).ToList();
            else
                result = result.ToList().OrderByDescending(x => propertyInfo.GetValue(x, null)).ToList();

            var fresult = new ModelPaged<ExceptionListModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return fresult;
        }

        public string InsertUpdateExceptionDetail(string shipmentURL, string defaultemail, InputExceptionModel inputExceptionModel)
        {
            try
            {
               // mailerService.SendEmail("test email from hotorder", "jagdish.sahu@graphicpkg.com", "New Hot Order - Test Mail");

                DateTime currDate = utilities.GetCSTNow();
                var salesOrdernumber = utilities.PrefixZero(inputExceptionModel.Salesordernumber, 10);
                var lineitemnumber = utilities.PrefixZero(inputExceptionModel.Lineitemnumber, 6);

                var exceptionexists = context.Exceptions.Where(x => x.Id != inputExceptionModel.Id
                && x.Salesordernumber == inputExceptionModel.Salesordernumber && x.Lineitemnumber == inputExceptionModel.Lineitemnumber).FirstOrDefault();

                if (exceptionexists != null)
                {
                    return "salesorderandlineitemnumberexists";
                }

                context.Database.BeginTransaction();
                Exceptions exception = null;
                if (inputExceptionModel.Id != 0)
                {
                    exception = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Id == inputExceptionModel.Id).FirstOrDefault();

                    if (exception.Exceptiondetails.Count() > 0)
                    {
                        exception.Exceptiondetails.ToList().ForEach(expdetails =>
                        {
                            Exceptiondetails ed = context.Exceptiondetails.Where(x => x.Id == expdetails.Id).FirstOrDefault();
                            context.Exceptiondetails.Remove(ed);
                        });
                    }
                }
                else
                {

                    exception = new Exceptions();

                    if (inputExceptionModel.Salesordernumber.Length != 10)
                    {
                        exception.Salesordernumber = salesOrdernumber;
                    }
                    else
                    {
                        exception.Salesordernumber = inputExceptionModel.Salesordernumber;
                    }

                    if (inputExceptionModel.Lineitemnumber.Length != 6)
                    {
                        exception.Lineitemnumber = lineitemnumber;
                    }
                    else
                    {
                        exception.Lineitemnumber = inputExceptionModel.Lineitemnumber;
                    }

                    exception.Createddate = currDate;
                    exception.Createdby = inputExceptionModel.Createdby;
                }

                exception.Modifieddate = currDate;
                exception.Modifiedby = inputExceptionModel.Createdby;

                if (exception != null)
                {
                    var time = inputExceptionModel.Desireddeliverytime.Split(":");
                    inputExceptionModel.Desireddeliverydatetime = inputExceptionModel.Desireddeliverydatetime.AddHours(Convert.ToDouble(time[0])).AddMinutes(Convert.ToDouble(time[1]));
                    exception.Desireddeliverydatetime = inputExceptionModel.Desireddeliverydatetime;
                    exception.Hotweightrollcount = inputExceptionModel.Hotweightrollcount;
                    exception.Exceptionreasonid = inputExceptionModel.Exceptionreasonid;
                    exception.Customerserviceemailid = inputExceptionModel.Customerserviceemailid;
                    exception.Afterhoursreceivername = inputExceptionModel.Afterhoursreceivername;
                    exception.Afterhoursreceiverphone = inputExceptionModel.Afterhoursreceiverphone;
                    exception.Rollstransferfromanothersoli = inputExceptionModel.Rollstransferfromanothersoli;
                    exception.Modeshiftrequired = inputExceptionModel.Modeshiftrequired;
                    exception.Requestcomments = inputExceptionModel.Requestcomments;

                    List<ShpDet> lstclshpdet = new List<ShpDet>();
                    ShpDet _cl_shpdet1 = new ShpDet { TKNUM = "" };
                    lstclshpdet.Add(_cl_shpdet1);

                    List<OrderDetail> lstorddet = new List<OrderDetail>();
                    SOLIList soliData = new SOLIList();

                    lstorddet.Add(new OrderDetail { POSNR = lineitemnumber, VBELN = salesOrdernumber });

                    if (exception.Rollstransferfromanothersoli == true)
                    {
                        if (inputExceptionModel.OrderDetailList.Count > 0)
                        {
                            inputExceptionModel.OrderDetailList.ForEach(x =>
                            {
                                lstorddet.Add(new OrderDetail { POSNR = utilities.PrefixZero(x.POSNR, 6), VBELN = utilities.PrefixZero(x.VBELN, 10) });
                            });
                        }
                    }

                    if (inputExceptionModel.Modeshiftrequired)
                    {
                        exception.Shiftedmode = inputExceptionModel.Shiftedmode;
                        exception.Modeforbalance = inputExceptionModel.Modeforbalance;
                    }
                    else
                    {
                        exception.Shiftedmode = "";
                        exception.Modeforbalance = "";
                    }

                    exception.Status = true;

                    Orders orders = new Orders();
                    orders.IT_ORDERS = lstorddet;
                    orders.IT_SHIPNO = lstclshpdet;

                    OrderData orderData = new OrderData();
                    orderData.Orders = orders;

                    soliData = soliShipmentDetail.GetShipmentData(shipmentURL, orderData);

                    if (soliData.ET_DETAILS != null && soliData.ET_DETAILS.Length != 0)
                    {
                        bool isOk = false;
                        lstorddet.ForEach(l =>
                            {
                                var soli = soliData.ET_DETAILS.ToList().Where(s => s.VBELN == l.VBELN && s.POSNR == l.POSNR).FirstOrDefault();

                                if (soli == null)
                                {
                                    isOk = true;
                                    return;
                                }
                            });

                        if (isOk)
                        {
                            return "primaryortransfersolinotpresent";
                        }

                        soliData.ET_DETAILS.ToList().ForEach(x =>
                        {
                            Exceptiondetails exceptiondetails = new Exceptiondetails();

                            if (lstorddet.Any(l => (l.VBELN == utilities.PrefixZero(x.VBELN, 10) && l.POSNR == utilities.PrefixZero(x.POSNR, 6))))
                            {
                                exceptiondetails.Hasexception = true;
                            }
                            else
                            {
                                exceptiondetails.Hasexception = false;
                            }
                            exceptiondetails.AccountExecutive = x.ACCOUNT_EXECUTIVE;
                            exceptiondetails.Arktx = x.ARKTX;

                            if (x.CDD == "")
                            {
                                exceptiondetails.Cdd = null;
                            }
                            else
                            {
                                exceptiondetails.Cdd = Convert.ToDateTime(x.CDD);
                            }
                            exceptiondetails.ConfirmQty = x.CONFIRM_QTY;
                            exceptiondetails.ContainerId = x.CONTAINER_ID;
                            exceptiondetails.CustPo = x.CUST_PO;
                            if (x.DEL_APPT_DATE_EARLY == "" || x.DEL_APPT_DATE_EARLY == "0000-00-00")
                            {
                                exceptiondetails.DelApptDateEarly = null;
                            }
                            else
                            {
                                exceptiondetails.DelApptDateEarly = Convert.ToDateTime(x.DEL_APPT_DATE_EARLY);
                            }
                            if (x.DEL_APPT_TIME_EARLY == "")
                            {
                                exceptiondetails.DelApptTimeEarly = null;
                            }
                            else
                            {
                                exceptiondetails.DelApptTimeEarly = TimeSpan.Parse(x.DEL_APPT_TIME_EARLY);
                            }

                            exceptiondetails.DelWindow = x.DEL_WINDOW;

                            if (x.EPED == "" || x.EPED == "0000-00-00")
                            {
                                exceptiondetails.Eped = null;
                            }
                            else
                            {
                                exceptiondetails.Eped = Convert.ToDateTime(x.EPED);
                            }

                            exceptiondetails.Gewei = x.GEWEI;


                            if (x.POSNR.Length != 6)
                            {

                                exceptiondetails.Lineitemnumber = utilities.PrefixZero(x.POSNR, 6);

                            }
                            else
                            {
                                exceptiondetails.Lineitemnumber = x.POSNR;
                            }

                            if (x.MAD == "" || x.MAD == "0000-00-00")
                            {
                                exceptiondetails.Mad = null;
                            }
                            else
                            {
                                exceptiondetails.Mad = Convert.ToDateTime(x.MAD);
                            }

                            exceptiondetails.Matnr = x.MATNR;
                            exceptiondetails.Modifiedby = inputExceptionModel.Modifiedby;
                            exceptiondetails.Modifieddate = currDate;
                            exceptiondetails.OrderType = x.ORDER_TYPE;
                            exceptiondetails.OrderUnits = x.ORDER_UNITS;
                            exceptiondetails.OrderUnitsUom = x.ORDER_UNITS_UOM;
                            if (x.PGI_DATE == "" || x.PGI_DATE == "0000-00-00")
                            {
                                exceptiondetails.PgiDate = null;
                            }
                            else
                            {
                                exceptiondetails.PgiDate = Convert.ToDateTime(x.PGI_DATE);
                            }

                            if (x.PICKUP_APPT_DATE_ERLY == "" || x.PICKUP_APPT_DATE_ERLY == "0000-00-00")
                            {
                                exceptiondetails.PickupApptDateErly = null;
                            }
                            else
                            {
                                exceptiondetails.PickupApptDateErly = Convert.ToDateTime(x.PICKUP_APPT_DATE_ERLY);
                            }

                            if (x.PICKUP_APPT_TIME_ERLY == "")
                            {
                                exceptiondetails.PickupApptTimeErly = null;
                            }
                            else
                            {
                                exceptiondetails.PickupApptTimeErly = TimeSpan.Parse(x.PICKUP_APPT_TIME_ERLY);
                            }

                            exceptiondetails.PlannedDelivQty = x.PLANNED_DELIV_QTY;
                            exceptiondetails.ProdConfirmPct = x.PROD_CONFIRM_PCT;
                            exceptiondetails.ProdQty = x.PROD_QTY;
                            if (x.VBELN.Length != 10)
                            {
                                exceptiondetails.Salesordernumber = utilities.PrefixZero(x.VBELN, 10);
                            }
                            else
                            {
                                exceptiondetails.Salesordernumber = x.VBELN;
                            }
                            exceptiondetails.Scacd = x.SCACD;
                            exceptiondetails.ShipFrom = x.SHIP_FROM;
                            exceptiondetails.ShipProdPct = x.SHIP_PROD_PCT;
                            exceptiondetails.ShipQty = x.SHIP_QTY;
                            exceptiondetails.Shipto = x.SHIPTO;
                            exceptiondetails.ShiptoCity = x.SHIPTO_CITY;
                            exceptiondetails.ShiptoCountry = x.SHIPTO_COUNTRY;
                            exceptiondetails.ShiptoName = x.SHIPTO_NAME;
                            exceptiondetails.ShiptoState = x.SHIPTO_STATE;
                            exceptiondetails.ShiptoStreet = x.SHIPTO_STREET;
                            exceptiondetails.ShiptoZipcd = x.SHIPTO_ZIPCD;
                            exceptiondetails.Soldto = x.SOLDTO;
                            exceptiondetails.SoldtoCity = x.SOLDTO_CITY;
                            exceptiondetails.SoldtoCountry = x.SOLDTO_COUNTRY;
                            exceptiondetails.SoldtoName = x.SOLDTO_NAME;
                            exceptiondetails.SoldtoState = x.SOLDTO_STATE;
                            exceptiondetails.SoldtoStreet = x.SOLDTO_STREET;
                            exceptiondetails.SoldtoZipcd = x.SOLDTO_ZIPCD;
                            exceptiondetails.Tknum = x.TKNUM;
                            exceptiondetails.StoShipment = x.STO_SHIPMENT;
                            exceptiondetails.Sto = x.STO;
                            exceptiondetails.Vrkme = x.VRKME;
                            exceptiondetails.Createddate = currDate;
                            exceptiondetails.Modifieddate = currDate;
                            exceptiondetails.Createdby = inputExceptionModel.Createdby;
                            exceptiondetails.Exceptionid = exception.Id;
                            exception.Exceptiondetails.Add(exceptiondetails);
                        });
                    }
                    else
                    {
                        Log.Error("roolback ");
                        context.Database.RollbackTransaction();
                        return "BAPIError";
                    }

                    if (exception.Id == 0)
                    {
                        context.Exceptions.Add(exception);
                    }
                    else
                    {
                        context.Exceptions.Update(exception);
                    }
                }

                Log.Information("context.SaveChanges");
                int submitvalue = context.SaveChanges();

                if (submitvalue > 0)
                {
                   EmailtoGPITeam(exception.Id, defaultemail);

                    exception.Planningteamnotified = true;
                    context.Exceptions.Update(exception);
                    context.SaveChanges();

                    Log.Information("context.Database.CommitTransaction");
                    context.Database.CommitTransaction();
                }

                return Convert.ToString(submitvalue);
            }

            catch (Exception ex)
            {
                context.Database.RollbackTransaction();
                throw ex;
            }
        }

        public void EmailtoGPITeam(int id, string defaultemail)
        {
            try
            {
                Exceptions exception = context.Exceptions.Include(x => x.Exceptiondetails).Include(x => x.Exceptiondetails).Where(x => x.Id == id).FirstOrDefault();

                List<Exceptiondetails> exceptiondet = exception.Exceptiondetails.Where(e => e.Hasexception == true &&
                !(e.Salesordernumber == e.Exception.Salesordernumber && e.Lineitemnumber == e.Exception.Lineitemnumber)).ToList();

                string transfersoli = "";

                List<TransferSoli> transfersolilist = new List<TransferSoli>();

                exceptiondet.ForEach(x =>
                {
                    var transoli = transfersolilist.Where(w => w.Salesordernumber == x.Salesordernumber && w.Lineitemnumber == x.Lineitemnumber).FirstOrDefault();
                    if (transoli == null)
                    {
                        transfersolilist.Add(new TransferSoli { Salesordernumber = x.Salesordernumber, Lineitemnumber = x.Lineitemnumber });
                    }
                });

                int index = 1;
                transfersolilist.ToList().ForEach(x =>
                {
                    if (transfersoli == "")
                        transfersoli = "<tr><td colspan=\"3\"><p class=\"checks\">This HOT order require rolls to be transferred from another order.</p></td></tr><tr><td style=\"width: 30;\">SOLI #" + index + "</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + x.Salesordernumber + "-" + x.Lineitemnumber + "</p></td></tr>";
                    else
                        transfersoli = transfersoli + "<tr><td style=\"width: 30;\">SOLI #" + index + "</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + x.Salesordernumber + "-" + x.Lineitemnumber + "</p></td></tr>";

                    index = index + 1;
                });

                string modeshift = "";
                if (exception.Modeshiftrequired)
                {
                    modeshift = "<tr><td colspan=\"3\"><p class=\"checks\">This HOT order require a mode shift.</p></td></tr><tr><td style=\"width: 30;\">Shifted Mode</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + exception.Shiftedmode + "</p></td></tr><tr><td style=\"width: 30;\">Mode for remaining balance</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + exception.Modeforbalance + "</p></td></tr>";
                }
                Customerserviceemails cust = context.Customerserviceemails.Where(x => x.Id == exception.Customerserviceemailid).FirstOrDefault();
                Exceptionreasons reason = context.Exceptionreasons.Where(x => x.Id == exception.Exceptionreasonid).FirstOrDefault();

                var shipfrom = exception.Exceptiondetails.Select(x => new { x.OrderType, x.ShipFrom }).Distinct().ToList();

                shipfrom.ForEach(s =>
               {

                   string toemail = "";
                   var excep = exception.Exceptiondetails.Where(e => e.ShipFrom == s.ShipFrom && e.OrderType == s.OrderType).ToList();

                   var shipmentunplannedlist = excep.Where(e => e.Tknum == "").ToList();
                   var shipmentplannedlist = excep.Where(e => e.Tknum != "").ToList();

                  // var defaultemail = context.Mailinglist.Where(m => m.Millid == 8 && m.Ordertypeid == 7).Select(x => x.Planningteamdl).FirstOrDefault();

                   int millid = context.Mills.Where(m => m.Millnumber == s.ShipFrom).Select(m => m.Id).FirstOrDefault();
                   int ordertypesid = context.Ordertypes.Where(m => m.Ordertype == s.OrderType).Select(m => m.Id).FirstOrDefault();

                   if (shipmentunplannedlist.Count() > 0)
                   {

                       string file = System.IO.File.ReadAllText("email.html");
                       file = file.Replace("{soli}", exception.Salesordernumber + "-" + exception.Lineitemnumber);
                       file = file.Replace("{desireddeliverydate}", exception.Desireddeliverydatetime.ToString("MM/dd/yyyy HH:mm tt"));
                       file = file.Replace("{createdby}", exception.Createdby);
                       file = file.Replace("{customerserviceemail}", cust.Customerserviceemail);
                       file = file.Replace("{requestcomments}", exception.Requestcomments);
                       file = file.Replace("{rollcount}", exception.Hotweightrollcount);
                       file = file.Replace("{exceptionreason}", reason.Exceptionreason);
                       file = file.Replace("{afterhoursreceiver}", exception.Afterhoursreceivername + " " + exception.Afterhoursreceiverphone);
                       file = file.Replace("{transfersoli}", transfersoli.Trim());
                       file = file.Replace("{shiftmode}", exception.Shiftedmode);
                       file = file.Replace("{modebalance}", exception.Modeforbalance);
                       file = file.Replace("{modeshift}", modeshift);

                       var planningteammail = context.Mailinglist.Where(m => m.Millid == millid && m.Ordertypeid == ordertypesid)
                                                  .Select(m => m.Planningteamdl).FirstOrDefault();

                       if (planningteammail != null)
                       {
                           toemail = planningteammail;

                       }
                       else
                       {
                           toemail = defaultemail;
                       }

                       string soli = "";
                       shipmentunplannedlist.ForEach(x =>
                       {
                           if (soli == "")
                           {
                               soli = "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                           }
                           else
                           {
                               soli = soli + "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                           }
                       });

                       file = file.Replace("{trow}", soli);
                       if (toemail != "")
                           mailerService.SendEmail(file, toemail, "New Hot Order - Test Mail");
                   }

                   if (shipmentplannedlist.Count() > 0)
                   {
                       string file = System.IO.File.ReadAllText("email.html");
                       file = file.Replace("{soli}", exception.Salesordernumber + "-" + exception.Lineitemnumber);
                       file = file.Replace("{desireddeliverydate}", exception.Desireddeliverydatetime.ToString("MM/dd/yyyy HH:mm tt"));
                       file = file.Replace("{createdby}", exception.Createdby);
                       file = file.Replace("{customerserviceemail}", cust.Customerserviceemail);
                       file = file.Replace("{requestcomments}", exception.Requestcomments);
                       file = file.Replace("{rollcount}", exception.Hotweightrollcount);
                       file = file.Replace("{exceptionreason}", reason.Exceptionreason);
                       file = file.Replace("{afterhoursreceiver}", exception.Afterhoursreceivername + " " + exception.Afterhoursreceiverphone);
                       file = file.Replace("{transfersoli}", transfersoli.Trim());
                       file = file.Replace("{shiftmode}", exception.Shiftedmode);
                       file = file.Replace("{modebalance}", exception.Modeforbalance);
                       file = file.Replace("{modeshift}", modeshift);

                       var executionteamdl = context.Mailinglist.Where(m => m.Millid == millid && m.Ordertypeid == ordertypesid)
                                                  .Select(m => m.Executionteamdl).FirstOrDefault();

                       if (executionteamdl != null)
                       {
                           toemail = executionteamdl;
                       }
                       else
                       {
                           toemail = defaultemail;
                       }

                       string soliplannedlist = "";
                       shipmentplannedlist.ForEach(x =>
                       {
                           if (soliplannedlist == "")
                           {
                               soliplannedlist = "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                           }
                           else
                           {
                               soliplannedlist = soliplannedlist + "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                           }
                       });

                       file = file.Replace("{trow}", soliplannedlist);

                       if (toemail != "")
                           mailerService.SendEmail(file, toemail, "New Hot Order - Test Mail");
                   }
               });

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
