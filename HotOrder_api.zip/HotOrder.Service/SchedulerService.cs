﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HotOrder.Service
{
    public interface ISchedulerService
    {
        int NightlyRun(string shipmentURL, ISoliShipmentDetail soliShipmentDetail);
        int NotifyHotOrderStatus(string shipmentURL);
        int UpdateExceptiondetails(string shipmentURL, ISoliShipmentDetail soliShipmentDetail);
    }

    public class SchedulerService : ISchedulerService
    {
        HotOrderContext context;
        IUtilities utilities;
        IMailerService mailerService;
        public SchedulerService(HotOrderContext _context, IUtilities _utilities, IMailerService _mailerService)
        {
            context = _context;
            utilities = _utilities;
            mailerService = _mailerService;
    }

        public int NightlyRun(string shipmentURL, ISoliShipmentDetail soliShipmentDetail)
        {
            try
            {
                DateTime currDate = utilities.GetCSTNow();
                Log.Information($"C# Timer trigger function started at: {currDate}");

                List<Exceptions> exceptions = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Status == true).ToList();
                //string shipmentURL = "http://gpiptcdwmis1.na.graphicpkg.pri:18555/GPI/SoliShipmentDetail/fetch";

                exceptions.ForEach(exception =>
                {
                    List<OrderDetail> lstorddet = new List<OrderDetail>();
                    SOLIList soliData = new SOLIList();

                    List<ShpDet> lstclshpdet = new List<ShpDet>();
                    ShpDet _cl_shpdet1 = new ShpDet { TKNUM = "" };
                    lstclshpdet.Add(_cl_shpdet1);

                    lstorddet.Add(new OrderDetail { POSNR = exception.Lineitemnumber, VBELN = exception.Salesordernumber });

                    if (exception.Rollstransferfromanothersoli == true)
                    {
                        List<Exceptiondetails> exceptiondet = exception.Exceptiondetails.Where(e => e.Hasexception == true &&
                        !(e.Salesordernumber == e.Exception.Salesordernumber && e.Lineitemnumber == e.Exception.Lineitemnumber)).ToList();

                        exceptiondet.ForEach(x =>
                        {
                            lstorddet.Add(new OrderDetail { POSNR = utilities.PrefixZero(x.Lineitemnumber, 6), VBELN = utilities.PrefixZero(x.Salesordernumber, 10) });
                        });
                    }

                    Orders orders = new Orders();
                    orders.IT_ORDERS = lstorddet;
                    orders.IT_SHIPNO = lstclshpdet;

                    OrderData orderData = new OrderData();
                    orderData.Orders = orders;

                    soliData = soliShipmentDetail.GetShipmentData(shipmentURL, orderData);

                    try
                    {
                        context.Database.BeginTransaction();
                        exception.Exceptiondetails.ToList().ForEach(expdetails =>
                        {
                            Exceptiondetails ed = context.Exceptiondetails.Where(x => x.Id == expdetails.Id).FirstOrDefault();
                            context.Exceptiondetails.Remove(ed);
                        });

                        if (soliData.ET_DETAILS != null && soliData.ET_DETAILS.Length != 0)
                        {
                            soliData.ET_DETAILS.ToList().ForEach(x =>
                            {
                                Exceptiondetails exceptiondetails = new Exceptiondetails();

                                if (lstorddet.Any(l => (l.VBELN == x.VBELN && l.POSNR == x.POSNR)))
                                {
                                    exceptiondetails.Hasexception = true;
                                }
                                else
                                {
                                    exceptiondetails.Hasexception = false;
                                }
                                exceptiondetails.AccountExecutive = x.ACCOUNT_EXECUTIVE;
                                exceptiondetails.Arktx = x.ARKTX;

                                if (x.CDD == "")
                                {
                                    exceptiondetails.Cdd = null;
                                }
                                else
                                {
                                    exceptiondetails.Cdd = Convert.ToDateTime(x.CDD);
                                }
                                exceptiondetails.ConfirmQty = x.CONFIRM_QTY;
                                exceptiondetails.ContainerId = x.CONTAINER_ID;
                                exceptiondetails.CustPo = x.CUST_PO;
                                if (x.DEL_APPT_DATE_EARLY == "" || x.DEL_APPT_DATE_EARLY == "0000-00-00")
                                {
                                    exceptiondetails.DelApptDateEarly = null;
                                }
                                else
                                {
                                    exceptiondetails.DelApptDateEarly = Convert.ToDateTime(x.DEL_APPT_DATE_EARLY);
                                }
                                if (x.DEL_APPT_TIME_EARLY == "")
                                {
                                    exceptiondetails.DelApptTimeEarly = null;
                                }
                                else
                                {
                                    exceptiondetails.DelApptTimeEarly = TimeSpan.Parse(x.DEL_APPT_TIME_EARLY);
                                }

                                exceptiondetails.DelWindow = x.DEL_WINDOW;

                                if (x.EPED == "" || x.EPED == "0000-00-00")
                                {
                                    exceptiondetails.Eped = null;
                                }
                                else
                                {
                                    exceptiondetails.Eped = Convert.ToDateTime(x.EPED);
                                }

                                exceptiondetails.Gewei = x.GEWEI;
                                exceptiondetails.Lineitemnumber = x.POSNR;
                                if (x.MAD == "" || x.MAD == "0000-00-00")
                                {
                                    exceptiondetails.Mad = null;
                                }
                                else
                                {
                                    exceptiondetails.Mad = Convert.ToDateTime(x.MAD);
                                }

                                exceptiondetails.Matnr = x.MATNR;
                                exceptiondetails.OrderType = x.ORDER_TYPE;
                                exceptiondetails.OrderUnits = x.ORDER_UNITS;
                                exceptiondetails.OrderUnitsUom = x.ORDER_UNITS_UOM;
                                if (x.PGI_DATE == "" || x.PGI_DATE == "0000-00-00")
                                {
                                    exceptiondetails.PgiDate = null;
                                }
                                else
                                {
                                    exceptiondetails.PgiDate = Convert.ToDateTime(x.PGI_DATE);
                                }

                                if (x.PICKUP_APPT_DATE_ERLY == "" || x.PICKUP_APPT_DATE_ERLY == "0000-00-00")
                                {
                                    exceptiondetails.PickupApptDateErly = null;
                                }
                                else
                                {
                                    exceptiondetails.PickupApptDateErly = Convert.ToDateTime(x.PICKUP_APPT_DATE_ERLY);
                                }

                                if (x.PICKUP_APPT_TIME_ERLY == "")
                                {
                                    exceptiondetails.PickupApptTimeErly = null;
                                }
                                else
                                {
                                    exceptiondetails.PickupApptTimeErly = TimeSpan.Parse(x.PICKUP_APPT_TIME_ERLY);
                                }

                                exceptiondetails.PlannedDelivQty = x.PLANNED_DELIV_QTY;
                                exceptiondetails.ProdConfirmPct = x.PROD_CONFIRM_PCT;
                                exceptiondetails.ProdQty = x.PROD_QTY;
                                exceptiondetails.Salesordernumber = x.VBELN;
                                exceptiondetails.Scacd = x.SCACD;
                                exceptiondetails.ShipFrom = x.SHIP_FROM;
                                exceptiondetails.ShipProdPct = x.SHIP_PROD_PCT;
                                exceptiondetails.ShipQty = x.SHIP_QTY;
                                exceptiondetails.Shipto = x.SHIPTO;
                                exceptiondetails.ShiptoCity = x.SHIPTO_CITY;
                                exceptiondetails.ShiptoCountry = x.SHIPTO_COUNTRY;
                                exceptiondetails.ShiptoName = x.SHIPTO_NAME;
                                exceptiondetails.ShiptoState = x.SHIPTO_STATE;
                                exceptiondetails.ShiptoStreet = x.SHIPTO_STREET;
                                exceptiondetails.ShiptoZipcd = x.SHIPTO_ZIPCD;
                                exceptiondetails.Soldto = x.SOLDTO;
                                exceptiondetails.SoldtoCity = x.SOLDTO_CITY;
                                exceptiondetails.SoldtoCountry = x.SOLDTO_COUNTRY;
                                exceptiondetails.SoldtoName = x.SOLDTO_NAME;
                                exceptiondetails.SoldtoState = x.SOLDTO_STATE;
                                exceptiondetails.SoldtoStreet = x.SOLDTO_STREET;
                                exceptiondetails.SoldtoZipcd = x.SOLDTO_ZIPCD;
                                exceptiondetails.Tknum = x.TKNUM;
                                exceptiondetails.StoShipment = x.STO_SHIPMENT;
                                exceptiondetails.Sto = x.STO;
                                exceptiondetails.Vrkme = x.VRKME;
                                exceptiondetails.Createddate = currDate;
                                exceptiondetails.Modifieddate = currDate;
                                exceptiondetails.Createdby = exception.Createdby;
                                exceptiondetails.Modifiedby = exception.Modifiedby;
                                exceptiondetails.Exceptionid = exception.Id;
                                exception.Exceptiondetails.Add(exceptiondetails);
                            });

                            context.Exceptions.Update(exception);
                            int retvalue = context.SaveChanges();

                            if (retvalue > 0)
                            {
                                var ProdConfirmPct = exception.Exceptiondetails.All(a => a.ProdConfirmPct.Number() >= 100);

                                if (ProdConfirmPct)
                                {
                                    exception.Status = false;
                                    context.Exceptions.Update(exception);
                                    context.SaveChanges();
                                }
                            }
                            context.Database.CommitTransaction();

                        }
                        else
                        {
                            context.Database.RollbackTransaction();
                        //log error for the record;
                    }

                    }
                    catch (Exception ex)
                    {
                        context.Database.RollbackTransaction();
                        Log.Error(ex.Message);
                        throw ex;
                    }
                });
                return 1;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw ex;
            }

            //Log.Information($"C# Timer trigger nightlyfunc function ended at: {utilities.GetCSTNow()}");
        }

        public int NotifyHotOrderStatus(string shipmentURL)
        {
            try
            {
                Log.Information($"C# Timer trigger function started at: {utilities.GetCSTNow()}");

                List<int> actualminutes = new List<int>();
                actualminutes.AddRange(new int[] { 00, 15, 30, 45 });

                List<Exceptions> exceptions = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Status == true).ToList();
                var nodeliveryappointment = new List<List<Exceptiondetails>>();
                var isEnable = context.OtherConfig.Select(x => x.IsEnable).FirstOrDefault();

                if (isEnable)
                {
                    nodeliveryappointment = exceptions.Select(x => x.Exceptiondetails.Where(e => e.Hasexception == true && (e.DelApptDateEarly == null || !actualminutes.Contains(e.DelApptTimeEarly.Value.Minutes))).ToList()).ToList();
                }
                else
                {
                    nodeliveryappointment = exceptions.Select(x => x.Exceptiondetails.Where(e => e.Hasexception == true && e.DelApptDateEarly == null).ToList()).ToList();
                }

                var desireddeliverydate = exceptions.Select(x => x.Exceptiondetails.Where(e => e.Hasexception == true && (e.DelApptDateEarly != null ? e.DelApptDateEarly.Value.Date.AddHours(e.DelApptTimeEarly.Value.Hours).AddMinutes(e.DelApptTimeEarly.Value.Minutes).AddSeconds(e.DelApptTimeEarly.Value.Seconds).AddMilliseconds(e.DelApptTimeEarly.Value.Milliseconds) : e.DelApptDateEarly) >= x.Desireddeliverydatetime).ToList()).ToList();

                var pickupappoint = exceptions.Select(x => x.Exceptiondetails.Where(e => e.Hasexception == true && (e.PickupApptDateErly != null ? e.PickupApptDateErly.Value.AddHours(e.PickupApptTimeErly.Value.Hours).AddMinutes(e.PickupApptTimeErly.Value.Minutes).AddSeconds(e.PickupApptTimeErly.Value.Seconds).AddMilliseconds(e.PickupApptTimeErly.Value.Milliseconds) : e.PickupApptDateErly) < utilities.GetCSTNow()).ToList()).ToList();
                var remainingbalance = exceptions.Select(x => x.Exceptiondetails.Where(e => e.Hasexception == true && e.Tknum == null && e.ProdConfirmPct.Number() < 100).ToList()).ToList();
                List<MillList> mills = new List<MillList>();

                nodeliveryappointment.ForEach(x =>
                {
                    if (x.Count() != 0)
                    {
                        MillList mlist = new MillList();
                        mlist.mill = x.Select(x => x.ShipFrom).FirstOrDefault();
                        mlist.listtype = "nodeliveryappointment";
                        mlist.notificationlist = x.FirstOrDefault();
                        mills.Add(mlist);
                    }
                });

                desireddeliverydate.ForEach(x =>
                {
                    if (x.Count() != 0)
                    {
                        MillList mlist = new MillList();
                        mlist.mill = x.Select(x => x.ShipFrom).FirstOrDefault();
                        mlist.listtype = "desireddeliverydate";
                        mlist.notificationlist = x.FirstOrDefault();
                        mills.Add(mlist);
                    }
                });

                pickupappoint.ForEach(x =>
                {
                    if (x.Count() != 0)
                    {
                        MillList mlist = new MillList();
                        mlist.mill = x.Select(x => x.ShipFrom).FirstOrDefault();
                        mlist.listtype = "pickupappoint";
                        mlist.notificationlist = x.FirstOrDefault();
                        mills.Add(mlist);
                    }
                });

                remainingbalance.ForEach(x =>
                {
                    if (x.Count() != 0)
                    {
                        MillList mlist = new MillList();
                        mlist.mill = x.Select(x => x.ShipFrom).FirstOrDefault();
                        mlist.listtype = "remainingbalance";
                        mlist.notificationlist = x.FirstOrDefault();
                        mills.Add(mlist);
                    }
                });

                List<string> mill = mills.Select(x => x.mill).Distinct().ToList();

                List<EmailToMill> emailtomilllst = new List<EmailToMill>();

                mill.ForEach(x =>
                {
                    EmailToMill emailtomill = new EmailToMill();

                    List<MillList> mll = mills.Where(m => m.mill == x).ToList();

                    List<MillList> nodelappoint = mll.Where(l => l.listtype == "nodeliveryappointment").ToList();

                    emailtomill.millid = x;
                    emailtomill.emailids = string.Join(",", context.Mailinglist.Include(x => x.Mill).Where(ml => ml.Mill.Millnumber == x).Select(ml => ml.Planningteamdl).Distinct().ToList());
                    emailtomill.listtype = nodelappoint.Select(x => x.listtype).FirstOrDefault();

                    if (nodelappoint.Count() > 0)
                    {
                        emailtomill.nodeliveryappointment = "<p class=\"heading\">NO Delivery Appointment:</p><table class=\"entries\"><thead><tr><td>SOLI</td><td>Desired Delivery Appt</td><td>Shipment #</td><td> SCAC</td><td>Updated PU Appt Early</td><td>Delivery Appt Early Date</td><td>Delivery Appt Early Time</td><td>Created By</td></tr></thead><tbody>";
                    }
                    nodelappoint.ForEach(nd =>
                    {
                        var excep = nd.notificationlist;
                        var pickupApptDateErly = "";
                        if (excep.PickupApptDateErly.HasValue)
                        {
                            pickupApptDateErly = excep.PickupApptDateErly.Value.ToString();
                        }

                        var delApptDateEarly = "";
                        if (excep.DelApptDateEarly.HasValue)
                        {
                            delApptDateEarly = excep.DelApptDateEarly.Value.ToString();
                        }

                        var delApptTimeEarly = "";
                        if (excep.DelApptTimeEarly.HasValue)
                        {
                            delApptTimeEarly = excep.DelApptTimeEarly.Value.ToString();
                        }

                        if (emailtomill.nodeliveryappointment != "")
                        {
                            emailtomill.nodeliveryappointment += "<tr><td>" + excep.Salesordernumber + " - " + excep.Lineitemnumber + "</td><td>" + excep.Exception.Desireddeliverydatetime + "</td><td>" + excep.Tknum + "</td><td>" + excep.Scacd + "</td><td>" + pickupApptDateErly + "</td><td>" + delApptDateEarly + "</td><td>" + delApptTimeEarly + "</td><td>" + excep.Exception.Createdby + "</td></tr>";
                        }
                    });

                    if (nodelappoint.Count() > 0)
                    {
                        emailtomill.nodeliveryappointment += "</tbody></table>";
                    }

                    List<MillList> desireddeliverydate = mll.Where(l => l.listtype == "desireddeliverydate").ToList();

                    if (desireddeliverydate.Count() > 0)
                    {
                        emailtomill.desireddeliverydate = "<p class=\"heading\">Current Delivery Appointment Will Not Meet The Desired Delivery Date:</p><table class=\"entries\"><thead><td>SOLI</td><td>Desired Delivery Appt</td><td>Shipment #</td><td>SCAC</td><td>Updated PU Appt Early</td><td>Delivery Appt Early Date</td><td>Delivery Appt Early Time</td><td>Created By</td></tr></thead><tbody>";
                    }

                    desireddeliverydate.ForEach(nd =>
                    {
                        var excep = nd.notificationlist;
                        var pickupApptDateErly = "";
                        if (excep.PickupApptDateErly.HasValue)
                        {
                            pickupApptDateErly = excep.PickupApptDateErly.Value.ToString();
                        }

                        var delApptDateEarly = "";
                        if (excep.DelApptDateEarly.HasValue)
                        {
                            delApptDateEarly = excep.DelApptDateEarly.Value.ToString();
                        }

                        var delApptTimeEarly = "";
                        if (excep.DelApptTimeEarly.HasValue)
                        {
                            delApptTimeEarly = excep.DelApptTimeEarly.Value.ToString();
                        }

                        if (emailtomill.desireddeliverydate != "")
                        {
                            emailtomill.desireddeliverydate += "<tr><td>" + excep.Salesordernumber + " - " + excep.Lineitemnumber + "</td><td>" + excep.Exception.Desireddeliverydatetime + "</td><td>" + excep.Tknum + "</td><td>" + excep.Scacd + "</td><td>" + pickupApptDateErly + "</td><td>" + delApptDateEarly + "</td><td>" + delApptTimeEarly + "</td><td>" + excep.Exception.Createdby + "</td></tr>";
                        }
                    });

                    if (desireddeliverydate.Count() > 0)
                    {
                        emailtomill.desireddeliverydate += "</tbody></table>";
                    }

                    List<MillList> pickupappoint = mll.Where(l => l.listtype == "pickupappoint").ToList();
                    if (pickupappoint.Count() > 0)
                    {
                        emailtomill.pickupappoint = "<p class=\"heading\">Pickup Appointment Is In The Past:</p><table class=\"entries\"><thead><tr><td>SOLI</td><td>Desired Delivery Appt</td><td>Shipment #</td><td>SCAC</td><td>Updated PU Appt Early</td><td>Delivery Appt Early Date</td><td>Delivery Appt Early Time</td><td>Created By</td></tr></thead><tbody>";
                    }
                    pickupappoint.ForEach(nd =>
                    {
                        var excep = nd.notificationlist;
                        var pickupApptDateErly = "";
                        if (excep.PickupApptDateErly.HasValue)
                        {
                            pickupApptDateErly = excep.PickupApptDateErly.Value.ToString();
                        }

                        var delApptDateEarly = "";
                        if (excep.DelApptDateEarly.HasValue)
                        {
                            delApptDateEarly = excep.DelApptDateEarly.Value.ToString();
                        }

                        var delApptTimeEarly = "";
                        if (excep.DelApptTimeEarly.HasValue)
                        {
                            delApptTimeEarly = excep.DelApptTimeEarly.Value.ToString();
                        }

                        if (emailtomill.pickupappoint != "")
                        {
                            emailtomill.pickupappoint += "<tr><td>" + excep.Salesordernumber + " - " + excep.Lineitemnumber + "</td><td>" + excep.Exception.Desireddeliverydatetime + "</td><td>" + excep.Tknum + "</td><td>" + excep.Scacd + "</td><td>" + pickupApptDateErly + "</td><td>" + delApptDateEarly + "</td><td>" + delApptTimeEarly + "</td><td>" + excep.Exception.Createdby + "</td></tr>";
                        }
                    });

                    if (pickupappoint.Count() > 0)
                    {
                        emailtomill.pickupappoint += "</tbody></table>";
                    }

                    List<MillList> remainingbalance = mll.Where(l => l.listtype == "remainingbalance").ToList();
                    if (remainingbalance.Count() > 0)
                    {
                        emailtomill.remainingbalance = "<p class=\"heading\">Remaining Balance:</p><table class=\"entries\"><thead><tr><td>SOLI</td><td>Desired Delivery Appt</td><td>Shipment #</td><td>SCAC</td><td>Updated PU Appt Early</td><td>Delivery Appt Early Date</td><td>Delivery Appt Early Time</td><td>Created By</td></tr></thead><tbody>";
                    }
                    remainingbalance.ForEach(nd =>
                    {
                        var excep = nd.notificationlist;
                        var pickupApptDateErly = "";
                        if (excep.PickupApptDateErly.HasValue)
                        {
                            pickupApptDateErly = excep.PickupApptDateErly.Value.ToString();
                        }

                        var delApptDateEarly = "";
                        if (excep.DelApptDateEarly.HasValue)
                        {
                            delApptDateEarly = excep.DelApptDateEarly.Value.ToString();
                        }

                        var delApptTimeEarly = "";
                        if (excep.DelApptTimeEarly.HasValue)
                        {
                            delApptTimeEarly = excep.DelApptTimeEarly.Value.ToString();
                        }

                        if (emailtomill.remainingbalance != "")
                        {
                            emailtomill.remainingbalance += "<tr><td>" + excep.Salesordernumber + " - " + excep.Lineitemnumber + "</td><td>" + excep.Exception.Desireddeliverydatetime + "</td><td>" + excep.Tknum + "</td><td>" + excep.Scacd + "</td><td>" + pickupApptDateErly + "</td><td>" + delApptDateEarly + "</td><td>" + delApptTimeEarly + "</td><td>" + excep.Exception.Createdby + "</td></tr>";
                        }
                    });

                    if (remainingbalance.Count() > 0)
                    {
                        emailtomill.remainingbalance += "</tbody></table>";
                    }
                    emailtomilllst.Add(emailtomill);
                });

                emailtomilllst.ForEach(e =>
                {
                    string file = System.IO.File.ReadAllText("email2.html");
                    file = file.Replace("{nodeliveryappt}", e.nodeliveryappointment);
                    file = file.Replace("{desireddeliverydate}", e.desireddeliverydate);
                    file = file.Replace("{pickupappoint}", e.pickupappoint);
                    file = file.Replace("{remainingbalance}", e.remainingbalance);
                    //mailerService.SendEmail(file, e.emailids, "Hot Order Status");
                });
                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int UpdateExceptiondetails(string shipmentURL, ISoliShipmentDetail soliShipmentDetail)
        {
            try
            {
                DateTime currDate = utilities.GetCSTNow();
                Log.Information($"C# Timer trigger function started at: {currDate}");

                List<Exceptions> exceptions = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Status == true).ToList();
                var oldexception = exceptions.Clone<Exceptions>();

                exceptions.ForEach(exception =>
                {
                    exception.Exceptiondetails.ToList().ForEach(expdetails =>
                    {
                        Exceptiondetails ed = context.Exceptiondetails.Where(x => x.Id == expdetails.Id).FirstOrDefault();
                        context.Exceptiondetails.Remove(ed);
                    });

                    Exceptions excep = new Exceptions();
                    excep = exception;

                    List<OrderDetail> lstorddet = new List<OrderDetail>();
                    SOLIList soliData = new SOLIList();

                    List<ShpDet> lstclshpdet = new List<ShpDet>();
                    ShpDet _cl_shpdet1 = new ShpDet { TKNUM = "" };
                    lstclshpdet.Add(_cl_shpdet1);

                    lstorddet.Add(new OrderDetail { POSNR = exception.Lineitemnumber, VBELN = exception.Salesordernumber });

                    if (exception.Rollstransferfromanothersoli == true)
                    {
                        List<Exceptiondetails> exceptiondet = exception.Exceptiondetails.Where(e => e.Hasexception == true &&
                        !(e.Salesordernumber == e.Exception.Salesordernumber && e.Lineitemnumber == e.Exception.Lineitemnumber)).ToList();

                        exceptiondet.ForEach(x =>
                        {
                            lstorddet.Add(new OrderDetail { POSNR = utilities.PrefixZero(x.Lineitemnumber, 6), VBELN = utilities.PrefixZero(x.Salesordernumber, 10) });
                        });
                    }

                    Orders orders = new Orders();
                    orders.IT_ORDERS = lstorddet;
                    orders.IT_SHIPNO = lstclshpdet;

                    OrderData orderData = new OrderData();
                    orderData.Orders = orders;

                    soliData = soliShipmentDetail.GetShipmentData(shipmentURL, orderData);

                    try
                    {
                        context.Database.BeginTransaction();

                        if (soliData.ET_DETAILS != null && soliData.ET_DETAILS.Length != 0)
                        {

                            soliData.ET_DETAILS.ToList().ForEach(x =>
                             {
                                 Exceptiondetails exceptiondetails = new Exceptiondetails();

                                 if (lstorddet.Any(l => (l.VBELN == x.VBELN && l.POSNR == x.POSNR)))
                                 {
                                     exceptiondetails.Hasexception = true;
                                 }
                                 else
                                 {
                                     exceptiondetails.Hasexception = false;
                                 }
                                 exceptiondetails.AccountExecutive = x.ACCOUNT_EXECUTIVE;
                                 exceptiondetails.Arktx = x.ARKTX;

                                 if (x.CDD == "")
                                 {
                                     exceptiondetails.Cdd = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.Cdd = Convert.ToDateTime(x.CDD);
                                 }
                                 exceptiondetails.ConfirmQty = x.CONFIRM_QTY;
                                 exceptiondetails.ContainerId = x.CONTAINER_ID;
                                 exceptiondetails.CustPo = x.CUST_PO;
                                 if (x.DEL_APPT_DATE_EARLY == "" || x.DEL_APPT_DATE_EARLY == "0000-00-00")
                                 {
                                     exceptiondetails.DelApptDateEarly = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.DelApptDateEarly = Convert.ToDateTime(x.DEL_APPT_DATE_EARLY);
                                 }
                                 if (x.DEL_APPT_TIME_EARLY == "")
                                 {
                                     exceptiondetails.DelApptTimeEarly = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.DelApptTimeEarly = TimeSpan.Parse(x.DEL_APPT_TIME_EARLY);
                                 }

                                 exceptiondetails.DelWindow = x.DEL_WINDOW;

                                 if (x.EPED == "" || x.EPED == "0000-00-00")
                                 {
                                     exceptiondetails.Eped = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.Eped = Convert.ToDateTime(x.EPED);
                                 }

                                 exceptiondetails.Gewei = x.GEWEI;
                                 exceptiondetails.Lineitemnumber = x.POSNR;
                                 if (x.MAD == "" || x.MAD == "0000-00-00")
                                 {
                                     exceptiondetails.Mad = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.Mad = Convert.ToDateTime(x.MAD);
                                 }

                                 exceptiondetails.Matnr = x.MATNR;
                                 exceptiondetails.OrderType = x.ORDER_TYPE;
                                 exceptiondetails.OrderUnits = x.ORDER_UNITS;
                                 exceptiondetails.OrderUnitsUom = x.ORDER_UNITS_UOM;
                                 if (x.PGI_DATE == "" || x.PGI_DATE == "0000-00-00")
                                 {
                                     exceptiondetails.PgiDate = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.PgiDate = Convert.ToDateTime(x.PGI_DATE);
                                 }

                                 if (x.PICKUP_APPT_DATE_ERLY == "" || x.PICKUP_APPT_DATE_ERLY == "0000-00-00")
                                 {
                                     exceptiondetails.PickupApptDateErly = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.PickupApptDateErly = Convert.ToDateTime(x.PICKUP_APPT_DATE_ERLY);
                                 }

                                 if (x.PICKUP_APPT_TIME_ERLY == "")
                                 {
                                     exceptiondetails.PickupApptTimeErly = null;
                                 }
                                 else
                                 {
                                     exceptiondetails.PickupApptTimeErly = TimeSpan.Parse(x.PICKUP_APPT_TIME_ERLY);
                                 }

                                 exceptiondetails.PlannedDelivQty = x.PLANNED_DELIV_QTY;
                                 exceptiondetails.ProdConfirmPct = x.PROD_CONFIRM_PCT;
                                 exceptiondetails.ProdQty = x.PROD_QTY;
                                 exceptiondetails.Salesordernumber = x.VBELN;
                                 exceptiondetails.Scacd = x.SCACD;
                                 exceptiondetails.ShipFrom = x.SHIP_FROM;
                                 exceptiondetails.ShipProdPct = x.SHIP_PROD_PCT;
                                 exceptiondetails.ShipQty = x.SHIP_QTY;
                                 exceptiondetails.Shipto = x.SHIPTO;
                                 exceptiondetails.ShiptoCity = x.SHIPTO_CITY;
                                 exceptiondetails.ShiptoCountry = x.SHIPTO_COUNTRY;
                                 exceptiondetails.ShiptoName = x.SHIPTO_NAME;
                                 exceptiondetails.ShiptoState = x.SHIPTO_STATE;
                                 exceptiondetails.ShiptoStreet = x.SHIPTO_STREET;
                                 exceptiondetails.ShiptoZipcd = x.SHIPTO_ZIPCD;
                                 exceptiondetails.Soldto = x.SOLDTO;
                                 exceptiondetails.SoldtoCity = x.SOLDTO_CITY;
                                 exceptiondetails.SoldtoCountry = x.SOLDTO_COUNTRY;
                                 exceptiondetails.SoldtoName = x.SOLDTO_NAME;
                                 exceptiondetails.SoldtoState = x.SOLDTO_STATE;
                                 exceptiondetails.SoldtoStreet = x.SOLDTO_STREET;
                                 exceptiondetails.SoldtoZipcd = x.SOLDTO_ZIPCD;
                                 exceptiondetails.Tknum = x.TKNUM;
                                 exceptiondetails.StoShipment = x.STO_SHIPMENT;
                                 exceptiondetails.Sto = x.STO;
                                 exceptiondetails.Vrkme = x.VRKME;
                                 exceptiondetails.Createddate = currDate;
                                 exceptiondetails.Modifieddate = currDate;
                                 exceptiondetails.Createdby = exception.Createdby;
                                 exceptiondetails.Modifiedby = exception.Modifiedby;
                                 exceptiondetails.Exceptionid = exception.Id;
                                 exception.Exceptiondetails.Add(exceptiondetails);
                             });

                            context.Exceptions.Update(exception);
                            int retvalue = context.SaveChanges();

                            if (retvalue > 0)
                            {
                                context.Database.CommitTransaction();
                            }
                        }
                        else
                        {
                            context.Database.RollbackTransaction();
                            //log error for the record;
                        }

                       
                    }
                    catch (Exception ex)
                    {
                        context.Database.RollbackTransaction();
                        Log.Error($"C# Timer trigger function ended at: {currDate}");
                        throw ex;
                    }
                });

                List<Exceptions> newexceptions = context.Exceptions.Include(x => x.Exceptiondetails).Where(x => x.Status == true).ToList();

                newexceptions.ForEach(exception =>
                {
                    Exceptions oldException = oldexception.Where(o => o.Id == exception.Id).FirstOrDefault();

                    if (oldException != null)
                    {
                        var oldActiveExceptiondetails = oldException.Exceptiondetails.Where(e => e.Hasexception == true).Select(e => new ExceptionSoli { Salesordernumber = e.Salesordernumber, Lineitemnumber = e.Lineitemnumber, Tknum = e.Tknum }).ToList();
                        var newActiveexceptiondetails = exception.Exceptiondetails.Where(e => e.Hasexception == true).Select(e => new ExceptionSoli { Salesordernumber = e.Salesordernumber, Lineitemnumber = e.Lineitemnumber, Tknum = e.Tknum }).ToList();

                        bool isAdditionalSoliExists = false;
                        newActiveexceptiondetails.ForEach(x =>
                        {
                            if (!isAdditionalSoliExists)
                            {
                                var soli = oldActiveExceptiondetails.Where(w => w.Salesordernumber == x.Salesordernumber && w.Lineitemnumber == x.Lineitemnumber && w.Tknum == x.Tknum).FirstOrDefault();
                                if (soli == null)
                                {
                                    isAdditionalSoliExists = true;
                                }
                            }
                        });

                        if (isAdditionalSoliExists == true)
                        {
                            EmailtoGPITeam(exception.Id);
                        }
                    }
                });

                return 1;
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                throw ex;
            }

            //Log.Information($"C# Timer trigger updateexceptiondetails function ended at: {utilities.GetCSTNow()}");
        }

        public void EmailtoGPITeam(int id)
        {
            try
            {
                Exceptions exception = context.Exceptions.Include(x => x.Exceptiondetails).Include(x => x.Exceptiondetails).Where(x => x.Id == id).FirstOrDefault();

                List<Exceptiondetails> exceptiondet = exception.Exceptiondetails.Where(e => e.Hasexception == true &&
                !(e.Salesordernumber == e.Exception.Salesordernumber && e.Lineitemnumber == e.Exception.Lineitemnumber)).ToList();

                string transfersoli = "";

                List<TransferSoli> transfersolilist = new List<TransferSoli>();

                exceptiondet.ForEach(x =>
                {
                    var transoli = transfersolilist.Where(w => w.Salesordernumber == x.Salesordernumber && w.Lineitemnumber == x.Lineitemnumber).FirstOrDefault();
                    if (transoli == null)
                    {
                        transfersolilist.Add(new TransferSoli { Salesordernumber = x.Salesordernumber, Lineitemnumber = x.Lineitemnumber });
                    }
                });

                int index = 1;
                transfersolilist.ToList().ForEach(x =>
                {
                    if (transfersoli == "")
                        transfersoli = "<tr><td colspan=\"3\"><p class=\"checks\">This HOT order require rolls to be transferred from another order.</p></td></tr><tr><td style=\"width: 30;\">SOLI #" + index + "</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + x.Salesordernumber + "-" + x.Lineitemnumber + "</p></td></tr>";
                    else
                        transfersoli = transfersoli + "<tr><td style=\"width: 30;\">SOLI #" + index + "</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + x.Salesordernumber + "-" + x.Lineitemnumber + "</p></td></tr>";

                    index = index + 1;
                });

                string modeshift = "";
                if (exception.Modeshiftrequired)
                {
                    modeshift = "<tr><td colspan=\"3\"><p class=\"checks\">This HOT order require a mode shift.</p></td></tr><tr><td style=\"width: 30;\">Shifted Mode</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + exception.Shiftedmode + "</p></td></tr><tr><td style=\"width: 30;\">Mode for remaining balance</td><td style=\"width: 5;\">:</td><td style=\"width: 65;\"><p>" + exception.Modeforbalance + "</p></td></tr>";
                }
                Customerserviceemails cust = context.Customerserviceemails.Where(x => x.Id == exception.Customerserviceemailid).FirstOrDefault();
                Exceptionreasons reason = context.Exceptionreasons.Where(x => x.Id == exception.Exceptionreasonid).FirstOrDefault();

                var shipfrom = exception.Exceptiondetails.Select(x => new { x.ShipFrom }).Distinct().ToList();

                shipfrom.ForEach(s =>
                {

                    string toemail = "";
                    var excep = exception.Exceptiondetails.Where(e => e.ShipFrom == s.ShipFrom).ToList();

                    var defaultemail = context.Mailinglist.Where(m => m.Millid == 8 && m.Ordertypeid == 7)
                                                   .Select(x => x.Planningteamdl).FirstOrDefault();

                    var millid = context.Mills.Where(m => m.Millnumber == s.ShipFrom).Select(m => m.Id).Distinct().FirstOrDefault();

                    if (excep.Count() > 0)
                    {
                        string file = System.IO.File.ReadAllText("email.html");
                        file = file.Replace("{soli}", exception.Salesordernumber + "-" + exception.Lineitemnumber);
                        file = file.Replace("{desireddeliverydate}", exception.Desireddeliverydatetime.ToString("MM/dd/yyyy HH:mm tt"));
                        file = file.Replace("{createdby}", exception.Createdby);
                        file = file.Replace("{customerserviceemail}", cust.Customerserviceemail);
                        file = file.Replace("{requestcomments}", exception.Requestcomments);
                        file = file.Replace("{rollcount}", exception.Hotweightrollcount);
                        file = file.Replace("{exceptionreason}", reason.Exceptionreason);
                        file = file.Replace("{afterhoursreceiver}", exception.Afterhoursreceivername + " " + exception.Afterhoursreceiverphone);
                        file = file.Replace("{transfersoli}", transfersoli.Trim());
                        file = file.Replace("{shiftmode}", exception.Shiftedmode);
                        file = file.Replace("{modebalance}", exception.Modeforbalance);
                        file = file.Replace("{modeshift}", modeshift);

                        var executionteamdl = context.Mailinglist.Where(m => m.Millid == millid).Select(m => m.Executionteamdl).Distinct().ToList();

                        if (executionteamdl != null)
                        {
                            executionteamdl.ForEach(x =>
                            {
                                if (toemail == "")
                                {
                                    toemail = x;
                                }
                                else
                                {
                                    toemail = toemail + "," + x;
                                }
                            });
                        }
                        else
                        {
                            toemail = defaultemail;
                        }

                        string solilist = "";
                        excep.ForEach(x =>
                        {
                            if (solilist == "")
                            {
                                solilist = "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                            }
                            else
                            {
                                solilist = solilist + "<tr><td>" + x.CustPo + "</td><td>" + x.Salesordernumber + "</td><td>" + x.Lineitemnumber + "</td><td>" + x.PgiDate + "</td><td>" + x.Eped + "</td><td>" + x.Tknum + "</td><td>" + x.Scacd + "</td><td>" + x.ContainerId + "</td><td>" + x.PickupApptDateErly + "</td><td>" + x.DelApptDateEarly + "</td><td>" + x.DelApptTimeEarly + "</td><td>" + x.SoldtoName + " ;" + x.SoldtoStreet + "" + x.SoldtoCity + "" + x.SoldtoState + x.SoldtoCountry + "</td></tr>";
                            }
                        });

                        file = file.Replace("{trow}", solilist);

                        if (toemail != "")
                            mailerService.SendEmail(file, toemail, "Hot Order update - Test Mail");
                    }
                });

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }



    public class ExceptionSoli
    {
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public string Tknum { get; set; }
    }

    public class TransferSoli
    {
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
    }

    public class EmailToMill
    {
        public string millid { get; set; }
        public string emailids { get; set; }
        public string listtype { get; set; }
        public string nodeliveryappointment { get; set; } = "";
        public string desireddeliverydate { get; set; } = "";
        public string pickupappoint { get; set; } = "";
        public string remainingbalance { get; set; } = "";
    }

    public class MillList
    {
        public string mill { get; set; }
        public string listtype { get; set; }
        public Exceptiondetails notificationlist { get; set; }
    }


}

