﻿using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace HotOrder.Service
{
    public interface IMailerService
    {
        void SendEmail(string body, string toemail, string subject);
    }
    public class MailerService: IMailerService
    {
        public void SendEmail(string body, string toemail, string subject)
        {
            Log.Information("Email for " + toemail + ", subject " + subject);
            MailMessage mail = new MailMessage();
            mail.Subject = subject;
            SmtpClient client = new SmtpClient("gpimail.na.graphicpkg.pri");
            mail.From = new MailAddress("donotreply@graphicpkg.com");
            mail.IsBodyHtml = true;

            try
            {
                mail.Body = body;
                mail.To.Add(toemail);
                client.Send(mail);
            }
            catch (Exception ex)
            {
                Log.Error("Email message: " + ex.Message);
                Log.Error("Email innerException: " + ex.InnerException);
                Log.Error("Email stack trace: " + ex.StackTrace);
                throw;
            }
        }
    }
}
