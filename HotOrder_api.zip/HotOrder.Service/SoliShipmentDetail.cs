﻿using HotOrder.BusinessModel;
using Newtonsoft.Json;
using Serilog;
using System;
using System.IO;
using System.Net;

namespace HotOrder.Service
{
    public interface ISoliShipmentDetail
    {
       SOLIList GetShipmentData(string webMethodsUrl, OrderData orderData);
    }

    public class SoliShipmentDetail : ISoliShipmentDetail
    {
        //static string webMethodsUrl = string.Format("http://gpiptcdwmis1.na.graphicpkg.pri:18555/GPI/SoliShipmentDetail/fetch");
        public SOLIList GetShipmentData(string webMethodsUrl, OrderData orderData)
        {
            try
            {                
                WebRequest requestObj = WebRequest.Create(webMethodsUrl);
                requestObj.Method = "POST";
                requestObj.ContentType = "application/json";
                string postData = JsonConvert.SerializeObject(orderData);

                SOLIList soli = new SOLIList();
                Log.Information("Webmethodurl: " + webMethodsUrl);

                using (var streamWriter = new StreamWriter(requestObj.GetRequestStream()))
                {
                    streamWriter.Write(postData);
                    streamWriter.Flush();
                    streamWriter.Close();
                    var httpResponse = (HttpWebResponse)requestObj.GetResponse();

                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        soli = (SOLIList)JsonConvert.DeserializeObject(streamReader.ReadToEnd(), typeof(SOLIList));
                    }
                }

                return soli;
            }
            catch (Exception ex)
            {
                Log.Error("Shipment exception : " + ex);
                throw ex;
            }
        }
    }


}
