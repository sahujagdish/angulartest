﻿using HotOrder.BusinessModel;
using HotOrder.Data.Model;
using HotOrder.Data.Model.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HotOrder.Service
{
    public interface IMillsService
    {
        ModelPaged<MillsModel> GetMillsDetail(LookupModel LookupModel);
        //MillsModel GetMill(int id);
        string InsertUpdateMill(MillsModel millsModel);
        List<CommonModel> GetMills();
        string DeleteMill(int id);
    }

    public class MillsService : IMillsService
    {
        HotOrderContext context;
        IUtilities utilities;

        public MillsService(HotOrderContext _context, IUtilities _utilities)
        {
            context = _context;
            utilities = _utilities;
        }

        //public int Upload()
        //{

        //    return 1;
        //}


        public ModelPaged<MillsModel> GetMillsDetail(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var query = context.Mills.SortBy(lookupModel.SortColumnName, lookupModel.SortOrder).Select(x =>
               new MillsModel()
               {
                   MillId = x.Id,
                   Millnumber = x.Millnumber,
                   Millname = x.Millname,
                   Createdby = x.Createdby,
                   Createddate = x.Createddate,
                   Modifiedby = x.Modifiedby,
                   Modifieddate = x.Modifieddate
               }
            ).ToList();

            var result = new ModelPaged<MillsModel>()
            {
                PagedDataModel = query.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return result;
        }

        public List<CommonModel> GetMills()
        {
            return context.Mills.Select(
              x => new CommonModel()
              {
                  Id = x.Id,
                  Name = x.Millname
              }
            ).ToList();
        }

        //public MillsModel GetMill(int id)
        //{

        //    return context.Mills.Where(x => x.Id == id).Select(x =>
        //        new MillsModel
        //        {
        //            Millnumber = x.Millnumber,
        //            Millname = x.Millname
        //        }).FirstOrDefault();
        //}

        public string InsertUpdateMill(MillsModel millsModel)
        {
            var duplicatecheck = context.Mills.Where(x => x.Id != millsModel.MillId && x.Millnumber == millsModel.Millnumber).FirstOrDefault();

            if (duplicatecheck != null)
            {
                return "millexists";
            }
            DateTime cst = utilities.GetCSTNow();
            Mills millsexists = context.Mills.Where(x => x.Id == millsModel.MillId).FirstOrDefault();
            if (millsexists != null)
            {
                millsexists.Millname = millsModel.Millname;
                millsexists.Millnumber = millsModel.Millnumber;
                millsexists.Modifiedby = millsModel.Modifiedby;
                millsexists.Modifieddate = cst;
                context.Mills.Attach(millsexists);
                this.context.Entry(millsexists).State = EntityState.Modified;
            }
            else
            {
                context.Mills.Add(
                    new Mills()
                    {
                        Millname = millsModel.Millname,
                        Millnumber = millsModel.Millnumber,
                        Createdby = millsModel.Createdby,
                        Createddate = cst,
                        Modifiedby = millsModel.Createdby,
                        Modifieddate = cst,
                    });
            }

            return Convert.ToString(context.SaveChanges());
        }

        public string DeleteMill(int id)
        {
            Mailinglist mailinglist = context.Mailinglist.Where(x => x.Millid == id).FirstOrDefault();
            if (mailinglist != null)
            {
                return "MailingExists";
            }

            Mills millsexists = context.Mills.Where(x => x.Id == id).FirstOrDefault();

            if (millsexists != null)
            {
                context.Mills.Remove(millsexists);
                return Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }
    }
}
