﻿namespace HotOrder.BusinessModel
{
    public class OrderTypesModel : BaseModel
    {
        public int OrdertypeId { get; set; }
        public string Ordertype { get; set; }
    }
}
