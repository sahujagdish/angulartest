﻿
using System;

namespace HotOrder.BusinessModel
{
    public class BaseModel
    {
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime? Modifieddate { get; set; }
    }
}
