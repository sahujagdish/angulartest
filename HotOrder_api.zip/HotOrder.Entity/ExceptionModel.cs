﻿using System;
using System.Collections.Generic;

namespace HotOrder.BusinessModel
{
    public class ExceptionModel : BaseModel
    {
        public int Id { get; set; }
        public bool Status { get; set; }
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public DateTime Desireddeliverydatetime { get; set; }
        public string Hotweightrollcount { get; set; }
        public int Exceptionreasonid { get; set; }
        public string Exceptionreason { get; set; }
        public int Customerserviceemailid { get; set; }
        public string Customerserviceemail { get; set; }
        public string Afterhoursreceivername { get; set; }
        public string Afterhoursreceiverphone { get; set; }
        public bool Rollstransferfromanothersoli { get; set; }
        public bool Modeshiftrequired { get; set; }
        public string Shiftedmode { get; set; }
        public string Modeforbalance { get; set; }
        public string Requestcomments { get; set; }
        public bool Planningteamnotified { get; set; }

        public virtual List<TransferSoliModel> TransferSoli { get; set; }
        public virtual List<ExceptiondetailsModel> Exceptiondetails { get; set; }

    }



    public class ExceptionListModel : BaseModel
    {
        public int Id { get; set; }
        public bool Status { get; set; }
        public string ShipmentNumber { get; set; }
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public DateTime Desireddeliverydatetime { get; set; }
        public string ShipFrom { get; set; }
        public string SoldTo { get; set; }
        public string SoldName { get; set; }
        public DateTime? EPED { get; set; }
        public string Tknum { get; set; }
        public bool isSelected { get; set; }
    }
}
