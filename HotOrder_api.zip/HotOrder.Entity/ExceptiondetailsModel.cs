﻿using System;

namespace HotOrder.BusinessModel
{
    public class ExceptiondetailsModel
    {
        public bool Isprimary { get; set; }
        public bool? Hasexception { get; set; }
        public int? Exceptionid { get; set; }
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public string Tknum { get; set; }
        public string StoShipment { get; set; }
        public string OrderType { get; set; }
        public string AccountExecutive { get; set; }
        public string Arktx { get; set; }
        public DateTime? Cdd { get; set; }
        public string ConfirmQty { get; set; }
        public string ContainerId { get; set; }
        public string CustPo { get; set; }
        public DateTime? DelApptDateEarly { get; set; }
        public TimeSpan? DelApptTimeEarly { get; set; }
        public string DelWindow { get; set; }
        public DateTime? Eped { get; set; }
        public string Gewei { get; set; }
        public DateTime? Mad { get; set; }
        public string Matnr { get; set; }
        public string OrderUnits { get; set; }
        public string OrderUnitsUom { get; set; }
        public DateTime? PgiDate { get; set; }
        public DateTime? PickupApptDateErly { get; set; }
        public TimeSpan? PickupApptTimeErly { get; set; }
        public string PlannedDelivQty { get; set; }
        public string ProdConfirmPct { get; set; }
        public string ProdQty { get; set; }
        public string Scacd { get; set; }
        public string ShipFrom { get; set; }
        public string ShipProdPct { get; set; }
        public string ShipQty { get; set; }
        public string Shipto { get; set; }
        public string ShiptoCity { get; set; }
        public string ShiptoCountry { get; set; }
        public string ShiptoName { get; set; }
        public string ShiptoState { get; set; }
        public string ShiptoStreet { get; set; }
        public string ShiptoZipcd { get; set; }
        public string Soldto { get; set; }
        public string SoldtoCity { get; set; }
        public string SoldtoCountry { get; set; }
        public string SoldtoName { get; set; }
        public string SoldtoState { get; set; }
        public string SoldtoStreet { get; set; }
        public string SoldtoZipcd { get; set; }
        public string Sto { get; set; }
        public string Vrkme { get; set; }
    }

    public class TransferSoliModel
    {
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
    }


    public class ExportModel
    {
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public string CustPo { get; set; }
        public string ShipmentNumber { get; set; }
        public DateTime Desireddeliverydatetime { get; set; }
        public string Hotweightrollcount { get; set; }
        public string Exceptionreason { get; set; }
        public string Customerserviceemail { get; set; }
        public string Afterhoursreceivername { get; set; }
        public string Afterhoursreceiverphone { get; set; }
        public DateTime? PgiDate { get; set; }
        public DateTime? Eped { get; set; }
        public string Shiftedmode { get; set; }
        public string Modeforbalance { get; set; }
        public string Requestcomments { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string StoShipment { get; set; }
        public string OrderType { get; set; }
        public string AccountExecutive { get; set; }
        public string Arktx { get; set; }
        public DateTime? Cdd { get; set; }
        public string ConfirmQty { get; set; }
        public string ContainerId { get; set; }
        public DateTime? DelApptDateEarly { get; set; }
        public TimeSpan? DelApptTimeEarly { get; set; }
        public string DelWindow { get; set; }
        public string Gewei { get; set; }
        public DateTime? Mad { get; set; }
        public string Matnr { get; set; }
        public string OrderUnits { get; set; }
        public string OrderUnitsUom { get; set; }
        public DateTime? PickupApptDateErly { get; set; }
        public TimeSpan? PickupApptTimeErly { get; set; }
        public string PlannedDelivQty { get; set; }
        public string ProdConfirmPct { get; set; }
        public string ProdQty { get; set; }
        public string Scacd { get; set; }
        public string ShipFrom { get; set; }
        public string ShipProdPct { get; set; }
        public string ShipQty { get; set; }
        public string Shipto { get; set; }
        public string ShiptoCity { get; set; }
        public string ShiptoCountry { get; set; }
        public string ShiptoName { get; set; }
        public string ShiptoState { get; set; }
        public string ShiptoStreet { get; set; }
        public string ShiptoZipcd { get; set; }
        public string Soldto { get; set; }
        public string SoldtoCity { get; set; }
        public string SoldtoCountry { get; set; }
        public string SoldtoName { get; set; }
        public string SoldtoState { get; set; }
        public string SoldtoStreet { get; set; }
        public string SoldtoZipcd { get; set; }
        public string Sto { get; set; }
        public string Vrkme { get; set; }
        public int Id { get; set; }
        public bool isPrimary { get; set; }
        public bool Hasexception { get; set; }

    }
}