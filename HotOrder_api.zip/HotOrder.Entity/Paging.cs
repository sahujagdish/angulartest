﻿using System;

namespace HotOrder.BusinessModel
{
    [Serializable]
    public class Paging
    {
        public int TotalCount { get; set; }
        public int PageSelected { get; set; }
        public int PageSize { get; set; }
    }
}
