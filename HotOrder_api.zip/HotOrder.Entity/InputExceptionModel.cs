﻿using System;
using System.Collections.Generic;

namespace HotOrder.BusinessModel
{
    public class InputExceptionModel : BaseModel
    {
        public InputExceptionModel()
        {
            //OrderDetailList = new List<OrderDetail>();
            //var orderdet = new[]
            //{
            //   // new OrderDetail { POSNR = "000010", VBELN = "101001844"},
            //    new OrderDetail { POSNR = "000020", VBELN = "101001761"},
            //    new OrderDetail { POSNR = "000020", VBELN = "0101001766"}
            //};
            //OrderDetailList.AddRange(orderdet);
        }
        public int Id { get; set; }
        public bool Status { get; set; }
        public string Salesordernumber { get; set; }
        public string Lineitemnumber { get; set; }
        public DateTime Desireddeliverydatetime { get; set; }
        public string Desireddeliverytime { get; set; }
        public string Hotweightrollcount { get; set; }
        public int Exceptionreasonid { get; set; }
        public string Exceptionreason { get; set; }
        public int Customerserviceemailid { get; set; }
        public string Customerserviceemail { get; set; }
        public string Afterhoursreceivername { get; set; }
        public string Afterhoursreceiverphone { get; set; }
        public bool Rollstransferfromanothersoli { get; set; }
        public bool Modeshiftrequired { get; set; }
        public string Shiftedmode { get; set; }
        public string Modeforbalance { get; set; }
        public string Requestcomments { get; set; }

        public List<OrderDetail> OrderDetailList { get; set; }
    }
}
