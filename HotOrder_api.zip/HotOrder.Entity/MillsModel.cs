﻿namespace HotOrder.BusinessModel
{
    public class MillsModel : BaseModel
    {
        public int MillId { get; set; }
        public string Millnumber { get; set; }
        public string Millname { get; set; }

    }
}
