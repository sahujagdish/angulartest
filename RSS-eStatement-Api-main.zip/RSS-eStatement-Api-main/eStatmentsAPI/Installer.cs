﻿using Common.Utilities;
using eStatmentsDAC.Service;
using eStatmentsDAC.Service.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eStatmentsAPI.Models;
using StatementsDAC.Service;
using Microsoft.Extensions.Caching.Memory;
using FluentValidation;
using eStatmentsAPI.Validation;
using eStatmentsDAC.Classes;

namespace eStatmentsAPI
{
    public class Installer : AbstractInstaller
    {
        public override void RegisterDependencies(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IEStatementService, EStatementService>();            
            serviceCollection.AddTransient<IParticipantService, ParticipantService>();
            serviceCollection.AddTransient<IReportService, ReportService>();
            serviceCollection.AddTransient<ISecurityService, SecurityService>();
            serviceCollection.AddTransient<IStatementService, StatementService>();
            serviceCollection.AddTransient<IMailerService, MailerService>();
            serviceCollection.AddTransient<IAccountService, AccountService>();
            serviceCollection.AddTransient<IUtilityService, UtilityService>();
            serviceCollection.AddTransient<INotificationService, NotificationService>();
            serviceCollection.AddTransient<ISponsorAccessService, SponsorAccessService>();
            
            serviceCollection.AddSingleton<IFileService, FileService>();

            serviceCollection.AddTransient<IViewStatementHelperService, ViewStatementHelperService>();
            serviceCollection.AddTransient<INotificationHelperService, NotificationHelperService>();
            
            serviceCollection.AddTransient<IValidator<DownloadReportRepoRequest>, DownloadReportRepoRequestValidation>();
            serviceCollection.AddTransient<IValidator<ParticipantRequest>, Participant_RequestValidator>();
            serviceCollection.AddTransient<IValidator<ParticipantInfoRequest>, ParticipantInfoRequestValidator>();
            serviceCollection.AddTransient<IValidator<PlanRequest>, PlanRequestValidator>();
            serviceCollection.AddTransient<IValidator<StatementRequest>, StatementRequestValidator>();
            serviceCollection.AddTransient<IValidator<SearchParticipantRequest>, SearchParticipantRequestValidator>();
            serviceCollection.AddTransient<IValidator<SelectSponsorRequest>, SelectSponsorRequestValidator>();
            serviceCollection.AddTransient<IValidator<UpdateSponsorAdminRequest>, UpdateSponsorAdminRequestValidator>();
            serviceCollection.AddTransient<IValidator<ChangePassword>, ChangePasswordValidator>();

            serviceCollection.AddMemoryCache();
        }
    }
}
