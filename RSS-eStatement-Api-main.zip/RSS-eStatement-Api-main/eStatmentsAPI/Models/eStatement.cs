﻿namespace eStatmentsAPI.Models
{
	public class eStatement
	{
	}
	public class Communications
	{
		public short CommunicationTypeCD;
		public string Descrip;
		public string Scope;


	}
	public class ProviderIdName
	{
		public int ProviderID { get; set; }
		public string Name { get; set; }
	}
	public class ProviderIdNameActiveUpdated
	{
		public int ProviderID { get; set; }
		public string Name { get; set; }
		public bool Active { get; set; }
		public bool Updated { get; set; }

	}

	public class ProviderDetails
	{

		public int ProviderID;
		public string Name;
		public string Email;
		public string ImgPath;
		public string VirtualDir;
		public string Code;
		public char[] ProvID;
		public bool Active = true;
		public byte UseSSNPIN = 1;
		public bool SubscribeEMail = false;
		public bool Accept = false;
		public bool IPClassC = true;
		public bool SummaryRpt = false;
		public bool IPCheck = false;
		public char[] IPAddress = null;
		public bool ValidationCode = false;
		public bool CustomNews = false;
		public bool Match = false;
		public bool PadAcctNumber = false;
		public byte PadDigits = 0;
		public bool CustomUnsubscribe = false;
		public bool CustomLogin = false;
		public bool CustomSample = false;
		public string NewsLetterPath;
		public string SamplePath;
		public string SummaryReportPath;
		public string HelpMsg = null;
		public string MailServer = null;
		public string MailAccount = null;
		public string MailUserName = null;
		public string MailPassword = null;
		public bool Help = false;
		public bool Signon = false;
		public bool Mail = false;
		public byte PDFBackground = 0;
		public bool Reconcile = false;
		public bool Handshake = false;
		public bool Advisory = false;
		public bool WarehouseOnly = false;
		public bool RegMatch = false;
		public bool Tracking = false;
		public bool AssetRetention = false;
		public bool SponHandshake = false;
		public bool AdminHandshake = false;
		public string ParHandshakeURL = "";
		public string SponHandshakeURL = "";
		public string AdminHandshakeURL = "";
		public bool ParSiteIsActive = true;
		public bool SponSiteIsActive = true;
		public bool AdminSiteIsActive = true;
		public bool PartIdInEmail = false;
		public bool PrivacyStatement = false;
		public bool RegSiteIsActive = false;
		public bool showPromoContent = true;
		public string NeptuneCustNo = null;
		public string ApplicationType = "statements";
		public bool HasEBN = false;
		public bool EmailParSiteLink = false;
		public bool AdminPasswordChange = false;
		/*
    Accept
    Active
    AdminExitURL
    AdminHandshake
    AdminHandshakeURL
    AdminPasswordChange
    AdminSiteIsActive
    Advisory
    ApplicationType
    ApprovalEmail
    AssetRetention
    Code
    CustomLogin
    CustomNews
    CustomSample
    CustomUnsubscribe
    Email
    EmailParSiteLink
    Handshake
    HasEBN
    Help
    ImgPath
    IPAddress
    IPCheck
    IPClassC
    Mail
    MailAccount
    MailPassword
    MailServer
    MailUserName
    Match
    Name
    NeptuneCustNo
    NewsLetterPath
    PadAcctNumber
    PadDigits
    ParExitURL
    ParHandshakeURL
    ParSiteIsActive
    PartIdInEmail
    PDFBackground
    PrivacyStatement
    ProvID
    ProviderID
    Reconcile
    RegMatch
    RegSiteIsActive
    SamplePath
    showPromoContent
    Signon
    SponExitURL
    SponHandshake
    SponHandshakeURL
    SponSiteIsActive
    SubscribeEMail
    SummaryReportPath
    SummaryRpt
    Tracking
    UseSSNPIN
    ValidationCode
    VirtualDir
    WarehouseOnly

*/
		/*	139
		Accept
		AcceptMsg
		AcceptMsgLastChange
		AcceptMsgLastChangeID
		Active
		AdminExitURL
		AdminHandshake
		AdminHandshakeURL
		AdminPasswordChange
		AdminSiteIsActive
		Advisory
		AllowLoginWithoutSS_IdentData
		ApplicationType
		ApprovalEmail
		AssetRetention
		ChangePWInstructionsText
		CloseDisclosureWindow
		Code
		CustomFAQHeadertext
		CustomFooterText
		CustomLogin
		CustomNews
		CustomPDFButtonText
		CustomSample
		CustomUnsubscribe
		CustomWelcomeMessageText
		DocumentViewingPageText
		EBNID
		Email
		EMailMsg
		EMailMsgLastChange
		EMailMsgLastChangeID
		EmailParSiteLink
		FtpInfoID
		Handshake
		HasCustomFAQHeader
		HasCustomFAQSection
		HasCustomFooterText
		HasCustomPDFButtonText
		HasCustomRegistrationEmail
		HasCustomWelcomeMessage
		HasDocumentViewingPage
		HasEBN
		HasExtendedTopNavLinks
		HasOrderedTextUtilityPanelCustomWidth
		HasPreUnsubscribeMsg2
		HasRegisterEmailInstructions
		HasRegisterFooterInstructions
		HasRegisterHeaderInstructions
		HasRegisterMemberidInstructions
		HasSampleSubLinks
		hasSensitivePlans
		HasSuperSponsor
		HasUpdateProfileInstructions
		HasUpdateProfilePanelCustomWidth
		Help
		HelpMsg
		HelpMsgLastChange
		HelpMsgLastChangeID
		ImgPath
		IPAddress
		IPCheck
		IPClassC
		LoginMsg
		LoginMsgLastChange
		LoginMsgLastChangeID
		Mail
		MailAccount
		MailPassword
		MailServer
		MailUserName
		Match
		MaxFailedLogin
		MessageBoardID
		Name
		NeptuneCustNo
		NewsLetterPath
		NumberOfPeriodsToDisplay
		PadAcctNumber
		PadDigits
		ParExitURL
		ParHandshakeURL
		ParSiteIsActive
		PartIdInEmail
		PasswordEditDays
		PDFBackground
		PreUnsubscribeMsg
		PreUnsubscribeMsg2
		PreUnsubscribeMsgLastChange
		PreUnsubscribeMsgLastChangeID
		PrivacyStatement
		ProvID
		ProviderGUID
		ProviderID
		PWInstructionsText
		Reconcile
		RegisterFooterInstructionsText
		RegisterHeaderInstructionsText
		RegistrationEmailBodyMsg
		RegistrationEmailBodyMsgLastChange
		RegistrationEmailBodyMsgLastChangeID
		RegMatch
		RegSiteIsActive
		SamplePath
		SampleStatementType
		showPromoContent
		Signon
		SignonMsg
		SignonMsgLastChange
		SignonMsgLastChangeID
		SiteVersion
		SmartImagePath
		SmartStylePath
		SponExitURL
		SponHandshake
		SponHandshakeURL
		SponSiteIsActive
		SubscribeEMail
		SummaryReportPath
		SummaryRpt
		Tracking
		UnsubscribeEmailBodyMsg
		UnsubscribeEmailBodyMsgLastChange
		UnsubscribeEmailBodyMsgLastChangeID
		UnsubscribeEmailSubjectMsg
		UnsubscribeEmailSubjectMsgLastChange
		UnsubscribeEmailSubjectMsgLastChangeID
		UnsubscribeMsg
		UnsubscribeMsgLastChange
		UnsubscribeMsgLastChangeID
		UserIDIstructionsText
		UseSSNPIN
		ValidationCode
		ValidationMsg
		ValidationMsgLastChange
		ValidationMsgLastChangeID
		VirtualDir
		WarehouseOnly
		*/



	}

	public class c_Administrator
	{
		public int AdministratorID { get; set; }
		public string FName { get; set; }
		public string LName { get; set; }
		public string UserID { get; set; }
		public string Password { get; set; }
		public int ProfileID { get; set; }
		public int ProviderID { get; set; }


	}
	public class c_Profiles
	{
		public int ProfileID { get; set; }
		//public int  ProviderID;
		public string ProfileName { get; set; }

	}
	public class c_ProvParLinks
	{
		public int PRPA_ProviderID { get; set; }
		public int PRPA_LinkOrder { get; set; }
		public int PRPA_LinkID { get; set; }
		public bool display { get; set; }

	}
	public class c_teProviderCommunications
	{
		public int ProviderID { get; set; }
		public short DisplayOrder { get; set; }
		public short CommunicationTypeCD { get; set; }
		public bool display { get; set; }

	}
	public class c_AboutText
	{
		public int AboutID { get; set; }
		public short AboutOrder { get; set; }
		public string AboutHeader { get; set; }
		public string AboutBody { get; set; }
		public int ProviderID { get; set; }
		public bool Active { get; set; }

	}


}


