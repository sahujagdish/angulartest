﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MMARDataApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using StatementsDAC.Service;
using Common.Utilities;
using eStatmentsDAC.BLL;
using StatementsDAC.BLL;

namespace eStatmentsAPI.Models
{
    public interface INotificationHelperService
    {
        PostResponse GetSaveResponse(PlanEnotifyOverrideType enotifyOverrideType,
            string radioPanProvider, string utilityText, string responseType, int providerID, vPlan planInfo = null);
        GetResponse ConstructReturnData(bool success, string contnet, MMARDataApi.Models.PlanEnotifyOverrideType enotifyOverrideType);
        void AddPlanDetail(IActionResult response,
            PlanEnotifyOverrideType overrideType,
            List<GetResponse> list,
            ProviderENotifySettings providerENotifySettings);

        PostResponse PostPlanNotification(int providerID, vPlan plan, EPlanNotification data, PlanEnotifyOverrideType notifyType);
    }

    public class NotificationHelperService : INotificationHelperService
    {
       INotificationService notificationService;
        IConfiguration configuration;
        IMailerService mailerService;

        public NotificationHelperService(IConfiguration configuration,
            INotificationService notificationService, IMailerService mailerService )
        {
            this.mailerService = mailerService;
            this.notificationService = notificationService;
            this.configuration = configuration;
        }

        public PostResponse GetSaveResponse(PlanEnotifyOverrideType enotifyOverrideType, 
            string radioPanProvider, string utilityText, string responseType,int providerID, vPlan planInfo)
        {
            string settingTypeText = string.Empty;
            switch (enotifyOverrideType)
            {
                case PlanEnotifyOverrideType.emailbody:
                    settingTypeText = "email text";
                    break;
                case PlanEnotifyOverrideType.fromaddress:
                    settingTypeText = "from address";
                    break;
                case PlanEnotifyOverrideType.fromname:
                    settingTypeText = "from name";
                    break;
                default:
                    settingTypeText = string.Empty;
                    break;
            }

            var postResponse = new PostResponse()
            {
                SettingType = PlanEnotifyOverrideType.emailbody.ToString(),
                Value = $"The {utilityText} {radioPanProvider} {settingTypeText} was {responseType} successfully."
            };

            try
            {
                var statementServer = configuration[Constants.StatementServer];
                var statementmail = configuration[Constants.ENotificationEMail];

                var provider = Provider.GetByProviderID(providerID);
                var providerName = (provider?.Name) ?? string.Empty;
                var planName = (planInfo == null ? string.Empty : planInfo.PlanName1);

                var mailBodyString = $"<br><b>Server: {statementServer}</b> <br><br>{providerName} has {responseType} {radioPanProvider} {planName} eNotification email text";
                var mailSubject = $"Server: {statementServer} - {providerName} has {responseType} {radioPanProvider} {planName} eNotification email text";
#if DEBUG
                mailerService.SendEmail(mailBodyString, this.configuration.GetValue<string>(Constants.ToEmail), mailSubject);
#else
                mailerService.SendEmail(mailBodyString, statementmail, mailSubject);
#endif
                postResponse.MailSent = true;
            }
            catch (Exception ex)
            {
                postResponse.MailSent = false;
            }

            return postResponse;
        }

        public GetResponse ConstructReturnData(bool success, string contnet, MMARDataApi.Models.PlanEnotifyOverrideType enotifyOverrideType)
        {
            var data = new GetResponse() { Data = new FieldData() };
            data.Success = success;
            data.Data.fieldLabel = "eNotification";
            data.Data.id = "txtarea-content";
            data.Data.name = "content";
            data.Data.value = contnet;
            data.Data.settingType = enotifyOverrideType.ToString();
            return data;
        }

        public void AddPlanDetail(IActionResult response,
            PlanEnotifyOverrideType overrideType,
            List<GetResponse> list,
            ProviderENotifySettings providerENotifySettings)
        {
            if (response is OkObjectResult responseOkResult)
                list.Add(ConstructReturnData(true, responseOkResult.Value as string, overrideType));
            else if (response is NotFoundObjectResult notfoundeOkResult)
            {
                switch (overrideType)
                {
                    case PlanEnotifyOverrideType.emailbody:
                        list.Add(ConstructReturnData(true, providerENotifySettings.EmailBody, overrideType));
                        break;
                    case PlanEnotifyOverrideType.fromaddress:
                        list.Add(ConstructReturnData(true, providerENotifySettings.Fromaddr, overrideType));
                        break;
                    case PlanEnotifyOverrideType.fromname:
                        list.Add(ConstructReturnData(true, providerENotifySettings.Fromname, overrideType));
                        break;
                    default:
                        list.Add(ConstructReturnData(false, "", overrideType));
                        break;
                }
            }
            else
                list.Add(ConstructReturnData(false, string.Empty, overrideType));
        }        

        public PostResponse PostPlanNotification(int providerID, vPlan plan, EPlanNotification data, PlanEnotifyOverrideType notifyType)
        {
            string emailResponse = string.Empty;
            switch (notifyType)
            {
                case PlanEnotifyOverrideType.emailbody:
                    emailResponse = notificationService.InsertUpdatePlanNotifySettings(plan.ProviderId ,plan.ExternalPlanId , data.emailbody, (int)notifyType);
                    break;
                case PlanEnotifyOverrideType.fromaddress:
                    emailResponse = notificationService.InsertUpdatePlanNotifySettings(plan.ProviderId, plan.ExternalPlanId, data.fromaddress, (int)notifyType);
                    break;
                case PlanEnotifyOverrideType.fromname:
                    emailResponse = notificationService.InsertUpdatePlanNotifySettings(plan.ProviderId, plan.ExternalPlanId, data.fromname, (int)notifyType);
                    break;
                default:
                    emailResponse =  string.Empty;
                    break;
            }

            var response = GetSaveResponse(notifyType, "plan", data.utilityType, emailResponse,providerID,plan);
            return response;

        }
    }

    public class EProviderNotification
    {
        public string utilityType { get; set; }
        public string emailbody { get; set; }
    }

    public class EPlanNotification : EProviderNotification
    {
        public string fromaddress { get; set; }
        public string fromname { get; set; }
    }

    public class PostResponse
    {
        public string SettingType { get; set; }
        public string Value { get; set; }
        public bool MailSent { get; set; }
    }

    public class GetResponse
    {
        public bool Success { get; set; }
        public FieldData Data { get; set; }
    }

    public class FieldData
    {
        public string fieldLabel { get; set; }
        public string id { get; set; }
        public string name { get; set; }
        public string value { get; set; }
        public string settingType { get; set; }
    }
}
