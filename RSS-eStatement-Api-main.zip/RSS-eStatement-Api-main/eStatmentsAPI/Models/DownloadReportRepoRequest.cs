﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public class DownloadReportRepoRequest
    {
        public int ProviderId { get; set; }
        public string PlanNum { get; set; }
        public string UID { get; set; }
        public string PartId { get; set; }
        public DateTime Date { get; set; }
        public string FileName { get; set; }
    }
}
