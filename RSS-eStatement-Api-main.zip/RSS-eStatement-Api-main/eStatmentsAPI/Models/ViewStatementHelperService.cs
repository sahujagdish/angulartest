﻿using eStatmentsAPI.Controllers;
using eStatmentsDAC.BLL;
using eStatmentsDAC.Classes;
using eStatmentsDAC.Service.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public interface IViewStatementHelperService
    {
        IViewStatementResponse CreateViewStatementResponse(Provider provider);
        void FillResponseWithStatements(IViewStatementResponse response, ViewStatementRequest request);
        string DecideButtonText(Provider provider, ViewTypeEnum viewType, ParticipantStatement sitem, bool canHaveCustomButtonText = false);
    }

    public class ViewStatementHelperService: IViewStatementHelperService
    {
        IStatementService statementService;
        IConfiguration configuration;
        IFileService fileService;

        public ViewStatementHelperService(IStatementService statementService,
            IConfiguration configuration, IFileService fileService)
        {
            this.fileService = fileService;
            this.configuration = configuration;
            this.statementService = statementService;
        }
        public IViewStatementResponse CreateViewStatementResponse(Provider provider)
        {
            var response = new ViewStatementResponse();
            if (!provider.AssetRetention)
            {
                response.LinkTitle = "Statement";
                response.LinkMessage = "View Statement PDF";
                if (provider.ApplicationType == "statements")
                    response.Header = "View Statement";
                else
                    response.Header = "View Communication";
            }
            else
            {
                response.Header = "Personalized Information";
                response.LinkTitle = "Personalized Information";
                response.LinkMessage = "View Personalized Information";
            }

            return response;
        }
        public void FillResponseWithStatements(IViewStatementResponse response, ViewStatementRequest request)
        {
            var communications = statementService.GetCommunications(request.GetProvider.NeptuneCustNo);
            var plans = statementService.GetParticipantPlans(new ParticipantPlanRequest()
            {
                SS_IdentTable = configuration["application:sSS_IdentTable"],
                Part_id = request.Ident.PART_ID,
                ProvId = new string(request.GetProvider.ProvID),
                UID = request.UID,
                Plannum = request.Plan_num
            });

            foreach (var planItem in plans)
            {
                foreach (var citem in communications)
                {
                    try
                    {
                        var statements = statementService.GetParticipantStatements(new ParticipantStatementRequest()
                        {
                            UID = request.UID,
                            SS_IdentTable = configuration["application:sSS_IdentTable"],
                            AssetRetention = request.GetProvider.AssetRetention,
                            Part_id = request.Ident.PART_ID,
                            Plan_num = planItem.plan_num,
                            Provid = new string(request.GetProvider.ProvID),
                            SelectedViewType = request.ViewType,
                            CommunicationTypeCD = citem.CommunicationTypeCD
                        });

                        var blockItem = new Block();
                        response.BlockList.Add(blockItem);
                        blockItem.Description = citem.Descrip;
                        blockItem.PlanName = planItem.plan_plan_name;

                        foreach (var sitem in statements)
                        {
                            if (sitem.batch)
                            {
                                var sFile = $"{new string(request.GetProvider.ProvID)}\\{sitem.rpt_date.ToString("yyyymmdd")}\\{sitem.file_name}";
                                if (fileService.Exists(FileStoreType.PDF_Path, sFile))
                                {
                                    var queryString = System.Web.HttpUtility.ParseQueryString(string.Empty);

                                    queryString.Add(UtilityController.PartialFileNameConstant, sFile);
                                    queryString.Add(UtilityController.StoreTypeConstant, FileStoreType.PDF_Path.ToString());

                                    blockItem.List.Add(new PDF()
                                    {
                                        ButtonText = DecideButtonText(request.GetProvider,request.ViewType,sitem),
                                        DownloadQuery = queryString.ToString()
                                    });
                                }
                            }
                            else if (!sitem.IsSmart)
                            {
                                var sContentDate = sitem.rpt_date.ToString("MM/dd/yyyy");
                                var sFileName = string.Empty;
                                var sFilePath = string.Empty;
                                var sLinkText = string.Empty;

                                if (new int[] { 1, 2, 3 }.Contains(citem.CommunicationTypeCD))
                                    sFileName = $"{new string(request.GetProvider.ProvID).Trim()}~{planItem.plan_num.Trim()}~{request.UID}.pdf";
                                else
                                {
                                    sFileName = (sitem.file_name ?? "").Trim();
                                    var sSecurityString = $"{new string(request.GetProvider.ProvID).Trim()}~{planItem.plan_num}~{request.UID}";
                                }
                                switch (citem.Scope)
                                {
                                    case "PROVIDER":
                                        sFilePath = $"{new string(request.GetProvider.ProvID).Trim()}\\{sFileName}";
                                        break;

                                    case "INDIVIDUAL":
                                    default:
                                        sFilePath = $"{new string(request.GetProvider.ProvID).Trim()}\\{sitem.rpt_date.ToString("yyyyMMdd")}\\{planItem.plan_num.Trim()}\\{sFileName}";
                                        break;
                                }

                                if (!request.GetProvider.AssetRetention)
                                    sLinkText = sContentDate;
                                else
                                {
                                    if (request.ViewType != ViewTypeEnum.Admin)
                                        sLinkText = sContentDate;
                                    else
                                    {
                                        if (sitem.platform > 100)
                                            sLinkText = $"{sContentDate} - Agent Version";
                                        else
                                            sLinkText = $"{sContentDate} - Participant Version";
                                    }
                                }

                                if (fileService.Exists(FileStoreType.IndividualPDF_Path, sFilePath))
                                {
                                    var queryString = System.Web.HttpUtility.ParseQueryString(string.Empty);

                                    queryString.Add(UtilityController.PartialFileNameConstant, sFilePath);
                                    queryString.Add(UtilityController.StoreTypeConstant, FileStoreType.IndividualPDF_Path.ToString());

                                    blockItem.List.Add(new PDF()
                                    {
                                        ButtonText = DecideButtonText(request.GetProvider, request.ViewType, sitem, true),
                                        DownloadQuery = queryString.ToString()
                                    });
                                }
                            }
                            else
                            {
                                blockItem.List.Add(new PDF()
                                {
                                    ButtonText = DecideButtonText(request.GetProvider, request.ViewType, sitem, true)
                                });
                            }
                        }
                    }
                    catch { throw; }
                }
            }
        }

        public string DecideButtonText(Provider provider, ViewTypeEnum viewType, ParticipantStatement sitem, bool canHaveCustomButtonText = false)
        {
            if (!provider.AssetRetention)
            {
                if (canHaveCustomButtonText && provider.HasCustomPDFButtonText)
                    return (provider.CustomPDFButtonText ?? "").Trim();

                return $"{sitem.rpt_date.ToString("MM/dd/yyyy")}";
            }
            else
            {
                if (viewType != ViewTypeEnum.Admin)
                    return $"{sitem.rpt_date.ToString("MM/dd/yyyy")}";
                else
                {
                    if (sitem.platform > 100)
                        return $"{sitem.rpt_date.ToString("MM/dd/yyyy")} - Agent Version";
                    else
                        return $"{sitem.rpt_date.ToString("MM/dd/yyyy")} - Participant Version";
                }
            }
        }
    }

    public class ViewStatementRequestAdmin
    {
        public string UID { get; set; }
        public string VirtualDir { get; set; }
    }

    public class ViewStatementRequestParticipant
    {
        public string VirtualDir { get; set; }
        public int ParticipantId { get; set; }
    }

    public class ViewStatementRequestSponsor
    {
        public int ProviderId { get; set; }
        public int SpadId { get; set; }
        public string UID { get; set; }
    }

    public class ViewStatementRequest
    {
        public string UID { get; set; }
        public SSIdentPartID Ident { get; set; }
        public eStatmentsDAC.BLL.Provider GetProvider { get; set; }
        public ViewTypeEnum ViewType { get; set; }
        public string Plan_num { get; set; } = string.Empty;
    }

    public interface IViewStatementResponse
    {
        bool HasPDFs { get; set; }
        string Header { get; set; }
        string LinkTitle { get; set; }
        string LinkMessage { get; set; }
        string Message { get; set; }
        List<Block> BlockList { get; set; }
    }
    public class ViewStatementResponse : IViewStatementResponse
    {
        public bool HasPDFs { get; set; }
        public string Header { get; set; } = string.Empty;
        public string LinkTitle { get; set; } = string.Empty;
        public string LinkMessage { get; set; } = string.Empty;
        public string Message { get; set; }
        public List<Block> BlockList { get; set; } = new List<Block>();
    }

    public class Block
    {
        public string PlanName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public List<PDF> List { get; set; } = new List<PDF>();
    }

    public class PDF
    {
        public string ButtonText { get; set; } = string.Empty;
        public string DownloadQuery { get; set; } = string.Empty;
    }
}
