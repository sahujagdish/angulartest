﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public class IsEditableResponse
    {
        public bool is_editable { get; set; }
        public string participant_UUID { get; set; }
    }
}
