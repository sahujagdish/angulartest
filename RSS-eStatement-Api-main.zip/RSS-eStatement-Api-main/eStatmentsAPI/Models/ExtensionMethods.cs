﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public static class ExtensionMethods
    {
        public static string TypeDescription(this TargetTypeEnum targetType)
        {
            switch (targetType)
            {
                case TargetTypeEnum.Administrator:
                    return LocalStringConstants.administrator;
                case TargetTypeEnum.Participant:
                    return LocalStringConstants.participant;
                case TargetTypeEnum.Sponsor:
                    return LocalStringConstants.sponAdministrator;
                default:
                    return string.Empty;
            }
        }

        public static string TypeDescription(this ModeTypeEnum targetType)
        {
            return targetType.ToString();
        }
    }
}
