﻿namespace eStatmentsAPI.Models
{
    public class StatementProcessor
    {
    }
}
