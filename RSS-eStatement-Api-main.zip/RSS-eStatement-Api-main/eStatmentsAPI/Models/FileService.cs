﻿using eStatmentsDAC.Classes;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public enum FileStoreType
    {
        DefaultFolder,
        IndividualPDF_Path,
        PDF_Path, //ColdFusion-Equivalent -> sPDF_Path
        AuditReportsDirPath,
        SummaryReportPath
    }

    public interface IFileService
    {
        bool Exists(FileStoreType fileStoreType, string partialFileName);
        public Tuple<bool, string> ExistsV2(FileStoreType fileStoreType, string partialFileName);
        byte[] ReadFileInBytes(FileStoreType fileStoreType, string partialFileName);
        string GenerateCSVFile<T>(List<T> data, string csvFieldNames);
        string GetRootPath(FileStoreType fileStoreType);
    }

    public class FileService : IFileService
    {
        IConfiguration configuration;
        CredentialCache credentialCache;

        public FileService(IConfiguration configuration)
        {
            this.configuration = configuration;
            FillNetworkCache();
        }

        public bool Exists(FileStoreType fileStoreType, string partialFileName)
        {
            var baseFolder = BaseFolder(fileStoreType);
            var qualifiedFile = $"{baseFolder.TrimEnd('\\')}\\{partialFileName.TrimStart('\\')}";
            return File.Exists(qualifiedFile);
        }

        public Tuple<bool, string> ExistsV2(FileStoreType fileStoreType, string partialFileName)
        {
            var baseFolder = BaseFolder(fileStoreType);
            var qualifiedFile = $"{baseFolder.TrimEnd('\\')}\\{partialFileName.TrimStart('\\')}";
            return new Tuple<bool, string>(File.Exists(qualifiedFile), qualifiedFile);
        }

        public byte[] ReadFileInBytes(FileStoreType fileStoreType, string partialFileName)
        {
            var baseFolder = BaseFolder(fileStoreType);
            var qualifiedFile = $"{baseFolder.TrimEnd('\\')}\\{partialFileName.TrimStart('\\')}";

            byte[] byteArray = System.IO.File.ReadAllBytes(qualifiedFile);
            return byteArray;
        }

        public string GenerateCSVFile<T>(List<T> data, string csvFieldNames)
        {
            Dictionary<string, PropertyInfo> dic = new Dictionary<string, PropertyInfo>();
            var properties = typeof(T).GetProperties();
            foreach (var item in properties)
            {
                var map = item.GetCustomAttribute<MapAttribute>();
                if (map == null) continue;

                dic.Add(map.Name, item);
            }

            List<string> values = new List<string>();
            var cols = csvFieldNames.Split(',', StringSplitOptions.RemoveEmptyEntries);
            StringBuilder builder = new StringBuilder();
            builder.AppendLine(csvFieldNames);

            foreach (var item in data)
            {
                foreach (var citem in cols)
                    values.Add((dic[citem].GetValue(item) ?? string.Empty).ToString());

                builder.AppendLine(string.Join(',', values));
                values.Clear();
            }

            var fileData = builder.ToString();
            return fileData;
        }

        private string BaseFolder(FileStoreType fileStoreType)
        {
            var baseFolder = string.Empty;
            var location = configuration["application:SharedLocation"];
            switch (fileStoreType)
            {
                case FileStoreType.PDF_Path:
                case FileStoreType.IndividualPDF_Path:
                case FileStoreType.AuditReportsDirPath:
                case FileStoreType.SummaryReportPath:
                    baseFolder = configuration[$"application:{fileStoreType.ToString()}"];
                    break;
                case FileStoreType.DefaultFolder:
                default:
                    baseFolder = configuration[fileStoreType.ToString()];
                    break;
            }
            return $"{location.TrimEnd('\\')}\\{baseFolder.TrimStart('\\')}";
        }

        public void FillNetworkCache()
        {
            var location = configuration["application:SharedLocation"];
            var userName = configuration["application:username"];
            var password= configuration["application:password"];
            NetworkCredential theNetworkCredential = new NetworkCredential(userName, password);
            credentialCache = new CredentialCache();
            credentialCache.Add(new Uri(location), "Basic", theNetworkCredential);
        }

        public string GetRootPath(FileStoreType fileStoreType)
        {
            return BaseFolder(fileStoreType);
        }
    }
}
