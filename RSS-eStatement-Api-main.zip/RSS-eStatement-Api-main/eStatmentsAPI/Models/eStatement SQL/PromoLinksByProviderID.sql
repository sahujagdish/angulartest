use eStatement;
go



-- get Promo link with ProviderID
DROP procedure dbo.eStatement_proc_GetPromoLinksByProviderID ;
go

create procedure dbo.eStatement_proc_GetPromoLinksByProviderID 
@ProviderID int
as
	SELECT * FROM PromoLinks WHERE ProviderID = @ProviderID;	
go
