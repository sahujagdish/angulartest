use eStatement;
go

--Should run only once
---**************************************************************************************************************************************
--ALTER TABLE [dbo].[teProviderAdminLinks] ADD PRIMARY KEY ([ProviderAdminLinksId]);
---**************************************************************************************************************************************
--primary key column 'tdAdminLinksId' was added into tdAdminLinks table. Latter it was deleted. This operation is performed and verified on Dev [10.224.86.23] and QA [10.226.102.135] DB.
----ALTER TABLE [dbo].[tdAdminLinks] ADD tdAdminLinksId INT IDENTITY(1,1)
----ALTER TABLE [dbo].[tdAdminLinks] ADD PRIMARY KEY (tdAdminLinksId);
---**************************************************************************************************************************************
--ALTER TABLE [dbo].[teAdminProfile] ADD PRIMARY KEY ([ProfileId]);

---**************************************************************************************************************************************
---**************************************************************************************************************************************
---**************************************************************************************************************************************

--can be run multiple times



-- get sample link with ProviderID
DROP procedure dbo.eStatement_proc_GetSampleLinkByProviderID ;
go

create procedure dbo.eStatement_proc_GetSampleLinkByProviderID 
@ProviderID int
as
	SELECT * FROM SampleLinks WHERE ProviderID = @ProviderID;	
go





-- get Promo link with ProviderID
DROP procedure dbo.eStatement_proc_GetPromoLinksByProviderID ;
go

create procedure dbo.eStatement_proc_GetPromoLinksByProviderID 
@ProviderID int
as
	SELECT * FROM PromoLinks WHERE ProviderID = @ProviderID;	
go





-- get FaqText with ProviderID

DROP procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] 
@ProviderID int
as
	SELECT * FROM FaqText WHERE ProviderID = @ProviderID;	
go




-- get PromoText
DROP procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] 
@ProviderID int
as
	SELECT * FROM PromoText WHERE ProviderID = @ProviderID;	
go



--ProvAdminLinks with providerId
DROP procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] 
@ProviderID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @ProviderID;	
go

--ProvAdminLinks with ProviderId and LinkID
DROP procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderIDandLinkID] ;
go

create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderIDandLinkID] 
@PRAD_ProviderID int,
@PRAD_LinkID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @PRAD_ProviderID and PRAD_LinkID=@PRAD_LinkID;	
go




--						teProviderCommunications
--geting teProviderCommunications using providerid
DROP procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] 
@ProviderID int
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID;	
go

--geting teProviderCommunications using providerid and CommunicationTypeCD
DROP procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderIDandCommunicationTypeCD] ;
go

create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderIDandCommunicationTypeCD] 
@ProviderID int,
@CommunicationTypeCD smallint
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID and CommunicationTypeCD=@CommunicationTypeCD;	
go


--  SAVING teProviderCommunications
DROP PROCEDURE [dbo].[eStatement_proc_PostteProviderCommunications];
go

create procedure [dbo].[eStatement_proc_PostteProviderCommunications]
@ProviderID int ,
@CommunicationTypeCD smallint ,
@DisplayOrder smallint

as
BEGIN
declare @maxCommunicationTypeCD smallint
	SELECT @maxCommunicationTypeCD =MAX(ProviderCommunicationTypeCD)  FROM teProviderCommunications;
	SET @maxCommunicationTypeCD= @maxCommunicationTypeCD+1;
	INSERT INTO teProviderCommunications (ProviderCommunicationTypeCD,CommunicationTypeCD, ProviderID, DisplayOrder) VALUES (@maxCommunicationTypeCD,@CommunicationTypeCD,@ProviderID,@DisplayOrder);  

END;
go



-- procedure AboutText
DROP procedure dbo.eStatement_proc_DefaultAboutTextByProviderID ;
go

create procedure dbo.eStatement_proc_AboutTextByProviderID 
@ProviderID int
as
	SELECT * FROM AboutText WHERE ProviderID = @ProviderID;	
go




-- view tdCommunication
DROP procedure dbo.eStatement_proc_GettdCommunications;
go

create procedure dbo.eStatement_proc_CommunicationTypeCD 
as
	SELECT CommunicationTypeCD , Descrip FROM tdCommunications;	
go

--	aboutText Insert
DROP procedure [dbo].[eStatement_proc_saveAboutText] ;
go

create procedure  [dbo].[eStatement_proc_saveAboutText]  
@AboutOrder int,
@AboutHeader varchar(100),
@AboutBody varchar(2000),
@ProviderID int,
@Active  bit

as
--insert into abouttext(aboutorder,aboutheader,aboutbody,providerid,active)
	insert into abouttext(AboutOrder,AboutHeader,AboutBody,ProviderID,Active)
	values(@AboutOrder,@AboutHeader,@AboutBody,@ProviderID,@Active);	
go



-- view view_GettdCommunicationsScope

DROP procedure dbo.eStatement_proc_GetScopetdCommunicationsScope;
go

create procedure dbo.eStatement_proc_GetScopetdCommunicationsScope 
as
	SELECT DISTINCT Scope FROM tdCommunications;	
go


--  SAVING tdCOMMUNICATION
DROP PROCEDURE dbo.eStatement_proc_saveCommunicationTypeCD;
go

create procedure dbo.eStatement_proc_saveCommunicationTypeCD 
@Descrip tdCommunications.Descrip,
@Scope varchar(10)
as
BEGIN
declare @count int
	SELECT @count=COUNT(*) FROM tdCommunications WHERE Descrip=@Descrip;
	if (@count=0) 
		BEGIN
			INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
			--SELECT @maxCommunicationTypeCD =MAX(CommunicationTypeCD)  FROM tdCommunications;
			--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) VALUES (@maxCommunicationTypeCD, @Descrip,@Scope);
		END
		
--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
END;
go


-- View getNameProviderID

DROP view dbo.eStatement_proc_getNameProviderID ;
go

create view dbo.ebn_proc_getClientCodes 
as
	SELECT ProviderID,Name FROM Provider ORDER by  Name;
go


-- PROCEDURE getMaxProviderID
DROP PROCEDURE dbo.eStatement_proc_getMaxProviderID ;
go

create PROCEDURE dbo.eStatement_proc_getMaxProviderID
@ProviderID Provider.ProviderID out
as
	SELECT @ProviderID=MAX( ProviderID) FROM Provider;
	return ProviderID
go


-- PROCEDURE getMaxProviderCommunicationTypeCD
DROP PROCEDURE dbo.eStatement_proc_getMaxProviderCommunicationTypeCD ;
go

create PROCEDURE dbo.eStatement_proc_getMaxProviderCommunicationTypeCD
@ProviderCommunicationTypeCD teProviderCommunications.ProviderCommunicationTypeCD out
as
	SELECT @ProviderCommunicationTypeCD= MAX(ProviderCommunicationTypeCD) FROM teProviderCommunications;
go

-- PROCEDURE qGetProviderCommunications
DROP PROCEDURE dbo.eStatement_proc_qGetProviderCommunications ;
go

create PROCEDURE dbo.eStatement_proc_qGetProviderCommunications
@ProviderID int
as
	SELECT tdCommunications.CommunicationTypeCD, tdCommunications.Descrip,teProviderCommunications.DisplayOrder
		FROM teProviderCommunications, tdCommunications 
		WHERE teProviderCommunications.CommunicationTypeCD = tdCommunications.CommunicationTypeCD 
			AND teProviderCommunications.ProviderID = @ProviderID 
			ORDER BY teProviderCommunications.DisplayOrder
go




DROP VIEW dbo.ebn_view_getClientCodes;
go

create view dbo.ebn_view_getClientCodes
as
SELECT sc.specialCodeID, sc.SpecialCode ,providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID
go
----------------------------------------------------------------------
--IF OBJECT_ID('ebn_proc_getClientCodes', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getClientCodes;
go

create procedure dbo.ebn_proc_getClientCodes @providerID  uniqueidentifier
as
SELECT sc.specialCodeID, sc.SpecialCode , providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID
	AND providerID = @providerID 
ORDER by  sc.SpecialCode
go
---**************************************************************************************************************************************


--IF OBJECT_ID('dbo.ebn_view_getClientContent', 'U') IS NOT NULL
DROP VIEW dbo.ebn_view_getClientContent;
go


create view dbo.ebn_view_getClientContent
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID	AND ct.contentCategoryID = cc.ContentCategoryID
go

----------------------------------------------------------------------

--IF OBJECT_ID('dbo.ebn_proc_getClientContent', 'U') IS NOT NULL
DROP procedure dbo.ebn_proc_getClientContent;
go


create procedure dbo.ebn_proc_getClientContent  @providerID uniqueidentifier
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID
	AND pct.providerID = @providerID 
	AND ct.contentCategoryID = cc.ContentCategoryID
ORDER by  ct.description
go

---**************************************************************************************************************************************

--IF OBJECT_ID('dbo.ebn_view_getContentTypes', 'U') IS NOT NULL
DROP VIEW dbo.ebn_view_getContentTypes;
go

create view dbo.ebn_view_getContentTypes 
as
SELECT DISTINCT ct.contentID,ct.description,ct.fileName,cc.name
FROM tdContentTypes ct, tdContentCategories cc
WHERE ct.contentCategoryID = cc.ContentCategoryID
go
--ORDER by ct.description

----------------------------------------------------------------------

--IF OBJECT_ID('dbo.ebn_proc_rcPermissions', 'U') IS NOT NULL
DROP procedure dbo.ebn_proc_rcPermissions;
go

create procedure dbo.ebn_proc_rcPermissions  @providerID uniqueidentifier
as
SELECT	SUM(PERMISSIONS) as PERMISSIONS
	FROM	TEPROVIDERADMINLINKS PAL INNER JOIN 
			TDADMINLINKS AL ON AL.LINKID = PAL.LINKID
	WHERE	PAL.providerID = @providerID
go

---**************************************************************************************************************************************
--IF OBJECT_ID('dbo.ebn_proc_ckProviderURLRoot', 'U') IS NOT NULL
DROP procedure  dbo.ebn_proc_ckProviderURLRoot;
go

--ckProviderURLRoot
create procedure dbo.ebn_proc_ckProviderURLRoot @providerID uniqueidentifier ,  @providerURLRoot varchar(30)
as
SELECT providerURLRoot, providerID
FROM dbo.teProvider
WHERE (providerURLRoot = @providerURLRoot)  AND (providerID != @providerID)	
go

---**************************************************************************************************************************************

--IF OBJECT_ID('ebn_proc_teProviderAdminLinksDeleteByProviderId', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderAdminLinksDeleteByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_teProviderAdminLinksDeleteByProviderId]
	@providerID  uniqueidentifier
AS
	DELETE FROM [dbo].[teProviderAdminLinks]
	WHERE
		[ProviderId] =@providerID
GO

---**************************************************************************************************************************************
--IF OBJECT_ID('ebn_proc_tdAdminLinksGetAll_withmyorder', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_tdAdminLinksGetAll_withmyorder;
go

CREATE PROCEDURE [dbo].[ebn_proc_tdAdminLinksGetAll_withmyorder]
AS
	SELECT	LINKID, DESCRIPTION, IMAGENAME, PERMISSIONS, FUSEACTION, PARENTLINKID,
			CASE PARENTLINKID 
				WHEN 0 THEN LINKID 
				ELSE PARENTLINKID
			END AS MYORDER
	FROM	TDADMINLINKS
	ORDER BY MYORDER
GO

---**************************************************************************************************************************************
--IF OBJECT_ID('ebn_proc_SelectteProviderAdminLinksByProviderId', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_SelectteProviderAdminLinksByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_SelectteProviderAdminLinksByProviderId]
	@providerID uniqueidentifier
AS

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ COMMITTED 

SELECT
	*
FROM [dbo].[teProviderAdminLinks]
WHERE
ProviderId = @providerID
GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_teProviderSpecialCodeDeleteByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderSpecialCodeDeleteByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_teProviderSpecialCodeDeleteByProviderId]
	@providerID  uniqueidentifier
AS

	DELETE FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID

GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getMaxProfileID]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getMaxProfileID;
go

CREATE PROCEDURE [dbo].[ebn_proc_getMaxProfileID]
as
SELECT	Max(ProfileId) as MaxProfileID
	FROM	teAdminProfile
	go
---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_view_getinfo]', 'U') IS NOT NULL
DROP view dbo.ebn_view_getinfo;
go

create view dbo.ebn_view_getinfo
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_SelectteProvider_Content_MappingByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_SelectteProvider_Content_MappingByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_SelectteProvider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
SELECT
	*
FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID
GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_delete_Provider_Content_MappingByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_delete_Provider_Content_MappingByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_delete_Provider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
DELETE FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID
GO
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getProviderContents]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getProviderContents;
go

CREATE PROCEDURE [dbo].[ebn_proc_getProviderContents]
	 @providerID uniqueidentifier
AS
SELECT distinct(tdContentTypes.ContentCategoryId), tdContentCategories.name
    FROM
    tdContentCategories
	INNER JOIN tdContentTypes on tdContentCategories.ContentCategoryId = tdContentTypes.ContentCategoryId
	INNER JOIN teProvider_ContentTypes on teProvider_ContentTypes.ContentID = tdContentTypes.ContentId
    WHERE   
    teProvider_ContentTypes.ProviderID =  @providerID
GO
---**************************************************************************************************************************************

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getinfo]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getinfo;
go

create proc dbo.ebn_proc_getinfo @providerID uniqueidentifier, @colid int 
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and IsActive = 1
        and displaylevel =  4
        and displaycol = @colid
		order by a.displayorder asc 
		go


---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getinfo_with_pid]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getinfo_with_pid;
go

create proc dbo.ebn_proc_getinfo_with_pid @providerID uniqueidentifier , @colid int , @pid int
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and parentid = @pid
        and IsActive = 1
        and displaylevel = 4
        and displaycol = @colid order by a.displayorder asc 
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_view_rsContentOptions]', 'U') IS NOT NULL
DROP view dbo.ebn_view_rsContentOptions;
go

create view dbo.ebn_view_rsContentOptions 
as
	SELECT	ct.name, pct.ContentID, pct.AllowDirectLinkingToFRC,pct.ProviderID
	FROM	teProvider_ContentTypes pct INNER JOIN tdContentTypes ct ON pct.ContentID = ct.ContentId
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsContentOptions_provider]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsContentOptions_provider ;
go

create proc dbo.ebn_proc_rsContentOptions_provider @providerID uniqueidentifier 
as

	SELECT	* from dbo.ebn_view_rsContentOptions  
	WHERE	ProviderID = @providerID
	ORDER BY ContentID
	go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsSpecialCodeID]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsSpecialCodeID;
go

create proc dbo.ebn_proc_rsSpecialCodeID @providerID uniqueidentifier , @scode int
as
	SELECT	*
	FROM	TEPROVIDERSPECIALCODE
	WHERE	PROVIDERID = @providerID
    AND SPECIALCODEID = @scode
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsVerifyClient]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsVerifyClient;
go

create proc dbo.ebn_proc_rsVerifyClient @providerID uniqueidentifier , @scode int
as
	SELECT	*
	FROM	FRCProviderKeys
	WHERE	PROVIDERID = @providerID
	go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getProductCodes]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getProductCodes;
go

create proc dbo.ebn_proc_getProductCodes
as
	SELECT productCode
	FROM tdContentTypes 
	ORDER by productCode
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getalltdAdminLinksGetAll]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getalltdAdminLinksGetAll;
go

create proc [dbo].[ebn_proc_getalltdAdminLinksGetAll]
as
select * from tdAdminLinks
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsGuideKeys]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsGuideKeys;
go

DROP type dbo.ebn_type_contentid;
go

CREATE TYPE [dbo].[ebn_type_contentid] AS TABLE(
    [contentId] [int] NULL
)
go 

CREATE PROCEDURE [dbo].[ebn_proc_rsGuideKeys]
(
   @idList ebn_type_contentid READONLY
)
AS
BEGIN

SELECT	ContentId, Name
	FROM	tdContentTypes
	WHERE	ContentId IN (SELECT contentId FROM @idList) 
	ORDER BY ContentId
END
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_view_rsContents]', 'U') IS NOT NULL
DROP view dbo.ebn_view_rsContents;
go

create view dbo.ebn_view_rsContents
as
	SELECT		ct.FileName, ct.Name, ct.ProductCode, p.ProviderID
	FROM		tdContentTypes ct Inner Join
				teProvider_ContentTypes pct on ct.ContentID = pct.contentID Inner Join
				teProvider p on pct.ProviderID = p.ProviderID
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_rsContents_provider]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsContents_provider;
go

create proc [dbo].[ebn_proc_rsContents_provider] @providerID uniqueidentifier 
as
	SELECT	*  FROM	dbo.ebn_view_rsContents  WHERE	ProviderID = @providerID
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_qGetContentTypes]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_qGetContentTypes;
go

create proc [dbo].[ebn_proc_qGetContentTypes]
as
SELECT    Name, ProductCode
	FROM      tdContentTypes
	where FileName LIKE '%#sDestinationProviderCustomerNumber#%' or Name LIKE 'RC #sDestinationProvider#%'
	ORDER By  ContentID

go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_providerneptune]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_providerneptune;
go

create proc [dbo].[ebn_proc_providerneptune]
@neptuneNo varchar(12) 
as
select ProviderId, Name from  TEPROVIDER where 
HASFRC = 1 AND ISACTIVE = 1 
AND NeptuneCustNo != @neptuneNo 
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_teProviderSpecialCodeByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderSpecialCodeByProviderId;
go

CREATE PROCEDURE [dbo].ebn_proc_teProviderSpecialCodeByProviderId
	@providerID  uniqueidentifier
AS

	select * FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID

GO
