use eStatement;
go

--geting teProviderCommunications using providerid
DROP procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] 
@ProviderID int
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID;	
go
