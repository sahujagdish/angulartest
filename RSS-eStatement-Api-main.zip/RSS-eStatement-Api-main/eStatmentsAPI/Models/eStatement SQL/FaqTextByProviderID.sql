use eStatement;
go

-- get FaqText with ProviderID

DROP procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] 
@ProviderID int
as
	SELECT * FROM FaqText WHERE ProviderID = @ProviderID;	
go