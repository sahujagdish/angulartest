use eStatement;
go


-- PROCEDURE getMaxProviderID
DROP PROCEDURE dbo.eStatement_proc_getMaxProviderID ;
go

create PROCEDURE dbo.eStatement_proc_getMaxProviderID
@ProviderID Provider.ProviderID out
as
	SELECT @ProviderID=MAX( ProviderID) FROM Provider;
	return ProviderID
go
