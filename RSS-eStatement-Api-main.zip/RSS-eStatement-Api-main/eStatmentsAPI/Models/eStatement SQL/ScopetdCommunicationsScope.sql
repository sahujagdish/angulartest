use eStatement;
go


-- view view_GettdCommunicationsScope

DROP procedure dbo.eStatement_proc_GetScopetdCommunicationsScope;
go

create procedure dbo.eStatement_proc_GetScopetdCommunicationsScope 
as
	SELECT DISTINCT Scope FROM tdCommunications;	
go
