use eStatement;
go


-- view tdCommunication
DROP procedure dbo.eStatement_proc_GettdCommunications;
go

create procedure dbo.eStatement_proc_CommunicationTypeCD 
as
	SELECT CommunicationTypeCD , Descrip FROM tdCommunications;	
go