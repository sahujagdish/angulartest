use eStatement;
go


-- View getNameProviderID

DROP view dbo.eStatement_proc_getNameProviderID ;
go

create view dbo.ebn_proc_getClientCodes 
as
	SELECT ProviderID,Name FROM Provider ORDER by  Name;
go
