use eStatement;
go



--ProvAdminLinks with providerId
DROP procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] 
@ProviderID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @ProviderID;	
go
