use eStatement;
go

-- get sample link with ProviderID
DROP procedure dbo.eStatement_proc_GetSampleLinkByProviderID ;
go

create procedure dbo.eStatement_proc_GetSampleLinkByProviderID 
@ProviderID int
as
	SELECT * FROM SampleLinks WHERE ProviderID = @ProviderID;	
go
