use eStatement;
go


-- get PromoText
DROP procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] 
@ProviderID int
as
	SELECT * FROM PromoText WHERE ProviderID = @ProviderID;	
go