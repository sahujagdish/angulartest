use eStatement;
go


--  SAVING tdCOMMUNICATION
DROP PROCEDURE dbo.eStatement_proc_saveCommunicationTypeCD;
go

create procedure dbo.eStatement_proc_saveCommunicationTypeCD 
@Descrip tdCommunications.Descrip,
@Scope varchar(10)
as
BEGIN
declare @count int
	SELECT @count=COUNT(*) FROM tdCommunications WHERE Descrip=@Descrip;
	if (@count=0) 
		BEGIN
			INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
			--SELECT @maxCommunicationTypeCD =MAX(CommunicationTypeCD)  FROM tdCommunications;
			--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) VALUES (@maxCommunicationTypeCD, @Descrip,@Scope);
		END
		
--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
END;
go