use eStatement;
go


-- procedure AboutText
DROP procedure dbo.eStatement_proc_DefaultAboutTextByProviderID ;
go

create procedure dbo.eStatement_proc_AboutTextByProviderID 
@ProviderID int
as
	SELECT * FROM AboutText WHERE ProviderID = @ProviderID;	
go
