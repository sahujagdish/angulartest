﻿using MMARDataApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public class ApprovalInformation
    {
        public Dictionary<int, string> proofDates { get; set; }
        public Dictionary<int, List<StatementReportFileType>> reportTypes { get; set; }
    }
}
