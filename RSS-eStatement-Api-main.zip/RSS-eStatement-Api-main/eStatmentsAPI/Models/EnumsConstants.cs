﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public enum TargetTypeEnum
    {
        Administrator,
        Participant,
        Sponsor
    }

    public enum ModeTypeEnum
    {
        add,
        reset
    }

    public class LocalStringConstants
    {
        public const string participant = "participant";
        public const string administrator = "administrator";
        public const string sponAdministrator = "sponAdministrator";
    }
}
