﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public class ChangePassword
    {
        public int UniqueId { get; set; }
        public string Current_pass { get; set; }
        public string New_pass { get; set; }
        public bool InitialLogin { get; set; }
        public TargetTypeEnum TargetType { get; set; }
    }
}
