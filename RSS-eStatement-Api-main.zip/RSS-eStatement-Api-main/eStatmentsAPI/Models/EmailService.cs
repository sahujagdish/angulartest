﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace eStatmentsAPI.Models
{
    public interface IEmailService
    {
        void SendNotificationChangeMail(NotificationChange change);
    }

    public class EmailService : IEmailService
    {
        IConfiguration configuration;
        public EmailService(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public void SendNotificationChangeMail(NotificationChange change)
        {
            var server = configuration["smtpserver"];
            SmtpClient client = new SmtpClient(server);
            client.Send(new MailMessage(
                "superstatement@dstsystems.com", 
                "superstatement@dstsystems.com",
                $"Server: {change.Server} - {change.SettingName} has {change.Action} {change.ProviderPlan} {change.EmailText} eNotification email text",
                $"<br><b>Server: {change.Server}</b> <br><br> {change.SettingName}  has {change.Action} {change.ProviderPlan} {change.EmailText} eNotification email text"));
        }
    }

    public class NotificationChange
    {
        public string Server { get; set; }
        public string SettingName { get; set; }
        public string Action { get; set; }
        public string ProviderPlan { get; set; }
        public string EmailText { get; set; }
    }
}
