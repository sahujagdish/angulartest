﻿using eStatmentsDAC.Classes;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Validation
{
    public class Participant_RequestValidator : FluentValidation.AbstractValidator<ParticipantRequest>
    {
        public Participant_RequestValidator()
        {
            RuleFor(x => x.providerID).NotEmpty();
        }
    }
}
