﻿using eStatmentsDAC.Classes;
using FluentValidation;

namespace eStatmentsAPI.Validation
{
    public class UpdateSponsorAdminRequestValidator : FluentValidation.AbstractValidator<UpdateSponsorAdminRequest>
    {
        public UpdateSponsorAdminRequestValidator()
        {
            RuleFor(x => x.SpadID).NotEmpty();
        }
    }
}
