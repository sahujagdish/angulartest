﻿using eStatmentsDAC.Classes;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Validation
{
    public class SearchParticipantRequestValidator : FluentValidation.AbstractValidator<SearchParticipantRequest>
    {
        public SearchParticipantRequestValidator()
        {
            RuleFor(x => x.ProviderID).NotEmpty();

            RuleFor(x => x.AdminID).Empty().When(x => x.SpadID != 0);
            RuleFor(x => x.AdminID).NotEmpty().When(x => x.SpadID == 0);
        }
    }
}
