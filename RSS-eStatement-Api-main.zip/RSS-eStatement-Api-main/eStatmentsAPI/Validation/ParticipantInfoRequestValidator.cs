﻿using eStatmentsDAC.Classes;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Validation
{
    public class ParticipantInfoRequestValidator : FluentValidation.AbstractValidator<ParticipantInfoRequest>
    {
        public ParticipantInfoRequestValidator()
        {
            RuleFor(x => x.providerid).NotEmpty();
        }
    }
}
