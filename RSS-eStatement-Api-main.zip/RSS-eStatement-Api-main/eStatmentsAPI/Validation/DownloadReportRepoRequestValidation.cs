﻿using eStatmentsAPI.Models;
using FluentValidation;
using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Validation
{
    public class DownloadReportRepoRequestValidation : FluentValidation.AbstractValidator<DownloadReportRepoRequest>
    {
        public DownloadReportRepoRequestValidation()
        {
            RuleFor(x => x.UID).NotNull().NotEmpty();
            RuleFor(x => x.ProviderId).NotEmpty().NotEqual(0);
            RuleFor(x => x.FileName).NotNull().NotEmpty();
            RuleFor(x => x.FileName).Must(x => x.Split('_').Length == 3);
        }
    }
}
