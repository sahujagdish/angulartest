﻿using eStatmentsDAC.Classes;
using FluentValidation;

namespace eStatmentsAPI.Validation
{
    public class SelectSponsorRequestValidator : FluentValidation.AbstractValidator<SelectSponsorRequest>
    {
        public SelectSponsorRequestValidator()
        {
            //RuleFor(x => x.SpadID).Empty().When(x => !string.IsNullOrEmpty(x.PlanNum) || x.SponID != 0);
            //RuleFor(x => x.SpadID).When(y=>y) .NotEmpty().When(x => string.IsNullOrEmpty(x.PlanNum) && x.SponID == 0);

            RuleFor(x => x.PlanNum).MaximumLength(10);
            RuleFor(x => x.SponName).MaximumLength(50);
            RuleFor(x => x.SponNum).MaximumLength(10);

            //SponName is not numm must have providerID.

        }
    }
}
