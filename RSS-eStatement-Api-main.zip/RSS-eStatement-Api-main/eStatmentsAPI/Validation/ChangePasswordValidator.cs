﻿using eStatmentsAPI.Models;
using FluentValidation;

namespace eStatmentsAPI.Validation
{
    public class ChangePasswordValidator : FluentValidation.AbstractValidator<ChangePassword> 
    {
        public ChangePasswordValidator()
        {
            RuleFor(x=>x.UniqueId).NotEmpty();
            RuleFor(x => x.New_pass).NotNull().NotEmpty();
            RuleFor(x => x.Current_pass).NotNull().NotEmpty();
        }
    }
}
