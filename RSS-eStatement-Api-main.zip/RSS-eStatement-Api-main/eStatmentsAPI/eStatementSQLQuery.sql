use eStatement;
go

--Should run only once
---**************************************************************************************************************************************
--ALTER TABLE [dbo].[teProviderAdminLinks] ADD PRIMARY KEY ([ProviderAdminLinksId]);
---**************************************************************************************************************************************
--primary key column 'tdAdminLinksId' was added into tdAdminLinks table. Latter it was deleted. This operation is performed and verified on Dev [10.224.86.23] and QA [10.226.102.135] DB.
----ALTER TABLE [dbo].[tdAdminLinks] ADD tdAdminLinksId INT IDENTITY(1,1)
----ALTER TABLE [dbo].[tdAdminLinks] ADD PRIMARY KEY (tdAdminLinksId);
---**************************************************************************************************************************************
--ALTER TABLE [dbo].[teAdminProfile] ADD PRIMARY KEY ([ProfileId]);

---**************************************************************************************************************************************
---**************************************************************************************************************************************
---**************************************************************************************************************************************

--can be run multiple times



-- get sample link with ProviderID
DROP procedure dbo.eStatement_proc_GetSampleLinkByProviderID ;
go

create procedure dbo.eStatement_proc_GetSampleLinkByProviderID 
@ProviderID int
as
	SELECT * FROM SampleLinks WHERE ProviderID = @ProviderID;	
go





-- get Promo link with ProviderID
DROP procedure dbo.eStatement_proc_GetPromoLinksByProviderID ;
go

create procedure dbo.eStatement_proc_GetPromoLinksByProviderID 
@ProviderID int
as
	SELECT * FROM PromoLinks WHERE ProviderID = @ProviderID;	
go





-- get FaqText with ProviderID

DROP procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetFaqTextByProviderID] 
@ProviderID int
as
	SELECT * FROM FaqText WHERE ProviderID = @ProviderID;	
go




-- get PromoText
DROP procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] 
@ProviderID int
as
	SELECT * FROM PromoText WHERE ProviderID = @ProviderID;	
go



--ProvAdminLinks with providerId
DROP procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderID] 
@ProviderID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @ProviderID;	
go

--ProvAdminLinks with ProviderId and LinkID
DROP procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderIDandLinkID] ;
go

create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderIDandLinkID] 
@PRAD_ProviderID int,
@PRAD_LinkID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @PRAD_ProviderID and PRAD_LinkID=@PRAD_LinkID;	
go




--						teProviderCommunications
--geting teProviderCommunications using providerid
DROP procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] ;
go

create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] 
@ProviderID int
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID;	
go

--geting teProviderCommunications using providerid and CommunicationTypeCD
DROP procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderIDandCommunicationTypeCD] ;
go

create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderIDandCommunicationTypeCD] 
@ProviderID int,
@CommunicationTypeCD smallint
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID and CommunicationTypeCD=@CommunicationTypeCD;	
go


--  SAVING teProviderCommunications
DROP PROCEDURE [dbo].[eStatement_proc_PostteProviderCommunications];
go

create procedure [dbo].[eStatement_proc_PostteProviderCommunications]
@ProviderID int ,
@CommunicationTypeCD smallint ,
@DisplayOrder smallint

as
BEGIN
declare @maxCommunicationTypeCD smallint
	SELECT @maxCommunicationTypeCD =MAX(ProviderCommunicationTypeCD)  FROM teProviderCommunications;
	SET @maxCommunicationTypeCD= @maxCommunicationTypeCD+1;
	INSERT INTO teProviderCommunications (ProviderCommunicationTypeCD,CommunicationTypeCD, ProviderID, DisplayOrder) VALUES (@maxCommunicationTypeCD,@CommunicationTypeCD,@ProviderID,@DisplayOrder);  

END;
go



-- procedure AboutText
DROP procedure dbo.eStatement_proc_DefaultAboutTextByProviderID ;
go

create procedure dbo.eStatement_proc_AboutTextByProviderID 
@ProviderID int
as
	SELECT * FROM AboutText WHERE ProviderID = @ProviderID;	
go




-- view tdCommunication
DROP procedure dbo.eStatement_proc_GettdCommunications;
go

create procedure dbo.eStatement_proc_CommunicationTypeCD 
as
	SELECT CommunicationTypeCD , Descrip FROM tdCommunications;	
go

--	aboutText Insert
DROP procedure [dbo].[eStatement_proc_saveAboutText] ;
go

create procedure  [dbo].[eStatement_proc_saveAboutText]  
@AboutOrder int,
@AboutHeader varchar(100),
@AboutBody varchar(2000),
@ProviderID int,
@Active  bit

as
--insert into abouttext(aboutorder,aboutheader,aboutbody,providerid,active)
	insert into abouttext(AboutOrder,AboutHeader,AboutBody,ProviderID,Active)
	values(@AboutOrder,@AboutHeader,@AboutBody,@ProviderID,@Active);	
go



-- view view_GettdCommunicationsScope

DROP procedure dbo.eStatement_proc_GetScopetdCommunicationsScope;
go

create procedure dbo.eStatement_proc_GetScopetdCommunicationsScope 
as
	SELECT DISTINCT Scope FROM tdCommunications;	
go


--  SAVING tdCOMMUNICATION
DROP PROCEDURE dbo.eStatement_proc_saveCommunicationTypeCD;
go

create procedure dbo.eStatement_proc_saveCommunicationTypeCD 
@Descrip tdCommunications.Descrip,
@Scope varchar(10)
as
BEGIN
declare @count int
	SELECT @count=COUNT(*) FROM tdCommunications WHERE Descrip=@Descrip;
	if (@count=0) 
		BEGIN
			INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
			--SELECT @maxCommunicationTypeCD =MAX(CommunicationTypeCD)  FROM tdCommunications;
			--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) VALUES (@maxCommunicationTypeCD, @Descrip,@Scope);
		END
		
--INSERT INTO tdCommunications (CommunicationTypeCD, Descrip, Scope) select max(CommunicationTypeCD ) ,  @Descrip,@Scope  from tdCommunications  
END;
go


-- View getNameProviderID

DROP view dbo.eStatement_proc_getNameProviderID ;
go

create view dbo.ebn_proc_getClientCodes 
as
	SELECT ProviderID,Name FROM Provider ORDER by  Name;
go


-- PROCEDURE getMaxProviderID
DROP PROCEDURE dbo.eStatement_proc_getMaxProviderID ;
go

create PROCEDURE dbo.eStatement_proc_getMaxProviderID
@ProviderID Provider.ProviderID out
as
	SELECT @ProviderID=MAX( ProviderID) FROM Provider;
	return ProviderID
go


-- PROCEDURE getMaxProviderCommunicationTypeCD
DROP PROCEDURE dbo.eStatement_proc_getMaxProviderCommunicationTypeCD ;
go

create PROCEDURE dbo.eStatement_proc_getMaxProviderCommunicationTypeCD
@ProviderCommunicationTypeCD teProviderCommunications.ProviderCommunicationTypeCD out
as
	SELECT @ProviderCommunicationTypeCD= MAX(ProviderCommunicationTypeCD) FROM teProviderCommunications;
go

-- PROCEDURE qGetProviderCommunications
DROP PROCEDURE dbo.eStatement_proc_qGetProviderCommunications ;
go

create PROCEDURE dbo.eStatement_proc_qGetProviderCommunications
@ProviderID int
as
	SELECT tdCommunications.CommunicationTypeCD, tdCommunications.Descrip,teProviderCommunications.DisplayOrder
		FROM teProviderCommunications, tdCommunications 
		WHERE teProviderCommunications.CommunicationTypeCD = tdCommunications.CommunicationTypeCD 
			AND teProviderCommunications.ProviderID = @ProviderID 
			ORDER BY teProviderCommunications.DisplayOrder
go




DROP VIEW dbo.ebn_view_getClientCodes;
go

create view dbo.ebn_view_getClientCodes
as
SELECT sc.specialCodeID, sc.SpecialCode ,providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID
go
----------------------------------------------------------------------
--IF OBJECT_ID('ebn_proc_getClientCodes', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getClientCodes;
go

create procedure dbo.ebn_proc_getClientCodes @providerID  uniqueidentifier
as
SELECT sc.specialCodeID, sc.SpecialCode , providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID
	AND providerID = @providerID 
ORDER by  sc.SpecialCode
go
---**************************************************************************************************************************************


--IF OBJECT_ID('dbo.ebn_view_getClientContent', 'U') IS NOT NULL
DROP VIEW dbo.ebn_view_getClientContent;
go


create view dbo.ebn_view_getClientContent
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID	AND ct.contentCategoryID = cc.ContentCategoryID
go

----------------------------------------------------------------------

--IF OBJECT_ID('dbo.ebn_proc_getClientContent', 'U') IS NOT NULL
DROP procedure dbo.ebn_proc_getClientContent;
go


create procedure dbo.ebn_proc_getClientContent  @providerID uniqueidentifier
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID
	AND pct.providerID = @providerID 
	AND ct.contentCategoryID = cc.ContentCategoryID
ORDER by  ct.description
go

---**************************************************************************************************************************************

--IF OBJECT_ID('dbo.ebn_view_getContentTypes', 'U') IS NOT NULL
DROP VIEW dbo.ebn_view_getContentTypes;
go

create view dbo.ebn_view_getContentTypes 
as
SELECT DISTINCT ct.contentID,ct.description,ct.fileName,cc.name
FROM tdContentTypes ct, tdContentCategories cc
WHERE ct.contentCategoryID = cc.ContentCategoryID
go
--ORDER by ct.description

----------------------------------------------------------------------

--IF OBJECT_ID('dbo.ebn_proc_rcPermissions', 'U') IS NOT NULL
DROP procedure dbo.ebn_proc_rcPermissions;
go

create procedure dbo.ebn_proc_rcPermissions  @providerID uniqueidentifier
as
SELECT	SUM(PERMISSIONS) as PERMISSIONS
	FROM	TEPROVIDERADMINLINKS PAL INNER JOIN 
			TDADMINLINKS AL ON AL.LINKID = PAL.LINKID
	WHERE	PAL.providerID = @providerID
go

---**************************************************************************************************************************************
--IF OBJECT_ID('dbo.ebn_proc_ckProviderURLRoot', 'U') IS NOT NULL
DROP procedure  dbo.ebn_proc_ckProviderURLRoot;
go

--ckProviderURLRoot
create procedure dbo.ebn_proc_ckProviderURLRoot @providerID uniqueidentifier ,  @providerURLRoot varchar(30)
as
SELECT providerURLRoot, providerID
FROM dbo.teProvider
WHERE (providerURLRoot = @providerURLRoot)  AND (providerID != @providerID)	
go

---**************************************************************************************************************************************

--IF OBJECT_ID('ebn_proc_teProviderAdminLinksDeleteByProviderId', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderAdminLinksDeleteByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_teProviderAdminLinksDeleteByProviderId]
	@providerID  uniqueidentifier
AS
	DELETE FROM [dbo].[teProviderAdminLinks]
	WHERE
		[ProviderId] =@providerID
GO

---**************************************************************************************************************************************
--IF OBJECT_ID('ebn_proc_tdAdminLinksGetAll_withmyorder', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_tdAdminLinksGetAll_withmyorder;
go

CREATE PROCEDURE [dbo].[ebn_proc_tdAdminLinksGetAll_withmyorder]
AS
	SELECT	LINKID, DESCRIPTION, IMAGENAME, PERMISSIONS, FUSEACTION, PARENTLINKID,
			CASE PARENTLINKID 
				WHEN 0 THEN LINKID 
				ELSE PARENTLINKID
			END AS MYORDER
	FROM	TDADMINLINKS
	ORDER BY MYORDER
GO

---**************************************************************************************************************************************
--IF OBJECT_ID('ebn_proc_SelectteProviderAdminLinksByProviderId', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_SelectteProviderAdminLinksByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_SelectteProviderAdminLinksByProviderId]
	@providerID uniqueidentifier
AS

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ COMMITTED 

SELECT
	*
FROM [dbo].[teProviderAdminLinks]
WHERE
ProviderId = @providerID
GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_teProviderSpecialCodeDeleteByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderSpecialCodeDeleteByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_teProviderSpecialCodeDeleteByProviderId]
	@providerID  uniqueidentifier
AS

	DELETE FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID

GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getMaxProfileID]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getMaxProfileID;
go

CREATE PROCEDURE [dbo].[ebn_proc_getMaxProfileID]
as
SELECT	Max(ProfileId) as MaxProfileID
	FROM	teAdminProfile
	go
---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_view_getinfo]', 'U') IS NOT NULL
DROP view dbo.ebn_view_getinfo;
go

create view dbo.ebn_view_getinfo
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_SelectteProvider_Content_MappingByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_SelectteProvider_Content_MappingByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_SelectteProvider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
SELECT
	*
FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID
GO

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_delete_Provider_Content_MappingByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_delete_Provider_Content_MappingByProviderId;
go

CREATE PROCEDURE [dbo].[ebn_proc_delete_Provider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
DELETE FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID
GO
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getProviderContents]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_getProviderContents;
go

CREATE PROCEDURE [dbo].[ebn_proc_getProviderContents]
	 @providerID uniqueidentifier
AS
SELECT distinct(tdContentTypes.ContentCategoryId), tdContentCategories.name
    FROM
    tdContentCategories
	INNER JOIN tdContentTypes on tdContentCategories.ContentCategoryId = tdContentTypes.ContentCategoryId
	INNER JOIN teProvider_ContentTypes on teProvider_ContentTypes.ContentID = tdContentTypes.ContentId
    WHERE   
    teProvider_ContentTypes.ProviderID =  @providerID
GO
---**************************************************************************************************************************************

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getinfo]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getinfo;
go

create proc dbo.ebn_proc_getinfo @providerID uniqueidentifier, @colid int 
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and IsActive = 1
        and displaylevel =  4
        and displaycol = @colid
		order by a.displayorder asc 
		go


---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_getinfo_with_pid]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getinfo_with_pid;
go

create proc dbo.ebn_proc_getinfo_with_pid @providerID uniqueidentifier , @colid int , @pid int
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and parentid = @pid
        and IsActive = 1
        and displaylevel = 4
        and displaycol = @colid order by a.displayorder asc 
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_view_rsContentOptions]', 'U') IS NOT NULL
DROP view dbo.ebn_view_rsContentOptions;
go

create view dbo.ebn_view_rsContentOptions 
as
	SELECT	ct.name, pct.ContentID, pct.AllowDirectLinkingToFRC,pct.ProviderID
	FROM	teProvider_ContentTypes pct INNER JOIN tdContentTypes ct ON pct.ContentID = ct.ContentId
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsContentOptions_provider]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsContentOptions_provider ;
go

create proc dbo.ebn_proc_rsContentOptions_provider @providerID uniqueidentifier 
as

	SELECT	* from dbo.ebn_view_rsContentOptions  
	WHERE	ProviderID = @providerID
	ORDER BY ContentID
	go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsSpecialCodeID]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsSpecialCodeID;
go

create proc dbo.ebn_proc_rsSpecialCodeID @providerID uniqueidentifier , @scode int
as
	SELECT	*
	FROM	TEPROVIDERSPECIALCODE
	WHERE	PROVIDERID = @providerID
    AND SPECIALCODEID = @scode
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsVerifyClient]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsVerifyClient;
go

create proc dbo.ebn_proc_rsVerifyClient @providerID uniqueidentifier , @scode int
as
	SELECT	*
	FROM	FRCProviderKeys
	WHERE	PROVIDERID = @providerID
	go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getProductCodes]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getProductCodes;
go

create proc dbo.ebn_proc_getProductCodes
as
	SELECT productCode
	FROM tdContentTypes 
	ORDER by productCode
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_getalltdAdminLinksGetAll]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_getalltdAdminLinksGetAll;
go

create proc [dbo].[ebn_proc_getalltdAdminLinksGetAll]
as
select * from tdAdminLinks
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_rsGuideKeys]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsGuideKeys;
go

DROP type dbo.ebn_type_contentid;
go

CREATE TYPE [dbo].[ebn_type_contentid] AS TABLE(
    [contentId] [int] NULL
)
go 

CREATE PROCEDURE [dbo].[ebn_proc_rsGuideKeys]
(
   @idList ebn_type_contentid READONLY
)
AS
BEGIN

SELECT	ContentId, Name
	FROM	tdContentTypes
	WHERE	ContentId IN (SELECT contentId FROM @idList) 
	ORDER BY ContentId
END
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_view_rsContents]', 'U') IS NOT NULL
DROP view dbo.ebn_view_rsContents;
go

create view dbo.ebn_view_rsContents
as
	SELECT		ct.FileName, ct.Name, ct.ProductCode, p.ProviderID
	FROM		tdContentTypes ct Inner Join
				teProvider_ContentTypes pct on ct.ContentID = pct.contentID Inner Join
				teProvider p on pct.ProviderID = p.ProviderID
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_rsContents_provider]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_rsContents_provider;
go

create proc [dbo].[ebn_proc_rsContents_provider] @providerID uniqueidentifier 
as
	SELECT	*  FROM	dbo.ebn_view_rsContents  WHERE	ProviderID = @providerID
go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_qGetContentTypes]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_qGetContentTypes;
go

create proc [dbo].[ebn_proc_qGetContentTypes]
as
SELECT    Name, ProductCode
	FROM      tdContentTypes
	where FileName LIKE '%#sDestinationProviderCustomerNumber#%' or Name LIKE 'RC #sDestinationProvider#%'
	ORDER By  ContentID

go
---**************************************************************************************************************************************
--IF OBJECT_ID('[ebn_proc_providerneptune]', 'U') IS NOT NULL
DROP proc dbo.ebn_proc_providerneptune;
go

create proc [dbo].[ebn_proc_providerneptune]
@neptuneNo varchar(12) 
as
select ProviderId, Name from  TEPROVIDER where 
HASFRC = 1 AND ISACTIVE = 1 
AND NeptuneCustNo != @neptuneNo 
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[ebn_proc_teProviderSpecialCodeByProviderId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.ebn_proc_teProviderSpecialCodeByProviderId;
go

CREATE PROCEDURE [dbo].ebn_proc_teProviderSpecialCodeByProviderId
	@providerID  uniqueidentifier
AS

	select * FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID

GO
----------------------------------		Atanu 3/11/2021			estatement processing center



-- get Profiles  with ProviderID		"qGetProfiles"	spGetProfilesByProviderID
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetProfilesByProviderID')
    BEGIN
        DROP  Procedure spGetProfilesByProviderID
    END
 Go

create procedure dbo.spGetProfilesByProviderID 
@ProviderID int,
@Active bit
as
	select ProfileID, ProfileName
	from Profiles
	where ProviderID=@ProviderID and Active = @Active
	order by ProfileID
go

-- get Administrator  with ProviderID		"qGetAdministrator"	spGetAdministratorByProviderID

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetAdministratorByProviderID')
    BEGIN
        DROP  Procedure spGetAdministratorByProviderID
    END
 Go

create procedure dbo.spGetAdministratorByProviderID 
@ProviderID int,
@active bit,
@hasSensitivePlans bit
as
	if (@hasSensitivePlans=1)
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid, hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0
			order by control_name, fname
	END
	ELSE
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid,0 as hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0 order by control_name, fname
		END
go--


-- get Administrator  with administratorid and userid		"qGetUsername"

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetAdministratorByAdministratoridAndUserID')
    BEGIN
        DROP  Procedure spGetAdministratorByAdministratoridAndUserID
    END
 Go

create procedure dbo.spGetAdministratorByAdministratoridAndUserID 
@AdministratorID int,
@active bit,
@hasSensitivePlans bit
as
	if (@hasSensitivePlans=1)
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid, hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0
			order by control_name, fname
	END
	ELSE
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid,0 as hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0 order by control_name, fname
		END
go--


-- get other Administratorid and userid		"qGetUsername"
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetOtherAdministrator')
    BEGIN
        DROP  Procedure spGetOtherAdministrator
    END
 Go

create procedure dbo.spGetOtherAdministrator 
@AdministratorID int,
@UserID varchar(10)
as
		BEGIN
			select userid 
			from administrator
			where userid= @UserID   
				and administratorid <> @AdministratorID
		END
go


-- get  Administrator using userid		"qGetUsername"
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetAdministratorByUserID')
    BEGIN
        DROP  Procedure spGetAdministratorByUserID
    END
 Go

create procedure dbo.spGetAdministratorByUserID 
@UserID varchar(10)
as
		BEGIN
			select userid 
			from administrator
			where userid= @UserID   
		END
go


--													Staff Profile

-- get  active Profiles using @ProviderID		"qGetProfiles"	ProfileMaint.cfm line 6
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetActiveProfilesByProviderID')
    BEGIN
        DROP  Procedure spGetActiveProfilesByProviderID
    END
 Go

create procedure dbo.spGetActiveProfilesByProviderID 
@ProviderID int
as
		BEGIN
			select profileid as control_id, profilename as control_name, active, 0 AS Updated
			from Profiles
			where Active = 1 and providerid= @ProviderID
			order by control_name
		END
go



-- get  AdminLinks,ProvAdminLinks using @ProviderID		"qGetAllLinks"	ProfileMaint.cfm line 15
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetAdminLinks_ProvAdminLinksByProviderID')
    BEGIN
        DROP  Procedure spGetAdminLinks_ProvAdminLinksByProviderID
    END
 Go

create procedure dbo.spGetAdminLinks_ProvAdminLinksByProviderID 
@ProviderID int
as
		BEGIN
			SELECT AdminLinks.LinkOrder,AdminLinks.LinkText,AdminLinks.LinkID
			FROM AdminLinks,ProvAdminLinks
			WHERE AdminLinks.LinkID = ProvAdminLinks.PRAD_LinkID AND 
			ProvAdminLinks.PRAD_ProviderID = @ProviderID
		    AND AdminLinks.LinkText != 'Login'
            AND AdminLinks.LinkText !=  'Logout'
		END
go

-- get  ProfileLinks,ProvAdminLinks		"qGetLinks""	ProfileMaint.cfm line 43
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetProfileLinks_ProvAdminLinks')
    BEGIN
        DROP  Procedure spGetProfileLinks_ProvAdminLinks
    END
 Go

create procedure dbo.spGetProfileLinks_ProvAdminLinks 
@ProviderID int,
@control_id int,
@LinkID int
as
		BEGIN
			SELECT ProfileLinks.PRLI_LinkID
			FROM ProfileLinks,ProvAdminLinks
			WHERE ProvAdminLinks.PRAD_LinkID = ProfileLinks.PRLI_LinkID 
					and ProvAdminLinks.PRAD_ProviderID = @ProviderID
					and ProfileLinks.PRLI_ProfileID = @control_id
--removed					and ProfileLinks.PRLI_LinkID =  @LinkID
		END
go




-- delete  ProfileLinks			"qDeleteProfileLinks""	ProfileMaintAction.cfm line 47
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spDeleteProfileLinksByPRLI_ProfileID')
    BEGIN
        DROP  Procedure spDeleteProfileLinksByPRLI_ProfileID
    END
 Go

create procedure dbo.spDeleteProfileLinksByPRLI_ProfileID 
@control_id int
as
		BEGIN
			DELETE 
					FROM ProfileLinks
					WHERE PRLI_ProfileID = @control_id
		END
go


-- get max  Profiles			"qGetMaxProfileID""	ProfileMaintAction.cfm line 112
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetMaxProfileIDByProviderID')
    BEGIN
        DROP  Procedure spGetMaxProfileIDByProviderID
    END
 Go
 
create procedure dbo.spGetMaxProfileIDByProviderID 
@ProviderID int
as
		BEGIN
			SELECT MAX(profileID) as MaxProfileID
						FROM Profiles
						WHERE ProviderID =  @ProviderID
		END
go

-- qGetSponsorName Summary.cfm
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spGetSponsorName')
    BEGIN
        DROP  Procedure spGetSponsorName
    END
 Go
 
create procedure dbo.spGetSponsorName 
@SPON_ID int
as
		BEGIN
			SELECT SPON_Name
	FROM Sponsor
	WHERE SPON_ID = @SPON_ID
		END
go

-- Testing as Dhiraj Told
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sptest')
    BEGIN
        DROP  Procedure sptest
    END
 Go
 

create procedure dbo.sptest 
@sponsorActive char(1)       = ''
as
		BEGIN
			SELECT @sponsorActive;
		END
go
