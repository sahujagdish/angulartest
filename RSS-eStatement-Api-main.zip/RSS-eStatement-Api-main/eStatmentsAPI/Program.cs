using Common.Authorization;
using Common.Extensions;
using Common.Logger;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((x, configuration) => 
            {
                configuration.AddEncryptedAndJsonFiles(x.HostingEnvironment);
            })
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.ConfigureSentry<BaseSentryConfigurer>();
                webBuilder.UseStartup<Startup>();
            });
    }
}
