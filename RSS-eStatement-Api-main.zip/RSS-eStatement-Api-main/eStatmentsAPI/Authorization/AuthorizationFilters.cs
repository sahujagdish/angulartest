﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using static eStatmentsAPI.Authorization.ClaimDictionary;

namespace eStatmentsAPI.Authorization
{
    public class EstatementAuthorizeAttribute : TypeFilterAttribute
    {
        public EstatementAuthorizeAttribute(CLAIM_TYPES claimType, params CLAIM_VALUES[] claimValue)
            : base(typeof(EstatementAuthorizeFilter))
        {

            var _claimType = eStatementClaimTypes[claimType];
            var _claimVals =  claimValue.Select(c => new Claim(_claimType, eStatementClaimValues[c])).ToArray();

            Arguments = new object[] { _claimVals };
        }

    }

    public class EstatementAuthorizeFilter : IAuthorizationFilter
    {
        readonly Claim[] _claims;
        public CLAIM_VALUES EstatementRoles { get; set; }

        public EstatementAuthorizeFilter(Claim[] claims)
        {
            _claims = claims;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {

            foreach(var claim in _claims)
            {
                var hasClaim = context.HttpContext.User.Claims.Any(c => c.Type == claim.Type && c.Value == claim.Value);
                if (hasClaim)
                {
                    context.Result = null;
                    return;
                }
                context.Result = new ForbidResult();
            }
        }
    }

    public enum CLAIM_TYPES
    {
        ROLE
    }
    public enum CLAIM_VALUES
    {
        ADMIN,
        PARTICIPANTS,
        SPONSORS
    }

    public static class ClaimDictionary
    {       
        public static Dictionary<CLAIM_TYPES, string> eStatementClaimTypes = new Dictionary<CLAIM_TYPES, string>
        {
            {CLAIM_TYPES.ROLE, "user_roles" }
        };
        public static Dictionary<CLAIM_VALUES, string> eStatementClaimValues = new Dictionary<CLAIM_VALUES, string>
        {
            {CLAIM_VALUES.ADMIN, "admin" },
            {CLAIM_VALUES.PARTICIPANTS, "participant" },
            {CLAIM_VALUES.SPONSORS, "sponsor" }
        };
    }
}
