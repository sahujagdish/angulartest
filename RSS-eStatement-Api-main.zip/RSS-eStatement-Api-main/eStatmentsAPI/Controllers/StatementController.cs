﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsAPI.Models;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using MMARDataApi.Models;
using Common.Utilities;
using StatementReportFileType = MMARDataApi.Models.StatementReportFileType;
using Statements;
using MMApi.Utilities;
using StatementReportTypeAttribute = MMARDataApi.Models.StatementReportTypeAttribute;
using ProviderENotifySettings = MMARDataApi.Models.ProviderENotifySettings;
using PlanEnotifyOverrideType = MMARDataApi.Models.PlanEnotifyOverrideType;
using MMApi.Models;
using StatementsDAC.BLL;

namespace eStatmentsAPI.Controllers
{
    [Route("statement")]
    [ApiController]
    [Authorize]
    public class StatementController : ControllerBase
    {
        IStatementService statementService;
        IConfiguration configuration;
        IMailerService mailer;
        INotificationHelperService notificationHelperService;
        IViewStatementHelperService viewStatementHelperService;
        IMemoryCache _cache;

        public StatementController(IStatementService statementService, 
            IConfiguration configuration, 
            IMailerService mailerService,
            INotificationHelperService notificationHelperService,
            IViewStatementHelperService viewStatementHelperService,
            IMemoryCache cache)
        {
            this.viewStatementHelperService = viewStatementHelperService;
            this.notificationHelperService = notificationHelperService;
            this.statementService = statementService;
            mailer = mailerService;
            this.configuration = configuration;
            _cache = cache;
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("statement-list")]
        public ActionResult GetStatements(StatementRequest req)
        {
            try
            {
                var searchResult = statementService.GetStatements(req);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpPost("delete-extractplans")]
        public ActionResult DeleteExtractPlans(DeleteExtractPlansRequest deleteExtractPlansRequest)
        {
            try
            {
                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                SaveExtactDeletedPlansRequest requestDeleted = new SaveExtactDeletedPlansRequest();
                SaveExtactDeletedPlansRequestBody deletedBody = new SaveExtactDeletedPlansRequestBody
                {
                    extractId = deleteExtractPlansRequest.ApprovalId
                };

                deletedBody.DeletedPlanExteralIds = new ArrayOfString();
                deletedBody.DeletedPlanExteralIds.AddRange(deleteExtractPlansRequest.ExtractPlansToDelete);
                deletedBody.userId = deleteExtractPlansRequest.UserId.ToString();
                requestDeleted.Body = deletedBody;

                Task<SaveExtactDeletedPlansResponse> response = statementsSoap.SaveExtactDeletedPlansAsync(requestDeleted);

                var returnValue = statementService.DeleteExtractPlans(deleteExtractPlansRequest.ApprovalId);

                return Ok(returnValue);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }       

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpPost("delete-extract")]
        public ActionResult DeleteExtract(int approvalId, string deleteBy)
        {
            try
            {
                var returnValue = statementService.DeleteExtract(approvalId, deleteBy);

                return Ok(returnValue);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserReportList))]
        [HttpPost("approve")]
        public ActionResult Approve(int approvalId, string provId, int approvedBy)
        {
            try
            {
                //string result = string.Empty;
                //HttpResponseMessage response;

                //var path = configuration["MMAPI:basepath"] + string.Format(configuration["MMAPI:approveextract"], approvalId);
                //var access_token = HttpContext.Request.Headers["Authorization"].ToString();

                //using (var client = new HttpClient())
                //{
                //    var httpRequestMessage = new HttpRequestMessage
                //    {
                //        Method = System.Net.Http.HttpMethod.Get,
                //        RequestUri = new Uri(path),
                //        Headers =
                //        {
                //            { HttpRequestHeader.Authorization.ToString(), access_token },
                //            { HttpRequestHeader.Accept.ToString(), "application/json" },
                //            { HttpRequestHeader.ContentType.ToString(), "application/json" },
                //        }
                //    };

                //    response = client.SendAsync(httpRequestMessage).Result;
                //    result = response.Content.ReadAsStringAsync().Result;

                //    if (!response.IsSuccessStatusCode)
                //    {
                //        return StatusCode(StatusCodes.Status400BadRequest);
                //    }
                //}
                
                    StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();
                    ApproveExtractRequest request = new ApproveExtractRequest(approvalId);

                    ApproveExtractResponse response = statementsSoap.ApproveExtractAsync(request).Result;

                
                int updateResult = statementService.Approve(approvalId, provId, approvedBy);

                if (updateResult > 0)
                {
                    var info = statementService.GetApprovalInfo(approvalId, provId);

                    if (info.ApprovalEmail != "")
                    {

                        string superstatementEmail = System.IO.File.ReadAllText(@"EmailFormat\SuperstatementEmail.html");
                        superstatementEmail = superstatementEmail.Replace("[NAME]", info.ProviderName);
                        superstatementEmail = superstatementEmail.Replace("[PROVID]", provId.ToString());
                        superstatementEmail = superstatementEmail.Replace("[ZIP_FILENAME]", info.ZIP_FileName);
                        superstatementEmail = superstatementEmail.Replace("[PATH]", info.Path);
                        superstatementEmail = superstatementEmail.Replace("[APPROVED_DATE]", !info.DateApproved.HasValue ? "" : info.DateApproved.Value.ToString("MM/dd/yyyy HH:mm tt"));
                        string subjectSuperstatementEmail = "Test email - Statement Print Approval - " + info.ProviderName;
#if DEBUG
                        mailer.SendEmail(superstatementEmail, this.configuration.GetValue<string>(Constants.ToEmail), subjectSuperstatementEmail);
#else
                        mailer.SendEmail(superstatementEmail, info.ApprovalEmail, subjectSuperstatementEmail);
#endif
                        string clientEmail = System.IO.File.ReadAllText(@"EmailFormat\StatementApprovalEmailToClient.html");
                        clientEmail = clientEmail.Replace("[NAME]", info.ProviderName);
                        clientEmail = clientEmail.Replace("[PROVID]", provId.ToString());
                        clientEmail = clientEmail.Replace("[ZIP_FILENAME]", info.ZIP_FileName);
                        clientEmail = clientEmail.Replace("[PATH]", info.Path);
                        clientEmail = clientEmail.Replace("[APPROVED_DATE]", !info.DateApproved.HasValue ? "" : info.DateApproved.Value.ToString("MM/dd/yyyy HH:mm tt"));

                        string subjectClientEmail = "Test email - Statement Print Approval - " + info.ZIP_FileName;
#if DEBUG
                        mailer.SendEmail(clientEmail, this.configuration.GetValue<string>(Constants.ToEmail), subjectClientEmail);
#else
                        mailer.SendEmail(clientEmail, info.ApprovalEmail, subjectClientEmail);
#endif
                    }
                }

                return Ok(updateResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }       
       
        
        [HttpGet("enotification/{messageBoardID}")]        
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<GetResponse>>> GetEnotificationData(int messageBoardID,[FromQuery] string externalPlanId = "")
        {
            try
            {
                List<GetResponse> list = new List<GetResponse>();
                var controller = GetStatementController(_cache);
                ProviderENotifySettings providerENotifySettings;

                var providerResponse = controller.GetProviderENotificationSettings(messageBoardID).Result;
                if (providerResponse is OkObjectResult providerResponseOkResult)
                    providerENotifySettings = providerResponseOkResult.Value as ProviderENotifySettings;
                else
                    return new List<GetResponse>() { new GetResponse() { Success = false } };

                if (!string.IsNullOrEmpty(externalPlanId))
                {
                    var emailBody = controller.GetPlanENotificationOverrideSetting(messageBoardID, externalPlanId,
                        PlanEnotifyOverrideType.emailbody).Result;
                    notificationHelperService.AddPlanDetail(emailBody, PlanEnotifyOverrideType.emailbody, list, providerENotifySettings);

                    var fromAddress = controller.GetPlanENotificationOverrideSetting(messageBoardID, externalPlanId,
                        PlanEnotifyOverrideType.fromaddress).Result;
                    notificationHelperService.AddPlanDetail(fromAddress, PlanEnotifyOverrideType.fromaddress, list, providerENotifySettings);

                    var fromName = controller.GetPlanENotificationOverrideSetting(messageBoardID, externalPlanId,
                        PlanEnotifyOverrideType.fromname).Result;
                    notificationHelperService.AddPlanDetail(fromName, PlanEnotifyOverrideType.fromname, list, providerENotifySettings);
                }
                else
                {
                    list.Add(notificationHelperService.ConstructReturnData(providerResponse is OkObjectResult, providerENotifySettings.EmailBody, PlanEnotifyOverrideType.emailbody));                    
                }

                return Ok(list);
            }
            catch (Exception ex)
            {
                return await Task.FromResult(this.CreateExceptionResponse(ex));
            }
        }
                
        [HttpPut("enotification/{messageBoardID}/provider")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PutProviderEnotificationData(int messageBoardID,[FromBody] EProviderNotification data)
        {
            try
            {
                var controller = GetStatementController(_cache);
                var setting = controller.PutProviderENotificationEmailBody(messageBoardID, data.emailbody).Result;
                var response = notificationHelperService.GetSaveResponse(PlanEnotifyOverrideType.emailbody, "provider", data.utilityType, "updated", messageBoardID);

                return Ok(response);
            }
            catch (Exception ex)
            {
                return await Task.FromResult(this.CreateExceptionResponse(ex));
            }
        }

        [HttpPost("enotification/{messageBoardID}/enotification/settings/{externalPlanId}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<PostResponse>>> PostPlanEnotificationData(int messageBoardID, string externalPlanId, [FromBody] EPlanNotification data)
        {
            try
            {
                List<PostResponse> list = new List<PostResponse>();
                var controller = GetStatementController(_cache);
                var providerId = controller.getProviderGuidByEstatementId(messageBoardID);

                var plan = vPlan.FillByProviderAndExternalID(providerId, externalPlanId);

                list.Add(notificationHelperService.PostPlanNotification(messageBoardID,plan, data, PlanEnotifyOverrideType.emailbody));
                list.Add(notificationHelperService.PostPlanNotification(messageBoardID,plan, data, PlanEnotifyOverrideType.fromaddress));
                list.Add(notificationHelperService.PostPlanNotification(messageBoardID,plan, data, PlanEnotifyOverrideType.fromname));

                return Ok();
            }
            catch (Exception ex)
            {
                return await Task.FromResult(this.CreateExceptionResponse(ex));
            }
        }

        [HttpPost("provider")]
        [ProducesResponseType(StatusCodes.Status200OK,Type = typeof(eStatmentsDAC.BLL.Provider))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<eStatmentsDAC.BLL.Provider> GetProviderByFieldName(string fieldName,string fieldValue,bool needQuotes)
        {
            var provider = eStatmentsDAC.BLL.Provider.FillByField(fieldName, fieldValue, needQuotes);
            return Ok(provider);
        }

        [HttpPost("admin")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound,Type =typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult ViewStatementAdmin(ViewStatementRequestAdmin adminRequest)
        {
            try
            {
                var provider = eStatmentsDAC.BLL.Provider.FillByField("VirtualDir", adminRequest.VirtualDir);
                
                if (provider == null)
                    return BadRequest();

                statementService.LogAudit(provider.ProviderID, provider.ProviderID ,
                    2, configuration["application:ip"], configuration["application:browser"]);

                var ident = statementService.GetSSIdentPartID(adminRequest.UID, new string(provider.ProvID));
                var response = viewStatementHelperService.CreateViewStatementResponse(provider);
                response.HasPDFs = ident != null;
                if (ident == null)
                    return NotFound(response);

                viewStatementHelperService.FillResponseWithStatements(response, new ViewStatementRequest()
                {
                    GetProvider = provider,
                    Ident = ident,
                    UID = adminRequest.UID,
                    ViewType = ViewTypeEnum.Admin
                });
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpPost("participant")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult ViewStatementParticipant(ViewStatementRequestParticipant requestParticipant)
        {
            try
            {
                var provider = eStatmentsDAC.BLL.Provider.FillByField("VirtualDir", requestParticipant.VirtualDir);                

                if (provider == null)
                    return BadRequest();

                statementService.LogAudit(provider.ProviderID, provider.ProviderID,
                    2, configuration["application:ip"], configuration["application:browser"]);

                var participant = statementService.GetParticipantPartId(requestParticipant.ParticipantId, provider.ProviderID);

                if (!participant.ContainsKey("SSN") || !participant.ContainsKey("AcctNumber"))
                    return NotFound();

                var response = viewStatementHelperService.CreateViewStatementResponse(provider);

                var ident = new SSIdentPartID();
                if (provider.UseSSNPIN == 1 || provider.UseSSNPIN == 2)
                    ident.PART_ID = participant["SSN"];
                else
                    ident.PART_ID = participant["AcctNumber"];


                response.HasPDFs = ident != null;
                var list = statementService.GetSSIdentPartIDForParticipant(ident.PART_ID, new string(provider.ProvID), provider.AssetRetention);

                if(list.Count == 0)
                {
                    if (provider.ApplicationType == "statements")
                        response.Message = "There are no Statements to display.";
                    else if (provider.ApplicationType == "communication")
                        response.Message = "There are no Communications to display.";
                    else
                        response.Message = "There is no Personalized Information to display.";
                    
                    return NotFound(response);
                }

                foreach (var item in list)
                {
                    ident.PLATFORM = item.Platform;
                    ident.BATCH = item.Batch;

                    viewStatementHelperService.FillResponseWithStatements(response, new ViewStatementRequest()
                    {
                        GetProvider = provider,
                        Ident = ident,
                        UID = item.UID,
                        ViewType = ViewTypeEnum.Participant
                    });
                }
              
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpPost("sponsor")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(ViewStatementResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult ViewStatementSponsor(ViewStatementRequestSponsor requestSponsor)
        {
            try
            {
                var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(requestSponsor.ProviderId);
                var spad = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(requestSponsor.SpadId);

                if (provider == null || spad == null)
                    return BadRequest();

                var response = viewStatementHelperService.CreateViewStatementResponse(provider);
                var sponsorDetail = statementService.GetSSIdentPartIDForSponsor(requestSponsor.UID , 
                    new string(provider.ProvID), spad.SPAD_SPON_ID, provider.HasSuperSponsor, provider.AssetRetention);

                foreach (var item in sponsorDetail)
                {
                    var ident = new SSIdentPartID();
                    ident.PART_ID = item.part_id;
                    ident.BATCH = item.batch;
                    response.HasPDFs = ident != null;

                    viewStatementHelperService.FillResponseWithStatements(response, new ViewStatementRequest()
                    {
                        GetProvider = provider,
                        Ident = ident,
                        UID = requestSponsor.UID ,
                        ViewType = ViewTypeEnum.Participant,
                        Plan_num = item.plan_num
                    });
                }
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpGet("logos/{providerId}")]
        [ProducesResponseType(typeof(IEnumerable<MMApi.Models.ProviderLogo>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProviderLogos(int providerId)
        {
            try
            {
                var mmApiStmtCtrl = GetStatementController(_cache);

                var response = await mmApiStmtCtrl.GetProviderLogos(providerId);

                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpGet("logos/{providerId}/{planid}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetPlanLogo(int providerId, string planId)
        {
            try
            {
                var mmApiStmtCtrl = GetStatementController(_cache);

                var response = await mmApiStmtCtrl.GetPlanLogo(providerId, planId);

                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserReportList))]
        [HttpPost("approval-list")]
        public ActionResult GetApprovalList(StatementApproalListRequest req)
        {
            try
            {
                var quarter = (DateTime.Now.Month + 2) / 3;
                var year = DateTime.Now.Year;

                switch (quarter)
                {
                    case 1:
                        req.Quarter = 4;
                        req.Year = year - 1;
                        break;
                    case 2:
                        req.Quarter = 1;
                        req.Year = year;
                        break;
                    case 3:
                        req.Quarter = 2;
                        req.Year = year;
                        break;
                    case 4:
                        req.Quarter = 3;
                        req.Year = year;
                        break;
                    default:
                        req.Quarter = 0;
                        req.Year = year;
                        break;
                }

                
                var searchResult = statementService.GetApprovalList(req);                
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpPost("extract/approvalinfo")]
        [ProducesResponseType(typeof(IEnumerable<Plan>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProofDatesandReport([FromBody] List<int> extractids)
        {
            try
            {               

                List<Models.ApprovalInformation> response = new List<Models.ApprovalInformation>();
                var info = GetApprovalInformation(extractids);

                response.Add(info);

                return Ok(response);

            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        private Models.ApprovalInformation GetApprovalInformation(List<int> extractids)
        {
            var mmApiStmtCtrl = GetStatementController(_cache);


            Dictionary<int, string> proofDates = new Dictionary<int, string>();
            Dictionary<int, List<StatementReportFileType>> reportTypes = new Dictionary<int, List<StatementReportFileType>>();



            Parallel.For(0, extractids.Count, i =>
            {
                var response1 = mmApiStmtCtrl.GetStatementProofFileDate(extractids[i]);
                var response2 = mmApiStmtCtrl.GetStatementExtractReports(extractids[i]);

                //Checking the response is successful or not which is sent using HttpClient  
                if (!response1.IsFaulted)
                {

                    //Storing the response details recieved from web api   
                    if (response1.Result is OkObjectResult result)
                    {
                        proofDates.Add(extractids[i], result.Value.ToString());
                    }
                }
                else
                {
                    proofDates.Add(extractids[i], "Error: " + response1.Exception.Message);
                    throw response1.Exception;
                }

                //Checking the response is successful or not which is sent using HttpClient  
                if (!response2.IsFaulted)
                {
                    //Storing the response details recieved from web api   
                    if (response2.Result is OkObjectResult result)
                    {
                        reportTypes.Add(extractids[i], (List<StatementReportFileType>)result.Value);
                    }
                }

            });

            var info = new Models.ApprovalInformation
            {
                proofDates = proofDates,
                reportTypes = reportTypes
            };

            return info;
        }

        [HttpGet("extract/{id}/plans")]
        [ProducesResponseType(typeof(IEnumerable<ExtractPlan>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetExtractPlans(int id)
        {
            try
            {
                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();
                GetExtractActivePlansRequestBody activeBody = new GetExtractActivePlansRequestBody
                {
                    extractId = id
                };

                GetExtractActivePlansRequest requestActive = new GetExtractActivePlansRequest(activeBody);

                GetExtractDeletedPlansRequest requestDeleted = new GetExtractDeletedPlansRequest();
                GetExtractDeletedPlansRequestBody deletedBody = new GetExtractDeletedPlansRequestBody
                {
                    extractId = id
                };
                requestDeleted.Body = deletedBody;

                Task<GetExtractActivePlansResponse> responseActive = statementsSoap.GetExtractActivePlansAsync(requestActive);
                Task<GetExtractDeletedPlansResponse> responseDeleted = statementsSoap.GetExtractDeletedPlansAsync(requestDeleted);

                GetExtractActivePlansResponse activePlansResponse = await responseActive;
                GetExtractDeletedPlansResponse deletedPlansResponse = await responseDeleted;

                ExtractPlan[] activePlans = activePlansResponse.Body.GetExtractActivePlansResult;
                ExtractPlan[] deletedPlans = deletedPlansResponse.Body.GetExtractDeletedPlansResult;

                StatementExtractPlan plan = new StatementExtractPlan();

                List<StatementExtractPlan> response = new List<StatementExtractPlan>();
                foreach (ExtractPlan ap in activePlans)
                {
                    plan = new StatementExtractPlan
                    {
                        ExternalPlanId = ap.ExternalPlanId,
                        PlanName1 = ap.PlanName1,
                        PlanName2 = ap.PlanName2,
                        IsDeleted = false
                    };

                    response.Add(plan);
                }

                foreach (ExtractPlan ap in deletedPlans)
                {
                    plan = new StatementExtractPlan
                    {
                        ExternalPlanId = ap.ExternalPlanId,
                        PlanName1 = ap.PlanName1,
                        PlanName2 = ap.PlanName2,
                        IsDeleted = true
                    };

                    response.Add(plan);
                }

                return new OkObjectResult(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        /// <summary>
        ///     Starts Process to Generate PDF Proof for Extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract identifier
        /// </param>
        [HttpGet("extract/{id}/generateProof")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GenerateProof(int id)
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"GenerateProof/{id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();
                client.Timeout = TimeSpan.FromMinutes(5);

                var response = await client.GetAsync(uri);

                //Checking the response is successful or not which is sent using HttpClient  
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return new ObjectResult(result);
                }
                else
                {
                    return new BadRequestObjectResult(response);
                }

            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpGet("extract/{extractId}/reports/{reportType}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetStatementReports(int extractId, MMARDataApi.Models.StatementReportFileType reportType)
        {
            try
            {
                var controller = GetStatementController(_cache);
                var result = await controller.GetStatementReport(extractId, reportType);

                return result;
            }
            catch (Exception ex)
            {
                return await Task.FromResult(this.CreateExceptionResponse(ex));
            }
        }


        /// <summary>
        ///     Gests a report if it existes for a specific extract 
        ///     and report type
        /// </summary>
        /// <param name="id">
        ///     Extract identifier to get the report for
        /// </param>
        /// <param name="reportType">
        ///     Type of report to retrieve
        /// </param>
        /// <returns>
        ///     FileSteamof the report if it exists
        /// </returns>
        //[HttpGet("extract/{id}/reports/{reportType}")]
        //[Authorize]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(StatusCodes.Status400BadRequest)]
        //public async Task<IActionResult> GetStatementExtractReport(int id, StatementReportFileType reportType)
        //{
        //    string uri = configuration["STATEMENTS:EndpointAddress"] + $"extract/{id}/reports/{reportType}";

        //    try
        //    {
        //        HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

        //        HttpResponseMessage response = await client.GetAsync(uri);

        //        //Checking the response is successful or not which is sent using HttpClient  
        //        if (response.IsSuccessStatusCode)
        //        {
        //            FieldInfo fieldInfo = reportType.GetType().GetField(reportType.ToString());
        //            object[] customAttributes = fieldInfo.GetCustomAttributes(typeof(StatementReportTypeAttribute), false);

        //            string mimeType = ((StatementReportTypeAttribute)customAttributes[0]).MimeType;
        //            string filenameLookup = ((StatementReportTypeAttribute)customAttributes[0]).PartialFilename;
        //            string extension = ((StatementReportTypeAttribute)customAttributes[0]).Extension;

        //            string fileName = filenameLookup + extension;
        //            byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);

        //            return File(retArr, mimeType, fileName);

        //        }
        //        else
        //        {
        //            return new BadRequestObjectResult(response);
        //        }
        //    }
        //    catch (Exception x)
        //    {
        //        return this.CreateExceptionResponse(x);
        //    }
        //}

        private MMARDataApi.Controllers.StatementController GetStatementController(IMemoryCache cache)
        {
            var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
            var logger = loggerFactory.CreateLogger<MMARDataApi.Controllers.StatementController>();

            MMARDataApi.Controllers.StatementController aa =
                new MMARDataApi.Controllers.StatementController(configuration, cache, logger);
            return aa;
        }
    }
}
