﻿using eStatmentsAPI.Models;
using eStatmentsDAC.BLL;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using eStatmentsDAC.eStatementAdmin;
using eStatmentsDAC.eStatementAdmin.DATA;
using eStatmentsDAC.Service;
using Common.Extensions;
using Common.Interfaces;
using StatusCodes = Microsoft.AspNetCore.Http.StatusCodes;
using Microsoft.Extensions.Configuration;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Classes;

namespace eStatmentsAPI.Controllers
{
    [Route("estatement")]
    [ApiController]
    public class eStatementController : ControllerBase
    {
        IAccountService account;
        IConfiguration configuration;
        IEStatementService statementService;

        public eStatementController(IAccountService accountsService, IConfiguration configuration,IEStatementService statementService)
        {
            this.account = accountsService;
            this.configuration = configuration;
            this.statementService = statementService;
        }

        /*                                                                                                        Proivider Administration  */
        // GET: api/<eStatementController>
        [HttpGet("Communications")]
        public ActionResult<IEnumerable<Communications>> GetAllCommunications()
        {
            var list = tdCommunications.GetAll();
            
            return Ok(list);

        }
        [HttpGet("EmptyCommunications")]
        public ActionResult<tdCommunications> GetEmptyCommunications()
        {
            return Ok(new tdCommunications());
        }
        [HttpPost("Communications")]
        public ActionResult<int> PostCommunicationsAddData(tdCommunications data)
        {

            var list = tdCommunications.GetAll();
            short max = 0;
            foreach (tdCommunications element in list)
            {
                if (element.Descrip == data.Descrip)
                {
                    return Ok(0);
                }
                max = max >= element.CommunicationTypeCD ? max : element.CommunicationTypeCD;
            }
            ++max;
            List<tdCommunications> newCommunication = new List<tdCommunications>();
            data.CommunicationTypeCD = max;
            newCommunication.Add(data);
            tdCommunications.BulkInsert(newCommunication);
            return Ok(data.CommunicationTypeCD);
        }

        //Provider
        [HttpGet("CommunicationsScope")]
        public ActionResult<IEnumerable<string>> GetCommunicationsScope()
        {
            IEnumerable<string> enumerable = statementService.GetCommunicationsScope();
            return Ok(enumerable);
        }

        [HttpGet("AllProviderDetails")]
        public ActionResult<IEnumerable<Provider>> GetAllProviderDetails()
        {
            var list = Provider.GetAll();
            return Ok(list);
        }

        [HttpGet("ProviderIdName")]
        public ActionResult<IEnumerable<ProviderIdName>> GetProviderName()
        {
            var list = Provider.GetAll();
            List<ProviderIdName> providerDetails = new List<ProviderIdName>();
            ProviderIdName temp;
            foreach (Provider element in list)
            {
                temp = new ProviderIdName();
                temp.ProviderID = element.ProviderID;
                temp.Name = element.Name;
                providerDetails.Add(temp);
            }
            return Ok(providerDetails);

        }
        [HttpGet("ProviderByProviderID")]
        public ActionResult<Provider> GetProviderByProviderID(int ProviderID)
        {
            return Ok(Provider.GetByProviderID(ProviderID));
        }
        [HttpGet("EmptyProvider")]
        public ActionResult<Provider> GetEmptyProvider()
        {
            Provider empty = new Provider();
            string constval = "null";
            empty.IPAddress = constval.ToCharArray();
            empty.SmartImagePath = constval.ToCharArray();
            empty.SmartStylePath = constval.ToCharArray();
            return Ok(empty);

        }
        //edit PROVIDER
        [HttpPut("Provider")]
        public ActionResult<Provider> PutProvider(Provider data)
        {
            List<Provider> newProvider = new List<Provider>();
            newProvider.Add(data);
            return Ok(data);
        }
        //add Provider
        [HttpPost("Provider")]
        public ActionResult<Provider> PostProvider(Provider data)
        {
            List<Provider> newProvider = new List<Provider>();
            newProvider.Add(data);
            if (data.ProviderID == 0)
            {

                Provider.BulkInsert(newProvider);
            }
            else
            {
                Provider.BulkUpdate(newProvider, 1);
            }
            return Ok(data);
        }
        [HttpPut("Provider/{id}")]
        public ActionResult<Provider> PutProvider(int id, Provider data)
        {

            List<Provider> newProvider = new List<Provider>();

            newProvider.Add(data);
            Provider.BulkUpdate(newProvider, 1);
            return Ok(data);


        }
        // DELETE api/<eStatementController>/5
        [HttpDelete("Provider")]
        public ActionResult<bool> DeleteProvider(int ProviderID)
        {
            if (Provider.DeleteById(ProviderID) == true)
            {
                return Ok("DELETED");
            }
            return Ok("Not Deleted");
        }

        /*     -------------------------------------------------------                   Avccount Administration  -------------------------------------------------------*/

        [HttpGet("ActiveProviderIdName")]
        public ActionResult<IEnumerable<ProviderIdName>> GetActiveProviderName()
        {
            var Providerlist = Provider.GetAll();
            var ProvAdminLinkslist = ProvAdminLinks.GetAll();
            var providerId = new List<int>();
            List<ProviderIdName> providerDetails = new List<ProviderIdName>();
            ProviderIdName temp;
            foreach (Provider ProviderElement in Providerlist)
            {
                if (ProviderElement.Active)
                {
                    if (providerId.Contains(ProviderElement.ProviderID))
                    {

                    }
                    else
                    {
                        providerId.Add(ProviderElement.ProviderID);
                        foreach (ProvAdminLinks ProvAdminElement in ProvAdminLinkslist)
                        {
                            if (ProviderElement.ProviderID == ProvAdminElement.PRAD_ProviderID)
                            {
                                temp = new ProviderIdName();
                                temp.ProviderID = ProvAdminElement.PRAD_ProviderID;
                                temp.Name = ProviderElement.Name;
                                providerDetails.Add(temp);
                                break;
                            }
                        }
                    }
                }
            }
            return Ok(providerDetails);
        }


        [HttpGet("ProviderCommunicationTypeCD")]
        public ActionResult<int> GetMaxProviderCommunicationTypeCD()
        {
            int max = 0;
            var teProviderCommunicationsData = teProviderCommunications.GetAll();
            foreach (teProviderCommunications element in teProviderCommunicationsData)
            {
                max = max >= element.ProviderCommunicationTypeCD ? max : element.ProviderCommunicationTypeCD;
            }
            max = max + 1;
            return Ok(max);
        }


        [HttpGet("Administrator")]
        public ActionResult<IEnumerable<c_Administrator>> qGetAdministrator(int ProviderID)
        {
            var AdministratorList = Administrator.GetAll();
            List<c_Administrator> data = new List<c_Administrator>();
            c_Administrator temp;
            foreach (Administrator element in AdministratorList)
            {
                // element.AdministratorID,element.UserID,element.Password,element.LName,element.FName,element.ProfileID;
                if (element.Active && element.ProviderID == ProviderID && element.InternalUser == false)
                {
                    temp = new c_Administrator()
                    {
                        AdministratorID = element.AdministratorID,
                        FName = element.FName,
                        LName = element.LName,
                        UserID = element.UserID,
                        Password = element.Password,
                        ProfileID = element.ProfileID,
                        ProviderID = element.ProviderID,
                    };
                    data.Add(temp);
                }
            }


            return Ok(data);
        }
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<spGetProfilesByProviderID>))]
        [HttpGet("Profiles")]
        public ActionResult<IEnumerable<spGetProfilesByProviderID>> profiles(int ProviderID, bool Active=true)
        {
            try
            {
                return account.GetProfiles(ProviderID, Active);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }



        /*-----------------------------------------------------------------------------------administrator -----------------------------------------*/
        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }

        //perfdect  using
        [HttpPost("Administrator")]
        public ActionResult<int> PostAdministrator(List<c_Administrator> data)
        {

            int i = 0;
            foreach (c_Administrator element in data)
            {
                if (element.AdministratorID < 0)
                {

                   
                    Administrator dataToSave = new Administrator();
                    dataToSave.FName = element.FName;
                    dataToSave.LName = element.LName;
                    dataToSave.EMail = "";
                    dataToSave.UserID = element.UserID;
                    dataToSave.Password = CreateMD5(element.Password);
                    dataToSave.ProfileID = element.ProfileID;
                    dataToSave.LastLogin = DateTime.Now;
                    dataToSave.Active = true;
                    dataToSave.isPasswordHashed = true;

                    string[] stringdata = Guid.NewGuid().ToString().ToUpper().Split('-');
                    string s = "";
                    int j = 0;
                    foreach (string str in stringdata)
                    {
                        if (j == 0)
                        {
                            s = s + str;
                        }
                        else if (j <= 3)
                        {
                            s = s + "-" + str;
                        }
                        else
                        {
                            s += str;
                        }
                        j++;
                    }
                    dataToSave.administratorUUID = s.ToCharArray();



                    List<Administrator> list = new List<Administrator>();
                    list.Add(dataToSave);
                    Administrator.BulkInsert(list);
                    i++;
                }
                else
                {

                    Administrator dataToUpdate = Administrator.GetByAdministratorID(element.AdministratorID);
                    List<Administrator> list = new List<Administrator>();
                    dataToUpdate.FName = element.FName;
                    dataToUpdate.LName = element.LName;
                    dataToUpdate.UserID = element.UserID;
                    dataToUpdate.Password = element.Password;
                    dataToUpdate.ProfileID = element.ProfileID;

                    dataToUpdate.LastLogin = DateTime.Now;

                    list.Add(dataToUpdate);
                    Administrator.BulkUpdate(list, 1);
                    i++;
                }
            }
            return Ok(i);
        }
        /* ------------------------------------------------Link Administration -------------------*/
        //perfect using
        [HttpGet("Providers")]
        public ActionResult<IEnumerable<ProviderIdNameActiveUpdated>> qGetProviders()
        {
           
            var ProviderList = Provider.GetAll();
            List<ProviderIdNameActiveUpdated> data = new List<ProviderIdNameActiveUpdated>();
            ProviderIdNameActiveUpdated temp;
            foreach (Provider element in ProviderList)
            {

                temp = new ProviderIdNameActiveUpdated()
                {
                    ProviderID = element.ProviderID,
                    Name = element.Name,
                    Active = element.Active,
                    Updated = false,

                };
                data.Add(temp);

            }


            return Ok(data);
        }
        //working fine perfect     
        [HttpGet("AllLinks")]
        public ActionResult<IEnumerable<ParLinks>> qGetAllLinks()
        {
            
            var ProviderList = ParLinks.GetAll();
            List<ParLinks> data = new List<ParLinks>();
            foreach (ParLinks element in ProviderList)
            {
                if (element.LinkText != "Login" && element.LinkText != "Logout")
                {

                    data.Add(element);
                }
            }
            return Ok(data);
        }

        // workinng fine and using
        [HttpGet("ProvParLinks")]
        public ActionResult<IEnumerable<object>> qGetProvParLinks(int ProviderID)
        {
            var ParLinksList = ParLinks.GetAll();
            List<object> datatoSend = new List<object>();
            foreach (ParLinks ParLinksElement in ParLinksList)
            {
                if (ParLinksElement.LinkText != "Login" && ParLinksElement.LinkText != "Logout")
                {
                    var ProvParLinksList = statementService.GetProvParLinksCommunicationsByPRPA_ProviderIDandPRPA_LinkID(ProviderID, (short)ParLinksElement.LinkID);
                    if (ProvParLinksList.Count() == 1)
                    {
                        ProvParLinks element = ProvParLinksList.First();
                        datatoSend.Add(new
                        {
                            LinkID = ParLinksElement.LinkID,
                            LinkOrder = element.PRPA_LinkOrder,
                            LinkText = ParLinksElement.LinkText,
                            display = true,
                        });
                    }
                    else
                    {

                        datatoSend.Add(new
                        {
                            LinkID = ParLinksElement.LinkID,
                            LinkOrder = ParLinksElement.LinkOrder,
                            LinkText = ParLinksElement.LinkText,
                            display = false,
                        });

                    }
                }
            }
            return Ok(datatoSend);
        }


        // working fine using
        [HttpPost("ProvParLinks")]
        public ActionResult PostProvParLinks(object data)
        {
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(data.ToString());
            int ProviderID = 0;
            Dictionary<int, c_ProvParLinks> dataToSave = new Dictionary<int, c_ProvParLinks>();
            c_ProvParLinks temp;
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID")
                {
                    ProviderID = Int32.Parse(item.Value);
                    break;
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s.All(char.IsDigit))
                {

                    temp = new c_ProvParLinks()
                    {
                        PRPA_ProviderID = ProviderID,
                        PRPA_LinkID = Int32.Parse(s),
                        display = Boolean.Parse(item.Value),
                        PRPA_LinkOrder = 0,
                    };
                    dataToSave.Add(temp.PRPA_LinkID, temp);
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID" || s == "Name")
                {
                }
                else if (!s.All(char.IsDigit))
                {
                    s = s.Substring(9);
                    dataToSave[Int32.Parse(s)].PRPA_LinkOrder = Int32.Parse(item.Value);
                }
            }
            Console.Clear();
            IEnumerable<ProvParLinks> ProvParLinksList;// = ProvParLinks.GetAll();
            foreach (var item in dataToSave)
            {
                ProvParLinksList = statementService.GetProvParLinksCommunicationsByPRPA_ProviderIDandPRPA_LinkID(ProviderID, item.Key);
                if (ProvParLinksList.Count() == 1)
                {
                    ProvParLinks dataToUpdate = ProvParLinksList.First();
                    List<ProvParLinks> List = new List<ProvParLinks>();
                    temp = item.Value;
                    if (temp.display == true)       //update
                    {
                        Console.WriteLine(dataToUpdate.PRPA_LinkOrder + "  :  " + temp.PRPA_LinkOrder);
                        dataToUpdate.PRPA_LinkOrder = temp.PRPA_LinkOrder;

                        Console.WriteLine("update:---  " + item.Key + "  :  " + item.Value.PRPA_LinkID + "  :  " + item.Value.PRPA_LinkOrder + "  :  " + item.Value.PRPA_ProviderID + "  :  " + item.Value.display);
                        List.Add(dataToUpdate);
                        ProvParLinks.BulkUpdate(List, 1);
                    }
                    else
                    {
                        Console.WriteLine("delete:---  " + item.Key + "  :  " + item.Value.PRPA_LinkID + "  :  " + item.Value.PRPA_LinkOrder + "  :  " + item.Value.PRPA_ProviderID + "  :  " + item.Value.display);
                        ProvParLinks.DeleteById(dataToUpdate.PRPA_PK);
                    }
                }
                else if (item.Value.display)
                {
                    List<ProvParLinks> insert = new List<ProvParLinks>();
                    ProvParLinks dataInsert = new ProvParLinks();
                    temp = item.Value;
                    dataInsert.PRPA_LinkOrder = temp.PRPA_LinkOrder;
                    dataInsert.PRPA_LinkID = temp.PRPA_LinkID;
                    dataInsert.PRPA_ProviderID = temp.PRPA_ProviderID;
                    insert.Add(dataInsert);
                    Console.WriteLine("insert:---  " + item.Key + "  :  " + item.Value.PRPA_LinkID + "  :  " + item.Value.PRPA_LinkOrder + "  :  " + item.Value.PRPA_ProviderID + "  :  " + item.Value.display);

                    ProvParLinks.BulkInsert(insert);
                }
            }
            return Ok();
        }






        //       not using  but working fast               //////

        [HttpGet("ProviderCommunications2")]
        public ActionResult<IEnumerable<object>> qGetProviderCommunications2(int ProviderID, short CommunicationTypeCD)
        {
            /*
             SELECT tdCommunications.CommunicationTypeCD, tdCommunications.Descrip,teProviderCommunications.DisplayOrder
					FROM teProviderCommunications, tdCommunications 
					WHERE teProviderCommunications.CommunicationTypeCD = tdCommunications.CommunicationTypeCD 
						AND teProviderCommunications.ProviderID = '#ListGetAt(form.ProviderID,1,"|")#'
					ORDER BY teProviderCommunications.DisplayOrder
            */
            //var tdCommunicationsList = tdCommunications.GetAll();
            var teProviderCommunicationsList = teProviderCommunications.GetAll();
            List<object> dataToSend = new List<object>();
            //object temp; anonimous
            foreach (teProviderCommunications providerCommunicationsListElement in teProviderCommunicationsList)
            {
                if (providerCommunicationsListElement.ProviderID == ProviderID && providerCommunicationsListElement.CommunicationTypeCD == CommunicationTypeCD)
                {
                    dataToSend.Add(new
                    {
                        CommunicationTypeCD = providerCommunicationsListElement.CommunicationTypeCD,
                        DisplayOrder = providerCommunicationsListElement.DisplayOrder,
                        display = true,
                    });
                    break;
                }
            }
            return Ok(dataToSend);
        }
        ///

        // PERFECT IN USE
        [HttpGet("ProviderCommunications")]
        public ActionResult<IEnumerable<object>> qGetProviderCommunications(int ProviderID)
        {
            var tdCommunicationslist = tdCommunications.GetAll();
            List<object> dataToSend = new List<object>();
            IEnumerable<teProviderCommunications> teProviderCommunicationsList;

            foreach (tdCommunications tdCommunicationslistElement in tdCommunicationslist)
            {
                teProviderCommunicationsList = statementService.GetteProviderCommunicationsByProviderIDandCommunicationTypeCD(ProviderID, tdCommunicationslistElement.CommunicationTypeCD);
                if (teProviderCommunicationsList.Count() == 1)
                {
                    teProviderCommunications teProviderCommunicationselement = teProviderCommunicationsList.First();
                    dataToSend.Add(new
                    {
                        Descrip = tdCommunicationslistElement.Descrip,
                        CommunicationTypeCD = teProviderCommunicationselement.CommunicationTypeCD,
                        DisplayOrder = teProviderCommunicationselement.DisplayOrder,
                        display = true,
                    });
                }
                else
                {
                    dataToSend.Add(new
                    {
                        Descrip = tdCommunicationslistElement.Descrip,
                        CommunicationTypeCD = tdCommunicationslistElement.CommunicationTypeCD,
                        DisplayOrder = 0,
                        display = false,
                    });
                }
            }
            return Ok(dataToSend);
        }




        //PERFECT IN UAE
        [HttpPost("ProviderCommunications")]
        public ActionResult qPostProviderCommunications(object data)
        {
            /*
             * ProviderId
             * All(CommunicationTypeCD)
             *      1=bool //present
             *      2
             *      DisplayOrder[CommunicationTypeCD]
            */
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(data.ToString());
            int ProviderID = 0;
            Dictionary<int, c_teProviderCommunications> dataToSave = new Dictionary<int, c_teProviderCommunications>();
            c_teProviderCommunications temp;
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID")
                {
                    ProviderID = Int32.Parse(item.Value);
                    break;
                }

            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s.All(char.IsDigit))
                {

                    temp = new c_teProviderCommunications()
                    {
                        ProviderID = ProviderID,
                        CommunicationTypeCD = (short)Int32.Parse(s),
                        display = Boolean.Parse(item.Value),
                        DisplayOrder = 0,
                    };
                    dataToSave.Add(temp.CommunicationTypeCD, temp);
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID" || s == "Name")
                {
                }
                else if (!s.All(char.IsDigit))
                {
                    s = s.Substring(12);
                    dataToSave[Int32.Parse(s)].DisplayOrder = (short)Int32.Parse(item.Value);
                }
            }

            //saving or updating Data
            Console.Clear();


            var teProviderCommunicationsList = statementService.GetteProviderCommunicationsByProviderID(ProviderID);
            var teProviderCommunicationsDict = new Dictionary<int, teProviderCommunications>();
            foreach (teProviderCommunications element in teProviderCommunicationsList)
            {
                teProviderCommunicationsDict.Add(element.CommunicationTypeCD, element);
            }

            foreach (var item in dataToSave)
            {
                if (teProviderCommunicationsDict.ContainsKey(item.Key))
                {
                    List<teProviderCommunications> update = new List<teProviderCommunications>();
                    teProviderCommunications element = teProviderCommunicationsDict[item.Key];
                    temp = item.Value;
                    if (temp.display == true)       //update
                    {
                        element.DisplayOrder = temp.DisplayOrder;
                        Console.WriteLine("update:---  " + item.Key + "  :  " + item.Value.CommunicationTypeCD + "  :  " + item.Value.DisplayOrder + "  :  " + item.Value.ProviderID + "  :  " + item.Value.display);
                        update.Add(element);
                        teProviderCommunications.BulkUpdate(update, 1);
                    }
                    else if (temp.display == false)
                    {
                        Console.WriteLine("delete:---  " + item.Key + "  :  " + item.Value.CommunicationTypeCD + "  :  " + item.Value.DisplayOrder + "  :  " + item.Value.ProviderID + "  :  " + item.Value.display);
                        teProviderCommunications.DeleteById(element.ProviderCommunicationTypeCD);
                    }
                }
                else if (item.Value.display)
                {
                    //List<teProviderCommunications> insert = new List<teProviderCommunications>();
                    teProviderCommunications dataInsert = new teProviderCommunications();
                    temp = item.Value;
                    dataInsert.DisplayOrder = temp.DisplayOrder;
                    dataInsert.CommunicationTypeCD = temp.CommunicationTypeCD;
                    dataInsert.ProviderID = temp.ProviderID;
                    //dataInsert.ProviderCommunicationTypeCD = ++max;
                    //insert.Add(dataInsert);
                    Console.WriteLine(statementService.PostteProviderCommunications(dataInsert));
                    Console.WriteLine("insert:---  " + item.Key + "  :  " + item.Value.CommunicationTypeCD + "  :  " + item.Value.DisplayOrder + "  :  " + item.Value.ProviderID + "  :  " + item.Value.display);
                    // teProviderCommunications.BulkInsert(insert);
                }
            }

            return Ok();

        }

        //  Not  Using It                 perfect no need of stored procedure just sending all data
        [HttpGet("AllAdminLinks")]
        public ActionResult<IEnumerable<object>> qGetAdminLinks()
        {
            /* 
	                SELECT LinkOrder,LinkText,LinkID
	                FROM AdminLinks
	                WHERE active = 1
		            AND LinkText != 'Login' AND LinkText != 'Logout'	
            */
            var AdminLinksList = AdminLinks.GetAll();
            List<object> data = new List<object>();
            foreach (AdminLinks element in AdminLinksList)
            {
                if (element.Active && element.LinkText != "Login" && element.LinkText != "Logout")
                {

                    data.Add(new
                    {
                        LinkID = element.LinkID,
                        LinkText = element.LinkText,
                        //LinkOrder =element.LinkOrder,
                    });
                }
            }
            return Ok(data);
        }
        // Perfect DoubleCheck
        [HttpGet("ProvAdminLinks")]
        public ActionResult<IEnumerable<object>> qGetProvAdminLinks(int ProviderID)
        {
            /*
             	SELECT PRAD_LinkID
			        FROM ProvAdminLinks
			        WHERE PRAD_LinkID = #qGetAllLinks.LinkID[x]# and PRAD_ProviderID = #qGetProviders.control_id[i]#
            */
            var AdminLinksList = AdminLinks.GetAll();   //necessary as all data is to send
            List<object> dataToSend = new List<object>();
            IEnumerable<ProvAdminLinks> ProvAdminLinksList;//= storedProcedure.GetProvAdminLinksProviderIDandLinkID(ProviderID, LinkID);
            foreach (AdminLinks element in AdminLinksList)
            {
                if (element.Active && element.LinkText != "Login" && element.LinkText != "Logout")
                {
                    ProvAdminLinksList = statementService.GetProvAdminLinksProviderIDandLinkID(ProviderID, (short)element.LinkID);
                    if (ProvAdminLinksList.Count() == 1)
                    {
                        ProvAdminLinks ProvAdminLinksElement = ProvAdminLinksList.First();
                        dataToSend.Add(new
                        {
                            PRAD_LinkID = ProvAdminLinksElement.PRAD_LinkID,
                            LinkText = element.LinkText,
                            display = true,
                        });
                    }
                    else
                    {
                        dataToSend.Add(new
                        {
                            PRAD_LinkID = element.LinkID,
                            LinkText = element.LinkText,
                            display = false,
                        });
                    }

                }
            }
            return dataToSend;
        }
        // perfect use n^2-->n
        [HttpPost("ProvAdminLinks")]
        public ActionResult qPostProvAdminLinks(object data)
        {
            /*
             * ProviderId
             * All(PRAD_LinkID)
             *      1=bool //present
             *      2
             *      
             *      
            */
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(data.ToString());
            int ProviderID = 0;
            Dictionary<int, bool> dataToSave = new Dictionary<int, bool>();
            //c_teProviderCommunications temp;
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID")
                {
                    ProviderID = Int32.Parse(item.Value);
                    break;
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s.All(char.IsDigit))
                {
                    dataToSave.Add((short)Int32.Parse(s), Boolean.Parse(item.Value));
                }
            }
            //saving or updating Data
            Console.Clear();
            var ProvAdminLinksList = statementService.GetProvAdminLinksProviderID(ProviderID);
            var ProvAdminLinksDict = new Dictionary<int, ProvAdminLinks>();
            foreach (ProvAdminLinks element in ProvAdminLinksList)
            {
                ProvAdminLinksDict.Add(element.PRAD_LinkID, element);
            }
            foreach (var item in dataToSave)
            {
                if (ProvAdminLinksDict.ContainsKey(item.Key))
                {
                    List<ProvAdminLinks> update = new List<ProvAdminLinks>();

                    if (item.Value == true)       //update
                    {
                        Console.WriteLine("update:---  " + item.Key + "  :  " + ProviderID);
                    }
                    else
                    {
                        Console.WriteLine("delete:---  " + item.Key + "  :  " + ProviderID);
                        ProvAdminLinks.DeleteById(ProvAdminLinksDict[item.Key].PRAD_PK);

                    }
                }
                else if (item.Value)
                {
                    List<ProvAdminLinks> insert = new List<ProvAdminLinks>();
                    ProvAdminLinks dataInsert = new ProvAdminLinks();
                    dataInsert.PRAD_LinkID = item.Key;
                    dataInsert.PRAD_ProviderID = ProviderID;
                    insert.Add(dataInsert);
                    Console.WriteLine("insert:---  " + item.Key + "  :  " + ProviderID);
                    ProvAdminLinks.BulkInsert(insert);
                }
            }

            return Ok();
        }


        [HttpGet("PromoLinks")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<PromoLinks>))]
        public ActionResult<IEnumerable<PromoLinks>> qGetPromoLinks(int ProviderID)
        {
            var promoLinkslist = statementService.GetPromoLinksByProviderID(ProviderID);
            return Ok(promoLinkslist);
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SampleLinks>))]
        [HttpGet("SampleLinks")]
        public ActionResult<IEnumerable<SampleLinks>> qGetSampleLinks(int ProviderID)
        {
            var sampleLinkslist = statementService.GetSampleLinkByProviderID(ProviderID);
            return Ok(sampleLinkslist);
        }
        //perfect use
        [HttpGet("createDefaultRegList")]
        public ActionResult createDefaultRegList(int ProviderID)
        {
            List<AboutText> list = new List<AboutText>();
            AboutText variable = new AboutText();

            var AboutTextList = variable.GetAboutTextsByProviderID(ProviderID);
           
            AboutTextList = variable.GetAboutTextsByProviderID(0);

            foreach (AboutText element in AboutTextList)
            {
                var temp = new AboutText();
                temp.AboutOrder = element.AboutOrder;
                temp.AboutHeader = element.AboutHeader;
                temp.AboutBody = element.AboutBody;
                temp.ProviderID = ProviderID;
                temp.Active = true;
                variable.SaveAboutTextsByProviderID(temp);
                Console.WriteLine(temp);
            }

            var Faqlist = statementService.GetFaqTextByProviderID(0);
            List<FaqText> dataToSend2 = new List<FaqText>();
            foreach (FaqText element in Faqlist)
            {

                var temp = new FaqText();
                temp.FAQOrder = element.FAQOrder;
                temp.Question = element.Question;
                temp.Answer = element.Answer;
                temp.ProviderId = ProviderID;
                temp.Active = true;
                dataToSend2.Add(temp);
                Console.WriteLine(temp);

            }
            FaqText.BulkInsert(dataToSend2);


            var PromoTextlist = statementService.GetPromoTextByProviderID(0);
            List<PromoText> dataToSend3 = new List<PromoText>();
            foreach (PromoText element in PromoTextlist)
            {

                var temp = new PromoText();
                temp.TextOrder = element.TextOrder;
                temp.TextHeader = element.TextHeader;
                temp.TextBody = element.TextBody;
                temp.ProviderID = ProviderID;
                temp.Active = true;
                dataToSend3.Add(temp);
                Console.WriteLine(temp);

            }
            PromoText.BulkInsert(dataToSend3);


            var PromoLinkslist = statementService.GetPromoLinksByProviderID(0); ;
            List<PromoLinks> dataToSend4 = new List<PromoLinks>();
            foreach (PromoLinks element in PromoLinkslist)
            {

                var temp = new PromoLinks();
                temp.LinkOrder = element.LinkOrder;
                temp.LinkText = element.LinkText;
                temp.LinkURL = element.LinkURL;
                temp.PopUp = element.PopUp;
                temp.ProviderID = ProviderID;
                temp.Active = true;
                temp.Secure = element.Secure;
                dataToSend4.Add(temp);

            }
            PromoLinks.BulkInsert(dataToSend4);


            var SampleLinkslist = statementService.GetSampleLinkByProviderID(0); ;
            List<SampleLinks> dataToSend5 = new List<SampleLinks>();
            foreach (SampleLinks element in SampleLinkslist)
            {

                var temp = new SampleLinks();
                temp.SampleOrder = element.SampleOrder;
                temp.SampleText = element.SampleText;
                temp.SampleURL = element.SampleURL;
                temp.PopUp = element.PopUp;
                temp.ProviderID = ProviderID;
                temp.Active = true;
                temp.Secure = element.Secure;
                dataToSend5.Add(temp);
                Console.WriteLine(temp);

            }
            SampleLinks.BulkInsert(dataToSend5);
            return Ok();
        }
        //perfgect use
        [HttpGet("Count")]
        public ActionResult<int> getCount(int ProviderID)
        {
            var SampleLinkslist = statementService.GetSampleLinkByProviderID(ProviderID);

            var PromoLinkslist = statementService.GetPromoLinksByProviderID(ProviderID);
            return SampleLinkslist.Count() + PromoLinkslist.Count();

        }

        //          saving reg
        //perfect use
        [HttpPost("PromoLinks")]
        public ActionResult qPostPromoLinks(object data)
        {
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(data.ToString());
            Dictionary<int, PromoLinks> dataToSave = new Dictionary<int, PromoLinks>();
            PromoLinks temp;
            List<PromoLinks> dataToUpdate = new List<PromoLinks>();

            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s.All(char.IsDigit))
                {
                    temp = PromoLinks.GetByLinkID(Int32.Parse(s));
                    temp.Active = Boolean.Parse(item.Value);
                    dataToSave.Add(temp.LinkID, temp);
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID" || s == "Name")
                {
                }
                else if (!s.All(char.IsDigit))
                {
                    s = s.Substring(9);
                    dataToSave[Int32.Parse(s)].LinkOrder = Int32.Parse(item.Value);
                    dataToUpdate.Add(dataToSave[Int32.Parse(s)]);
                    temp = dataToSave[Int32.Parse(s)];
                }
            }
            PromoLinks.BulkUpdate(dataToUpdate, dataToUpdate.Count());
            return Ok();
        }
        // Perfect use
        [HttpPost("SampleLinks")]
        public ActionResult qPostSampleLinks(object data)
        {
            var dictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(data.ToString());
            Dictionary<int, SampleLinks> dataToSave = new Dictionary<int, SampleLinks>();
            SampleLinks temp;
            List<SampleLinks> dataToUpdate = new List<SampleLinks>();

            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s.All(char.IsDigit))
                {
                    temp = SampleLinks.GetBySampleID(Int32.Parse(s));
                    temp.Active = Boolean.Parse(item.Value);
                    dataToSave.Add(temp.SampleID, temp);
                }
            }
            foreach (var item in dictionary)
            {
                string s = item.Key;
                if (s == "ProviderID" || s == "Name")
                {
                }
                else if (!s.All(char.IsDigit))
                {
                    s = s.Substring(11);
                    dataToSave[Int32.Parse(s)].SampleOrder = Int32.Parse(item.Value);
                    dataToUpdate.Add(dataToSave[Int32.Parse(s)]);
                }
            }
            SampleLinks.BulkUpdate(dataToUpdate, dataToUpdate.Count());
            return Ok();
        }

    }
}
