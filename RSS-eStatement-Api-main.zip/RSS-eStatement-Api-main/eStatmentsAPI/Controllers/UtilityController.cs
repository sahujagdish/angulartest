﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsAPI.Models;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace eStatmentsAPI.Controllers
{
    [Route("Utility")]
    [ApiController]
    [Authorize]
    public class UtilityController : ControllerBase
    {
        IConfiguration configuration;
        IUtilityService utility;
        IFileService fileService;
        public UtilityController(IUtilityService utilityService,
            IConfiguration configuration,
            IFileService fileService)
        {
            this.fileService = fileService;
            this.configuration = configuration;
            utility = utilityService;
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("orderedtext-Provider")]
        [AllowAnonymous]
        public ActionResult GetOrderedTextByProvider(int providerId, string link)
        {
            try
            {
                var searchResult = utility.GetOrderedTextByProvider(providerId, link);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("orderedtext-utilities")]
        public ActionResult GetOrderedTextUtilities(int ProviderId, int ProfileId)
        {
            try
            {
                var searchResult = utility.GetOrderedTextUtilities(ProviderId, ProfileId);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<string>))]
        [HttpPost("orderedtext-utilities-options")]
        [Authorize]
        public ActionResult GetOrderedTextUtilitiesOptions(int ProviderId, int ProfileId)
        {
            try
            {
                var searchResult = utility.GetOrderedTextUtilitiesOptions(ProviderId, ProfileId);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpPost("save-orderedtext")]
        public ActionResult SaveOrderedTextUtilities([FromBody] SaveOrderTextUtilityRequest saveOrderTextUtilityRequest)
        {
            try
            {
                var returnValue = utility.SaveOrderedTextUtilities(saveOrderTextUtilityRequest.ProviderId, saveOrderTextUtilityRequest.Type, saveOrderTextUtilityRequest.Text);

                return Ok(returnValue);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("sitetext-utilities")]
        public ActionResult GetSiteTextUtilities(int ProviderId, int ProfileId)
        {
            try
            {
                var searchResult = utility.GetSiteTextUtilities(ProviderId, ProfileId);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpPost("save-text")]
        public ActionResult SaveTextUtilities([FromBody] SaveTextUtilityRequest saveTextUtilityRequest)
        {
            try
            {
                var returnValue = utility.SaveTextUtilities(saveTextUtilityRequest.ProviderId, saveTextUtilityRequest.Type, saveTextUtilityRequest.Subject, saveTextUtilityRequest.Text, saveTextUtilityRequest.IPId);

                return Ok(returnValue);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        public const string PartialFileNameConstant = "partialFileName";
        public const string StoreTypeConstant = "storeType";
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FileContentResult))]
        [HttpGet("download-file")]
        public ActionResult DownloadFile(string partialFileName, FileStoreType storeType)
        {
            try
            {
                if (storeType == FileStoreType.DefaultFolder) return BadRequest("Need store type");

                if (!fileService.Exists(storeType, partialFileName))
                    return NotFound("File not found");

                byte[] byteArray = fileService.ReadFileInBytes(storeType, partialFileName);
                var ext = Path.GetExtension(partialFileName).TrimStart('.');
                return new FileContentResult(byteArray, $"application/{ext}");
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<Newsletter>))]
        [HttpPost("news-letter")]
        public ActionResult<IEnumerable<Newsletter>> DownloadNewsLetter(int providerId, int platform)
        {
            try
            {
                var list = utility.GetNewsletter(providerId, platform);
                return Ok(list);
            }
            catch(Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
    }
}
