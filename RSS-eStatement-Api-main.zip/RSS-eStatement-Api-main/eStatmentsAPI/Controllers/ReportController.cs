﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
using System.Text;
using eStatmentsAPI.Models;
using System.IO;
using Microsoft.Net.Http.Headers;

namespace eStatmentsAPI.Controllers
{
    [Route("report")]
    [ApiController]
    [Authorize]
    public class ReportController : ControllerBase
    {
        IFileService fileService;
        IReportService report;
        IConfiguration configuration;
        IStatementService statementService;
        public ReportController(IReportService reportservice, 
            IConfiguration configuration,IFileService fileService,
            IStatementService statementService)
        {
            this.statementService = statementService;
            this.report = reportservice;
            this.configuration = configuration;
            this.fileService = fileService;
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AuditList))]
        [HttpPost("audit-report")]
        public ActionResult GetAuditReportDetails(AuditReportRequest req)
        {
            try
            {
                var searchResult = report.GetAuditReportDetails(req);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserReportList))]
        [HttpPost("user-report")]
        public ActionResult GetUserReportDetails(UserReportRequest req)
        {
            try
            {
                var searchResult = report.GetUserReportDetails(req);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LookupModel))]
        [HttpPost("audit-types")]
        public ActionResult GetAuditTypes(bool accept, bool validationcode, bool assetretention, bool handshake)
        {
            try
            {
                var searchResult = report.GetAuditTypes(accept, validationcode, assetretention, handshake);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LookupModel))]
        [HttpPost("statuscodes")]
        public ActionResult GetStatusCodes(bool accept, bool validationcode, bool match)
        {
            try
            {
                var searchResult = report.GetStatusCodes(accept, validationcode, match);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SponsorSearchResult>))]
        [HttpPost("sponsor-search")]
        public ActionResult<IEnumerable<SponsorSearchResult>> SponsorSearch(SponsorSearch data)// //  qSponsorSearch  32
        {
            try
            {
                return Ok(report.SponsorSearch(data));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }


        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SummaryReportResult>))]
        [HttpPost("summary-reports")]
        public ActionResult<IEnumerable<SummaryReportResult>> SummaryReports(SummaryReport data) //  pGetSummaryReport 83  SponsorManager.cfc
        {
            try
            {
                return Ok(report.SummaryReport(data));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SponsorProfiles>))]
        [HttpGet("sponsor-profiles")]
        public ActionResult<IEnumerable<SponsorProfiles>> SponsorProfiles() //  qGetSponsorProfiles 108  SponsorManager.cfc nw_GetSponsorProfiles   117
        {
            try
            {
                return Ok(report.GetSponsorProfiles());
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SponsorPlans>))]
        [HttpGet("sponsor-plans")]
        public ActionResult<IEnumerable<SponsorPlans>> SponsorPlans(int p_PPL_Spon_ID) //  //  qGetSponsorPlans    nw_GetSponPlan2 144  SponsorManager.cfc 
        {
            try
            {
                return Ok(report.SponsorPlans(p_PPL_Spon_ID));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
        //qGetSponsor    nw_GetSponAdministrator     174  SponsorManager.cfc 
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SponsorAdministrator))]
        [HttpGet("sponsor-administrator")]
        public ActionResult<SponsorAdministrator> SponsorAdministrator(string p_spad_id) //qGetSponsor    nw_GetSponAdministrator     174  SponsorManager.cfc 
        {
            try
            {
                return Ok(report.SponsorAdministrator(p_spad_id));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SponsorAdministrator))]
        [HttpPost("sponsor-administrator")]
        public ActionResult<bool> UpdateSponsorAdministrator(SponsorAdministrator data) //manageSponsor    nw_UpdSponAdministrator     194  SponsorManager.cfc 
        {
            try
            {
                return Ok(report.UpdateSponsorAdministrator(data));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FileContentResult))]
        [HttpPost("audit-report/download")]
        public ActionResult DownloadAuditReportDetails(DownloadAuditReportRequest req)
        {
            try
            {
                var filename = $"{req.ProviderID}{DateTime.Now.ToString("MMddyyyy")}_{DateTime.Now.ToString("hhmmss")}.csv";
                string list_order = string.Empty;
                switch (req.UseSSNPin)
                {
                    case 0:
                        list_order = "fname,lname,acctnumber,auditdate,auditDesc,planNum";
                        break;
                    case 1:
                        list_order = "fname,lname,acctnumber,ssn,auditdate,auditDesc,planNum";
                        break;
                    case 2:
                        list_order = "fname,lname,ssn,auditdate,auditDesc,planNum";
                        break;
                    default:
                        list_order = "fname,lname";
                        break;
                }

                if (req.AuditCode == 4 ) 
                    list_order = $"{list_order},statusname";

                var searchResult = report.GetAuditReportDetails(req);
                var fileData = fileService.GenerateCSVFile(searchResult.List, list_order);
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(fileData);
                return Ok(new FileContentResult(bytes, new MediaTypeHeaderValue("application/csv"))
                {
                    FileDownloadName = filename
                });
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FileContentResult))]
        [HttpPost("user-report/download")]
        public ActionResult DownloadUserReportDetails(DownloadUserReportRequest req)
        {
            try
            {
                var filename = $"{req.ProviderID}{DateTime.Now.ToString("MMddyyyy")}_{DateTime.Now.ToString("hhmmss")}.csv";
                var list_order = string.Empty;

                switch (req.UseSSNPin)
                {
                    case 0:
                            list_order = "fname,lname,acctnumber,email,statusName,planNum";
                            break;
                    case 1:
                            list_order = "fname,lname,acctnumber,ssn,email,statusName,planNum";
                            break;
                    case 2:
                            list_order = "fname,lname,ssn,email,statusName,planNum";
                            break;
                    default:
                            list_order = "fname,lname";
                        break;
                }

                var searchResult = report.GetUserReportDetails(req);
                var fileData = fileService.GenerateCSVFile(searchResult.List, list_order);
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(fileData);
                return Ok(new FileContentResult(bytes,new MediaTypeHeaderValue("application/csv"))
                {
                    FileDownloadName = filename
                });
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PhysicalFileResult))]
        [HttpPost("report-repo/download")]
        public ActionResult Download(DownloadReportRepoRequest request)
        {
            //#if DEBUG
            //            var testFile = @"C:\Temp\test.pdf";
            //            var ext2 = Path.GetExtension(testFile);
            //            return new PhysicalFileResult(testFile, $"application/{ext2}");
            //#endif

            var parts = request.FileName.Split('_');
            if (parts.Length != 3)
                return BadRequest();

            var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(request.ProviderId);
            var plans = statementService.GetParticipantPlans(new ParticipantPlanRequest()
            {
                SS_IdentTable = configuration["application:sSS_IdentTable"],
                Part_id = request.PartId,
                ProvId = new string(provider.ProvID),
                UID = request.UID ,
                Plannum = request.PlanNum
            });

            var planNums = plans.Select(x => x.plan_num);

            var iProvID = parts[0];
            var sPlanNum = parts[1];
            var sUserID = parts[2];
            var sFullFilePath = $"{iProvID}\\{request.Date}\\{sPlanNum}\\{request.FileName}";

            if (!planNums.Contains(sPlanNum) || !sUserID.Equals(request.UID, StringComparison.InvariantCultureIgnoreCase) ||
                iProvID.Equals(new string(provider.ProvID)))
                return BadRequest("You do not have the proper credentials to view this report!");
            else if (fileService.Exists(FileStoreType.IndividualPDF_Path, sFullFilePath))
                return NotFound("We're sorry - the file you requested is not available.");

            var ext = Path.GetExtension(sFullFilePath).Trim('.');
            return new PhysicalFileResult(sFullFilePath, $"application/{ext}");
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PhysicalFileResult))]
        [HttpPost("audit-report-path")]
        public ActionResult GetDataAuditReport(int approvalId, string provId)
        {
            string fullFilePath = "";
            try
            {
                var file = statementService.GetDataAuditReport(approvalId, provId);

                if (file != "")
                    fullFilePath = fileService.GetRootPath(FileStoreType.AuditReportsDirPath) + @"\" + provId + @"\" + file;

                if (!System.IO.File.Exists(fullFilePath))
                {
                    return NotFound("We're sorry - the file you requested is not available.");
                }

                byte[] bytes = System.IO.File.ReadAllBytes(fullFilePath);
                return Ok(new FileContentResult(bytes, $"application/txt"));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<SponsorSummaryReports>))]
        [HttpGet("sponsor-summary-report")]
        public ActionResult<List<SponsorSummaryReports>> SponsorSummaryReports(int p_providerid, int p_spon_id) //Summary.cfm
        {
            try
            {

                List<SponsorSummaryReports> dataToSend =new List<SponsorSummaryReports>();
                List<NWSummaryReports> data;
                string temp = report.GetSponsorName(p_spon_id).FirstOrDefault();
                data =report.SponsorSummaryReports( p_providerid,  p_spon_id);
                for (int i=0;i<data.Count;i++)
                {

                    dataToSend.Add(new SponsorSummaryReports()
                    {
                        Summ_FileName = data[i].Summ_FileName,
                        Summ_Text = data[i].Summ_Text,
                        SPON_Name = temp,
                        //<li><a href="servefile.cfm?version=4&filename=#trim(SUMM_FileName)#">#trim(SUMM_Text)#</a></li>
                    });
                }
                return Ok(dataToSend);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }


        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<SponsorSummaryReports>))]
        [HttpGet("sponsor-summary-report")]
        public ActionResult<List<SponsorSummaryReports>> SponsorSummaryReportsBySponId(int providerId, int sponId) //Summary.cfm
        {
            try
            {
                var list = GetSummaryReports(providerId, sponId);
                return Ok(list);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<SponsorSummaryReports>))]
        [HttpGet("sponsor-summary-report-spad")]
        public ActionResult<List<SponsorSummaryReports>> SponsorSummaryReportsBySpadId(int providerid, int spadId) //Summary.cfm
        {
            try
            {
                var spad = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(spadId);
                var list = GetSummaryReports(providerid, spad.SPAD_SPON_ID);
                return Ok(list);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        private List<SponsorSummaryReports> GetSummaryReports(int providerId, int sponId)
        {
            List<SponsorSummaryReports> dataToSend = new List<SponsorSummaryReports>();
            List<NWSummaryReports> data;
            string temp = report.GetSponsorName(sponId).FirstOrDefault();
            data = report.SponsorSummaryReports(providerId, sponId);

            foreach (var item in data)
            {
                dataToSend.Add(new SponsorSummaryReports()
                {
                    PartialFileName = item.PartialFileName,
                    Summ_FileName = item.Summ_FileName,
                    Summ_Text = item.Summ_Text,
                    SPON_Name = temp,
                    //<li><a href="servefile.cfm?version=4&filename=#trim(SUMM_FileName)#">#trim(SUMM_Text)#</a></li>
                });
            }
            return dataToSend;
        }
    }
}
