﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsAPI.Models;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using eStatmentsAPI.Authorization;
using System.Text;
using Common.Utilities;
using Statements.Process;
using Microsoft.Extensions.Logging;

//#define DLL
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eStatmentsAPI.Controllers
{
    [Route("participant")]
    [ApiController]
    [Authorize]
    public class ParticipantController : ControllerBase
    {
        IParticipantService participant;
        IConfiguration configuration;
        IMailerService mailer;
        ILogger<ParticipantController> _logger;

        public ParticipantController(IParticipantService participantService, 
            IConfiguration configuration, IMailerService mailerService,
            ILogger<ParticipantController> logger)
        {
            this._logger = logger;
            this.participant = participantService;
            this.configuration = configuration;
            this.mailer = mailerService;
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IsEditableResponse))]
        [HttpPost("iseditable")]
        public ActionResult IsEditable(int providerid, string uid)
        {
            try
            {
                if (providerid == 0) return BadRequest("Please provide provider id.");
                var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(providerid);
                if (provider == null) return NotFound("Unable to find provider.");

                var list = participant.IsParticipantEditable(provider.UseSSNPIN == 1, providerid, new string(provider.ProvID), uid);
                IsEditableResponse response = new IsEditableResponse()
                {
                    is_editable = list?.Count > 0,
                    participant_UUID = list?.FirstOrDefault() ?? string.Empty
                };
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<DateTime>))]
        [HttpPost("statement/dates")]
        public ActionResult<IEnumerable<DateTime>> StatementDatesAction(GetStatementDatesRequest p)
        {
            try
            {
                var list = participant.GetStatementDates(p);
                return Ok(list);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
#if DLL
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<string>))]
        [HttpPost("statement/process")]
        [AllowAnonymous]
        public ActionResult<string> GetNameToProcessStatement(NameToProcessStatementRequest p)
        {
            try
            {
                var list = participant.GetNameToProcessStatement(p);
                var firstName = string.Join(',', list.Select(x => x.FNAME));
                var lastName = string.Join(',', list.Select(x => x.LNAME));

                //< cfset nameList = ListAppend(nameList, trim(qGlName & LEFT(qGfName, 1)), ",") >
                var nameList = string.Join(',', list.Select(x => x.LNAME + (x.FNAME.Length >= 1 ? x.FNAME[0]: string.Empty)));

                var asm = Assembly.LoadFile(configuration["StatementsDll"]);
                var typ = asm.GetType("Statements.Process.MultipleStatementProcessor");
                var method = typ.GetMethod("ProcessStatement");

                var result = method.Invoke(Activator.CreateInstance(typ), new object[]
                {
                    firstName, lastName, nameList, p.statementDates,
                    p.email, p.isOutputToFTP, p.isProcessAll, p.isSingleFile, p.neptuneCustNo, p.partId, p.planNum, p.plan_num,
                    p.prov_id, p.uid, p.userType, p.providerid, p.isSuperSponsor, p.assetRetention, p.agentID, p.iSID,
                    p.hideSensitivePlans, p.useSSNPin
                });

                return Ok((result ?? "").ToString());
                //var returnString = new Statements.Process.MultipleStatementProcessor().ProcessStatement(firstName, lastName, nameList, p.statementDates,
                //    p.email, p.isOutputToFTP, p.isProcessAll, p.isSingleFile, p.neptuneCustNo, p.partId, p.planNum, p.plan_num,
                //    p.prov_id, p.uid, p.userType, p.providerid, p.isSuperSponsor, p.assetRetention, p.agentID, p.iSID, 
                //    p.hideSensitivePlans, p.useSSNPin);
                //return Ok(returnString);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
#else
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<string>))]
        [HttpPost("statement/process")]
        [AllowAnonymous]
        public ActionResult<string> GetNameToProcessStatement(NameToProcessStatementRequest p)
        {
            try
            {
                var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(p.ProviderId);
                p.ProvId = new string(provider.ProvID);
                p.NeptuneCustNo = provider.NeptuneCustNo;
                p.AssetRetention = provider.AssetRetention;
                p.UseSSNPin = provider.UseSSNPIN;

                if (p.AdminId > 0)
                {
                    var admin = eStatmentsDAC.BLL.Administrator.GetByAdministratorID(p.AdminId);
                    p.HideSensitivePlans = admin.hideSensitivePlans;
                    p.UserType = "admin";
                }
                else if (p.SpadId > 0)
                {
                    var spad = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(p.SpadId);
                    var spon = eStatmentsDAC.BLL.Sponsor.GetBySPON_ID(spad.SPAD_SPON_ID);
                    p.IsSuperSponsor = spon.SPON_IsSuperSponsor;
                    p.UserType = "sponsor";
                    p.SponId = spad.SPAD_SPON_ID;
                }
                else
                    return BadRequest("Can be either a Admin or Sponsor");
                
                var nameAndPartIds = participant.GetNameToProcessStatement(p);
                p.PartId = string.Join(',', nameAndPartIds.PartIds);

                var list = nameAndPartIds.NameList;                
                var firstName = string.Join(',', list.Select(x => x.FNAME));
                var lastName = string.Join(',', list.Select(x => x.LNAME));
                var uid = string.Join(',', p.Uids);
                //< cfset nameList = ListAppend(nameList, trim(qGlName & LEFT(qGfName, 1)), ",") >
                var nameList = string.Join(',', list.Select(x => x.LNAME + (x.FNAME.Length >= 1 ? x.FNAME[0]: string.Empty)));

                var processor = new MultipleStatementProcessor(mailer);
                var response = processor.ProcessStatmentGeneration(firstName, lastName, nameList, p.StatementDates,
                    p.Email, p.IsOutputToFTP, p.IsProcessAll, p.IsSingleFile, p.NeptuneCustNo, p.PartId, p.PlanNum, p.PlanNumList,
                    p.ProvId, uid, p.UserType, p.ProviderId.ToString(), p.IsSuperSponsor, p.AssetRetention, p.AgentID, p.SponId.ToString(),
                    p.HideSensitivePlans , p.UseSSNPin);

#if DEBUG
#else
                _logger.Log(LogLevel.Information, string.Join(',', response.MissingPdfFiles));
                response.MissingPdfFiles.Clear();
#endif

                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
#endif
        private const string pLName = "pLName";
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SSIdentPartIDResponse))]
        [HttpPost("statement/search/ss_ident_partid")]
        public ActionResult<SSIdentPartIDResponse> GetStatements(SSIdentSearchRequest req)
        {
            try
            {
                if (req.SSIdentRequest.SearchBy == pLName && req == null)
                    return BadRequest($"For SearchBy : {pLName} needs participants request.");

                req.SearchRequest.FillRemainingProperties();
                
                if (req.SSIdentRequest.IsSponsor)
                {
                    var sponAdmin = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(req.SearchRequest.SpadID);
                    var spon = eStatmentsDAC.BLL.Sponsor.GetBySPON_ID(sponAdmin.SPAD_SPON_ID);
                    req.SSIdentRequest.PlanName = req.SSIdentRequest.ProvID.ToUpper().Trim() + spon.SPON_Num.Trim();
                }

                if (req.SSIdentRequest.SearchBy == pLName)
                {
                    req.SearchRequest.Limit = 0;
                    req.SearchRequest.SortField = "lname";
                    var searchResult = participant.GetSearchParticipants(req.SearchRequest, out int totalCount);
                    req.SSIdentRequest.PartList = searchResult.Select(x => x.PartId).ToArray();
                }

                var result = participant.GetSSIdentPartID(req.SSIdentRequest);
                
                foreach (var item in result.List)
                {
                    var dynamicDateString = item.DateSubmitted.ToString("yyyyMMdd_HHmmss");
                    if(req.SSIdentRequest.IsSponsor)
                    {
                        item.PartialFileName = $"{req.SSIdentRequest.ProvID}\\{req.SSIdentRequest.PlanName}\\{dynamicDateString}\\{item.FileName}";
                    }
                    else
                    {
                        item.PartialFileName = $"{req.SSIdentRequest.ProvID}\\{dynamicDateString}\\{item.FileName}";
                    }
                }

                return Ok(result);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SearchedParticipantsResponse))]
        [HttpPost("statement/search")]
        //[EstatementAuthorize(CLAIM_TYPES.ROLE, CLAIM_VALUES.ADMIN)]
        //[EstatementAuthorize]
        public ActionResult<SearchedParticipantsResponse> SearchStatements(SearchParticipantRequest req)
        {
            try
            {
                req.FillRemainingProperties();
                var searchResult = participant.GetSearchParticipants(req, out int totalCount);

                foreach (var item in searchResult)
                    item.PartId = item.PartId.MaskCharacter();

                return Ok(new SearchedParticipantsResponse() { List = searchResult, TotalCount = totalCount });
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<ParticipantResponse>))]
        [HttpPost]
        public ActionResult<ParticipantResponse> GetParticipant(ParticipantRequest req)
        {
            try
            {
                req.FillRemainingFields();
                var searchResult = participant.GetParticipant(req);
                
                if(searchResult == null) return NotFound();

                if (searchResult.MI == "\0")
                    searchResult.MI = String.Empty;
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ParticipantUserIDResponse))]
        [HttpPost("userid")]
        public ActionResult<ParticipantUserIDResponse> GetParticipantUserID(ParticipantUserIDRequest req)
        {
            try
            {
                var searchResult = participant.GetParticipantUserID(req);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(decimal))]
        [HttpGet("part_count")]
        public ActionResult<decimal> GetSS_IdentCount(string part_id)
        {
            try
            {
                var count = participant.GetSSIdentCount(part_id);
                return Ok(count);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(decimal))]
        [AllowAnonymous]
        [HttpPut("")]
        public ActionResult<decimal> InsertParticipant(ParticipantInfoRequest info)
        {
            try
            {
                info.FillRemainingfields();
                
                var charList = Guid.NewGuid().ToString().ToCharArray().ToList();
                charList.RemoveAt(charList.LastIndexOf('-'));
                info.participantuuid = new String(charList.ToArray());

                var id = participant.InsertParticipant(info);
                return Ok(id);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ParticipantInfoRequest))]
        [HttpGet("empty")]
        public ActionResult<ParticipantInfoRequest> Empty_participant()
        {
            try
            {
                return Ok(new ParticipantInfoRequest());
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [HttpPatch]
        public ActionResult UpdateParticipant(PatchParticipant info)
        {
            try
            {
                participant.UpdateParticipant(info);
                if (!string.IsNullOrEmpty(info.uuid))
                    participant.UpdateSSIdent(info.lname, info.fname, info.uuid);

                return NoContent();
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PatchParticipant))]
        [HttpGet("empty_patch")]
        public ActionResult<PatchParticipant> EmptyParticipantPatch()
        {
            try
            {
                return Ok(new PatchParticipant());
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("plan-list")]
       // [EstatementAuthorize(CLAIM_TYPES.ROLE, CLAIM_VALUES.ADMIN, CLAIM_VALUES.PARTICIPANTS)]
       //[EstatementAuthorize(CLAIM_TYPES.ROLE, CLAIM_VALUES.SPONSORS)]
        public ActionResult GetPlanList(PlanRequest req)
        {
            try
            {
                req.FillRemainingFields();
                var searchResult = participant.GetPlansByProviderId(req);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<PlanResponse>))]
        [HttpPost("sponsor-plan-list")]
        public ActionResult<IEnumerable<PlanResponse>> GetSponsorPlanList(int ISID)
        {
            try
            {
                var searchResult = participant.GetSponsorPlanList(ISID);
                return Ok(searchResult);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(PlanResponse))]
        [HttpPost("participant-unsubcribe")]
        public ActionResult GetParticipantUnsubcribeDetails(int iPID, int providerId)
        {
            try
            {
                participant.UpdateParticipant(iPID, "IN");
                string product = "eStatements";
                var result = participant.GetParticipantUnsubcribeDetails(iPID, providerId);

                if (result.UnsubscribeDetails.ApplicationType == "Statements")
                {
                    product = "eStatements";

                } else if (result.UnsubscribeDetails.ApplicationType == "edelivery")
                {
                    product = "eDelivery";
                }
                else if (result.UnsubscribeDetails.ApplicationType == "Both")
                {
                    product = "eCommunications";
                }

                if(result.ParticipantDetails.Email != "")
                {
                    string strBody = result.ParticipantDetails.FirstName + " " + result.ParticipantDetails.LastName + " /n/r /n/r" + result.UnsubscribeDetails.UnsubscribeEmailBodyMsg;
#if DEBUG
                    mailer.SendEmail(strBody, this.configuration.GetValue<string>(Constants.ToEmail), result.UnsubscribeDetails.UnsubscribeEmailSubjectMsg);
#else
                    mailer.SendEmail(strBody, result.ParticipantDetails.Email, result.UnsubscribeDetails.UnsubscribeEmailSubjectMsg);
#endif
                }

                if (result.UnsubscribeDetails.MailAccount != "")
                {
                    string subject = product + " Unsubscribe Notification";
                    string body = result.ParticipantDetails.FirstName + " " + result.ParticipantDetails.LastName + " has unsubscribed from " + product;
#if DEBUG
                    mailer.SendEmail(body, this.configuration.GetValue<string>(Constants.ToEmail), subject);
#else
                    mailer.SendEmail(body, result.UnsubscribeDetails.MailAccount, subject);
#endif
                }

                return Ok(result);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
    }
}