﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsDAC.BLL;
using eStatmentsDAC.Classes;
using eStatmentsDAC.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MMARDataApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using eStatmentsDAC.BLL;
using System.Threading.Tasks;
using System.Diagnostics.CodeAnalysis;
using StatusCodes = Microsoft.AspNetCore.Http.StatusCodes;
using eStatmentsAPI.Models;
using Common.Utilities;

namespace eStatmentsAPI.Controllers
{
    [Route("account")]
    [ApiController]
    [Authorize]
    //[EstatementAuthorize(CLAIM_TYPES.ROLE, CLAIM_VALUES.ADMIN)]
    public class AccountController : ControllerBase
    {
        IAccountService account;
        IConfiguration configuration;
        ICaptchaService captchaService;
        string flexProvIds = string.Empty;

        public AccountController(IAccountService accountService, ICaptchaService captchaService, IConfiguration configuration)
        {            
            this.account = accountService;
            this.configuration = configuration;
            this.captchaService = captchaService;
            flexProvIds = configuration["FlexProvIds"];
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AdminLinkResponse))]
        [HttpGet("captcha-provider")]
        [AllowAnonymous]
        public IActionResult GetCaptchaProvider(int capchaCount)
        {
            try
            {
                var captchaCode = captchaService.CreateCapchaCode(capchaCount);
                Response.Headers.Add(new KeyValuePair<string, Microsoft.Extensions.Primitives.StringValues>("CaptchaText", EncryptionHelper.MD5Hash(captchaCode)));
                Response.Headers.Add("Access-Control-Expose-Headers", "CaptchaText");
                return File(captchaService.GenerateCaptchaImage(200, 50, captchaCode), "image/png");
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AdminLinkResponse))]
        [HttpGet("captcha-validator")]
        [AllowAnonymous]
        public IActionResult CaptchaValidator(string inputCaptcha, string captchaCode)
        {
            try
            {
                var result = captchaService.ValidateCaptchaCode(inputCaptcha, captchaCode);
                return Ok(result);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AdminLinkResponse))]
        [HttpPost("active-provider")]
        public ActionResult GetActiveProvider(int providerId)
        {
            try
            {
                //pass 0 to get all the active provider
                var response = account.GetActiveProviders(providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(LookupModel))]
        [HttpPost("validate-provider")]
        [AllowAnonymous]
        public ActionResult CheckValidProvider(string provider)
        {
            try
            {
                //pass 0 to get all the active provider
                var response = account.CheckValidProvider(provider);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<string>))]
        [HttpPost("provider-assignedsite")]
        [AllowAnonymous]
        public ActionResult GetProviderAssignedSite(string provider)
        {
            try
            {
                //pass 0 to get all the active provider
                var response = account.GetProviderAssignedSite(provider);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<AdminLinkResponse>))]
        [HttpGet("sidebar-Links/admin")]
        public ActionResult GetAdminLinks(int providerId, int profileId)
        {
            try
            {
                var response = account.GetAdminLinks(providerId, profileId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<ParticipantLinkResponse>))]
        [HttpGet("sidebar-Links/participant")]
        public ActionResult GetParticipantLinks(int providerId)
        {
            try
            {
                var response = account.GetParticipantLinks(providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<SponsorLinkResponse>))]
        [HttpGet("sidebar-Links/sponsor")]
        public ActionResult GetSponsorLinks(int providerId, int spadId)
        {
            try
            {
                var response = account.GetSponsorLinks(providerId, spadId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(List<LookupModel>))]
        [HttpPost("profiles-details")]
        public ActionResult GetProfilesByProviderId(int providerId)
        {
            try
            {
                //pass 0 to get all the active provider
                var response = account.GetProfilesByProviderId(providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        //user maint action line 53
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [HttpPut("deactivate-administrator/{id}")]
        public ActionResult<string> DeactivateAdministrator(int id)
        {
            try
            {
                Administrator temp = eStatmentsDAC.BLL.Administrator.GetByAdministratorID(id);
                if (temp == null)
                    return NotFound("Cannot find Administratorid with that AdsministratorID");
                temp.Active = false;
                List<Administrator> toupdate = new List<Administrator>();
                toupdate.Add(temp);
                eStatmentsDAC.BLL.Administrator.BulkUpdate(toupdate, 1);
                return Ok("updated");
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Administrator))]
        [HttpGet("administrator-other-userid")]
        public ActionResult<spGetOtherAdministrator> otherAdministor(int AdministratorID, string UserID)//qGetUsername usermaintaction line 60
        {
            try
            {
                return Ok(account.GetOtherAdministrator(AdministratorID, UserID));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [HttpPut("administrator")]
        public ActionResult<string> UpdateAdministrator([FromBody] AdministratorUpdate data)// qUpdUser line 66
        {
            try
            {
                Administrator temp = eStatmentsDAC.BLL.Administrator.GetByAdministratorID(data.control_id);
                if (temp == null)
                    return NotFound("Cannot find Administratorid with that AdsministratorID");

                temp.LName = data.control_name;
                temp.FName = data.fname;
                temp.UserID = data.userid;
                if (data.password != "PLACEHOLDERVALUE1!")
                    temp.Password = data.password;
                temp.ProfileID = data.profileid;
                temp.failedAuthAttempts = data.failedAuthAttempts;
                temp.passwordEditByAdmin = true;
                if (data.hasSensitivePlans)
                    temp.hideSensitivePlans = data.hidesensitiveplans;
                if (data.isInternalUser)
                    temp.DTNUMBER = data.dtnumber;
                else if (data.isInternalUser && data.dtnumber != "")
                    temp.InternalUser = true;
                else
                    temp.InternalUser = data.isInternalUser;
                List<Administrator> toupdate = new List<Administrator>();
                toupdate.Add(temp);
                eStatmentsDAC.BLL.Administrator.BulkUpdate(toupdate, 1);
                return Ok("updated");
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ActionResult))]
        [HttpPost("administrator")]
        public ActionResult Administrator([FromBody] AdministratorCreate data) //qInsUser line 103 UserMaintAction
        {
            try
            {
                Administrator dataToInsert = new Administrator();

                dataToInsert.FName = data.fname;
                dataToInsert.LName = data.control_name;
                dataToInsert.EMail = "";
                dataToInsert.UserID = data.userid;
                dataToInsert.Password = data.userPassword;
                dataToInsert.ProfileID = data.profileid;
                dataToInsert.LastLogin = DateTime.Now;
                dataToInsert.ProviderID = data.ProviderID;
                dataToInsert.Active = true;
                var charList = Guid.NewGuid().ToString().ToCharArray().ToList();
                charList.RemoveAt(charList.LastIndexOf('-'));
                dataToInsert.administratorUUID = charList.ToArray();
                if (data.hasSensitivePlans)
                    dataToInsert.hideSensitivePlans = data.hidesensitiveplans;
                if (data.InternalUser)
                {
                    dataToInsert.DTNUMBER = data.dtnumber;
                    dataToInsert.InternalUser = data.isinternaluser;
                }
                List<Administrator> insertList = new List<Administrator>();
                insertList.Add(dataToInsert);
                eStatmentsDAC.BLL.Administrator.BulkInsert(insertList);
                return Ok();
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<AdministratorDetailsResponse>))]
        [HttpGet("administrator")]
        public ActionResult<IEnumerable<AdministratorDetailsResponse>> Administrator(int providerId)
        {
            try
            {
                var response = account.GetAdministrator(providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(spGetAdministratorByUserID))]
        [HttpGet("administrator-userid/{UserID}")]
        public ActionResult<spGetAdministratorByUserID> AdministratorUserID(string UserID)//qGetUsername usermaintaction line 104
        {
            try
            {
                return Ok(account.GetAdministratorUserID(UserID));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }


        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Administrator))]
        [HttpGet("administrator-empty")]
        public ActionResult<Administrator> EmptyAdministrator()//for shreys help
        {
            try
            {
                return Ok(new Administrator());
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<spGetProfilesByProviderID>))]
        [HttpGet("profiles")]
        public ActionResult<IEnumerable<spGetProfilesByProviderID>> Profiles(int ProviderID, bool Active = true)
        {
            try
            {
                return account.GetProfiles(ProviderID, Active);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<spGetAdministratorByProviderID>))]
        [HttpGet("all-links")]
        public ActionResult<IEnumerable<spGetAdminLinks_ProvAdminLinksByProviderID>> adminLinks_ProvAdminLinksByProviderID(int ProviderID) //"qGetAllLinks"	ProfileMaint.cfm line 15
        {
            try
            {
                return Ok(account.GetAdminLinks_ProvAdminLinksByProviderID(ProviderID));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<spGetProfileLinks_ProvAdminLinks>))]
        [HttpGet("links")]
        public ActionResult<IEnumerable<spGetProfileLinks_ProvAdminLinks>> ProfileLinks_ProvAdminLinks(int ProviderID, int control_id) //qGetLinks	ProfileMaint.cfm line 43
        {
            try
            {
                return Ok(account.GetProfileLinks_ProvAdminLinksByProviderID(ProviderID, control_id)); // remove last condition and ProfileLinks.PRLI_LinkID =  @LinkID
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [HttpDelete("profiles/{control_id}")]
        public ActionResult<bool> DeactivateProfiles(int control_id)// delete ProfileLinks, ProvAdminLinks		"qDelProfile""	ProfileMaintAction.cfm line 32
        {
            try
            {
                Profiles temp = eStatmentsDAC.BLL.Profiles.GetByProfileID(control_id);
                if (temp == null)
                    return NotFound(false);
                temp.Active = false;
                List<Profiles> toupdate = new List<Profiles>();
                toupdate.Add(temp);
                eStatmentsDAC.BLL.Profiles.BulkUpdate(toupdate, 1);
                return Ok(true);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [HttpPut("profiles/{control_id}")]
        public ActionResult<bool> UpdateProfiles(int control_id, string control_name, int ProviderID)// 	"qUpdProfile""	ProfileMaintAction.cfm line 42
        {
            try
            {
                Profiles temp = eStatmentsDAC.BLL.Profiles.GetByProfileID(control_id);
                if (temp == null)
                    return NotFound(false);
                if (temp.ProviderID != ProviderID)
                    return NotFound(false);
                temp.ProfileName = control_name;
                List<Profiles> toupdate = new List<Profiles>();
                toupdate.Add(temp);
                eStatmentsDAC.BLL.Profiles.BulkUpdate(toupdate, 1);
                return Ok(true);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(bool))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(bool))]
        [HttpDelete("profilelinks/{control_id}")]
        public ActionResult<bool> DeleteProfileLinks(int control_id)//		"qDeleteProfileLinks""	ProfileMaintAction.cfm line 47
        {
            try
            {

                return Ok(account.DeleteProfileLinksByPRLI_ProfileID(control_id));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ActionResult))]
        [HttpPost("profilelinks")]
        public ActionResult ProfileLinks(int control_id, [FromBody] int[] link_value) //qInsertProfileLinks and qInsertLogoutLink  line 77  ProfileMaintAction.cfm
        {
            try
            {
                List<ProfileLinks> toInsert = new List<ProfileLinks>();
                ProfileLinks data;
                for (int i = 0; i < link_value.Length; i++)
                {
                    data = new ProfileLinks();
                    data.PRLI_ProfileID = control_id;
                    data.PRLI_LinkID = link_value[i];
                    toInsert.Add(data);
                }

                eStatmentsDAC.BLL.ProfileLinks.BulkInsert(toInsert);
                return Ok();
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Profiles))]
        [HttpGet("profiles-empty")]
        public ActionResult<Profiles> EmptyProfiles()//for shreys help
        {
            try
            {
                return Ok(new Profiles());
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ActionResult))]
        [HttpPost("profiles")]
        public ActionResult AddProfiles(Profiles data) //qInsProfile   line 93  ProfileMaintAction.cfm
        {
            try
            {
                List<Profiles> toUpdate = new List<Profiles>();
                toUpdate.Add(data);
                eStatmentsDAC.BLL.Profiles.BulkInsert(toUpdate);
                return Ok();
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpGet("max-profile")]
        public ActionResult<int> MaxProfileID(int ProviderID)//for shreys help
        {
            try
            {
                return Ok(account.GetMaxProfileID(ProviderID));
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        /// <summary>
        /// This "auth" api is a hack to generate access token which will be used to call.
        /// MMApi hosted in CSH legacy servers. Dont use this auth for any other purpose.
        /// This "auth" api needs to be authenticated using token from keycloak.
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("auth")]
        [AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult Auth([FromBody] AuthUser user)
        {
            try
            {
                using (eStatementDBContext context = new eStatementDBContext(configuration))
                {
                    var entity = from login in context.AdminEntity
                                 where
                                       login.providerid == user.clientid &&
                                       login.userId.Equals(user.username)
                                 select (login);

                    if (entity == null || entity.Count() == 0)
                    {
                        return new OkObjectResult("User is not valid for the given client");
                    }
                }

                string userID = string.Empty;
                // We have a valid user
                var response = ComposeToken(userID, user.username);
                return new OkObjectResult(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserDetailsResponse))]
        [HttpPost("user-details")]
        public ActionResult GetUserDetails(string userId, string role, int providerId)
        {
            try
            {
                var response = account.GetUserDetails(userId, role, providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpPost("update-lastlogin")]
        public ActionResult UpdateLastLogin(int id, string role)
        {
            try
            {
                var response = account.UpdateLastLogin(id, role);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [HttpGet("is-flex-provid")]
        public ActionResult IsFlexProvId(string provId)
        {
            return Ok(flexProvIds.Contains(provId));
        }

        /// <summary>
        ///     Generates the internals of the JWT
        /// </summary>
        /// <param name="userId">
        ///     Internal identifier for the user requesting
        ///     the token
        /// </param>
        /// <param name="username">
        ///     Username for the user requesting the token
        /// </param>
        /// <returns>
        ///     Internals of the JWT
        /// </returns>
        private async Task<dynamic> ComposeToken(string userId, string username)
        {
            MMApi.Controllers.AccountController ac = new MMApi.Controllers.AccountController(configuration, null);

            var response = new
            {
                access_token = await ac.generateToken(userId, username),
                refresh_token = string.Empty,
                expires_in = Convert.ToInt32(configuration["JWT:ValidFor"]),
                token_type = "Bearer"
            };

            return response;
        }
    }
}
