﻿using Common.Utilities;
using eStatmentsAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Statements.Business.MultipleStatement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;
        IConfiguration configuration;
        IWebHostEnvironment webHostEnvironment;
        IMailerService mailservice;
        IFileService fileService;

        public WeatherForecastController(ILogger<WeatherForecastController> logger,
            IConfiguration configuration, IWebHostEnvironment webHostEnvironment, 
            IMailerService mailservice,
            IFileService fileService)
        {
            this.fileService = fileService;
            this.mailservice = mailservice;
            this.webHostEnvironment = webHostEnvironment;
            this.configuration = configuration;
            _logger = logger;
        }

        [HttpGet("anonymous")]
        [AllowAnonymous]
        public ActionResult Get_Test()
        {
            return Ok("Hello world");
        }

#if DEBUG
        [HttpGet("file-exists")]
        [AllowAnonymous]
        public ActionResult FileOperation(FileStoreType typeStore, string partialPath)
        {
            return Ok(fileService.ExistsV2(typeStore, partialPath));
        }

        [HttpGet("env-name")]
        [AllowAnonymous]
        public ActionResult Get_EnvironmentName()
        {
            return Ok(webHostEnvironment.EnvironmentName);
        }

        [HttpGet("setting")]
        [AllowAnonymous]
        public ActionResult Get_SettingValue(string key)
        {
            return Ok(configuration[key]);
        }

        [HttpGet("env")]
        [AllowAnonymous]
        public ActionResult Get_EnvDetail()
        {
            return Ok(webHostEnvironment);
        }

        [HttpPost("mail")]
        [AllowAnonymous]
        public ActionResult SendTestMail(string toEmail)
        {
            try
            {
                mailservice.SendEmail($"This is test mail {DateTime.Now.ToString()}", toEmail, $"Test mail {DateTime.Now.ToString()}");
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
#endif

        [HttpGet]
        [Authorize]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpPost("ftp")]
        [AllowAnonymous]
        public ActionResult TestFtp(FTPInfoExtended request)
        {
            var helper = new Statements.FTPHelper(request);
            helper.UploadFiles(new List<Statements.Business.TvpSSIdent>() { new Statements.Business.TvpSSIdent() { file_name = request.SourceFileName } }, new Statements.ProcessResponse());
            return Ok("Please check");
        }

        [HttpPost("ftp-ssl")]
        [AllowAnonymous]
        public ActionResult TestFtpSSL(FTPInfoExtended request)
        {
            var helper = new Statements.FTPHelper(request);
            helper.UploadFiles(new List<Statements.Business.TvpSSIdent>() { new Statements.Business.TvpSSIdent() { file_name = request.SourceFileName } }, new Statements.ProcessResponse());
            return Ok("Please check");
        }

        [HttpPost("ftp-ssh")]
        [AllowAnonymous]
        public ActionResult TestFtpSSH(FTPInfoExtended request)
        {
            var helper = new Statements.FTPHelper(request);
            helper.UploadFiles(new List<Statements.Business.TvpSSIdent>() { new Statements.Business.TvpSSIdent() { file_name = request.SourceFileName } }, new Statements.ProcessResponse());
            return Ok("Please check");
        }
    }

    public class FTPInfoExtended : FTPInfo
    {
        public string SourceFileName { get; set; }
        public string DestinationFolderName { get; set; }
    }
}
