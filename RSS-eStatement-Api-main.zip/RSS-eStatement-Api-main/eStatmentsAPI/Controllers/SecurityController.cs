﻿using Common.Extensions;
using Common.Interfaces;
using eStatmentsAPI.Models;
using eStatmentsDAC.Service.Interfaces;
using eStatmentsDAC.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eStatmentsAPI.Controllers
{
    [Route("security")]
    [ApiController]
    [Authorize]
    public class SecurityController : ControllerBase
    {
        ISecurityService security;
        public SecurityController(ISecurityService securityService)
        {
            this.security = securityService;
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        [HttpPost("changepassword")]
        public ActionResult ChangePassword(ChangePassword cp)
        {
            try
            {
                switch (cp.TargetType)
                {
                    case TargetTypeEnum.Administrator:
                        return ParseChangePasswordProcResult(security.ChangePasswordAdministrator(cp.UniqueId, cp.Current_pass, cp.New_pass));
                    case TargetTypeEnum.Participant:
                        return ParseChangePasswordProcResult(security.ChangePasswordParticipant(cp.UniqueId, cp.Current_pass, cp.New_pass, cp.InitialLogin));
                    case TargetTypeEnum.Sponsor:
                        return ParseChangePasswordProcResult(security.ChangePasswordSponsor(cp.UniqueId, cp.Current_pass, cp.New_pass));
                    default:
                        return BadRequest("Invalid target type.");
                }
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        private ActionResult ParseChangePasswordProcResult(int result)
        {
            if (result == -1)
                return BadRequest("The value you entered for Current Password is invalid!");
            else if (result == -2)
                return BadRequest("The User ID and the Password should not be the same.");
            else if (result == 1)
                return NoContent();
            else
                return UnprocessableEntity();
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(int))]
        [HttpGet("failedattempt")]
        public ActionResult<int> GetFailedAttempts(string userid, TargetTypeEnum targetType)
        {
            try
            {
                int attempts = security.GetFailedAttempts(userid, targetType.TypeDescription());

                return Ok(attempts);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpPost("failedattempt")]
        public ActionResult LogFailedAttempts(string userid, ModeTypeEnum mode, TargetTypeEnum targetType)
        {
            try
            {
                security.LogFailedAuthAttempts(userid, mode.TypeDescription(), targetType.TypeDescription());

                return NoContent();
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<string>))]
        [HttpGet("uuid")]
        public ActionResult<IEnumerable<string>> GetUUID(string uuid, string providerId)
        {
            try
            {
                var list = security.GetUUID(uuid, providerId);
                return Ok(list);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status502BadGateway, Type = typeof(IErrorResponse))]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(DateTime))]
        [HttpGet("lastedit")]
        public ActionResult<DateTime> LastPasswordEdit(int id, TargetTypeEnum targetType)
        {
            try
            {
                var date = security.LastPasswordEdit(id, targetType.TypeDescription());
                return Ok(date);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }
    }
}