﻿using Common.Extensions;
using eStatmentsDAC;
using eStatmentsDAC.Classes;
using eStatmentsDAC.Service.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace eStatmentsAPI.Controllers
{
    [Route("sponsor")]
    [ApiController]
    public class SponsorController : ControllerBase
    {
        ISponsorAccessService sponsorAccessService;
        public SponsorController(ISponsorAccessService sponsorAccessService)
        {
            this.sponsorAccessService = sponsorAccessService;
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(SelectSponsorResponse))]
        [HttpPost("select")]
        public ActionResult SelectSponsor(SelectSponsorRequest selectSponsorRequest)
        {
            try
            {
                var response = sponsorAccessService.SelectSponsors(selectSponsorRequest);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetSponsorProfileResponse>))]
        [HttpGet("profiles")]
        public ActionResult GetSponsorProfiles([FromQuery] int sppf_spon_id = 0, [FromQuery] ActiveConditionEnum boolCondition = ActiveConditionEnum.True)
        {
            try
            {
                var response = sponsorAccessService.GetSponsorProfiles(sppf_spon_id, boolCondition);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetSponsorPlansResponse>))]
        [HttpGet("plans")]
        public ActionResult GetSponsorPlans(int sponID)
        {
            try
            {
                var response = sponsorAccessService.GetSponsorPlans(sponID);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetSponAdministratorDetailResponse>))]
        [HttpPost("administrator")]
        public ActionResult GetSponAdministrator(GetSponAdministratorDetailRequest request)
        {
            try
            {
                var response = sponsorAccessService.GetSponAdministrator(request);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetAllSponsorLinksResponse>))]
        [HttpGet("all-links")]
        public ActionResult GetAllSponsorLinks(int providerId)
        {
            try
            {
                var response = sponsorAccessService.GetAllSponsorLinks(providerId);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetAllSponsorLinksResponse>))]
        [HttpGet("all-links/profiles")]
        public ActionResult GetAllSponsorLinksForProfile(int spad_spon_id)
        {
            try
            {
                var response = sponsorAccessService.GetAllSponsorLinksForProfile(spad_spon_id);
                return Ok(response);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SponsorGridLinks>))]
        [HttpGet("profile/grid")]
        public ActionResult GetSponsorProfileGrid(int sponId, int sppfId)
        {
            var profile = eStatmentsDAC.BLL.SponProfiles.GetBySPPF_ID(sppfId);
            var links = sponsorAccessService.GetAllSponsorLinksForProfile(sponId);
            List<SponsorGridLinks> responses = new List<SponsorGridLinks>();
            var gridItem = new SponsorGridLinks()
            {
                ControlID = profile.SPPF_ID,
                ControlName = profile.SPPF_Name,
                Active = true
            };
            responses.Add(gridItem);
            foreach (var link in links)
            {
                var idList = sponsorAccessService.GetSponsorProfileGrid(sponId, profile.SPPF_ID, link.SpliID);
                if (idList.Count > 0)
                    gridItem.SponsorLinkIDs.Add(new SponsorLinkDetail() { SpliID = link.SpliID, Active = true });
                else
                    gridItem.SponsorLinkIDs.Add(new SponsorLinkDetail() { SpliID = link.SpliID, Active = false });
            }
            return Ok(responses);
        }

        [ProducesResponseType(StatusCodes.Status200OK)]
        [HttpGet]
        public ActionResult GetSponsor(int spon_id)
        {
            if (spon_id == 0)
                return BadRequest();

            try
            {
                var sponsor = eStatmentsDAC.BLL.Sponsor.GetBySPON_ID(spon_id);
                if (sponsor == null)
                    return NotFound();

                var sponsorResponse = new { ControlID = sponsor.SPON_ID, ControlName = sponsor.SPON_Name, Active = sponsor.SPON_Active, Updated = false };
                return Ok(sponsorResponse);
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<SponsorGridLinks>))]
        [HttpGet("grid")]
        public ActionResult GetSponsorGrid(int spon_id, int providerId)
        {
            var sponsor = eStatmentsDAC.BLL.Sponsor.GetBySPON_ID(spon_id);
            List<SponsorGridLinks> responses = new List<SponsorGridLinks>();
            var gridItem = new SponsorGridLinks()
            {
                ControlID = sponsor.SPON_ID,
                ControlName = sponsor.SPON_Name,
                Active = sponsor.SPON_Active
            };
            responses.Add(gridItem);
            var response = sponsorAccessService.GetAllSponsorLinks(providerId);
            foreach (var link in response)
            {
                var ids = sponsorAccessService.GetSponProvLinks(link.SpliID, sponsor.SPON_ID);
                if (ids.Count > 0)
                    gridItem.SponsorLinkIDs.Add(new SponsorLinkDetail() { SpliID = link.SpliID, Active = true });
                else
                    gridItem.SponsorLinkIDs.Add(new SponsorLinkDetail() { SpliID = link.SpliID, Active = false });
            }
            return Ok(responses);
        }

        [HttpPost("links")]
        public ActionResult UpdateSponsorLinkAction(SponsorGridLinks linkPackage)
        {
            try
            {
                if (linkPackage.Updated && linkPackage.ControlID > 0)
                {
                    var profiles = sponsorAccessService.GetSponsorProfiles(linkPackage.ControlID, ActiveConditionEnum.Skip);
                    if (profiles.Count == 0)
                    {
                        sponsorAccessService.NewSponsor(linkPackage);
                    }
                    else
                    {
                        sponsorAccessService.UpdateSponsorLink(linkPackage);
                    }
                }
            }
            catch (Exception ex)
            {
                return this.CreateExceptionResponse(ex);
            }
            return NoContent();
        }

        [HttpPost("profile")]
        public ActionResult UpdateSponsorProfileAction(int sponID, SponsorGridLinks linkPackage)
        {
            try
            {
                if (!linkPackage.Active && linkPackage.ControlID > 0)
                {
                    sponsorAccessService.DeActivateSponProfiles(linkPackage.ControlID, linkPackage.Active);
                }
                else if (linkPackage.Updated && linkPackage.ControlID > 0)
                {
                    sponsorAccessService.UpdateSponProfiles(linkPackage);
                }
                else if (linkPackage.Active && linkPackage.ControlID <= 0)
                {
                    sponsorAccessService.InsertSponProfiles(sponID, linkPackage);
                }
            }
            catch (Exception ex)
            {
                return this.CreateExceptionResponse(ex);
            }
            return NoContent();
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IEnumerable<GetSponAdministratorDetailResponse>))]
        [HttpPut("administrator")]
        public ActionResult PutSponAdministrator(int providerId, [FromBody] GetSponAdministratorDetailResponse request)
        {
            try
            {
                if (!request.Active && request.ControlID > 0)
                {
                    sponsorAccessService.DeActivateSponAdmin(request.ControlID);
                    return NoContent();
                }
                else if (request.Updated && request.ControlID > 0)
                {
                    var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(providerId);
                    var admin = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(request.ControlID);
                    if (sponsorAccessService.ValidateSponAdministrator(request.SpadUserID, request.ControlID))
                    {
                        admin.SPAD_LName = request.ControlName;
                        admin.SPAD_FName = request.SpadFName;
                        admin.SPAD_EMail = request.SpadEMail;
                        admin.SPAD_UserID = request.SpadUserID;
                        admin.SPAD_Password = request.SpadPassword;
                        admin.SPAD_SPPF_ID = request.SpadSppfID;
                        admin.failedAuthAttempts = 0;
                        admin.passwordEditByAdmin = true;

                        if (provider.AssetRetention)
                            admin.SPAD_AgentID = request.SpadAgentID;

                        if (request.IsInternalUser)
                        {
                            admin.DTNUMBER = request.DTNumber;
                            admin.INTERNAL_USER = request.IsInternalUser;
                        }

                        eStatmentsDAC.BLL.SponAdministrator.BulkUpdate(new List<eStatmentsDAC.BLL.SponAdministrator>() { admin }, 5);
                        return NoContent();
                    }
                    else
                        return BadRequest($"Error updating user {request.ControlName},{request.SpadFName}, User Name is not unique");
                }
                else if (request.Active && request.ControlID <= 0)
                {
                    var provider = eStatmentsDAC.BLL.Provider.GetByProviderID(providerId);
                    if (sponsorAccessService.ValidateSponAdministrator(request.SpadUserID, 0))
                    {
                        var admin = new eStatmentsDAC.BLL.SponAdministrator();
                        admin.SPAD_Num = request.SpadNum;
                        admin.SPAD_SPON_ID = request.SpadSponId;
                        admin.SPAD_FName = request.SpadFName;
                        admin.SPAD_LName = request.ControlName;
                        admin.SPAD_EMail = request.SpadEMail;
                        admin.SPAD_UserID = request.SpadUserID;
                        admin.SPAD_Password = request.SpadPassword;
                        admin.SPAD_SPPF_ID = request.SpadSppfID;
                        admin.SPAD_LastLogin = DateTime.Now;
                        admin.SPAD_Active = true;
                        if (provider.AssetRetention)
                            admin.SPAD_AgentID = request.SpadAgentID;

                        var charList = Guid.NewGuid().ToString().ToCharArray().ToList();
                        charList.RemoveAt(charList.LastIndexOf('-'));
                        admin.sponAdministratorUUID = charList.ToArray();

                        if (request.IsInternalUser)
                        {
                            admin.DTNUMBER = request.DTNumber;
                            admin.INTERNAL_USER = request.IsInternalUser;
                        }
                        eStatmentsDAC.BLL.SponAdministrator.BulkInsert(new List<eStatmentsDAC.BLL.SponAdministrator>() { admin });
                        return NoContent();
                    }
                    else
                        return BadRequest("UserId is not unique");
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception x)
            {
                return this.CreateExceptionResponse(x);
            }
        }

        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(string))]
        [HttpGet("name")]
        public ActionResult GetSponName(int spadID)
        {
            var spad = eStatmentsDAC.BLL.SponAdministrator.GetBySPAD_ID(spadID);
            if (spad == null) return BadRequest("Bad Spad ID");
            var sponsor =  eStatmentsDAC.BLL.Sponsor.GetBySPON_ID(spad.SPAD_SPON_ID);
            if (sponsor == null) return BadRequest("Bad Spon ID");
            return Ok(sponsor.SPON_Name);
        }
    }
}