﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eStatmentsAPI
{
    public class Constants
    {
        public const string ENotificationEMail = "Mail:ENotificationEMail";
        public const string StatementServer = "Mail:StatementServer";
        public const string ToEmail = "Mail:ToEmail";
    }
}
