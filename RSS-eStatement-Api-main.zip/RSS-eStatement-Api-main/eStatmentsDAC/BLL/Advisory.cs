/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : Advisory
/// Filename : Advisory.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for Advisory.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT228274]	08/04/2021 06:46:04 AM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class Advisory
	{
		#region Constructors / Destructors 
		public Advisory()
		{
		}
		#endregion
	}
}