/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : AngularAdminlinks
/// Filename : AngularAdminlinks.cs
/// Copyright: SS&C 2022
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for AngularAdminlinks.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	02/07/2022 14:16:18 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class AngularAdminlinks
	{
		#region Constructors / Destructors 
		public AngularAdminlinks()
		{
		}
		#endregion
	}
}