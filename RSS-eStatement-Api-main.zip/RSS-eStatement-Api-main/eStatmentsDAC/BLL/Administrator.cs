/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : Administrator
/// Filename : Administrator.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for Administrator.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT228274]	08/04/2021 06:46:01 AM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class Administrator
	{
		#region Constructors / Destructors 
		public Administrator()
		{
		}
		#endregion
	}
}