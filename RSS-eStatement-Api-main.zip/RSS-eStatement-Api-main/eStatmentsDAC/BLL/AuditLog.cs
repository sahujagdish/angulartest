/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : AuditLog
/// Filename : AuditLog.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for AuditLog.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT228274]	08/04/2021 06:46:06 AM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class AuditLog
	{
		#region Constructors / Destructors 
		public AuditLog()
		{
		}
		#endregion
	}
}