/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : AdminLinks
/// Filename : AdminLinks.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for AdminLinks.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT228274]	08/04/2021 06:46:03 AM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class AdminLinks
	{
		#region Constructors / Destructors 
		public AdminLinks()
		{
		}
		#endregion
	}
}