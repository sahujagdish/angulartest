/// -----------------------------------------------------------------------------
/// Project	 : eStatmentsDAC
/// Namespace: eStatmentsDAC.BLL
/// Class	 : AuditType
/// Filename : AuditType.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for AuditType.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT228274]	08/04/2021 06:46:07 AM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using eStatmentsDAC.DAL;

namespace eStatmentsDAC.BLL
{
	public partial class AuditType
	{
		#region Constructors / Destructors 
		public AuditType()
		{
		}
		#endregion
	}
}