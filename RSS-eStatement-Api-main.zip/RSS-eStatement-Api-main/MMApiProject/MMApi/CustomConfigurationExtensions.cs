﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace Settings
{
    #region using 
    using Microsoft.Extensions.Configuration;
    #endregion using

    public static class CustomConfigurationExtensions
    {
        public static IConfigurationBuilder AddEncryptedAndJsonFiles( this IConfigurationBuilder builder, string fileName, string basePath, bool optional, bool reloadOnChange = false )
        {
            string jsonFilePath = builder.GetFileProvider().GetFileInfo( fileName ).PhysicalPath;
            var encryptedConfiguration = new EncryptedConfigurationSource( jsonFilePath, basePath );

            return builder
                .AddJsonFile( fileName, optional, reloadOnChange )
                .Add( encryptedConfiguration );
        }
    }
}
