﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2019 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Controllers
{
    #region using
    using System;
    using System.Collections.Generic;
    using System.IdentityModel.Tokens.Jwt;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.ServiceModel;
    using System.Text;
    using System.Reflection;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using MMApi.Models;
    using MMApi.ViewModel;
    using Newtonsoft.Json;
    using Statements;
    using MMApi.Utilities;
    #endregion using

    [ApiController]
    [Produces( "application/json" )]
    [Route( "api/v1/[controller]" )]
    [EnableCors( "CorsPolicy" )]
    [ApiExplorerSettings( GroupName = "statements" )]
    public class StatementController : ControllerBase
    {
        #region fields
        private readonly IConfiguration configuration;
        private readonly ILogger logger;
        #endregion fields

        #region Contructor
        /// <summary>
        ///     Default constructor that uses deendancy injection
        ///     to get the configuraion
        /// </summary>
        /// <param name="config">
        ///     Constructed application configuation
        /// </param>
        public StatementController( IConfiguration configuration, ILogger<StatementController> logger )
        {
            this.configuration = configuration;
            this.logger = logger;

            logger.LogInformation( "Started Statements Controller" );
        }
        #endregion Constructor

        #region Extract
        /// <summary>
        ///     Approves a Statement Extract by its identifier
        /// </summary>
        /// <param name="id">
        ///     Statement Extract Identifier
        /// </param>
        /// <returns>
        ///     Status of the call for approval
        /// </returns>
        [HttpGet( "extract/{id}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ExtractPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> ApproveExtract( int id )
        {
            try
            {
                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();
                ApproveExtractRequest request = new ApproveExtractRequest( id );

                ApproveExtractResponse response = statementsSoap.ApproveExtractAsync( request ).Result;

                return Ok();
            }
            catch( Exception ex )
            {
                logger.LogError(ex, $"ApproveExtract Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the plans associated with the extract
        /// </summary>
        /// <param name="id">
        ///      Statement Extract Identifier
        /// </param>
        /// <returns>
        ///     List of plans for the extract and the deleted plans
        ///     have been identified
        /// </returns>
        [HttpGet( "extract/{id}/plans" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ExtractPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetExtractPlans( int id )
        {
            try
            {
                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();
                GetExtractActivePlansRequestBody activeBody = new GetExtractActivePlansRequestBody
                {
                    extractId = id
                };

                GetExtractActivePlansRequest requestActive = new GetExtractActivePlansRequest( activeBody );

                GetExtractDeletedPlansRequest requestDeleted = new GetExtractDeletedPlansRequest();
                GetExtractDeletedPlansRequestBody deletedBody = new GetExtractDeletedPlansRequestBody
                {
                    extractId = id
                };
                requestDeleted.Body = deletedBody;

                Task<GetExtractActivePlansResponse> responseActive = statementsSoap.GetExtractActivePlansAsync( requestActive );
                Task<GetExtractDeletedPlansResponse> responseDeleted = statementsSoap.GetExtractDeletedPlansAsync( requestDeleted );

                GetExtractActivePlansResponse activePlansResponse = await responseActive;
                GetExtractDeletedPlansResponse deletedPlansResponse = await responseDeleted;

                ExtractPlan[] activePlans = activePlansResponse.Body.GetExtractActivePlansResult;
                ExtractPlan[] deletedPlans = deletedPlansResponse.Body.GetExtractDeletedPlansResult;

                StatementExtractPlan plan = new StatementExtractPlan();

                List<StatementExtractPlan> response = new List<StatementExtractPlan>();
                foreach ( ExtractPlan ap in activePlans )
                {
                    plan = new StatementExtractPlan
                    {
                        ExternalPlanId = ap.ExternalPlanId,
                        PlanName1 = ap.PlanName1,
                        PlanName2 = ap.PlanName2,
                        IsDeleted = false
                    };

                    response.Add( plan );
                }

                foreach ( ExtractPlan ap in deletedPlans )
                {
                    plan = new StatementExtractPlan
                    {
                        ExternalPlanId = ap.ExternalPlanId,
                        PlanName1 = ap.PlanName1,
                        PlanName2 = ap.PlanName2,
                        IsDeleted = true
                    };

                    response.Add( plan );
                }

                return new OkObjectResult( response );
            }
            catch( Exception ex )
            {
                logger.LogError(ex, $"GetExtractPlans Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the llas marked for deletion within the extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract Identifier
        /// </param>
        /// <returns>
        ///     List of deleted plans for an extract
        /// </returns>
        [HttpGet( "extract/{id}/plans/deleted" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ExtractPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetExtractDeletedPlans( int id )
        {
            try
            {
                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                GetExtractDeletedPlansRequestBody deletedBody = new GetExtractDeletedPlansRequestBody
                {
                    extractId = id
                };

                GetExtractDeletedPlansRequest requestDeleted = new GetExtractDeletedPlansRequest( deletedBody );

                Task<GetExtractDeletedPlansResponse> responseDeleted = statementsSoap.GetExtractDeletedPlansAsync( requestDeleted );
                GetExtractDeletedPlansResponse deletedPlansResponse = await responseDeleted;

                ExtractPlan[] deletedPlans = deletedPlansResponse.Body.GetExtractDeletedPlansResult;

                StatementExtractPlan plan = new StatementExtractPlan();
                List<StatementExtractPlan> response = new List<StatementExtractPlan>();

                foreach ( ExtractPlan ap in deletedPlans )
                {
                    plan = new StatementExtractPlan
                    {
                        ExternalPlanId = ap.ExternalPlanId,
                        PlanName1 = ap.PlanName1,
                        PlanName2 = ap.PlanName2,
                        IsDeleted = true
                    };

                    response.Add( plan );
                }

                return new OkObjectResult( response );
            }
            catch( Exception ex )
            {
                logger.LogError(ex, $"GetExtractDeletedPlans Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Marks the given plans for deletion within the extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract Identifier
        /// </param>
        /// <param name="DeletedExternalds">
        ///     List of all the plan external Plan identifiers for the
        ///     plans to be delted
        /// </param>
        /// <returns>
        ///     Status of the callto mark plans as deleted
        /// </returns>
        [HttpPut( "extract/{id}/plans/deleted" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutExtractDeletedPlans( int id, [FromBody] List<string> DeletedExternalds )
        {
            try
            {
                var accessToken = HttpContext.Request.Headers[ "Authorization" ].ToString().Replace( "Bearer", string.Empty ).Trim();

                var tokenS = new JwtSecurityTokenHandler().ReadToken( accessToken ) as JwtSecurityToken;

                var nameId = tokenS.Claims.First( claim => claim.Type == "nameid" ).Value;

                StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                SaveExtactDeletedPlansRequest requestDeleted = new SaveExtactDeletedPlansRequest();
                SaveExtactDeletedPlansRequestBody deletedBody = new SaveExtactDeletedPlansRequestBody
                {
                    extractId = id
                };

                deletedBody.DeletedPlanExteralIds = new ArrayOfString();
                deletedBody.DeletedPlanExteralIds.AddRange( DeletedExternalds );
                deletedBody.userId = nameId.ToString();
                requestDeleted.Body = deletedBody;

                Task<SaveExtactDeletedPlansResponse> response = statementsSoap.SaveExtactDeletedPlansAsync( requestDeleted );
                SaveExtactDeletedPlansResponse deletedPlansResponse = await response;

                return new OkResult();
            }
            catch( Exception ex )
            {
                logger.LogInformation(ex.Message, $"PutExtractDeletedPlans Failure for id {id}", new object[] { DeletedExternalds });
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Get Statement Extract Approval Data
        /// </summary>
        /// <param name="id">
        ///     Statement Extract Identifier
        /// </param>
        /// <returns>
        ///     Eaxtract Approval Data
        /// </returns>
        [HttpGet("extract/{id}/data")]
        [Authorize]
        [ProducesResponseType(typeof(IEnumerable<ExtractPlan>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetExtractApprovalData(int id)
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"data/{id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();
                
                HttpResponseMessage response = await client.GetAsync(uri);
                //Checking the response is successful or not which is sent using HttpClient  
                if (response.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;
                    return new OkObjectResult(JsonConvert.DeserializeObject<dynamic>(json));
                }
                else
                {
                    return await Task.FromResult(BadRequest(new ApiResponse(400)));
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"GetExtractApprovalData Failure for id {id}", null);
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Gets PDF Proof for Extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract identifier
        /// </param>
        /// <returns>
        ///     PDF Stream
        /// </returns>
        [HttpGet("extract/{id}/getProof")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProof( int id )
        {
            try
            {
                return  GetStatementExtractReport( id, StatementReportFileType.Proof ).Result;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"GetProof Failure for id {id}");
                return new BadRequestObjectResult(new ApiResponse(400));
            }
        }

        /// <summary>
        ///     Starts Process to Generate PDF Proof for Extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract identifier
        /// </param>
        [HttpGet("extract/{id}/generateProof")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GenerateProof(int id)
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"GenerateProof/{id}";
                
                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();
                client.Timeout = TimeSpan.FromMinutes( 5 );
                
                var response = await client.GetAsync(uri);

                //Checking the response is successful or not which is sent using HttpClient  
                if( response.IsSuccessStatusCode )
                {
                    return new ObjectResult( response.Content.ReadAsStringAsync().Result );
                }
                else
                {
                    return new BadRequestObjectResult( response );
                }

            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"GenerateProof Failure for id {id}");
                return new BadRequestObjectResult(new ApiResponse(400));
            }
        }

        /// <summary>
        ///     Gets the last date a proof we creawted
        /// </summary>
        /// <param name="id">
        ///     Extract identifier to get the proof for
        /// </param>
        /// <returns>
        ///     Date of the last proof if it extsts
        /// </returns>
        [HttpGet( "extract/{id}/proof/date" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProofDate( int id )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"extract/{id}/proof/date";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if( response.IsSuccessStatusCode )
                {
                    return new ObjectResult( response.Content.ReadAsStringAsync().Result );
                }
                else
                {
                    return new BadRequestObjectResult( response );
                }
            }
            catch( Exception ex )
            {
                logger.LogError( ex, $"GenerateProofDate Failure for id {id}", null );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Get all the latest dates for proofs and list of report if it existes for a specific extract 
        ///     and report type
        /// </summary>
        /// <param name="extractids">
        ///     List of extracts to get the proof dates + reports for
        /// </param>
        /// <returns>
        ///     List of Extract Id's and the associated proof date + list of report
        /// </returns>
        [HttpPost( "extract/approvalinfo" )]
        [ProducesResponseType( typeof( IEnumerable<Plan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [Authorize]
        public IActionResult GetProofDatesandReport( [FromBody] List<int> extractids )
        {
            string uri = configuration["STATEMENTS:EndpointAddress"] + "extract";

            try
            {
                Dictionary<int, string> proofDates = new Dictionary<int, string>();
                Dictionary<int, List<StatementReportFileType>> reportTypes = new Dictionary<int, List<StatementReportFileType>>();

                ApprovalInformation info = new ApprovalInformation();
                List<ApprovalInformation> response = new List<ApprovalInformation>();


                Parallel.For( 0, extractids.Count, i =>
                {
                    HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                    var response1 = client.GetAsync( $"{uri}/{extractids[i]}/proof/date" ).Result;
                    var response2 = client.GetAsync( $"{uri}/{extractids[i]}/reports" ).Result;

                    //Checking the response is successful or not which is sent using HttpClient  
                    if ( response1.IsSuccessStatusCode )
                    {

                        //Storing the response details recieved from web api   
                        var proofDatejson = response1.Content.ReadAsStringAsync().Result;
                        proofDates.Add( extractids[i], proofDatejson );
                    }
                    else
                    {
                        proofDates.Add( extractids[i], "Error: " + response1.StatusCode.ToString() );
                    }

                    //Checking the response is successful or not which is sent using HttpClient  
                    if ( response2.IsSuccessStatusCode )
                    {
                        //Storing the response details recieved from web api   
                        var reportTypeResults = response2.Content.ReadAsStringAsync().Result;

                        int[] typearray = JsonConvert.DeserializeObject<int[]>( reportTypeResults );

                        List<StatementReportFileType> statementReportFileTypes = ((StatementReportFileType[])(object)typearray).ToList();
                        ;
                        reportTypes.Add( extractids[i], statementReportFileTypes );
                    }

                }
                );

                info = new ApprovalInformation
                {
                    proofDates = proofDates,
                    reportTypes = reportTypes
                };

                response.Add( info );


                //Storing the response details recieved from web api   
                return new OkObjectResult( response );

            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProofDates Failure {ex.Message}", null );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Get all the latest dates for proofs 
        /// </summary>
        /// <param name="extractids">
        ///     List of extracts to get the proof dates for
        /// </param>
        /// <returns>
        ///     List of Extract Id's and the associated proof date
        /// </returns>
        [HttpPost( "extract/proofdates" )]
        [ProducesResponseType( typeof( IEnumerable<Plan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [Authorize]
        public IActionResult GetProofDates( [FromBody] List<int> extractids )
        {
            string uri = configuration["STATEMENTS:EndpointAddress"] + "extract";

            try
            {
                Dictionary<int, string> proofDates = new Dictionary<int, string>();
                Parallel.For( 0, extractids.Count, i =>
                {
                    HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                  
                    var response = client.GetAsync( $"{uri}/{extractids[i]}/proof/date" ).Result;

                    //Checking the response is successful or not which is sent using HttpClient  
                    if ( response.IsSuccessStatusCode )
                    {

                        //Storing the response details recieved from web api   
                        var proofDatejson = response.Content.ReadAsStringAsync().Result;
                        proofDates.Add( extractids[i], proofDatejson );
                    }
                    else
                    {
                        proofDates.Add( extractids[i], "Error: " + response.StatusCode.ToString() );
                    }
                }
                );

                //Storing the response details recieved from web api   
                return new OkObjectResult( proofDates );

            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProofDates Failure {ex.Message}", null );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Gests a report if it existes for a specific extract 
        ///     and report type
        /// </summary>
        /// <param name="id">
        ///     Extract identifier to get the report for
        /// </param>
        /// <param name="reportType">
        ///     Type of report to retrieve
        /// </param>
        /// <returns>
        ///     FileSteamof the report if it exists
        /// </returns>
        [HttpGet( "extract/{id}/reports/{reportType}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetStatementExtractReport( int id, StatementReportFileType reportType )
        {
            string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"extract/{id}/reports/{reportType}";

            try
            {
                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if( response.IsSuccessStatusCode )
                {
                    FieldInfo fieldInfo = reportType.GetType().GetField( reportType.ToString() );
                    object[] customAttributes = fieldInfo.GetCustomAttributes( typeof( StatementReportTypeAttribute ), false );

                    string mimeType = ((StatementReportTypeAttribute)customAttributes[0]).MimeType;
                    string filenameLookup = ((StatementReportTypeAttribute)customAttributes[0]).PartialFilename;
                    string extension = ((StatementReportTypeAttribute)customAttributes[0]).Extension;

                    string fileName = filenameLookup + extension;
                    byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                    return File( retArr, mimeType, fileName );

                }
                else
                {
                    return new BadRequestObjectResult( response );
                }
            }
            catch( Exception ex )
            {
                logger.LogError( ex, $"GetStatementExtractReport Failure for id {id} and report type {reportType}", null );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Gets all the reports avaliable for the an extract
        /// </summary>
        /// <param name="extractids">
        ///     List of extract identifiers to to get the avaliable reports
        ///     for
        /// </param>
        /// <returns>
        ///     List of extract identifiers and avaliable reports for the extract
        /// </returns>
        [HttpPost( "extract/reports" )]
        [ProducesResponseType( typeof( IEnumerable<Plan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [Authorize]
        public IActionResult GetStatementExtractReports( [FromBody] List<int> extractids )
        {
            string uri = configuration["STATEMENTS:EndpointAddress"] + "extract";

            try
            {
                Dictionary<int, List<StatementReportFileType>> reportTypes = new Dictionary<int, List<StatementReportFileType>>();
                Parallel.For( 0, extractids.Count, i =>
                {
                    HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                    var response = client.GetAsync( $"{uri}/{extractids[i]}/reports" ).Result;

                    //Checking the response is successful or not which is sent using HttpClient  
                    if ( response.IsSuccessStatusCode )
                    {
                        //Storing the response details recieved from web api   
                        var reportTypeResults = response.Content.ReadAsStringAsync().Result;

                        int[] typearray = JsonConvert.DeserializeObject<int[]>( reportTypeResults );

                        List<StatementReportFileType> statementReportFileTypes = ((StatementReportFileType[])(object)typearray).ToList(); ;
                        reportTypes.Add( extractids[i], statementReportFileTypes );
                    }
                }
                );

                //Storing the response details recieved from web api   
                return new OkObjectResult( reportTypes );

            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetStatementExtractReports Failure {ex.Message}", null );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        #endregion

        #region eStatement Provider Settings
        /// <summary>
        ///     Gets all Plans with Messagea and logo associations for a 
        ///     given provider
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of all the logos a provider has including
        ///     the id and thumbnail of the logo
        /// </returns>
        [HttpGet( "{providerId}" )]
        [ProducesResponseType( typeof( IEnumerable<Plan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [Authorize]
        public async Task<IActionResult> GetProviderInformation ([FromRoute] int providerId )
        {
            try
            {
                string uriLogo = configuration[ "STATEMENTS:EndpointAddress" ] + $"logos/{providerId}";
                string uriMsgs = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}";
                string uriPlans = configuration[ "STATEMENTS:EndpointAddress" ] + $"plans/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                Task<HttpResponseMessage> logos = getAsync( uriLogo, client );
                Task<HttpResponseMessage> msgs = getAsync( uriMsgs, client ); 
                Task<HttpResponseMessage> plans = getAsync( uriPlans, client );
              
                HttpResponseMessage responseLogos = await logos;
                HttpResponseMessage responseMsgs = await msgs;
                HttpResponseMessage responsePlans = await plans;

                ////Checking the response is successful or not which is sent using HttpClient  
                if ( responseLogos.IsSuccessStatusCode &&
                     responseMsgs.IsSuccessStatusCode &&
                     responsePlans.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var logosjson = responseLogos.Content.ReadAsStringAsync().Result;
                    var msgjson = responseMsgs.Content.ReadAsStringAsync().Result;
                    var planjson = responsePlans.Content.ReadAsStringAsync().Result;


                    dynamic logoresults = JsonConvert.DeserializeObject<dynamic>( logosjson );
                    dynamic msgresults = JsonConvert.DeserializeObject<dynamic>( msgjson );
                    dynamic planresults = JsonConvert.DeserializeObject<dynamic>( planjson );

                    List<Plan> returnPlans = new List<Plan>();

                    foreach ( var planresult in planresults )
                    {
                        Plan p = new Plan
                        {
                            ProviderId = planresult.providerId,
                            PlanName1 = planresult.planName1,
                            PlanName2 = planresult.planName2,
                            ExternalPlanId = planresult.externalPlanId,
                            LogoId = planresult.logoId
                        };
                        foreach ( var logresult in logoresults )
                        {
                            if ( logresult.logoId == planresult.logoId )
                            {
                                p.Thumbnail = logresult.thumbnail;
                                break;
                            }
                        }

                        foreach ( var msgresult in msgresults )
                        {
                            if ( msgresult.messageId == planresult.message1Id )
                            {
                                p.Message1 = msgresult.originalMessage;
                                p.Message1Id = msgresult.messageId;
                                p.Message1Name = msgresult.messageName;
                            }
                            if ( msgresult.messageId == planresult.message2Id )
                            {
                                p.Message2 = msgresult.originalMessage;
                                p.Message2Id = msgresult.messageId;
                                p.Message2Name = msgresult.messageName;
                            }
                            if ( msgresult.messageId == planresult.message3Id )
                            {
                                p.Message3 = msgresult.originalMessage;
                                p.Message3Id = msgresult.messageId;
                                p.Message3Name = msgresult.messageName;
                            }
                            if ( msgresult.messageId == planresult.message4Id )
                            {
                                p.Message4 = msgresult.originalMessage;
                                p.Message4Id = msgresult.messageId;
                                p.Message4Name = msgresult.messageName;
                            }
                            if ( msgresult.messageId == planresult.message5Id )
                            {
                                p.Message5 = msgresult.originalMessage;
                                p.Message5Id = msgresult.messageId;
                                p.Message5Name = msgresult.messageName;
                            }
                        }

                        returnPlans.Add( p );
                    }

                    //Storing the response details recieved from web api   
                    return new OkObjectResult( returnPlans );

                }
                else
                {
                    return new BadRequestObjectResult( new ApiResponse( 400 ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"GetProviderInformation Failure for id {providerId}", null);
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpGet( "eStatements/{providerId}/enotification/settings" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> GetProviderENotificationSettings( [FromRoute] int providerId )
        {

            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    var json = response.Content.ReadAsStringAsync().Result;

                    ProviderENotifySettings providerENotifySettings = JsonConvert.DeserializeObject<ProviderENotifySettings>( json );

                    return new OkObjectResult( providerENotifySettings );
                }
                else
                {
                    logger.LogError( $"GetProviderENotificationSettings Failure for id {providerId} - {response.Content}", null );
                    return await Task.FromResult( BadRequest(response.StatusCode) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProviderENotificationSettings Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status202Accepted )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PutProviderENotificationSettings( [FromRoute] int providerId, [FromBody] ProviderENotifySettings settings )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( settings );

                HttpResponseMessage response = await client.PutAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    return Ok();
                }
                else
                {
                    logger.LogError( $"PutProviderENotificationSettings Failure for id {providerId} - {response.Content}", null );
                    return await Task.FromResult( BadRequest( response.StatusCode ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PutProviderENotificationSettings Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPost( "eStatements/{providerId}/enotification/settings/emailbody" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PostProviderENotificationSettings( [FromRoute] int providerId, [FromBody] ProviderENotifySettings settings )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/emailbody";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( settings );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    return Created( $"eStatements/{providerId}/enotification/settings", settings );
                }
                else
                {
                    logger.LogError( $"PostProviderENotificationSettings Failure for id {providerId} - {response.Content}", null );
                    return await Task.FromResult( BadRequest( response.StatusCode ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostProviderENotificationSettings Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings/emailbody" )]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [Authorize]
        public async Task<IActionResult> PutProviderNotificationEmailBody( [FromRoute] int providerId, [FromBody] string emailBody )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/emailbody";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( emailBody );

                HttpResponseMessage response = await client.PutAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    return Ok();
                }
                else
                {
                    logger.LogError( $"GetProviderNotificationEmailBody for provider {providerId} failed with code {response.StatusCode} and message {response.Content.ReadAsStringAsync().Result}" );
                    return await Task.FromResult( BadRequest( response ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Get plan email bodu content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId">
        /// </param>
        /// <returns>
        ///     Content of the plans email content
        /// </returns>
        [HttpGet( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> GetPlanENotificationEmailBody( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                if ( response.IsSuccessStatusCode )
                {
                    return new ObjectResult( response.Content.ReadAsStringAsync().Result );
                }
                else
                {
                    if ( response.StatusCode == HttpStatusCode.NotFound )
                    {
                        return NotFound();
                    }
                    else
                    {
                        return new BadRequestObjectResult( response );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Get plan email body content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId">
        /// </param>
        /// <returns>
        ///     Content of the plans email content
        /// </returns>
        [HttpDelete( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> DeletePlanENotificationEmailBody( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                if ( response.IsSuccessStatusCode )
                {
                    return new ObjectResult( response.Content.ReadAsStringAsync().Result );
                }
                else
                {
                    if ( response.StatusCode == HttpStatusCode.NotFound )
                    {
                        return NotFound();
                    }
                    else
                    {
                        return new BadRequestObjectResult( response );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Ets plan email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId"
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PutPlanENotificationEmailBody( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype, [FromBody] string content )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( content );

                HttpResponseMessage response = await client.PutAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    if ( response.StatusCode == HttpStatusCode.NotFound )
                    {
                        return NotFound();
                    }

                    return Ok();
                }
                else
                {
                    logger.LogError( $"PutPlanENotificationEmailBody for provider {providerId} and plan {externalPlanId} failed with code {response.StatusCode} and message {response.Content.ReadAsStringAsync().Result}" );
                    return await Task.FromResult( BadRequest( response ) );
                }
            }
            catch ( Exception ex )
            {

                logger.LogError( $"PutPlanENotificationEmailBody for provider {providerId} and plan {externalPlanId} {ex.Message} - stacktrace {ex.StackTrace}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Ets plan email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId"
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPost( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PostPlanENotificationEmailBody( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype, [FromBody] string content )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( content );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    
                    return new ObjectResult( response.Content.ReadAsStringAsync().Result );
                }
                else
                {
                    logger.LogError( $"PutPlanENotificationEmailBody for provider {providerId} and plan {externalPlanId} failed with code {response.StatusCode} and message {response.Content.ReadAsStringAsync().Result}" );
                    return await Task.FromResult( BadRequest( response ) );
                }
            }
            catch ( Exception ex )
            {

                logger.LogError( $"PutPlanENotificationEmailBody for provider {providerId} and plan {externalPlanId} {ex.Message} - stacktrace {ex.StackTrace}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion eStatement Provider Settings

        #region logos
        /// <summary>
        ///     Gets tall the logos that are assigned to a
        ///     given provider
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of all the logos a provider has including
        ///     the id and thumbnail of the logo
        /// </returns>
        [HttpGet( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ProviderLogo> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderLogos( int providerId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {

                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic logos = JsonConvert.DeserializeObject<dynamic>( json );

                    List<ProviderLogo> providerLogos = new List<ProviderLogo>();
                    foreach ( var logo in logos )
                    {
                        ProviderLogo providerLogo = new ProviderLogo
                        {
                            LogoId = logo.logoId,
                            ProviderId = logo.providerId,
                            Thumbnail = logo.thumbnail
                        };

                        providerLogos.Add( providerLogo );
                    }

                    return new OkObjectResult( providerLogos );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProviderLogos Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a specific provider logo
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Identifier for the logo
        /// </param>
        /// <returns>
        ///     The Provider logo along with the thumbnail of the logo
        /// </returns>
        [HttpGet( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetLogo( int providerId, [RequiredFromQuery] string id )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {

                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic logo = JsonConvert.DeserializeObject<dynamic>( json );

                    ProviderLogo providerLogo = new ProviderLogo
                    {
                        LogoId = logo.logoId,
                        ProviderId = logo.providerId,
                        Thumbnail = logo.thumbnail
                    };

                    return new OkObjectResult( providerLogo );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetLogo Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a logo assigned to a provider along with all
        ///     the Plans that have the logo assinged
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Identifier for the logo
        /// </param>
        /// <returns>
        ///     Status of the method,  200, 404 or 400
        /// </returns>
        [HttpPost("logos/{providerId}/delete")]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeleteLogo( int providerId, [RequiredFromQuery] string id )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    return new OkResult();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetLogo Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates a message for a provider
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the message
        /// </param>
        /// <param name="newMessage">
        ///     Message text to be used to update
        /// </param>
        /// <returns></returns>
        [HttpPut( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutLogo( int providerId, [RequiredFromQuery] string id, IFormFile file )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                byte[] data;
                using ( var br = new BinaryReader( file.OpenReadStream() ) )
                {
                    data = br.ReadBytes( (int)file.OpenReadStream().Length );
                }

                ByteArrayContent bytes = new ByteArrayContent( data );

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic results = JsonConvert.DeserializeObject<dynamic>( json );

                    StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                    SaveProviderLogoRequest request = new SaveProviderLogoRequest();
                    request.Body = new SaveProviderLogoRequestBody()
                    {
                        providerId = providerId,
                        id = id,
                        logo = data,
                        logoFilename = file.FileName
                    };

                    Task<SaveProviderLogoResponse> soapResponse = statementsSoap.SaveProviderLogoAsync( request );

                    SaveProviderLogoResponse saveResponse = await soapResponse;

                    HttpResponseMessage response2 = await client.GetAsync( uri );
                    if ( response2.StatusCode == HttpStatusCode.OK )
                    {
                        json = response2.Content.ReadAsStringAsync().Result;

                        return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                    }
                    else
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                    }
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PutLogo Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a new Logo to the providers universe of
        ///     logos
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the logo
        /// </param>
        /// <param name="file">
        ///     File to be uploaded into the providers univers
        /// </param>
        /// <returns>
        ///     Stats of the addition of the logo
        /// </returns>
        [HttpPost( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status409Conflict )]
        public async Task<IActionResult> PostLogo( int providerId, [RequiredFromQuery] string id, IFormFile file )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                byte[] data;
                using ( var br = new BinaryReader( file.OpenReadStream() ) )
                {
                    data = br.ReadBytes( (int)file.OpenReadStream().Length );
                }

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.StatusCode == HttpStatusCode.NotFound )
                {
                    StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                    SaveProviderLogoRequest request = new SaveProviderLogoRequest();
                    request.Body = new SaveProviderLogoRequestBody()
                    {
                        providerId = providerId,
                        id = id,
                        logo = data,
                        logoFilename = file.FileName
                    };

                    Task<SaveProviderLogoResponse> soapResponse = statementsSoap.SaveProviderLogoAsync( request );

                    SaveProviderLogoResponse saveResponse = await soapResponse;

                    HttpResponseMessage response2 = await client.GetAsync( uri );
                    if ( response2.StatusCode == HttpStatusCode.OK )
                    {
                        var json = response2.Content.ReadAsStringAsync().Result;

                        return Created( $"logos/{providerId}?id={id}", JsonConvert.DeserializeObject<dynamic>( json ) );
                    }
                    else
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                    }
                }
                else if ( response.StatusCode == HttpStatusCode.Conflict )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostLogo Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets Logo Report 
        /// </summary>
        /// <param name="id">
        ///     Provider identifer for eStatemewnts provider
        /// </param>
        /// <returns>
        ///     PDF Stream
        /// </returns>
        [HttpGet( "logos/{providerId}/Report" )]
        //[Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GeneratePlanLogoAssignmentReport( int providerId )
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"GeneratePlanLogoAssignmentReport/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();

                FileStreamResult fileResult = null;
                var response = await client.GetAsync( uri );
                var fileStream = await response.Content.ReadAsStreamAsync();
                var mimeType = "application/pdf";
                var fileName = response.Headers.GetValues( "My-File-Name" ).First();
                fileResult = File( fileStream, mimeType, fileName );
                if ( fileResult == null )
                {
                    return new NotFoundObjectResult( new ApiResponse( 404 ) );
                }
                else
                {
                    return fileResult;
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"Call to CSH StatementService.svc GenerateLogoReport Failure for id {providerId}" );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        /// <summary>
        ///     Adds a mew logo assignments to multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the logo
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     New message has been created to all plans
        /// </returns>
        [HttpPost( "logos/{providerId}/plans" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostLogoAssignmentForPlans( int providerId, [RequiredFromQuery] string id, [FromBody] List<string> newLogoAssignment )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/plans?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( newLogoAssignment );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    return Ok();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a logo assignment from multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the logo to be removed from plans
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     Logo has been removed from all plans
        /// </returns>
        [HttpPost( "logos/{providerId}/{id}/plans/delete" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostLogoRemoveAssignmentForPlans( int providerId, string id, [FromBody] List<string> planExternalIds )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/{id}/plans/delete";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( planExternalIds );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if ( response.IsSuccessStatusCode )
                {
                    return Ok();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostLogoRemoveAssignmentForPlans Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }


        /// <summary>
        ///     Gets the logo assigned to a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <returns>
        ///     Plan Logo information if found
        /// </returns>
        [HttpGet( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlanLogo( int providerId, string planId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/{planId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api  
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic planLogo = JsonConvert.DeserializeObject<dynamic>( json );

                    PlanLogo logo = new PlanLogo
                    {
                        ExternalPlanId = planLogo.externalPlanId,
                        LogoId = planLogo.logoId,
                        ProviderId = planLogo.providerId
                    };

                    return new OkObjectResult( logo );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetPlanLogo Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates the plan logo assignment for the 
        ///     supplied plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <param name="id">
        ///     Internal idetifier for the logo being assined to th the
        ///     plan
        /// </param>
        /// <returns>
        ///     Plan Logo information if successful
        /// </returns>
        [HttpPut( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutPlanLogo( int providerId, string planId, [RequiredFromQuery] string id )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/{planId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PutAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api  
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PutPlanLogo Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a logo assignment to the provided plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <returns>
        ///     OK if the logo assignment has been removed 
        /// </returns>
        [HttpPost("logos/{providerId}/{planid}/delete")]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeletePlanLogo( int providerId, string planId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/{planId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    return new OkResult();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"DeletePlanLogo Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a new logo assigment to the given plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <param name="id">
        ///     Interanl identifier for the logo to be assined to the plan
        /// </param>
        /// <returns>
        ///     New Plan
        /// </returns>
        [HttpPost( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostPlanLogo( int providerId, string planId, [RequiredFromQuery] string id )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"logos/{providerId}/{planId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PostAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return Created( $"logos/{providerId}/{planId}?id={id}", JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.Conflict )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostPlanLogo Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion logos

        #region Plans
        /// <summary>
        ///     Gets all the plans associed to the fiven provider identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider
        /// </returns>
        [HttpGet( "plans/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<StatementPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlans( int providerId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    List<StatementPlan> statementPlans = new List<StatementPlan>();

                    dynamic plans = JsonConvert.DeserializeObject<dynamic>( json );
                    foreach ( var plan in plans )
                    {
                        StatementPlan statementPlan = new StatementPlan();

                        statementPlan.ProviderId = plan.providerId;
                        statementPlan.ExternalPlanId = plan.externalPlanId;
                        statementPlan.PlanName1 = plan.planName1;
                        statementPlan.PlanName2 = plan.planName2;
                        statementPlan.LogoId = plan.logoId;
                        statementPlan.Message1Id = plan.message1Id;
                        statementPlan.Message2Id = plan.message2Id;
                        statementPlan.Message3Id = plan.message3Id;
                        statementPlan.Message4Id = plan.message4Id;
                        statementPlan.Message5Id = plan.message5Id;

                        statementPlans.Add( statementPlan );
                    }

                    return new OkObjectResult( statementPlans );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetPlans Failure for id {providerId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the plans associated to the given provider identifier and message identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <param name="messageId">
        ///     Message identifier assinged by client
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider and message
        /// </returns>
        [HttpGet( "plans/{providerId}/msg/{messageId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessagePlans( int providerId, string messageId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}/msg/{messageId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetMessagePlans Failure for providerId {providerId} and messageId {messageId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the plans associated to the given provider identifier and logo identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <param name="logoId">
        ///     Logo identifier assinged by client
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider and logo
        /// </returns>
        [HttpGet( "plans/{providerId}/logo/{logoId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetLogoPlans( int providerId, string logoId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}/logo/{logoId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetLogoPlans Failure for providerId {providerId} and logoId {logoId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets plan information for the given plan
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     Plan information for the given provider and plan identifiers
        /// </returns>
        [HttpGet( "plans/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlan( int providerId, string planId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}/{planId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetPlan Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a plan from the Providers plan universe
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     Ok if the plan has been deleted and found
        /// </returns>
        [HttpPost("plans/{providerId}/{planId}/delete")]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeletePlan( int providerId, string planId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}/{planId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    return new OkResult();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"DeletePlan Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updated plan informatino for the given plan
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <param name="name1">
        ///     First name given to the plan
        /// </param>
        /// <param name="name2">
        ///     Second Name given to the plan
        /// </param>
        /// <returns>
        ///     Newly updated plna if the plan was found
        /// </returns>
        [HttpPut( "plans/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutPlan( int providerId, string planId, [RequiredFromQuery] string name1, [RequiredFromQuery] string name2 )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}/{planId}?name1={name1}&name2={name2}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PutAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api  
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PutPlan Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Creates a new plan in the Providers Univers
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <param name="name1">
        ///     First name given to the plan
        /// </param>
        /// <param name="name2">
        ///     Second Name given to the plan
        /// </param>
        /// <returns>
        ///     Newly created Plan if the plan information if not found
        /// </returns>
        [HttpPost( "plans/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostPlan( int providerId, [RequiredFromQuery] string planId, [RequiredFromQuery] string name1, [RequiredFromQuery] string name2 )
        {
            // If exits throw 409
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"plans/{providerId}?planId={planId}&name1={name1}&name2={name2}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PostAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return Created( $"plans/{providerId}/{planId}?name1={name1}$name2={name2}", JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.Conflict )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostPlan Failure for plan {planId}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets PDF Proof for Extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract identifier
        /// </param>
        /// <returns>
        ///     PDF Stream
        /// </returns>
        [HttpGet( "plans/{providerId}/Reports/ML" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessageLogoPlanAssignmentReport( int providerId )
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"GeneratePlanLogoMessageAssignmentReport/{providerId}";
                
                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();

                FileStreamResult fileResult = null;
                var response = await client.GetAsync( uri );
                var fileStream = await response.Content.ReadAsStreamAsync();
                var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                var fileName = response.Headers.GetValues( "My-File-Name" ).First();
                fileResult = File( fileStream, mimeType, fileName );
                if ( fileResult == null )
                {
                    return new NotFoundObjectResult( new ApiResponse( 404 ) );
                }
                else
                {
                    return fileResult;
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GenerateMessageAssignmentReport Failure for id {providerId}" );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }
        #endregion Plans

        #region Messages
        /// <summary>
        ///     Gets all the messagea assinged to a given internal provider
        ///     identifier
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of all the messasges assingned to a provider
        /// </returns>
        [HttpGet( "msgs/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessages( int providerId )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"GetMessages Failure for id {providerId}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a provider message by its specified identifier
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Message identifier assinged by client
        /// '</param>
        /// <returns>
        ///     Message in rtf format and the message identifier
        /// </returns>
        [HttpGet( "msgs/{providerId}/{id}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessage( int providerId, string id )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"GetMessage Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a Provider message allong with all the 
        ///     plan message assignments for this message
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Message identifier
        /// </param>
        /// <returns>
        ///     Status of the removal, 200, 404, 400
        /// </returns>
        [HttpPost("msgs/{providerId}/{id}/delete")]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeleteMessage( int providerId, string id )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/{id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    return new OkResult();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"DeleteMessage Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates a message for a provider
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the message
        /// </param>
        /// <param name="newMessage">
        ///     Message text to be used to update
        /// </param>
        /// <returns></returns>
        [HttpPut( "msgs/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutMessage( int providerId, [RequiredFromQuery]string id, [FromBody]NewMessage newMessage )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic results = JsonConvert.DeserializeObject<dynamic>( json );

                    StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                    SaveProviderMessageRequest request = new SaveProviderMessageRequest();
                    request.Body = new SaveProviderMessageRequestBody()
                    {
                        providerId = providerId,
                        id = id,
                        messageName = newMessage.MessageName,
                        newMessage = newMessage.Message,
                        htmlMessage = newMessage.Message
                    };

                    Task<SaveProviderMessageResponse> soapResponse = statementsSoap.SaveProviderMessageAsync( request );

                    SaveProviderMessageResponse saveResponse = await soapResponse;

                    return Ok();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }


            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"PutMessage Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a mew messages to a providers universe
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier to be givento the message
        /// </param>
        /// <param name="newMessage">
        ///     Message in plan or rtf format
        /// </param>
        /// <returns>
        ///     New message that was created
        /// </returns>
        [HttpPost( "msgs/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status409Conflict )]
        public async Task<IActionResult> PostMessage( int providerId, [RequiredFromQuery]string id, [FromBody] PostMessage newMessage )
        {
            // If exits throw 409
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage exitsResponse = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( exitsResponse.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    //Storing the response details recieved from web api   
                    StatementsSoapClient statementsSoap = new WebClientHelper(configuration, HttpContext).generateStatementsSoapClient();

                    SaveProviderMessageRequest request = new SaveProviderMessageRequest();
                    request.Body = new SaveProviderMessageRequestBody()
                    {
                        providerId = providerId,
                        id = id,
                        messageName = newMessage.MessageName,
                        newMessage = newMessage.Message,
                        htmlMessage = newMessage.Message
                    };
                    Task<SaveProviderMessageResponse> response = statementsSoap.SaveProviderMessageAsync( request );


                    SaveProviderMessageResponse saveResponse = await response;

                    return Created( $"msgs/{providerId}?id={id}", request.Body );
                }
                else if ( exitsResponse.StatusCode == System.Net.HttpStatusCode.Conflict )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"PostMessage Failure for id {id}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a mew messages assignments to multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="location">
        ///     Location number where to put the message
        /// </param>
        /// <param name="id">
        ///     External identifier for the message to be assigned
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     New message has been created to all plans
        /// </returns>
        [HttpPost( "msgs/{providerId}/plans/{location}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostMessageAssignmentForPlans( int providerId, int location, [RequiredFromQuery]string id, [FromBody] List<string> newMessageAssignment )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/plans/{location}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( newMessageAssignment );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                if( response.IsSuccessStatusCode )
                {
                    return Ok();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for id {id}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a message assignment from multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the message to be removed from plans
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     Message has been removed from all plans
        /// </returns>
        [HttpPost("msgs/{providerId}/{id}/plans/delete")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PostMessageRemoveAssignmentForPlans(int providerId, string id, [FromBody] List<string> planExternalIds)
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"msgs/{providerId}/{id}/plans/delete";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject(planExternalIds);

                HttpResponseMessage response = await client.PostAsync(uri, new StringContent(json, Encoding.UTF8, "application/json"));

                if (response.IsSuccessStatusCode)
                {
                    return Ok();
                }
                else
                {
                    return await Task.FromResult(BadRequest(new ApiResponse(400)));
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"PostMessageRemoveAssignmentForPlans Failure for id {id}", null);
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Gets all the message assiments for a statement
        ///     for a particular plan.
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External plan identifier
        /// </param>
        /// <returns>
        ///     All the message assigments for a particular plan
        /// </returns>
        [HttpGet( "msgs/{providerId}/plans/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlanMessages( int providerId, string planId )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/plans/{planId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"GetPlanMessages Failure for plan {planId}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets the Plan Message assignment or a specified
        ///     location on a statement
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     The message assingements for the plan and location
        /// </returns>
        [HttpGet( "msgs/{providerId}/{planid}/{location}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> GetPlanMessageByLocation( int providerId, string planId, int location )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/{planId}/{location}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"GetPlanMessageByLocation Failure for plan {planId} and location {location}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates the message assignment for a plan and specific location within
        ///     a statement.
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External plan identifier
        /// </param>
        /// <param name="location">
        ///     Lcation of the message within a statement
        /// </param>
        /// <param name="msgid">
        ///     External message identifier
        /// </param>
        /// <returns>
        ///     Staetus of changing the message for a specific location
        /// </returns>
        [HttpPut( "msgs/{providerId}/{planId}/{location}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> PutPlanMessage( int providerId, string planId, int location, [RequiredFromQuery]string id )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/{location}?id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PostAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return Created( $"msgs/{providerId}/{location}?id={id}", JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"PutPlanMessage Failure for plan {planId} and location {location}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes the message assigment as a specified location
        ///     for a plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan identifier for which the message is assigned
        /// </param>
        /// <param name="location">
        ///     Location of the message within a statements
        /// </param>
        /// <returns>
        ///     Status of the delete
        /// </returns>
        [HttpPost("msgs/{providerId}/{planId}/delete")]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> DeletePlanMessage( int providerId, string planId, [RequiredFromQuery]int location )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/{planId}?location={location}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.DeleteAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    return new OkResult();
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.NotFound )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"DeletePlanMessage Failure for plan {planId} and location {location}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a new plan message assignment
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     Externl Plan identifier to associate the message
        ///     to
        /// </param>
        /// <param name="location">
        ///     Location where the messasge iwll be places
        /// </param>
        /// <param name="msgid">
        ///     External identifeir for the message to be assigned to the locaiton
        /// </param>
        /// <returns>
        ///     Status for adding a new plan message assignment
        /// </returns>
        [HttpPost( "msgs/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> PostPlanMessage( int providerId, string planId, [RequiredFromQuery]int location, [RequiredFromQuery]string id )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"msgs/{providerId}/{planId}?location={location}&id={id}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.PostAsync( uri, null );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return Created( $"msgs/{providerId}/{planId}?location={location}&id={id}", JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else if ( response.StatusCode == System.Net.HttpStatusCode.Conflict )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError(ex, $"PostPlanMessage Failure for plan {planId} and location {location}", null);
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets PDF Proof for Extract
        /// </summary>
        /// <param name="id">
        ///     Statement Extract identifier
        /// </param>
        /// <returns>
        ///     PDF Stream
        /// </returns>
        [HttpGet( "msgs/{providerId}/Plans/Report" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessagePlanAssignmentReport( int providerId )
        {
            try
            {
                string uri = configuration["CSH:StatementWCFEndpointAddress"] + $"GenerateMessageAssignmentReport/{providerId}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClientBasicAuth();
                
                FileStreamResult fileResult = null;
                var response = await client.GetAsync( uri );
                var fileStream = await response.Content.ReadAsStreamAsync();
                var mimeType = "application/pdf";
                var fileName = response.Headers.GetValues( "My-File-Name" ).First();
                fileResult = File( fileStream, mimeType, fileName );
                if ( fileResult == null )
                {
                    return new NotFoundObjectResult( new ApiResponse( 404 ) );
                }
                else
                {
                    return fileResult;
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GenerateMessageAssignmentReport Failure for id {providerId}" );
                return new BadRequestObjectResult( new ApiResponse( 400 ) );
            }
        }

        #endregion Messages

        #region eStatements

        /// <summary>
        ///     Gets all the eStatements for a provider
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <returns>
        ///     LIst of eStatements that can be retireved
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/" )] // Get all the statments for a provider
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderEStatements( int providerId )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"estatements/{providerId}/statements";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProviderEStatements Failure for providerId:{providerId} ", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the statements for a provider and a specified date
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retrieve
        /// </param>
        /// <returns>
        ///     Returns all the Provider eStatemetns for a statement date
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/{statementdate}" )] // Get all the statments for a provider for a particular date
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderEStatementsByDate( int providerId, DateTime statementdate )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/statements/{statementdate.ToString( "yyyy-MM-dd" )}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetProviderEStatementsByDate Failure for providerId:{providerId} statementdate:{statementdate.ToString( "yyyy-MM-dd" )}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the statements for s specific participant
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <returns>
        ///     All the statements for a participant
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/pars/{uid}" )] // get all statements for a participant reguardless of plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsEStatements( int providerId, Guid uid )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/statements/pars/{uid}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantsEStatements Failure for providerId:{providerId} uid:{uid}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a PDF contained all the participants statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     PDF containing all the participants statements for a specified date
        /// </returns>
        [HttpPost( "estatements/{providerId}/statements/pars/combined" )] // Get Combined PDF of all statements for a Dete and participant
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsCombinedEStatements( int providerId, [FromBody] List<int> eStatementIDs )
        {
            try
            {
                string uri = configuration["STATEMENTS:EndpointAddress"] + $"estatements/{providerId}/statements/pars/combined";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                var json = JsonConvert.SerializeObject( eStatementIDs );

                HttpResponseMessage response = await client.PostAsync( uri, new StringContent( json, Encoding.UTF8, "application/json" ) );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    string pdfName = $"{response.Content.Headers.ContentDisposition.FileName}.pdf";
                    byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                    return File( retArr, "application/pdf", pdfName );
                }
                else
                {
                    return new BadRequestObjectResult( response );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantsCombinedEStatementsByDate Failure for providerId:{providerId} eStatementIDs:{eStatementIDs.ToString()}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a PDF contained all the participants statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     PDF containing all the participants statements for a specified date
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/pars/{uid}/{statementdate}/combined" )] // Get Combined PDF of all statements for a Dete and participant
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsCombinedEStatementsByDate( int providerId, Guid uid, DateTime statementdate )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/statements/pars/{uid}/{statementdate.ToString( "yyyy-MM-dd" )}/combined";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    string pdfName = $"{response.Content.Headers.ContentDisposition.FileName}.pdf";
                    byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                    return File( retArr, "application/pdf", pdfName );
                }
                else
                {
                    return new BadRequestObjectResult( response );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantsCombinedEStatementsByDate Failure for providerId:{providerId} uid:{uid} statementdate:{statementdate.ToString( "yyyy-MM-dd" )}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the participant statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Date of the statement
        /// </param>
        /// <returns>
        ///     All the eStatements for a participant for a specifed date
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/pars/{uid}/{statementdate}" )] // get all statements for a participant reguardless of plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsEStatementsByDate( int providerId, Guid uid, DateTime statementdate )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/statements/pars/{uid}/{statementdate.ToString( "yyyy-MM-dd" )}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantsEStatementsByDate Failure for providerId:{providerId} uid:{uid} statementdate:{statementdate.ToString( "yyyy-MM-dd" )}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the eStatements for a provider and a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider plan combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/statements/" )] // get all the statemetns for a plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlansEStatements( int providerId, string planid )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/plans/{planid}/statements";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetPlansEStatements Failure for providerId:{providerId} planid:{planid}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///      Gets all the eStatements for a provider and a specific plan and date
        /// </summary>
        /// <summary>
        ///     Gets all the eStatements for a provider and a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider, plan and statement date combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/statements/{statementdate}" )] // get all the statements fro a plan and date
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlansEStatementsByDate( int providerId, string planid, DateTime statementdate )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/plans/{planid}/statements/{statementdate.ToString( "yyyy-MM-dd" )}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetPlansEStatementsByDate Failure for providerId:{providerId} planid:{planid} statementdate:{statementdate} ", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///  List of all the eStatements for a provider, plan and participant combiniation
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider plan and participant combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/" )]  // Get all Statements for a Participant
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantPlansEStatements( int providerId, string planid, Guid uid )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/plans/{planid}/pars/{uid}/statements";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantPlansEStatements Failure for providerId:{providerId} planid:{planid} uid:{uid} ", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets an eStatement for a participant and specific date
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     Kust if statenebts for a participant and specific date
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate}" )]  // Get All Statements for a Date for a Participants
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantPlansEStatementsbyDate( int providerId, string planid, Guid uid, DateTime statementdate )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate.ToString( "yyyy-MM-dd" )}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();
                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    return new OkObjectResult( JsonConvert.DeserializeObject<dynamic>( json ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetParticipantPlansEStatementsbyDate Failure for providerId:{providerId} planid:{planid} uid:{uid} statementdate: {statementdate}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets the eStatement PDF document
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <param name="statementid">
        ///     Identifeir for the PDF Codument
        /// </param>
        /// <returns>
        ///     File stream of the eStatement PDF document
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate}/{statementid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetEStatement( int providerId, string planid, Guid uid, DateTime statementdate, int statementid )
        {
            try
            {
                string uri = configuration[ "STATEMENTS:EndpointAddress" ] + $"estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate.ToString( "yyyy-MM-dd" )}/{statementid}";

                HttpClient client = new WebClientHelper(configuration, HttpContext).generateHttpClient();

                HttpResponseMessage response = await client.GetAsync( uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if ( response.IsSuccessStatusCode )
                {
                    string pdfName = $"{response.Content.Headers.ContentDisposition.FileName}.pdf";
                    byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                    return File( retArr, "application/pdf", pdfName );
                }
                else
                {
                    return new BadRequestObjectResult( response );
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"GetEStatement Failure for providerId:{providerId} plsnifz:{planid} uid:{uid} statementdate:{statementdate} statementid:{statementid}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion eStatements


        #region Private Methods

        /// <summary>
        ///     Starts async method call
        /// </summary>
        /// <param name="url">
        ///     Rest service endpoint
        /// </param>
        /// <param name="client">
        ///     Http Client to call the REST endpoint
        /// </param>
        /// <returns>
        ///     Task running the Http Response
        /// </returns>
        async Task<HttpResponseMessage> getAsync( string url, HttpClient client )
        {
            dynamic result = await client.GetAsync( url );
            return result;
        }

        #endregion Private Methods
    }
}
