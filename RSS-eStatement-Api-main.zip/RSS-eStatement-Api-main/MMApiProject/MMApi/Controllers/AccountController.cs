﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Controllers
{
    #region using 
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Microsoft.IdentityModel.Tokens;
    using MMApi.Models;
    using MMApi.ViewModel;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.IdentityModel.Tokens.Jwt;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Security.Claims;
    using System.Security.Cryptography.X509Certificates;
    using System.ServiceModel;
    using System.Text;
    using System.Threading.Tasks;

    #endregion using

    
    [Route( "api/[controller]" )]
    [Produces( "application/json" )]
    [EnableCors( "CorsPolicy" )]
    [ApiController]
    [ApiExplorerSettings( GroupName = "auth" )]
    public class AccountController : ControllerBase
    {
        #region Fields
        /// <summary>
        ///     Applicaton configuation setting 
        /// </summary>
        private IConfiguration configuration;
        private readonly ILogger logger;
        #endregion Fields

        #region constructor
        /// <summary>
        ///     Default construcor
        /// </summary>
        /// <param name="config">
        ///     Application configuration
        /// </param>
        public AccountController( IConfiguration config, ILogger<AccountController> logger )
        {
            configuration = config;
            this.logger = logger; 
        }
        #endregion constructor

        #region Public Methods
        [HttpGet("uptime")]
        [AllowAnonymous]
        public IActionResult UpTime()
        {
            return new OkObjectResult( DateTime.Now.ToString() );
        }

        /// <summary>
        ///     Authorizes a user and issues a token
        /// </summary>
        /// <param name="clientid">
        ///     Client that is requesting the Authorization
        /// </param>
        /// <param name="Grant_Type">
        ///     What type of authorzation is being asked for
        /// </param>
        /// <param name="Username">
        ///     User to authorize
        /// </param>
        /// <param name="Password">
        ///     Users password
        /// </param>
        /// <param name="Refresh_Token">
        ///     Possible token to refresh
        /// </param>
        /// <returns>
        ///     JWT if authorized
        /// </returns>
        [HttpPost( "auth" )]
        [AllowAnonymous]
        public async Task<IActionResult> Auth( [FromBody] AuthUser user )
        {
            try
            {
                switch( user.grant_type )
                {
                    case "password":
                        {
                            Guid clientIdGuid = Guid.Empty;
                            string userID = string.Empty;
                            if ( Guid.TryParse( user.client_id, out clientIdGuid ) )
                            {
                                userID = isValidUser( user.username, user.password );
                            }
                            else
                            {
                                string uri = $"{configuration[ "STATEMENTS:EndpointAddress" ]}auth";
                                HttpClient client = new HttpClient();
                                client.DefaultRequestHeaders.Accept.Clear();
                                client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue( "application/json" ) );
                                
                                HttpResponseMessage httpResponse = await client.PostAsync( uri, 
                                    new StringContent( "{\"clientid\":\"" + user.client_id + "\",\"username\":\"" + user.username + "\",\"password\":\"" + user.password + "\"}",
                                    Encoding.UTF8,
                                    "application/json" ) );

                                //Checking the response is successful or not which is sent using HttpClient  
                                if ( httpResponse.IsSuccessStatusCode )
                                {
                                    //Storing the response details recieved from web api   
                                    var json = httpResponse.Content.ReadAsStringAsync().Result;

                                    string results = JsonConvert.DeserializeObject<dynamic>( json );

                                    userID = results.Insert( 23, "-");
                                }
                                else
                                {
                                    return new OkObjectResult( "Invalid username and/or Password" );
                                }
                            }

                            if ( String.IsNullOrEmpty( userID ) )
                            {
                                return new OkObjectResult( "Invalid username and/or Password" );
                            }
                            else
                            {
                                // We have a valid user
                                var response = composeToken( userID, user.username );
                                var result = new OkObjectResult( response );
                                return result;
                                
                            }
                        }
                    case "refresh_token":
                        {
                            try
                            {
                                var response = refreshToken( user.password, user.username, user.refresh_token );
                                return new OkObjectResult( response );
                            }
                            catch
                            {
                                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                            }
                        }
                    default:
                        return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch( Exception ex )
            {
                return new OkObjectResult( ex.Message + " : " + ex.StackTrace );
            }
        }

        /// <summary>
        ///     Authorizes a user for the MassMutual system
        /// </summary>
        /// <param name="userId">
        ///     Internal Identifier for the user to authorize
        /// </param>
        /// <returns>
        ///     If authorized then UserAuthorization Object
        /// </returns>
        [HttpGet( "{userId}/authorize" )]
        [Authorize]
        public async Task<IActionResult> AuthorizeUser( string userId )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                CSH.GetLoginUserSoapOut soapOut = partiesSoap.GetLoginUserAsync( userId ).Result;

                // Validate the the Client is MassMutual - No Other users will be authorized
                if( soapOut.ClientID == configuration[ "CSH:ProviderId" ] )
                {
                    UserAuthorization authorization = new UserAuthorization
                    {
                        Username = soapOut.UserInfo.LoginName,
                        Email = soapOut.Email,
                        FirstName = soapOut.UserInfo.FirstName,
                        LastName = soapOut.UserInfo.LastName,
                        LastLoginDttm = soapOut.UserInfo.LastLoginDttm,
                        MustChangePassword = soapOut.UserInfo.MustChangePassword,
                        EmployeeIdentifier = soapOut.UserInfo.EmployeeIdentifier,
                        // UserAdministrator = 4,
                        UserAdmin = soapOut.UserRoleIDs.Contains( "4" ),
                        // CommunicationsReport = 72,
                        InvoicesAccess = soapOut.UserRoleIDs.Contains( "72" ),
                        OrgId = soapOut.UserOrgID,
                        HasSecurityQuestions = partiesSoap.HasSecurityQuestionsAsync( userId ).Result
                    };

                    return new OkObjectResult( authorization );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets User infromation from CSH
        /// </summary>
        /// <param name="userId">
        ///     CSH Internal identiier for the user
        /// </param>
        /// <returns>
        ///     User object if found
        /// </returns>
        [HttpGet( "{userId}" )]
        [Authorize]
        public User GetUser( string userId )
        {
            CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
            CSH.GetUserSoapOut soapOut = partiesSoap.GetUserAsync( userId ).Result;

            User user = new User
            {
                Email = soapOut.EmailAddress,
                FName = soapOut.FirstName,
                LName = soapOut.LastName,
                UserId = soapOut.PartyID,
                Username = soapOut.LoginName
            };

            return user;
        }

        /// <summary>
        ///     Gets any security questions that were
        ///     answered for a given user
        /// </summary>
        /// <param name="userId">
        ///     Internal identifier for the user
        /// </param>
        /// <returns>
        ///     List of questions retrieved from the CSH system
        /// </returns>
        [HttpGet( "{userId}/securityquestions" )]
        [Authorize]
        public async Task<IActionResult> GetSecurityQuestions( string userId )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                var questions = partiesSoap.GetUserSecurityQuestionsAsync( userId ).Result;

                return new OkObjectResult( questions );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a list of security questions that can be 
        ///     answered
        /// </summary>
        /// <returns>
        ///     List of all the security questions within CSH
        /// </returns>
        [HttpGet( "securityquestions" )]
        [Authorize]
        public async Task<IActionResult> GetSecurityQuestions()
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                CSH.GetSecurityQuestionsResponse questions = partiesSoap.GetSecurityQuestionsAsync().Result;

                List<SecurityQuestion> data = new List<SecurityQuestion>();
                if( questions != null )
                {
                    foreach( CSH.SecurityQuestion q in questions.GetSecurityQuestionsResult )
                    {
                        SecurityQuestion sq = new SecurityQuestion
                        {
                            Id = (int)q.SecurityQuestionID,
                            Text = q.SecurityQuestionText
                        };
                        data.Add( sq );
                    }
                }
                return new OkObjectResult( data );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Saves user questions and answers to the CSH system
        /// </summary>
        /// <param name="userId">
        ///     Internal identiier for the user
        /// </param>
        /// <param name="question1">
        ///     Identiier for the first question
        /// </param>
        /// <param name="question2">
        ///     Idenfitier for the second queston
        /// </param>
        /// <param name="answer1">
        ///     Answer to question 1
        /// </param>
        /// <param name="answer2">
        ///     Answer to question 2
        /// </param>
        /// <returns>
        ///     Indicator if the information was saved to CSH
        /// </returns>
        [HttpPut( "{userId}/securityquestions" )]
        [Authorize]
        public bool SaveUserSecurityQuestions( string userId, [FromBody] SecurityQuestions securityQuestions )
        {
            CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();

            CSH.SecurityQuestionsAnswersSoapIn soapIn = new CSH.SecurityQuestionsAnswersSoapIn
            {
                PersonPartyID = userId
            };

            CSH.SecurityQuestionAnswer userAnswer1 = new CSH.SecurityQuestionAnswer
            {
                SecurityQuestionID = (short)securityQuestions.question1,
                SecurityQuestionAnswerText = securityQuestions.answer1
            };

            CSH.SecurityQuestionAnswer userAnswer2 = new CSH.SecurityQuestionAnswer
            {
                SecurityQuestionID = (short)securityQuestions.question2,
                SecurityQuestionAnswerText = securityQuestions.answer2
            };
            soapIn.UserAnswers = new CSH.SecurityQuestionAnswer[] { userAnswer1, userAnswer2 };

            bool result = partiesSoap.SaveUserSecurityQuestionsAndAnswersAsync( soapIn ).Result;

            return result;
        }

        /// <summary>
        ///     Adds a user to the system for MassMutual
        /// </summary>
        /// <param name="FirstName">
        ///     First Name for the user to be added
        /// </param>
        /// <param name="LastName">
        ///     Last Name fo the user to be added
        /// </param>
        /// <param name="Username">
        ///     Username for the new user
        /// </param>
        /// <param name="Password">
        ///     Password for the new user
        /// </param>
        /// <param name="Email">
        ///     Email address for the new user
        /// </param>
        /// <param name="OrgId">
        ///     ORG identifier to be assciated
        ///     with the new user.
        /// </param>
        /// <param name="MustChangePassword">
        ///     Indicator if the user must change 
        ///     their password on next logon
        /// </param>
        /// <param name="InvoicesAccess">
        ///     Does the user have access to invoices
        /// </param>
        /// <param name="UserAdmin">
        ///     Does the user have access to add and edit 
        ///     other users
        /// </param>
        /// <returns>
        ///     New user internal identifier if a successful save
        /// </returns>
        [HttpPost("newUser")]
        [Authorize]
        public async Task<IActionResult> UserPost([FromBody] UserInsUpd userInfo )
         
        {
                try
                {
                    CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                    CSH.SaveUserSoapIn soapIn = new CSH.SaveUserSoapIn
                    {
                        MustChangePassword = userInfo.mustChangePassword,
                        FirstName = userInfo.firstName,
                        LastName = userInfo.lastName,
                        LoginName = userInfo.username,
                        EmailAddress = userInfo.email,
                        PartyID = string.Empty,
                        PhoneNbr = string.Empty,
                        FaxNbr = string.Empty,
                        ActualClientID = userInfo.orgId,
                        ActingOnBehalfOfClientID = userInfo.orgId,
                        Password = userInfo.password,
                        IsActive = true,
                        ActiveStart = DateTime.Now,
                        ModifiedByPartyID = userInfo.orgId,
                        EmployeeIdentifier = userInfo.employeeIdentifier
                    };

                    List<string> userRoles = new List<string>();
                    if ( userInfo.invoicesAccess )
                    {
                        userRoles.Add("72");
                    }

                    if ( userInfo.userAdmin )
                    {
                        userRoles.Add("4");
                    }

                soapIn.UserRoles = userRoles.ToArray();

                // Save User Info for existing users
                string userID = partiesSoap.SaveUserAsync( soapIn ).Result;

                return new OkObjectResult( userID );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates user information within CSH
        /// </summary>
        /// <param name="userId">
        ///     Internal identifier for the user
        ///     to be updated
        /// </param>
        /// <param name="FirstName">
        ///     First Name for the user
        /// </param>
        /// <param name="LastName">
        ///     Last Name fo the user
        /// </param>
        /// <param name="Username">
        ///     Username for the user
        /// </param>
        /// <param name="Email">
        ///     Email address for the user
        /// </param>
        /// <param name="OrgId">
        ///     ORG identifier assciated
        ///     with the user.
        /// </param>
        /// <param name="MustChangePassword">
        ///     Indicator if the user must change 
        ///     their password on next logon
        /// </param>
        /// <param name="InvoicesAccess">
        ///     Does the user have access to invoices
        /// </param>
        /// <param name="UserAdmin">
        ///     Does the user have access to add and edit 
        ///     other users
        /// </param>
        /// <param name="Question1">
        ///     Internal question number for the first question
        ///     the user has provided answers for
        /// </param>
        /// <param name="Question2">
        ///     Internal question number for the second question
        ///     the user has provided answers for
        /// </param>
        /// <param name="Answer1">
        ///     Answer to Question 1
        /// </param>
        /// <param name="Answer2">
        ///     Answer to Question 2
        /// </param>
        /// <returns>
        ///     Boolean true if the system can save the user information
        /// </returns>
        [HttpPut( "{userId}" )]
        [Authorize]
        public async Task<IActionResult> UserPut( string userId, [FromBody] UserInsUpd userInfo )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                CSH.SaveUserSoapIn soapIn = new CSH.SaveUserSoapIn
                {
                    MustChangePassword = userInfo.mustChangePassword,
                    FirstName = userInfo.firstName,
                    LastName = userInfo.lastName,
                    LoginName = userInfo.username,
                    EmailAddress = userInfo.email,
                    ActualClientID = userInfo.orgId,
                    ActingOnBehalfOfClientID = userInfo.orgId,
                    ModifiedByPartyID = userId,
                    PartyID = userId,
                    PhoneNbr = string.Empty,
                    FaxNbr = string.Empty,
                    Password = userInfo.password,
                    IsActive = true,
                    EmployeeIdentifier = userInfo.employeeIdentifier
                };

                List<string> userRoles = new List<string>();
                if( userInfo.invoicesAccess )
                {
                    userRoles.Add( "72" );
                }

                if( userInfo.userAdmin )
                {
                    userRoles.Add( "4" );
                }

                soapIn.UserRoles = userRoles.ToArray();

                // Save User Info for existing users
                string userID = partiesSoap.SaveUserAsync( soapIn ).Result;

                if( userInfo.question1 > 0 )
                {
                    SecurityQuestions sq = new SecurityQuestions();
                    sq.answer1 = userInfo.answer1;
                    sq.answer2 = userInfo.answer2;
                    sq.question1 = userInfo.question1;
                    sq.question2 = userInfo.question2;

                    // if we have questions then we need to save them
                    this.SaveUserSecurityQuestions( userId, sq );
                }

                return new OkObjectResult( true );

            }
            catch( Exception ex )
            {
                logger.LogDebug( ex.Message );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a user from the CSH system
        /// </summary>
        /// <param name="userId">
        ///     Internal CSH identifier for the user to delete
        /// </param>
        /// <param name="activeUserId">
        ///     Internal CSH identifier for the user that is making the delete
        ///     for trakcing purposes
        /// </param>
        /// <returns>
        ///     Returns OK if the user has been deleted
        /// </returns>
        [HttpDelete( "{userId}/{activeUserId}" )]
        [Authorize]
        public async Task<IActionResult> DeleteUser( string userId, string activeUserId )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                CSH.SaveUserSoapIn soapIn = new CSH.SaveUserSoapIn
                {
                    ActualClientID = configuration[ "CSH:ProviderId" ],
                    ActingOnBehalfOfClientID = configuration[ "CSH:ProviderId" ],
                    ModifiedByPartyID = activeUserId,
                    PartyID = userId,
                    PhoneNbr = string.Empty,
                    FaxNbr = string.Empty,
                    EmailAddress = string.Empty,
                    IsActive = false
                };


                // Save User Info for existing users
                string userID = partiesSoap.SaveUserAsync( soapIn ).Result;
                if( !String.IsNullOrEmpty( userID ) )
                {
                    return new OkResult();
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Validates a new assword based on the provider
        ///     preferences for passwords with CSH
        /// </summary>
        /// <param name="userId">
        ///     Internal Identifier for the user to have the password
        ///     validated
        /// </param>
        /// <param name="orgId">
        ///     Internal org identifier to the provider to check
        /// </param>
        /// <param name="oldPassword">
        ///     Current password that is being udated
        /// </param>
        /// <param name="newPassword">
        ///     New password to check.
        /// </param>
        /// <returns>
        ///     Boolean indicator if the change is valid based on the 
        ///     provider settings.
        /// </returns>
        [HttpPost( "{userId}/IsValidPassword" )]
        [Authorize]
        public async Task<IActionResult> IsValidPasswordChange( string userId, [FromBody] ValidatePassword vaidatePassword )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                bool valid = partiesSoap.IsValidPasswordChangeAsync( userId, vaidatePassword.orgId, vaidatePassword.oldPassword, vaidatePassword.newPassword ).Result;

                if( valid )
                {
                    return new OkObjectResult( true );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400, "Your password does not meet the password change requirements" ) ) );
                }
            }
            catch( Exception ex )
            {
                if( ex.Message.Contains( "ApplicationException" ) )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400, "Your password does not meet the password change requirements") ) );
                }
                else if( ex.Message.Contains( "BusinessRuleException" ) )
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400, "Your password does not meet the password change requirements") ) );
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
        }

        /// <summary>
        ///    Get the security questions for a user based on username
        /// </summary>
        /// <param name="username">
        ///     Username to be checked
        /// </param>
        /// <param name="email">
        ///     email address to be used to assist in the check
        /// </param>
        /// <returns>
        ///     Boolean indicator if the username can be used.
        /// </returns>
        [HttpGet( "isvaliduser" )]
        public async Task<IActionResult> ValidateForgotPasswordUser( string username, string email )
        {
            ForgotPasswordUser user = new ForgotPasswordUser();

            CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
            CSH.AuthenticateUserSoapOut response = partiesSoap.AuthenticateUserAsync( username, string.Empty, email ).Result;

            if( !string.IsNullOrEmpty( response.PartyID ) || Guid.Parse( response.PartyID ) != Guid.Empty )
            {
                user.UserId = response.PartyID;
                List<SecurityQuestion> questions = new List<SecurityQuestion>();
                foreach( CSH.SecurityQuestion sq in response.Questions )
                {
                    SecurityQuestion question = new SecurityQuestion
                    {
                        Id = sq.SecurityQuestionID,
                        Text = sq.SecurityQuestionText
                    };
                    questions.Add( question );
                }
                user.SecurityQuestions = questions.ToArray();

                return new OkObjectResult( user );
            }
            else
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Validates a users security questions when resetting their password
        /// </summary>
        /// <param name="userId">
        ///     Internal CSH user identifier
        /// </param>
        /// <param name="question1Id">
        ///     Identifier for the first question
        /// </param>
        /// <param name="answer1">
        ///     Answer to the first question
        /// </param>
        /// <param name="question2Id">
        ///     Idenfier for the second question
        /// </param>
        /// <param name="answer2">
        ///     Answer to the second questino
        /// </param>
        /// <returns>
        ///     True if the information was valid
        /// </returns>
        [HttpPost( "{userId}/securityquestions/valdate" )]
        public async Task<IActionResult> ValidateUserQuestions( string userId, [FromBody] SecurityQuestions securityQuestions )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();

                CSH.ResetPasswordSoapIn soapIn = new CSH.ResetPasswordSoapIn
                {
                    PersonPartyID = userId
                };

                CSH.SecurityQuestionAnswer a1 = new CSH.SecurityQuestionAnswer
                {
                    SecurityQuestionID = (short)securityQuestions.question1,
                    SecurityQuestionAnswerText = securityQuestions.answer1
                };

                CSH.SecurityQuestionAnswer a2 = new CSH.SecurityQuestionAnswer
                {
                    SecurityQuestionID = (short)securityQuestions.question2,
                    SecurityQuestionAnswerText = securityQuestions.answer2
                };

                soapIn.UserAnswers = new CSH.SecurityQuestionAnswer[] { a1, a2 };

                CSH.ResetPasswordResponse response = partiesSoap.ResetPasswordAsync( soapIn ).Result;

                if( response != null )
                {
                    return new OkObjectResult( response );
                }

                return new OkObjectResult( response );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Determines if a username is already used within CSH
        /// </summary>
        /// <param name="username">
        ///     username to lookup
        /// </param>
        /// <returns>
        ///     Boolean indicator on the usernames avaliablity
        /// </returns>
        [HttpGet( "username/avaliable/{username}" )]
        public async Task<IActionResult> IsUsernameAvaliable( string username )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                var response = partiesSoap.IsLoginNameAvaliableAsync( username ).Result;
                return new OkObjectResult( response );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

     
        /// <summary>
        ///     Resets a users password within CSH
        /// </summary>
        /// <param name="userId">
        ///     Internal CSH user identifier
        /// </param>
        /// <param name="validationCode">
        ///     Password reset validation code
        /// </param>
        /// <param name="newPassword">
        ///     New password to be used for the user
        /// </param>
        /// <returns></returns>
        [HttpPost( "auth/password/reset" )]
        public async Task<IActionResult> ResetPassword( PasswordReset passwordReset )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();

                CSH.ResetPasswordSoapIn soapIn = new CSH.ResetPasswordSoapIn
                {
                    PersonPartyID = passwordReset.userId,
                    VerificationCode = passwordReset.validationCode,
                    NewPassword = passwordReset.newPassword
                };

                CSH.SecurityQuestionAnswer a1 = new CSH.SecurityQuestionAnswer
                {
                    SecurityQuestionID = 0
                };

                soapIn.UserAnswers = new CSH.SecurityQuestionAnswer[] { a1 };

                try
                {
                    CSH.ResetPasswordResponse response = partiesSoap.ResetPasswordAsync( soapIn ).Result;
                    return new OkObjectResult( response );
                }
                catch
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                }
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the users for the MassMutual provider within
        ///     the CSH system
        /// </summary>
        /// <returns>
        ///     List of Users that are assined to the MassMutual provider
        ///     within CSH
        /// </returns>
        [HttpGet("Users")]
        [Authorize]
        public async Task<IActionResult> GetUsers()
        {
            List<User> data = new List<User>();

            CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
            CSH.GetPartiesRelatedToPartyIDWithActiveStateAsListItemsResponse response =
                partiesSoap.GetPartiesRelatedToPartyIDWithActiveStateAsListItemsAsync( new string[] { configuration[ "CSH:ProviderId" ] }, 2, 2, 2 ).Result;

            if( response != null )
            {
                foreach( CSH.ListItem li in response.GetPartiesRelatedToPartyIDWithActiveStateAsListItemsResult )
                {
                    User u = new User
                    {
                        UserId = li.ID,
                        FName = li.Description
                    };
                    data.Add( u );
                }
            }
            return new OkObjectResult( data );
        }
        #endregion Public Methods

        #region Private Methods
        /// <summary>
        ///     Validates a username and password using the CSH system
        /// </summary>
        /// <param name="username">
        ///     Username to validate
        /// </param>
        /// <param name="password">
        ///     Password to validate
        /// </param>
        /// <returns>
        ///     Guid if username and password validates
        /// </returns>
        private string isValidUser( string username, string password )
        {
            CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();

            CSH.AuthenticateUserSoapOut soapOut = partiesSoap.AuthenticateUserAsync( username, password, string.Empty ).Result;

            if ( soapOut.ValidLogin )
            {
                return soapOut.PartyID;
            }
            else
            {
                return string.Empty;
            }
        }
   
        /// <summary>
        ///     Generates the internals of the JWT
        /// </summary>
        /// <param name="userId">
        ///     Internal identifier for the user requesting
        ///     the token
        /// </param>
        /// <param name="username">
        ///     Username for the user requesting the token
        /// </param>
        /// <returns>
        ///     Internals of the JWT
        /// </returns>
        private async Task<dynamic> composeToken( string userId, string username )
        {
            var response = new
            {
                access_token = await generateToken( userId, username ),
                refresh_token = await generateRefreshToken( userId ),
                expires_in = Convert.ToInt32( configuration[ "JWT:ValidFor" ] ),
                token_type = "Bearer"
            };

            return response;
        }

        /// <summary>
        ///     Generates a Refresh Token for a user
        /// </summary>
        /// <param name="userId">
        ///     Internal Identifier for the user
        /// </param>
        /// <param name="username">
        ///     Username for the user requesting the token
        /// </param>
        /// <param name="refreshToken">
        ///     Current refreshtoken to be refreshed
        /// </param>
        /// <returns>
        ///     New Refresh Token if avaliable
        /// </returns>
        private async Task<dynamic> refreshToken( string userId, string username, string refreshToken )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();

                if( partiesSoap.IsValidRefreshTokenAsync( userId, refreshToken ).Result )
                {
                    string newRefreshToken = partiesSoap.GenerateRefreshTokenAsync( userId ).Result;

                    var response = new
                    {
                        access_token = await generateToken( userId, username ),
                        refresh_token = newRefreshToken,
                        expires_in = Convert.ToInt32( configuration[ "JWT:ValidFor" ] ),
                        token_type = "Bearer"
                    };

                    return response;
                }
                else
                {
                    return await Task.FromResult( BadRequest( new ApiResponse( 400, "Invalid refresh token." ) ) );
                }
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Reads a file into a byte array
        /// </summary>
        /// <param name="fileName">
        ///     File to read
        /// </param>
        /// <returns>
        ///     Byte array containing the file contents
        /// </returns>
        private byte[] readFile( string fileName )
        {
            byte[] data = null;
            using( FileStream fs = new FileStream( fileName, FileMode.Open, FileAccess.Read ) )
            {
                int size = (int) fs.Length;
                data = new byte[ size ];
                size = fs.Read( data, 0, size );
            }
            return data;
        }

        /// <summary>
        ///     Generates a JWT for a validated user
        /// </summary>
        /// <param name="userId">
        ///     Internal identifier for the user requesting
        ///     the JWT
        /// </param>
        /// <param name="username">
        ///     Username for the user requesting the JWT
        /// </param>
        /// <returns>
        ///     JWT token signed using the certificate contained 
        ///     wthin the application configuration
        /// </returns>
        public async Task<string> generateToken( string userId, string username )
        {
            var claims = new[]
            {
                new Claim( JwtRegisteredClaimNames.Sub, username ),
                new Claim( JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString() ),
                new Claim( JwtRegisteredClaimNames.NameId, userId )
            };

            var key = new SymmetricSecurityKey( Encoding.UTF8.GetBytes( configuration[ "Jwt:Key" ] ) );
            var creds = new SigningCredentials( key, SecurityAlgorithms.HmacSha256 );

            byte[] certificateBytes = readFile( configuration[ "Jwt:Certificate" ] );
            X509Certificate2 certificate2 = new X509Certificate2( certificateBytes, configuration[ "Jwt:CertPassword" ], 
                X509KeyStorageFlags.Exportable |
                X509KeyStorageFlags.MachineKeySet |
                X509KeyStorageFlags.PersistKeySet );

            var securityKey = new X509SecurityKey( certificate2 );

            var token = new JwtSecurityToken( configuration[ "Jwt:Issuer" ],
                configuration[ "Jwt:Issuer" ],
                claims,
                expires: DateTime.Now.AddMinutes( 10 ),
                signingCredentials: creds );

            return new JwtSecurityTokenHandler().WriteToken( token );
        }

        /// <summary>
        ///     Generated a connection to the Parties service within the CSH system
        ///     using the username and password withing the config.
        /// </summary>
        /// <returns>
        ///     Connectiion to the Parties service within CSH
        /// </returns>
        private CSH.PartiesSoapClient generatePartiesSoapClient()
        {
            BasicHttpBinding binding = new BasicHttpBinding();
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            binding.MaxReceivedMessageSize = int.MaxValue;
            EndpointAddress ea = new EndpointAddress( configuration[ "CSH:EndpointAddress" ] );
            CSH.PartiesSoapClient partiesSoap = new CSH.PartiesSoapClient( binding, ea );

            partiesSoap.ClientCredentials.UserName.UserName = configuration[ "CSH:UserName" ];
            partiesSoap.ClientCredentials.UserName.Password = configuration[ "CSH:Password" ];

            return partiesSoap;
        }

        /// <summary>
        ///     Generates a JWT Refresh token
        /// </summary>
        /// <param name="userId">
        ///     Internal Identifier for the user that is
        ///     requesting the refresh token
        /// </param>
        /// <returns>
        ///     New Refresh token if avaliable
        /// </returns>
        private async Task<string> generateRefreshToken( string userId )
        {
            try
            {
                CSH.PartiesSoapClient partiesSoap = generatePartiesSoapClient();
                return partiesSoap.GenerateRefreshTokenAsync( userId ).Result;
            }
            catch
            {
                throw new ApplicationException( "Unable to generate new refesh token" );
            }
        }

        #endregion Private Methods
    }
}