﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Controllers
{
    #region using
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using MMApi.Models;
    using Newtonsoft.Json;
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using System.IO;
    #endregion using

    [ApiController]
    [Produces( "application/json" )]
    [Route( "api/v1/[controller]" )]
    [EnableCors( "CorsPolicy" )]
    [ApiExplorerSettings( GroupName = "massmutual" )]
    public class DataStatsController : ControllerBase
    {
        #region Fields
        /// <summary>
        ///     Applicaton configuation setting 
        /// </summary>
        private readonly IConfiguration configuration;
        #endregion Fields

        #region Constructor
        /// <summary>
        ///     Default constructor
        /// </summary>
        /// <param name="config">
        ///     Application configuration that has been injected
        /// </param>
        public DataStatsController( IConfiguration config )
        {
            configuration = config;
        }
        #endregion Constructor

        #region Public Methods
        /// <summary>
        ///     Gets the allowed production dates that can be viewed
        /// </summary>
        /// <returns>
        ///     Array of valid production dates
        /// </returns>
        [HttpGet( "pdates" )]
        [Authorize]
        public IEnumerable<DateTime> ProductionDates()
        {
            DateTime end = DateTime.Now;
            DateTime start = DateTime.Now.AddDays( -90 );

            var monthlist = new List<DateTime>();

            for( var d = start; d <= end; d = d.AddMonths( 1 ) )
            {
                monthlist.Add( new DateTime( d.Year, d.Month, 1 ) );
            }
            monthlist.Add( new DateTime( end.Year, end.Month, 1 ) );
            return monthlist.Distinct().ToList();
        }

        /// <summary>
        ///     Gets all the particiant communcations
        ///     for a given type and time range
        /// </summary>
        /// <param name="commType">
        ///     Type of communcations to retrieve
        /// </param>
        /// <param name="year">
        ///     Year of the data to retrieve
        /// </param>
        /// <param name="month">
        ///     Month of the data to retireve
        /// </param>
        /// <param name="day">
        ///     Optional day of data to retrieve
        /// </param>
        /// <returns>
        ///     List of participants for the date range
        /// </returns>
        [HttpGet( "stats/{commType}/{year}/{month:int}/{day:int?}" )]
        [Authorize]
        public async Task<IActionResult> ParticipantData( [FromRoute] string commType,
            [FromRoute] int year,
            [FromRoute] int month,
            [FromRoute] int? day = null )
        {
            DateTime startDate = DateTime.MinValue;
            DateTime endDate = DateTime.MinValue;

            if( day.HasValue )
            {
                startDate = new DateTime( year, month, day.Value );
                endDate = startDate;
            }
            else
            {
                startDate = new DateTime( year, month, 1 );
                endDate = startDate.AddMonths( 1 ).AddDays( -1 );
            }

            var accessToken = HttpContext.Request.Headers[ "Authorization" ].ToString().Replace( "Bearer", string.Empty ).Trim();

            string uri = configuration[ "MMAR:EndpointAddress" ] + $"comms?startDate={startDate.ToString( "yyyy-MM-dd" )}&endDate={endDate.ToString( "yyyy-MM-dd" )}&commType={commType}";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue( "application/json" ) );
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue( "Bearer", accessToken );
            HttpResponseMessage response = await client.GetAsync( uri );

            //Checking the response is successful or not which is sent using HttpClient  
            if( response.IsSuccessStatusCode )
            {
                //Storing the response details recieved from web api   
                var json = response.Content.ReadAsStringAsync().Result;

                dynamic results = JsonConvert.DeserializeObject<dynamic>( json );

                List<parData> pars = new List<parData>();

                foreach( var result in results )
                {
                    parData pd = new parData
                    {
                        fname = result.fname,
                        lname = result.lname,
                        id = result.id
                    };

                    List<parPDFData> pdfData = new List<parPDFData>();

                    foreach( var pdf in result.communications )
                    {
                        parPDFData pard = new parPDFData
                        {
                            planname = pdf.planName
                        };

                        string newDate = pdf.date;
                        try
                        {
                            pard.pdfdate = Convert.ToDateTime( newDate ).ToString( "yyyy-MM-dd" );
                        }
                        catch( Exception ex )
                        {
                            string s = ex.Message;
                        }
                        pard.pdf = pdf.pdf;
                        pard.orderId = pdf.orderId;
                        pdfData.Add( pard );
                    }

                    pd.pdfdata = pdfData;

                    pars.Add( pd );
                }
                return new OkObjectResult( pars );
            }
            else
            {
                return new BadRequestObjectResult( response );
            }
        }

        /// <summary>
        ///     Gets statistical information for a specific month
        /// </summary>
        /// <param name="date">
        ///     Date to retrive the data for.
        /// </param>
        /// <returns>
        ///     Statistics for a secific month
        /// </returns>
        [HttpGet( "stats/{date}" )]
        [Authorize]
        public async Task<IActionResult> Stats( [FromRoute] DateTime date )
        {
            string startDate = date.ToString( "MM-01-yyyy" );
            string endDate = new DateTime( date.Year, date.Month, 1 ).AddMonths( 1 ).AddDays( -1 ).ToString( "MM-dd-yyyy" );
            MonthlyStats stats = new MonthlyStats();

            try
            {
                var accessToken = HttpContext.Request.Headers[ "Authorization" ].ToString().Replace( "Bearer", string.Empty ).Trim();

                string uri = $"stats?startDate={startDate}&endDate={endDate}";
                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue( "application/json" ) );

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue( "Bearer", accessToken );
                HttpResponseMessage response = await client.GetAsync( configuration[ "MMAR:EndpointAddress" ] + uri );

                //Checking the response is successful or not which is sent using HttpClient  
                if( response.IsSuccessStatusCode )
                {
                    //Storing the response details recieved from web api   
                    var json = response.Content.ReadAsStringAsync().Result;

                    dynamic results = JsonConvert.DeserializeObject<dynamic>( json );
            
                    stats.MonthData = new List<MonthData>();
                    MonthData mdataLow = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "Low",
                        LetterType = "l"
                    };
                    MonthData b2pmdataLow = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "B2P Low",
                        LetterType = "b2p l"
                    };
                    MonthData mdataLowOpp = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "Low/Opp",
                        LetterType = "lo"
                    };
                    MonthData b2pmdataLowOpp = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "B2P Low/Opp",
                        LetterType = "b2p lo"
                    };
                    MonthData mdataHigh = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "High",
                        LetterType = "h"
                    };
                    MonthData b2pmdataHigh = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "B2P High",
                        LetterType = "b2p h"
                    };
                    MonthData mdataEOnly = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "E Only",
                        LetterType = "e"
                    };
                    MonthData b2pmdataEOnly = new MonthData
                    {
                        Data = new List<DayTotal>(),
                        Label = "B2P E Only",
                        LetterType = "b2p e"
                    };

                    DayTotal dayTotal = new DayTotal();
                    foreach( var result in results )
                    {
                        DateTime feedDate = DateTime.Parse( result.feedDate.ToString() );
                        if( stats.Month == 0 )
                        {
                            stats.Month = feedDate.Month;
                            stats.Year = feedDate.Year;
                        }

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.totalLow.ToString() )
                        };
                        mdataLow.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.b2PTotalLow.ToString() )
                        };
                        b2pmdataLow.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.totalLowOpp.ToString() )
                        };
                        mdataLowOpp.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.b2PTotalLowOpp.ToString() )
                        };
                        b2pmdataLowOpp.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.totalHigh.ToString() )
                        };
                        mdataHigh.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.b2PTotalHigh.ToString() )
                        };
                        b2pmdataHigh.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                        {
                            Day = feedDate.Day,
                            Total = Convert.ToInt32( result.totalEOnly.ToString() )
                        };
                        mdataEOnly.Data.Add( dayTotal );

                        dayTotal = new DayTotal
                         {
                             Day = feedDate.Day,
                             Total = Convert.ToInt32( result.b2PTotalEOnly.ToString() )
                         };
                         b2pmdataEOnly.Data.Add( dayTotal );

                    }

                    stats.MonthData.Add( mdataLow );
                    stats.MonthData.Add( b2pmdataLow );

                    stats.MonthData.Add( mdataLowOpp );
                    stats.MonthData.Add( b2pmdataLowOpp );

                    stats.MonthData.Add( mdataHigh );
                    stats.MonthData.Add( b2pmdataHigh );

                    stats.MonthData.Add( mdataEOnly );
                    //stats.MonthData.Add( b2pmdataEOnly );

                }

            }
            catch( Exception ex )
            {
                using( StreamWriter sw = new StreamWriter( @"E:\1.txt" ) )
                {
                    sw.WriteLine( ex.Message );
                    sw.WriteLine( ex.Source );
                    sw.WriteLine( ex.StackTrace );
                }
            }

            return new OkObjectResult( stats );
        }

        /// <summary>
        ///     Gets a communication for a specific particiiant
        /// </summary>
        /// <param name="id">
        ///     Internal MM identifier for the order the communication was in
        /// </param>
        /// <param name="commid">
        ///     Internal MM Identifier for the communication
        /// </param>
        /// <returns>
        ///     Stream of the communicatino if found
        /// </returns>
        [HttpGet( "orders/{id}/{commid}" )]
        [Authorize]
        public async Task<IActionResult> GetCommunication( int id, Guid commid )
        {
            var accessToken = HttpContext.Request.Headers[ "Authorization" ].ToString().Replace( "Bearer", string.Empty ).Trim();

            string uri = $"orders/{id}/{commid}";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue( "application/json" ) );

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue( "Bearer", accessToken );
            HttpResponseMessage response = await client.GetAsync( configuration[ "MMAR:EndpointAddress" ] + uri );

            //Checking the response is successful or not which is sent using HttpClient  
            if( response.IsSuccessStatusCode )
            {
                string pdfName = $"{response.Content.Headers.ContentDisposition.FileName}.pdf";
                byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                return File( retArr, "application/pdf", pdfName );
            }
            else
            {
                return new BadRequestObjectResult( response );
            }
        }

        /// <summary>
        ///     Gets an invoice for a specified time period
        /// </summary>
        /// <param name="year">
        ///     Year to retrieve the invoice for
        /// </param>
        /// <param name="month">
        ///     Month ot retirieve the invoice for
        /// </param>
        /// <returns>
        ///     Stream of the XLSX file that contains the invoice
        /// </returns>
        [HttpGet( "orders/invoice/{year}/{month}" )]
        [Authorize]
        public async Task<IActionResult> GetInvoice( int year, int month )
        {
            var accessToken = HttpContext.Request.Headers[ "Authorization" ].ToString().Replace( "Bearer", string.Empty ).Trim();

            string uri = $"orders/Invoice/{year}/{month}";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add( new MediaTypeWithQualityHeaderValue( "application/json" ) );

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue( "Bearer", accessToken );

            HttpResponseMessage response = await client.GetAsync( configuration[ "MMAR:EndpointAddress" ] + uri );

            //Checking the response is successful or not which is sent using HttpClient  
            if( response.IsSuccessStatusCode )
            {
                string xlsxName = $"{response.Content.Headers.ContentDisposition.FileName}";
                byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait( false );

                return File( retArr, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xlsxName );
            }
            else
            {
                return new BadRequestObjectResult( response );
            }
        }


        /// <summary>
        ///     Gets a report for a particular range of dates.
        /// </summary>
        /// <param name="year1">
        ///     Year1 to retieve the report for
        /// </param>
        /// <param name="year2">
        ///     Year2 to retieve the report for
        /// </param>
        /// <returns>
        ///     Stream of the XLSX file that contains the report
        /// </returns>
        [HttpGet("orders/downloadreport/{year1}/{year2}")]
        [Authorize]
        public async Task<IActionResult> GetReport( string year1, string year2)
        {
            var accessToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer", string.Empty).Trim();

            string uri = $"orders/downloadreport/{year1}/{year2}";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            HttpResponseMessage response = await client.GetAsync(configuration["MMAR:EndpointAddress"] + uri);

            //Checking the response is successful or not which is sent using HttpClient  
            if (response.IsSuccessStatusCode)
            {
                string xlsxName = $"{response.Content.Headers.ContentDisposition.FileName}";
                byte[] retArr = await response.Content.ReadAsByteArrayAsync().ConfigureAwait(false);

                return File(retArr, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xlsxName);
            }
            else
            {
                return new BadRequestObjectResult(response);
            }
        }

        #endregion Public Methods
    }
}