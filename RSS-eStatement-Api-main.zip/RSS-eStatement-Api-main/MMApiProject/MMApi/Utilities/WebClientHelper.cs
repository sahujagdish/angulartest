﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Statements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace MMApi.Utilities
{
    public class WebClientHelper
    {
        IConfiguration configuration;
        HttpContext httpContext;

        public WebClientHelper(IConfiguration configuration, HttpContext httpContext)
        {
            this.configuration = configuration;
            this.httpContext = httpContext;
        }


        /// <summary>
        ///     Generated a connection to the Statements service within the CSH system
        ///     using the username and password withing the config.
        /// </summary>
        /// <returns>
        ///     Connectiion to the service within CSH
        /// </returns>
        public StatementsSoapClient generateStatementsSoapClient()
        {
            BasicHttpBinding binding = new BasicHttpBinding();
            binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            binding.MaxReceivedMessageSize = int.MaxValue;
            EndpointAddress ea = new EndpointAddress(configuration["CSH:StatementEndpointAddress"]);
            StatementsSoapClient partiesSoap = new StatementsSoapClient(binding, ea);

            partiesSoap.ClientCredentials.UserName.UserName = configuration["CSH:UserName"];
            partiesSoap.ClientCredentials.UserName.Password = configuration["CSH:Password"];

            return partiesSoap;
        }

        /// <summary>
        ///      Generates Rest Http client to be used for communications that use basic auth
        /// </summary>
        /// <returns><
        ///      HHTP client used fro tor rest services
        /// /returns>
        public HttpClient generateHttpClientBasicAuth()
        {
            var auth = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{configuration["CSH:UserName"]}:{configuration["CSH:Password"]}"));
            HttpClient client = generateHttpClient();
            
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", auth);

            return client;
        }

        /// <summary>
        ///     Generates Rest Http client to be used for communication that use bearer tokens
        /// </summary>
        /// <returns>
        ///     HHTP client used fro tor rest services
        /// </returns>
        public HttpClient generateHttpClient()
        {
            var handler = new HttpClientHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            handler.ServerCertificateCustomValidationCallback =
                (httpRequestMessage, cert, cetChain, policyErrors) =>
                {
                    return true;
                };

            var accessToken = httpContext.Request.Headers["Authorization"].ToString().Replace("Bearer", string.Empty).Trim();

            HttpClient client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            return client;
        }
    }
}
