﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Models
{
    #region using
    using System;
    using System.Runtime.InteropServices;
    using System.Security;
    #endregion using

    public static class Extentions
    {
        /// <summary>
        ///     Converts the given stirng into a SecureStirng object
        /// </summary>
        /// <param name="planTextString">
        ///     String to be converted
        /// </param>
        /// <returns>
        ///     SecureString object for the string provided
        /// </returns>
        public static SecureString ConvertToSecureString( this string planTextString )
        {
            if( planTextString == null )
                throw new ArgumentNullException( "planTextString" );

            var securePassword = new SecureString();

            foreach( char c in planTextString )
                securePassword.AppendChar( c );

            securePassword.MakeReadOnly();

            return securePassword;
        }

        /// <summary>
        ///     Converts a secure string back to a string.
        /// </summary>
        /// <param name="secureString">
        ///     Secure String to convert base to string.
        /// </param>
        /// <returns>
        ///     String that the secure string represented
        /// </returns>
        public static string ConvertToUNSecureString( this SecureString secureString )
        {
            IntPtr unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode( secureString );
                return Marshal.PtrToStringUni( unmanagedString );
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode( unmanagedString );
            }
        }
    }
}
