﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMApi.Models
{
    public enum StatementReportFileType1
    {
        Audit = 1,

        BadAddress = 2,

        BadAllocation = 3,

        NoActivity = 4
    }

    public enum StatementReportFileType
    {
        [StatementReportTypeAttribute( @"text/plain", @"daud", "txt" )]
        Audit = 1,

        [StatementReportTypeAttribute( @"text/plain", @"badad", "txt" )]
        BadAddress = 2,

        [StatementReportTypeAttribute( @"text/plain", @"badalloc", "txt" )]
        BadAllocation = 3,

        [StatementReportTypeAttribute( @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", @"badparts", "xlsx" )]
        NoActivity = 4,

        [StatementReportTypeAttribute( @"application/pdf", "", "pdf" )]
        Proof = 5
    }

    public class Plan
    {
        public Guid ProviderId;
        public string PlanName1;
        public string PlanName2;
        public string ExternalPlanId;
        public string LogoId;
        public byte[] Thumbnail;
        public string Message1Id;
        public string Message1Name;
        public string Message1;
        public string Message2Id;
        public string Message2Name;
        public string Message2;
        public string Message3Id;
        public string Message3Name;
        public string Message3;
        public string Message4Id;
        public string Message4Name;
        public string Message4;
        public string Message5Id;
        public string Message5Name;
        public string Message5;
    }

    public class StatementExtractPlan
    {
        public string PlanName1 { get; set; }
        public string PlanName2 { get; set; }
        public string ExternalPlanId { get; set; }
        public bool IsDeleted { get; set; }
    }

    public class ApprovalInformation
    {
        public Dictionary<int, string> proofDates;
        public Dictionary<int, List<StatementReportFileType>> reportTypes;
    }

    public class NewMessage
    {
        public string MessageName { get; set; }
        public string Message { get; set; }
    }

    public class PostMessage
    {
        public string MessageId { get; set; }
        public string MessageName { get; set; }
        public string Message { get; set; }
    }

    public class eStatement
    {
        public string part_id { get; set; }
        public string plan_num { get; set; }
        public string plan_name { get; set; }
        public DateTime statementDate { get; set; }
        public int? statementId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public Guid uid { get; set; }
    }

    public class StatementPlan
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string PlanName1 { get; set; }
        public string PlanName2 { get; set; }
        public string LogoId { get; set; }
        public string Message1Id { get; set; }
        public string Message2Id { get; set; }
        public string Message3Id { get; set; }
        public string Message4Id { get; set; }
        public string Message5Id { get; set; }
    }

    public class ProviderLogo
    {
        public Guid ProviderId { get; set; }
        public string LogoId { get; set; }
        public string Thumbnail { get; set; }
    }

    public class PlanLogo
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string LogoId { get; set; }
    }

    public class ProviderENotifySettings
    {
        public Guid ProviderId { get; set; }
        public string Fromaddr { get; set; }
        public string Fromname { get; set; }
        public string EMailSubject { get; set; }
        public string EmailBody { get; set; }
        public string? Replyaddr { get; set; }
        public string? Replyname { get; set; }
        public int? EmailBatchSize { get; set; }
        public int? HoursBetweenBatch { get; set; }
        public bool? AreEmailSentOnWeekendHoliday { get; set; } = false;
        public bool? IsSundaySkipped { get; set; } = false;
        public bool? IsMondaySkipped { get; set; } = false;
        public bool? IsTuesdaySkipped { get; set; } = false;
        public bool? IsWednesDaySkipped { get; set; } = false;
        public bool? IsThursdaySkipped { get; set; } = false;
        public bool? IsFridaySkipped { get; set; } = false;
        public bool? IsSaturdaySkipped { get; set; } = false;
    }

    /// <summary>
    ///     
    /// </summary>
    public enum PlanEnotifyOverrideType
    {
        emailbody = 1,
        fromaddress = 2,
        fromname = 3,
        replyaddress = 4,
        replyname = 5,
        emailsubject = 6
    }

    public class PlanEnotifyOverrideSettings
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string Content { get; set; }
        public byte PlanEnotifyOverrideTypeCD { get; set; }
    }
}
