﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMApi.Models
{
    public class StatementReportTypeAttribute : Attribute
    {
        #region Constructors
        /// <summary>
        ///     Contructor used to classify StatementReportTypeAttribute.
        /// </summary>
        /// <param name="">
        /// Bit Mask for ContentEditing with regard to the KnowledgeBaseAssetType.
        /// </param>
        /// <param name="eeditMask">
        /// Bit Mask for EEditing with regard to the KnowledgeBaseAssetType.
        /// </param>
        public StatementReportTypeAttribute( string mimeType, string partialFilename, string extension )
        {
            MimeType = mimeType;
            PartialFilename = partialFilename;
            Extension = extension;
        }
        #endregion

        #region Public Properties
        public string MimeType { get; set; } = string.Empty;

        public string PartialFilename { get; set; } = string.Empty;

        public string Extension { get; set; } = string.Empty;
        #endregion Public Properties
    }
}
