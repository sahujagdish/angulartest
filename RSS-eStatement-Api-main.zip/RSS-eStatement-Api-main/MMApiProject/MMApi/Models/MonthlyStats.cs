﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Models
{
    #region using
    using System.Collections.Generic;
    #endregion using

    public class MonthlyStats
    {
        public int Month { get; set; }
        
        public int Year { get; set; }

        public List<MonthData> MonthData { get; set; }
    }

    public class MonthData 
    {
        public string Label { get; set; }
        public string LetterType { get; set; }

        public List<DayTotal> Data { get; set; }
    }

    public class DayTotal
    {   
        public int Day { get; set; }
        
        public int Total { get; set; }
    }
        
    public class parData
    {
        public string fname { get; set; }
        public string lname { get; set; }
        public string id { get; set; }
        public List<parPDFData> pdfdata { get; set; }
    }

    public class parPDFData
    {
        public string planname { get; set; }
        public string pdfdate { get; set; }
        public string pdf { get; set; }
        public int orderId { get; set; }
    }
}
