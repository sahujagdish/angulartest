﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.Models
{
    #region using
    using System;
    using System.ComponentModel.DataAnnotations;
    #endregion using

    public class AuthUser
    {
        public string client_id { get; set; }
        public string grant_type { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string refresh_token { get; set; }
    }

    public class ForgotPasswordUser
    {
        public string UserId { get; set; }
        public SecurityQuestion[] SecurityQuestions { get; set; }
    }

    public class SecurityQuestion
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }

    public class User
    {
        public string UserId { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Username { get; set; }

        [EmailAddress]
        public string Email { get; set; }
        public int SQ1Id { get; set; }
        public string SQ1 { get; set; }
        public int SQ2Id { get; set; }
        public string SQ2 { get; set; }
    }

    public class UserInsUpd
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string orgId { get; set; }
        public bool mustChangePassword { get; set; }
        public bool invoicesAccess { get; set; }
        public bool userAdmin { get; set; }
        public int question1 { get; set; }
        public int question2 { get; set; }
        public string answer1 { get; set; }
        public string answer2 { get; set; }
        public string employeeIdentifier { get; set; }
    }

    public class UserAuthorization
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string EmployeeIdentifier { get; set; }
        public bool MustChangePassword { get; set; }
        public bool HasSecurityQuestions { get; set; }
        public DateTime LastLoginDttm { get; set; }
        public bool UserAdmin { get; set; }
        public bool InvoicesAccess { get; set; }
        public string OrgId { get; set; }
    }

    public class SecurityQuestions
    {
        public int question1 { get; set; }
        public int question2 { get; set; }
        public string answer1 { get; set; }
        public string answer2 { get; set; }
    }

    public class PasswordReset
    {
        public string userId { get; set; }
        public string validationCode { get; set; }
        public string newPassword { get; set; }
    }

    public class ValidatePassword
    {
        public string orgId { get; set; }
        public string oldPassword { get; set; }
        public string newPassword { get; set; }
    }

}
