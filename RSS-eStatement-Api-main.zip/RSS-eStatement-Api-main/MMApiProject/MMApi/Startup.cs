﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi
{
    #region using
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Settings;
    using Microsoft.Extensions.Hosting;
    using Microsoft.OpenApi.Models;
    using System.Text.Json.Serialization;
    #endregion using

    public partial class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup( IConfiguration configuration, IWebHostEnvironment env )
        {
            var builder = new ConfigurationBuilder()
              .SetBasePath( env.ContentRootPath )
              .AddJsonFile( "appsettings.json", optional: true, reloadOnChange: true )
              .AddEncryptedAndJsonFiles( $"appsettings.json", env.ContentRootPath, optional: true, reloadOnChange: true );

            builder.AddEnvironmentVariables();

            configuration = builder.Build();

            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices( IServiceCollection services )
        {
            services.AddCors( options =>
            {
                options.AddPolicy(name: "CorsPolicy", builder => builder.AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader() 
                );
            } );

            services.AddSingleton<IConfiguration>( Configuration );

            services.AddMvc().AddNewtonsoftJson();

            services.AddSwaggerGen( c =>
            {
                c.SwaggerDoc( "auth", new OpenApiInfo { Title = "Auth API - v1", Version = "v1" } );
                c.SwaggerDoc( "massmutual", new OpenApiInfo { Title = "MassMutual API - v1", Version = "v1" } );
                c.SwaggerDoc( "statements", new OpenApiInfo { Title = "Statements API - v1", Version = "v1" } );
            } );

            services.AddControllers().AddJsonOptions( options =>
              options.JsonSerializerOptions.Converters.Add( new JsonStringEnumConverter() ) );

            configureJwtAuthService( services );
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure( IApplicationBuilder app, IWebHostEnvironment env )
        {
            app.UseCors(options => options.WithOrigins("*").AllowAnyMethod().AllowAnyHeader());

            if ( env.IsDevelopment() )
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseDeveloperExceptionPage();
            app.UseSwagger();
            app.UseSwaggerUI( c =>
            {
#if DEBUG
                c.SwaggerEndpoint( "/swagger/auth/swagger.json", "Auth API - v1" );
                c.SwaggerEndpoint( "/swagger/massmutual/swagger.json", "MassMutual API - v1" );
                c.SwaggerEndpoint( "/swagger/statements/swagger.json", "Statements API v1" );
#else

                c.SwaggerEndpoint( "auth/swagger.json", "Auth API - v1" );
                c.SwaggerEndpoint( "massmutual/swagger.json", "MassMutual API - v1" );
                c.SwaggerEndpoint( "statements/swagger.json", "Statements API v1" );
#endif

            } );

           
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(options => { options.WithOrigins("*").AllowAnyMethod().AllowAnyHeader(); });
            //app.UseCors("CorsPolicy");

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints( endpoints =>
            {
                endpoints.MapControllers();
            } );
        }
    }
}
