﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace Settings
{
    #region using
    using Microsoft.Extensions.Configuration;
    using Newtonsoft.Json.Linq;
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text.RegularExpressions;
    #endregion using

    public class EncryptedConfigurationSource : IConfigurationSource
    {
        public string JsonFilePath { get; }
        public string EncryptedFilePath { get; }

        private string _settingsBasePath;

        public EncryptedConfigurationSource( string jsonFilePath, string settingsBasePath )
        {
            _settingsBasePath = settingsBasePath;
            JsonFilePath = jsonFilePath;
            EncryptedFilePath = Regex.Replace( JsonFilePath, Regex.Escape( ".json" ) + "$", ".enc" );
        }

        public IConfigurationProvider Build( IConfigurationBuilder builder )
        {
            return new EncryptedConfigurationProvider( this );
        }

        
        internal string GetEncryptionKeyPath( JObject jsonRoot )
        {
            var path = jsonRoot[ "EncryptionKeyPath" ];
            if( path == null ) return null;
            var fiEncKey = new FileInfo( Path.Combine( _settingsBasePath, path.ToString() ) );
            if( !fiEncKey.Exists )
                throw new Exception( "EncryptionKeyPath was specified but cannot be found" );
            return fiEncKey.FullName;
        }

        internal JObject GetEncryptedContents( byte[] encrypted, Aes aes )
        {
            using( MemoryStream msDecrypt = new MemoryStream( encrypted ) )
            using( CryptoStream csDecrypt = new CryptoStream( msDecrypt, aes.CreateDecryptor(), CryptoStreamMode.Read ) )
            using( StreamReader srDecrypt = new StreamReader( csDecrypt, System.Text.Encoding.UTF8 ) )
            {
                string plaintext = srDecrypt.ReadToEnd();
                return JObject.Parse( plaintext );
            }
        }

        internal Aes GetEncryptionAlgorithm( string keyPath )
        {
            if( !File.Exists( keyPath ) )
                throw new InvalidDataException( "EncryptionKeyPath key cannot be found" );

            byte[] data = File.ReadAllBytes( keyPath );
            if( data.Length != 48 )
                throw new InvalidDataException( "EncryptionKeyPath key does not contain valid key and IV. Must be 48 bytes length." );

            var aes = Aes.Create();

            byte[] key = new byte[ 32 ];
            Array.Copy( data, key, 32 );
            aes.Key = key;

            byte[] iv = new byte[ 16 ];
            Array.Copy( data, 32, iv, 0, 16 );
            aes.IV = iv;

            return aes;
        }
    }
}