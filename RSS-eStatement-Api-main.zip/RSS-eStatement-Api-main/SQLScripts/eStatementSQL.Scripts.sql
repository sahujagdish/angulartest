﻿use estatement
go
--**********************************************************************************

drop proc dbo.api_proc_change_password_participant
go

create procedure dbo.api_proc_change_password_participant 
@uuid varchar(40), 
@current_pass varchar(40), 
@new_pass varchar(40),
@initialLogin bit
as

declare @table_uid varchar(40)
declare @table_pass varchar(40)
declare @table_code varchar(40)
declare @r_rount int

		SELECT @table_pass = Password, @table_code = StatusCode
        FROM Participant
        WHERE participant.participantUUID = @uuid AND Password = @current_pass
		
		select @r_rount = @@Rowcount

		if @r_rount = 0
		begin
			select -1, 'The value you entered for Current Password is invalid!'
			return
		end

		SELECT @table_uid = UserID
        FROM Participant
        WHERE participant.participantUUID = @uuid AND Password = @current_pass

		select @r_rount = @@Rowcount

		if @table_uid = @new_pass
		begin
			select -2, 'The User ID and the Password should not be the same.'
			return
		end

		declare @sql nvarchar(1000)
		set @sql = '
		UPDATE Participant
            SET Password =  ''' + @new_pass + ''' 
            , PrevPassword = ''' + @table_pass + ''' 
            , LastPasswordEdit = GETDATE()
            , LastLogin = GETDATE() 
			, failedAuthAttempts = 0
            , isPasswordHashed = 1'

		if @initialLogin = 1
		begin
		set @sql = @sql + ', PasswordEditByAdmin = 0 '
		end

		set @sql = @sql + ' WHERE participantUUID = ''' + @uuid  + '''  '

		print @sql
		EXEC sys.[sp_executesql] @sql

		select 1 as code, 'Password changed' as msg
go


--**********************************************************************************

drop proc dbo.api_proc_change_password_administrator
go

create procedure dbo.api_proc_change_password_administrator @uuid varchar(40),  @current_pass varchar(40), @new_pass varchar(40)
as
declare @r_rount int
declare @table_pass varchar(40)

        SELECT @table_pass = Password
        FROM   Administrator
        WHERE  AdministratorUUID = @uuid
        AND Password    = @current_pass
		select @r_rount = @@Rowcount

		if @r_rount = 0
		begin
			select -1 as code, 'The value you entered for Current Password is invalid!' as msg
			return
		end

		UPDATE Administrator
        SET Password = @new_pass
            ,LastPasswordEdit = getdate()
            ,failedAuthAttempts = 0
            ,passwordEditByAdmin =  0
        WHERE administratorUUID = @uuid

		select 1 as code, 'Password changed' as msg
go

--**********************************************************************************

drop proc dbo.api_proc_change_password_sponsor
go

create procedure dbo.api_proc_change_password_sponsor @uuid varchar(40), @current_pass varchar(40), @new_pass varchar(40)
as
declare @r_rount int
declare @table_pass varchar(40)

		SELECT @table_pass = SPAD_Password
        FROM   sponAdministrator
        WHERE  sponAdministratorUUID = @uuid
        AND SPAD_Password = @current_pass
		select @r_rount = @@Rowcount

		if @r_rount = 0
		begin
			select -1, 'The value you entered for Current Password is invalid!'
			return
		end

		 UPDATE sponAdministrator
         SET SPAD_password = @new_pass
             ,LastPasswordEdit = getdate()
             ,failedAuthAttempts = 0
             ,passwordEditByAdmin = 0
         WHERE sponAdministratorUUID = @uuid

		 select 1 as code, 'Password changed' as msg
go

--**********************************************************************************

drop proc dbo.api_proc_get_uuid
go

create procedure dbo.api_proc_get_uuid @uuid varchar(40), @providerid varchar(40)
as
      select participantUUID as 'uid'
      from participant
      where participantUUID = @uuid
        AND participant.providerid = @providerid
        AND participant.statuscode != 'DE'
        AND participant.statuscode != 'IN'
go


--**********************************************************************************

drop proc dbo.api_proc_last_password_edit
go

create procedure dbo.api_proc_last_password_edit @id int, @mode varchar(20)
as
if @mode = 'participant'
begin
        select LastPasswordEdit
        from participant
        where participantid = @id
end
else if @mode = 'administrator'
begin
        select LastPasswordEdit
        from administrator
        where administratorID = @id
end
else if @mode = 'sponadministrator'
begin
        select LastPasswordEdit
        from sponAdministrator
        where SPAD_ID =  @id
end
else
begin
		select convert(datetime,'1900-01-01')
end
go


--**********************************************************************************

drop proc dbo.api_proc_log_failed_auth_attempts
go

create procedure dbo.api_proc_log_failed_auth_attempts @userid varchar(20), @mode varchar(20), @table_name varchar(20)
as

declare @sql nvarchar(500)

if  @mode = 'add'
begin

        declare @table_attempt int
        declare @rcount int

        set @sql = 'select @a = failedAuthAttempts from ' + @table_name
        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		set @sql = @sql + ' select @b = @@Rowcount'

		print @sql
        EXEC sys.[sp_executesql] @sql , N'@a int out , @b int out', @table_attempt out , @rcount out
        --select @rcount = @@Rowcount
		print @rcount
		print @table_attempt

        --------------------update attempts -------------

        if @rcount = 1
        begin
            set @table_attempt = 1 + @table_attempt 
        end
        else
        begin
            set @table_attempt = 1
        end

		print 'will add : ' +  convert(varchar(10),@table_attempt)

        set @sql = ' update ' + @table_name + ' set failedAuthAttempts = ' + convert(varchar(10),@table_attempt)

        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		print @sql
        EXEC sys.[sp_executesql] @sql     
end
else if @mode = 'reset'
begin
        
        set @sql = ' update ' + @table_name + ' set failedAuthAttempts = 0 '

        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

        EXEC sys.[sp_executesql] @sql   
end
go

--**********************************************************************************

drop proc dbo.api_proc_get_failed_attempts
go

create procedure dbo.api_proc_get_failed_attempts @userid varchar(20), @table_name varchar(20)
as
        declare @sql nvarchar(500)
        declare @table_attempt int

        set @sql = 'select @a = failedAuthAttempts from ' + @table_name
        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		print @sql
        EXEC sys.[sp_executesql] @sql , N'@a int out ', @table_attempt out 

		select @table_attempt
go    

--**********************************************************************************

drop proc dbo.spIsParticipantEditable
go

create procedure dbo.spIsParticipantEditable @useSSN bit, @providerid varchar(10), @provid varchar(10), @uid varchar(50)
as
        declare @sql nvarchar(500)
		set @sql = ' select	participantUUID
                     from	participant, ss_ident
                     where '
        if @useSSN = 1 
        begin
            set @sql = @sql + ' participant.SSN = ss_ident.part_id '
        end
        else
        begin
            set @sql = @sql + ' participant.acctnumber = ss_ident.part_id '
        end

        set @sql = @sql + ' and participant.ProviderID  = ' + CONVERT(varchar(10),  @providerid ) + '
                            and ss_ident.provid = ''' + CONVERT(varchar(50),  @provid ) + '''
                            and uid = ''' + CONVERT(varchar(50),  @uid ) + ''' '

        print @sql
        EXEC sys.[sp_executesql] @sql

go

--**********************************************************************************

drop function [dbo].[tesla_fn_split_string]
go

create FUNCTION [dbo].[tesla_fn_split_string]
(
    @string    nvarchar(max),
    @delimiter nvarchar(max)
)
/*
    The same as STRING_SPLIT for compatibility level < 130
    https://docs.microsoft.com/en-us/sql/t-sql/functions/string-split-transact-sql?view=sql-server-ver15
*/
RETURNS TABLE AS RETURN
(
    SELECT 
      --ROW_NUMBER ( ) over(order by (select 0))                            AS id     --  intuitive, but not correect
        Split.a.value('let $n := . return count(../*[. << $n]) + 1', 'int') AS id
      , Split.a.value('.', 'NVARCHAR(MAX)')                                 AS value
    FROM
    (
        SELECT CAST('<X>'+REPLACE(@string, @delimiter, '</X><X>')+'</X>' AS XML) AS String
    ) AS a
    CROSS APPLY String.nodes('/X') AS Split(a)
)
go

--**********************************************************************************

IF not EXISTS (SELECT * FROM sys.types WHERE is_table_type = 1 AND name = 'api_type_varcar_col')
begin

CREATE TYPE dbo.api_type_varcar_col AS TABLE(
    varchar_col varchar(500)
)
end
go 

 --**********************************************************************************
drop proc dbo.api_proc_getStatementDates
go

create procedure dbo.api_proc_getStatementDates  @uID api_type_varcar_col readonly,  @planNum api_type_varcar_col readonly ,  @provID varchar(50)
as

 ;with fetch_part_id(d_part_id) as (
 SELECT DISTINCT PART_ID as d_part_id
 FROM SS_IDENT
 WHERE UID	in (select varchar_col from @uID)
 AND PROVID = @provID)

  SELECT DISTINCT rpt_date
  FROM ss_ident 
  WHERE part_id IN (select d_part_id from fetch_part_id)
    and plan_num IN (select varchar_col from @planNum) 
    and ss_ident.provid = @provID
    and ss_ident.uid   in (select varchar_col from @uID)
    and isactive = 1 
    and CommunicationTypeCD = 1 
	ORDER BY RPT_DATE DESC      
go

--**********************************************************************************

drop proc dbo.api_proc_get_name_to_process_statement
go

create procedure dbo.api_proc_get_name_to_process_statement @uID api_type_varcar_col readonly, @providerid int ,  @provID varchar(50)
as

 ;with fetch_part_id(d_part_id) as (
 SELECT DISTINCT PART_ID as d_part_id
 FROM SS_IDENT
 WHERE UID	in (select varchar_col from @uID)
 AND PROVID = @provID)

   SELECT DISTINCT FNAME, LNAME
   FROM PARTICIPANT
   WHERE   SSN  IN (select d_part_id from fetch_part_id)
   AND PROVIDERID  = @providerid
 
go
--**********************************************************************************

drop proc dbo.api_proc_get_SSIdentPartID
go

create procedure dbo.api_proc_get_SSIdentPartID 
@searchBy varchar(20) ,
@part_list api_type_varcar_col readonly,
@plan_name varchar(500),
@provID varchar(50),
@sponsor varchar(50)
as

    declare @sql nvarchar(2000)
    
    set @sql = ' SELECT  DISTINCT
                 FILE_NAME, DATESUBMITTED 
                 FROM 
                 SS_IDENT 
                 WHERE 1 = 1'
    
    if @searchBy = 'pLName'
    begin
       set @sql = @sql  + ' AND PART_ID IN (select varchar_col from @local_part_list) '
    end
    else if  @searchBy = 'pCode'
    begin
        set @sql = @sql  + ' AND PLAN_NUM LIKE '''+ @plan_name + '%''' 
    end
    else if  @searchBy = 'pName'
    begin
        set @sql = @sql  + ' AND PLAN_NUM IN 
                             ( 
                                SELECT PLAN_Plan_Num 
                                FROM plans 
                                WHERE plan_Plan_name LIKE '''+ @plan_name + '%''
                                AND plan_provid = '''+@provID+'''
                             ) '
    end
    
    set @sql = @sql  + '
     AND PROVID   = '''+ @provID + '''
                        AND  COMMUNICATIONTYPECD IN (
                                                        SELECT COMMUNICATIONTYPECD FROM tdCommunications
                                                        WHERE 
                                                        DESCRIP = ''Statements Combined'' '
    if @sponsor = 'SPONSOR'
    begin
        set @sql = @sql  + ' AND SCOPE   = ''SPONSOR'') '
    end
    else
    begin
        set @sql = @sql  + ' AND SCOPE   = ''ADMIN'') '
    end
    set @sql = @sql  + '  AND  FILELOCATIONTYPECD IN ( SELECT filelocationtypecd FROM tdFileLocation WHERE descrip = ''UI Repository'' ) AND ISACTIVE = 1'
    
    print @sql
	EXEC sys.[sp_executesql] @sql  , N'@local_part_list api_type_varcar_col readonly', @part_list
go  

--**********************************************************************************
drop proc dbo.api_proc_get_participant
go

create procedure dbo.api_proc_get_participant @providerID int, @useSSNPin int, @uid varchar(50), @parUUID varchar(50)
as

declare @sql nvarchar(2000)
set @sql = 'SELECT	participant.fname, participant.mi, participant.lname, participant.ssn, participant.acctnumber,
					participant.email, participant.userid, ''PLACEHOLDERVALUE1!'' as [password],  
                    participant.statuscode,
					statuscodes.statusname, participant.vcode, participant.participantid
			FROM	participant, statuscodes '

if @uid <> ''
begin
    set @sql = @sql + ',ss_ident'
end

    set @sql = @sql + ' WHERE	participant.statuscode=statuscodes.statuscode '

if @uid <> ''
begin
    if @useSSNPin = 1 or @useSSNPin = 2
    begin
        set @sql = @sql + ' AND ss_ident.part_id = participant.ssn '
    end
    else
    begin
        set @sql = @sql + ' AND ss_ident.part_id = participant.acctnumber '
    end
end

set @sql = @sql + ' AND participant.providerid = ' + Convert(nvarchar(10),@providerID)
if @uid <> ''
begin
    set @sql = @sql + ' AND ss_ident.uid = ''' + @uid + ''' '
end

set @sql = @sql + ' AND participant.participantUUID = '''+ @parUUID + ''' '
print @sql
EXEC sys.[sp_executesql] @sql 
go


--**********************************************************************************
drop proc dbo.api_proc_getSS_Ident_count
go

create procedure dbo.api_proc_getSS_Ident_count @part_id varchar(20)
as
	SELECT	count(part_id) as part_count
	FROM	ss_ident
	WHERE	part_id = @part_id
go


--**********************************************************************************
drop proc dbo.api_proc_update_participant
go

create procedure dbo.api_proc_update_participant 
@p_fname		varchar(20),
@p_mi			varchar(1),
@p_lname		varchar(20),
@p_email		varchar(80),
@p_password		varchar(32),
@p_statuscode	varchar(2),
@p_part_id int,
@p_acctnumber	varchar(20),
@p_bit_setAdmin bit
as

declare @sql nvarchar(2000)
declare @prev_pass nvarchar(50)

SELECT	@prev_pass = password
FROM	Participant
WHERE	ParticipantID = @p_part_id


set @sql = ' UPDATE	Participant SET	
            FName = ''' + @p_fname + '''
			,MI = ''' + @p_mi + '''
			,LName = ''' + @p_lname + '''
			,EMail = ''' + @p_email + ''' '
if @p_password	<> ''
begin
set @sql = @sql + ',Password = ''' + @p_password + ''' '
end

set @sql = @sql + ' ,StatusCode = ''' + @p_statuscode + '''
			,LastChange = getdate()
			,LastChangeID = ' + convert(varchar(10), @p_part_id ) 

if @p_acctnumber	<> ''
begin
set @sql = @sql + ',AcctNumber = ''' + @p_acctnumber + ''' '
end

if @p_bit_setAdmin = 1
begin
set @sql = @sql + ',PasswordEditByAdmin = 1
,PrevPassword = ''' + @prev_pass  + ''' '
end

set @sql = @sql + ' ,isPasswordHashed = 1
			        ,failedAuthAttempts = 0
			        WHERE	ParticipantID =  ''' + convert(varchar(10), @p_part_id)  + ''' '
					print @sql
EXEC sys.[sp_executesql] @sql 
go

--**********************************************************************************
drop proc dbo.api_proc_update_ss_ident
go

create procedure dbo.api_proc_update_ss_ident 
@p_fname		varchar(20),
@p_uid 			varchar(50),
@p_lname		varchar(20)
as
	UPDATE	ss_ident
	SET		fname = @p_fname
			,lname = @p_lname
	WHERE	uid = @p_uid
go