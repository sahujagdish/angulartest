use SponsorPortal
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_getby_userdefinable]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_getby_userdefinable;
go

CREATE PROCEDURE [dbo].spadmin_proc_getby_userdefinable
AS
SELECT * FROM tdContentCategories WHERE isUserDefinable = 1 ORDER BY Name
GO


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_getcontent_items]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_getcontent_items;
go

CREATE PROCEDURE [dbo].spadmin_proc_getcontent_items @useGenericMenuCategoriesForEBN bit, 
@providerID  uniqueidentifier, @ContentCategoryId int, @ContentType varchar(50)
as

if @useGenericMenuCategoriesForEBN =1 
begin
	print 'Yes useGenericMenuCategoriesForEBN'
	if @ContentType = ''
	begin
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID 
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId
			ORDER BY tdContentTypes.AdminSiteText
	end
	else
	begin
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID 
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId			
			and tdContentTypes.ContentScope = @ContentType
			ORDER BY tdContentTypes.AdminSiteText	
	end
end
else
begin
	print 'not useGenericMenuCategoriesForEBN'
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId
			ORDER BY tdContentTypes.AdminSiteText	
end
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_getcontent_categories ]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_getcontent_categories ;
go

CREATE PROCEDURE [dbo].spadmin_proc_getcontent_categories @useGenericMenuCategoriesForEBN bit, 
@providerID  uniqueidentifier, @ContentType varchar(50), @contentCategoryId varchar(10)
as
if @useGenericMenuCategoriesForEBN =1 
begin
		SELECT tdContentCategories.ContentCategoryId, teLink.Description AS Name 
		FROM tdContentCategories INNER JOIN
        teLink ON tdContentCategories.ContentCategoryId = teLink.ContentCategoryId INNER JOIN
        teProvider_ContentCategories ON tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		WHERE (teProvider_ContentCategories.ProviderID = @providerID) 
		AND (tdContentCategories.isUserDefinable = 1)
		ORDER BY teLink.sOrder
end
else
begin
	if  @ContentType = ''
	begin
		SELECT tdContentCategories.ContentCategoryId,tdContentCategories.Name
		FROM tdContentCategories, teProvider_ContentCategories
		WHERE  tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		AND teProvider_ContentCategories.ProviderID = @providerID
		AND (tdContentCategories.isUserDefinable = 1) 
		AND (tdContentCategories.ContentCategoryId != @contentCategoryId )
		ORDER BY tdContentCategories.Name
	end
	else
	begin
		SELECT tdContentCategories.ContentCategoryId,tdContentCategories.Name
		FROM tdContentCategories, teProvider_ContentCategories
		WHERE  tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		AND teProvider_ContentCategories.ProviderID = @providerID
		AND (tdContentCategories.isUserDefinable = 1) 
		AND (tdContentCategories.ContentCategoryId != @contentCategoryId )
		and (tdContentCategories.Scope = @ContentType or tdContentCategories.Scope = 'ALL')
		ORDER BY tdContentCategories.Name
	end
end
go
---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_adduserdefined_contentitem ]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_adduserdefined_contentitem ;
go

CREATE PROCEDURE [dbo].spadmin_proc_adduserdefined_contentitem @scope varchar(10),
@contentCategoryId int , @fileType varchar(200), @contentName varchar(100),
@providerID  uniqueidentifier ,@useGenericMenuCategoriesForEBN bit
as

declare @p_next_id numeric
declare @p_error numeric

EXEC [dbo].[p_next_id]  'tdContentTypes' ,@p_next_id output, @p_error output 

if @p_error = 0
begin

	DECLARE @sProductCode varchar(20)
	set @sProductCode = 'UDC' + CONVERT(varchar(10),@p_next_id)

	select @fileType = rtrim(ltrim(@fileType))

	declare @sFileName varchar(200)
	set @sFileName = @sProductCode + '.' + @fileType;	


	if @useGenericMenuCategoriesForEBN = 1
	begin
				INSERT INTO tdContentTypes(ContentId,Name,Description,AdminSiteText,FileName,ContentCategoryId,isUploadable,ProductCode,ContentScope,StaticContent)
				VALUES(@p_next_id,@contentName ,@contentName ,@contentName ,@sFileName,@contentCategoryId,1,@sProductCode,@scope,0)
	end
	else
	begin
			INSERT INTO tdContentTypes(ContentId,Name,Description,AdminSiteText,FileName,ContentCategoryId,isUploadable,ProductCode)
				VALUES(@p_next_id, @contentName, @contentName, @contentName,@sFileName,@contentCategoryId,1,@sProductCode)
	end

	--implementation for 'qInsProvider_ContentTypes' function
	INSERT INTO teProvider_ContentTypes(ProviderID,ContentID)
	VALUES(@providerID,@p_next_id)
end

select @p_next_id  as NextID, @p_error as ErrorID
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_content_types ]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_content_types ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_content_types @providerID  uniqueidentifier ,@useGenericMenuCategoriesForEBN bit
as

if @useGenericMenuCategoriesForEBN = 1
begin
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, 
		tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText, 
		tdContentTypes.isInstanced
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories  
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND (tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId)	
		AND (tdContentTypes.isUploadable = 1) 
		AND (teProvider_ContentTypes.ProviderID = @providerID)
		AND (tdContentTypes.ContentScope = 'PLAN')
		ORDER BY tdContentTypes.Name
end
else
begin
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, 
		tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText, 
		tdContentTypes.isInstanced
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories  
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND (tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId)	
		AND (tdContentTypes.isUploadable = 1) 
		AND (teProvider_ContentTypes.ProviderID = @providerID)
		AND (tdContentCategories.Scope = 'PLAN')
		ORDER BY tdContentTypes.Name
end
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_plan_content]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_plan_content ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_plan_content @planid int
as

	SELECT tePlan_Document.ContentId, tePlan_Document.dateUpdated, tePlan_Document.isActive
    ,tePlan_Document.Plan_DocumentID, tePlan_Document.isInProduction, 
	tdContentTypes.Name, tdContentTypes.Name + ' ' + Cast(Format(tePlan_Document.dateUpdated, 'd','en-US') as varchar(10)) As InstancedName
    ,tePlan_Document.InstanceId, tdContentTypes.ProductCode, tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText
    FROM tePlan_Document, tdContentTypes 
    WHERE (tdContentTypes.ContentId = tePlan_Document.ContentId)
    AND (tePlan_Document.PlanId = @planid)
    AND (tdContentTypes.isUploadable = 1)
    AND ((tePlan_Document.ExpirationDate IS NULL) or (tePlan_Document.ExpirationDate > getdate()))
    ORDER BY Name, InstancedName	
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_plan_number]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_plan_number ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_plan_number  @planid int, @providerID  uniqueidentifier 
as
	SELECT tePlan.Number, tePlan.Name, teSponsor.Name as SponsorName
	FROM tePlan, teSponsor
	WHERE tePlan.SponsorId = teSponsor.SponsorId
	AND tePlan.PlanId =  @planid
	AND teSponsor.ProviderId = @providerID
	AND tePlan.isActive = 1
go



---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_insert_update_document_upload]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_insert_update_document_upload ;
go

CREATE PROCEDURE [dbo].spadmin_proc_insert_update_document_upload @contentId int,@planId int, @instanceId int, @userId uniqueidentifier, @fileExisted bit
as
declare @count int
declare @sql nvarchar(1000)
set @sql = 'SELECT @c = count(*) 
		FROM tePlan_Document
		WHERE ContentID = ' + convert(nvarchar(12), @contentId)+ '
		AND PlanId = ' +convert(nvarchar(12), @planId) + '
		AND isInProduction = 0 '

		if @instanceId > 0
		begin
		set @sql = @sql + ' AND InstanceId = '+  CONVERT(varchar(10), @instanceId)
		end

		print @sql 
EXEC sys.[sp_executesql] @sql , N'@c int out', @count out

--if record exists update 
if @count > 0 and  @fileExisted = 1
begin
print 'in update'
	declare @sql_update nvarchar(2000)
	set @sql_update = '
		UPDATE tePlan_Document
		SET isActive = 0
			, dateUpdated = getdate()
			, UserId = '+ CONVERT(varchar(40), @userId) + '
			, publishedfrom =  2
		WHERE ContentID = '+  CONVERT(varchar(50),  @contentId )+ '
			AND PlanId = ' +  CONVERT(varchar(50),@planId) + '
			AND isInProduction = 0'

	if @instanceId > 0
	begin
		set @sql_update = ' AND InstanceId = ' +  CONVERT(varchar(50),@instanceId)
	end

	print @sql_update 

	EXEC sys.[sp_executesql] @sql_update
end
else
begin
print 'in insert'
	declare @sql_insert nvarchar(2000)
	set @sql_insert = '
	 INSERT INTO tePlan_Document(PlanId,ContentId,isActive,isInProduction,dateUpdated,UserId,PublishedFrom,InstanceId)
                VALUES('+ CONVERT(varchar(50), @planId )+ ', ' +  CONVERT(varchar(50), @contentId) + ',0,0,getdate(),'''+  CONVERT(varchar(50), @userId)+''',2'
				
	if @instanceId > 0
	begin
		set @sql_insert = @sql_insert + ' , ' + @instanceId + ')'
	end
	else
		begin
		set @sql_insert = @sql_insert + ' , null)'
	end
	print @sql_insert 

	EXEC sys.[sp_executesql] @sql_insert 
end
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_update_plan_document]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_update_plan_document ;
go

CREATE PROCEDURE [dbo].spadmin_proc_update_plan_document @userid uniqueidentifier, @contentId int,@planId int, @instanceId int
as
if @instanceId > -1
begin
		UPDATE tePlan_Document
		SET isActive = 0 , dateUpdated = getdate() , UserId = @userid , publishedfrom = 2
		WHERE ContentID = @contentId
		AND PlanId = @planId
		AND isInProduction = 0
		AND InstanceId = @instanceId
end
else
begin
		UPDATE tePlan_Document
		SET isActive = 0 , dateUpdated = getdate() , UserId = @userid , publishedfrom = 2
		WHERE ContentID = @contentId
		AND PlanId = @planId
		AND isInProduction = 0
end
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_prov_link]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_prov_link;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_prov_link @providerID  uniqueidentifier, @contentId int
as
		SELECT teLink.LinkId,teLink.sOrder,teLink.Description, teLink.ContentCategoryId
		FROM teLink, tdContentTypes 
		WHERE teLink.ContentCategoryId = tdContentTypes.ContentCategoryId 
		AND tdContentTypes.ContentId = @contentId
		AND teLink.ProviderId =@providerID
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[spadmin_proc_get_plan_link]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_plan_link;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_plan_link @planid int, @linkid int
as
		SELECT Plan_LinkID
		FROM tePlan_Link
		WHERE PlanID = @planid
		AND LinkId = @linkid
go

---**************************************************************************************************************************************
--IF OBJECT_ID('[spadmin_proc_get_instanced_content]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_instanced_content;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_instanced_content @planid int, @providerID  uniqueidentifier,@contentId int
as
		SELECT tePlan_Document.Plan_DocumentId, tdContentTypes.Name, tePlan_Document.InstanceId, 
        tdContentTypes.Name + ' ' + CAST(Format(tePlan_Document.dateUpdated, 'd', 'en-US') AS varchar(10)) AS InstancedName
		FROM tePlan INNER JOIN
		tePlan_Document ON tePlan.PlanId = tePlan_Document.PlanId INNER JOIN
		teSponsor ON tePlan.SponsorId = teSponsor.SponsorId INNER JOIN
		tdContentTypes ON tePlan_Document.ContentId = tdContentTypes.ContentId
		WHERE  tePlan.PlanId = @planid
		AND teSponsor.ProviderId = @providerID
		AND tePlan.isActive = 1
		AND tePlan_Document.ContentID = @contentId
		AND ((tePlan_Document.ExpirationDate IS NULL) or (tePlan_Document.ExpirationDate > getdate()))
		ORDER BY InstancedName
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_insert_update_teProvider_Document]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_insert_update_teProvider_Document ;
go

CREATE PROCEDURE [dbo].spadmin_proc_insert_update_teProvider_Document @userid uniqueidentifier,
@providerid uniqueidentifier, @contentId int, @fileExisted bit
as
if @fileExisted = 1
begin
		UPDATE teProvider_Document
		SET isActive = 0
		, dateUpdated = getdate()
		, UserId = @userid
		WHERE ContentID = @contentId
		AND ProviderId = @providerid
		AND isInProduction = 0
end
else
begin

		INSERT INTO teProvider_Document(ProviderId,ContentId,isActive,isInProduction,dateUpdated,UserId)
			VALUES(@providerid, @contentId,0,0, getdate(),@userid)
end
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_delete_teProvider_Document]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_delete_teProvider_Document ;
go

CREATE PROCEDURE [dbo].spadmin_proc_delete_teProvider_Document @providerid uniqueidentifier, @contentId int
as

		DELETE
		FROM teProvider_Document
		WHERE ContentID = @contentId
		AND isInProduction = 1
		AND ProviderId = @providerid

go
---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_fileName_with_contentId]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_fileName_with_contentId ;
go

CREATE PROCEDURE [dbo].spadmin_proc_fileName_with_contentId @providerid uniqueidentifier, @docId int
as

		SELECT FileName, teProvider_Document.ContentId
		FROM tdContentTypes, teProvider_Document 
		WHERE tdContentTypes.ContentId = teProvider_Document.ContentId 
		AND teProvider_Document.Provider_DocumentId = @docId
		AND teProvider_Document.ProviderId = @providerid
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_provider_content]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_provider_content ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_provider_content @providerid uniqueidentifier 
as
	SELECT teProvider_Document.ContentId, teProvider_Document.dateUpdated, teProvider_Document.isActive
		,teProvider_Document.Provider_DocumentID, teProvider_Document.isInProduction
		,tdContentTypes.Name, tdContentTypes.ProductCode, tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText
	FROM teProvider_Document, tdContentTypes 
	WHERE (tdContentTypes.ContentId = teProvider_Document.ContentId)
		AND (teProvider_Document.ProviderId = @providerid) 
		AND (tdContentTypes.isUploadable = 1)
		ORDER BY Name	
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_provider_content_types]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_provider_content_types ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_provider_content_types @providerid uniqueidentifier, @useGenericMenuCategoriesForEBN bit
as
	declare @sql nvarchar(1000)
	set @sql = '
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, tdContentTypes.AdminSiteText + ''['' + tdContentTypes.ProductCode + '']'' as AdminSiteText
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories 
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
		AND tdContentTypes.isUploadable = 1
		AND teProvider_ContentTypes.ProviderID = ''' + CONVERT(varchar(50),  @providerid ) + ''''

	if @useGenericMenuCategoriesForEBN = 1
	begin
		set @sql =  @sql  + ' AND tdContentTypes.ContentScope = ''PROVIDER'''
	end
	else
	begin
		set @sql =  @sql +  ' AND tdContentCategories.Scope = ''PROVIDER'''
	end
	
	set @sql =  @sql +  ' ORDER BY tdContentTypes.Name'
	print @sql
	EXEC sys.[sp_executesql] @sql
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_custom_fund_code]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_custom_fund_code ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_custom_fund_code  @providerid uniqueidentifier, @customFundCode varchar(50)
as
	SELECT CustomFundCode
	FROM teMasterFund
	WHERE ProviderId = @providerid
	AND CustomFundCode = @customFundCode
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_standard_performance]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_standard_performance ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_standard_performance @providerid uniqueidentifier, 
@fundfeedType varchar(50), @fundfeedTypeValue varchar(50)
as

declare @sqlcmd nvarchar(2000)
set @sqlcmd = 'SELECT MasterFundID   FROM [SponsorPortal].[dbo].[teMasterFund]
				 WHERE  providerid = ''' + convert(nvarchar(36), @providerid) + ''' AND ' + @fundfeedType + ' = '+  @fundfeedTypeValue + '
                    AND CustomFund  = 0'
print @sqlcmd		
EXEC sys.[sp_executesql] @sqlcmd		
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_file]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_file ;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_file @providerid uniqueidentifier, 
@customfundcode varchar(50), @invType varchar(50)
as

	declare @sql nvarchar(1000)
	set @sql = 'SELECT CustomFundCode FROM teProviderCustomInvestments
				WHERE CustomFundCode = '''+ @customfundcode + '''
				AND ProviderId = '''+  convert(nvarchar(36),@providerid) + '''
				AND isInProduction = 0'
	if @invType = 'fund'
	begin
		set @sql = @sql + ' AND isFund = 1'
	end
	else
	begin
		set @sql = @sql + ' AND isProspectus = 1'
	end

	EXEC sys.[sp_executesql] @sql		
go



---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_upd_provider_custom_investments]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_upd_provider_custom_investments ;
go

CREATE PROCEDURE [dbo].spadmin_proc_upd_provider_custom_investments @userId uniqueidentifier, @providerId uniqueidentifier, 
@customfundcode varchar(50), @invType varchar(50)
as

	declare @sql nvarchar(1000)
	set @sql = 'UPDATE teProviderCustomInvestments
			SET isActive = 0
				, dateUpdated = getdate()
				, UserId = '''+  convert(nvarchar(36),@userId )+ '''' 
	
	if @invType = 'fund'
	begin
		set @sql = ' ,isFund = 1'
	end
	else
	begin
		set @sql = ' ,isProspectus = 1'
	end

	set @sql = ' WHERE CustomFundCode = ''' + @customfundcode + ''' 
				AND ProviderId = ''' +  convert(nvarchar(36),@providerId )+ '''
				AND isInProduction = 0 '

	EXEC sys.[sp_executesql] @sql		
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_insert_update_custom_investment]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_insert_update_custom_investment ;
go


alter PROCEDURE [dbo].spadmin_proc_insert_update_custom_investment 
@providerid uniqueidentifier,
@userId uniqueidentifier  ,
@customfundcode varchar(50), 
@invType varchar(50)
as
--Look of existing record
	declare @count int
	set @count = -1
	declare @sql nvarchar(1000)
	set @sql = ' SELECT @c = count(*) FROM teProviderCustomInvestments
				WHERE CustomFundCode = '''+ @customfundcode + '''
				AND ProviderId = '''+ convert(nvarchar(36),  @providerid) + ''' AND isInProduction = 0 '
	if @invType = 'fund'
	begin
		set @sql = @sql + ' AND isFund = 1'
	end
	else
	begin
		set @sql = @sql + ' AND isProspectus = 1'
	end

	EXEC sys.[sp_executesql] @sql , N'@c int out', @count out
	
--if record exists update 
if @count > 0
begin
	declare @up_sql nvarchar(1000)
	set @up_sql = 'UPDATE teProviderCustomInvestments
			SET isActive = 0
				, dateUpdated = getdate()
				, UserId = '''+ convert(nvarchar(36), @userId) + ''' ' 
	
	if @invType = 'fund'
	begin
		set @up_sql = @up_sql + ' ,isFund = 1'
	end
	else
	begin
		set @up_sql = @up_sql + ' ,isProspectus = 1'
	end

	set @up_sql = @up_sql + ' WHERE CustomFundCode = ''' + @customfundcode + ''' 
				AND ProviderId = ''' +  convert(nvarchar(36),@providerId )+ '''
				AND isInProduction = 0 '
				print @up_sql
	EXEC sys.[sp_executesql] @up_sql
	
end
else
begin
--Insert if not exists
	declare @isfund int
	declare @ispros int

	if @invType = 'fund'
	begin
		set @isfund = 1
		set @ispros = 0
	end
	else
	begin
		set @isfund = 0
		set @ispros = 1
	end

	INSERT INTO teProviderCustomInvestments(ProviderId,CustomFundCode,isActive,isInProduction,dateUpdated,UserId,isFund,isProspectus)
	VALUES(@providerId,@customfundcode,0,0,GETDATE(),@userId,@isfund,@ispros)
end
go




---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_fileName_for_invid]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_fileName_for_invid ;
go


create PROCEDURE [dbo].spadmin_proc_get_fileName_for_invid 
@providerid uniqueidentifier,
@invid  int
as

	SELECT CustomFundCode,isFund,isProspectus
	FROM teProviderCustomInvestments 
	WHERE ProviderCustomInvestmentID = @invid 
	AND ProviderID = @providerid
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_del_production_content]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_del_production_content ;
go

create PROCEDURE [dbo].spadmin_proc_del_production_content 
@providerid uniqueidentifier,
@custfundcode varchar(50),
@isfund bit
as
	declare @sql nvarchar(2000)
	set @sql = ' DELETE
	FROM teProviderCustomInvestments
	WHERE CustomFundCode = ''' + @custfundcode + '''
	AND isInProduction = 1
	AND ProviderId = ''' +  convert(nvarchar(36),@providerid) + ''' '
	
	if @isfund = 1
	begin
		set @sql = @sql + ' AND isFund = 1 '
	end
	else
	begin
		set @sql = @sql + ' AND isProspectus = 1 '
	end

	EXEC sys.[sp_executesql] @sql
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_del_teplan_fund]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_del_teplan_fund ;
go

create PROCEDURE [dbo].spadmin_proc_del_teplan_fund
@masterFundIdList varchar(200)
as
	declare @sql nvarchar(1000)
	set @sql = '	IF EXISTS (SELECT MasterFundID FROM teplan_fund WHERE MasterFundID in(' + @masterFundIdList + '))
					begin
    					DELETE FROM teplan_fund WHERE MasterFundID in(' + @masterFundIdList + ')
					end '
	EXEC sys.[sp_executesql] @sql
go

---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_del_master_fund]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_del_master_fund ;
go

create PROCEDURE [dbo].spadmin_proc_del_master_fund
@masterFundIdList varchar(200),
@providerid uniqueidentifier
as
	declare @sql nvarchar(1000)
	set @sql = '	DELETE FROM [teMasterFund]
			WHERE
			MasterFundID in(' + @masterFundIdList + ')
			and
			ProviderId = ''' +  convert(nvarchar(36),@providerid) + ''
	EXEC sys.[sp_executesql] @sql
go



---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_custom_fund_details]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_custom_fund_details;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_custom_fund_details @providerID  uniqueidentifier, @MasterFundID int
AS
				SELECT  
				CASE WHEN Name IS NOT NULL THEN Name ELSE '' END AS Name
				,CASE WHEN FundID IS NOT NULL THEN FundID ELSE '' END AS FundID
				,CASE WHEN Cusip IS NOT NULL THEN rtrim(cusip) ELSE '' END AS cusip
				,CASE WHEN Ticker IS NOT NULL THEN rtrim(ticker) ELSE '' END AS ticker
				,CASE WHEN CustomFundCode IS NOT NULL THEN CustomFundCode ELSE '' END AS CustomFundCode
				,CASE WHEN AssetClass IS NOT NULL THEN AssetClass ELSE '' END AS AssetClass
				,CASE WHEN OneMonth = - 999 OR OneMonth IS NULL THEN '' ELSE Cast(OneMonth AS varchar(10))END AS OneMonth
				,CASE WHEN ThreeMonth = - 999 OR ThreeMonth IS NULL THEN '' ELSE Cast(ThreeMonth AS varchar(10))END AS ThreeMonth
				,CASE WHEN OneYear = - 999 OR OneYear IS NULL THEN '' ELSE Cast(OneYear AS varchar(10))END AS OneYear
				,CASE WHEN ThreeYear = - 999 OR ThreeYear IS NULL THEN '' ELSE Cast(ThreeYear AS varchar(10))END AS ThreeYear
				,CASE WHEN FiveYear = - 999 OR FiveYear IS NULL THEN '' ELSE Cast(FiveYear AS varchar(10))END AS FiveYear
				,CASE WHEN TenYear = - 999 OR TenYear IS NULL THEN '' ELSE Cast(TenYear AS varchar(10))END AS TenYear
				,CASE WHEN AsOfDate IS NOT NULL THEN CONVERT(varchar(10), AsofDate, 101) ELSE '' END AS AsOfDate
				,CASE WHEN SinceInception = - 999 OR SinceInception IS NULL THEN '' ELSE Cast(SinceInception AS varchar(10))END AS SinceInception
				,CASE WHEN PrevYr1Return = - 999 OR PrevYr1Return IS NULL THEN '' ELSE Cast(PrevYr1Return AS varchar(10))END AS PrevYr1Return
				,CASE WHEN PrevYr2Return = - 999 OR PrevYr2Return IS NULL THEN '' ELSE Cast(PrevYr2Return AS varchar(10))END AS PrevYr2Return
				,CASE WHEN PrevYr3Return = - 999 OR PrevYr3Return IS NULL THEN '' ELSE Cast(PrevYr3Return AS varchar(10))END AS PrevYr3Return
				,CASE WHEN PrevYr4Return = - 999 OR PrevYr4Return IS NULL THEN '' ELSE Cast(PrevYr4Return AS varchar(10))END AS PrevYr4Return
				,CASE WHEN PrevYr5Return = - 999 OR PrevYr5Return IS NULL THEN '' ELSE Cast(PrevYr5Return AS varchar(10))END AS PrevYr5Return
				,CASE WHEN PrevYr6Return = - 999 OR PrevYr6Return IS NULL THEN '' ELSE Cast(PrevYr6Return AS varchar(10))END AS PrevYr6Return
				,CASE WHEN YTD = - 999 OR YTD IS NULL THEN '' ELSE Cast(YTD AS varchar(10))END AS YTD
				,CASE WHEN Inception IS NOT NULL THEN CONVERT(varchar(10), Inception, 101) ELSE '' END AS Inception
				,CASE WHEN ExpRatio = - 999 OR ExpRatio IS NULL THEN '' ELSE Cast(ExpRatio AS varchar(10))END AS ExpRatio
				,CASE WHEN ExpDate IS NOT NULL THEN Cast(rtrim(ExpDate) AS varchar(10)) ELSE '' END AS ExpDate
				,CASE WHEN NetExpRatio = - 999 OR NetExpRatio IS NULL THEN '' ELSE Cast(NetExpRatio AS varchar(11))END AS NetExpRatio
				,CASE WHEN MgmtStylePassive = 1 THEN 'Passive' 
                	  WHEN MgmtStylePassive = 0 THEN 'Active'  	
                      ELSE ''
                 END AS MgmtStylePassive     
				,CASE WHEN WebSite IS NOT NULL THEN WebSite ELSE '' END AS WebSite
				,CASE WHEN MorningStarCategory IS NOT NULL THEN MorningStarCategory ELSE '' END AS MorningStarCategory
				,CASE WHEN BenchmarkName IS NOT NULL THEN BenchmarkName ELSE '' END AS BenchmarkName
				,CASE WHEN BenchmarkOneMonth = - 999 OR BenchmarkOneMonth IS NULL THEN '' ELSE Cast(BenchmarkOneMonth AS varchar(11))END AS BenchmarkOneMonth
				,CASE WHEN BenchmarkThreeMonth = - 999 OR BenchmarkThreeMonth IS NULL THEN '' ELSE Cast(BenchmarkThreeMonth AS varchar(11))END AS BenchmarkThreeMonth
				,CASE WHEN BenchmarkOneYear = - 999 OR BenchmarkOneYear IS NULL THEN '' ELSE Cast(BenchmarkOneYear AS varchar(11))END AS BenchmarkOneYear
				,CASE WHEN BenchmarkThreeYear = - 999 OR BenchmarkThreeYear IS NULL THEN '' ELSE Cast(BenchmarkThreeYear AS varchar(11))END AS BenchmarkThreeYear
				,CASE WHEN BenchmarkFiveYear = - 999 OR BenchmarkFiveYear IS NULL THEN '' ELSE Cast(BenchmarkFiveYear AS varchar(11))END AS BenchmarkFiveYear
				,CASE WHEN BenchmarkTenYear = - 999 OR BenchmarkTenYear IS NULL THEN '' ELSE Cast(BenchmarkTenYear AS varchar(11))END AS BenchmarkTenYear
				,CASE WHEN BenchNote IS NOT NULL THEN BenchNote ELSE '' END AS BenchNote
				,CASE WHEN MgmtFee = - 999 OR MgmtFee IS NULL THEN '' ELSE Cast(MgmtFee AS varchar(11))END AS MgmtFee 
				,CASE WHEN Fee12B1 = - 999 OR Fee12B1 IS NULL THEN '' ELSE Cast(Fee12B1 AS varchar(11))END AS Fee12B1
				,CASE WHEN OtherFees = - 999 OR OtherFees IS NULL THEN '' ELSE Cast(OtherFees AS varchar(11))END AS OtherFees
				,CASE WHEN RedemptionFee = - 999 OR RedemptionFee IS NULL THEN '' ELSE Cast(RedemptionFee AS varchar(11))END AS RedemptionFee
				,CASE WHEN RedeemDays IS NULL THEN '' ELSE  Cast(RedeemDays AS varchar(3)) END AS RedeemDays
				,CASE WHEN FrontEndSalesCharge = - 999 OR FrontEndSalesCharge IS NULL THEN '' ELSE Cast(FrontEndSalesCharge AS varchar(11))END AS FrontEndSalesCharge
				,CASE WHEN DeferredSalesCharge = - 999 OR DeferredSalesCharge IS NULL THEN '' ELSE Cast(DeferredSalesCharge AS varchar(11))END AS DeferredSalesCharge
				,UseStandardPerformance
                ,customprospectus,customFundFactSheet
			FROM teMasterFund
			WHERE (ProviderId = @providerID)
				AND MasterFundID = @MasterFundID 
go




---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_custom_funds]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_custom_funds;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_custom_funds @providerID  uniqueidentifier, @fundName varchar(200) , @CustomFundCode varchar(50),
@Cusip varchar(50),  @Ticker varchar(50),  @fundid varchar(50)
AS
	declare @sql nvarchar(1000)

	set @sql = 'SELECT MasterFundId, Name
				FROM teMasterFund 
				WHERE (ProviderId = '+  convert(nvarchar(36),@providerID) + ')
				AND CustomFund = 1'

	if @fundName <> ''
	begin
	set @sql = @sql + ' AND (Name LIKE '''+@fundName+ '%'') '
	end

	if @CustomFundCode <> ''
	begin
	set @sql = @sql + ' AND (CustomFundCode LIKE '''+@CustomFundCode+'%'') '
	end

	if @Cusip <> ''
	begin
	set @sql = @sql + ' AND (cusip LIKE '''+@Cusip+'%'') '
	end

	if @Ticker <> ''
	begin
	set @sql = @sql + ' AND (ticker LIKE '''+@Ticker+'%'') '
	end

	if @fundid <> ''
	begin
	set @sql = @sql + ' AND (fundid LIKE '''+@fundid+'%'') '
	end
	
	set @sql = @sql + '	ORDER BY NAME'

	EXEC sys.[sp_executesql] @sql
go


---**************************************************************************************************************************************

--IF OBJECT_ID('[spadmin_proc_get_custom_investments]', 'U') IS NOT NULL
DROP PROCEDURE dbo.spadmin_proc_get_custom_investments;
go

CREATE PROCEDURE [dbo].spadmin_proc_get_custom_investments @providerID  uniqueidentifier
AS
	SELECT MasterFundId, Name, CUSIP, FundID, Ticker, CustomFundCode
	FROM teMasterFund 
	WHERE (CustomFund = 1) AND (ProviderId = @providerID ) 
	ORDER BY Name
go

