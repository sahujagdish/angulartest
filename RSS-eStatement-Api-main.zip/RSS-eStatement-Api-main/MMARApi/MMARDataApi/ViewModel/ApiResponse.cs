﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMApi.ViewModel
{
    #region using
    using System;
    using System.Linq;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.ActionConstraints;
    using Microsoft.AspNetCore.Mvc.ApplicationModels;
    #endregion using

    public class RequiredFromQueryAttribute : FromQueryAttribute, IParameterModelConvention
    {
        public void Apply( ParameterModel parameter )
        {
            if ( parameter.Action.Selectors != null && parameter.Action.Selectors.Any() )
            {
                parameter.Action.Selectors.Last().ActionConstraints.Add( new RequiredFromQueryActionConstraint( parameter.BindingInfo?.BinderModelName ?? parameter.ParameterName ) );
            }
        }
    }
    public class RequiredFromQueryActionConstraint : IActionConstraint
    {
        private readonly string _parameter;

        public RequiredFromQueryActionConstraint( string parameter )
        {
            _parameter = parameter;
        }

        public int Order => 999;

        public bool Accept( ActionConstraintContext context )
        {
            if ( !context.RouteContext.HttpContext.Request.Query.ContainsKey( _parameter ) )
            {
                return false;
            }

            return true;
        }
    }

    public class ApiResponse
    {
        #region Public Properties
        /// <summary>
        ///     Status code that will be used for the repsone
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        ///     Message to be delivered with the response
        /// </summary>
        public string Message { get; set; }
        #endregion Public Properties

        #region Constructor
        /// <summary>
        ///     Default Constructor
        /// </summary>
        /// <param name="statusCode">
        ///     Status code assined to this object
        /// </param>
        /// <param name="message">
        ///     Possible message to the response for this object
        /// </param>
        public ApiResponse( int statusCode, string message = null )
        {
            StatusCode = statusCode;
            Message = String.IsNullOrEmpty( message ) ? getDefaultMessageForStatusCode( statusCode ) : message;
        }
        #endregion Constructor

        #region Private Methods
        /// <summary>
        ///     Interperates a status code to a message
        /// </summary>
        /// <param name="statusCode">
        ///     Status code to evaluate
        /// </param>
        /// <returns>
        ///     Message associated with a status code
        /// </returns>
        private string getDefaultMessageForStatusCode( int statusCode )
        {
            switch( statusCode )
            {
                case 400:
                    return "Bad request";
                case 404:
                    return "Resource not found";
                case 409:
                    return "Conflict";
                case 500:
                    return "An unhandeled error occurred";
                default:
                    return null;
            }
        }
        #endregion Private Methods
    }
}
