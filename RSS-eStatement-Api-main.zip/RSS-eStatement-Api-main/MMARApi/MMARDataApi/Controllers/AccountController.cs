﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Controllers
{
    #region Using
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using MMARDataApi.Models;
    using System;
    using System.Collections.Generic;
    using Microsoft.Data.SqlClient;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    #endregion Using

    [Produces( "application/json" )]
    [Route( "api/v1/Statement" )]
    [EnableCors( "CorsPolicy" )]
    [ApiExplorerSettings( GroupName = "auth" )]
    public class AccountController : Controller
    {
        private IConfiguration configuration;
        private readonly ILogger<AccountController> logger;

        #region Contructor
        /// <summary>
        ///     Default constructor that uses deendancy injection
        ///     to get the configuraion
        /// </summary>
        /// <param name="config">
        ///     Constructed application configuation
        /// </param>
        public AccountController( IConfiguration config, ILogger<AccountController> logger )
        {
            configuration = config;
            this.logger = logger;
        }
        #endregion Constructor

        /// <summary>
        ///     Authorizes a user and issues a token
        /// </summary>
        /// <param name="clientid">
        ///     Client that is requesting the Authorization
        /// </param>
        /// <param name="Username">
        ///     User to authorize
        /// </param>
        /// <param name="Password">
        ///     Users password
        /// </param>
        /// <returns>
        ///     JWT if authorized
        /// </returns>
        [HttpPost( "auth" )]
        [AllowAnonymous]
        [ProducesResponseType( StatusCodes.Status200OK )]
        public IActionResult Auth( [FromBody] AuthUser user )
        {
            try
            {

                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    string hashPassword = md5Hash( user.password );
                    var entity = from login in context.AdminEntity
                                                 where 
                                                       login.providerid == user.clientid &&
                                                       login.userId.Equals( user.username ) &&
                                                       login.password.Trim() == hashPassword
                                                 select (login);

                    if ( entity != null && entity.Count() == 1 )
                    {
                        return new OkObjectResult( entity.First().administratorUUID );
                    }
                    else
                    {
                        return new OkObjectResult( "Invalid username and/or Password" );
                    }
                }

            }
            catch ( Exception ex )
            {
                return new OkObjectResult( ex.Message + " : " + ex.StackTrace );
            }
        }

        #region pivate methods
        /// <summary>
        ///     Converts the MD5 encrypted input string 
        ///     to the unencrypted value
        /// </summary>
        /// <param name="input">
        ///     MD5 encrypted string
        /// </param>
        /// <returns>
        ///     Unencrypted string
        /// </returns>
        private string md5Hash( string input )
        {
            byte[] bytes = Encoding.ASCII.GetBytes( input );
            using ( var md5 = MD5.Create() )
            {
                var result =  string.Join( "", md5.ComputeHash( bytes ).Select( x => x.ToString( "X2" ) ) );

                return result;
            }
        }
        #endregion pivate methods
    }
}