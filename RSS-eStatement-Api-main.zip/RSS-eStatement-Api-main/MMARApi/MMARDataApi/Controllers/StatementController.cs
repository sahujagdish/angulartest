﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Controllers
{
    #region using
    using Microsoft.AspNetCore.Authentication;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Caching.Memory;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using MMApi.ViewModel;
    using MMARDataApi.Models;
    using PdfSharpCore.Pdf;
    using PdfSharpCore.Pdf.IO;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Threading.Tasks;
    #endregion using

    [Produces( "application/json" )]
    [Route( "api/v1/[controller]" )]
    [EnableCors( "CorsPolicy" )]
    [ApiController]
    [ApiExplorerSettings( GroupName = "statements" )]
    public class StatementController : Controller
    {
        #region fields
        private readonly IConfiguration configuration;
        private readonly IMemoryCache cache;
        private readonly ILogger<StatementController> logger;
        #endregion fields

        #region Contructor
        /// <summary>
        ///     Default constructor that uses deendancy injection
        ///     to get the configuraion
        /// </summary>
        /// <param name="config">
        ///     Constructed application configuation
        /// </param>
        public StatementController( IConfiguration configuration, IMemoryCache cache, ILogger<StatementController> logger )
        {
            this.configuration = configuration;
            this.cache = cache;
            this.logger = logger;
        }
        #endregion Constructor

        #region private cache methods
        /// <summary>
        ///     Gets the CSH associated GUID based on the 
        ///     eStatement Provider identifier
        /// </summary>
        /// <param name="eStatementId">
        ///     Internal identifier for eStatement Provider
        /// </param>
        /// <returns>
        ///     CSH Provider identifier based on the the eStatement Provider identifier
        /// </returns>
        public Guid getProviderGuidByEstatementId( int eStatementId )
        {
            if ( !cache.TryGetValue<EStatementProvider>( $"CSHProviderId-{eStatementId})", out EStatementProvider provider ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var provider2 = context.Provider.Where( p => p.EStatementProviderId == eStatementId );
                    if ( provider2 != null && provider2.Count() > 0 )
                    {
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromMinutes( 5 ) );

                        cache.Set<EStatementProvider>( $"CSHProviderId-{eStatementId})", provider2.First() );//, cacheEntryOptions );

                        return provider2.First().ProviderId;
                    }
                    else
                    {
                        throw new ApplicationException( $"The provider identifier {eStatementId} was not found." );
                    }
                }
            }

            return provider.ProviderId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerId">
        /// </param>
        /// <returns>
        /// </returns>
        private int getEstatementProviderIdByProviderGuid( Guid providerId )
        {
            if ( !cache.TryGetValue<int>( $"ESProviderId-{providerId}", out int eStatementProviderId ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var provider = context.Provider.Where( p => p.ProviderId == providerId );
                    if ( provider != null && provider.Count() > 0 )
                    {
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromHours( 5 ) );

                        cache.Set<int>( $"ESProviderId-{providerId}", provider.First().EStatementProviderId, cacheEntryOptions );

                        return provider.First().EStatementProviderId;
                    }
                    else
                    {
                        throw new ApplicationException( $"The provider identifier {providerId} was not found." );
                    }
                }
            }

            return eStatementProviderId;
        }

        /// <summary>
        ///     Gets the CSH associated provider based on the 
        ///     eStatement Provider identifier
        /// </summary>
        /// <param name="eStatementId">
        ///     Internal identifier for eStatement Provider
        /// </param>
        /// <returns>
        ///     CSH Provider information based on the the eStatement Provider identifier
        /// </returns>
        private EStatementProvider getProviderByEstatementId( int eStatementId )
        {
            if ( !cache.TryGetValue<EStatementProvider>( $"ESProvider-{eStatementId}", out EStatementProvider provider ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var provider2 = context.Provider.Where( p => p.EStatementProviderId == eStatementId );
                    if ( provider2 != null && provider2.Count() > 0 )
                    {
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromHours( 5 ) );

                        cache.Set<EStatementProvider>( $"ESProvider-{eStatementId}", provider2.First(), cacheEntryOptions );

                        return provider2.First();
                    }
                    else
                    {
                        throw new ApplicationException( $"The provider identifier {eStatementId} was not found." );
                    }
                }
            }

            return provider;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="extractId"></param>
        /// <returns></returns>
        private StatementExtract getStatementExtract( int extractId )
        {
            if ( !cache.TryGetValue<StatementExtract>( $"SE-{extractId}", out StatementExtract statementExtract ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var extract = context.StatementExtract.Where( e => e.EStatementExtractId == extractId );
                    if ( extract != null && extract.Count() > 0 )
                    {
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromHours( 5 ) );

                        cache.Set<StatementExtract>( $"SE-{extractId}", extract.First(), cacheEntryOptions );

                        return extract.First();
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            return statementExtract;
        }

        /// <summary>
        ///     Gets the Provider Settings for the given 
        ///     internal provider identifier
        /// </summary>
        /// <param name="providerId">
        ///     Internal provider idnetifier
        /// </param>
        /// <returns><
        ///     ProviderSEttings object if found
        /// /returns>
        private ProviderSettings getProviderSettings( Guid providerId )
        {
            if ( !cache.TryGetValue<ProviderSettings>( $"PS-{providerId}", out ProviderSettings providerSettings ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var providerSettingsCache = context.ProviderSettings.Where( x => x.ProviderId == providerId );
                    if ( providerSettingsCache != null && providerSettingsCache.Count() > 0 )
                    {
                        ProviderSettings psCache = providerSettingsCache.First();
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromHours( 5 ) );

                        cache.Set<ProviderSettings>( $"SE-PS-{providerId}", psCache, cacheEntryOptions );

                        return psCache;
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            return providerSettings;
        }

        /// <summary>
        ///     Gets all the provider plans and sets the cache for 1 hour
        /// </summary>
        /// <param name="providerGuid">
        ///     Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of Provider Plans for the specified provider
        /// </returns>
        private List<ProviderPlan> getProviderPlans( Guid providerGuid )
        {
            if ( !cache.TryGetValue<List<ProviderPlan>>( $"PLANS-{providerGuid}", out List<ProviderPlan> providerPlans ) )
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var plans = context.ProviderPlan.Where( l => l.ProviderId == providerGuid );
                    if ( plans != null && plans.Count() > 0 )
                    {
                        List<ProviderPlan> plansCache = plans.ToList();
                        // Set cache options.
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                            // Keep in cache for this time, reset time if accessed.
                            .SetSlidingExpiration( TimeSpan.FromHours( 1 ) );

                        cache.Set<List<ProviderPlan>>( $"PLANS-{providerGuid}", plansCache, cacheEntryOptions );

                        return plansCache;
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            return providerPlans;

        }
        #endregion private cache methods

        #region private methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerSettings"></param>
        /// <returns></returns>
        private DateTime getProvider1stQuarter( ProviderSettings providerSettings )
        {

            if ( providerSettings != null && providerSettings.eStatementQuarters > 0 )
            {
                var quarters = YearQuarter.FromDate( DateTime.Now );
                var allQuarters = quarters.GetPreviousQuarters( providerSettings.eStatementQuarters );
                return allQuarters[0].BegOfQuarter;
            }
            else
            {
                logger.LogError( $"Method getProvider1stQuarter:  The ProviderSettings for Provider {providerSettings.ProviderAbbrev} where not found" );
                throw new ApplicationException( $"The ProviderSettings for the number of statement quarters to present for Provider {providerSettings.ProviderAbbrev} where not found" );   
            }
        }
        #endregion private methods

        #region public methods
        [HttpGet( "uptime" )]
        [AllowAnonymous]
        public IActionResult UpTime()
        {
            return new OkObjectResult( DateTime.Now.ToString() );
        }

        #region eStatement Provider Settings
        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpGet( "eStatements/{providerId}/enotification/settings" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> GetProviderENotificationSettings( [FromRoute] int providerId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.ProviderENotifySettings.Where( p => p.ProviderId == cshProviderId );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        ProviderENotifySettings settings = notifySettings.First();

                        return new OkObjectResult( settings );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status202Accepted )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PutProviderENotificationSettings( [FromRoute] int providerId, [FromBody] ProviderENotifySettings settings )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.ProviderENotifySettings.Where( p => p.ProviderId == cshProviderId );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        ProviderENotifySettings newSettings = notifySettings.First();

                        newSettings.ProviderId = settings.ProviderId;
                        newSettings.Fromaddr = settings.Fromaddr;
                        newSettings.Fromname = settings.Fromname;
                        newSettings.EMailSubject = settings.EMailSubject;
                        newSettings.EmailBody = settings.EmailBody;
                        newSettings.Replyaddr = settings.Replyaddr;
                        newSettings.Replyname = settings.Replyname;
                        newSettings.EmailBatchSize = settings.EmailBatchSize;
                        newSettings.HoursBetweenBatch = settings.HoursBetweenBatch;
                        newSettings.AreEmailSentOnWeekendHoliday = settings.AreEmailSentOnWeekendHoliday;
                        newSettings.IsSundaySkipped = settings.IsSundaySkipped;
                        newSettings.IsMondaySkipped = settings.IsMondaySkipped;
                        newSettings.IsTuesdaySkipped = settings.IsTuesdaySkipped;
                        newSettings.IsWednesDaySkipped = settings.IsWednesDaySkipped;
                        newSettings.IsThursdaySkipped = settings.IsThursdaySkipped;
                        newSettings.IsFridaySkipped = settings.IsFridaySkipped;
                        newSettings.IsSaturdaySkipped = settings.IsSaturdaySkipped;

                        context.SaveChanges();
                        return new OkObjectResult( newSettings );

                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"Failure for provider {providerId} in method PostProviderENotificationSettings", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPost( "eStatements/{providerId}/enotification/settings" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PostProviderENotificationSettings( [FromRoute] int providerId, [FromBody] ProviderENotifySettings settings )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.ProviderENotifySettings.Where( p => p.ProviderId == cshProviderId );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                    }
                    else
                    {
                        ProviderENotifySettings newSettings = new ProviderENotifySettings
                        {
                            ProviderId = cshProviderId,
                            Fromaddr = settings.Fromaddr,
                            Fromname = settings.Fromname,
                            EMailSubject = settings.EMailSubject,
                            EmailBody = settings.EmailBody,
                            Replyaddr = settings.Replyaddr,
                            Replyname = settings.Replyname,
                            EmailBatchSize = settings.EmailBatchSize,
                            HoursBetweenBatch = settings.HoursBetweenBatch,
                            AreEmailSentOnWeekendHoliday = settings.AreEmailSentOnWeekendHoliday,
                            IsSundaySkipped = settings.IsSundaySkipped,
                            IsMondaySkipped = settings.IsMondaySkipped,
                            IsTuesdaySkipped = settings.IsTuesdaySkipped,
                            IsWednesDaySkipped = settings.IsWednesDaySkipped,
                            IsThursdaySkipped = settings.IsThursdaySkipped,
                            IsFridaySkipped = settings.IsFridaySkipped,
                            IsSaturdaySkipped = settings.IsSaturdaySkipped
                        };

                        context.Add( newSettings );
                        context.SaveChanges();

                        return Created( $"eStatements/{providerId}/enotification/settings", newSettings );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"Failure for provider {providerId} in method PostProviderENotificationSettings", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Post provider email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings/emailbody" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PutProviderENotificationEmailBody( [FromRoute] int providerId, [FromBody] string emailBody )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.ProviderENotifySettings.Where( p => p.ProviderId == cshProviderId );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        ProviderENotifySettings settings = notifySettings.First();
                        settings.EmailBody = emailBody;
                        context.SaveChanges();

                        return new OkObjectResult( settings );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }


        /// <summary>
        ///     Get plan email bodu content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId">
        /// </param>
        /// <returns>
        ///     Content of the plans email content
        /// </returns>
        [HttpGet( "eStatements/{providerId}/enotification/settings/{externalPlanId}" )]
        [ProducesResponseType( typeof( IEnumerable<ProviderENotifySettings>), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> GetAllPlanENotificationOverrideSetting( [FromRoute] int providerId, [FromRoute] string externalPlanId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.PlanEnotifyOverrideSettings.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == externalPlanId );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        return new OkObjectResult( notifySettings );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Get plan email bodu content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId">
        /// </param>
        /// <returns>
        ///     Content of the plans email content
        /// </returns>
        [HttpGet( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( ProviderENotifySettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> GetPlanENotificationOverrideSetting( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.PlanEnotifyOverrideSettings.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == externalPlanId && ((PlanEnotifyOverrideType)p.PlanEnotifyOverrideTypeCD) == settingtype );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        PlanEnotifyOverrideSettings settings = notifySettings.First();

                        return new OkObjectResult( settings.Content );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Get plan email bodu content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId">
        /// </param>
        /// <returns>
        ///     Content of the plans email content
        /// </returns>
        [HttpDelete( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( PlanEnotifyOverrideSettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> DeletePlanENotificationOverrideSetting( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.PlanEnotifyOverrideSettings.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == externalPlanId && ((PlanEnotifyOverrideType)p.PlanEnotifyOverrideTypeCD) == settingtype );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        PlanEnotifyOverrideSettings settings = notifySettings.First();

                        context.PlanEnotifyOverrideSettings.Remove( settings );
                        context.SaveChanges();
                        return new OkResult();
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostMessage Failure for provider {providerId} in method GetProviderNotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Ets plan email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId"
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPut( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( PlanEnotifyOverrideSettings ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PutPlanENotificationOverrideSetting( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype, [FromBody] string content )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.PlanEnotifyOverrideSettings.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == externalPlanId && ((PlanEnotifyOverrideType)p.PlanEnotifyOverrideTypeCD) == settingtype );

                    if ( notifySettings != null && notifySettings.Count() > 0 )
                    {
                        PlanEnotifyOverrideSettings settings = notifySettings.First();
                        settings.Content = content;
                        context.SaveChanges();

                        return new OkObjectResult( settings );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"Pust Message Failure for provider {providerId} and plan {externalPlanId} for type {settingtype.ToString()} in method PutPlanENotificationEmailBody", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Ets plan email content used for eNotification for statements
        /// </summary>
        /// <param name="providerId">
        ///     eStatement provider identifier 
        /// </param>
        /// <param name="externalPlanId"
        /// </param>
        /// <param name="emailBody">
        ///     Email body for eNotifications
        /// </param>
        /// <returns>
        ///     Status of the REST call
        /// </returns>
        [HttpPost( "eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}" )]
        [ProducesResponseType( typeof( PlanEnotifyOverrideSettings ), StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status409Conflict )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [Authorize]
        public async Task<IActionResult> PostPlanENotificationOverrideSetting( [FromRoute] int providerId, [FromRoute] string externalPlanId, [FromRoute] PlanEnotifyOverrideType settingtype, [FromBody] string content )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var notifySettings = context.PlanEnotifyOverrideSettings.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == externalPlanId && ((PlanEnotifyOverrideType)p.PlanEnotifyOverrideTypeCD) == settingtype );

                    PlanEnotifyOverrideSettings settings = new PlanEnotifyOverrideSettings();
                    settings.ProviderId = cshProviderId;
                    settings.ExternalPlanId = externalPlanId;
                    settings.Content = content;
                    settings.PlanEnotifyOverrideTypeCD = (byte)settingtype;

                    if ( notifySettings != null && notifySettings.Count() == 0 )
                    {
                        context.Add( settings );
                        context.SaveChanges();

                        return new CreatedResult( $"/eStatements/{providerId}/enotification/settings/{externalPlanId}/{settingtype}", settings );
                    }
                    else
                    {
                        return new ConflictObjectResult( settings );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex, $"PostPlanENotificationEmailBody Failure for provider {providerId} and plan {externalPlanId} with error {ex.Message} - stacktrace {ex.StackTrace}", null );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion eStatement Provider Settings

        #region Logos
        /// <summary>
        ///     Gets provider level logos
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     Gets logoid assigned to the provider 
        /// </returns>
        [HttpGet("logos/{providerId}/plevel")]
        [Authorize]
        [ProducesResponseType(typeof(IEnumerable<ProviderLogo>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetProviderLevelLogos(int providerId)
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId(providerId);

                using (StatementsDBContext context = new StatementsDBContext(configuration))
                {
                    var logo = context.ProviderLevelLogos.Where(p => p.ProviderId == cshProviderId);

                    if (logo != null && logo.Count() > 0)
                    {
                        return new OkObjectResult(logo.First());
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Deletes provider level logo 
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Identifier for the logo
        /// </param>
        /// <returns>
        ///     Status of the method,  200, 404 or 400
        /// </returns>
        [HttpDelete("logos/{providerId}/plevel")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteLogo(int providerId)
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId(providerId);

                using (StatementsDBContext context = new StatementsDBContext(configuration))
                {

                    ProviderLevelLogo providerLogo = context.ProviderLevelLogos.Where(l => l.ProviderId == cshProviderId).FirstOrDefault();

                    if (providerLogo != null && !String.IsNullOrWhiteSpace(providerLogo.LogoId))
                    {
                        using (var transaction = context.Database.BeginTransaction())
                        {
                            context.ProviderLevelLogos.Remove(providerLogo);
                            context.SaveChanges();
                            transaction.Commit();
                        }
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return new OkResult();
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Adds a new logo assigment to the given plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <param name="id">
        ///     Interanl identifier for the logo to be assined to the plan
        /// </param>
        /// <returns>
        ///     New Plan
        /// </returns>
        [HttpPost("logos/{providerId}/{id}/plevel")]
        [Authorize]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PostProviderLevelLogo(int providerId,string id)
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId(providerId);

                using (StatementsDBContext context = new StatementsDBContext(configuration))
                {
                    var planLogo = context.ProviderLevelLogos.Where(p => p.ProviderId == cshProviderId);

                    if (planLogo != null && planLogo.Count() > 0)
                    {
                        var logo = planLogo.First();
                        logo.LogoId = id;
                        context.SaveChanges();
                        return NoContent();
                    }
                    else
                    {
                        ProviderLevelLogo logo = new ProviderLevelLogo
                        {
                            ProviderId = cshProviderId,
                            LogoId = id
                        };

                        context.Add(logo);
                        context.SaveChanges();

                        return Created($"logos/{providerId}/plevel", logo);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Gets tall the logos that are assigned to a
        ///     given provider
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of all the logos a provider has including
        ///     the id and thumbnail of the logo
        /// </returns>
        [HttpGet( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ProviderLogo> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderLogos( int providerId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                List<ProviderLogo> logos = new List<ProviderLogo>();

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    logos = context.ProviderLogos.Where( p => p.ProviderId == cshProviderId )
                        .Select( pm => new ProviderLogo()
                        {
                            ProviderId = cshProviderId,
                            LogoId = pm.LogoId,
                            Thumbnail = pm.Thumbnail

                        } ).OrderBy( o => o.LogoId ).ToList<ProviderLogo>();
                }
                return new OkObjectResult( logos );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a specific provider logo
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Identifier for the logo
        /// </param>
        /// <returns>
        ///     The Provider logo along with the thumbnail of the logo
        /// </returns>
        [HttpGet( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( ProviderLogo ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetLogo( int providerId, [RequiredFromQuery] string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var logo = context.ProviderLogos.Where( p => p.ProviderId == cshProviderId && p.LogoId == id );

                    if ( logo != null && logo.Count() > 0 )
                    {
                        return new OkObjectResult( logo.First() );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a logo assigned to a provider along with all
        ///     the Plans that have the logo assinged
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Identifier for the logo
        /// </param>
        /// <returns>
        ///     Status of the method,  200, 404 or 400
        /// </returns>
        [HttpDelete( "logos/{providerId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeleteLogo( int providerId, [RequiredFromQuery] string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    ProviderLogo providerLogo = context.ProviderLogos.Where( l => l.ProviderId == cshProviderId && l.LogoId == id ).FirstOrDefault();

                    if ( providerLogo != null && !String.IsNullOrWhiteSpace( providerLogo.LogoId ) )
                    {
                        using ( var transaction = context.Database.BeginTransaction() )
                        {
                            IEnumerable<PlanLogo> planLogos = context.PlanLogo.Where( l => l.ProviderId == cshProviderId && l.LogoId == id );

                            if ( planLogos.Count() > 0 )
                            {
                                context.PlanLogo.RemoveRange( planLogos );
                                context.SaveChanges();
                            }

                            context.ProviderLogos.Remove( providerLogo );
                            context.SaveChanges();
                            transaction.Commit();
                        }
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return new OkResult();
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a mew logo assignments to multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the logo
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     New message has been created to all plans
        /// </returns>
        [HttpPost( "logos/{providerId}/plans" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostLogoAssignmentForPlans( int providerId, [RequiredFromQuery] string id, [FromBody] List<string> planExternalIds )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    // Get all current assigments that need to be updated
                    List<PlanLogo> currentAssignments = context.PlanLogo.Where(
                         x => x.ProviderId == cshProviderId && planExternalIds.Contains( x.ExternalPlanId ) ).ToList();

                    // Get all new assigments that need to be added
                    List<string> currnetExternalIds = currentAssignments.Select( p => p.ExternalPlanId ).ToList();

                    List<string> newAssignments = planExternalIds.Where( x => !currnetExternalIds.Contains( x ) ).ToList();

                    using ( var transaction = context.Database.BeginTransaction() )
                    {
                        try
                        {
                            // Update the exting message assigments
                            foreach ( PlanLogo cLogo in currentAssignments )
                            {
                                cLogo.LogoId = id;
                            }

                            // Add new message assignments
                            foreach ( string nLogo in newAssignments )
                            {
                                PlanLogo logo = new PlanLogo
                                {
                                    ProviderId = cshProviderId,
                                    ExternalPlanId = nLogo,
                                    LogoId = id
                                };

                                context.Add( logo );
                            }

                            context.SaveChanges();

                            transaction.Commit();

                            return Ok();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a logo assignment from multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the logo to be removed from plans
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     Logo has been removed from all plans
        /// </returns>
        [HttpPost( "logos/{providerId}/{id}/plans/delete" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostLogoRemoveAssignmentForPlans( int providerId, string id, [FromBody] List<string> planExternalIds )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    using ( var transaction = context.Database.BeginTransaction() )
                    {
                        try
                        {
                            // Delete any Plan Logo Association
                            IEnumerable<PlanLogo> planLogos = context.PlanLogo.Where( p => p.ProviderId == cshProviderId && planExternalIds.Contains( p.ExternalPlanId ) && p.LogoId == id );

                            if ( planLogos.Count() > 0 )
                            {
                                context.PlanLogo.RemoveRange( planLogos );
                                context.SaveChanges();
                            }
                            transaction.Commit();

                            return Ok();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets the logo assigned to a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <returns>
        ///     Plan Logo information if found
        /// </returns>
        [HttpGet( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( typeof( PlanLogo ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlanLogo( int providerId, string planId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var logo = context.PlanLogo.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId );

                    if ( logo != null && logo.Count() > 0 )
                    {
                        return new OkObjectResult( logo.First() );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates the plan logo assignment for the 
        ///     supplied plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <param name="id">
        ///     Internal idetifier for the logo being assined to th the
        ///     plan
        /// </param>
        /// <returns>
        ///     Plan Logo information if successful
        /// </returns>
        [HttpPut( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( typeof( PlanLogo ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutPlanLogo( int providerId, string planId, [RequiredFromQuery] string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planLogo = context.PlanLogo.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId );

                    if ( planLogo != null && planLogo.Count() > 0 )
                    {
                        var logo = planLogo.First();

                        logo.LogoId = id;
                        context.SaveChanges();

                        return new OkObjectResult( logo );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a logo assignment to the provided plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <returns>
        ///     OK if the logo assignment has been removed 
        /// </returns>
        [HttpDelete( "logos/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeletePlanLogo( int providerId, string planId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    context.PlanLogo.Remove( context.PlanLogo.Find( new object[] { cshProviderId, planId } ) );
                    context.SaveChanges();
                }
                return new OkResult();
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a new logo assigment to the given plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///      Exteral Plan identifier for th eproviders plan
        /// </param>
        /// <param name="id">
        ///     Interanl identifier for the logo to be assined to the plan
        /// </param>
        /// <returns>
        ///     New Plan
        /// </returns>
        [HttpPost( "logos/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostPlanLogo( int providerId, string planId, [RequiredFromQuery] string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planLogo = context.PlanLogo.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId );

                    if ( planLogo != null && planLogo.Count() > 0 )
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                    }
                    else
                    {
                        PlanLogo logo = new PlanLogo
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanId = planId,
                            LogoId = id
                        };

                        context.Add( logo );
                        context.SaveChanges();

                        return Created( $"msgs/{providerId}/{planId}", logo );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion Logos

        #region Plans
        /// <summary>
        ///     Gets all the plans associed to the fiven provider identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider
        /// </returns>
        [HttpGet( "plans/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<StatementPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlans( int providerId )
        {
            try
            {
                List<StatementPlan> plans = new List<StatementPlan>();
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    plans = context.ProviderPlans.Where( p => p.ProviderId == cshProviderId )
                        .Select( pl => new StatementPlan()
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanId = pl.ExternalPlanId,
                            PlanName1 = pl.PlanName1,
                            PlanName2 = pl.PlanName2,
                            LogoId = pl.LogoId,
                            Message1Id = pl.Message1Id,
                            Message2Id = pl.Message2Id,
                            Message3Id = pl.Message3Id,
                            Message4Id = pl.Message4Id,
                            Message5Id = pl.Message5Id
                        } ).OrderBy( o => o.ExternalPlanId ).ToList<StatementPlan>();
                }
                return new OkObjectResult( plans );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the plans associated to the given provider identifier and message identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <param name="messageId">
        ///     Message identifier assinged by client
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider and message
        /// </returns>
        [HttpGet( "plans/{providerId}/msg/{messageId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<StatementPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessagePlans( int providerId, string messageId )
        {
            try
            {
                List<ProviderPlan> plans = new List<ProviderPlan>();
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    plans = context.PlanMessages.Where( p => p.MessageId == messageId ).Join(
                            context.ProviderPlans,
                            pm => pm.ExternalPlanID,
                            pp => pp.ExternalPlanId,
                            ( pm, pp ) => new ProviderPlan()
                            {
                                ProviderId = pp.ProviderId,
                                ExternalPlanId = pp.ExternalPlanId,
                                PlanName1 = pp.PlanName1,
                                PlanName2 = pp.PlanName2
                            } )
                            .Where( p => p.ProviderId == cshProviderId )
                            .OrderBy( o => o.ExternalPlanId ).Distinct().ToList<ProviderPlan>();
                }
                return new OkObjectResult( plans );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the plans associated to the given provider identifier and logo identifier
        /// </summary>
        /// <param name="providerId">
        ///     eStatements Provider identifier
        /// </param>
        /// <param name="logoId">
        ///     Logo identifier assinged by client
        /// </param>
        /// <returns>
        ///     Collection of Plans associated to the provider and logo
        /// </returns>
        [HttpGet( "plans/{providerId}/logo/{logoId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<StatementPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetLogoPlans( int providerId, string logoId )
        {
            try
            {
                List<ProviderPlan> plans = new List<ProviderPlan>();
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    plans = context.PlanLogo.Where( p => p.LogoId == logoId ).Join(
                            context.ProviderPlans,
                            pl => pl.ExternalPlanId,
                            pp => pp.ExternalPlanId,
                            ( pl, pp ) => new ProviderPlan()
                            {
                                ProviderId = cshProviderId,
                                ExternalPlanId = pp.ExternalPlanId,
                                PlanName1 = pp.PlanName1,
                                PlanName2 = pp.PlanName2
                            } )
                            .Where( p => p.ProviderId == cshProviderId )
                            .OrderBy( o => o.ExternalPlanId ).Distinct().ToList<ProviderPlan>();
                }
                return new OkObjectResult( plans );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets plan information for the given plan
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     Plan information for the given provider and plan identifiers
        /// </returns>
        [HttpGet( "plans/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IQueryable<StatementPlan> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlan( int providerId, string planId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planQ = context.ProviderPlan.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId )
                        .Select( pl => new StatementPlan()
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanId = pl.ExternalPlanId,
                            PlanName1 = pl.PlanName1,
                            PlanName2 = pl.PlanName2
                        } ).FirstOrDefault();

                    if ( planQ == null )
                    {
                        return NotFound();
                    }
                    else
                    {
                        return new OkObjectResult( planQ );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a plan from the Providers plan universe
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     Ok if the plan has been deleted and found
        /// </returns>
        [HttpDelete( "plans/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( typeof( StatementPlan ), StatusCodes.Status200OK )]
        [ProducesResponseType( typeof( StatementPlan ), StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeletePlan( int providerId, string planId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    ProviderPlan providerPlan = context.ProviderPlan.Where( l => l.ProviderId == cshProviderId && l.ExternalPlanId == planId ).FirstOrDefault();

                    if ( providerPlan != null && !String.IsNullOrWhiteSpace( providerPlan.ExternalPlanId ) )
                    {
                        using ( var transaction = context.Database.BeginTransaction() )
                        {
                            IEnumerable<ProviderPlan> providerPlans = context.ProviderPlan.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId );

                            if ( providerPlans.Count() > 0 )
                            {
                                // Delete any Plan Message Association
                                IEnumerable<PlanMessage> planMessages = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanID == planId );

                                if ( planMessages.Count() > 0 )
                                {
                                    context.PlanMessages.RemoveRange( planMessages );
                                    context.SaveChanges();
                                }

                                // Delete any Plan Logo Association
                                IEnumerable<PlanLogo> planLogos = context.PlanLogo.Where( l => l.ProviderId == cshProviderId && l.ExternalPlanId == planId );

                                if ( planLogos.Count() > 0 )
                                {
                                    context.PlanLogo.RemoveRange( planLogos );
                                    context.SaveChanges();
                                }

                                context.ProviderPlan.Remove( providerPlan );
                                context.SaveChanges();

                                transaction.Commit();
                            }
                        }
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return new OkResult();
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updated plan informatino for the given plan
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <param name="name1">
        ///     First name given to the plan
        /// </param>
        /// <param name="name2">
        ///     Second Name given to the plan
        /// </param>
        /// <returns>
        ///     Newly updated plna if the plan was found
        /// </returns>
        [HttpPut( "plans/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( typeof( ProviderPlan ), StatusCodes.Status200OK )]
        [ProducesResponseType( typeof( ProviderPlan ), StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PutPlan( int providerId, string planId, [RequiredFromQuery] string name1, [RequiredFromQuery] string name2 )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var plan = context.ProviderPlan.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId );

                    if ( plan != null && plan.Count() > 0 )
                    {
                        var updatePlan = plan.First();

                        updatePlan.PlanName1 = name1;
                        updatePlan.PlanName2 = name2;

                        context.SaveChanges();

                        return new OkObjectResult( updatePlan );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Creates a new plan in the Providers Univers
        /// </summary>
        /// <param name="providerId">
        ///     eStatements provider identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <param name="name1">
        ///     First name given to the plan
        /// </param>
        /// <param name="name2">
        ///     Second Name given to the plan
        /// </param>
        /// <returns>
        ///     Newly created Plan if the plan information if not found
        /// </returns>
        [HttpPost( "plans/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( ProviderPlan ), StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostPlan( int providerId, [RequiredFromQuery] string planId, [RequiredFromQuery] string name1, [RequiredFromQuery] string name2 )
        {
            Guid cshProviderId = getProviderGuidByEstatementId( providerId );

            // If exits throw 409
            try
            {
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    ProviderPlan plan = context.ProviderPlan.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanId == planId ).FirstOrDefault();

                    if ( plan != null && !String.IsNullOrWhiteSpace( plan.ExternalPlanId ) )
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                    }
                    else
                    {
                        ProviderPlan newPlan = new ProviderPlan
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanId = planId,
                            PlanName1 = name1,
                            PlanName2 = name2
                        };

                        context.Add( newPlan );
                        context.SaveChanges();

                        return Created( $"plans/{providerId}/{planId}", newPlan );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion Plans

        #region Messages
        /// <summary>
        ///     Gets all the messagea assinged to a given internal provider
        ///     identifier
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <returns>
        ///     List of all the messasges assingned to a provider
        /// </returns>
        [HttpGet( "msgs/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<ProviderMessage> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessages( int providerId )
        {
            List<ProviderMessage> messages = new List<ProviderMessage>();

            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    messages = context.ProviderMessages.Where( p => p.ProviderId == cshProviderId )
                        .Select( pm => new ProviderMessage()
                        {
                            ProviderId = cshProviderId,
                            MessageName = pm.MessageName,
                            MessageId = pm.MessageId,
                            OriginalMessage = pm.OriginalMessage
                        } ).OrderBy( o => o.MessageId ).ToList<ProviderMessage>();
                }
                return new OkObjectResult( messages );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a provider message by its specified identifier
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Message identifier assinged by client
        /// '</param>
        /// <returns>
        ///     Message in rtf format and the message identifier
        /// </returns>
        [HttpGet( "msgs/{providerId}" )]
        [Authorize]
        [ProducesResponseType( typeof( ProviderMessage ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetMessage( int providerId, [RequiredFromQuery] string id )
        {
            ProviderMessage message = new ProviderMessage();

            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    message = context.ProviderMessages.Where( p => p.ProviderId == cshProviderId && p.MessageId == id )
                        .Select( pm => new ProviderMessage()
                        {
                            ProviderId = cshProviderId,
                            MessageName = pm.MessageName,
                            MessageId = pm.MessageId,
                            OriginalMessage = pm.OriginalMessage
                        } ).FirstOrDefault();
                }

                if ( message != null && message.ProviderId != Guid.Empty )
                {
                    return new OkObjectResult( message );
                }
                else
                {
                    return NotFound();
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes a Provider message allong with all the 
        ///     plan message assignments for this message
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     Message identifier
        /// </param>
        /// <returns>
        ///     Status of the removal, 200, 404, 400
        /// </returns>
        [HttpDelete( "msgs/{providerId}/{id}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> DeleteMessage( int providerId, string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    ProviderMessage providerMessage = context.ProviderMessages.Where( l => l.ProviderId == cshProviderId && l.MessageId == id ).FirstOrDefault();

                    if ( providerMessage != null && !String.IsNullOrWhiteSpace( providerMessage.MessageId ) )
                    {
                        using ( var transaction = context.Database.BeginTransaction() )
                        {
                            IEnumerable<PlanMessage> planMessages = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.MessageId == id );

                            if ( planMessages.Count() > 0 )
                            {
                                context.PlanMessages.RemoveRange( planMessages );
                                context.SaveChanges();
                            }

                            context.ProviderMessages.Remove( providerMessage );
                            context.SaveChanges();

                            transaction.Commit();
                        }
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return new OkResult();
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the message assiments for a statement
        ///     for a particular plan.
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External plan identifier
        /// </param>
        /// <returns>
        ///     All the message assigments for a particular plan
        /// </returns>
        [HttpGet( "msgs/{providerId}/plans/{planid}" )]
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<PlanMessage> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlanMessages( int providerId, string planId )
        {
            try
            {
                var accessToken = await HttpContext.GetTokenAsync( "access_token" );

                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                List<PlanMessage> planMessages = new List<PlanMessage>();
                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    planMessages = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanID == planId )
                        .Select( s => new PlanMessage()
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanID = s.ExternalPlanID,
                            MessageId = s.MessageId,
                            MessageLocation = s.MessageLocation
                        } ).OrderBy( o => o.MessageLocation ).ToList<PlanMessage>();
                }

                return new OkObjectResult( planMessages );
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets the Plan Message assignment or a specified
        ///     location on a statement
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan Identifier
        /// </param>
        /// <returns>
        ///     The message assingements for the plan and location
        /// </returns>
        [HttpGet( "msgs/{providerId}/{planid}/{location}" )]
        [Authorize]
        [ProducesResponseType( typeof( PlanMessage ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> GetPlanMessageByLocation( int providerId, string planId, int location )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planMessage = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanID == planId && p.MessageLocation == location );

                    if ( planMessage != null && planMessage.Count() > 0 )
                    {
                        return new OkObjectResult( planMessage.First() );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Updates the message assignment for a plan and specific location within
        ///     a statement.
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External plan identifier
        /// </param>
        /// <param name="location">
        ///     Lcation of the message within a statement
        /// </param>
        /// <param name="msgid">
        ///     External message identifier
        /// </param>
        /// <returns>
        ///     Staetus of changing the message for a specific location
        /// </returns>
        [HttpPut( "msgs/{providerId}/{planId}/{location}" )]
        [Authorize]
        [ProducesResponseType( typeof( PlanMessage ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> PutPlanMessage( int providerId, string planId, int location, [RequiredFromQuery] string id )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planMessage = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanID == planId && p.MessageLocation == location );

                    if ( planMessage != null && planMessage.Count() > 0 )
                    {
                        PlanMessage msg = planMessage.First();
                        msg.MessageId = id;
                        context.SaveChanges();

                        return new OkObjectResult( msg );
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Deletes the message assigment as a specified location
        ///     for a plan
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     External Plan identifier for which the message is assigned
        /// </param>
        /// <param name="location">
        ///     Location of the message within a statements
        /// </param>
        /// <returns>
        ///     Status of the delete
        /// </returns>
        [HttpDelete( "msgs/{providerId}/{planId}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> DeletePlanMessage( int providerId, string planId, [RequiredFromQuery] int location )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    PlanMessage planMessage = context.PlanMessages.Where( l => l.ProviderId == cshProviderId && l.ExternalPlanID == planId && l.MessageLocation == location ).FirstOrDefault();

                    if ( planMessage != null && !String.IsNullOrWhiteSpace( planMessage.ExternalPlanID ) )
                    {
                        context.PlanMessages.Remove( planMessage );
                        context.SaveChanges();
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                return new OkResult();
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a new plan message assignment
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="planId">
        ///     Externl Plan identifier to associate the message
        ///     to
        /// </param>
        /// <param name="location">
        ///     Location where the messasge iwll be places
        /// </param>
        /// <param name="msgid">
        ///     External identifeir for the message to be assigned to the locaiton
        /// </param>
        /// <returns>
        ///     Status for adding a new plan message assignment
        /// </returns>
        [HttpPost( "msgs/{providerId}/{planid}" )]
        [Authorize]
        [ProducesResponseType( typeof( PlanMessage ), StatusCodes.Status201Created )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        public async Task<IActionResult> PostPlanMessageLogo( int providerId, string planId, [RequiredFromQuery] short location, [RequiredFromQuery] string id )
        {
            logger.LogInformation( "PostPlanMesageLogo" );
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var planMessage = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && p.ExternalPlanID == planId && p.MessageLocation == location );

                    if ( planMessage != null && planMessage.Count() > 0 )
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 409 ) ) );
                    }
                    else
                    {
                        PlanMessage msg = new PlanMessage
                        {
                            ProviderId = cshProviderId,
                            ExternalPlanID = planId,
                            MessageId = id,
                            MessageLocation = location
                        };

                        context.Add( msg );
                        context.SaveChanges();

                        return Created( $"msgs/{providerId}/{planId}", msg );
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Adds a mew messages assignments to multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="location">
        ///     Location number where to put the message
        /// </param>
        /// <param name="id">
        ///     External identifier for the message
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     New message has been created to all plans
        /// </returns>
        [HttpPost( "msgs/{providerId}/plans/{location}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostMessageAssignmentForPlans( int providerId, short location, [RequiredFromQuery] string id, [FromBody] List<string> planExternalIds )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    // Get all current assigments that need to be updated
                    List<PlanMessage> currentAssignments = context.PlanMessages.Where(
                         x => x.ProviderId == cshProviderId && planExternalIds.Contains( x.ExternalPlanID ) && x.MessageLocation == location ).ToList();

                    // Get all new assigments that need to be added
                    List<string> currnetExternalIds = currentAssignments.Select( p => p.ExternalPlanID ).ToList();

                    List<string> newAssignments = planExternalIds.Where( x => !currnetExternalIds.Contains( x ) ).ToList();

                    using ( var transaction = context.Database.BeginTransaction() )
                    {
                        try
                        {
                            // Update the exting message assigments
                            foreach ( PlanMessage cMsg in currentAssignments )
                            {
                                cMsg.MessageId = id;
                            }

                            // Add new message assignments
                            foreach ( string nMsg in newAssignments )
                            {
                                PlanMessage msg = new PlanMessage
                                {
                                    ProviderId = cshProviderId,
                                    ExternalPlanID = nMsg,
                                    MessageId = id,
                                    MessageLocation = location
                                };

                                context.Add( msg );
                            }

                            context.SaveChanges();

                            transaction.Commit();

                            return Ok();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Removes a message assignment from multiple plans
        /// </summary>
        /// <param name="providerId">
        ///     Statements Internal Provider Identifier
        /// </param>
        /// <param name="id">
        ///     External identifier for the message to be removed from plans
        /// </param>
        /// <param name="planExternalIds">
        ///     List of External Plan Identifiers in JSON format
        /// </param>
        /// <returns>
        ///     Message has been removed from all plans
        /// </returns>
        [HttpPost( "msgs/{providerId}/{id}/plans/delete" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> PostMessageRemoveAssignmentForPlans( int providerId, string id, [FromBody] List<string> planExternalIds )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {

                    using ( var transaction = context.Database.BeginTransaction() )
                    {
                        try
                        {
                            // Delete any Plan Message Association
                            IEnumerable<PlanMessage> planMessages = context.PlanMessages.Where( p => p.ProviderId == cshProviderId && planExternalIds.Contains( p.ExternalPlanID ) && p.MessageId == id );

                            if ( planMessages.Count() > 0 )
                            {
                                context.PlanMessages.RemoveRange( planMessages );
                                context.SaveChanges();
                            }
                            transaction.Commit();

                            return Ok();
                        }
                        catch
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion Messages        

        #region eStatements
        /// <summary>
        ///     Gets the date and time of the last proof was ran
        /// </summary>
        /// <param name="extractId">
        ///     Statement Production extract identifier
        /// </param>
        /// <returns>
        ///     Return the data and time of the last proof if one extists
        /// </returns>
        [HttpGet( "extract/{extractid}/proof/date" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetStatementProofFileDate( int extractId )
        {
            try
            {
                string fileDate = string.Empty;

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var proofDate = context.StatementExtractReport.Where( x => x.EStatementExtractID == extractId && x.StatementExtractReportTypeCD == 1 );

                    if ( proofDate != null && proofDate.Count() == 1 )
                    {

                        fileDate = proofDate.First().ReportDate.ToString( "MM-dd-yyyy HH:mm:ss" );
                    }
                }

                if ( String.IsNullOrEmpty( fileDate ) )
                {
                    return NotFound();
                }
                else
                {
                    return await Task.FromResult( new OkObjectResult( fileDate ) );
                }

            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets an extract report by type if it exits
        /// </summary>
        /// <param name="extractId">
        ///     Internal extract identifir that relates to a feed and provider
        /// </param>
        /// <param name="reportType">
        ///     Type of report to retieve
        /// </param>
        /// <returns>
        ///     Report file stream
        /// </returns>
        [HttpGet( "extract/{extractId}/reports/{reportType}" )]
        //[Authorize]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetStatementReport( int extractId, StatementReportFileType reportType )
        {
            try
            {
                FieldInfo fieldInfo = reportType.GetType().GetField( reportType.ToString() );

                object[] customAttributes = fieldInfo.GetCustomAttributes( typeof( StatementReportTypeAttribute ), false );

                if ( customAttributes.Length != 1 )
                {
                    throw new NotImplementedException( "The Statement Report Type Attribute does not exist for this report type." );
                }

                int statementReportType = ((StatementReportTypeAttribute)customAttributes[0]).CSHType;
                string mimeType = ((StatementReportTypeAttribute)customAttributes[0]).MimeType;

                using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                {
                    var report = context.ExtractReport.Where( x => x.EStatementExtractID == extractId && x.StatementExtractReportTypeCD == statementReportType );

                    if ( report != null && report.Count() == 1 )
                    {
                        var extractReport = report.First();

                        var readStream = extractReport.Report;

                        logger.LogInformation( $"Sending Report for extract {extractId} with reporttype of {statementReportType}" );

                        return File( readStream, mimeType, extractReport.ReportName );

                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a list of all reports that have been produced for this extract
        /// </summary>
        /// <param name="extractId">
        ///     Internal extract identifir that relates to a feed and provider
        /// </param>
        /// <returns>
        ///     List of avaliable report for the extract
        /// </returns>
        [HttpGet( "extract/{extractId}/reports" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetStatementExtractReports( int extractId )
        {
            try
            {
                // See if the files are cached first otherwise get the file info
                if ( !cache.TryGetValue<List<StatementReportFileType>>( $"EReports-{extractId}", out List<StatementReportFileType> statementExtractFiles ) )
                {
                    List<StatementReportFileType> avaliableReports = new List<StatementReportFileType>();

                    using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
                    {
                        var statementExtractReports = context.StatementExtractReport.Where( x => x.EStatementExtractID == extractId );

                        if ( statementExtractReports != null && statementExtractReports.Count() > 0 )
                        {
                            foreach ( var statementExtractReport in statementExtractReports )
                            {
                                logger.LogInformation( $"Report Type: {(int)statementExtractReport.StatementExtractReportTypeCD}" );
                                foreach ( StatementReportFileType statementReportFileType in Enum.GetValues( typeof( StatementReportFileType ) ) )
                                {
                                    FieldInfo fieldInfo = statementReportFileType.GetType().GetField( statementReportFileType.ToString() );

                                    object[] customAttributes = fieldInfo.GetCustomAttributes( typeof( StatementReportTypeAttribute ), false );

                                    if ( customAttributes.Length != 1 )
                                    {
                                        throw new NotImplementedException( "The Statement Report Type Attribute does not exist for this report type." );
                                    }
                                    logger.LogInformation( $"CSH Report Type: {((StatementReportTypeAttribute)customAttributes[0]).CSHType}" );
                                    if ( (int)statementExtractReport.StatementExtractReportTypeCD == ((StatementReportTypeAttribute)customAttributes[0]).CSHType )
                                    {
                                        avaliableReports.Add( statementReportFileType );
                                        logger.LogInformation( $"Adding report type for extract {extractId} with type: {(int)statementReportFileType}" );
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            return NotFound();
                        }
                    }

                    if ( avaliableReports.Count() > 0 )
                    {
                        var cacheEntryOptions = new MemoryCacheEntryOptions()
                          // Keep in cache for this time, reset time if accessed.
                          .SetSlidingExpiration( TimeSpan.FromHours( 5 ) );

                        cache.Set( $"EReports-{extractId}", avaliableReports, cacheEntryOptions );
                    }

                    return new OkObjectResult( avaliableReports );

                }

                return new OkObjectResult( statementExtractFiles );

            }
            catch ( Exception ex )
            {
                logger.LogError( ex.ToString() );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }


        /// <summary>
        ///     Gets all the eStatements for a provider
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <returns>
        ///     LIst of eStatements that can be retireved
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/" )] // Get all the statments for a provider
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderEStatements( int providerId )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                ProviderSettings providerSettings = getProviderSettings( cshProviderId );
                DateTime startingDateOfStatements = getProvider1stQuarter( providerSettings );

                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId &&
                                sp.statementDate.Date >= startingDateOfStatements.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetProviderEStatements: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetProviderEStatements : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the statements for a provider and a specified date
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retrieve
        /// </param>
        /// <returns>
        ///     Returns all the Provider eStatemetns for a statement date
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/{statementdate}" )] // Get all the statments for a provider for a particular date
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetProviderEStatementsByDate( int providerId, DateTime statementdate )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetProviderEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetProviderEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the statements for s specific participant
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <returns>
        ///     All the statements for a participant
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/pars/{uid}" )] // get all statements for a participant reguardless of plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsEStatements( int providerId, Guid uid )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                ProviderSettings providerSettings = getProviderSettings( cshProviderId );
                DateTime startingDateOfStatements = getProvider1stQuarter( providerSettings );

                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.uid == uid &&
                                sp.statementDate.Date >= startingDateOfStatements.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetParticipantsEStatements: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetParticipantsEStatements : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a PDF contained all the participants statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     PDF containing all the participants statements for a specified date
        /// </returns>
        [HttpPost( "estatements/{providerId}/statements/{planid}/statements/pars/{uid}/combined/isFtped" )] // Get Combined PDF of all statements for a Dete and participant
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsCombinedEStatementsByDates( int providerId, string planid, Guid uid, [FromBody]List<DateTime> statementdates, bool isFtped )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.uid == uid && statementdates.Select( x => x.Date ).Contains( sp.statementDate.Date )
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        string part_id = query.First().part_id.Trim();
                        string plannum = query.First().plan_num.Trim();
                        string provid = query.First().provid;
                        string  fname = query.First().firstname;
                        string lname = query.First().lastname;
                        string downloadName = $"{planid}_multipleperiods_{lname}{part_id.Substring( part_id.Length - 4, 4 )}.pdf";

                        downloadName = string.Join( string.Empty, downloadName.Split( Path.GetInvalidFileNameChars() ) );

                        PdfDocument outputDocument = new PdfDocument();

                        using ( eStatementDBContext pdfcontext = new eStatementDBContext( configuration ) )
                        {
                            foreach ( eStatementData parStatement in query )
                            {
                                var eStatementQuery = pdfcontext.eStatement.Where( x => x.ID == parStatement.statementId );

                                if ( eStatementQuery != null && eStatementQuery.Count() == 1 && eStatementQuery.First().eStatementPdf.Length > 0 )
                                {

                                    ParticipanteStatement statementPdf = eStatementQuery.First();

                                    MemoryStream ms = new MemoryStream( statementPdf.eStatementPdf );
                                    PdfDocument inDoc = PdfReader.Open( ms, PdfDocumentOpenMode.Import );
                                    for ( int idx = 0; idx < inDoc.PageCount; idx++ )
                                    {
                                        // Get the page from the external document...
                                        PdfPage page = inDoc.Pages[idx];
                                        // ...and add it to the output document.
                                        outputDocument.AddPage( page );
                                    }

                                    logger.LogInformation( $"Adding PDF document {statementPdf.ID} to Combined pdf for participants {uid}" );

                                }
                            }
                        }

                        tvp_ss_ident tvp_ss_ident = new tvp_ss_ident();
                        tvp_ss_ident.file_name = downloadName;
                        tvp_ss_ident.part_id = part_id;
                        tvp_ss_ident.position = 0;
                        tvp_ss_ident.pages = outputDocument.PageCount;
                        tvp_ss_ident.plan_num = plannum;
                        tvp_ss_ident.rpt_date = DateTime.Now;
                        tvp_ss_ident.isactive = 1;
                        tvp_ss_ident.spon_num = plannum;
                        tvp_ss_ident.provid = provid;
                        tvp_ss_ident.trans_no = "0";
                        tvp_ss_ident.fname = fname;
                        tvp_ss_ident.lname = lname;
                        tvp_ss_ident.uid = uid;
                        tvp_ss_ident.platform = 0;
                        tvp_ss_ident.batch = 0;
                        tvp_ss_ident.IsSmart = 0;
                        tvp_ss_ident.CommunicationTypeCD = "ADMIN";
                        if ( isFtped )
                        {
                            tvp_ss_ident.FileLocationTypeCD = "FTP";
                        }
                        else
                        {
                            tvp_ss_ident.FileLocationTypeCD = "UI Repository";
                        }
                        tvp_ss_ident.DateSubmitted = DateTime.Now.ToString();

                        saveCombinedPDFFilesData( new List<tvp_ss_ident>() { tvp_ss_ident } );
                        using ( MemoryStream rms = new MemoryStream() )
                        {
                            outputDocument.Save( rms, false );
                            byte[] combinedBytes = rms.ToArray();

                            saveCombinedPDFFile( part_id, plannum, tvp_ss_ident.rpt_date, combinedBytes );

                            var mimeType = "application/pdf";

                            logger.LogInformation( $"Sending combined eStatement for participant {uid} with statement date {statementdates}" );

                            if( isFtped )
                            {
                                //send file to client FTP server
                            }

                            // Send client email that the file is complete and read for viewing
                            /// Need to store the file
                            return File( combinedBytes, mimeType, downloadName );
                        }
                    }
                    else
                    {
                        logger.LogError( $"Method GetParticipantsEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetParticipantsEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }


        /// <summary>
        ///     Gets a PDF contained all the participants statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     PDF containing all the participants statements for a specified date
        /// </returns>
        [HttpPost( "estatements/{providerId}/statements/{planid}/pars/combined/{statementdate}" )] // Get Combined PDF of all statements for a Dete and participant
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsCombinedEStatementsByPlan( int providerId, string planid, DateTime statementdate, [FromBody] MultipleEStatments eStatements )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num.Equals( planid, StringComparison.OrdinalIgnoreCase ) && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        if( eStatements.eStatementIDs.Count() > 0)
                        {
                            query = query.Where( x => eStatements.eStatementIDs.Select( s => s.Trim() ).Contains( x.part_id.Trim() ) );
                        }

                        if ( query != null && query.Count() > 0 )
                        {
                            string downloadName = $"{DateTime.Now.ToString( "yyyyMMdd" )}-{providerId}-Combined.pdf";
                            downloadName = string.Join( string.Empty, downloadName.Split( Path.GetInvalidFileNameChars() ) );

                            PdfDocument outputDocument = new PdfDocument();

                            using ( eStatementDBContext pdfcontext = new eStatementDBContext( configuration ) )
                            {
                                foreach ( eStatementData parStatement in query )
                                {
                                    var eStatementQuery = pdfcontext.eStatement.Where( x => x.ID == parStatement.statementId );

                                    if ( eStatementQuery != null && eStatementQuery.Count() == 1 && eStatementQuery.First().eStatementPdf.Length > 0 )
                                    {

                                        ParticipanteStatement statementPdf = eStatementQuery.First();

                                        MemoryStream ms = new MemoryStream( statementPdf.eStatementPdf );
                                        PdfDocument inDoc = PdfReader.Open( ms, PdfDocumentOpenMode.Import );
                                        for ( int idx = 0; idx < inDoc.PageCount; idx++ )
                                        {
                                            // Get the page from the external document...
                                            PdfPage page = inDoc.Pages[idx];
                                            // ...and add it to the output document.
                                            outputDocument.AddPage( page );
                                        }

                                        logger.LogInformation( $"Adding PDF document {downloadName} to Combined pdf for {eStatements.eStatementIDs.Count()} participants statements" );
                                    }
                                }
                            }

                            using ( MemoryStream rms = new MemoryStream() )
                            {
                                outputDocument.Save( rms, false );
                                byte[] combinedBytes = rms.ToArray();

                                var mimeType = "application/pdf";

                                logger.LogInformation( $"Sending combined eStatement for participant {downloadName}" );

                                return File( combinedBytes, mimeType, downloadName );
                            }
                        }
                        else
                        {
                            logger.LogError( $"Method GetParticipantsEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                            return NotFound();
                        }
                    }
                    else
                    {
                        logger.LogError( $"Method GetParticipantsEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetParticipantsEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the participant statements for a specified date
        /// </summary>
        /// <param name="providerId">
        ///      Provider Identifier
        /// </param>
        /// <param name="uid">
        ///      Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Date of the statement
        /// </param>
        /// <returns>
        ///     All the eStatements for a participant for a specifed date
        /// </returns>
        [HttpGet( "estatements/{providerId}/statements/pars/{uid}/{statementdate}" )] // get all statements for a participant reguardless of plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantsEStatementsByDate( int providerId, Guid uid, DateTime statementdate )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.uid == uid && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetParticipantsEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetParticipantsEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the eStatements for a provider and a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider plan combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/statements/" )] // get all the statemetns for a plan
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlansEStatements( int providerId, string planid )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                ProviderSettings providerSettings = getProviderSettings( cshProviderId );
                DateTime startingDateOfStatements = getProvider1stQuarter( providerSettings );

                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num == planid &&
                                sp.statementDate.Date >= startingDateOfStatements.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetPlansEStatements: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetPlansEStatements : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///      Gets all the eStatements for a provider and a specific plan and date
        /// </summary>
        /// <summary>
        ///     Gets all the eStatements for a provider and a specific plan
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider, plan and statement date combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/statements/{statementdate}" )] // get all the statements fro a plan and date
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetPlansEStatementsByDate( int providerId, string planid, DateTime statementdate )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num == planid && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetPlansEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetPlansEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///  List of all the eStatements for a provider, plan and participant combiniation
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <returns>
        ///     List of all the eStatements for a provider plan and participant combiniation
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/" )]  // Get all Statements for a Participant
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantPlansEStatements( int providerId, string planid, Guid uid )
        {
            try
            {
                Guid cshProviderId = getProviderGuidByEstatementId( providerId );

                ProviderSettings providerSettings = getProviderSettings( cshProviderId );
                DateTime startingDateOfStatements = getProvider1stQuarter( providerSettings );

                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num == planid && sp.uid == uid &&
                                sp.statementDate.Date >= startingDateOfStatements.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetPlansEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetPlansEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets an eStatement for a participant and specific date
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <returns>
        ///     Kust if statenebts for a participant and specific date
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate}" )]  // Get All Statements for a Date for a Participants
        [Authorize]
        [ProducesResponseType( typeof( IEnumerable<eStatement> ), StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetParticipantPlansEStatementsbyDate( int providerId, string planid, Guid uid, DateTime statementdate )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {
                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num == planid && sp.uid == uid && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {
                        List<eStatement> eStatements = new List<eStatement>();
                        foreach ( eStatementData parStatement in query )
                        {
                            eStatement eStatement = new eStatement();
                            eStatement.firstname = parStatement.firstname;
                            eStatement.lastname = parStatement.lastname;
                            eStatement.part_id = parStatement.part_id;
                            eStatement.plan_name = parStatement.plan_name;
                            eStatement.plan_num = parStatement.plan_num;
                            eStatement.statementDate = parStatement.statementDate;
                            eStatement.statementId = parStatement.statementId;
                            eStatement.uid = parStatement.uid;

                            eStatements.Add( eStatement );
                        }

                        return new OkObjectResult( eStatements );
                    }
                    else
                    {
                        logger.LogError( $"Method GetPlansEStatementsByDate: No Particpant Statements were found for Provider {providerId}" );
                        return NotFound();
                    }
                }
            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetPlansEStatementsByDate : {providerId}  exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets the eStatement PDF document
        /// </summary>
        /// <param name="providerId">
        ///     Provider Identifier
        /// </param>
        /// <param name="planid">
        ///     Plan Identifier
        /// </param>
        /// <param name="uid">
        ///     Participant Identifier
        /// </param>
        /// <param name="statementdate">
        ///     Statement Date to retieve
        /// </param>
        /// <param name="statementid">
        ///     Identifeir for the PDF Codument
        /// </param>
        /// <returns>
        ///     File stream of the eStatement PDF document
        /// </returns>
        [HttpGet( "estatements/{providerId}/plans/{planid}/pars/{uid}/statements/{statementdate}/{statementid}" )]
        [Authorize]
        [ProducesResponseType( StatusCodes.Status200OK )]
        [ProducesResponseType( StatusCodes.Status404NotFound )]
        [ProducesResponseType( StatusCodes.Status400BadRequest )]
        public async Task<IActionResult> GetEStatement( int providerId, string planid, Guid uid, DateTime statementdate, int statementid )
        {
            try
            {
                using ( eStatementDBContext context = new eStatementDBContext( configuration ) )
                {

                    var query = from sp in context.eStatements
                                where sp.providerid == providerId && sp.plan_num == planid && sp.uid == uid && sp.statementDate.Date == statementdate.Date
                                select sp;

                    if ( query != null && query.Count() > 0 )
                    {

                        eStatementData statement = query.First();

                        var eStatementQuery = context.eStatement.Where( x => x.ID == statementid );

                        if ( eStatementQuery != null && eStatementQuery.Count() == 1 && eStatementQuery.First().eStatementPdf.Length > 0 )
                        {
                            string downloadName = $"{statement.statementDate.Year}-Q{YearQuarter.FromDate( statement.statementDate ).Quarter}-{statement.spon_num}.pdf";

                            downloadName = string.Join( string.Empty, downloadName.Split( Path.GetInvalidFileNameChars() ) );

                            ParticipanteStatement statementPdf = eStatementQuery.First();

                            var readStream = statementPdf.eStatementPdf;
                            var mimeType = "application/pdf";

                            logger.LogInformation( $"Sending eStatement for provider {providerId} with statement identifier {statementid}" );

                            return File( readStream, mimeType, downloadName );

                        }
                        else
                        {
                            logger.LogError( $"The eStatement with identifier {statementid} was not found." );
                            return NotFound();
                        }
                    }
                    else
                    {
                        logger.LogError( $"The eStatement was not found for the Proivder with ID {providerId} and eStatement with statmentid {statementid} combination" );
                        return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                    }
                }


            }
            catch ( Exception ex )
            {
                logger.LogError( $"GetEStatement : {providerId} : {statementid} : exception {ex.ToString()}" );
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }
        #endregion eStatements

        #endregion public methods

        #region private methods
        private void saveCombinedPDFFilesData( List<tvp_ss_ident> ss_ident )
        {
            string connectionString = configuration["ConnectionStrings:ESTATEMENT"];

            using ( SqlConnection sqlConnection = new SqlConnection( connectionString ) )
            {
                using ( SqlCommand sqlCommand = new SqlCommand( "usp_insert_update_ss_ident", sqlConnection ) )
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    SqlParameter sqlParameter = sqlCommand.Parameters.AddWithValue( "@tvp_ss_idnet", ss_ident.ToDataTable() );
                    sqlParameter.SqlDbType = SqlDbType.Structured;
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                }
                sqlConnection.Close();
            }
        }

        private void saveCombinedPDFFile( string part_id, string plan_num, DateTime rptDate, byte[] fileData )
        {
            string connectionString = configuration["ConnectionStrings:ESTATEMENT"];

            using ( SqlConnection sqlConnection = new SqlConnection( connectionString ) )
            {
                using ( SqlCommand sqlCommand = new SqlCommand( "pEStatementPdfInsUpd", sqlConnection ) )
                {
                    SqlParameter parameter = new SqlParameter( "part_id", part_id );
                    sqlCommand.Parameters.Add( parameter );

                    parameter = new SqlParameter( "plan_num", plan_num );
                    sqlCommand.Parameters.Add( parameter );

                    parameter = new SqlParameter( "rpt_date", rptDate );
                    sqlCommand.Parameters.Add( parameter );

                    parameter = new SqlParameter( "eStatementPdf", fileData );
                    sqlCommand.Parameters.Add( parameter );

                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                }
                sqlConnection.Close();
            }
        }
        #endregion private methods

    }
}