﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Controllers
{

    #region using
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.FileProviders;
    using System.Runtime.InteropServices;
    using System.Security;
    using System.Security.Principal;
    using Microsoft.Win32.SafeHandles;
    using MMApi.ViewModel;
    using MMARDataApi.Models;
    using OfficeOpenXml;
    using OfficeOpenXml.Style;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    #endregion using

    [Produces( "application/json" )]
    [Route( "api/v1/[controller]" )]
    [EnableCors( "CorsPolicy" )]
    [ApiExplorerSettings( GroupName = "massmutual" )]
    public class MMARDataController : Controller
    {
        private IConfiguration configuration;

        #region Contructor
        /// <summary>
        ///     Default constructor that uses deendancy injection
        ///     to get the configuraion
        /// </summary>
        /// <param name="config">
        ///     Constructed application configuation
        /// </param>
        public MMARDataController( IConfiguration config )
        {
            configuration = config;
        }
        #endregion Constructor

        #region Public Methods
        [HttpGet( "uptime" )]
        [AllowAnonymous]
        public IActionResult UpTime()
        {
            return new OkObjectResult( DateTime.Now.ToString() );
        }
        /// <summary>
        ///     Gets Feed Statistical data fro a given
        ///     date range
        /// </summary>
        /// <param name="startDate">
        ///     State Date for when to get the data from
        /// </param>
        /// <param name="endDate">
        ///     End Date to get the data to
        /// </param>
        /// <returns>
        ///     Statistics array
        /// </returns>
        [HttpGet( "stats" )]
        [Authorize]
        public async Task<IActionResult> Get( DateTime startDate, DateTime endDate )
        {
            List<Statistics> stats = new List<Statistics>();

            try
            {
                using( MMARDBContext context = new MMARDBContext( configuration ) )
                {

                    stats = context.FeedStatistics2s.Where( s => s.FeedDate >= startDate &&
                                         s.FeedDate <= endDate )
                                         .Select( s => new Statistics()
                                         {
                                             FeedDate = s.FeedDate,
                                             TotalLow = s.TotalLow,
                                             B2PTotalLow = s.B2PTotalLow,
                                             TotalLowOpp = s.TotalLowOpp,
                                             B2PTotalLowOpp = s.B2PTotalLowOpp,
                                             TotalHigh = s.TotalHigh,
                                             B2PTotalHigh = s.B2PTotalHigh,
                                             TotalEOnly = s.TotalEOnly
                                         } ).OrderBy( o => o.FeedDate ).ToList<Statistics>();

                }
                return new OkObjectResult( stats );
            }
            catch( Exception ex)
            {
                string s = ex.Message;
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets all the participant communications for the specified date range 
        ///     and communication type
        /// </summary>
        /// <param name="startDate">
        ///     Start date to get the data from
        /// </param>
        /// <param name="endDate">
        ///     End date to ge the data to
        /// </param>
        /// <param name="commType">
        ///     Communication type to retieve
        /// </param>
        /// <returns>
        ///     Participant array
        /// </returns>
        [HttpGet( "comms" )]
        [Authorize]
        public async Task<IActionResult> GetComms( DateTime startDate, DateTime endDate, string commType )
        {
            List<Participant> pars = new List<Participant>();

            List<string> idTypes = new List<string>();
            List<int> feedTypes = new List<int>();
            switch( commType.ToLower() )
            {
                case "l":
                case "lo":
                    feedTypes = new List<int>() { 1, 2 };
                    break;
                case "h":
                    feedTypes = new List<int>() { 4, 5 };
                    break;
                default:
                    feedTypes = new List<int>() { 3, 6 };
                    break;
            }

            List<string> oppCodes = new List<string>() { "OLBF", "OLBFDF", "OLBM", "LMOF", "LMOMPDF", "LMOM" };

            try
            {
                using( MMARDBContext context = new MMARDBContext( configuration ) )
                {
                    var query = (from p in context.ParticipantCommunications
                                 join c in context.CSHOrder on p.OrderId equals c.ID
                                 where (startDate == endDate ? c.FeedDate == startDate : c.FeedDate >= startDate &&
                                      c.FeedDate <= endDate && c.FeedTypeCD != Feedtype.eOnly)
                                      
                                 select new { p, c });

                    if( commType.ToLower() != "a" )
                    {
                        query = query.Where( w => feedTypes.Contains( (int) w.c.FeedTypeCD ) );

                        if( commType.ToLower() == "lo" )
                        {
                            query = query.Where( w => oppCodes.Contains( w.p.CommunicationType ) );
                        }
                        else if( commType.ToLower() == "l")
                        {
                            query = query.Where( w => !oppCodes.Contains( w.p.CommunicationType ) );
                        }
                    }

                    var result = ( from r in query
                                   select new
                                   {
                                       FirstName = r.p.FirstName,
                                       LastName = r.p.LastName,
                                       CSHParID = r.p.CSHParID,
                                       ParID = r.p.ParID,
                                       PlanName = r.p.PlanName,
                                       FeedDate = r.c.FeedDate,
                                       OrderId = r.c.ID
                                   } ).ToList();


                    HashSet<string> parHash = new HashSet<string>();

                    foreach ( var p in result )
                    {
                        bool found = true;
                        Participant par = new Participant
                        {
                            fname = p.FirstName,
                            lname = p.LastName,
                            id = p.ParID
                        };

                        if( parHash.Contains( par.fname.Trim().ToLower() + par.lname.Trim().ToLower() + par.id.Trim().ToLower() ) )
                        {
                            par = pars.Where( x => x.fname.Trim().ToLower() == par.fname.Trim().ToLower() &&
                                    x.lname.Trim().ToLower() == par.lname.Trim().ToLower() &&
                                    x.id.Trim().ToLower() == par.id.Trim().ToLower() ).First();
                        }
                        else
                        {
                            found = false;
                            parHash.Add( par.fname.Trim().ToLower() + par.lname.Trim().ToLower() + par.id.Trim().ToLower() );
                            par.communications = new List<Communication>();
                        }

                        Communication comm = new Communication();
                        comm.planName = p.PlanName;
                        comm.pdf = p.CSHParID.ToString();
                        comm.date = p.FeedDate;
                        comm.orderId = p.OrderId;
                        par.communications.Add( comm );
                        if( !found )
                        {
                            pars.Add( par );
                        }
                    }
                }

                return new OkObjectResult( pars );
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        /// <summary>
        ///     Gets a PDF communication for the given order/communication identifier
        /// </summary>
        /// <param name="id">
        ///     Itentifier for the order to get the communication from
        /// </param>
        /// <param name="commid">
        ///     Identifier for the communication to retireve
        /// </param>
        /// <returns>
        ///     File stream of the PDF file
        /// </returns>
        [HttpGet( "orders/{id}/{commid}" )]
        [Authorize]
        public async Task<IActionResult> GetParticipantCommunication( int id, Guid commid )
        {
            const int LOGON32_PROVIDER_DEFAULT = 0;
            //This parameter causes LogonUser to create a primary token.   
            const int LOGON32_LOGON_INTERACTIVE = 2;

            try
            {
                using( MMARDBContext context = new MMARDBContext( configuration ) )
                {
                    var result = ( from p in context.ParticipantCommunications
                                   join c in context.CSHOrder on p.OrderId equals c.ID
                                   where ( p.OrderId == id && p.CSHParID == commid )
                                   select new
                                   {
                                       commid = p.CSHParID,
                                       planName = p.PlanName,
                                       feedDate = c.FeedDate,
                                       folder = c.CSHOrderNbr
                                   } ).FirstOrDefault() ?? null;


                    if( result != null )
                    {

                        string pdfLocation = $@"{configuration[ "Comms:Location" ]}{result.folder}\";
                        string pdfName = $"{result.commid}.pdf";
                        string downloadName = $"{result.feedDate.ToString( "yyyy-MM-dd" )} - {result.planName}";

                        downloadName = string.Join( string.Empty, downloadName.Split( Path.GetInvalidFileNameChars() ) );

                        bool useImpersonation = Convert.ToBoolean( configuration[ "Impersonation:UseImpersonation" ] );

                        // Call LogonUser to obtain a handle to an access token.   
                        SafeAccessTokenHandle safeAccessTokenHandle = null;
                        if( useImpersonation )
                        {
                            bool returnValue = LogonUser( configuration[ "Impersonation:Username" ],
                             configuration[ "Impersonation:DOMAIN" ], configuration[ "Impersonation:Password" ],
                            LOGON32_LOGON_INTERACTIVE,
                            LOGON32_PROVIDER_DEFAULT,
                            out safeAccessTokenHandle );

                            if( false == returnValue )
                            {
                                int ret = Marshal.GetLastWin32Error();
                                Console.WriteLine( "LogonUser failed with error code : {0}", ret );
                                throw new System.ComponentModel.Win32Exception( ret );
                            }
                        }


                        FileStreamResult fileResult = null;
                        // Note: if you want to run as unimpersonated, pass  
                        //       'SafeAccessTokenHandle.InvalidHandle' instead of variable 'safeAccessTokenHandle'  
                        WindowsIdentity.RunImpersonated(
                            useImpersonation ? safeAccessTokenHandle : SafeAccessTokenHandle.InvalidHandle,
                            // User action  
                            () =>
                            {
                                if( System.IO.File.Exists( pdfLocation + pdfName ) )
                                {
                                    IFileProvider provider = new PhysicalFileProvider( pdfLocation );
                                    IFileInfo fileInfo = provider.GetFileInfo( pdfName );
                                    var readStream = fileInfo.CreateReadStream();
                                    var mimeType = "application/pdf";

                                    fileResult = File( readStream, mimeType, downloadName );
                                }
                                else
                                {
                                    fileResult = null;
                                }
                            }
                        );

                        if( fileResult == null )
                        {
                            return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                        }
                        else
                        {
                            return fileResult;
                        }
                    }
                    else
                    {
                        return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
                    }
                }
            }
            catch
            {
                return await Task.FromResult( BadRequest( new ApiResponse( 400 ) ) );
            }
        }

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        public static extern bool LogonUser( 
            [MarshalAs( UnmanagedType.LPStr )]String lpszUsername,
            [MarshalAs( UnmanagedType.LPStr )]String lpszDomain,
            [MarshalAs( UnmanagedType.LPStr )]String lpszPassword,
            int dwLogonType, 
            int dwLogonProvider, 
            out SafeAccessTokenHandle phToken );

        private FileStreamResult getCommunicationFromDisk( string pdfLocation, string pdfName, string downloadName )
        {
            if( System.IO.File.Exists( pdfLocation + pdfName ) )
            {
                IFileProvider provider = new PhysicalFileProvider( pdfLocation );
                IFileInfo fileInfo = provider.GetFileInfo( pdfName );
                var readStream = fileInfo.CreateReadStream();
                var mimeType = "application/pdf";

                return File( readStream, mimeType, downloadName );
            }
            else
            {
                return null;
            }

        }

        /// <summary>
        ///     Gets a production invoice for a particular year and month.
        ///     
        ///     NOTE: only 4 months of data is kept on the live system.
        /// </summary>
        /// <param name="year">
        ///     Year to retieve the invoice for
        /// </param>
        /// <param name="month">
        ///     Month to retireve the invoce for
        /// </param>
        /// <returns>
        ///     Excel File Stream that contains the invoce
        /// </returns>
        [HttpGet( "orders/invoice/{year}/{month}" )]
        [Authorize]
        public async Task<IActionResult> GetOrderInvoice( int year, int month )
        {
            byte[] fileContents;
            var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            try
            {
                using( MemoryStream ms = new MemoryStream() )
                {

                    using( MMARDBContext context = new MMARDBContext( configuration ) )
                    {
                        // Get number of Feeds that we processed from MM
                        var stats = ( from s in context.FeedStatistics
                                      where s.FeedDate.Month == month && s.FeedDate.Year == year
                                      select s );

                        // This goes in fields E:15 and E:16
                        int totalFeeds = stats.Select( x => x.FeedDate ).Distinct().Count();
                        // This goes in E:17
                        int totalLow = stats.Sum( x => x.TotalLow + x.TotalLowOpp );
                        // This goes in E:18
                        int totalHigh = stats.Sum( x => x.TotalHigh );
                        // Add Both together and this is E:19
                        int totalPdf = stats.Sum( x => x.TotalEOnly );
                        // This goid in D:15 to count
                        List<string> jts = ( from jt in context.CSHOrder
                                             where jt.FeedDate.Month == month && jt.FeedDate.Year == year
                                             orderby jt.JT
                                             select jt.JT ).ToList();

                        FileInfo fi = new FileInfo( "MMAR-Invoice.xlsx" );

                        using( ExcelPackage pck = new ExcelPackage( fi ) )
                        {
                            var ws = pck.Workbook.Worksheets[ 1 ];

                            ws.Cells[ 15, 5 ].Value = totalFeeds.ToString();
                            ws.Cells[ 16, 5 ].Value = totalFeeds.ToString();
                            ws.Cells[ 17, 5 ].Value = totalLow.ToString();
                            ws.Cells[ 18, 5 ].Value = totalHigh.ToString();
                            ws.Cells[ 19, 5 ].Value = ( totalLow + totalHigh ).ToString();
                            ws.Cells[ 20, 5 ].Value = ( totalLow + totalHigh ).ToString();

                            int cellCount = 15;
                            foreach( string jt in jts )
                            {
                                ws.Cells[ cellCount, 4 ].Value = jt;

                                cellCount++;
                            }

                            ExcelRange range = ws.Cells[ 26, 1, cellCount - 1, 6 ];

                            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            range.Style.Border.Right.Style = ExcelBorderStyle.Thin;

                            pck.Workbook.Calculate();
                            pck.SaveAs( ms );
                        }
                    }
                    ms.Position = 0;

                    fileContents = ms.ToArray();
                }

                return File( fileContents, mimeType, $"MMAR-Invoice-{month}-{year}.xlsx" );

            }
            catch
            {
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }

        /// <summary>
        ///     Gets a report for a particular range of dates.
        ///     
        ///     NOTE: only 4 months of data is kept on the live system.
        /// </summary>
        /// <param name="year1">
        ///     Year1 to retieve the report for
        /// </param>
        /// <param name="year2">
        ///     Year2 to retireve the report for
        /// </param>
        /// <returns>
        ///     Excel File Stream that contains the invoce
        /// </returns>
        [HttpGet("orders/downloadreport/{year1}/{year2}")]
        [Authorize]
        public async Task<IActionResult> GetReport(string year1, string year2)
        {
            byte[] fileContents;
            var mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            DateTime date1 = Convert.ToDateTime(year1);
            DateTime date2 = Convert.ToDateTime(year2);
           
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    using (MMARDBContext context = new MMARDBContext(configuration))
                    {
                        // Get number of Feeds that we processed from MM
                        var stats1 = context.FeedStatistics.Where(s => s.FeedDate >= date1 &&
                                        s.FeedDate <= date2)
                                         .Select(s => new Statistics()
                                         {
                                             FeedDate = s.FeedDate,
                                             TotalLow = s.TotalLow,
                                             TotalLowOpp = s.TotalLowOpp,
                                             TotalHigh = s.TotalHigh,
                                             TotalEOnly = s.TotalEOnly
                                         }).OrderBy(o => o.FeedDate).ToList<Statistics>();


                        var stats = context.FeedStatistics2s.Where( s => s.FeedDate >= date1 &&
                                         s.FeedDate <= date2 )
                                         .Select( s => new Statistics()
                                         {
                                             FeedDate = s.FeedDate,
                                             TotalLow = s.TotalLow,
                                             B2PTotalLow = s.B2PTotalLow,
                                             TotalLowOpp = s.TotalLowOpp,
                                             B2PTotalLowOpp = s.B2PTotalLowOpp,
                                             TotalHigh = s.TotalHigh,
                                             B2PTotalHigh = s.B2PTotalHigh,
                                             TotalEOnly = s.TotalEOnly,
                                             B2PTotalEOnly = s.B2PTotalEOnly
                                         } ).OrderBy( o => o.FeedDate ).ToList<Statistics>();


                        FileInfo fi = new FileInfo("MMAR-DownloadReport.xlsx");
                        
                        using (ExcelPackage pck = new ExcelPackage(fi))
                        {
                            var ws = pck.Workbook.Worksheets[1];

                            int cellCount = 2;
                            int i=0;
                            int totalCount = stats.Count;

                            for (DateTime date = date1; date.Date <= date2.Date; date = date.AddDays(1) )                            
                            {
                                ws.Cells[cellCount, 1].Value = date;

                                if ( totalCount > i && date == stats[i].FeedDate) {                                    
                                    ws.Cells[ cellCount, 2 ].Value = stats[ i ].TotalLow;
                                    ws.Cells[ cellCount, 3 ].Value = stats[ i ].B2PTotalLow;
                                    ws.Cells[ cellCount, 4 ].Value = stats[ i ].TotalLowOpp;
                                    ws.Cells[ cellCount, 5 ].Value = stats[ i ].B2PTotalLowOpp;
                                    ws.Cells[ cellCount, 6 ].Value = stats[ i ].TotalHigh;
                                    ws.Cells[ cellCount, 7 ].Value = stats[ i ].B2PTotalHigh;
                                    ws.Cells[ cellCount, 8 ].Value = stats[ i ].TotalEOnly;

                                    i++;
                                }                                

                                cellCount++;
                                
                            }

                            pck.Workbook.Calculate();
                            pck.SaveAs(ms);
                        }
                    }
                    ms.Position = 0;

                    fileContents = ms.ToArray();
                }

                return File(fileContents, mimeType, $"MMAR-Invoice-{year1}-{year2}.xlsx");

            }
            catch(Exception ex)
            {
                using (StreamWriter sw = new StreamWriter(@"E:\Web\MMArDataApi\DRError.txt"))
                {
                    sw.WriteLine(ex.Message);
                    sw.WriteLine(ex.Source);
                    sw.WriteLine(ex.StackTrace);
                }
                return await Task.FromResult(BadRequest(new ApiResponse(400)));
            }
        }
        #endregion Public Methods
    }
}