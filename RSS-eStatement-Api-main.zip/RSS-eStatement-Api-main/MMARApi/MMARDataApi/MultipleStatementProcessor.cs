﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi
{

	public static class DataTableExtensions
	{
		public static DataTable ToDataTable<T>( this IList<T> data )
		{
			PropertyDescriptorCollection properties = TypeDescriptor.GetProperties( typeof( T ) );
			DataTable dataTable = new DataTable();
			for ( int i = 0; i < properties.Count; i++ )
			{
				PropertyDescriptor propertyDescriptor = properties[i];
				dataTable.Columns.Add( propertyDescriptor.Name, propertyDescriptor.PropertyType );
			}
			object[] array = new object[properties.Count];
			foreach ( T datum in data )
			{
				for ( int j = 0; j < array.Length; j++ )
				{
					array[j] = properties[j].GetValue( datum );
				}
				dataTable.Rows.Add( array );
			}
			return dataTable;
		}
	}

	public class tvp_ss_ident
	{

		public string file_name
		{
			get;
			set;
		}

		public string part_id
		{
			get;
			set;
		}

		public int position
		{
			get;
			set;
		}

		public int pages
		{
			get;
			set;
		}

		public string plan_num
		{
			get;
			set;
		}

		public DateTime rpt_date
		{
			get;
			set;
		}

		public int isactive
		{
			get;
			set;
		}


		public string spon_num
		{
			get;
			set;
		}

		public string provid
		{
			get;
			set;
		}

		public string trans_no
		{
			get;
			set;
		}

		public string fname
		{
			get;
			set;
		}

		public string lname
		{
			get;
			set;
		}

		public Guid uid
		{
			get;
			set;
		}

		public int platform
		{
			get;
			set;
		}

		public int batch
		{
			get;
			set;
		}

		public int IsSmart
		{
			get;
			set;
		}

		
		public string CommunicationTypeCD
		{
			get;
			set;
		}

		public string FileLocationTypeCD
		{
			get;
			set;
		}
		
		public string DateSubmitted 
		{
			get;
			set;
		}
	}

	//public class MultipleStatementProcessor
	//{

	//	public List<string> ProcessStatement( string part_id, string provID, string planNum, string uid, bool isSingleFile, string statementDates, bool isProcessAll, string lastName, bool isOutputToFTP, string neptuneCustNo )
	//	{
	//		_ = string.Empty;
	//		List<string> list = new List<string>();
	//		string empty = string.Empty;

	//		List<string> planNumList = planNum.Split( ',' ).ToList();

	//		string[] lastNameList = lastName.Split( new char[1]{','}, StringSplitOptions.RemoveEmptyEntries );
	//		string[] part_idList = part_id.Split( new char[1]{','}, StringSplitOptions.RemoveEmptyEntries );

	//		int communicationtype = int.MinValue;
	//		string communicationscope = string.Empty;

	//		getCommunicationTypeCD( neptuneCustNo, ref communicationtype, ref communicationscope );

	//		List<tvp_ss_ident> list3 = new List<tvp_ss_ident>();

	//		string text = ConfigurationManager.AppSettings["UIRepositoryInputLocation"].ToString();

	//		empty = ((!isOutputToFTP) ? ConfigurationManager.AppSettings["UIRepositoryLocation"].ToString() : ConfigurationManager.AppSettings["FTPOutputFileLocation"].ToString());

	//		string text2 = string.Empty;
	//		string empty2 = string.Empty;

	//		string[] statementDatesList = statementDates.Split( new char[1]{','}, StringSplitOptions.RemoveEmptyEntries );

	//		string[] uidList = uid.Split( new char[1]{','}, StringSplitOptions.RemoveEmptyEntries );

	//		if ( !Directory.Exists( empty ) )
	//		{
	//			Directory.CreateDirectory( empty );
	//		}

	//		tvp_ss_ident tvp_ss_ident = new tvp_ss_ident();

	//		if ( part_idList.Length == 1 && isSingleFile )
	//		{
	//			// Gets all the statements for 1 participant for specified dates

	//			empty = empty + planNum + "_multipleperiods_" + lastNameList[0] + part_id.Substring( part_id.Length - 4, 4 ) + ".pdf";

	//			for ( int i = 0; i < statementDatesList.Count(); i++ )
	//			{
	//				if ( communicationtype == 1 || communicationtype == 2 || communicationtype == 3 )
	//				{
	//					text2 = provID + "~" + planNum + "~" + uid + ".pdf";
	//				}
	//				empty2 = ((!(communicationscope == "PROVIDER")) ? (text + provID + "\\" + Convert.ToDateTime( statementDatesList[i] ).ToString( "yyyyMMdd" ) + "\\" + planNum + "\\" + text2) : (text + provID + "\\" + Convert.ToDateTime( statementDatesList[i] ).ToString( "yyyyMMdd" ) + "\\" + text2));
	//				list.Add( empty2 );
	//			}

	//			tvp_ss_ident.file_name = Path.GetFileName( empty );
	//			tvp_ss_ident.part_id = part_id;
	//			tvp_ss_ident.position = 0;
	//			tvp_ss_ident.pages = createCombinedPDFFiles( provID, empty, part_idList, lastNameList, list.ToArray() );
	//			tvp_ss_ident.plan_num = planNum;
	//			tvp_ss_ident.rpt_date = DateTime.Now;
	//			tvp_ss_ident.isactive = 1;
	//			tvp_ss_ident.spon_num = planNum;
	//			tvp_ss_ident.provid = provID;
	//			tvp_ss_ident.trans_no = "0";
	//			tvp_ss_ident.fname = "test";
	//			tvp_ss_ident.lname = lastNameList[0];
	//			tvp_ss_ident.uid = new Guid( uid );
	//			tvp_ss_ident.platform = 0;
	//			tvp_ss_ident.batch = 0;
	//			tvp_ss_ident.IsSmart = 0;
	//			tvp_ss_ident.CommunicationTypeCD = communicationtype;
	//			tvp_ss_ident.FileLocationTypeCD = 2;
	//			list3.Add( tvp_ss_ident );
	//		}
	//		else if ( part_idList.Length > 1 && isSingleFile )
	//		{
	//			for ( int j = 0; j < part_idList.Count(); j++ )
	//			{
	//				if ( communicationtype == 1 || communicationtype == 2 || communicationtype == 3 )
	//				{
	//					text2 = provID + "~" + planNum + "~" + uidList[j] + ".pdf";
	//				}
	//				empty2 = ((!(communicationscope == "PROVIDER")) ? (text + provID + "\\" + Convert.ToDateTime( statementDatesList[0] ).ToString( "yyyyMMdd" ) + "\\" + planNum + "\\" + text2) : (text + provID + "\\" + Convert.ToDateTime( statementDatesList[0] ).ToString( "yyyyMMdd" ) + "\\" + text2));
	//				list.Add( empty2 );
	//			}
	//			List<ParticipantFile> participantFileList = new List<ParticipantFile>();

	//			string[] fileList = list.ToArray();
	//			participantFileList = FileListwithSizeandName( fileList );

	//			participantFileList = participantFileList.OrderBy( ( ParticipantFile x ) => x.FileSize ).ToList();

	//			new List<string>();
	//		}
	//		else if ( part_idList.Length > 1 && !isSingleFile )
	//		{
	//			for ( int k = 0; k < part_idList.Count(); k++ )
	//			{
	//				if ( communicationtype == 1 || communicationtype == 2 || communicationtype == 3 )
	//				{
	//					text2 = provID + "~" + planNumList[k] + "~" + uidList[k] + ".pdf";
	//				}
	//				empty2 = ((!(communicationscope == "PROVIDER")) ? (text + provID + "\\" + Convert.ToDateTime( statementDatesList[0] ).ToString( "yyyyMMdd" ) + "\\" + planNumList[k] + "\\" + text2) : (text + provID + "\\" + Convert.ToDateTime( statementDatesList[0] ).ToString( "yyyyMMdd" ) + "\\" + text2));
	//				if ( File.Exists( empty2 ) )
	//				{
	//					tvp_ss_ident.file_name = Path.GetFileName( empty2 );
	//					tvp_ss_ident.part_id = part_idList[k];
	//					tvp_ss_ident.position = 0;
	//					tvp_ss_ident.pages = createPDFFiles( provID, empty, part_idList[k], lastNameList[k], empty2 );
	//					tvp_ss_ident.plan_num = planNumList[k];
	//					tvp_ss_ident.rpt_date = DateTime.Now;
	//					tvp_ss_ident.isactive = 1;
	//					tvp_ss_ident.spon_num = planNumList[k];
	//					tvp_ss_ident.provid = provID;
	//					tvp_ss_ident.trans_no = "0";
	//					tvp_ss_ident.fname = "test";
	//					tvp_ss_ident.lname = lastNameList[k];
	//					tvp_ss_ident.uid = new Guid( uidList[k] );
	//					tvp_ss_ident.platform = 0;
	//					tvp_ss_ident.batch = 0;
	//					tvp_ss_ident.IsSmart = 0;
	//					tvp_ss_ident.CommunicationTypeCD = communicationtype;
	//					tvp_ss_ident.FileLocationTypeCD = 2;
	//					list3.Add( tvp_ss_ident );
	//				}
	//			}
	//		}

	//		saveCombinedPDFFilesData( list3 );
	//		return list;
	//	}
	//}
}
