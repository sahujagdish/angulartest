﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi
{
    #region Using
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.IdentityModel.Tokens;
    using System.IO;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    #endregion Using

    public partial class Startup
    {
        #region Private Methods
        /// <summary>
        ///     Creates the JWT token authorization scheme for
        ///     this api
        /// </summary>
        /// <param name="services">
        ///     IServiceCollection
        /// </param>
        private void configureJwtAuthService( IServiceCollection services )
        {
            byte[] certificateBytes = readFile( Configuration[ "Jwt:Certificate" ] );
            X509Certificate2 certificate2 = new X509Certificate2( certificateBytes, Configuration[ "Jwt:CertPassword" ],
                X509KeyStorageFlags.Exportable |
                X509KeyStorageFlags.MachineKeySet |
                X509KeyStorageFlags.PersistKeySet );
            var securityKey = new X509SecurityKey( certificate2 );

            SigningCredentials creds = new SigningCredentials( securityKey, SecurityAlgorithms.RsaSha256 );


            services.AddAuthentication( JwtBearerDefaults.AuthenticationScheme )
               .AddJwtBearer( options =>
               {
                   options.Audience = Configuration[ "Jwt:Issuer" ];

                   options.TokenValidationParameters = new TokenValidationParameters
                   {
                       ValidateIssuer = true,
                       ValidateAudience = true,
                       ValidateLifetime = true,
                       ValidateIssuerSigningKey = true,
                       ValidIssuer = Configuration[ "Jwt:Issuer" ],
                       ValidAudience = Configuration[ "Jwt:Issuer" ],

                       IssuerSigningKey = new SymmetricSecurityKey( Encoding.UTF8.GetBytes( Configuration[ "Jwt:Key" ] ) )
            
                   };
               } 
            );
        }

        /// <summary>
        ///     Reads the given file into byte data
        /// </summary>
        /// <param name="fileName">
        ///     Filename including the full path
        /// </param>
        /// <returns>
        ///     Byte array for the given file
        /// </returns>
        private byte[] readFile( string fileName )
        {
            byte[] data = null;
            using( FileStream fs = new FileStream( fileName, FileMode.Open, FileAccess.Read ) )
            {
                int size = (int) fs.Length;
                data = new byte[ size ];
                size = fs.Read( data, 0, size );
            }
            return data;
        }
        #endregion
    }
}
