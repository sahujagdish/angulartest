﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/


namespace MMARDataApi.Models
{
    #region using
    using Microsoft.Extensions.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.EntityFrameworkCore;

    #endregion
    public class StatementsDBContext : DbContext
    {
        #region Database's
        public DbSet<ProviderMessage> ProviderMessages { get; set; }

        public DbSet<PlanMessage> PlanMessages { get; set; }
        
        public DbSet<ProviderLevelLogo> ProviderLevelLogos { get; set; }

        public DbSet<ProviderLogo> ProviderLogos { get; set; }

        public DbSet<PlanLogo> PlanLogo { get; set; }

        public DbSet<EStatementProvider> Provider { get; set; }

        public DbSet<StatementPlan> ProviderPlans { get; set; }

        public DbSet<ProviderPlan> ProviderPlan { get; set; }

        public DbSet<StatementExtract> StatementExtract { get; set; }

        public DbSet<StatementExtractOrder> StatementExtractOrders { get; set; }

        public DbSet<StatementExtractOrderParticipant> StatementExtractOrderParticipants { get; set; }


        public DbSet<ProviderSettings> ProviderSettings { get; set; }

        public DbSet<StatementExtractReport> StatementExtractReport { get; set; }

        public DbSet<StatementExtractReportReport> ExtractReport { get; set; }

        public DbSet<ProviderENotifySettings> ProviderENotifySettings { get; set; }

        public DbSet<PlanEnotifyOverrideSettings> PlanEnotifyOverrideSettings { get; set; }

        #endregion Database's

        private IConfiguration configuration;

        /// <summary>
        public StatementsDBContext( IConfiguration config )
        {
            configuration = config;
            Database.SetCommandTimeout( 15000 );
        }

        protected override void OnConfiguring( DbContextOptionsBuilder optionsBuilder )
        {
            string connectionString = configuration[ "ConnectionStrings:STATEMENTS" ];
                optionsBuilder
                .UseSqlServer( connectionString );
        }

        /// <summary>
        ///     Add the Views used to extract data from the tables 
        /// </summary>
        /// <param name="modelBuilder">
        /// </param>
        protected override void OnModelCreating( ModelBuilder modelBuilder )
        {
            modelBuilder.Entity<ProviderMessage>().ToTable( "vProviderMessage" );
            modelBuilder.Entity<PlanMessage>().ToTable( "vPlanMessage" );
            modelBuilder.Entity<ProviderLogo>().ToTable( "vProviderLogo" );
            modelBuilder.Entity<PlanLogo>().ToTable( "vPlanLogo" );
            modelBuilder.Entity<EStatementProvider>().ToTable( "vProviderIds" );
            modelBuilder.Entity<StatementPlan>().ToTable( "vProviderPlans" );
            modelBuilder.Entity<ProviderPlan>().ToTable( "vPlan" );
            modelBuilder.Entity<StatementExtract>().ToTable( "vStatementExtract" );

            modelBuilder.Entity<ProviderLevelLogo>().ToTable("teProviderLevelLogo").HasKey(x=>x.ProviderId);

            modelBuilder.Entity<ProviderMessage>()
              .HasKey( c => new { c.ProviderId, c.MessageId } );

            modelBuilder.Entity<PlanMessage>()
             .HasKey( c => new { c.ProviderId, c.ExternalPlanID, c.MessageLocation} );

            modelBuilder.Entity<ProviderLogo>()
                .HasKey( c => new { c.ProviderId, c.LogoId } );

            modelBuilder.Entity<PlanLogo>()
                .HasKey( c => new { c.ProviderId, c.ExternalPlanId } );

            modelBuilder.Entity<StatementPlan>()
                .HasKey( c => new { c.ProviderId, c.ExternalPlanId } );

            modelBuilder.Entity<ProviderPlan>()
                .HasKey( c => new { c.ProviderId, c.ExternalPlanId } );

            modelBuilder.Entity<StatementExtract>()
               .HasKey( c => new { c.EStatementExtractId } );

            modelBuilder.Entity<StatementExtractOrder>().ToTable("vStatementExtractOrder");

            modelBuilder.Entity<StatementExtractOrder>()
             .HasKey(c => new { c.StatementOrderId });

            modelBuilder.Entity<StatementExtractOrderParticipant>().ToTable("vStatementExtractOrderParticipant");

            modelBuilder.Entity<StatementExtractOrderParticipant>()
             .HasKey(c => new { c.StatementOrderId, c.PlanId, c.ParticipantId });

            modelBuilder.Entity<ProviderSettings>().ToTable("vProviderSettings");

            modelBuilder.Entity<ProviderSettings>()
             .HasKey(c => new { c.ProviderId });

            modelBuilder.Entity<StatementExtractReport>().ToTable( "vStatementExtractReportSmall" );

            modelBuilder.Entity<StatementExtractReport>()
             .HasKey( c => new { c.EStatementExtractID, c.StatementExtractReportTypeCD } );

            modelBuilder.Entity<StatementExtractReportReport>().ToTable( "vGetStatementExtractReport" );
            modelBuilder.Entity<StatementExtractReportReport>()
             .HasKey( c => new { c.EStatementExtractID, c.StatementExtractReportTypeCD } );

            modelBuilder.Entity<ProviderENotifySettings>().ToTable( "vProviderENotifySettings" );
            modelBuilder.Entity<ProviderENotifySettings>()
             .HasKey( c => new { c.ProviderId } );

            modelBuilder.Entity<PlanEnotifyOverrideSettings>().ToTable( "vPlanEnotifyOverrideSettings" );
            modelBuilder.Entity<PlanEnotifyOverrideSettings>()
             .HasKey( c => new { c.ProviderId, c.ExternalPlanId, c.PlanEnotifyOverrideTypeCD } );
        }
    }
}
