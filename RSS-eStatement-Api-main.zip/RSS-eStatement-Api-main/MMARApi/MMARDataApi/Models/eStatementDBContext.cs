﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    #endregion using

    public class eStatementDBContext : DbContext
    {

        #region Database's
        public DbSet<AdministratorEntity> AdminEntity { get; set; }
        public DbSet<eStatementData> eStatements { get; set; }
        public DbSet<ParticipanteStatement> eStatement { get; set; }
        #endregion Database's

        #region Fields
        private readonly IConfiguration configuration;
        #endregion Fields

        /// <summary>
        public eStatementDBContext( IConfiguration config )
        {
            configuration = config;
            Database.SetCommandTimeout( 15000 );
        }

        protected override void OnConfiguring( DbContextOptionsBuilder optionsBuilder )
        {
            string connectionString = configuration[ "ConnectionStrings:ESTATEMENT" ];
            optionsBuilder           .UseSqlServer( connectionString );


        }
        /// <summary>
        ///     Add the Views used to extract data from the tables 
        /// </summary>
        /// <param name="modelBuilder">
        /// </param>
        protected override void OnModelCreating( ModelBuilder modelBuilder )
        {
            modelBuilder.Entity<AdministratorEntity>().ToTable( "vAdministratorLogin" );

            modelBuilder.Entity<AdministratorEntity>()
                .HasKey( c => new { c.administratorUUID } );

            modelBuilder.Entity<eStatementData>().ToTable( "veStatement" );

            modelBuilder.Entity<eStatementData>()
                .HasKey( c => new { c.part_id, c.plan_num, c.statementDate } );

            modelBuilder.Entity<ParticipanteStatement>().ToTable( "vGetEStatementPdf" );

            modelBuilder.Entity<ParticipanteStatement>()
             .HasKey( c => new { c.ID } );
        }
    }
}
