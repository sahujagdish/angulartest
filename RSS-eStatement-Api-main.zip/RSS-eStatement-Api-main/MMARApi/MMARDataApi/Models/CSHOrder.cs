﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using System;
    #endregion using

    public class CSHOrder
    {
        /// <summary>
        ///     Gets or Sets the Primary Key 
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///     Gets or Sets the CSH Order Number
        /// </summary>
        public string CSHOrderNbr { get; set; }

        /// <summary>
        ///     Gets or Sets the CSH Job Ticket Number
        /// </summary>
        public string JT { get; set; }

        /// <summary>
        ///    Gets or Sets the Date the production of the feed started
        /// </summary>
        public DateTime ProductionDate { get; set; }

        /// <summary>
        ///     Gets or Sets the Date of the Feed given by MassMutual
        /// </summary>
        public DateTime FeedDate { get; set; }

        /// <summary>
        ///     Gets or Sets the File that the data for the production run
        ///     can from
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        ///     Gets or Sets the Total number of participants that were produced
        /// </summary>
        public int TotalParticipants { get; set; }

        /// <summary>
        ///     Gets or Sets the  Type of feed this order is for. ie Low, High, Directship Bulk
        /// </summary>
        public Feedtype FeedTypeCD { get; set; }
    }
}
