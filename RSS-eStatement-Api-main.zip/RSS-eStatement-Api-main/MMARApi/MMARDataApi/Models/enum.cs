﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    /// <summary>
    ///     Types of output production that is
    ///     performed for MassMutual
    /// </summary>
    public enum Feedtype : short
    {
        Unknown = 0,
        LowDirect = 1,
        LowBulk = 2,
        LowPDF = 3,
        HighDirect = 4,
        HighBuil = 5,
        HighPdf = 6,
        eOnly=7
    }
}
