﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi.Models
{
    public class StatementPlan
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string PlanName1 { get; set; }
        public string PlanName2 { get; set; }
        public string LogoId { get; set; }
        public string Message1Id { get; set; }
        public string Message2Id { get; set; }
        public string Message3Id { get; set; }
        public string Message4Id { get; set; }
        public string Message5Id { get; set; }
    }

    public class ProviderPlan
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string PlanName1 { get; set; }
        public string PlanName2 { get; set; }
    }
}
