﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi.Models
{
    public class AdministratorEntity
    {
        public string administratorUUID { get; set; }
        public int providerid { get; set; }
        public string userId { get; set; }
        public string password { get; set; }
    }

    public class EStatementProvider
    {
        public int EStatementProviderId { get; set; }
        public Guid ProviderId { get; set; }
        public string SPath { get; set; }
    }

    public class AuthUser
    {
        public int clientid { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }

    public class EStatementFile
    {
        public int eStatementProviderId { get; set; }
        public int StatementOrderId { get; set; }
        public string PlanId { get; set; }
        public string ParticipantId { get; set; }
    }

    public class ProviderSettings
    {
        public Guid ProviderId { get; set; }
        public string ProviderAbbrev { get; set; }
        public string ProviderName { get; set; }
        public int? EStatementProviderId { get; set; }
        public Guid? ReportingLevelId { get; set; }
        public Guid? CustomReportingLevelId { get; set; }
        public string FTPSite { get; set; }
        public Guid? FTPLocationId { get; set; }
        public string Spath { get; set; }
        public string Powerprt { get; set; }
        public string Shname { get; set; }
        public string Shadr1 { get; set; }
        public string Shadr2 { get; set; }
        public string Shadr3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public bool Provadd { get; set; }
        public string Pname { get; set; }
        public string Padr1 { get; set; }
        public string Padr2 { get; set; }
        public string Padr3 { get; set; }
        public string Class1 { get; set; }
        public string Class2 { get; set; }
        public string Class3 { get; set; }
        public string Class4 { get; set; }
        public string Class5 { get; set; }
        public string Class6 { get; set; }
        public bool MBU { get; set; }
        public bool Ror { get; set; }
        public bool Ytdror { get; set; }
        public bool abgpg1mess { get; set; }
        public bool Noloan { get; set; }
        public bool Vestbal { get; set; }
        public bool Bold_funds { get; set; }
        public bool Smart_ben { get; set; }
        public bool Lipper { get; set; }
        public bool Units { get; set; }
        public bool abgmodel { get; set; }
        public string Bookkeeper { get; set; }
        public string Sm_cont_hd { get; set; }
        public string Sm_acct_hd { get; set; }
        public bool Feediscl { get; set; }
        public string Modelhead { get; set; }
        public bool abgflag { get; set; }
        public bool Indices { get; set; }
        public bool Loandisp { get; set; }
        public bool Smart_plm { get; set; }
        public bool Expenses { get; set; }
        public bool Sourcedet { get; set; }
        public bool Dist { get; set; }
        public bool Srctotals { get; set; }
        public string Rebatename { get; set; }
        public short? Expdisplay { get; set; }
        public string Header2 { get; set; }
        public bool Expratio { get; set; }
        public bool BoldFunds { get; set; }
        public bool Demography { get; set; }
        public bool TickerFlag { get; set; }
        public int? Smart_mes { get; set; }
        public int? Smart_pg2 { get; set; }
        public int? Smart_acc { get; set; }
        public int? Smart_acc2 { get; set; }
        public int? Smart_all { get; set; }
        public int? Smart_all2 { get; set; }
        public short? ProofNum { get; set; }
        public bool GetProofParsFromFile { get; set; }
        public bool GetProofParsFromFeed { get; set; }
        public bool EStatement { get; set; }
        public bool ENotify { get; set; }
        public bool EAutoReg { get; set; }
        public bool UseBadAddresses { get; set; }
        public bool CanUseLicensedIndices { get; set; }
        public bool IsEnvelopeSealedSponsor { get; set; }
        public bool IsEnvelopeSealedProvider { get; set; }
        public short? ProductionDays { get; set; }
        public bool AreAllDaysUsedFromProductionTime { get; set; }
        public bool NoSpace { get; set; }
        public bool EdArt { get; set; }
        public bool RebalDate { get; set; }
        public bool IsPerformanceMasked { get; set; }
        public bool IsSMRCreated { get; set; }
        public bool IsParticipantDataInSMR { get; set; }
        public bool IsUsingDSTPerformance { get; set; }
        public bool IsUsingCustomFunds { get; set; }
        public bool IsFundPerformanceUsed { get; set; }
        public bool IsStatementTypeUsed { get; set; }
        public string Header1 { get; set; }
        public string Header1a { get; set; }
        public int? NewClass { get; set; }
        public bool IsBadAddressReportUsed { get; set; }
        public bool IsBadAllocationReportUsed { get; set; }
        public bool IsNoActivityReportUsed { get; set; }
        public bool IsAuditReportUsed { get; set; }
        public short? ProductionDelay { get; set; }
        public short eStatementQuarters { get; set; }

    }

    public class StatementExtract
    {
        public int EStatementExtractId { get; set; }
        public Guid ProviderId { get; set; }
        public Guid DataFeedid { get; set; }
        public string FeedName { get; set; }
        public string StatementType { get; set; }
        public string AssociatedPlans { get; set; }
        public DateTime AddedDttm { get; set; }
        public DateTime ApprovalDttm { get; set; }
    }

    public class StatementExtractOrder
    {
        // Properties
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int StatementOrderId { get; set; }
        public Guid OutputFileName { get; set; }
        public int EStatementExtractId { get; set; }
        public string JT_NUM { get; set; }
        public int? PlanCount { get; set; }
        public int? ParticipantCount { get; set; }
        public byte? ExtractProcessingTypeCD { get; set; }
        public int? TotalPageCount { get; set; }
        public int? TotalBadAddresses { get; set; }
    }

    public class StatementExtractOrderParticipant
    {
        // Properties
        public int ID { get; set; }
        public int StatementOrderId { get; set; }
        public string PlanId { get; set; }
        public string ParticipantId { get; set; }
        public string OutputFileName { get; set; }
        public short StatementQuarter { get; set; }
        public short StatementYear { get; set; }
        public string ReferenceID { get; set; }
        public bool HasActiveEmail { get; set; }
        public bool? IsEmailSent { get; set; }
        public DateTime? EmailProcessingDttm { get; set; }
    }

    public class ParticipanteStatement
    {
        // Properties
        public int ID { get; set; }
        public byte[] eStatementPdf { get; set; }
    }

    public class eStatementData
    {
        public int providerid { get; set; }
        public string provid { get; set; }
        public string part_id { get; set; }
        public string plan_num { get; set; }
        public string plan_name { get; set; }
        public string spon_num { get; set; }
        public DateTime statementDate { get; set; }
        public int? statementId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public Guid uid { get; set; }


    }

    public class eStatement
    {
        public string part_id { get; set; }
        public string plan_num { get; set; }
        public string plan_name { get; set; }
        public DateTime statementDate { get; set; }
        public int? statementId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public Guid uid { get; set; }
    }

    public class MultipleEStatments
    {
        public bool isonefile { get; set; }
        public bool isftped { get; set; }
        public List<string> eStatementIDs { get; set; }
    }

    public enum StatementReportFileType
    {
        [StatementReportTypeAttribute( @"text/plain", @"daud", "txt", 2 )]
        Audit = 1,

        [StatementReportTypeAttribute( @"text/plain", @"badad", "txt", 3 )]
        BadAddress = 2,

        [StatementReportTypeAttribute(@"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", @"badalloc", "xlsx", 4)]
        BadAllocation = 3,

        [StatementReportTypeAttribute(@"text/plain", @"badparts", "txt", 5)]        
        NoActivity = 4,

        [StatementReportTypeAttribute( @"application/pdf", @"", "pdf", 1 )]
        Proof = 5,
    }

}