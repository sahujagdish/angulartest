﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi.Models
{
    public class ProviderLevelLogo
    {
        [Key]
        public Guid ProviderId { get; set; }
        public string LogoId { get; set; }
    }

    public class ProviderLogo
    {
        public Guid ProviderId { get; set; }
        public string LogoId { get; set; }
        public string Thumbnail { get; set; }
    }

    public class PlanLogo
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string LogoId { get; set; }
    }
}
