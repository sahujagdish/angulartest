﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi.Models
{
    public class ProviderMessage
    {
        
        public Guid ProviderId { get; set; }
        public string MessageName { get; set; }
        public string MessageId { get; set; }
        public string CompusetMessage { get; set; }
        public string OriginalMessage { get; set; }
    }

    public class PlanMessage
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanID { get; set; }
        public string MessageId { get; set;  }
        public short MessageLocation { get; set; }
    }

    public class NewMessage
    {
        public string Message { get; set; }
    }
}
