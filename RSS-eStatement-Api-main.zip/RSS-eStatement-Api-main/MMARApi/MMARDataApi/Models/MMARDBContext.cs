﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    #endregion using

    public class MMARDBContext : DbContext
    {
        public DbSet<FeedStatistics> FeedStatistics { get; set; }

        public DbSet<FeedStatistics2> FeedStatistics2s { get; set; }

        public DbSet<CSHOrder> CSHOrder { get; set; }

        public DbSet<ParticipantCommunication> ParticipantCommunications { get; set; }

        private IConfiguration configuration;

        /// <summary>
        ///     Constructor
        /// </summary>
        public MMARDBContext( IConfiguration config )
        {
            configuration = config;
            Database.SetCommandTimeout( 15000 );
        }

        protected override void OnConfiguring( DbContextOptionsBuilder optionsBuilder )
        {
            string connectionString = configuration[ "ConnectionStrings:MMAR" ];
            optionsBuilder
                .UseSqlServer( connectionString ); 
        }

        /// <summary>
        ///     Add the Views used to extract data from the tables 
        /// </summary>
        /// <param name="modelBuilder">
        /// </param>
        protected override void OnModelCreating( ModelBuilder modelBuilder )
        {
            modelBuilder.Entity<FeedStatistics>().ToTable( "vFeedStatistics" );
            modelBuilder.Entity<FeedStatistics2>().ToTable( "vFeedStatistics2" );
            modelBuilder.Entity<CSHOrder>().ToTable( "vCSHOrder" );
            modelBuilder.Entity<ParticipantCommunication>().ToTable( "vParticipantCommunication" );
        }
    }
}
