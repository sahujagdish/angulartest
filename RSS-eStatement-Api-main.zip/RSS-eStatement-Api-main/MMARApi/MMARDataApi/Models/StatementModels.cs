﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi.Models
{
    public class StatementExtractReport
    {
        public int EStatementExtractID { get; set; }
        public string ReportName { get; set; }
        public DateTime ReportDate { get; set; }
        public byte StatementExtractReportTypeCD { get; set; }
    }

    public class StatementExtractReportReport
    {
        public int EStatementExtractID { get; set; }

        public string ReportName { get; set; }

        public byte[] Report { get; set; }

        public byte StatementExtractReportTypeCD { get; set; }
    }


    public class ProviderENotifySettings
    {
        public Guid ProviderId { get; set; }
        public string Fromaddr { get; set; }
        public string Fromname { get; set; }
        public string EMailSubject { get; set; }
        public string EmailBody { get; set; }
        public string? Replyaddr { get; set; }
        public string? Replyname { get; set; }
        public int? EmailBatchSize { get; set; }
        public int? HoursBetweenBatch { get; set; }
        public bool? AreEmailSentOnWeekendHoliday { get; set; } = false;
        public bool? IsSundaySkipped { get; set; } = false;
        public bool? IsMondaySkipped { get; set; } = false;
        public bool? IsTuesdaySkipped { get; set; } = false;
        public bool? IsWednesDaySkipped { get; set; } = false;
        public bool? IsThursdaySkipped { get; set; } = false;
        public bool? IsFridaySkipped { get; set; } = false;
        public bool? IsSaturdaySkipped { get; set; } = false;
    }

    /// <summary>
    ///     
    /// </summary>
    public enum PlanEnotifyOverrideType
    {
        emailbody = 1,
        fromaddress = 2,
        fromname = 3,
        replyaddress = 4,
        replyname = 5,
        emailsubject = 6
    }

    public class PlanEnotifyOverrideSettings
    {
        public Guid ProviderId { get; set; }
        public string ExternalPlanId { get; set; }
        public string Content { get; set; }
        public byte PlanEnotifyOverrideTypeCD { get; set; }
    }

}

