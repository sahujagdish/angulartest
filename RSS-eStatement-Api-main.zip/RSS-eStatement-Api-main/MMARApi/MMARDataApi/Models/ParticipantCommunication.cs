﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using System;
    using System.ComponentModel.DataAnnotations;
    #endregion using

    public class ParticipantCommunication
    {
        /// <summary>
        ///     Gets or Sets the Contract Number for the given participant
        /// </summary>
        public string ContractNo { get; set; }

        /// <summary>
        ///     Gets or Sets the Participants First Name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        ///     Gets or Sets the Participants Last Name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        ///     Gets or Sets the participant identifier which is the 
        ///     las 4 digits of the SSN
        /// </summary>
        public string ParID { get; set; }

        /// <summary>
        ///     Gets or Sets the identifier used to process through the CSH
        ///     ordering system
        /// </summary>
        [Key]
        public Guid CSHParID { get; set; }

        /// <summary>
        ///     Gets or Sets the external plan identifier
        /// </summary>
        public string PlanId { get; set; }

        /// <summary>
        /// Gets or Sets the plan name
        /// </summary>
        public string PlanName { get; set; }

        /// <summary>
        ///     Gets or Sets the type of communication produced. This is the code
        ///     given by MassMurual
        /// </summary>
        public string CommunicationType { get; set; }

        /// <summary>
        ///     Gets or Sets the MassMutual order identifier
        /// </summary>
        public int OrderId { get; set; }
    }
}
