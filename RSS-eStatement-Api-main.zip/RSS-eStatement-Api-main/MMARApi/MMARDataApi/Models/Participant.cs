﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using System;
    using System.Collections.Generic;
    #endregion using

    public class Participant
    {
        /// <summary>
        ///     Gets or Sets the Participants First Name
        /// </summary>
        public string fname { get; set; }

        /// <summary>
        ///     Gets or Sets the Participants Last Name
        /// </summary>
        public string lname { get; set; }

        /// <summary>
        ///     Gets or Sets the Participants Last 4 digits of SSN
        /// </summary>
        public string id { get; set; }

        /// <summary>
        ///     Gets or Sets the List of all communications for the participant
        /// </summary>
        public List<Communication> communications { get; set; }
    }

    public class Communication
    {
        /// <summary>
        ///     Gets or Sets the Plan Name the communication is fo
        /// </summary>
        public string planName { get; set; }

        /// <summary>
        ///     Gets or Sets the Date the communication was for - this is the Feed Date
        /// </summary>
        public DateTime date { get; set; }

        /// <summary>
        ///     Gets or Sets the Identifier for the PDF stored on disk
        /// </summary>
        public string pdf { get; set; }

        /// <summary>
        ///     Gets or Sets the MassMutual Internal order identifier
        /// </summary>
        public int orderId { get; set; }
    }
}
