﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace MMARDataApi.Models
{
    #region using
    using System;
    #endregion using

    public class FeedStatistics2
    {
        /// <summary>
        ///     Primary Key
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///     Date of the Feed given by MassMutual
        /// </summary>
        public DateTime FeedDate { get; set; }

        /// <summary>
        ///     Gets or Sets the Total Low communications produced excluding
        ///     any OPP communications
        /// </summary>
        public int TotalLow { get; set; }

        /// <summary>
        ///     Gets or Sets the B2P Total Low communications produced excluding
        ///     any OPP communications
        /// </summary>
        public int B2PTotalLow
        {
            get; set;
        }

        /// <summary>
        ///     Gets or Sets the Total low OPP communications produced
        /// </summary>
        public int TotalLowOpp { get; set; }

        /// <summary>
        ///     Gets or Sets the B2P Total low OPP communications produced
        /// </summary>
        public int B2PTotalLowOpp
        {
            get; set;
        }

        /// <summary>
        ///     Gets or Sets the Total HIgh communications produced
        /// </summary>
        public int TotalHigh { get; set; }

        /// <summary>
        ///     Gets or Sets the B2P Total HIgh communications produced
        /// </summary>
        public int B2PTotalHigh
        {
            get; set;
        }

        /// <summary>
        ///    Gets or Sets the Total PDF only communications produced
        /// </summary>
        public int TotalEOnly { get; set; }

        /// <summary>
        ///    Gets or Sets the B2P Total PDF only communications produced
        /// </summary>
        public int B2PTotalEOnly
        {
            get; set;
        }
    }
}
