﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MMARDataApi
{
    public class YearQuarter
    {
        public int Year { get; private set; }
        public int Quarter { get; private set; }

        private YearQuarter() { }

        private YearQuarter(int year, int quarter)
        {
            this.Year = year;
            this.Quarter = quarter;
        }

        public static YearQuarter FromDate(DateTime date)
        {
            int[] quarters = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4 };
            var q = new YearQuarter();
            q.Quarter = quarters[date.Month - 1];
            q.Year = date.Year;
            return q;
        }

        public override string ToString()
        {
            return string.Format("{0}-{1}", Year, Quarter);
        }

        public DateTime BegOfQuarter
        {
            get { return new DateTime(Year, (3 * Quarter) - 2, 1); }
        }

        // The beginning of the next quarter is the exclusive end for this quarter.
        // If you want the inclusive end of this quarter, this is one way depending upon your desired precision of seconds.
        public DateTime EndOfQuarter
        {
            get
            {
                return NextQuarter.BegOfQuarter.AddMilliseconds(-1);
            }
        }

        public YearQuarter NextQuarter
        {
            get
            {
                var y = Year;
                var q = Quarter + 1;
                if (q == 5)
                {
                    q = 1;
                    y++;
                }
                return new YearQuarter(y, q);
            }
        }

        public YearQuarter PreviousQuarter
        {
            get
            {
                var y = Year;
                var q = Quarter - 1;
                if (q == 0)
                {
                    q = 4;
                    y--;
                }
                return new YearQuarter(y, q);
            }
        }

        public IList<YearQuarter> GetPreviousQuarters(int count)
        {
            var list = new List<YearQuarter>();

            var quarter = this;

            for (var i = 0; i < count; i++)
            {
                quarter = quarter.PreviousQuarter;
                list.Add(quarter);
            }

            list.Reverse();

            return list;
        }

        public IList<YearQuarter> GetNextQuarters(int count)
        {
            var list = new List<YearQuarter>();

            var quarter = this;

            for (var i = 0; i < count; i++)
            {
                quarter = quarter.NextQuarter;
                list.Add(quarter);
            }

            return list;
        }

    }
}
