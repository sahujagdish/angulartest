﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace Settings
{
    #region using
    using System.Collections;
    using Newtonsoft.Json.Linq;
    #endregion using

    public class JsonInOrderIterator : IEnumerable
    {
        #region Fields
        private readonly JObject _root;
        #endregion Fields

        #region Public Methods
        public JsonInOrderIterator( JObject root )
        {
            _root = root;
        }

        public IEnumerator GetEnumerator()
        {
            foreach( var item in DoObject( _root ) )
            {
                yield return item;
            }
        }
        #endregion Public Methods

        #region Private Methods
        private IEnumerable DoObject( JObject obj )
        {
            foreach( JProperty prop in obj.Properties() )
            {
                foreach( var item in doProperty( prop ) )
                {
                    yield return item;
                }
            }
        }

        private IEnumerable doArray( JArray ary )
        {
            foreach( JToken value in ary.Values() )
            {
                if( value.Type == JTokenType.Property )
                {
                    foreach( var item in doProperty( value as JProperty ) )
                    {
                        yield return item;
                    }
                }
                else
                {
                    yield return value;
                }
            }
        }

        private IEnumerable doProperty( JProperty prop )
        {
            var value = prop.Value;
            if( value.Type == JTokenType.Object )
            {
                foreach( var res in DoObject( value as JObject ) )
                {
                    yield return res;
                }
            }
            else if( value.Type == JTokenType.Array )
            {
                foreach( var res in doArray( value as JArray ) )
                {
                    yield return res;
                }
            }
            else
            {
                yield return value;
            }
        }
        #endregion Private Methods
    }
}

