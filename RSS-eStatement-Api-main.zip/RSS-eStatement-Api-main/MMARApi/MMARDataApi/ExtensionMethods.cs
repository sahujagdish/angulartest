﻿

namespace MMARDataApi
{
    #region using
    using System.Text.RegularExpressions;
    #endregion using
    public static class ExtensionMethods
    {
        /// <summary>
        ///     Tells if the given string matches the given wildcard.
        ///     Two wildcards are allowed: '*' and '?'
        ///     '*' matches 0 or more characters
        ///     '?' matches any character
        /// </summary>
        /// <param name="wildcard">
        ///     The wildcard.
        /// </param>
        /// <param name="s">
        ///     The s.
        ///  </param>
        /// <param name="ignoreCase">
        ///     if set to <c>true</c> [ignore case].
        /// </param>
        /// <returns>
        ///     Indiator of a match
        /// </returns>
        public static bool WildcardMatch( this string wildcard, string s, bool ignoreCase = false )
        {
            return WildcardMatch( wildcard, s, 0, 0, ignoreCase );
        }

        /// <summary>
        ///     Internal matching algorithm.
        /// </summary>
        /// <param name="wildcard">
        ///     The wildcard.
        /// </param>
        /// <param name="s">
        ///     The s.
        /// </param>
        /// <param name="wildcardIndex">
        ///     Index of the wildcard.
        /// </param>
        /// <param name="sIndex">
        ///     Index of the s.
        ///  </param>
        /// <param name="ignoreCase">
        ///     if set to <c>true</c> [ignore case].
        /// </param>
        /// <returns>
        ///     Indicator of a match
        /// </returns>
        private static bool WildcardMatch( this string wildcard, string s, int wildcardIndex, int sIndex, bool ignoreCase )
        {

            string wildCardPattern = "^" + Regex.Escape( s ).Replace( "\\*", ".*" );
            wildCardPattern = wildCardPattern.Replace( "\\?", "." ) + "$";

            Regex patternMatch = new Regex( wildCardPattern, ignoreCase ? RegexOptions.IgnoreCase : RegexOptions.None );
            return patternMatch.IsMatch( wildcard );
        }
    }
}
