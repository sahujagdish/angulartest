﻿/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2018 by DST Systems, Inc.
*   All Rights Reserved.
*/

namespace Settings
{
    #region using
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using Newtonsoft.Json.Linq;
    using Microsoft.Extensions.Configuration;
    #endregion using

    public class EncryptedConfigurationProvider : ConfigurationProvider
    {
        EncryptedConfigurationSource _source;
        public EncryptedConfigurationProvider( EncryptedConfigurationSource source )
        {
            _source = source;
        }

        public override void Load()
        {
            if( !File.Exists( _source.JsonFilePath ) )
                return;
            var jsonRoot = JObject.Parse( File.ReadAllText( _source.JsonFilePath ) );
            string keyPath = _source.GetEncryptionKeyPath( jsonRoot );
            if( String.IsNullOrEmpty( keyPath ) )
                return; // no encryption is to be done on this file
            Aes aes = _source.GetEncryptionAlgorithm( keyPath );

            if( !File.Exists( _source.EncryptedFilePath ) )
                throw new Exception( "Encryption file not found at given path." );

            JObject encJsonRoot = _source.GetEncryptedContents( File.ReadAllBytes( _source.EncryptedFilePath ), aes );
            foreach( JToken item in new JsonInOrderIterator( encJsonRoot ) )
            {
                if( item.Parent.Type != JTokenType.Property )
                    continue;
                var prop = item.Parent as JProperty;
                Data[ prop.Name ] = prop.Value.ToString();
            }
        }
    }
}