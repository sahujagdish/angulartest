using System;
using System.IO;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using MMARDataApi.Controllers;
using MMARDataApi.Models;
using NUnit.Framework;
using Settings;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Swashbuckle.SwaggerUi;
using System.Linq;
using MMARDataApi;
using Microsoft.AspNetCore.Razor.Language.Extensions;

namespace TestApi
{
    public class Tests
    {
        #region Fields
        private StatementController statementController;
        private IConfigurationRoot configuration;

        #endregion Fields

         [ SetUp]
        public void Setup()
        {
            var builder = new ConfigurationBuilder()
             .SetBasePath( Directory.GetCurrentDirectory() )
             .AddJsonFile( "appsettings.json", optional: true, reloadOnChange: true )
             .AddEncryptedAndJsonFiles( $"appsettings.dev.json", Directory.GetCurrentDirectory(), optional: true, reloadOnChange: true );

            builder.AddEnvironmentVariables();

            configuration = builder.Build();
            IMemoryCache cache = new MemoryCache( new MemoryCacheOptions() );

            var loggerFactory = LoggerFactory.Create( builder => builder.AddConsole() );

            var logger = loggerFactory.CreateLogger<StatementController>();

            statementController = new StatementController( configuration, cache, logger );
        }

        /// <summary>
        ///     Test Getting Proof File Date
        /// </summary>
        [Test]
        public void TestGetStatementProofFileDate()
        {
            var result = statementController.GetStatementProofFileDate( 2900 );

            //((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode
            Assert.IsNotNull( result.Result.ToString() );

            result = statementController.GetStatementProofFileDate( 2900 );
        }

        /// <summary>
        ///     Gets Getting Statement Extract Reports by report type
        /// </summary>
        [Test]
        public void TestGetStatementReport()
        {
            var result = statementController.GetStatementReport( 0, StatementReportFileType.Audit );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode );

            result = statementController.GetStatementReport( 0, StatementReportFileType.BadAddress );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode );

            result = statementController.GetStatementReport( 0, StatementReportFileType.BadAllocation );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode );

            result = statementController.GetStatementReport( 0, StatementReportFileType.NoActivity );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode );

            int extractId = 0;

            using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
            {
                extractId = context.StatementExtractReport.ToList().GroupBy( g => g.EStatementExtractID ).Where( w=> w.Count() == 4 ).First().Key;
            }

            result = statementController.GetStatementReport( extractId, StatementReportFileType.Audit );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            Assert.AreEqual( "RanToCompletion", result.Status.ToString() );

            result = statementController.GetStatementReport( extractId, StatementReportFileType.BadAddress );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            Assert.AreEqual( "RanToCompletion", result.Status.ToString() );

            result = statementController.GetStatementReport( extractId, StatementReportFileType.BadAllocation );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            Assert.AreEqual( "RanToCompletion", result.Status.ToString() );

            result = statementController.GetStatementReport( extractId, StatementReportFileType.NoActivity );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            Assert.AreEqual( "RanToCompletion", result.Status.ToString() );
        }

        /// <summary>
        ///     Get all the Statement Reports for a particular extract
        /// </summary>
        [Test]
        public void TestGetStatementExtractReports()
        {
            var result = statementController.GetStatementExtractReports( 0 );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.StatusCodeResult)result.Result).StatusCode );

            int extractId = 0;

            using ( StatementsDBContext context = new StatementsDBContext( configuration ) )
            {
                extractId = context.StatementExtractReport.ToList().GroupBy( g => g.EStatementExtractID ).Where( w => w.Count() == 4 ).First().Key;
            }

            result = statementController.GetStatementExtractReports( extractId );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );
            Assert.AreEqual( 4, ((List<StatementReportFileType>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count );

            result = statementController.GetStatementExtractReports( extractId );

            Assert.IsNotNull( result.Result.ToString() );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );
            Assert.AreEqual( 4, ((List<StatementReportFileType>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count );   
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestGetProviderENotifySettings()
        {
            var result = statementController.GetProviderENotificationSettings( 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );
            
            result = statementController.GetProviderENotificationSettings( 63 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            ProviderENotifySettings settings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value;

            Assert.AreEqual( new Guid( "59A3141C-385F-423A-A081-1860F419E9D2" ), settings.ProviderId );

            string emailBody = settings.EmailBody;

            // Test Saving new email body

            var newEmailBody = statementController.PutProviderENotificationEmailBody( 63, $"Unit Test email body - here is the original {emailBody}" );

            Assert.IsNotNull( newEmailBody );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), newEmailBody.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)newEmailBody.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)newEmailBody.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            ProviderENotifySettings saveSettings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)newEmailBody.Result).Value;

            Assert.AreEqual( saveSettings.EmailBody, $"Unit Test email body - here is the original {emailBody}" );

            // revert back the email settings

            var originalEmailBody = statementController.PutProviderENotificationEmailBody( 63, emailBody );
            Assert.IsNotNull( originalEmailBody );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), originalEmailBody.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)originalEmailBody.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)originalEmailBody.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            ProviderENotifySettings originalSettings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)originalEmailBody.Result).Value;
            Assert.AreEqual( emailBody, originalSettings.EmailBody );

            result = statementController.GetProviderENotificationSettings( 63 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            settings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value;
            Assert.AreEqual( emailBody, settings.EmailBody );

        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestPutProviderENotifySettings()
        {
            var result = statementController.GetProviderENotificationSettings( 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetProviderENotificationSettings( 63 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            ProviderENotifySettings settings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value;

            ProviderENotifySettings modifiedSettings = new ProviderENotifySettings
            {
                ProviderId = settings.ProviderId,
                Fromaddr = settings.Fromaddr,
                Fromname = settings.Fromname,
                EMailSubject = settings.EMailSubject,
                EmailBody = settings.EmailBody,
                Replyaddr = settings.Replyaddr,
                Replyname = settings.Replyname,
                EmailBatchSize = settings.EmailBatchSize,
                HoursBetweenBatch = settings.HoursBetweenBatch,
                AreEmailSentOnWeekendHoliday = settings.AreEmailSentOnWeekendHoliday,
                IsSundaySkipped = settings.IsSundaySkipped,
                IsMondaySkipped = settings.IsMondaySkipped,
                IsTuesdaySkipped = settings.IsTuesdaySkipped,
                IsWednesDaySkipped = settings.IsWednesDaySkipped,
                IsThursdaySkipped = settings.IsThursdaySkipped,
                IsFridaySkipped = settings.IsFridaySkipped,
                IsSaturdaySkipped = settings.IsSaturdaySkipped
            };

            modifiedSettings.Fromaddr = $"Unit Test: {settings.Fromaddr}";
            modifiedSettings.EMailSubject = $"Unit Test: {settings.EMailSubject}";

            var updateResult = statementController.PutProviderENotificationSettings( 63, modifiedSettings );

            Assert.IsNotNull( updateResult );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), updateResult.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            ProviderENotifySettings usettings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).Value;

            Assert.AreEqual( modifiedSettings.Fromaddr, usettings.Fromaddr );
            Assert.AreEqual( modifiedSettings.EMailSubject, usettings.EMailSubject );
            Assert.AreEqual( $"Unit Test: {settings.Fromaddr}", usettings.Fromaddr );
            Assert.AreEqual( $"Unit Test: {settings.EMailSubject}", usettings.EMailSubject );

            updateResult = statementController.PutProviderENotificationSettings( 63, settings );

            Assert.IsNotNull( updateResult );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), updateResult.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            usettings = (ProviderENotifySettings)((Microsoft.AspNetCore.Mvc.ObjectResult)updateResult.Result).Value;

            Assert.AreEqual( settings.Fromaddr, usettings.Fromaddr );
            Assert.AreEqual( settings.EMailSubject, usettings.EMailSubject );

        }

        /// <summary>
        ///     TEst addubg Plans eNotify Settings
        /// </summary>
        [Test]
        public void TestPutPlanENotifySettings()
        {
            var result = statementController.GetProviderENotificationSettings( 63 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( ProviderENotifySettings ) );

            result = statementController.PutPlan( 63, "Scott", "Scott", "Scott" );
            result = statementController.PostPlan( 63, "Scott", "Scott", "Scott" );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody, "Email Plan Body Plan Test" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody, "Email Plan Body Plan Test" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.ConflictObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 409, ((Microsoft.AspNetCore.Mvc.ConflictObjectResult)result.Result).StatusCode );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody, "Email Plan Body Plan Test" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody, "Email Plan Body Plan Test" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody, "Put Email Plan Body Plan Test" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );

            result = statementController.GetPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );
            Assert.AreEqual( "Put Email Plan Body Plan Test", ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).Value );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.emailbody );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );


            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress, "do_not_reply@dstsystems.com" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress, "do_not_reply@dstsystems.com" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.ConflictObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 409, ((Microsoft.AspNetCore.Mvc.ConflictObjectResult)result.Result).StatusCode );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress, "do_not_reply@dstsystems.com" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress, "do_not_reply@dstsystems.com" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress, "PUT_do_not_reply@dstsystems.com" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );

            result = statementController.GetPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );
            Assert.AreEqual( "PUT_do_not_reply@dstsystems.com", ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).Value );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromaddress );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname, "S�amus Pottery" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname, "S�amus Pottery" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.ConflictObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 409, ((Microsoft.AspNetCore.Mvc.ConflictObjectResult)result.Result).StatusCode );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname, "S�amus Pottery" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );
            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            result = statementController.PostPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname, "S�amus Pottery" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.CreatedResult ), result.Result.GetType() );
            Assert.AreEqual( 201, ((Microsoft.AspNetCore.Mvc.CreatedResult)result.Result).StatusCode );

            result = statementController.PutPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname, "PUT_S�amus Pottery" );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );

            result = statementController.GetPlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).StatusCode );
            Assert.AreEqual( "PUT_S�amus Pottery", ((Microsoft.AspNetCore.Mvc.OkObjectResult)result.Result).Value );

            result = statementController.DeletePlanENotificationOverrideSetting( 63, "Scott", PlanEnotifyOverrideType.fromname );
            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );

            result = statementController.DeletePlan( 63, "Scott" );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.OkResult)result.Result).StatusCode );
        }

        [Test]
        public void TestGetProviderEStatements()
        {
            var result = statementController.GetProviderEStatements( 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];
            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        [Test]
        public void TestGetProviderEStatementsByDate()
        {
            var result = statementController.GetProviderEStatementsByDate( 0, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetProviderEStatementsByDate( 126, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter =  YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatementsByDate( 126, quarter.PreviousQuarter.EndOfQuarter );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];
            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestGetParticipantsEStatements()
        {
            var result = statementController.GetParticipantsEStatements( 0, Guid.NewGuid() );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetParticipantsEStatements( 126, Guid.NewGuid() );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetParticipantsEStatements( 126, eStatement.uid );

             eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        [Test]
        public void TestGetParticipantsCombinedEStatementsByDates()
        {
            var result = statementController.GetParticipantsCombinedEStatementsByDates( 0, string.Empty, Guid.Empty, new List<DateTime>() { DateTime.Now },false );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantsCombinedEStatementsByDates( 126, string.Empty, Guid.Empty, new List<DateTime>() { DateTime.Now }, false );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 63 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Where( x => x.statementId != null ).FirstOrDefault();

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );

            result = statementController.GetParticipantsCombinedEStatementsByDates( 63, eStatement.plan_num, eStatement.uid, new List<DateTime>() { DateTime.Now }, false );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantsCombinedEStatementsByDates( 63, eStatement.plan_num, eStatement.uid, new List<DateTime>() { eStatement.statementDate }, false );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            string downloadname = $"{eStatement.statementDate.ToString( "yyyyMMdd" )}-{eStatement.uid}.pdf";
            Assert.AreEqual( downloadname, ((Microsoft.AspNetCore.Mvc.FileContentResult)result.Result).FileDownloadName );
            Assert.Greater( ((Microsoft.AspNetCore.Mvc.FileContentResult)result.Result).FileContents.Length, 0 );
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestGetParticipantsEStatementsByDate()
        {
            var result = statementController.GetParticipantsEStatementsByDate( 0, Guid.NewGuid(), DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantsEStatementsByDate( 126, Guid.NewGuid(), DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetParticipantsEStatementsByDate( 126, eStatement.uid, eStatement.statementDate );

            eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestGetPlansEStatements()
        {
            var result = statementController.GetPlansEStatements( 0, string.Empty );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetPlansEStatements( 126, string.Empty );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetPlansEStatements( 126, eStatement.plan_num );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        /// <summary>
        /// 
        /// </summary>
        [Test]
        public void TestGetPlansEStatementsByDate()
        {
            var result = statementController.GetPlansEStatementsByDate( 0, string.Empty, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetPlansEStatementsByDate( 126, string.Empty, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetPlansEStatementsByDate( 126, eStatement.plan_num, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetPlansEStatementsByDate( 126, eStatement.plan_num, eStatement.statementDate );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }

        /// <summary>
        ///     
        /// </summary>
        [Test]
        public void TestGetParticipantPlansEStatements()
        {
            var result = statementController.GetParticipantPlansEStatements( 0, string.Empty, Guid.Empty );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetParticipantPlansEStatements( 126, string.Empty, Guid.Empty);

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetParticipantPlansEStatements( 126, eStatement.plan_num, Guid.Empty );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantPlansEStatements( 126, eStatement.plan_num, eStatement.uid );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }
    
        /// <summary>
        ///     
        /// </summary>
        [Test]
        public void TestGetParticipantPlansEStatementsbyDate()
        {
            var result = statementController.GetParticipantPlansEStatementsbyDate( 0, string.Empty, Guid.Empty, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantPlansEStatementsbyDate( 126, string.Empty, Guid.Empty, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 107 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            result = statementController.GetParticipantPlansEStatementsbyDate( 126, eStatement.plan_num, Guid.Empty, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantPlansEStatementsbyDate( 126, eStatement.plan_num, eStatement.uid, DateTime.Now );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetParticipantPlansEStatementsbyDate( 107, eStatement.plan_num, eStatement.uid, eStatement.statementDate );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            eStatement = ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value)[0];

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
        }


        /// <summary>
        ///     Test getting and eStatement
        /// </summary>
        [Test]
        public void TestGetEStatement()
        {
            var result = statementController.GetEStatement( 0, string.Empty, Guid.Empty, DateTime.Now, 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetEStatement( 126, string.Empty, Guid.Empty, DateTime.Now, 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            YearQuarter quarter = YearQuarter.FromDate( DateTime.Now );
            result = statementController.GetProviderEStatements( 126 );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.OkObjectResult ), result.Result.GetType() );
            Assert.AreEqual( 200, ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).StatusCode );

            Assert.IsTrue( ((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value.GetType() == typeof( List<eStatement> ) );
            Assert.Greater( ((List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Count(), 0 );

            eStatement eStatement = ( (List<eStatement>)((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value).Where( x => x.statementId != null ).FirstOrDefault();

            Assert.IsNotEmpty( eStatement.firstname );
            Assert.IsNotEmpty( eStatement.lastname );
            Assert.IsNotEmpty( eStatement.part_id );
            Assert.IsNotEmpty( eStatement.plan_name );
            Assert.IsNotEmpty( eStatement.plan_num );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.statementDate );
            Assert.IsNotNull( eStatement.uid );
            
            result = statementController.GetEStatement( 126, eStatement.plan_num, Guid.Empty, DateTime.Now, 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetEStatement( 126, eStatement.plan_num, eStatement.uid, DateTime.Now, 0 );

            Assert.AreEqual( 400, ((Microsoft.AspNetCore.Mvc.BadRequestObjectResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.BadRequestObjectResult ), result.Result.GetType() );

            result = statementController.GetEStatement( 126, eStatement.plan_num, eStatement.uid, eStatement.statementDate, 0 );

            Assert.AreEqual( 404, ((Microsoft.AspNetCore.Mvc.NotFoundResult)result.Result).StatusCode );

            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.NotFoundResult ), result.Result.GetType() );

            result = statementController.GetEStatement( 126, eStatement.plan_num, eStatement.uid, eStatement.statementDate, (int)eStatement.statementId );

            Assert.IsNotNull( result );
            Assert.AreEqual( typeof( Microsoft.AspNetCore.Mvc.FileContentResult ), result.Result.GetType() );
            string downloadname =  $"{eStatement.statementDate.Year}-Q{YearQuarter.FromDate( eStatement.statementDate ).Quarter}-{eStatement.plan_num.Replace( "ABGH", string.Empty )}.pdf";
            Assert.AreEqual( downloadname, ((Microsoft.AspNetCore.Mvc.FileContentResult)result.Result).FileDownloadName );
            Assert.Greater( ((Microsoft.AspNetCore.Mvc.FileContentResult)result.Result).FileContents.Length, 0 );
        }
    }
}
