﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;

namespace Statements
{
    public class DataApi
    {
        private const int initialCapacity = 1024;
        private static Hashtable connectStrings = new Hashtable();

        private DataApi()
        {
        }

        public static DataTable FilterSort(DataTable dtToSort, string filter, string sort)
        {
            DataTable dataTable = dtToSort.Clone();
            foreach (DataRow row in dtToSort.Select(filter, sort))
                dataTable.ImportRow(row);
            return dataTable;
        }

        public static DataSet FilterSort(
          DataSet dsToSort,
          string tableName,
          string filter,
          string sort)
        {
            DataTable table = dsToSort.Tables[tableName];
            DataTable dataTable = DataApi.FilterSort(table, filter, sort);
            dsToSort.EnforceConstraints = false;
            table.Rows.Clear();
            for (int index = 0; index < dataTable.Rows.Count; ++index)
                table.ImportRow(dataTable.Rows[index]);
            dsToSort.EnforceConstraints = true;
            return dsToSort;
        }

        public static DataSet FilterSort(
          DataSet dsToSort,
          int tableIndex,
          string filter,
          string sort)
        {
            return DataApi.FilterSort(dsToSort, dsToSort.Tables[tableIndex].TableName, filter, sort);
        }

        public static int GetRowIndex(DataView dv, DataRow row)
        {
            int num = -1;
            if (row != null)
            {
                for (int recordIndex = 0; recordIndex <= dv.Count; ++recordIndex)
                {
                    if (object.ReferenceEquals((object)dv[recordIndex].Row, (object)row))
                    {
                        num = recordIndex;
                        break;
                    }
                }
            }
            return num;
        }

        public static SqlConnection Connect(Enum databaseToUse) => DataApi.Connect(DataApi.GetConnectionString(databaseToUse));

        public static SqlConnection Connect(Enum databaseToUse, Guid partitionKey) => DataApi.Connect(DataApi.GetConnectionString(databaseToUse));

        public static SqlConnection Connect(string connectString)
        {
            if (connectString == string.Empty)
                throw new Exception("The connection string is empty.");
            SqlConnection sqlConnection = (SqlConnection)null;
            try
            {
                sqlConnection = new SqlConnection();
                sqlConnection.ConnectionString = connectString;
                sqlConnection.Open();
                return sqlConnection;
            }
            catch (System.Exception ex)
            {
                if (sqlConnection != null)
                {
                    if (sqlConnection.State == ConnectionState.Open)
                        sqlConnection.Close();
                    sqlConnection.Dispose();
                }
                throw new ApplicationException("Exception establishing connection.", ex);
            }
        }

        public static string GetConnectionString(Enum databaseToUse)
        {
            string str = string.Empty;
            if (DataApi.connectStrings.Contains((object)databaseToUse))
            {
                str = DataApi.connectStrings[(object)databaseToUse].ToString();
            }
            else
            {
                //object[] customAttributes = databaseToUse.GetType().GetMember(databaseToUse.ToString())[0].GetCustomAttributes(false);
                //if (customAttributes.Length > 0)
                //{
                //    if (typeof(ConnectionStringAttribute) == customAttributes[0].GetType())
                //        str = ((ConnectionStringAttribute)customAttributes[0]).ConnectionString;
                //    else if (typeof(ConfigurationAppSettingsKeyAttribute) == customAttributes[0].GetType())
                //        str = DataApi.GetConnectionString((ConfigurationAppSettingsKeyAttribute)customAttributes[0]);
                //    else if (typeof(RegistryKeyAttribute) == customAttributes[0].GetType())
                //        str = DataApi.GetConnectionString((RegistryKeyAttribute)customAttributes[0]);
                //}
                //if (str != string.Empty)
                //{
                //    lock (DataApi.connectStrings)
                //    {
                //        if (!DataApi.connectStrings.Contains((object)databaseToUse))
                //            DataApi.connectStrings.Add((object)databaseToUse, (object)str);
                //    }
                //}
            }
            return str;
        }

        //private static string decryptConnectionString(string encryptedConnectionString)
        //{
        //    NameValueCollection section = (NameValueCollection)ConfigurationManager.GetSection("secureAppSettings");
        //    string empty1 = string.Empty;
        //    string registryEntries;
        //    if (section["SqlConnectStringPassphraseFile"] != null)
        //    {
        //        registryEntries = section["SqlConnectStringPassphraseFile"];
        //    }
        //    else
        //    {
        //        registryEntries = RegistrySearch.GetRegistryEntries("SOFTWARE\\Newkirk\\NewkirkOne\\Environment", "SqlConnectStringPassphraseFilePath");
        //        if (string.IsNullOrEmpty(registryEntries))
        //            throw new ApplicationException("The Pass Pharse for the connection strings has not been added to the application settings.");
        //    }
        //    string passPhrase = string.Empty;
        //    string empty2 = string.Empty;
        //    using (StreamReader streamReader = new StreamReader(registryEntries))
        //    {
        //        string str;
        //        while ((str = streamReader.ReadLine()) != null)
        //        {
        //            if (str.Trim().Length > 0)
        //            {
        //                passPhrase = str.Trim();
        //                break;
        //            }
        //        }
        //    }
        //    return Crypto.DecryptTextUsingAES(encryptedConnectionString, passPhrase);
        //}

        //private static string GetConnectionString(
        //  ConfigurationAppSettingsKeyAttribute configurationAppSettingsKeyAttribute)
        //{
        //    
        //    return ConfigurationManager.AppSettings[configurationAppSettingsKeyAttribute.AppSettingsKey];
        //}

        //private static string GetConnectionString(RegistryKeyAttribute registryKeyAttribute) => DataApi.decryptConnectionString(RegistrySearch.GetRegistryEntries(registryKeyAttribute.RegistrySubKeyGroup, registryKeyAttribute.RegistrySubKey));

        public static SqlCommand CreateSqlCommand(Enum databaseToUse, string sqlCommand) => DataApi.CreateSqlCommand(DataApi.GetConnectionString(databaseToUse), sqlCommand);

        public static SqlCommand CreateSqlCommand(string connectString, string sqlCommand)
        {
            SqlConnection connection = DataApi.Connect(connectString);
            return new SqlCommand(sqlCommand, connection);
        }

        public static SqlCommand CreateSqlCommand(
          SqlConnection connection,
          string sqlCommand,
          IsolationLevel isolationLevel)
        {
            SqlCommand sqlCommand1 = new SqlCommand(sqlCommand, connection);
            sqlCommand1.Transaction = sqlCommand1.Connection.BeginTransaction(isolationLevel);
            return sqlCommand1;
        }

        public static SqlCommand CreateSqlSPCommand(
          Enum databaseToUse,
          string storedProcedureName)
        {
            return DataApi.CreateSqlSPCommand(DataApi.GetConnectionString(databaseToUse), storedProcedureName);
        }

        public static SqlCommand CreateSqlSPCommand(
          string connectString,
          string storedProcedureName)
        {
            SqlCommand sqlCommand = DataApi.CreateSqlCommand(connectString, storedProcedureName);
            sqlCommand.CommandType = CommandType.StoredProcedure;
            return sqlCommand;
        }

        public static SqlCommand AddSqlParameter(
          SqlCommand cmd,
          string paramName,
          ParameterDirection direction,
          object value)
        {
            SqlParameter sqlParameter = new SqlParameter();
            sqlParameter.ParameterName = paramName;
            sqlParameter.Direction = direction;
            sqlParameter.SqlDbType = DataApi.GetSqlTypeFromSystemType(value.GetType());
            sqlParameter.Value = value;
            cmd.Parameters.Add(sqlParameter);
            return cmd;
        }

        public static SqlParameter CreateSqlParameter(
          string paramName,
          ParameterDirection direction,
          object value)
        {
            SqlParameter sqlParameter = new SqlParameter();
            sqlParameter.ParameterName = paramName;
            sqlParameter.Direction = direction;
            sqlParameter.SqlDbType = DataApi.GetSqlTypeFromSystemType(value.GetType());
            sqlParameter.Value = value;
            return sqlParameter;
        }

        public static DataApi.CreateParameterizedINListResults CreateParameterizedINList<T>(
          List<T> inListArray)
        {
            return DataApi.CreateParameterizedINList<T>(inListArray, 0);
        }

        public static DataApi.CreateParameterizedINListResults CreateParameterizedINList<T>(
          List<T> inListArray,
          int startnum)
        {
            DataApi.CreateParameterizedINListResults parameterizedInListResults = new DataApi.CreateParameterizedINListResults();
            StringBuilder stringBuilder = new StringBuilder(1024);
            stringBuilder.Append(" ( ");
            List<SqlParameter> sqlParameterList = new List<SqlParameter>();
            for (int index = 0; index < inListArray.Count; ++index)
            {
                string parameterName = "@InClauseParm" + (index + startnum).ToString();
                sqlParameterList.Add(new SqlParameter(parameterName, (object)inListArray[index])
                {
                    SqlDbType = DataApi.GetSqlTypeFromSystemType(typeof(T))
                });
                stringBuilder.Append(parameterName);
                if (index != inListArray.Count - 1)
                    stringBuilder.Append(", ");
            }
            stringBuilder.Append(" ) ");
            parameterizedInListResults.Parameters = sqlParameterList;
            parameterizedInListResults.InListQuery = stringBuilder.ToString();
            return parameterizedInListResults;
        }

        public static int ExecuteBatchNonQuery(Enum databaseToUse, string batchCommand)
        {
            int num = 0;
            using (SqlConnection sqlConnection = DataApi.Connect(databaseToUse))
            {
                using (SqlTransaction transaction = sqlConnection.BeginTransaction())
                {
                    num = DataApi.ExecuteBatchNonQuery(batchCommand, transaction);
                    transaction.Commit();
                }
            }
            return num;
        }

        public static int ExecuteBatchNonQuery(string batchCommand, SqlTransaction transaction) => DataApi.ExecuteBatchNonQuery(batchCommand, transaction, int.MinValue);

        public static int ExecuteBatchNonQuery(
          string batchCommand,
          SqlTransaction transaction,
          int commandTimeout)
        {
            int num = 0;
            using (SqlCommand sqlCommand1 = new SqlCommand())
            {
                using (SqlCommand sqlCommand2 = new SqlCommand())
                {
                    if (transaction.Connection == null)
                        throw new ArgumentException("Transaction passed to this method must already be started.", nameof(transaction));
                    sqlCommand1.CommandType = CommandType.Text;
                    sqlCommand1.Connection = transaction.Connection;
                    sqlCommand1.Transaction = transaction;
                    sqlCommand1.CommandText = "SET ARITHABORT ON";
                    sqlCommand1.ExecuteNonQuery();
                    sqlCommand2.CommandType = CommandType.Text;
                    sqlCommand2.Connection = transaction.Connection;
                    sqlCommand2.Transaction = transaction;
                    sqlCommand2.CommandText = batchCommand;
                    if (commandTimeout != int.MinValue)
                        sqlCommand2.CommandTimeout = commandTimeout;
                    num = sqlCommand2.ExecuteNonQuery();
                }
            }
            return num;
        }

        public static DataSet ExecuteSqlString(Enum databaseToUse, string sqlStatement) => DataApi.ExecuteSqlString(DataApi.GetConnectionString(databaseToUse), sqlStatement);

        public static DataSet ExecuteSqlString(string connectString, string sqlStatement)
        {
            DataSet dataSet = new DataSet();
            SqlDataAdapter sqlDataAdapter = (SqlDataAdapter)null;
            try
            {
                sqlDataAdapter = DataApi.GetDataAdapter(connectString, sqlStatement);
                sqlDataAdapter.Fill(dataSet);
                return dataSet;
            }
            finally
            {
                if (sqlDataAdapter != null && sqlDataAdapter.SelectCommand != null && sqlDataAdapter.SelectCommand.Connection != null)
                {
                    sqlDataAdapter.SelectCommand.Connection.Close();
                    sqlDataAdapter.Dispose();
                }
            }
        }

        public static DataSet ExecuteSqlString(
          Enum databaseToUse,
          string sqlStatement,
          string tableName)
        {
            return DataApi.ExecuteSqlString(DataApi.GetConnectionString(databaseToUse), sqlStatement, tableName);
        }

        public static DataSet ExecuteSqlString(
          string connectString,
          string sqlStatement,
          string tableName)
        {
            DataSet dataSet = new DataSet();
            SqlDataAdapter sqlDataAdapter = (SqlDataAdapter)null;
            try
            {
                sqlDataAdapter = DataApi.GetDataAdapter(connectString, sqlStatement);
                sqlDataAdapter.Fill(dataSet, tableName);
                return dataSet;
            }
            finally
            {
                if (sqlDataAdapter != null && sqlDataAdapter.SelectCommand != null && sqlDataAdapter.SelectCommand.Connection != null)
                {
                    sqlDataAdapter.SelectCommand.Connection.Close();
                    sqlDataAdapter.Dispose();
                }
            }
        }

        public static DataSet ExecuteSqlString(
          Enum databaseToUse,
          string sqlStatement,
          DataSet dataSet,
          string tableName)
        {
            return DataApi.ExecuteSqlString(DataApi.GetConnectionString(databaseToUse), sqlStatement, dataSet, tableName);
        }

        public static DataSet ExecuteSqlString(
          string connectString,
          string sqlStatement,
          DataSet dataSet,
          string tableName)
        {
            SqlDataAdapter sqlDataAdapter = (SqlDataAdapter)null;
            try
            {
                if (dataSet == null)
                    throw new ArgumentNullException(nameof(dataSet), "DataSet must be created prior to calling ExecuteSqlString");
                sqlDataAdapter = DataApi.GetDataAdapter(connectString, sqlStatement);
                sqlDataAdapter.Fill(dataSet, tableName);
                return dataSet;
            }
            finally
            {
                if (sqlDataAdapter != null && sqlDataAdapter.SelectCommand != null && sqlDataAdapter.SelectCommand.Connection != null)
                {
                    sqlDataAdapter.SelectCommand.Connection.Close();
                    sqlDataAdapter.Dispose();
                }
            }
        }

        public static object ExecuteSqlStringScalar(Enum databaseToUse, string sqlStatement)
        {
            object obj = (object)null;
            string sqlCommand1 = DataApi.Pack(sqlStatement);
            SqlCommand sqlCommand2 = DataApi.CreateSqlCommand(DataApi.GetConnectionString(databaseToUse), sqlCommand1);
            sqlCommand2.Transaction = sqlCommand2.Connection.BeginTransaction(IsolationLevel.ReadUncommitted);
            try
            {
                obj = sqlCommand2.ExecuteScalar();
                sqlCommand2.Transaction.Commit();
            }
            finally
            {
                if (sqlCommand2.Connection != null)
                    sqlCommand2.Connection.Close();
                sqlCommand2.Dispose();
            }
            return obj;
        }

        public static DataSet ExecuteSqlCommand(
          SqlCommand cmd,
          DataSet dataSet,
          string tableName)
        {
            SqlDataAdapter sqlDataAdapter = (SqlDataAdapter)null;
            try
            {
                if (dataSet == null)
                    throw new ArgumentNullException(nameof(dataSet), "DataSet must be created prior to calling ExecuteSqlString");
                cmd.Transaction = cmd.Connection.BeginTransaction(IsolationLevel.ReadUncommitted);
                sqlDataAdapter = new SqlDataAdapter(cmd);
                sqlDataAdapter.Fill(dataSet, tableName);
                return dataSet;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlDataAdapter != null && sqlDataAdapter.SelectCommand != null && sqlDataAdapter.SelectCommand.Connection != null)
                {
                    sqlDataAdapter.SelectCommand.Connection.Close();
                    sqlDataAdapter.Dispose();
                }
            }
        }

        public static DataSet ExecuteSqlCommand(
          SqlCommand cmd,
          DataSet dataSet,
          string[] tableNames)
        {
            SqlDataAdapter sqlDataAdapter = (SqlDataAdapter)null;
            try
            {
                if (dataSet == null)
                    throw new ArgumentNullException(nameof(dataSet), "DataSet must be created prior to calling ExecuteSqlString");
                cmd.Transaction = cmd.Connection.BeginTransaction(IsolationLevel.ReadUncommitted);
                sqlDataAdapter = new SqlDataAdapter(cmd);
                sqlDataAdapter.TableMappings.Add("Table", tableNames[0]);
                for (int index = 1; index < tableNames.Length; ++index)
                    sqlDataAdapter.TableMappings.Add("Table" + index.ToString(), tableNames[index]);
                sqlDataAdapter.Fill(dataSet);
                return dataSet;
            }
            finally
            {
                if (sqlDataAdapter != null && sqlDataAdapter.SelectCommand != null && sqlDataAdapter.SelectCommand.Connection != null)
                {
                    sqlDataAdapter.SelectCommand.Connection.Close();
                    sqlDataAdapter.Dispose();
                }
            }
        }

        public static bool RecycleCache()
        {
            bool flag = false;
            if (DataApi.connectStrings.Count != 0)
                DataApi.connectStrings = new Hashtable();
            if (DataApi.connectStrings.Count == 0)
                flag = true;
            return flag;
        }

        //public static void DeleteItem(object objectToSave, SqlTransaction transaction)
        //{
        //    if (transaction.Connection == null)
        //        throw new ArgumentException("Transaction passed to this method must already be started.", nameof(transaction));
        //    using (SqlCommand itemDeleteCommand = DataApi.GetItemDeleteCommand(objectToSave, transaction))
        //    {
        //        if (itemDeleteCommand.CommandText.Length == 0)
        //            throw new ApplicationException(string.Format("Unable to determine delete stored procedure to invoke for object {0}.", (object)objectToSave.ToString()));
        //        using (SqlCommand sqlCommand = new SqlCommand())
        //        {
        //            sqlCommand.CommandType = CommandType.Text;
        //            sqlCommand.Connection = transaction.Connection;
        //            sqlCommand.Transaction = transaction;
        //            sqlCommand.CommandText = "SET ARITHABORT ON";
        //            sqlCommand.ExecuteNonQuery();
        //        }
        //        itemDeleteCommand.ExecuteNonQuery();
        //    }
        //}

        //public static SqlCommand GetItemDeleteCommand(
        //  object objectToParse,
        //  SqlTransaction transaction)
        //{
        //    SqlCommand sqlCommand = new SqlCommand();
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    if (transaction != null)
        //    {
        //        sqlCommand.Connection = transaction.Connection;
        //        sqlCommand.Transaction = transaction;
        //    }
        //    Type type = objectToParse.GetType();
        //    foreach (PropertyInfo property in type.GetProperties(BindingFlags.Instance | BindingFlags.Public))
        //    {
        //        object[] customAttributes = property.GetCustomAttributes(typeof(StoredProcMappingAttribute), false);
        //        if (customAttributes.Length > 0)
        //        {
        //            StoredProcMappingAttribute mappingAttribute = (StoredProcMappingAttribute)customAttributes[0];
        //            if (mappingAttribute.PrimaryKey && !DataApi.isPropertyNull(property, objectToParse, mappingAttribute.EmptyStringIsNull))
        //            {
        //                SqlParameter sqlParameter = new SqlParameter();
        //                sqlParameter.ParameterName = mappingAttribute.SqlParamName;
        //                sqlParameter.Direction = ParameterDirection.Input;
        //                sqlParameter.Value = property.GetValue(objectToParse, (object[])null);
        //                sqlParameter.SqlDbType = mappingAttribute.SqlDbType != SqlDbType.Variant ? mappingAttribute.SqlDbType : DataApi.GetSqlTypeFromSystemType(property.PropertyType);
        //                sqlCommand.Parameters.Add(sqlParameter);
        //            }
        //        }
        //    }
        //    object[] customAttributes1 = type.GetCustomAttributes(typeof(StoredProcNameAttribute), false);
        //    sqlCommand.CommandText = ((StoredProcNameAttribute)customAttributes1[0]).DeleteProcName;
        //    return sqlCommand;
        //}

        //public static void SaveItem(ISaveable objectToSave, SqlTransaction transaction) => DataApi.SaveItem(objectToSave, transaction, int.MinValue);

        //public static void SaveItem(
        //  ISaveable objectToSave,
        //  SqlTransaction transaction,
        //  int commandTimeout)
        //{
        //    SqlCommand sqlCommand1 = new SqlCommand();
        //    try
        //    {
        //        GetItemSaveCommandReturn saveCommandReturn = transaction.Connection != null ? objectToSave.GetSaveCommand(transaction) : throw new ArgumentException("Transaction passed to this method must already be started.", nameof(transaction));
        //        sqlCommand1 = saveCommandReturn.SaveCommand;
        //        ArrayList returnPropertyArray = saveCommandReturn.ReturnPropertyArray;
        //        ArrayList returnParamArray = saveCommandReturn.ReturnParamArray;
        //        if (commandTimeout != int.MinValue)
        //            sqlCommand1.CommandTimeout = commandTimeout;
        //        if (sqlCommand1.CommandText.Length == 0)
        //            throw new ApplicationException("Unable to determine stored procedure to invoke for object " + objectToSave.ToString());
        //        SqlCommand sqlCommand2 = new SqlCommand();
        //        sqlCommand2.CommandType = CommandType.Text;
        //        sqlCommand2.Connection = transaction.Connection;
        //        sqlCommand2.Transaction = transaction;
        //        sqlCommand2.CommandText = "SET ARITHABORT ON";
        //        sqlCommand2.ExecuteNonQuery();
        //        sqlCommand1.ExecuteNonQuery();
        //        for (int index = 0; index < returnPropertyArray.Count; ++index)
        //            ((PropertyInfo)returnPropertyArray[index]).SetValue((object)objectToSave, ((DbParameter)returnParamArray[index]).Value, (object[])null);
        //    }
        //    catch (System.Exception ex)
        //    {
        //        if (ex.GetType() == typeof(PropertyNullException) || ex.GetType() == typeof(BusinessRuleException))
        //        {
        //            throw;
        //        }
        //        else
        //        {
        //            StringBuilder stringBuilder = new StringBuilder();
        //            try
        //            {
        //                if (ex.GetType() == typeof(SqlException))
        //                    stringBuilder.Append("An error occurred in " + sqlCommand1.CommandText + Environment.NewLine);
        //                else
        //                    stringBuilder.Append("A non-SQL general error occurred while attempting to process " + sqlCommand1.CommandText + Environment.NewLine);
        //                stringBuilder.Append("The parameter list was:  " + Environment.NewLine);
        //                for (int index = 0; index < sqlCommand1.Parameters.Count; ++index)
        //                {
        //                    stringBuilder.Append(sqlCommand1.Parameters[index].ParameterName);
        //                    stringBuilder.Append(" = ");
        //                    Type type = sqlCommand1.Parameters[index].Value.GetType();
        //                    if (type.IsSubclassOf(typeof(Enum)))
        //                    {
        //                        stringBuilder.Append(Convert.ToInt32(sqlCommand1.Parameters[index].Value).ToString());
        //                        stringBuilder.Append("  (");
        //                        stringBuilder.Append(type.ToString());
        //                        stringBuilder.Append(".");
        //                        stringBuilder.Append(sqlCommand1.Parameters[index].Value.ToString());
        //                        stringBuilder.Append(")");
        //                    }
        //                    else
        //                        stringBuilder.Append(sqlCommand1.Parameters[index].Value.ToString());
        //                    stringBuilder.Append(Environment.NewLine);
        //                }
        //                stringBuilder.Append(ex.ToString());
        //            }
        //            catch
        //            {
        //                throw ex;
        //            }
        //            throw new ApplicationException(stringBuilder.ToString(), ex);
        //        }
        //    }
        //    finally
        //    {
        //        sqlCommand1?.Dispose();
        //    }
        //}

        //public static void BatchSaveItems<T>(IBatchSavable<T> collection, SqlConnection conn) where T : IBatchPreSavable => DataApi.batchSaveItems<T>(collection, SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.UseInternalTransaction, conn, (SqlTransaction)null);

        //public static void BatchSaveItems<T>(IBatchSavable<T> collection, SqlTransaction transaction) where T : IBatchPreSavable => DataApi.batchSaveItems<T>(collection, SqlBulkCopyOptions.TableLock, transaction.Connection, transaction);

        //private static void batchSaveItems<T>(
        //  IBatchSavable<T> collection,
        //  SqlBulkCopyOptions options,
        //  SqlConnection conn,
        //  SqlTransaction transaction)
        //  where T : IBatchPreSavable
        //{
        //    if (string.IsNullOrEmpty(collection.BatchSaveProcName))
        //        throw new ArgumentNullException("BatchSaveProcName");
        //    collection.BatchPreSave();
        //    using (IDataReader dataReader = collection.GetDataReader())
        //    {
        //        using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(conn, options, transaction))
        //        {
        //            sqlBulkCopy.BatchSize = collection.BatchSize;
        //            sqlBulkCopy.DestinationTableName = collection.TableName;
        //            sqlBulkCopy.BulkCopyTimeout = collection.CommandTimeout;
        //            foreach (SqlBulkCopyColumnMapping columnMapping in collection.GetColumnMappings())
        //                sqlBulkCopy.ColumnMappings.Add(columnMapping);
        //            sqlBulkCopy.WriteToServer(dataReader);
        //        }
        //    }
        //    using (SqlCommand sqlCommand = new SqlCommand("SET ARITHABORT ON", conn, transaction))
        //    {
        //        sqlCommand.ExecuteNonQuery();
        //        sqlCommand.CommandText = collection.BatchSaveProcName;
        //        sqlCommand.CommandType = CommandType.StoredProcedure;
        //        sqlCommand.Parameters.AddRange(collection.GetBatchSaveParameters().ToArray());
        //        if (collection.CommandTimeout != int.MinValue)
        //            sqlCommand.CommandTimeout = Math.Max(collection.CommandTimeout, 0);
        //        sqlCommand.ExecuteNonQuery();
        //        if (string.IsNullOrEmpty(collection.BatchCleanupProcName))
        //            return;
        //        sqlCommand.Parameters.Clear();
        //        sqlCommand.CommandText = collection.BatchCleanupProcName;
        //        sqlCommand.Parameters.AddRange(collection.GetBatchCleanupParameters().ToArray());
        //        sqlCommand.ExecuteNonQuery();
        //    }
        //}

        //public static GetItemSaveCommandReturn GetItemSaveCommand(
        //  ISaveable objectToParse,
        //  SqlTransaction transaction)
        //{
        //    objectToParse.PreSave();
        //    ArrayList arrayList1 = new ArrayList(5);
        //    ArrayList arrayList2 = new ArrayList(5);
        //    SqlCommand sqlCommand = new SqlCommand();
        //    sqlCommand.CommandType = CommandType.StoredProcedure;
        //    if (transaction != null)
        //    {
        //        sqlCommand.Connection = transaction.Connection;
        //        sqlCommand.Transaction = transaction;
        //    }
        //    Type type1 = objectToParse.GetType();
        //    foreach (PropertyInfo property in type1.GetProperties(BindingFlags.Instance | BindingFlags.Public))
        //    {
        //        object[] customAttributes = property.GetCustomAttributes(typeof(StoredProcMappingAttribute), false);
        //        if (customAttributes.Length > 0)
        //        {
        //            StoredProcMappingAttribute mappingAttribute = (StoredProcMappingAttribute)customAttributes[0];
        //            bool flag = DataApi.isPropertyNull(property, (object)objectToParse, mappingAttribute.EmptyStringIsNull);
        //            bool output = mappingAttribute.Output;
        //            if (!flag || output)
        //            {
        //                SqlParameter sqlParameter = new SqlParameter();
        //                sqlParameter.ParameterName = mappingAttribute.SqlParamName;
        //                if (output)
        //                {
        //                    arrayList2.Add((object)sqlParameter);
        //                    arrayList1.Add((object)property);
        //                }
        //                if (property.PropertyType.IsSubclassOf(typeof(Array)))
        //                {
        //                    Array array = (Array)property.GetValue((object)objectToParse, new object[0]);
        //                    StringBuilder stringBuilder = new StringBuilder(5120);
        //                    foreach (object obj in array)
        //                    {
        //                        Type type2 = obj.GetType();
        //                        stringBuilder.Append(stringBuilder.Length > 0 ? "," : "");
        //                        if (type2.IsSubclassOf(typeof(Enum)))
        //                            stringBuilder.Append(((int)obj).ToString());
        //                        else
        //                            stringBuilder.Append(obj.ToString());
        //                    }
        //                    sqlParameter.Value = (object)stringBuilder.ToString();
        //                    sqlParameter.SqlDbType = SqlDbType.VarChar;
        //                }
        //                else
        //                {
        //                    if (property.PropertyType.Name == "List`1" && !flag)
        //                    {
        //                        object obj = property.GetValue((object)objectToParse, (object[])null);
        //                        MethodInfo method = obj.GetType().GetMethod("ToArray");
        //                        sqlParameter.Value = method.Invoke(obj, (object[])null);
        //                    }
        //                    else
        //                        sqlParameter.Value = flag ? (object)DBNull.Value : property.GetValue((object)objectToParse, (object[])null);
        //                    sqlParameter.SqlDbType = mappingAttribute.SqlDbType != SqlDbType.Variant ? mappingAttribute.SqlDbType : DataApi.GetSqlTypeFromSystemType(DataApi.GetPropertyTypeFromPropertyInfo(property));
        //                }
        //                sqlParameter.Direction = output ? ParameterDirection.InputOutput : ParameterDirection.Input;
        //                sqlCommand.Parameters.Add(sqlParameter);
        //            }
        //        }
        //    }
        //    object[] customAttributes1 = type1.GetCustomAttributes(typeof(StoredProcNameAttribute), false);
        //    if (customAttributes1.Length > 0)
        //        sqlCommand.CommandText = ((StoredProcNameAttribute)customAttributes1[0]).InsUpdProcName;
        //    GetItemSaveCommandReturn saveCommandReturn;
        //    saveCommandReturn.SaveCommand = sqlCommand;
        //    saveCommandReturn.ReturnParamArray = arrayList2;
        //    saveCommandReturn.ReturnPropertyArray = arrayList1;
        //    return saveCommandReturn;
        //}

        //public static List<SqlParameter> GetBatchParameters(
        //  object itemToParse,
        //  BatchParameterType parameterType)
        //{
        //    List<SqlParameter> sqlParameterList = new List<SqlParameter>();
        //    if (itemToParse == null)
        //        return sqlParameterList;
        //    foreach (var data in itemToParse.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public).Cast<PropertyInfo>().SelectMany((Func<PropertyInfo, IEnumerable<BatchSaveSqlParameterAttribute>>)(info => info.GetCustomAttributes(typeof(BatchSaveSqlParameterAttribute), true).Cast<BatchSaveSqlParameterAttribute>()), (info, mapping) =>
        //    {
        //        var data = new { info = info, mapping = mapping };
        //        return data;
        //    }).Where(_param1 => (_param1.mapping.BatchParameterType & parameterType) > BatchParameterType.None).Select(_param0 =>
        //    {
        //        var data = new
        //        {
        //            PropertyInfo = _param0.info,
        //            ParameterMapping = _param0.mapping
        //        };
        //        return data;
        //    }))
        //    {
        //        if (!DataApi.isPropertyNull(data.PropertyInfo, itemToParse, data.ParameterMapping.EmptyStringIsNull))
        //        {
        //            SqlParameter sqlParameter = new SqlParameter();
        //            sqlParameter.ParameterName = data.ParameterMapping.ParamName;
        //            sqlParameter.Direction = ParameterDirection.Input;
        //            if (data.PropertyInfo.PropertyType.IsSubclassOf(typeof(Array)))
        //            {
        //                Array anArray = (Array)data.PropertyInfo.GetValue(itemToParse, new object[0]);
        //                sqlParameter.Value = (object)DataApi.CreateDelimitedList(anArray, ",", false);
        //                sqlParameter.SqlDbType = SqlDbType.VarChar;
        //            }
        //            else
        //            {
        //                sqlParameter.Value = data.PropertyInfo.GetValue(itemToParse, (object[])null);
        //                sqlParameter.SqlDbType = data.ParameterMapping.SqlDbType != SqlDbType.Variant ? data.ParameterMapping.SqlDbType : DataApi.GetSqlTypeFromSystemType(DataApi.GetPropertyTypeFromPropertyInfo(data.PropertyInfo));
        //            }
        //            sqlParameter.Precision = data.ParameterMapping.Precision;
        //            sqlParameter.Scale = data.ParameterMapping.Scale;
        //            if (data.ParameterMapping.Length > 0)
        //                sqlParameter.Size = data.ParameterMapping.Length;
        //            sqlParameterList.Add(sqlParameter);
        //        }
        //    }
        //    return sqlParameterList;
        //}

        public static string CreateDelimitedList(Array anArray, string delimiter, bool useQuotes)
        {
            string str1 = string.Empty;
            StringBuilder stringBuilder = new StringBuilder(5120);
            if (useQuotes)
                str1 = "'";
            foreach (object an in anArray)
            {
                if (an != null)
                {
                    string str2 = an.ToString();
                    if (useQuotes)
                        str2.Replace("'", "''");
                    stringBuilder.Append((stringBuilder.Length > 0 ? delimiter : "") + str1 + str2 + str1);
                }
            }
            return stringBuilder.ToString();
        }

        public static string[] CreateDelimitedListGroup(
          Array anArray,
          string delimiter,
          bool useQuotes,
          int groupSize)
        {
            ArrayList arrayList = new ArrayList();
            string str1 = string.Empty;
            int num = 0;
            StringBuilder stringBuilder = new StringBuilder();
            if (useQuotes)
                str1 = "'";
            foreach (object an in anArray)
            {
                if (an != null)
                {
                    ++num;
                    string str2 = an.ToString();
                    if (useQuotes)
                        str2.Replace("'", "''");
                    stringBuilder.Append((stringBuilder.Length > 0 ? delimiter : "") + str1 + str2 + str1);
                    if (num % groupSize == 0 && num > 0 || num == anArray.Length)
                    {
                        arrayList.Add((object)stringBuilder.ToString());
                        stringBuilder = new StringBuilder();
                    }
                }
            }
            return (string[])arrayList.ToArray(typeof(string));
        }

        public static SqlDbType GetSqlTypeFromSystemType(Type t)
        {
            Type type = !t.IsSubclassOf(typeof(Enum)) ? t : Enum.GetUnderlyingType(t);
            if (type == typeof(string))
                return SqlDbType.VarChar;
            if (type == typeof(long))
                return SqlDbType.BigInt;
            if (type == typeof(int))
                return SqlDbType.Int;
            if (type == typeof(short))
                return SqlDbType.SmallInt;
            if (type == typeof(double))
                return SqlDbType.Float;
            if (type == typeof(Decimal))
                return SqlDbType.Decimal;
            if (type == typeof(float))
                return SqlDbType.Real;
            if (type == typeof(byte))
                return SqlDbType.TinyInt;
            if (type == typeof(Guid))
                return SqlDbType.UniqueIdentifier;
            if (type == typeof(DateTime))
                return SqlDbType.DateTime;
            if (type == typeof(bool))
                return SqlDbType.Bit;
            throw new NotSupportedException("Cannot convert system type to database type: " + t.FullName);
        }

        public static Type GetSystemTypeFromSqlType(SqlDbType sqlDbType)
        {
            if (sqlDbType.ToString().ToLower().EndsWith("char"))
                return typeof(string);
            switch (sqlDbType)
            {
                case SqlDbType.BigInt:
                    return typeof(long);
                case SqlDbType.Bit:
                    return typeof(bool);
                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                    return typeof(DateTime);
                case SqlDbType.Decimal:
                    return typeof(Decimal);
                case SqlDbType.Float:
                    return typeof(double);
                case SqlDbType.Int:
                    return typeof(int);
                case SqlDbType.Money:
                    return typeof(Decimal);
                case SqlDbType.Real:
                    return typeof(float);
                case SqlDbType.UniqueIdentifier:
                    return typeof(Guid);
                case SqlDbType.SmallInt:
                    return typeof(short);
                case SqlDbType.Text:
                    return typeof(string);
                case SqlDbType.TinyInt:
                    return typeof(byte);
                default:
                    throw new NotSupportedException("Cannot convert database type to system type: " + sqlDbType.ToString());
            }
        }

        //public static void FillBusinessBaseObject(
        //  BusinessBase businessObject,
        //  string sqlQuery,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel)
        //{
        //    DataApi.FillBusinessBaseObject(businessObject, sqlQuery, databaseToUse, isolationLevel, int.MinValue);
        //}

        //public static void FillBusinessBaseObject(
        //  BusinessBase businessObject,
        //  string sqlQuery,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  int commandTimeout)
        //{
        //    using (SqlConnection connection = DataApi.Connect(databaseToUse))
        //    {
        //        using (SqlCommand sqlCommand = DataApi.CreateSqlCommand(connection, sqlQuery, isolationLevel))
        //        {
        //            if (commandTimeout != int.MinValue)
        //                sqlCommand.CommandTimeout = commandTimeout;
        //            using (SafeDataReaderProxy safeDataReader = new SafeDataReaderProxy((IDataReader)sqlCommand.ExecuteReader()))
        //            {
        //                if (safeDataReader.Read())
        //                    businessObject.Fill(safeDataReader);
        //                safeDataReader.Close();
        //            }
        //            if (sqlCommand.Transaction == null)
        //                return;
        //            sqlCommand.Transaction.Dispose();
        //        }
        //    }
        //}

        //public static void FillBusinessBaseObject(
        //  BusinessBase businessObject,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel)
        //{
        //    DataApi.FillBusinessBaseObject(businessObject, sqlQuery, sqlParameters, databaseToUse, isolationLevel, int.MinValue);
        //}

        //public static void FillBusinessBaseObject(
        //  BusinessBase businessObject,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  int commandTimeout)
        //{
        //    using (SqlConnection connection = DataApi.Connect(databaseToUse))
        //    {
        //        SqlParameter sqlParameter1 = new SqlParameter();
        //        using (SqlCommand sqlCommand = DataApi.CreateSqlCommand(connection, sqlQuery, isolationLevel))
        //        {
        //            if (commandTimeout != int.MinValue)
        //                sqlCommand.CommandTimeout = commandTimeout;
        //            if (sqlParameters != null)
        //            {
        //                foreach (SqlParameter sqlParameter2 in sqlParameters)
        //                    sqlCommand.Parameters.Add(sqlParameter2);
        //            }
        //            using (SafeDataReaderProxy safeDataReader = new SafeDataReaderProxy((IDataReader)sqlCommand.ExecuteReader()))
        //            {
        //                if (safeDataReader.Read())
        //                    businessObject.Fill(safeDataReader);
        //                safeDataReader.Close();
        //            }
        //            if (sqlCommand.Transaction == null)
        //                return;
        //            sqlCommand.Transaction.Dispose();
        //        }
        //    }
        //}

        //public static void FillBusinessCollectionBaseObject(
        //  BusinessCollectionBase businessCollectionObject,
        //  string sqlQuery,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  Type businessObjectType)
        //{
        //    DataApi.FillBusinessCollectionBaseObject(businessCollectionObject, sqlQuery, databaseToUse, isolationLevel, int.MinValue, businessObjectType);
        //}

        //public static void FillBusinessCollectionBaseObject(
        //  BusinessCollectionBase businessCollectionObject,
        //  string sqlQuery,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  int commandTimeout,
        //  Type businessObjectType)
        //{
        //    using (SqlConnection connection = DataApi.Connect(databaseToUse))
        //    {
        //        using (SqlCommand sqlCommand = DataApi.CreateSqlCommand(connection, sqlQuery, isolationLevel))
        //        {
        //            if (commandTimeout != int.MinValue)
        //                sqlCommand.CommandTimeout = commandTimeout;
        //            using (SafeDataReaderProxy safeDataReader = new SafeDataReaderProxy((IDataReader)sqlCommand.ExecuteReader()))
        //            {
        //                while (safeDataReader.Read())
        //                {
        //                    BusinessBase businessBase = (BusinessBase)businessObjectType.GetConstructor(Type.EmptyTypes).Invoke((object[])null);
        //                    businessBase.Fill(safeDataReader);
        //                    businessCollectionObject.Add((object)businessBase);
        //                }
        //                safeDataReader.Close();
        //            }
        //            if (sqlCommand.Transaction == null)
        //                return;
        //            sqlCommand.Transaction.Dispose();
        //        }
        //    }
        //}

        //public static void FillBusinessCollectionBaseObject(
        //  BusinessCollectionBase businessCollectionObject,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  Type businessObjectType)
        //{
        //    DataApi.FillBusinessCollectionBaseObject(businessCollectionObject, sqlQuery, sqlParameters, databaseToUse, isolationLevel, int.MinValue, businessObjectType);
        //}

        //public static void FillBusinessCollectionBaseObject(
        //  BusinessCollectionBase businessCollectionObject,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  int commandTimeout,
        //  Type businessObjectType)
        //{
        //    using (SqlConnection connection = DataApi.Connect(databaseToUse))
        //    {
        //        using (SqlCommand sqlCommand = DataApi.CreateSqlCommand(connection, sqlQuery, isolationLevel))
        //        {
        //            if (commandTimeout != int.MinValue)
        //                sqlCommand.CommandTimeout = commandTimeout;
        //            if (sqlParameters != null)
        //                sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
        //            using (SafeDataReaderProxy safeDataReader = new SafeDataReaderProxy((IDataReader)sqlCommand.ExecuteReader()))
        //            {
        //                while (safeDataReader.Read())
        //                {
        //                    BusinessBase businessBase = (BusinessBase)businessObjectType.GetConstructor(Type.EmptyTypes).Invoke((object[])null);
        //                    businessBase.Fill(safeDataReader);
        //                    businessCollectionObject.Add((object)businessBase);
        //                }
        //                safeDataReader.Close();
        //            }
        //            if (sqlCommand.Transaction == null)
        //                return;
        //            sqlCommand.Transaction.Dispose();
        //        }
        //    }
        //}

        //public static void FillBusinessCollectionBaseObject<T>(
        //  BusinessCollectionBase<T> collection,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel)
        //  where T : BusinessBase, new()
        //{
        //    DataApi.FillBusinessCollectionBaseObject<T>(collection, sqlQuery, sqlParameters, databaseToUse, isolationLevel, int.MinValue);
        //}

        //public static void FillBusinessCollectionBaseObject<T>(
        //  BusinessCollectionBase<T> collection,
        //  string sqlQuery,
        //  List<SqlParameter> sqlParameters,
        //  Enum databaseToUse,
        //  IsolationLevel isolationLevel,
        //  int commandTimeout)
        //  where T : BusinessBase, new()
        //{
        //    using (SqlConnection connection = DataApi.Connect(databaseToUse))
        //    {
        //        using (SqlCommand sqlCommand = DataApi.CreateSqlCommand(connection, sqlQuery, isolationLevel))
        //        {
        //            if (commandTimeout != int.MinValue)
        //                sqlCommand.CommandTimeout = commandTimeout;
        //            if (sqlParameters != null)
        //                sqlCommand.Parameters.AddRange(sqlParameters.ToArray());
        //            using (SafeDataReaderProxy safeDataReader = new SafeDataReaderProxy((IDataReader)sqlCommand.ExecuteReader()))
        //            {
        //                while (safeDataReader.Read())
        //                {
        //                    T obj = new T();
        //                    obj.Fill(safeDataReader);
        //                    collection.Add(obj);
        //                }
        //            }
        //            if (sqlCommand.Transaction == null)
        //                return;
        //            sqlCommand.Transaction.Dispose();
        //        }
        //    }
        //}

        private static string Pack(string stringToPack)
        {
            while (stringToPack.IndexOf("  ") > 0)
                stringToPack = stringToPack.Replace("  ", " ");
            return stringToPack;
        }

        private static SqlDataAdapter GetDataAdapter(
          Enum databaseToUse,
          string sqlStatement)
        {
            return DataApi.GetDataAdapter(DataApi.GetConnectionString(databaseToUse), sqlStatement);
        }

        private static SqlDataAdapter GetDataAdapter(
          string connectString,
          string sqlStatement)
        {
            string sqlCommand1 = DataApi.Pack(sqlStatement);
            SqlCommand sqlCommand2 = DataApi.CreateSqlCommand(connectString, sqlCommand1);
            sqlCommand2.Transaction = sqlCommand2.Connection.BeginTransaction(IsolationLevel.ReadUncommitted);
            return new SqlDataAdapter(sqlCommand2);
        }

        //private static bool isPropertyNull(
        //  PropertyInfo propertyInfo,
        //  object objectToSave,
        //  bool isEmptyStringNull)
        //{
        //    bool flag = false;
        //    object obj = propertyInfo.GetValue(objectToSave, (object[])null);
        //    Type fromPropertyInfo = DataApi.GetPropertyTypeFromPropertyInfo(propertyInfo);
        //    if (obj == null || fromPropertyInfo == typeof(DateTime) && (DateTime)obj == DateTime.MinValue || fromPropertyInfo == typeof(Decimal) && (Decimal)obj == Decimal.MinValue || fromPropertyInfo == typeof(double) && (double)obj == double.MinValue || fromPropertyInfo == typeof(int) && (int)obj == int.MinValue || fromPropertyInfo == typeof(short) && (short)obj == short.MinValue || fromPropertyInfo == typeof(byte) && (byte)obj == (byte)0 || fromPropertyInfo == typeof(Guid) && (Guid)obj == Guid.Empty || fromPropertyInfo == typeof(string) && obj.ToString() == string.Empty && isEmptyStringNull)
        //        flag = true;
        //    return flag;
        //}

        //private static Type GetPropertyTypeFromPropertyInfo(PropertyInfo propertyInfo) => !propertyInfo.PropertyType.IsSubclassOf(typeof(Enum)) ? propertyInfo.PropertyType : Enum.GetUnderlyingType(propertyInfo.PropertyType);

        public struct CreateParameterizedINListResults
        {
            public List<SqlParameter> Parameters;
            public string InListQuery;
        }
    }
}
