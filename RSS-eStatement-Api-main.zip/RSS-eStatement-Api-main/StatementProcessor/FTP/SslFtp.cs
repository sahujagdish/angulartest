﻿// Decompiled with JetBrains decompiler
// Type: Newkirk.Framework.SecureFtp.SslFtp
// Assembly: Newkirk.Framework, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1427E607-5760-4C73-AA04-06C2E8AE2795
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Newkirk.Framework.dll

//using ComponentPro.IO;
//using ComponentPro.Net;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text;
using System.Threading;

namespace Newkirk.Framework.SecureFtp
{
  public class SslFtp : IDisposable
  {
    private const string logConfiguration = "SslFtpErrorLog";
    private bool stackTrace;
    private bool lastError;
    private string lastErrorText;
    private string errorLog;
    private ProtocolType protocol = ProtocolType.Unknown;
    private FileSystem ftpClient;
    private string hostName = string.Empty;
    private string userName = string.Empty;
    private string password = string.Empty;
    private int port;
    private int timeout = 60;
    private bool passiveMode = true;
    private FileTransferModeType transferType = FileTransferModeType.Binary;
    private FtpTransferModeType ftpTransferType = FtpTransferModeType.Stream;

    public string HostName
    {
      get => this.hostName;
      set => this.hostName = value;
    }

    public string UserName
    {
      get => this.userName;
      set => this.userName = value;
    }

    public string Password
    {
      get => this.password;
      set => this.password = value;
    }

    public int Port
    {
      get => this.port;
      set => this.port = value;
    }

    public bool Connected => ((IRemoteFileSystem) this.ftpClient).IsConnected;

    public ProtocolType Protocol
    {
      get => this.protocol;
      set => this.protocol = value;
    }

    public bool StackTrace
    {
      get => this.stackTrace;
      set => this.stackTrace = value;
    }

    public bool LastError
    {
      get => this.lastError;
      set => this.lastError = value;
    }

    public string LastErrorText
    {
      get => this.lastErrorText;
      set => this.lastErrorText = value;
    }

    public string ErrorLog
    {
      get => this.errorLog;
      set => this.errorLog = value;
    }

    public int DirectoryItemsCount => this.ftpClient.ListDirectory().Count;

    public string RemotePath => this.ftpClient.GetCurrentDirectory();

    public int Timeout
    {
      get => this.timeout;
      set => this.timeout = value;
    }

    public bool PassiveMode
    {
      get => this.passiveMode;
      set => this.passiveMode = value;
    }

    public FileTransferModeType TransferType
    {
      get => this.transferType;
      set => this.transferType = value;
    }

    public FtpTransferModeType FtpTransferType
    {
      get => this.ftpTransferType;
      set => this.ftpTransferType = value;
    }

    public SslFtp()
    {
      this.ftpClient = (FileSystem) null;
      this.hostName = string.Empty;
      this.userName = string.Empty;
      this.password = string.Empty;
      if (ConfigurationManager.AppSettings["SslFtpErrorLog"] == null)
        return;
      this.errorLog = ConfigurationManager.AppSettings["SslFtpErrorLog"];
    }

    ~SslFtp() => this.Dispose();

    public void Dispose()
    {
      if (this.ftpClient == null)
        return;
      if (((IRemoteFileSystem) this.ftpClient).State != RemoteFileSystemState.Disposed && ((IRemoteFileSystem) this.ftpClient).IsConnected)
        ((IRemoteFileSystem) this.ftpClient).Disconnect();
      this.ftpClient.Dispose();
      this.ftpClient = (FileSystem) null;
    }

    public void Connect()
    {
      try
      {
        if (this.protocol == ProtocolType.SSH)
        {
          this.port = this.port > 0 ? this.port : 22;
          this.ftpClient = (FileSystem) new Sftp();
          ((Sftp) this.ftpClient).EnableCompression = true;
          ((Sftp) this.ftpClient).Connect(this.hostName, this.port);
          ((Sftp) this.ftpClient).Authenticate(this.userName, this.password);
        }
        else
        {
          this.port = this.port > 0 ? this.port : 21;
          this.ftpClient = (FileSystem) new Ftp();
          ((Ftp) this.ftpClient).Passive = this.passiveMode;
          ((Ftp) this.ftpClient).KeepAliveInterval = 60;
          ((Ftp) this.ftpClient).TransferMode = (FtpTransferMode) this.ftpTransferType;
          ((Ftp) this.ftpClient).SendAbortCommand = true;
          ((Ftp) this.ftpClient).SendTelnetInterruptSignal = true;
          this.ftpClient.ChangeDirectoryBeforeFileOperation = true;
          this.ftpClient.ChangeDirectoryBeforeListing = true;
          ((Ftp) this.ftpClient).SmartPathResolving = true;
          if (this.protocol == ProtocolType.SSL)
            ((Ftp) this.ftpClient).Connect(this.hostName, this.port, SecurityMode.Explicit);
          else
            ((Ftp) this.ftpClient).Connect(this.hostName, this.port);
          ((Ftp) this.ftpClient).Authenticate(this.userName, this.password);
          ((Ftp) this.ftpClient).KeepAlive();
        }
        ((IRemoteFileSystem) this.ftpClient).Timeout = this.timeout * 1000;
        ((IRemoteFileSystem) this.ftpClient).MaxDownloadSpeed = 0;
        ((IRemoteFileSystem) this.ftpClient).MaxUploadSpeed = 0;
        ((IRemoteFileSystem) this.ftpClient).TransferType = (FileTransferType) this.transferType;
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        throw ex;
      }
    }

    public void Disconnect()
    {
      if (!this.Connected)
        return;
      ((IRemoteFileSystem) this.ftpClient).Disconnect();
    }

    public void Getfile(string LocalFile, string RemoteFile)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot Get File on FTP site.  There is no valid connection.");
      if (!Directory.Exists(new FileInfo(LocalFile).Directory.ToString()))
      {
        this.writeError(3001, "Directory for LocalFile in Getfile: " + LocalFile + " Does Not Exist");
      }
      else
      {
        try
        {
          ((IRemoteFileSystem) this.ftpClient).DownloadFile(RemoteFile, LocalFile);
        }
        catch (Exception ex)
        {
          this.writeError(ex);
          this.ftpClient.Cancel();
        }
      }
    }

    public void PutFile(string LocalFile, string RemoteFile)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot Put File on FTP site.  There is no valid connection.");
      string empty = string.Empty;
      if (!File.Exists(LocalFile))
      {
        this.writeError(3000, " Local File: " + LocalFile + " Does Not Exist!");
      }
      else
      {
        try
        {
          ((IRemoteFileSystem) this.ftpClient).UploadFile(LocalFile, RemoteFile);
        }
        catch (Exception ex)
        {
          this.writeError(ex);
          this.ftpClient.Cancel();
          throw new ApplicationException(empty + "There was an error placing the " + LocalFile + " to the FTP site.", ex);
        }
      }
    }

    public void RemoveDir(string RemotePath)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot remove directory.  There is no valid connection.");
      string path = RemotePath.Trim();
      if (!path.StartsWith("/"))
        path = "/" + path;
      try
      {
        this.ftpClient.DeleteDirectory(path);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw new ApplicationException("SslFtp RemoveDir failed for: " + RemotePath, ex);
      }
    }

    public void MakeDir(string newDirectory)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot make directory.  There is no valid connection.");
      try
      {
        if (this.CheckDirectory(newDirectory))
          return;
        try
        {
          this.ftpClient.CreateDirectory(newDirectory);
        }
        catch
        {
          string[] strArray = newDirectory.Split('/');
          ArrayList arrayList = new ArrayList();
          foreach (string str in strArray)
          {
            if (str.Length > 0)
              arrayList.Add((object) str);
          }
          StringBuilder stringBuilder = new StringBuilder();
          foreach (string str in (string[]) arrayList.ToArray(typeof (string)))
          {
            stringBuilder.Append("/" + str);
            if (!this.CheckDirectory(stringBuilder.ToString()))
              this.ftpClient.CreateDirectory(stringBuilder.ToString());
          }
        }
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw new ApplicationException("SslFtp MakeDir failed for: " + this.RemotePath, ex);
      }
    }

    public void RenameFile(string NewRemotePath, string OldRemotePath)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot rename file.  There is no valid connection.");
      try
      {
        this.ftpClient.Rename(OldRemotePath, NewRemotePath);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw new ApplicationException("SslFtp RenameFile failed for: " + OldRemotePath, ex);
      }
    }

    public void DeleteRemoteFile(string remotePath, string remoteFile)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot delete file.  There is no valid connection.");
      string str = remotePath.Trim();
      if (str.EndsWith("/"))
        str = str.Remove(str.Length - 1, 1);
      string path = str + "/" + remoteFile.Trim();
      try
      {
        this.ftpClient.DeleteFile(path);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw new ApplicationException("SslFtp DeleteRemoteFile failed for: " + path, ex);
      }
    }

    public void DeleteRemoteFile(string fullPathAndName)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot delete the file.  There is no valid connection.");
      try
      {
        this.ftpClient.DeleteFile(fullPathAndName);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw new ApplicationException("SslFtp DeleteRemoteFile failed for: " + fullPathAndName, ex);
      }
    }

    public bool CheckDirectory(string remoteDirectory)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot check the directory.  There is no valid connection.");
      try
      {
        if (!remoteDirectory.StartsWith("/"))
          remoteDirectory = "/" + remoteDirectory;
        return this.ftpClient.DirectoryExists(remoteDirectory);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        return false;
      }
    }

    public bool FileExists(string filePath)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot check the directory.  There is no valid connection.");
      try
      {
        return this.ftpClient.FileExists(filePath);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        return false;
      }
    }

    public void DownloadFiles(string remoteFolder, string destinationFolder, string pattern)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot check the directory.  There is no valid connection.");
      try
      {
        if (string.IsNullOrEmpty(pattern))
          pattern = "*.*";
        ((IRemoteFileSystem) this.ftpClient).DownloadFiles(remoteFolder, destinationFolder, pattern);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw ex;
      }
    }

    public void DeleteFilesInDirectory(string remoteFolder, string pattern)
    {
      if (!this.Connected)
        throw new ApplicationException("Cannot check the directory.  There is no valid connection.");
      try
      {
        if (string.IsNullOrEmpty(pattern))
          pattern = "*.*";
        this.ftpClient.DeleteDirectory(remoteFolder, RecursionMode.None, false, SearchCondition.Masks(pattern));
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw ex;
      }
    }

    public List<string> GetFileList(string remoteFolder)
    {
      List<string> stringList = new List<string>();
      if (!this.Connected)
        throw new ApplicationException("Cannot check the directory.  There is no valid connection.");
      try
      {
        foreach (FtpFileInfo ftpFileInfo in (IEnumerable<IFileInfo>) this.ftpClient.ListDirectory(remoteFolder))
          stringList.Add(ftpFileInfo.Name);
      }
      catch (Exception ex)
      {
        this.writeError(ex);
        this.ftpClient.Cancel();
        throw ex;
      }
      return stringList;
    }

    private void writeError(Exception ex)
    {
      if (!(ex is FtpException) && !(ex is ProxySocketException) || string.IsNullOrEmpty(ex.Message))
        return;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.AppendLine(ex.Message);
      if (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message))
        stringBuilder.AppendLine(ex.InnerException.Message);
      stringBuilder.AppendLine(ex.StackTrace);
      stringBuilder.AppendLine();
      this.writeError(3000, stringBuilder.ToString());
    }

    private void writeError(int errno, string errmsg)
    {
      if (!string.IsNullOrEmpty(this.errorLog))
      {
        DateTime now = DateTime.Now;
        string str = now.ToLongDateString() + " " + now.ToLongTimeString();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.AppendLine("A FTP Error Has Occurred:");
        stringBuilder.AppendLine("DateTimeStamp: " + str);
        stringBuilder.AppendLine("Error Number: " + errno.ToString());
        stringBuilder.AppendLine("Error Message: " + errmsg);
        if (this.StackTrace)
        {
          System.Diagnostics.StackTrace stackTrace = new System.Diagnostics.StackTrace();
          stringBuilder.AppendLine("Error StackTrace: " + stackTrace.ToString());
        }
        stringBuilder.AppendLine();
        using (Mutex mutex = new Mutex(false, "FTPWriteErrorLog"))
        {
          try
          {
            mutex.WaitOne();
            using (StreamWriter streamWriter = File.AppendText(this.errorLog))
            {
              using (TextWriter textWriter = TextWriter.Synchronized((TextWriter) streamWriter))
              {
                textWriter.WriteLine(stringBuilder.ToString());
                textWriter.Close();
                streamWriter.Close();
              }
            }
          }
          finally
          {
            mutex.ReleaseMutex();
            mutex.Close();
          }
        }
      }
      this.LastError = true;
      this.LastErrorText = errmsg;
    }
  }
}
