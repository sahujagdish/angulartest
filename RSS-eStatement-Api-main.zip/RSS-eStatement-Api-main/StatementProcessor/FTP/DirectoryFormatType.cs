﻿// Decompiled with JetBrains decompiler
// Type: Newkirk.Framework.SecureFtp.DirectoryFormatType
// Assembly: Newkirk.Framework, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1427E607-5760-4C73-AA04-06C2E8AE2795
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Newkirk.Framework.dll

namespace Newkirk.Framework.SecureFtp
{
  public enum DirectoryFormatType
  {
    Auto,
    Unix,
    Windows,
    VShell,
    UnknownDirectoryFormat,
  }
}
