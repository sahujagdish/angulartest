﻿// Decompiled with JetBrains decompiler
// Type: Statements.ConfigurationSettings
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using System.Configuration;

namespace Statements
{
  public class ConfigurationSettings
  {
        //public static string GetConfigurationAppSettingsValue(string key) => Rsct.Utilities.DataAccess.RootConfig.Instance.Configuration[key];// string.Empty;// !string.IsNullOrEmpty(key) ? ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location).AppSettings.Settings[key].Value : string.Empty;

        public static string GetConfigurationValue(string key) => Rsct.Utilities.DataAccess.RootConfig.Instance.Configuration[key];// string.Empty;//!string.IsNullOrEmpty(key) ? ConfigurationManager.OpenExeConfiguration(this.GetType().Assembly.Location).ConnectionStrings.ConnectionStrings[key].ConnectionString : string.Empty;
    }
}
