﻿// Decompiled with JetBrains decompiler
// Type: Statements.Constants
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

namespace Statements
{
  public static class Constants
  {
    public const string ProcessedSuccessfully = "Processed Successfully";
    public const string Tiled = "~";
    public const string BackWordSlash = "\\";
    public const string PDFExtension = ".PDF";
    public const string StatementNotification = "Statement Notification";
    public const string StatementFailureNotification = "Statement Failure Notification ";
    public const string ClientSuccessMessage = "The statements you requested from eStatement are available in the designated location.  They will be available for 30 days.";
    public const string ClientFailureMessage = "Oops! An issue has occurred with the generation of your requested statement(s) from eStatement.  Our internal team has been notified and is working to resolve this issue.  We apologize for the inconvenience.";
    public const string InternalFailureMessage = "An issue has occurred with the generation of statement(s) requested by ";
    public const string FTP = "FTP";
    public const string UIRepository = "UI Repository";
    public const string UIRepositoryInputLocation = "UIRepositoryInputLocation";
    public const string FTPOutputFileLocation = "FTPOutputFileLocation";
    public const string UIRepositoryLocation = "UIRepositoryLocation";
    public const string StatementConnection = "StatementConnection";
    public const string MailServer = "MailServer";
    public const string AdminEmail = "AdminEmail";
    public const string DeployedEnvironment = "Environment";
    public const string Error = "Error";
    public const string Admin = "admin";
    public const string Sponsor = "sponsor";
    public const string Statements = "statements";
    public const string assetRetention = "asset retention";
    public const string gapAnalysis = "gap analysis";
    public const string provider = "provider";
    public const string multiplePeriods = "_multipleperiods_";
  }
}
