﻿// Decompiled with JetBrains decompiler
// Type: Statements.MultipleStatementBuilder
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

//using Newkirk.Framework.Data;
using Statements.Business;
using Statements.Business.MultipleStatement;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Statements
{
    public static class MultipleStatementBuilder
    {
        public static List<Participant> GetParticipantsByProviderIDAndPlanNum(
          string providerID,
          string provID,
          string planNum,
          string userType,
          bool isSuperSponsor,
          bool assetRetention,
          string agentID,
          string iSID,
          bool hideSensitivePlans,
          byte useSSNPin)
        {
            string configurationConnestionValue = ConfigurationSettings.GetConfigurationValue("ConnectionStrings:eStatement");
            List<Participant> participantList = new List<Participant>();
            int minValue = int.MinValue;
            try
            {
                using (SqlConnection connection = new SqlConnection(configurationConnestionValue))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("pSearchParticipants", connection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@provID", ParameterDirection.Input, (object)provID));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@useSSNPin", ParameterDirection.Input, (object)useSSNPin));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@sPartID", ParameterDirection.Input, (object)string.Empty));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@lname", ParameterDirection.Input, (object)string.Empty));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@accessCode", ParameterDirection.Input, (object)string.Empty));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@bSuperSponsor", ParameterDirection.Input, (object)(isSuperSponsor)));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@bAssetRetention", ParameterDirection.Input, (object)(assetRetention)));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@agentID", ParameterDirection.Input, (object)agentID));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@iSID", ParameterDirection.Input, (object)iSID));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@hideSensitivePlans", ParameterDirection.Input, (object)(hideSensitivePlans)));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@start", ParameterDirection.Input, (object)0));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@limit", ParameterDirection.Input, (object)999));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@sortField", ParameterDirection.Input, (object)"lname"));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@sortDir", ParameterDirection.Input, (object)"ASC"));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@providerID", ParameterDirection.Input, (object)providerID));
                        sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@totalCount", ParameterDirection.Output, (object)minValue));
                        if (userType.ToLower().Equals("admin"))
                        {
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@sponPlans", ParameterDirection.Input, (object)string.Empty));
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@bSponsor", ParameterDirection.Input, (object)0));
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@planName", ParameterDirection.Input, (object)planNum));
                        }
                        else
                        {
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@sponPlans ", ParameterDirection.Input, (object)planNum));
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@planName", ParameterDirection.Input, (object)string.Empty));
                            sqlCommand.Parameters.Add(DataApi.CreateSqlParameter("@bSponsor", ParameterDirection.Input, (object)1));
                        }
                        connection.Open();
                        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlDataReader.Read())
                            {
                                try
                                {
                                    if (sqlDataReader.GetValue(0) != null)
                                    {
                                        Participant participant = new Participant()
                                        {
                                            PartId = sqlDataReader["part_id"].ToString().Trim(),
                                            PalnNum = sqlDataReader[nameof(planNum)].ToString().Trim(),
                                            UID = new Guid(sqlDataReader["uid"].ToString()),
                                            LastName = sqlDataReader["LName"].ToString(),
                                            FirstName = sqlDataReader["FName"].ToString()
                                        };
                                        participant.StatmentName = (participant.LastName.Length > 10 ? (object)participant.LastName.Substring(0, 10) : (object)participant.LastName).ToString() + (object)participant.FirstName[0];
                                        participantList.Add(participant);
                                    }
                                }
                                catch (Exception ex) { }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
                throw new Exception("Error occured while getting the participant info");
            }
            return participantList;
        }

        public static List<object> GetCommunicationTypeCDandScope(string neptuneID)
        {
            List<object> objectList = (List<object>)null;
            string configurationConnestionValue = ConfigurationSettings.GetConfigurationValue("ConnectionStrings:eStatement");
            //string configurationConnestionValue = new ConfigurationSettings().GetConfigurationConnestionValue("StatementConnection");
            try
            {
                using (SqlConnection connection = new SqlConnection(configurationConnestionValue))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("pGetProviderCommunications", connection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        sqlCommand.Parameters.Add("@NeptuneCustNo", SqlDbType.Char).Value = (object)neptuneID;
                        connection.Open();
                        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlDataReader.Read())
                            {
                                if (objectList == null)
                                    objectList = new List<object>();
                                objectList.Add(!string.IsNullOrEmpty(sqlDataReader["Descrip"].ToString()) ? (object)sqlDataReader["Descrip"].ToString() : (object)"");
                                objectList.Add(!string.IsNullOrEmpty(sqlDataReader["Scope"].ToString()) ? (object)sqlDataReader["Scope"].ToString() : (object)"");
                            }
                        }
                    }
                }
                return objectList;
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
                throw new Exception("Error occured in get provider communication");
            }
        }
    }
}