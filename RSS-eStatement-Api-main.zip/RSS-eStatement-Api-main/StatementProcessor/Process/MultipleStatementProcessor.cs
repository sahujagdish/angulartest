﻿// Decompiled with JetBrains decompiler
// Type: Statements.Process.MultipleStatementProcessor
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using Common.Utilities;
using iTextSharp.text;
using iTextSharp.text.pdf;
//using Newkirk.Framework.SecureFtp;
//using Newkirk.Framework.SecureFtp;
using Statements.Business;
using Statements.Business.MultipleStatement;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;

namespace Statements.Process
{
    public class MultipleStatementProcessor
    {
        CredentialCache credentialCache;
        IMailerService mailerService;
        public MultipleStatementProcessor(IMailerService mailerService)
        {
            this.mailerService = mailerService;
            SetCache();
        }

        public void SetCache()
        {
            var location = ConfigurationSettings.GetConfigurationValue("application:SharedLocation");
            var userName = ConfigurationSettings.GetConfigurationValue("application:username");
            var password = ConfigurationSettings.GetConfigurationValue("application:password");
            NetworkCredential theNetworkCredential = new NetworkCredential(userName, password);
            credentialCache = new CredentialCache();
            credentialCache.Add(new Uri(location), "Basic", theNetworkCredential);
        }

        //public string ProcessStatement(
        //  string firstName,
        //  string lastName,
        //  string nameList,
        //  string statementDates,
        //  string email,
        //  bool isOutputToFTP,
        //  bool isProcessAll,
        //  bool isSingleFile,
        //  string neptuneCustNo,
        //  string partId,
        //  string planNum,
        //  string plan_num,
        //  string provID,
        //  string uid,
        //  string userType,
        //  string providerid,
        //  string isSuperSponsor,
        //  string assetRetention,
        //  string agentID,
        //  string iSID,
        //  string hideSensitivePlans,
        //  string useSSNPin)
        //{
        //    string str = "Statement genertion process initiated";
        //    try
        //    {
        //        new MultipleStatementProcessor.AsyncMethodCaller(this.ProcessStatmentGeneration).BeginInvoke(firstName, lastName, nameList, statementDates, email, isOutputToFTP, isProcessAll, isSingleFile, neptuneCustNo, partId, planNum, plan_num, provID, uid, userType, providerid, isSuperSponsor, assetRetention, agentID, iSID, hideSensitivePlans, useSSNPin, (AsyncCallback)null, (object)null);
        //    }
        //    catch (Exception ex)
        //    {
        //        str = ex.Message;
        //        ExceptionLogging.LogError(ex);
        //    }
        //    return str;
        //}

        public ProcessResponse ProcessStatmentGeneration(
          string firstName,
          string lastName,
          string nameList,
          string statementDates,
          string email,
          bool isOutputToFTP,
          bool isProcessAll,
          bool isSingleFile,
          string neptuneCustNo,
          string partId,
          string planNum,
          string plan_num,
          string provID,
          string uid,
          string userType,
          string providerid,
          bool isSuperSponsor,
          bool assetRetention,
          string agentID,
          string iSID,
          bool hideSensitivePlans,
          byte useSSNPin)
        {
            var processResponse = new ProcessResponse();
            string empty1 = string.Empty;
            try
            {
                List<string> stringList = new List<string>();
                string empty2 = string.Empty;
                string empty3 = string.Empty;
                List<string> partIdList = (List<string>)null;
                List<string> uids = (List<string>)null;
                string empty4 = string.Empty;
                string empty5 = string.Empty;
                string empty6 = string.Empty;
                string empty7 = string.Empty;
                DateTime now = DateTime.Now;
                string dateFormatwithSec = now.ToString().GetDateFormatwithSec();
                List<TvpSSIdent> tvpSsIdentList = new List<TvpSSIdent>();
                List<string> list1;
                List<string> list2;
                List<string> list3;
                List<string> Namelist;
                if (isProcessAll)
                {
                    List<Participant> providerIdAndPlanNum = MultipleStatementBuilder.GetParticipantsByProviderIDAndPlanNum(providerid, provID, planNum, userType, isSuperSponsor, assetRetention, agentID, iSID, hideSensitivePlans, useSSNPin);
                    uids = ((IEnumerable<string>)uid.Split(',')).Select<string, string>((Func<string, string>)(c => c.ToLower())).ToList<string>();
                    partIdList = ((IEnumerable<string>)partId.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    providerIdAndPlanNum.RemoveAll((Predicate<Participant>)(x => partIdList.Contains(x.PartId) && uids.Contains(x.UID.ToString())));
                    list1 = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.FirstName.Trim())).ToList<string>();
                    list2 = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.LastName.Trim())).ToList<string>();
                    list3 = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.PalnNum.Trim())).ToList<string>();
                    Namelist = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.StatmentName.Trim())).ToList<string>();
                    partIdList = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.PartId)).ToList<string>();
                    uids = providerIdAndPlanNum.Select<Participant, string>((Func<Participant, string>)(c => c.UID.ToString())).ToList<string>();
                }
                else
                {
                    firstName = firstName.Replace('^', ' ');
                    list1 = ((IEnumerable<string>)firstName.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    lastName = lastName.Replace('^', ' ');
                    list2 = ((IEnumerable<string>)lastName.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    list3 = ((IEnumerable<string>)plan_num.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    partIdList = ((IEnumerable<string>)partId.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    nameList = nameList.Replace('^', ' ');
                    List<string> list4 = ((IEnumerable<string>)nameList.Split(',')).Select<string, string>((Func<string, string>)(c => c.Trim())).ToList<string>();
                    Namelist = new List<string>();
                    foreach (string str in list4)
                        Namelist.Add(str.Length > 11 ? str.Substring(0, 10) + str.Substring(str.Length - 1, 1) : str);
                    uids = ((IEnumerable<string>)uid.Split(',')).Select<string, string>((Func<string, string>)(c => c.ToLower())).ToList<string>();
                }
                List<object> communicationTypeCdandScope = MultipleStatementBuilder.GetCommunicationTypeCDandScope(neptuneCustNo);
                if (communicationTypeCdandScope.Count > 0)
                {
                    empty6 = Convert.ToString(communicationTypeCdandScope[0]);
                    empty7 = Convert.ToString(communicationTypeCdandScope[1]);
                }
                string appSettingsValue = ConfigurationSettings.GetConfigurationValue("StatementsDll:UIRepositoryInputLocation");
                string str1 = ConfigurationSettings.GetConfigurationValue("StatementsDll:UIRepositoryLocation");
                //string appSettingsValue = new ConfigurationSettings().GetConfigurationAppSettingsValue("UIRepositoryInputLocation");
                //string str1 = new ConfigurationSettings().GetConfigurationAppSettingsValue("UIRepositoryLocation");
                string empty8 = string.Empty;
                string empty9 = string.Empty;
                List<string> list5 = ((IEnumerable<string>)statementDates.Split(new char[1]
                {
          ','
                }, StringSplitOptions.RemoveEmptyEntries)).ToList<string>();
                if (partIdList.Count == 1)
                {
                    if (isSingleFile)
                    {
                        try
                        {
                            string tempoutputFilePath1;
                            if (userType.ToLower().Equals("admin"))
                                tempoutputFilePath1 = Path.Join(str1, provID, dateFormatwithSec);
                            else
                                tempoutputFilePath1 = Path.Join(str1, provID, plan_num, dateFormatwithSec);
                            MultipleStatementProcessor.createDirectory(tempoutputFilePath1);
                            string tempoutputFilePath2 = Path.Join(tempoutputFilePath1, plan_num + "_multipleperiods_" + Namelist[0] + partId.Substring(partId.Length - 4, 4) + ".PDF");
                            for (int index = 0; index < list5.Count<string>(); ++index)
                            {
                                string path = this.filePathCreation(appSettingsValue, provID, empty6, plan_num, list5[index], empty7, uids[0], userType);                                
                                if (File.Exists(path))
                                    stringList.Add(path);
                                else
                                    processResponse.MissingPdfFiles.Add(path);
                            }

                            if (stringList.Count > 0)
                            {
                                string combinedPdfFiles = this.createCombinedPDFFiles(provID, tempoutputFilePath2, partIdList, stringList, email);
                                TvpSSIdent tvpSsIdent = MultipleStatementProcessor.addingParticipantInfo(provID, partId, plan_num, firstName, lastName, uids[0], userType, isOutputToFTP, now.ToString());
                                tvpSsIdent.file_name = combinedPdfFiles;
                                tvpSsIdentList.Add(tvpSsIdent);
                                goto label_41;
                            }
                            else
                                goto label_41;
                        }
                        catch (Exception ex)
                        {
                            this.sentMail(email, false, true, string.Empty, string.Empty, string.Empty, string.Empty);
                            this.sentMail(string.Empty, false, false, providerid, plan_num, provID, planNum);
                            ExceptionLogging.LogError(ex);
                            goto label_41;
                        }
                    }
                }
                if (partIdList.Count > 1 && isSingleFile)
                {
                    for (int index = 0; index < partIdList.Count<string>(); ++index)
                    {
                        plan_num = list3[index];
                        string path = this.filePathCreation(appSettingsValue, provID, empty6, list3[index], list5[0], empty7, uids[index], userType);
                        
                        if (File.Exists(path))
                            stringList.Add(path);
                        else
                            processResponse.MissingPdfFiles.Add(path);
                    }

                    if (stringList.Count > 0)
                    {
                        List<ParticipantFile> participantFileList = new List<ParticipantFile>();
                        List<ParticipantFile> participantFiles = this.fileListwithSizeandName(stringList.ToList<string>());
                        List<string> outputFileGroup = new List<string>();
                        tvpSsIdentList = this.processPdfFilestoGroup(provID, partIdList, list5[0], list3, list1, list2, Namelist, participantFiles, str1, outputFileGroup, uids, userType, isOutputToFTP, now.ToString(), email);
                    }
                }
                else if (partIdList.Count > 1 && !isSingleFile)
                {
                    string outputDirctory = str1;
                    for (int index = 0; index < partIdList.Count<string>(); ++index)
                    {
                        plan_num = list3[index];
                        string str2 = this.filePathCreation(appSettingsValue, provID, empty6, list3[index], list5[0], empty7, uids[index], userType);
                        if (File.Exists(str2))
                        {
                            try
                            {
                                str1 = MultipleStatementProcessor.filePathCreation(provID, userType, str1, list3, dateFormatwithSec, outputDirctory, index);
                                string pdfFiles = this.createPDFFiles(list3[index], str1, list5[0], partIdList[index], Namelist[index], str2, email);
                                TvpSSIdent tvpSsIdent = MultipleStatementProcessor.addingParticipantInfo(provID, partIdList[index], list3[index], list1[index], list2[index], uids[index], userType, isOutputToFTP, now.ToString());
                                tvpSsIdent.file_name = pdfFiles;
                                tvpSsIdentList.Add(tvpSsIdent);
                            }
                            catch (Exception ex)
                            {
                                this.sentMail(email, false, true, string.Empty, string.Empty, string.Empty, string.Empty);
                                this.sentMail(string.Empty, false, false, providerid, plan_num, provID, planNum);
                                ExceptionLogging.LogError(ex);
                            }
                        }
                        else
                            processResponse.MissingPdfFiles.Add(str2);
                    }
                }
            label_41:
                if (tvpSsIdentList.Count <= 0)
                {
                    processResponse.Message = $"{ processResponse.MissingPdfFiles.Count} input statement files are missing.";
                    return processResponse;
                }

                processResponse.Success = true;
                if (isOutputToFTP)
                {
                    FTPInfo ftpInfo = this.getFTPInfo(providerid, userType);
                    if (ftpInfo != null)
                    {
                        List<string> failureFileNameList = this.sendToFTP(tvpSsIdentList, ftpInfo, processResponse);
                        
                        if (!processResponse.Success)
                            return processResponse;

                        tvpSsIdentList.ForEach((Action<TvpSSIdent>)(c => c.file_name = Path.GetFileName(c.file_name)));
                        if (failureFileNameList.Count > 0)
                            tvpSsIdentList.RemoveAll((Predicate<TvpSSIdent>)(c => failureFileNameList.Contains(c.file_name)));
                        if (tvpSsIdentList.Count > 0)
                            this.saveCombinedPDFFilesData(tvpSsIdentList);

                        processResponse.Message = $"Statement files proccessed and uploaded to FTP.";
                    }
                }
                else
                {
                    tvpSsIdentList.ForEach((Action<TvpSSIdent>)(c => c.file_name = Path.GetFileName(c.file_name)));
                    this.saveCombinedPDFFilesData(tvpSsIdentList);

                    processResponse.Message = $"Statement files proccessed and  uploaded to eStatement website accessible repository.";
                }
                if (string.IsNullOrEmpty(email))
                    return processResponse;
                this.sentMail(email, true, true, string.Empty, string.Empty, string.Empty, string.Empty);
                processResponse.IsMailSent = true;
            }
            catch (Exception ex)
            {
                processResponse.Success = false;
                processResponse.Message = $"Unable to proccess files.";
                this.sentMail(email, false, true, string.Empty, string.Empty, string.Empty, string.Empty);
                this.sentMail(string.Empty, false, false, providerid, plan_num, provID, planNum);
                ExceptionLogging.LogError(ex);
            }

            return processResponse;
        }

        private string filePathCreation(
          string pdfPath,
          string provID,
          string communicationDescrip,
          string planNum,
          string date,
          string communicationScope,
          string uid,
          string userType)
        {
            string empty = string.Empty;
            string str1 = string.Empty;
            if (communicationDescrip.ToLower() == "statements" || communicationDescrip.ToLower() == "asset retention" || communicationDescrip.ToLower() == "gap analysis")
                str1 = provID + "~" + planNum + "~" + uid + ".PDF";
            string str2;
            if (communicationScope.ToLower() == "provider")
                str2 = pdfPath + provID + "\\" + date.GetDateFormatInString() + "\\" + str1;
            else
                str2 = pdfPath + provID + "\\" + date.GetDateFormatInString() + "\\" + planNum + "\\" + str1;
            return str2;
        }

        private static string filePathCreation(
          string provID,
          string userType,
          string tempoutputFilePath,
          List<string> planNums,
          string DateSubmited,
          string outputDirctory,
          int i)
        {
            switch (userType.ToLower())
            {
                case "admin":
                    tempoutputFilePath = outputDirctory + provID + "\\" + DateSubmited + "\\";
                    break;
                case "sponsor":
                    tempoutputFilePath = outputDirctory + provID + "\\" + planNums[i] + "\\" + DateSubmited + "\\";
                    break;
            }
            return tempoutputFilePath;
        }

        private static void createDirectory(string tempoutputFilePath)
        {
            if (Directory.Exists(tempoutputFilePath))
                return;
            Directory.CreateDirectory(tempoutputFilePath);
        }

        private List<TvpSSIdent> processPdfFilestoGroup(
          string provID,
          List<string> partIDs,
          string date,
          List<string> planNums,
          List<string> firstNameList,
          List<string> lastNameList,
          List<string> Namelist,
          List<ParticipantFile> participantFiles,
          string outputFilePath,
          List<string> outputFileGroup,
          List<string> uids,
          string userType,
          bool isOutputToFTP,
          string DateSubmited,
          string email)
        {
            string str = string.Empty;
            List<string> stringList = new List<string>();
            string filename = string.Empty;
            List<TvpSSIdent> tvpSsIdentList1 = new List<TvpSSIdent>();
            List<TvpSSIdent> tvpSsIdentList2 = new List<TvpSSIdent>();
            List<string> source = new List<string>();
            long num = 0;
            try
            {
                for (int index = 0; index < participantFiles.Count<ParticipantFile>(); ++index)
                {
                    string fileName = participantFiles[index].FileName;
                    source.Add(fileName);
                    long length = new FileInfo(fileName).Length;
                    if (length + num <= 10485760L)
                    {
                        if (File.Exists(fileName))
                        {
                            outputFileGroup.Add(fileName);
                            num += length;
                            TvpSSIdent tvpSsIdent = MultipleStatementProcessor.addingParticipantInfo(provID, partIDs[index], planNums[index], firstNameList[index], lastNameList[index], uids[index], userType, isOutputToFTP, DateSubmited);
                            tvpSsIdentList2.Add(tvpSsIdent);
                        }
                    }
                    else if (length + num > 10485760L)
                    {
                        Guid.NewGuid();
                        if (string.IsNullOrEmpty(str))
                        {
                            string outputFileName = MultipleStatementProcessor.createOutputFileName(provID, outputFilePath, userType, DateSubmited, str, tvpSsIdentList2);
                            MultipleStatementProcessor.createDirectory(outputFileName);
                            tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname = tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname.Length > 10 ? tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname.Substring(0, 10) : tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname;
                            if (tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname.Length == 0)
                                tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname = " ";
                            str = outputFileName + tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().plan_num + "_" + date.GetDateFormatInString() + "_" + tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname + (object)tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname[0] + "_" + DateTime.Now.ToString().GetDateFormatwithSec() + ".PDF";
                        }
                        filename = this.createCombinedPDFFiles(provID, str, partIDs, outputFileGroup, email);
                        num = 0L;
                        str = string.Empty;
                        outputFileGroup = new List<string>();
                        tvpSsIdentList2.ForEach((Action<TvpSSIdent>)(c => c.file_name = filename));
                        tvpSsIdentList1.AddRange((IEnumerable<TvpSSIdent>)tvpSsIdentList2);
                        tvpSsIdentList2 = new List<TvpSSIdent>();
                        if (index != participantFiles.Count<ParticipantFile>() - 1 && source.Where<string>((Func<string, bool>)(c => !outputFileGroup.Contains(c))).Count<string>() > 0)
                        {
                            num += length;
                            TvpSSIdent tvpSsIdent = MultipleStatementProcessor.addingParticipantInfo(provID, partIDs[index], planNums[index], firstNameList[index], lastNameList[index], uids[index], userType, isOutputToFTP, DateSubmited);
                            tvpSsIdentList2.Add(tvpSsIdent);
                            outputFileGroup.Add(fileName);
                        }
                    }
                    if (index == participantFiles.Count<ParticipantFile>() - 1 && (tvpSsIdentList2.Count > 0 || source.Where<string>((Func<string, bool>)(c => !outputFileGroup.Contains(c))).Count<string>() > 0))
                    {
                        if (outputFileGroup.Count == 0 && index == participantFiles.Count<ParticipantFile>() - 1)
                            outputFileGroup.Add(participantFiles[index].FileName);
                        if (tvpSsIdentList2.Count == 0)
                        {
                            TvpSSIdent tvpSsIdent = MultipleStatementProcessor.addingParticipantInfo(provID, partIDs[index], planNums[index], firstNameList[index], lastNameList[index], uids[index], userType, isOutputToFTP, DateSubmited);
                            tvpSsIdentList2.Add(tvpSsIdent);
                        }
                        if (string.IsNullOrEmpty(str))
                        {
                            string outputFileName = MultipleStatementProcessor.createOutputFileName(provID, outputFilePath, userType, DateSubmited, str, tvpSsIdentList2);
                            MultipleStatementProcessor.createDirectory(outputFileName);
                            if (source.Count == outputFileGroup.Count)
                            {
                                str = outputFileName + tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().plan_num + "_" + date.GetDateFormatInString() + "_" + DateTime.Now.ToString().GetDateFormatwithSec() + ".PDF";
                            }
                            else
                            {
                                tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname = tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname.Length > 10 ? tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname.Substring(0, 10) : tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname;
                                if (tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname.Length == 0)
                                    tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname = " ";
                                str = outputFileName + tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().plan_num + "_" + date.GetDateFormatInString() + "_" + tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().lname + (object)tvpSsIdentList2.FirstOrDefault<TvpSSIdent>().fname[0] + "_" + DateTime.Now.ToString().GetDateFormatwithSec() + ".PDF";
                            }
                        }
                        filename = this.createCombinedPDFFiles(provID, str, partIDs, outputFileGroup, email);
                        outputFileGroup.Clear();
                        num = 0L;
                        str = string.Empty;
                        tvpSsIdentList2.ForEach((Action<TvpSSIdent>)(c => c.file_name = filename));
                        tvpSsIdentList1.AddRange((IEnumerable<TvpSSIdent>)tvpSsIdentList2);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
            }
            return tvpSsIdentList1;
        }

        private static string createOutputFileName(
          string provID,
          string outputFilePath,
          string userType,
          string DateSubmited,
          string outputFileName,
          List<TvpSSIdent> ss_ident1)
        {
            switch (userType.ToLower())
            {
                case "admin":
                    outputFileName = outputFilePath + provID + "\\" + DateSubmited.GetDateFormatwithSec() + "\\";
                    break;
                case "sponsor":
                    outputFileName = outputFilePath + provID + "\\" + ss_ident1.FirstOrDefault<TvpSSIdent>().plan_num + "\\" + DateSubmited.GetDateFormatwithSec() + "\\";
                    break;
            }
            return outputFileName;
        }

        private static TvpSSIdent addingParticipantInfo(
          string provID,
          string partIDs,
          string planNums,
          string fNameList,
          string lNameList,
          string uids,
          string userType,
          bool isOutputToFTP,
          string DateSubmited)
        {
            return new TvpSSIdent()
            {
                file_name = string.Empty,
                part_id = partIDs,
                position = 0,
                pages = 0,
                plan_num = planNums,
                rpt_date = DateTime.Now,
                isactive = 1,
                spon_num = planNums,
                provid = provID,
                trans_no = "0",
                fname = fNameList,
                lname = lNameList,
                uid = uids,
                platform = 0,
                batch = 0,
                IsSmart = 0,
                CommunicationTypeCD = userType,
                DateSubmited = DateSubmited,
                FileLocationTypeCD = isOutputToFTP ? "FTP" : "UI Repository"
            };
        }

        private List<ParticipantFile> fileListwithSizeandName(List<string> fileList)
        {
            List<ParticipantFile> participantFileList = new List<ParticipantFile>();
            try
            {
                foreach (string file in fileList)
                {
                    if (File.Exists(file))
                    {
                        long length = new FileInfo(file).Length;
                        participantFileList.Add(new ParticipantFile()
                        {
                            FileName = file,
                            FileSize = length
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
            }
            return participantFileList;
        }

        private string createCombinedPDFFiles(
          string provID,
          string tempoutputFilePath,
          List<string> partIDs,
          List<string> list,
          string fromEamil)
        {
            List<PdfReader> pdfReaderList = new List<PdfReader>();
            string str = string.Empty;
            try
            {
                if (list.Count<string>() > 0)
                {
                    foreach (string filename in list)
                    {
                        PdfReader pdfReader = new PdfReader(filename);
                        pdfReaderList.Add(pdfReader);
                    }
                    using (Document document = new Document(PageSize.A4, 0.0f, 0.0f, 0.0f, 0.0f))
                    {
                        PdfWriter instance = PdfWriter.GetInstance(document, (Stream)new FileStream(tempoutputFilePath, FileMode.Create, FileAccess.ReadWrite));
                        document.Open();
                        str = tempoutputFilePath;
                        foreach (PdfReader reader in pdfReaderList)
                        {
                            PdfReader.unethicalreading = true;
                            for (int pageNumber = 1; pageNumber <= reader.NumberOfPages; ++pageNumber)
                            {
                                PdfImportedPage importedPage = instance.GetImportedPage(reader, pageNumber);
                                document.Add((IElement)Image.GetInstance((PdfTemplate)importedPage));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
            }
            return str;
        }

        private string createPDFFiles(
          string planCode,
          string tempoutputFilePath,
          string date,
          string partIDs,
          string lastNames,
          string filePath,
          string fromEamil)
        {
            string path = string.Empty;
            try
            {
                PdfReader reader = new PdfReader(filePath);
                MultipleStatementProcessor.createDirectory(tempoutputFilePath);
                path = tempoutputFilePath + planCode + "_" + date.GetDateFormatInString() + "_" + lastNames.ToString() + partIDs.Substring(partIDs.Length - 4, 4).ToString() + ".pdf";
                using (Document document = new Document(PageSize.A4, 0.0f, 0.0f, 0.0f, 0.0f))
                {
                    PdfWriter instance = PdfWriter.GetInstance(document, (Stream)new FileStream(path, FileMode.Create, FileAccess.ReadWrite));
                    document.Open();
                    PdfReader.unethicalreading = true;
                    for (int pageNumber = 1; pageNumber <= reader.NumberOfPages; ++pageNumber)
                    {
                        PdfImportedPage importedPage = instance.GetImportedPage(reader, pageNumber);
                        document.Add((IElement)Image.GetInstance((PdfTemplate)importedPage));
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
            }
            return path;
        }

        private FTPInfo getFTPInfo(string ftpProviderID, string userType)
        {
            FTPInfo ftpInfo = (FTPInfo)null;
            try
            {
                string empty = string.Empty;
                string cmdText = !userType.ToLower().Equals("admin") ? "Select * from  FTPInfo f INNER JOIN Sponsor  s  ON s.FtpInfoID = f.FtpInfoID where s.SPON_ProviderID  = @ftpProviderID " : "Select * from  FTPInfo f INNER JOIN Provider p  ON p.FtpInfoID = f.FtpInfoID where p.ProviderID  = @ftpProviderID ";
                string configurationConnestionValue = ConfigurationSettings.GetConfigurationValue("ConnectionStrings:eStatement");
                using (SqlConnection connection = new SqlConnection(configurationConnestionValue))
                {
                    using (SqlCommand sqlCommand = new SqlCommand(cmdText, connection))
                    {
                        sqlCommand.Parameters.Add("@ftpProviderID", SqlDbType.Int);
                        sqlCommand.Parameters["@ftpProviderID"].Value = (object)Convert.ToInt32(ftpProviderID);
                        connection.Open();
                        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
                        {
                            while (sqlDataReader.Read())
                            {
                                if (sqlDataReader.GetValue(0) != null)
                                {
                                    ftpInfo = new FTPInfo();
                                    ftpInfo.ftpHost = sqlDataReader["Host"].ToString();
                                    ftpInfo.ftpName = sqlDataReader["Name"].ToString();
                                    ftpInfo.ftpUsername = sqlDataReader["UserName"].ToString();
                                    ftpInfo.ftpPassword = sqlDataReader["Password"].ToString();
                                    ftpInfo.ftpPort = (int)Convert.ToInt16(sqlDataReader["Port"].ToString());
                                    ftpInfo.ftpSecureTypeTypeCD = sqlDataReader["SecurityTypeTypeCD"].ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
                throw new Exception("Error occured in ftp info");
            }
            return ftpInfo;
        }

        private List<string> sendToFTP(List<TvpSSIdent> tvpSSIdentList,
          FTPInfo ftpInfo,ProcessResponse response)
        {
            var helper = new FTPHelper(ftpInfo);
            return helper.UploadFiles(tvpSSIdentList, response);  
            //string appSettingsValue = ConfigurationSettings.GetConfigurationValue("FTPOutputFileLocation");
            //string str = this.Decrypt(ftpInfo.ftpPassword);
            //List<string> stringList = new List<string>();

            //using (SslFtp sslFtp = new SslFtp())
            //
            //sslFtp.HostName = ftpInfo.ftpHost;
            //sslFtp.UserName = ftpInfo.ftpUsername;
            //sslFtp.Password = str;
            //sslFtp.Port = ftpInfo.ftpPort;
            //switch (ftpInfo.ftpSecureTypeTypeCD)
            //{
            //  case "1":
            //    sslFtp.Protocol = ProtocolType.FTP;
            //    break;
            //  case "2":
            //    sslFtp.Protocol = ProtocolType.SSL;
            //    break;
            //  case "3":
            //    sslFtp.Protocol = ProtocolType.SSH;
            //    break;
            //  default:
            //    throw new Exception("FtpSecurityType of Unknown is not supported!");
            //}
            //sslFtp.Connect();
            //foreach (TvpSSIdent tvpSsIdent in tvpSSIdentList)
            //{
            //  string fileName = Path.GetFileName(tvpSsIdent.file_name);
            //  try
            //  {
            //    string newDirectory = (Path.GetDirectoryName(tvpSsIdent.file_name).Replace(new ConfigurationSettings().GetConfigurationAppSettingsValue("UIRepositoryLocation"), appSettingsValue) + "/").Replace("\\", "/");
            //    sslFtp.MakeDir(newDirectory);
            //    sslFtp.PutFile(tvpSsIdent.file_name, newDirectory + fileName);
            //    File.Delete(tvpSsIdent.file_name);
            //  }
            //  catch (Exception ex)
            //  {
            //    stringList.Add(Path.GetFileName(tvpSsIdent.file_name));
            //    ExceptionLogging.LogError(ex);
            //    throw new Exception();
            //  }
            //}
            //sslFtp.Disconnect();
            //}
            //return stringList;
        }

        private void saveCombinedPDFFilesData(List<TvpSSIdent> ss_ident)
        {
            string configurationConnestionValue = ConfigurationSettings.GetConfigurationValue("ConnectionStrings:eStatement");
            try
            {
                using (SqlConnection connection = new SqlConnection(configurationConnestionValue))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("usp_insert_update_ss_ident", connection))
                    {
                        sqlCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dataTable = ss_ident.ToDataTable<TvpSSIdent>();
                        sqlCommand.Parameters.AddWithValue("@tvp_ss_idnet", (object)dataTable).SqlDbType = SqlDbType.Structured;
                        connection.Open();
                        sqlCommand.ExecuteNonQuery();
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
                throw new Exception();
            }
        }

        private void sentMail(
          string toMail,
          bool IsSucess,
          bool isclient,
          string providerId,
          string planCode,
          string provID,
          string planName)
        {
            try
            {
                //if (new ConfigurationSettings().GetConfigurationAppSettingsValue("Environment").ToLower().Equals("local"))
                //    return;
                int num = IsSucess ? 1 : 0;
                if (string.IsNullOrEmpty(toMail))
                    toMail = ConfigurationSettings.GetConfigurationValue("StatementsDll:AdminEmail");
#if DEBUG
                toMail = ConfigurationSettings.GetConfigurationValue("Mail:ToEmail");
#endif
                MailMessage message = new MailMessage("DoNotReply-eStatements@dstrs.com", toMail);
                SmtpClient smtpClient = new SmtpClient();
                smtpClient.Port = 25;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Host = ConfigurationSettings.GetConfigurationValue("Mail:Server");

                if (IsSucess)
                {
                    message.Subject = "Statement Notification";
                    message.Body = "The statements you requested from eStatement are available in the designated location.  They will be available for 30 days.";
                }
                else if (!IsSucess && isclient)
                {
                    message.Subject = "Statement Failure Notification ";
                    message.Body = "Oops! An issue has occurred with the generation of your requested statement(s) from eStatement.  Our internal team has been notified and is working to resolve this issue.  We apologize for the inconvenience.";
                }
                else if (!IsSucess && !isclient)
                {
                    message.Subject = "Statement Failure Notification ";
                    MailMessage mailMessage1 = message;
                    mailMessage1.Subject = mailMessage1.Subject + "_" + providerId + "_" + planCode;
                    message.Body = "An issue has occurred with the generation of statement(s) requested by ";
                    MailMessage mailMessage2 = message;
                    mailMessage2.Body = mailMessage2.Body + provID + " for " + planName;
                }
                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                ExceptionLogging.LogError(ex);
            }
        }

        private delegate void AsyncMethodCaller(
          string firstName,
          string lastName,
          string nameList,
          string statementDates,
          string email,
          bool isOutputToFTP,
          bool isProcessAll,
          bool isSingleFile,
          string neptuneCustNo,
          string partId,
          string planNum,
          string plan_num,
          string provID,
          string uid,
          string userType,
          string providerid,
          string isSuperSponsor,
          string assetRetention,
          string agentID,
          string iSID,
          string hideSensitivePlans,
          string useSSNPin);
    }
}