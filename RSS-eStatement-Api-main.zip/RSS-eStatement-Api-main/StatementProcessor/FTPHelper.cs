﻿using Renci.SshNet;
using Statements.Business;
using Statements.Business.MultipleStatement;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Statements
{
    public class FTPHelper
    {
        IGenericFtpClient client;

        public FTPHelper(FTPInfo ftpInfo)
        {
#if DEBUG
            ftpInfo.ftpHost = ConfigurationSettings.GetConfigurationValue("StatementsDll:Ftp_Host");
            ftpInfo.ftpUsername = ConfigurationSettings.GetConfigurationValue("StatementsDll:Ftp_Username");
            ftpInfo.ftpPassword = ConfigurationSettings.GetConfigurationValue("StatementsDll:Ftp_Password");
            ftpInfo.ftpPort = Convert.ToInt32(ConfigurationSettings.GetConfigurationValue("StatementsDll:Ftp_Port"));

            if (ConfigurationSettings.GetConfigurationValue("StatementsDll:Ftp_Protocol") == "ssh")
            {
                 client = new SSHFTPClient(ftpInfo);
            }
            else
            {
                client = new FluentFTPClient(ftpInfo);
            }
            return;
#endif

            ftpInfo.ftpPassword = Decrypt(ftpInfo.ftpPassword);
            switch (ftpInfo.ftpSecureTypeTypeCD)
            {
                case "1":
                case "2":
                    client = new FluentFTPClient(ftpInfo);
                    break;

                case "3":
                    client = new SSHFTPClient(ftpInfo);
                    break;

                default:
                    client = new FluentFTPClient(ftpInfo);
                    break;
            }
        }

        public List<string> UploadFiles(List<TvpSSIdent> tvpSSIdentList, ProcessResponse response)
        {
            using (client)
            {
                string appSettingsValue = ConfigurationSettings.GetConfigurationValue("StatementsDll:FTPOutputFileLocation");
                List<string> stringList = new List<string>();
                List<string> filesToDelete = new List<string>();

                client.Connect();
                foreach (TvpSSIdent tvpSsIdent in tvpSSIdentList)
                {
                    string fileName = Path.GetFileName(tvpSsIdent.file_name);
                    try
                    {
                        string newDirectory = (Path.GetDirectoryName(tvpSsIdent.file_name).Replace
                                (ConfigurationSettings.GetConfigurationValue("StatementsDll:UIRepositoryLocation"), appSettingsValue) + "/")
                                .Replace("\\", "/");

                        CreateFolders(appSettingsValue, newDirectory);
                        client.UploadFile(tvpSsIdent.file_name, newDirectory + fileName);
                        filesToDelete.Add(tvpSsIdent.file_name);
                    }
                    catch (Exception ex)
                    {
                        stringList.Add(Path.GetFileName(tvpSsIdent.file_name));
                        ExceptionLogging.LogError(ex);
                        response.Success = false;
                        response.Message = ex.Message;
                        break;
                    }
                }
                client.Disconnect();

                foreach (var item in filesToDelete)
                {
                    try
                    {
                        File.Delete(item);
                    }
                    catch (Exception x)
                    {
                        response.Success = false;
                        response.Message = x.Message;
                    }
                }
                return stringList;
            }
        }

        protected void CreateFolders(string rootFolder, string completePath)
        {   
            var remotePath = rootFolder;
            var path = completePath.Replace(rootFolder, "");
            if (!client.DirectoryExists(remotePath))
                client.CreateDirectory(remotePath);
            foreach (var item in path.Split('/'))
            {
                remotePath += "/" + item;
                if (!client.DirectoryExists(remotePath))
                    client.CreateDirectory(remotePath);
            }
        }

        protected string Decrypt(string cipherText)
        {
            if (string.IsNullOrEmpty(cipherText))
                return cipherText;

            string password = "MAKV2SPBNI99212";
            byte[] buffer = Convert.FromBase64String(cipherText);
            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, new byte[13]
                {
          (byte) 73,
          (byte) 118,
          (byte) 97,
          (byte) 110,
          (byte) 32,
          (byte) 77,
          (byte) 101,
          (byte) 100,
          (byte) 118,
          (byte) 101,
          (byte) 100,
          (byte) 101,
          (byte) 118
                });
                aes.Key = rfc2898DeriveBytes.GetBytes(32);
                aes.IV = rfc2898DeriveBytes.GetBytes(16);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(buffer, 0, buffer.Length);
                        cryptoStream.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(memoryStream.ToArray());
                }
            }
            return cipherText;
        }
    }

    public interface IGenericFtpClient : IDisposable
    {
        bool DirectoryExists(string path);
        void Connect();
        void Disconnect();
        void CreateDirectory(string path);
        void UploadFile(string localPath, string remotePath);
    }

    public class FluentFTPClient : IGenericFtpClient
    {
        FTPInfo ftpInfo;
        FluentFTP.FtpClient ftpClient;
        public FluentFTPClient(FTPInfo ftpInfo)
        {
            this.ftpInfo = ftpInfo;
            if (ftpInfo.ftpSecureTypeTypeCD == "1")
            {
                ftpClient = new FluentFTP.FtpClient(ftpInfo.ftpHost, ftpInfo.ftpUsername, ftpInfo.ftpPassword);
            }
            else
            {
                var port = ftpInfo.ftpPort > 0 ? ftpInfo.ftpPort : 21;
                ftpClient = new FluentFTP.FtpClient(ftpInfo.ftpHost, port, ftpInfo.ftpUsername, ftpInfo.ftpPassword);
                ftpClient.EncryptionMode = FluentFTP.FtpEncryptionMode.Auto;
            }

            ftpClient.ValidateCertificate += new FluentFTP.FtpSslValidation(OnValidateCertificate);

            //ftpClient.DataConnectionEncryption = true;
            //var cer = new X509Certificate2(certificate);
            //ftpClient.ClientCertificates.Add(cer);
            //System.Net.ServicePointManager.ServerCertificateValidationCallback = ServerCertificateValidationCallback;
//#endif
        }

        void OnValidateCertificate(FluentFTP.FtpClient control, FluentFTP.FtpSslValidationEventArgs e)
        {
            // add logic to test if certificate is valid here
            e.Accept = true;
        }

        private bool ServerCertificateValidationCallback(object sender, X509Certificate certificate,
                                        X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        public bool DirectoryExists(string path) { return ftpClient.DirectoryExists(path); }

        public void Connect()
        {
            ftpClient.Connect();
        }

        public void CreateDirectory(string path)
        {
            ftpClient.CreateDirectory(path);
        }

        public void Disconnect()
        {
            ftpClient.Disconnect();
        }

        public void UploadFile(string localPath, string remotePath)
        {
            ftpClient.UploadFile(localPath, remotePath);
        }

        public void Dispose()
        {
            if (ftpClient == null) return;
            if (ftpClient.IsConnected)
                ftpClient.Disconnect();
        }
    }

    public class SSHFTPClient : IGenericFtpClient
    {
        FTPInfo ftpInfo;
        SftpClient ftpClient;

        public SSHFTPClient(FTPInfo ftpInfo)
        {
            this.ftpInfo = ftpInfo;
            var port = ftpInfo.ftpPort > 0 ? ftpInfo.ftpPort : 22;
            ftpClient = new SftpClient(ftpInfo.ftpHost, port,
                ftpInfo.ftpUsername, ftpInfo.ftpPassword);
        }

        public bool DirectoryExists(string path)
        {
            return ftpClient.Exists(path);
        }

        public void Connect()
        {            
            ftpClient.Connect();
        }

        public void CreateDirectory(string newDirectory)
        {
            ftpClient.CreateDirectory(newDirectory);            
        }

        public void Disconnect()
        {
            ftpClient.Disconnect();
        }

        public void UploadFile(string localFilePath,string remoteFilePath)
        {
            var fileStream = File.OpenRead(localFilePath);
            ftpClient.UploadFile(fileStream, remoteFilePath);
            fileStream.Close();
        }

        public void Dispose()
        {
            if (ftpClient == null) return;
            if (ftpClient.IsConnected)
                ftpClient.Disconnect();
        }
    }
}
