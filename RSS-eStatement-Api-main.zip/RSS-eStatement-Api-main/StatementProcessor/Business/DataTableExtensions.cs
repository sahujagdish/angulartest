﻿// Decompiled with JetBrains decompiler
// Type: Statements.Business.DataTableExtensions
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

namespace Statements.Business
{
  public static class DataTableExtensions
  {
    public static DataTable ToDataTable<T>(this IList<T> data)
    {
      PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof (T));
      DataTable dataTable = new DataTable();
      for (int index = 0; index < properties.Count; ++index)
      {
        PropertyDescriptor propertyDescriptor = properties[index];
        dataTable.Columns.Add(propertyDescriptor.Name, propertyDescriptor.PropertyType);
      }
      object[] objArray = new object[properties.Count];
      foreach (T obj in (IEnumerable<T>) data)
      {
        for (int index = 0; index < objArray.Length; ++index)
          objArray[index] = properties[index].GetValue((object) obj);
        dataTable.Rows.Add(objArray);
      }
      return dataTable;
    }
  }
}
