﻿// Decompiled with JetBrains decompiler
// Type: Statements.Business.ExceptionLogging
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using System;
using System.IO;

namespace Statements.Business
{
  public static class ExceptionLogging
  {
    public static void LogError(Exception ex)
    {
      try
      {
        string appSettingsValue = ConfigurationSettings.GetConfigurationValue("StatementsDll:Error");
        if (!Directory.Exists(appSettingsValue))
          Directory.CreateDirectory(appSettingsValue);
        string path = appSettingsValue + DateTime.Now.ToString("yyyyMMdd") + ".txt";
        if (!File.Exists(path))
          File.Create(path).Dispose();
        using (StreamWriter streamWriter = File.AppendText(path))
        {
          streamWriter.WriteLine("Log Written Date:  " + DateTime.Now.ToString());
          streamWriter.WriteLine("Start--------------------------------------");
          streamWriter.WriteLine("Error LineNo: = " + ex.StackTrace.Substring(ex.StackTrace.Length - 8, 8));
          streamWriter.WriteLine("Error Message: = " + ex.GetType().Name.ToString());
          streamWriter.WriteLine("Exception Type: = " + ex.GetType().ToString());
          streamWriter.WriteLine("Error Location: = " + ex.Message.ToString());
          streamWriter.WriteLine("--------------------------------------End");
          streamWriter.WriteLine(Environment.NewLine);
          streamWriter.Flush();
          streamWriter.Close();
        }
      }
      catch (Exception ex1)
      {
        ex1.ToString();
      }
    }
  }
}
