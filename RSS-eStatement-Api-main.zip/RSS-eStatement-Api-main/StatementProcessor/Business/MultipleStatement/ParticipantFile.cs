﻿// Decompiled with JetBrains decompiler
// Type: Statements.Business.MultipleStatement.ParticipantFile
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

namespace Statements.Business.MultipleStatement
{
  public class ParticipantFile
  {
    public string FileName { get; set; }

    public long FileSize { get; set; }
  }
}
