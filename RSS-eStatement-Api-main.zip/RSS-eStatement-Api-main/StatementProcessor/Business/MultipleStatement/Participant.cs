﻿// Decompiled with JetBrains decompiler
// Type: Statements.Business.MultipleStatement.Participant
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using System;

namespace Statements.Business.MultipleStatement
{
  public class Participant
  {
    public string PartId { get; set; }

    public string PalnNum { get; set; }

    public Guid UID { get; set; }

    public string FirstName { get; set; }

    public string LastName { get; set; }

    public string StatmentName { get; set; }

    public string SSN { get; set; }
  }
}
