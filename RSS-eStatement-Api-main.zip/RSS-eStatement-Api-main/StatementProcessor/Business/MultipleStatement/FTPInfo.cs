﻿// Decompiled with JetBrains decompiler
// Type: Statements.Business.MultipleStatement.FTPInfo
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

namespace Statements.Business.MultipleStatement
{
  public class FTPInfo
  {
    public string ftpName { get; set; }

    public string ftpHost { get; set; }

    public string ftpUsername { get; set; }

    public string ftpPassword { get; set; }

    public int ftpPort { get; set; }

    public string ftpSecureTypeCD { get; set; }

    public string ftpSecureTypeTypeCD { get; set; }
  }
}
