﻿// Decompiled with JetBrains decompiler
// Type: Statements.TestCF
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

namespace Statements
{
  public class TestCF
  {
    public string Hello() => "Hi From Dotnet";
  }
}
