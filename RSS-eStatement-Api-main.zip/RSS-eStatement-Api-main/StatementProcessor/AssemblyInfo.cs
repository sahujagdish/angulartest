﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("Statements")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2016")]
[assembly: Guid("b3aac792-c5af-4d4f-95e6-a45eb528befd")]
[assembly: AssemblyProduct("Statements")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
