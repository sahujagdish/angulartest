﻿// Decompiled with JetBrains decompiler
// Type: Statements.StringExtensions
// Assembly: Statements, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 62CB0B71-FFC2-4A65-8AE0-1A8A1E12F262
// Assembly location: C:\Users\dt231131\Downloads\dotNetProxy\dotNetProxy\Statements.dll

using System;

namespace Statements
{
  public static class StringExtensions
  {
    public static string GetDateFormatInString(this string dateValue)
    {
      string empty = string.Empty;
      if (!string.IsNullOrEmpty(dateValue))
        empty = Convert.ToDateTime(dateValue).ToString("yyyyMMdd");
      return empty;
    }

    public static string GetDateFormatwithSec(this string dateValue)
    {
      string empty = string.Empty;
      if (!string.IsNullOrEmpty(dateValue))
        empty = Convert.ToDateTime(dateValue).ToString("yyyyMMdd_HHmmss");
      return empty;
    }
  }
}
