/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : tdPlanEnotifyOverrideType
/// Filename : tdPlanEnotifyOverrideType.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for tdPlanEnotifyOverrideType.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:26:40 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	public partial class tdPlanEnotifyOverrideType
	{
		#region Constructors / Destructors 
		public tdPlanEnotifyOverrideType()
		{
		}
		#endregion
	}
}