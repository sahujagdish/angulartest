/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : vProviderSettings
/// Filename : vProviderSettings.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for vProviderSettings.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:32:22 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	public partial class vProviderSettings
	{
		#region Constructors / Destructors 
		#endregion
	}
}