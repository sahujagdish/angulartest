/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : teProviderLogo
/// Filename : teProviderLogo.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for teProviderLogo.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:27:50 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	public partial class teProviderLogo
	{
		#region Constructors / Destructors 
		public teProviderLogo()
		{
		}
		#endregion
	}
}