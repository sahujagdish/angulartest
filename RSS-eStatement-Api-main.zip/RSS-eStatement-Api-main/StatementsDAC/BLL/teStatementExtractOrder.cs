/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : teStatementExtractOrder
/// Filename : teStatementExtractOrder.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for teStatementExtractOrder.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:29:45 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	public partial class teStatementExtractOrder
	{
		#region Constructors / Destructors 
		public teStatementExtractOrder()
		{
		}
		#endregion
	}
}