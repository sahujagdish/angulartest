/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : tdStatementExtractReportType
/// Filename : tdStatementExtractReportType.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for tdStatementExtractReportType.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:26:46 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	public partial class tdStatementExtractReportType
	{
		#region Constructors / Destructors 
		public tdStatementExtractReportType()
		{
		}
		#endregion
	}
}