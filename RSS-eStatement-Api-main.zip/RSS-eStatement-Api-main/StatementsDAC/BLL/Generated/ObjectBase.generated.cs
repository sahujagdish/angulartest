/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.BLL
/// Class	 : ObjectBase
/// Filename : ObjectBase.generated.cs
/// Copyright: SS&C 2022
///
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for ObjectBase.
/// </summary>
///
/// <remarks>
/// </remarks>
/// -----------------------------------------------------------------------------
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.DAL;

namespace StatementsDAC.BLL
{
	/// <summary>
	/// Abstract class for all View Objects
	/// </summary>
	[Serializable, DataContract]
    public abstract partial class ObjectBase
    {
        #region Methods
		/// <summary>
		/// Serializes object to XML string
		/// </summary>
		public string ToXml()
		{
			StringWriter xmlStream = new StringWriter();
			using(XmlTextWriter writer = new XmlTextWriter(xmlStream))
			{
				DataContractSerializer serializer = new DataContractSerializer(this.GetType());
				serializer.WriteObject(writer, this);
				return xmlStream.ToString();
			}
		}

		/// <summary>
		/// Deserialized object from XML string
		/// </summary>
		public static T FromXml<T>(string xml)
		{
			using (XmlTextReader reader = new XmlTextReader(new StringReader(xml)))
			{
				DataContractSerializer serializer = new DataContractSerializer(typeof(T));
				return (T)serializer.ReadObject(reader);
			}
		}
		
		/// <summary>
		/// Bind current DbContext Property Encryptor to the given property
		/// </summary>
		/// <param name="property">Instance of the IEncryptedProperty</param>
		protected internal static void BindEncryptor(IEncryptedProperty property)
		{
			if (property != null)
			{
				property.Encryptor = DbContext.ConnectionOptions.PropertyValueEncryptor;
			}
		}
		#endregion
    }
}
