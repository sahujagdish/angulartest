/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.DAL
/// Class	 : tdStatementExtractReportTypeDATA
/// Filename : tdStatementExtractReportTypeDATA.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for tdStatementExtractReportType.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:26:46 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.BLL;

namespace StatementsDAC.DAL
{
	internal partial class tdStatementExtractReportTypeDATA
	{
		#region Constructors / Destructors 
		#endregion
	}
}
