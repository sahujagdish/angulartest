/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.DAL
/// Class	 : tePlanEnotifyOverrideSettingsDATA
/// Filename : tePlanEnotifyOverrideSettingsDATA.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for tePlanEnotifyOverrideSettings.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:27:13 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.BLL;

namespace StatementsDAC.DAL
{
	internal partial class tePlanEnotifyOverrideSettingsDATA
	{
		#region Constructors / Destructors 
		#endregion
	}
}
