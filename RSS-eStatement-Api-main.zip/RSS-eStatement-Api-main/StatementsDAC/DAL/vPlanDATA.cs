/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.DAL
/// Class	 : vPlanDATA
/// Filename : vPlanDATA.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for vPlan.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:32:08 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.BLL;
using System.Data.SqlClient;
using System.Data;

namespace StatementsDAC.DAL
{
	internal partial class vPlanDATA
	{
		#region Constructors / Destructors 
		#endregion

		public static vPlan FillByProviderAndExternalID(Guid guid, string externalId)
		{
			using (DbConnectionScope scope = new DbConnectionScope(DbContext.ConnectionOptions))
			using (SqlCommand cmd = scope.CreateStoredProcCommand("[dbo].[pFillvPlanByProviderAndExternalID]"))
			{
				scope.AddInParameter(cmd, "@ProviderId", SqlDbType.UniqueIdentifier, 16, guid);
				scope.AddInParameter(cmd, "@ExternalPlanId", SqlDbType.VarChar, 100, externalId);

				using (SqlDataReader reader = cmd.ExecuteReader())
				{
					return DbContext.GetObject<vPlan>(reader, MapFromDataReader);
				}
			}
		}
	}
}
