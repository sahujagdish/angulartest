/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.DAL
/// Class	 : vFeedFilesDATA
/// Filename : vFeedFilesDATA.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for vFeedFiles.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:32:02 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.BLL;

namespace StatementsDAC.DAL
{
	internal partial class vFeedFilesDATA
	{
		#region Constructors / Destructors 
		#endregion
	}
}
