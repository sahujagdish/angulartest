/// -----------------------------------------------------------------------------
/// Project	 : StatementsDAC
/// Namespace: StatementsDAC.DAL
/// Class	 : vSetup_ProviderSettingsDATA
/// Filename : vSetup_ProviderSettingsDATA.cs
/// Copyright: SS&C 2021
/// 
/// -----------------------------------------------------------------------------
/// <summary>
/// Summary description for vSetup_ProviderSettings.
/// </summary>
///
/// <remarks>
/// </remarks>
/// 
/// <history>
/// 	[DT231131]	11/05/2021 16:32:23 PM created.
/// </history>
/// -----------------------------------------------------------------------------
using System;
using System.Linq;
using System.Configuration;
using System.Collections.Generic;
using System.Xml.Serialization;
using Rsct.Utilities.DataAccess;
using StatementsDAC.BLL;

namespace StatementsDAC.DAL
{
	internal partial class vSetup_ProviderSettingsDATA
	{
		#region Constructors / Destructors 
		#endregion
	}
}
