﻿using StatementsDAC.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rsct.Utilities.DataAccess;

namespace StatementsDAC.Service
{
    public interface INotificationService
    {
        string InsertUpdatePlanNotifySettings(Guid providerId, string externalPlanId, string content, int settingType);
    }

    public class NotificationService : INotificationService
    {
        public string InsertUpdatePlanNotifySettings(Guid providerId, string externalPlanId, string content, int settingType)
        {
            using (DbConnectionScope scope = new DbConnectionScope(DbContext.ConnectionOptions))
            using (SqlCommand cmd = scope.CreateStoredProcCommand("[dbo].[pInsertUpdatePlanNotifySettings]"))
            {
                scope.AddInParameter(cmd, "@ProviderId", SqlDbType.UniqueIdentifier, 16, providerId);
                scope.AddInParameter(cmd, "@ExternalPlanId", SqlDbType.VarChar, 100, externalPlanId);
                scope.AddInParameter(cmd, "@Content", SqlDbType.VarChar, content.Length, content);
                scope.AddInParameter(cmd, "@PlanEnotifyOverrideTypeCD", SqlDbType.TinyInt, 1, settingType);

                var response = cmd.ExecuteScalar();
                return response as string;
            }
        }
    }
}
