﻿*******************************************************************************
* This document conatins a short summary on project generation options of the 
* [RSCT DAL Template Wizard] tool.
*
* Complete developers guide can be found at: 
*     http://sharepoint.wealthmsi.com/InfoTech/Shared%20Documents/Development/ - Data Access Layer Generation Tool.docx
*******************************************************************************

The RSCT DAL Template Wizard is a code generation tool created by RSCT to standardize development 
of Data Access and Business Logic layers for Web Applications with "Database First" approach. 
The generated code is based on Active Record Pattern.

Configuration:
------------
	The RSCT Visual Studio Extensions package must be installed in order to re-generate BLL/DAL project. This 
	extension can be found under RSCT Private Gallery section of Visual Studion Extension Manager. Once installed
	the project Context Menu will have an 'Update BLL/DAL' menu option to access code generation Wizard. Please
	refer to the developers guide for more information.

Screen 1
Options - Specify DAL project generation options:
------------
SQL Connection String: Connection string to the database.
Namespace: Namespace prefix used in the project.
Connection String Key:  Key used to read the connection string from the configuration file.


Preferences:
------------
- Get All:	This option will generate static method IList<T> GetAll(). Used to load
			data from relatively small tables for caching in middle tier or UI. * When using Soft Delete
			also creates GetAllActive() which returns all records where IsDeleted = false.

- Save:		Generate instance method void Save(string savedBy). Saves instance of the object 
			to the database. If "Lazy Load Relationships" option selected, will save loaded 
			children instances.

- Soft Delete:	Generate instance method void SoftDelete(string deletedBy). This is "Soft delete"
				from database.  *REQUIREMENT:  Table MUST have IsDeleted bit not null column, otherwise
				the method is not created.

- Delete:	Generate static method bool DeleteById(PK1[, PK2, …]). This is “Hard delete” 
			from database - can be used to delete objects from database without loading first. 
			Allows efficient way to implement delete confirmation dialogs in Web Application.

- Bulk Insert/Update:
			Generate two static methods:
			void BulkInsert(IEnumerable<T> items, int batchSize, IEnumerable<IPropertyMap<T>> propertyMappings)
			void BulkUpdate(IEnumerable<T> items, int batchSize)

			This is very fast one way push to database. Executing an extremely large batch could decrease performance. 
			Therefore, you should test for the optimum batch size setting before implementing your application.
			Value of updateBatchSize = 0 removes limit on the batch size, and value of updateBatchSize = 1 disables batch updating.
			Note: Partial updates not supported in bulk update call, but bulk insert supports partial properties.

- Inheritance:
			Generate code with class inheritance based on the foreign key relationship. The Inheritance chain is determined based on 
			the FK relation sequence. The Foreign Key should be 1 to 1 relationship to the parent and include all Primary Key columns.
			The generated code is based on the Table per Type (TPT) inheritance pattern.

- Convert To Upper Case:
			Convert string values to Upper case before storing in Database.

- Update Logging:
			Generate code in property set to track value changes and store in UpdateHistory table.
			*Requirement - 
				1. UpdateHistory and UpdateHistoryRow tables must exist in database for tracking (Code Generator will create this).
				2. Database tables must have primary key's for tracking.
				3. On Second screen of code generator, Change Data Tracking (CDT) must be selected for table.

- Lazy Load Relationships:
			Generate code to create properties based on Foreign Key relationships using Lazy Load pattern.

- Generate Lookup Enum
			Generate enums based on the values in Lookup table
			*Requirement - Lookup table must exist in database.  Must have the following format:
			*Script available at bottom of this readme.
			  Table name [Lookup](
				[LookupId] [int] NOT NULL,
				[GroupName] [varchar](50) NOT NULL,
				[Value] [varchar](75) NULL,
				[Description] [varchar](150) NULL,
				[SortOrder] [int] NULL,
				[IsDeleted] [bit] NOT NULL,
				[AddDate] [datetime] NOT NULL,
				[AddBy] [varchar](55) NOT NULL,

- Include Select By Foreign Key:
			Generate Stored Procedures and corresponding GetBy static methods based on the Foreign Keys

- Include Select By Index:
			Generate Stored Procedures and corresponding GetBy static methods based on the Indexes. GetBy Primary Key
			will be generated regardless of this setting.

- Generate Empty Partial Classes:
			Creates empty partial classes to extend Business Logic Layer and corresponding Data Access Layer. The code
			generation process will not override existing files modified by developer. The Cyclic Redundancy Check algorithm 
			used to validate file content and match to the generated code.

- Enable Partial Property Load:
			Generate Lazy Load properties for database fields with size over specified minimum size in bytes. Data will be 
			loaded on demand in Property getter thus it is transparent for developer. But if class has more than one 
			oversized property - all of them will be loaded if at least one touched. The decision is made on assumption that 
			memory consumption is cheaper than round trips to database. Default value is 4000 bytes.

- Generate Unit Test project:
			This option allows generation of the Unit Test project for the BLL/DAL based on the configuration for the target
			project. The template creates DALUnitTestHelper class with methods that should expedite manual creation of Unit 
			Tests for the BLL. In addition CRUD Unit Tests created to validate basic functionality.

- Commit Unit Test Database changes:
			It is recomended to rollback all changes created by CRUD Unit Tests, but in case developer wants to populate 
			database with random data for load testing, this option allows to commit all data changes to the database at
			the end of successfull unit test. Default value is false.

Screen 2
Tables - Specify tables to exclude, caching options and Change Data Capture selection:
- Table Name: Table Name
- Exclude:  Excludes table from code generation.
- Cache:	Enables caching of the GetAll() results in the DAL itself – subsequent calls to 
			GetAll() method will return values from the cache. 
			*Accessed using Linq to Object. Bizobject.Cache.Items.Where(p => p.column == "").
- Enable CDT:	Enables Change Data Tracking (CDT) for the table.  If table meets all requirements data will be audited ONLY when modified.
				There is no record creation audit.

- Generate CREATE tables SQL script to support Update History feature - Creates sql script to create UpdateHistory and UpdateHistoryRow tables (UpdateHistoryTables.generated.sql).

- AutoExecute CREATE tables SQL script - Executes the sql script against the database specified in Connection String to create the UpdateHistory and UpdateHistoryRow tables.

Screen 3
Stored Procedures - Choose how to generate stored procedures scripts:
- Stored Procedure Prefix:
			The prefix of the generated Stored Procedures to distinguish them from manually created by developer or DBA. Keep
			in mind that length of the Stored Procedure name cannot exceed 128 characters, thus make prefix as short as possible.

- Execute Account:
			The list of users or roles to grant EXECUTE permission to the generated Stored Procedures separated by coma or semicolon.
			The format is: Username [, Username, ...]

- Generate Combined Insert/Update Stored Procedures:
			This option allows to generate one Stored Procedure for SQL inserts or updates with check if record exists on the 
			SQL Server side. If unchecked Wizard will generate separate insert/update Stored Procedures which provides more
			granular security control options for DBAs.

- Save Stored Procedures Script in project:
			This option will store generated SQL script for Stored Procedures to the project for further analysis. 
			The file path inside project is '/SQL/Generated/StoredProcedures.generated.sql'.

- AutoExecute Stored Procedures script
			This option allows to execute generated Stored Procedure script automatically as part of code generation process.

- Drop All generated Stored Procedures with same prefix:
			If checked this option allows for the Wizard to delete all Stored Procedures with the specified prefix. This option
			is useful to keep database clean during research and development phases.


Column Encryption and Compression driven by Table Column Extended Properties:
- IsEncrypted:	Indicates that column stored in encrypted format. Acceptable values True/False.
- IsCompressed: Indicates that column strored in compressed format (Zip). Acceptable values True/False.
- EncapsulatedClrDataType: Allows to specify .Net CLR type of the Encrypted/Compressed property.  (String, Int32, Long, etc.)

The encryption password is stored in the "Column Encryption Password" property of the connection string.
Example: 
<configuration>
	...
	<connectionStrings>
		<add name="DbContext" connectionString="Data Source=(local);Initial Catalog=DbName;Integrated Security=True;Column Encryption Password=P@ssw0rd;"/>
	</connectionStrings>
	...
</configuration>


Handling Transactions:

BaseObject is inherited by all Business Objects
BaseObject methods:
- ToXml()				 -	Instance method that returns the object serialized to XML as a string (not XMLDocument).
- FromXml<T>(string xml) -	Instance method that deserializes an xml string to an object(accepts generics for strongly typed object)
- ToString()			 -	Returns a string with all of the properties serialized into the following 
							format P:{FirstName} V:{John}|P:{LastName} V:{Smith}|etc.

BaseObject properties:
- IsNew						- Readonly
- IsModified				- Readonly
- IsPartialDataModified		- Readonly
- NoDataMemberColumnNames	- This is a helper property.  Array of common column names that a developer may not want copied when 
							  using CopyTo.  "AddBy", "AddDate", "ModifiedBy", "ModifiedDate", "IsDeleted"


Additional Features:
Lookup table
 - Creates Enum's for Lookup table and creates LookupGroup enum that has all Groups
 - Several Convert methods to convert string to enum.  String can be a number or value.

CopyTo - Shallow copy of the object.
		 this.CopyTo(myObject, f => f.Where(p => !this.NoDataMemberColumnNames.Contains(p.PropertyName)));
Partial methods onBeforeSave and onAfterSave - These methods are used to execute code before and after the Save(string savedBy) method is called.
											   The benefit of partial methods are that if they are not used the code is not compiled.

Project file only options:
- IncludeDatabasewiseClone:
			Generate DatabasewiseClone() instance method to creates a shallow copy of the current instance, but only for Database mapped properties.

- EnableSqlCacheDependency
			Generate SqlDependency based Cache invalidation methods.

NOTE(s) Feature:
if (Model.IncludeNotes)
                    {
                        Table noteTable = Table.Database["Note"];
                        m_IncludeNotes =
                            noteTable != null &&
                            noteTable.HasIdentityColumn &&
                            noteTable.HasPrimaryKey &&
                            noteTable.Columns.Contains("MetaTableId") &&
                            noteTable.Columns.Contains("RowId") &&
                            this.Table.IsIntegerPrimaryKey &&
                            Table.MetaTableId.HasValue &&
                            !Model.TablesToExclude.Contains("Note", StringComparer.CurrentCultureIgnoreCase);
                    }
                    else
                    {
                        m_IncludeNotes = false;
                    }

Lookup table sql:
/****** Object:  Table [dbo].[Lookup]    Script Date: 01/23/2013 08:44:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Lookup](
	[LookupId] [int] NOT NULL,
	[GroupName] [varchar](50) NOT NULL,
	[Value] [varchar](75) NULL,
	[Description] [varchar](150) NULL,
	[SortOrder] [int] NULL,
	[IsDeleted] [bit] NOT NULL,
	[AddDate] [datetime] NOT NULL,
	[AddBy] [varchar](55) NOT NULL,
 CONSTRAINT [PK_Lookup] PRIMARY KEY NONCLUSTERED 
(
	[LookupId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY],
 CONSTRAINT [IX_Lookup_GroupNameAndValue] UNIQUE CLUSTERED 
(
	[GroupName] ASC,
	[Value] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'GroupName allows the grouping of Value''s in the Lookup table.

The GroupName should be used as the column name + LookupId (GroupNameLookupId) in tables that use it.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Lookup', @level2type=N'COLUMN',@level2name=N'GroupName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The value stored for the Lookup record.  This column can also be used for User Interface display purposes, but it is designed to not be visible.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Lookup', @level2type=N'COLUMN',@level2name=N'Value'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Additional information about the Value.  This description can also be used as for the UI, but was only designed for adding additional information about the Value.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Lookup', @level2type=N'COLUMN',@level2name=N'Description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'SortOrder within the GroupName' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Lookup', @level2type=N'COLUMN',@level2name=N'SortOrder'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Stores all the Lookup values for the RolloverCentral application.

The records in this table are converted into Enums by the Code Generator.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Lookup'
GO

ALTER TABLE [dbo].[Lookup] ADD  CONSTRAINT [DF_Lookup_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
GO

ALTER TABLE [dbo].[Lookup] ADD  CONSTRAINT [DF_Lookup_AddDate]  DEFAULT (getdate()) FOR [AddDate]
GO


