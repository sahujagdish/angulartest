﻿
create procedure dbo.ebn_proc_rcPermissions  @providerID uniqueidentifier
as
SELECT	SUM(PERMISSIONS) as PERMISSIONS
	FROM	TEPROVIDERADMINLINKS PAL INNER JOIN 
			TDADMINLINKS AL ON AL.LINKID = PAL.LINKID
	WHERE	PAL.providerID = @providerID