﻿
CREATE PROCEDURE [dbo].[ebn_proc_teProviderSpecialCodeDeleteByProviderId]
	@providerID  uniqueidentifier
AS

	DELETE FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID