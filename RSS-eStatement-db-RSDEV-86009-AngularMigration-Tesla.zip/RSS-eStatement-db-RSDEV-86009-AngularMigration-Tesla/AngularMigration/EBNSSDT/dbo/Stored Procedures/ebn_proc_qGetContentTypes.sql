﻿
create proc [dbo].[ebn_proc_qGetContentTypes]
as
SELECT    Name, ProductCode
	FROM      tdContentTypes
	where FileName LIKE '%#sDestinationProviderCustomerNumber#%' or Name LIKE 'RC #sDestinationProvider#%'
	ORDER By  ContentID