﻿
create proc [dbo].[ebn_proc_rsContents_provider] @providerID uniqueidentifier 
as
	SELECT	*  FROM	dbo.ebn_view_rsContents  WHERE	ProviderID = @providerID