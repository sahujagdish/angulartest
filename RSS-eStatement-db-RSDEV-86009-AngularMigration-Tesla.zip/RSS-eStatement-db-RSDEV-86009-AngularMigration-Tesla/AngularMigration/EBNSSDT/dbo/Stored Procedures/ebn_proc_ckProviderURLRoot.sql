﻿
--ckProviderURLRoot
create procedure dbo.ebn_proc_ckProviderURLRoot @providerID uniqueidentifier ,  @providerURLRoot varchar(30)
as
SELECT providerURLRoot, providerID
FROM dbo.teProvider
WHERE (providerURLRoot = @providerURLRoot)  AND (providerID != @providerID)