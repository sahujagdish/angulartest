﻿
create proc dbo.ebn_proc_rsSpecialCodeID @providerID uniqueidentifier , @scode int
as
	SELECT	*
	FROM	TEPROVIDERSPECIALCODE
	WHERE	PROVIDERID = @providerID
    AND SPECIALCODEID = @scode