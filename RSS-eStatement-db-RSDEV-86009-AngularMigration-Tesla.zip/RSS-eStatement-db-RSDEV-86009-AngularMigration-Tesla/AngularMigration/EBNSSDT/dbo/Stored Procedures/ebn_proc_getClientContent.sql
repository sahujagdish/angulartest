﻿

create procedure dbo.ebn_proc_getClientContent  @providerID uniqueidentifier
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID
	AND pct.providerID = @providerID 
	AND ct.contentCategoryID = cc.ContentCategoryID
ORDER by  ct.description