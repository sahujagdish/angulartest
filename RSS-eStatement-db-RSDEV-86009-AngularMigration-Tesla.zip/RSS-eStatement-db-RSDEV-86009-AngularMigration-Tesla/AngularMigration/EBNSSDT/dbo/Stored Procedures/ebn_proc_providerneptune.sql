﻿
create proc [dbo].[ebn_proc_providerneptune]
@neptuneNo varchar(12) 
as
select ProviderId, Name from  TEPROVIDER where 
HASFRC = 1 AND ISACTIVE = 1 
AND NeptuneCustNo != @neptuneNo