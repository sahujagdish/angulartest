﻿
create proc dbo.ebn_proc_rsVerifyClient @providerID uniqueidentifier
as
	SELECT	*
	FROM	FRCProviderKeys
	WHERE	PROVIDERID = @providerID