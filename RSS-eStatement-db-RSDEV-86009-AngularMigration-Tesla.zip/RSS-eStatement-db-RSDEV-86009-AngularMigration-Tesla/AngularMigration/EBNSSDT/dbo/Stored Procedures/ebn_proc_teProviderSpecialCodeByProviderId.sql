﻿
CREATE PROCEDURE [dbo].ebn_proc_teProviderSpecialCodeByProviderId
	@providerID  uniqueidentifier
AS

	select * FROM [dbo].[teProviderSpecialCode]
	WHERE
		[ProviderId] =@providerID