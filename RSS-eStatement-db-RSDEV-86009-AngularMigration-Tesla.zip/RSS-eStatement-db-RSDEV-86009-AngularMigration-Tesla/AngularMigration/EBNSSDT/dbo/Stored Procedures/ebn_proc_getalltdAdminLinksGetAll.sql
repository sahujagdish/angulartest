﻿
create proc [dbo].[ebn_proc_getalltdAdminLinksGetAll]
as
select * from tdAdminLinks