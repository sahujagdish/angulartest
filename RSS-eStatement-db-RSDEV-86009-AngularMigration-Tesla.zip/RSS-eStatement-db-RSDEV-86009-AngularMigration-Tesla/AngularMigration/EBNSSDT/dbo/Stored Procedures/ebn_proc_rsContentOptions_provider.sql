﻿
create proc dbo.ebn_proc_rsContentOptions_provider @providerID uniqueidentifier 
as

	SELECT	* from dbo.ebn_view_rsContentOptions  
	WHERE	ProviderID = @providerID
	ORDER BY ContentID