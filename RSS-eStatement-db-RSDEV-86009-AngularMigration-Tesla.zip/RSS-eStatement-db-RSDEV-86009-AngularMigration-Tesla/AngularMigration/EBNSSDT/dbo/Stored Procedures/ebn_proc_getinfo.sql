﻿
create proc dbo.ebn_proc_getinfo @providerID uniqueidentifier, @colid int 
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and IsActive = 1
        and displaylevel =  4
        and displaycol = @colid
		order by a.displayorder asc