﻿
CREATE PROCEDURE [dbo].[ebn_proc_SelectteProvider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
SELECT
	*
FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID