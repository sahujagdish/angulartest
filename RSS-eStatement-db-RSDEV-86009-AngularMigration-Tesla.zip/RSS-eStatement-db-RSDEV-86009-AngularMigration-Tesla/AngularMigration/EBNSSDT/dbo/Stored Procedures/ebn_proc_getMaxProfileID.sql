﻿
CREATE PROCEDURE [dbo].[ebn_proc_getMaxProfileID]
as
SELECT	Max(ProfileId) as MaxProfileID
	FROM	teAdminProfile