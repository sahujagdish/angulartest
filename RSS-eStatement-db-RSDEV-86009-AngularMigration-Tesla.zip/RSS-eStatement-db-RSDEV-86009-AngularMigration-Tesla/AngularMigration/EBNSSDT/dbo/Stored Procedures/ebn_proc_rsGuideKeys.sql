﻿
CREATE PROCEDURE [dbo].[ebn_proc_rsGuideKeys]
(
   @idList ebn_type_contentid READONLY
)
AS
BEGIN

SELECT	ContentId, Name
	FROM	tdContentTypes
	WHERE	ContentId IN (SELECT contentId FROM @idList) 
	ORDER BY ContentId
END