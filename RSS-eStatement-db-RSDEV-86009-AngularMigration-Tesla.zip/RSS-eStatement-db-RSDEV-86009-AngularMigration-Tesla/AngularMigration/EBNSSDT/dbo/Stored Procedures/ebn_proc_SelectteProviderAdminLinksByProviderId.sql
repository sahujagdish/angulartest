﻿
CREATE PROCEDURE [dbo].[ebn_proc_SelectteProviderAdminLinksByProviderId]
	@providerID uniqueidentifier
AS

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ COMMITTED 

SELECT
	*
FROM [dbo].[teProviderAdminLinks]
WHERE
ProviderId = @providerID