﻿
CREATE PROCEDURE [dbo].[ebn_proc_getProviderContents]
	 @providerID uniqueidentifier
AS
SELECT distinct(tdContentTypes.ContentCategoryId), tdContentCategories.name
    FROM
    tdContentCategories
	INNER JOIN tdContentTypes on tdContentCategories.ContentCategoryId = tdContentTypes.ContentCategoryId
	INNER JOIN teProvider_ContentTypes on teProvider_ContentTypes.ContentID = tdContentTypes.ContentId
    WHERE   
    teProvider_ContentTypes.ProviderID =  @providerID