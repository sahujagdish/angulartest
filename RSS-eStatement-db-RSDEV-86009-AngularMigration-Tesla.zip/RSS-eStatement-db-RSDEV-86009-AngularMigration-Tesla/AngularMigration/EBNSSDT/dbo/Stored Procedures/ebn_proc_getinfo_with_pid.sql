﻿
create proc dbo.ebn_proc_getinfo_with_pid @providerID uniqueidentifier , @colid int , @pid int
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID
		where 
        providerid = @providerID
        and parentid = @pid
        and IsActive = 1
        and displaylevel = 4
        and displaycol = @colid order by a.displayorder asc