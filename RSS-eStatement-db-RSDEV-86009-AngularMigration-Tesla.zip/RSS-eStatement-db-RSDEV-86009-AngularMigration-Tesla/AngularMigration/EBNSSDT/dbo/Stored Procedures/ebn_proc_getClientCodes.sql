﻿
create procedure dbo.ebn_proc_getClientCodes @providerID  uniqueidentifier
as
SELECT sc.specialCodeID, sc.SpecialCode , providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID
	AND providerID = @providerID 
ORDER by  sc.SpecialCode