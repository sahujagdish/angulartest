﻿
CREATE PROCEDURE [dbo].[ebn_proc_teProviderAdminLinksDeleteByProviderId]
	@providerID  uniqueidentifier
AS
	DELETE FROM [dbo].[teProviderAdminLinks]
	WHERE
		[ProviderId] =@providerID