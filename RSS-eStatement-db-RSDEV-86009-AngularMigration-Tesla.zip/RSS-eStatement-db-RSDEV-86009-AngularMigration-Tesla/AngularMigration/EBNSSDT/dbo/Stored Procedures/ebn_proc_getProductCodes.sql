﻿
create proc dbo.ebn_proc_getProductCodes
as
	SELECT productCode
	FROM tdContentTypes 
	ORDER by productCode