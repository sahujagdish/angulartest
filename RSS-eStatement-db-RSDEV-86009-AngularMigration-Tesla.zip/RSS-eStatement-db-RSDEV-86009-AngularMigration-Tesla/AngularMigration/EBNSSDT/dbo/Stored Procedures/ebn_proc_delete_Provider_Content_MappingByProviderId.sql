﻿
CREATE PROCEDURE [dbo].[ebn_proc_delete_Provider_Content_MappingByProviderId]
	 @providerID uniqueidentifier
AS
DELETE FROM [dbo].[teProvider_Content_Mapping]
WHERE ProviderID = @providerID