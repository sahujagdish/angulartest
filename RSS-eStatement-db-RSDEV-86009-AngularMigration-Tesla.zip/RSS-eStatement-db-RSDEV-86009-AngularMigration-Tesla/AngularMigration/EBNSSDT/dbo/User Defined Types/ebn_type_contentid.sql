﻿CREATE TYPE [dbo].[ebn_type_contentid] AS TABLE (
    [contentId] INT NULL);

