﻿
create view dbo.ebn_view_getContentTypes 
as
SELECT DISTINCT ct.contentID,ct.description,ct.fileName,cc.name
FROM tdContentTypes ct, tdContentCategories cc
WHERE ct.contentCategoryID = cc.ContentCategoryID