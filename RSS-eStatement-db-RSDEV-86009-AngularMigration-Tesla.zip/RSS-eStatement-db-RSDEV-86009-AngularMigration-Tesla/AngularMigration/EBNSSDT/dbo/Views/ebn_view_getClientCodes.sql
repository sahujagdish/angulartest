﻿
create view dbo.ebn_view_getClientCodes
as
SELECT sc.specialCodeID, sc.SpecialCode ,providerID
FROM tdspecialcode sc, teProviderSpecialCode psc
WHERE sc.specialCodeID = psc.specialCodeID