﻿
create view dbo.ebn_view_rsContentOptions 
as
	SELECT	ct.name, pct.ContentID, pct.AllowDirectLinkingToFRC,pct.ProviderID
	FROM	teProvider_ContentTypes pct INNER JOIN tdContentTypes ct ON pct.ContentID = ct.ContentId