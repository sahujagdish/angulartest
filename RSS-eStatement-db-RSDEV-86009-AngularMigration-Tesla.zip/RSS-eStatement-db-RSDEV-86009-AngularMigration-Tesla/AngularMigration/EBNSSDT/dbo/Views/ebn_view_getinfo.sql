﻿
create view dbo.ebn_view_getinfo
as
select A.*,B.Name,B.Description,B.AdminSiteText,B.FileName,B.ContentCategoryId,
B.isUploadable,B.ProductCode,B.ShowTopFrame,B.MasteryPointProduct,B.isInstanced,
B.ContentScope , B.StaticContent, B.DirectLink from 
        CONTENTLAYOUT A 
        INNER JOIN tdcontenttypes B ON A.CONTENTID = B.CONTENTID