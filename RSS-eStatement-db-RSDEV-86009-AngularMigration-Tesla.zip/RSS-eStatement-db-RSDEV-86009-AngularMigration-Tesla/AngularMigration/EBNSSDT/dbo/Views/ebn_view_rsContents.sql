﻿
create view dbo.ebn_view_rsContents
as
	SELECT		ct.FileName, ct.Name, ct.ProductCode, p.ProviderID
	FROM		tdContentTypes ct Inner Join
				teProvider_ContentTypes pct on ct.ContentID = pct.contentID Inner Join
				teProvider p on pct.ProviderID = p.ProviderID