﻿

create view dbo.ebn_view_getClientContent
as
SELECT  ct.contentID, ct.name, ct.description, ct.fileName, cc.name as catName, pct.nk1
FROM tdContentTypes ct, teProvider_ContentTypes pct, tdContentCategories cc
WHERE ct.contentID = pct.ContentID	AND ct.contentCategoryID = cc.ContentCategoryID