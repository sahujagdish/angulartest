﻿--Dhiraj Dusane
--RSDEV-89087

CREATE View [dbo].[vProviderLevelLogo] AS

     SELECT 
		ProviderId,		
		LogoId
    FROM teProviderLevelLogo

GO