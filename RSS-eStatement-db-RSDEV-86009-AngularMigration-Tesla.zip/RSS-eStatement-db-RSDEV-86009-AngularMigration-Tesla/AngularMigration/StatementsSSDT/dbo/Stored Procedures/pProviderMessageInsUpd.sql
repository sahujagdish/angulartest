﻿
-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pProviderMessageInsUpd]
	@ProviderId UNIQUEIDENTIFIER,
    @MessageName VARCHAR(50) = NULL,
	@MessageId VARCHAR(20) OUTPUT,
	@CompuSetMessage VARCHAR(MAX),
    @OriginalMessage VARCHAR(MAX) = NULL
	 
AS
      SET NOCOUNT ON

     BEGIN TRY
        UPDATE Statements..teProviderMessage
            SET 
		    ProviderId = @ProviderId,
            MessageName = @MessageName,
		    MessageId = @MessageId,
            CompuSetMessage = @CompuSetMessage,
            OriginalMessage = @OriginalMessage,
            ModifiedDttm = GETDATE()
        WHERE ProviderId = @ProviderId
            AND MessageId = @MessageId

        --
        -- Insert new record.
        --
        IF @@ROWCOUNT = 0
            INSERT INTO Statements..teProviderMessage (   
                ProviderId,
                MessageName,
			    MessageId,
			    CompuSetMessage,
                OriginalMessage,
                ModifiedDttm
            )
            VALUES (
                @ProviderId,
                @MessageName,
			    @MessageId,
			    @CompuSetMessage,
                @OriginalMessage,
                GETDATE()
            )
            
    END TRY
    BEGIN CATCH
        -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000)
        DECLARE @ErrorSeverity INT
        DECLARE @ErrorState INT
        DECLARE @ErrorNumber INT

        SELECT
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE(),
            @ErrorNumber =  ERROR_NUMBER()

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )

        RETURN @ErrorNumber
    END CATCH