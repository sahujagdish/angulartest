-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2021 by DST Systems, Inc.
--   All Rights Reserved.
CREATE PROCEDURE [dbo].[pInsertUpdatePlanNotifySettings]
@ProviderId uniqueidentifier, 
@ExternalPlanId varchar(100), 
@Content varchar(max), 
@PlanEnotifyOverrideTypeCD tinyint
AS
	if exists (select * from tePlanEnotifyOverrideSettings 
	where ProviderId =  @ProviderId and ExternalPlanId = @ExternalPlanId 
	and PlanEnotifyOverrideTypeCD = @PlanEnotifyOverrideTypeCD)
	begin
		update tePlanEnotifyOverrideSettings set Content = @Content  
		where ProviderId =  @ProviderId and ExternalPlanId = @ExternalPlanId 
		and PlanEnotifyOverrideTypeCD = @PlanEnotifyOverrideTypeCD
		select 'updated'
	end
	else
	begin
		insert into tePlanEnotifyOverrideSettings(ProviderId,ExternalPlanId,Content,PlanEnotifyOverrideTypeCD)
		values(@ProviderId,@ExternalPlanId,@Content,@PlanEnotifyOverrideTypeCD)
		select 'inserted'
	end  
GO