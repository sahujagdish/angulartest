﻿-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2021 by DST Systems, Inc.
--   All Rights Reserved.
--Created by: Dhiraj Dusane
--Created date: 2022-01-04 
--Example: [dbo].[pFillvPlanByProviderAndExternalID] '59A3141C-385F-423A-A081-1860F419E9D2','007'
CREATE PROCEDURE [dbo].[pFillvPlanByProviderAndExternalID]
@ProviderId uniqueidentifier, 
@ExternalPlanId varchar(100)
AS
	select * from vPlan  where ProviderId = @ProviderId and ExternalPlanId = @ExternalPlanId
GO