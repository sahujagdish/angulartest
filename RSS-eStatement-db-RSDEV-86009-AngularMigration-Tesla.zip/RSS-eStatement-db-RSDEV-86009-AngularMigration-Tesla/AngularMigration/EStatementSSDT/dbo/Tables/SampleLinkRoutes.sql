﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create table dbo.SampleLinkRoutes
(
	[SampleID] [int] NOT NULL,
	[NewSampleURL] [varchar](100) NOT NULL,
	primary key ([SampleID])
)
go
