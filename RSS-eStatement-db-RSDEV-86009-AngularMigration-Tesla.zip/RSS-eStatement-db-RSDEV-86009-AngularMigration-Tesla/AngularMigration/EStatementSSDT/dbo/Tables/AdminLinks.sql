﻿CREATE TABLE [dbo].[AdminLinks] (
    [LinkID]    INT           IDENTITY (1, 1) NOT NULL,
    [LinkOrder] INT           NOT NULL,
    [LinkText]  VARCHAR (30)  NOT NULL,
    [LinkURL]   VARCHAR (100) NOT NULL,
    [PopUp]     BIT           CONSTRAINT [DF_AdminLinks_PopUp] DEFAULT (0) NOT NULL,
    [Active]    BIT           CONSTRAINT [DF_AdminLinks_Active] DEFAULT (1) NOT NULL,
    [Secure]    BIT           CONSTRAINT [DF_AdminLinks_Secure] DEFAULT (0) NOT NULL,
    [Show]      BIT           CONSTRAINT [DF_AdminLinks_Show] DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_AdminLinks] PRIMARY KEY NONCLUSTERED ([LinkID] ASC) WITH (FILLFACTOR = 90)
);
GO

