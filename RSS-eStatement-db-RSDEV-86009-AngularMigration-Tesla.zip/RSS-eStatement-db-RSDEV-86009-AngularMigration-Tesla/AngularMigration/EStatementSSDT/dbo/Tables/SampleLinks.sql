﻿CREATE TABLE [dbo].[SampleLinks] (
    [SampleID]    INT           IDENTITY (1, 1) NOT NULL,
    [SampleOrder] INT           NOT NULL,
    [SampleText]  VARCHAR (300) NOT NULL,
    [SampleURL]   VARCHAR (100) NULL,
    [PopUp]       BIT           CONSTRAINT [DF_SampleLinks_SamplePopUp] DEFAULT ((0)) NOT NULL,
    [ProviderID]  INT           NOT NULL,
    [Active]      BIT           CONSTRAINT [DF_SampleLinks_Active] DEFAULT ((0)) NOT NULL,
    [Secure]      BIT           CONSTRAINT [DF_SampleLinks_Secure] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_SampleLinks] PRIMARY KEY NONCLUSTERED ([SampleID] ASC) WITH (FILLFACTOR = 90)
);

