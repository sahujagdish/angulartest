﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create table dbo.PromoLinkRoutes
(
	[LinkID] [int] NOT NULL,
	[NewLinkURL] [varchar](100) NOT NULL,
	primary key ([LinkID])
)
go
