﻿CREATE TABLE [dbo].[SponLinks] (
    [SPLI_ID]    INT           IDENTITY (1, 1) NOT NULL,
    [SPLI_Order] INT           NOT NULL,
    [SPLI_Text]  VARCHAR (30)  NOT NULL,
    [SPLI_URL]   VARCHAR (100) NOT NULL,
    [Popup]      BIT           CONSTRAINT [DF__SponLinks__Popup__382F5661] DEFAULT (0) NULL,
    [Active]     BIT           CONSTRAINT [DF__SponLinks__Activ__39237A9A] DEFAULT (1) NULL,
    [Secure]     BIT           CONSTRAINT [DF_SponLinks_Secure] DEFAULT (0) NOT NULL,
    [Handshake]  BIT           CONSTRAINT [DF_SponLinks_Handshake] DEFAULT (1) NOT NULL,
    CONSTRAINT [SponLinks_PK] PRIMARY KEY CLUSTERED ([SPLI_ID] ASC) WITH (FILLFACTOR = 90)
);

