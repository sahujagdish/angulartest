﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create table dbo.SponLinkRoutes
(
	[SPLI_ID] [int] NOT NULL,
	[NewSPLI_URL] [varchar](100) NOT NULL,
	primary key ([SPLI_ID])
)
go