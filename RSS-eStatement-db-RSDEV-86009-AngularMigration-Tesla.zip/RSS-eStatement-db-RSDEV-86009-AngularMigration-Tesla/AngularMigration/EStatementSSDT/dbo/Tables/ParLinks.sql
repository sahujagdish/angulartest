﻿CREATE TABLE [dbo].[ParLinks] (
    [LinkID]    INT           IDENTITY (1, 1) NOT NULL,
    [LinkOrder] INT           NOT NULL,
    [LinkText]  VARCHAR (30)  NOT NULL,
    [LinkURL]   VARCHAR (100) NOT NULL,
    [PopUp]     BIT           CONSTRAINT [DF_ParLinks_PopUp] DEFAULT (0) NOT NULL,
    [Secure]    BIT           CONSTRAINT [DF_ParLinks_Secure] DEFAULT (0) NOT NULL,
    [Handshake] BIT           CONSTRAINT [DF_ParLinks_Handshake] DEFAULT (1) NOT NULL,
    CONSTRAINT [PK_ParLinks] PRIMARY KEY NONCLUSTERED ([LinkID] ASC) WITH (FILLFACTOR = 90)
);

