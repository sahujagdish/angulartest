﻿CREATE TABLE [dbo].[PromoLinks] (
    [LinkID]     INT           IDENTITY (1, 1) NOT NULL,
    [LinkOrder]  INT           NOT NULL,
    [LinkText]   VARCHAR (30)  NOT NULL,
    [LinkURL]    VARCHAR (100) NOT NULL,
    [PopUp]      BIT           CONSTRAINT [DF_PromoLinks_PopUp] DEFAULT (0) NOT NULL,
    [ProviderID] INT           NOT NULL,
    [Active]     BIT           CONSTRAINT [DF_PromoLinks_Active] DEFAULT (0) NOT NULL,
    [Secure]     BIT           CONSTRAINT [DF_PromoLinks_Secure] DEFAULT (0) NOT NULL,
    CONSTRAINT [PK_PromoLinks] PRIMARY KEY CLUSTERED ([LinkID] ASC)
);

