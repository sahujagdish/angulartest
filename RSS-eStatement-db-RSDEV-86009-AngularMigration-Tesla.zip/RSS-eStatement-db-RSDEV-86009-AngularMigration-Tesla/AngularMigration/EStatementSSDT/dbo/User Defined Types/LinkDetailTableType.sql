﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777


CREATE TYPE [dbo].[LinkDetailTableType] AS TABLE
(
	SpliID int,
	Active bit
)