﻿--CREATEBY: Dhiraj Dusane

CREATE TYPE dbo.api_type_varcar_col AS TABLE(
    varchar_col varchar(500)
)