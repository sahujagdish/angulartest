﻿
create procedure dbo.spDeleteProfileLinksByPRLI_ProfileID 
@control_id int
as
		BEGIN
			DELETE 
					FROM ProfileLinks
					WHERE PRLI_ProfileID = @control_id
		END