﻿--Dhiraj Dusane
--RSDEV-90962

create procedure dbo.pGetParticipant @providerID int, @useSSNPin int, @uid varchar(50), @parUUID varchar(50)
as

declare @sql nvarchar(2000)
set @sql = 'SELECT distinct	participant.fname, participant.mi, participant.lname, participant.ssn, participant.acctnumber,
					participant.email, participant.userid, ''PLACEHOLDERVALUE1!'' as [password],  
                    participant.statuscode,
					statuscodes.statusname, participant.vcode, participant.participantid
			FROM	participant, statuscodes '

if @uid <> ''
begin
    set @sql = @sql + ',ss_ident'
end

    set @sql = @sql + ' WHERE	participant.statuscode=statuscodes.statuscode '

if @uid <> ''
begin
    if @useSSNPin = 1 or @useSSNPin = 2
    begin
        set @sql = @sql + ' AND ss_ident.part_id = participant.ssn '
    end
    else
    begin
        set @sql = @sql + ' AND ss_ident.part_id = participant.acctnumber '
    end
end

set @sql = @sql + ' AND participant.providerid = ' + Convert(nvarchar(10),@providerID)
if @uid <> ''
begin
    set @sql = @sql + ' AND ss_ident.uid = ''' + @uid + ''' '
end

set @sql = @sql + ' AND participant.participantUUID = '''+ @parUUID + ''' '
print @sql
EXEC sys.[sp_executesql] @sql