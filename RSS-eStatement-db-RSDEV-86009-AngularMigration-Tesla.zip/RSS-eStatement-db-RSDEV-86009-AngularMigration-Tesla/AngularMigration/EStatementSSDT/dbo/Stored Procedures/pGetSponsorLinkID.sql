﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777


CREATE PROCEDURE [dbo].[pGetSponsorLinkID]
	@spad_spon_id int ,
	@sppr_sppf_id int,
	@sppr_spli_id int
AS
	SELECT SponProfileLinks.SPPR_SPLI_ID
			FROM SponProfileLinks,SponAdminLinks
			WHERE SponAdminLinks.SPAD_SPLI_ID = SponProfileLinks.SPPR_SPLI_ID 
					and SponAdminLinks.SPAD_SPON_ID =  @spad_spon_id
					and SponProfileLinks.SPPR_SPPF_ID =  @sppr_sppf_id
					and SponProfileLinks.SPPR_SPLI_ID = @sppr_spli_id
RETURN 0


