﻿
create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderIDandCommunicationTypeCD] 
@ProviderID int,
@CommunicationTypeCD smallint
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID and CommunicationTypeCD=@CommunicationTypeCD;