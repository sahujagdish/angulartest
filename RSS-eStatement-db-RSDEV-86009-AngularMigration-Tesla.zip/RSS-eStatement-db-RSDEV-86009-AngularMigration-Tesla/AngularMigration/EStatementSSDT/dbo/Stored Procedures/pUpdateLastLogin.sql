﻿
--CREATED BY: Jagdish sahu
--CREATED DATE: 26-11-2021
CREATE PROCEDURE dbo.pUpdateLastLogin
@Id INT,
@Role VARCHAR(50)
AS
BEGIN
	if(@Role = 'administrator')
	BEGIN
	IF EXISTS(SELECT TOP 1 * FROM Administrator WHERE AdministratorId = @Id )
		BEGIN
			UPDATE Administrator
			SET LastLogin = GETDATE()
			WHERE AdministratorId = @Id
		END
	END
	ELSE IF(@Role = 'participant')
	BEGIN
	IF EXISTS(SELECT TOP 1 * FROM Participant WHERE ParticipantId = @Id )
		BEGIN
			UPDATE Participant
			SET LastLogin = GETDATE()
			WHERE ParticipantId = @Id
		END
	END
	ELSE IF(@Role = 'sponsor')
	BEGIN
		if Exists(select top 1 * from SponAdministrator where SPAD_SPON_ID = @Id )
		BEGIN
		--select 1
			UPDATE SponAdministrator
			SET SPAD_LastLogin = GETDATE()
			WHERE SPAD_SPON_ID = @Id
		END
	END
END