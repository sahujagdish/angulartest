﻿
create procedure dbo.api_proc_get_failed_attempts @userid varchar(20), @table_name varchar(20)
as
        declare @sql nvarchar(500)
        declare @table_attempt int

        set @sql = 'select @a = failedAuthAttempts from ' + @table_name
        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		print @sql
        EXEC sys.[sp_executesql] @sql , N'@a int out ', @table_attempt out 

		select @table_attempt