﻿
--CREATEBY: Jagdish sahu
--CREATE DATE: 05-11-2021
--Example: pGetAdministrator 10000105
CREATE PROCEDURE dbo.pGetAdministrator
@ProviderId INT
AS
BEGIN
SELECT administratorid as control_id, userid, 
		'PLACEHOLDERVALUE1!' as password, 
		lname as control_name, 
	    fname, 
		profileid, 
		0 as updated, 
		1 as active, 
		hidesensitiveplans,
		internal_user as isInternalUser,
		dtnumber
	FROM administrator
	WHERE active=1 and providerid = @ProviderId
		AND internaluser = 0
	ORDER BY control_name, fname
END