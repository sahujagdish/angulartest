﻿
create procedure dbo.spGetActiveProfilesByProviderID 
@ProviderID int
as
		BEGIN
			select profileid as control_id, profilename as control_name, active, 0 AS Updated
			from Profiles
			where Active = 1 and providerid= @ProviderID
			order by control_name
		END