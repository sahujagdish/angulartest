﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE procedure [dbo].[pGetSponProvLinks] 
@spad_spli_id int,
@spad_spon_id int
as	
	SELECT SPAD_SPLI_ID
	FROM dbo.SponAdminLinks
	WHERE SPAD_SPLI_ID = @spad_spli_id
	and SPAD_SPON_ID =  @spad_spon_id
go