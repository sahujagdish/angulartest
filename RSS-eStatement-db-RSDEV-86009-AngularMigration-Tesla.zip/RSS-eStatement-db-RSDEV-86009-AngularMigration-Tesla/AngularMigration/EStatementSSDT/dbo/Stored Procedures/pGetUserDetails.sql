﻿--CREATED BY: Jagdish sahu
--CREATED DATE: 16-02-2021
--Example: pGetUserDetails '000004107', 'participant',63
CREATE PROCEDURE dbo.pGetUserDetails
@UserId VARCHAR(50),
@Role VARCHAR(50),
@ProviderId int = 0
AS
BEGIN
	if(@Role = 'administrator')
	BEGIN
		SELECT DISTINCT AdministratorID as Id, ISNULL(LastLogin,GETDATE()) as LastLogin,InternalUser,hideSensitivePlans 
		FROM Administrator WHERE UserID = @UserId and ProviderID = @ProviderId
	END
	ELSE IF(@Role = 'participant')
	BEGIN
		SELECT DISTINCT ParticipantId as Id,ISNULL(LastLogin,GetDATE()) as LastLogin,CONVERT(BIT, 0) as InternalUser, CONVERT(bit, 0) as  hideSensitivePlans 
		FROM Participant WHERE UserID = @UserId and ProviderID = @ProviderId and StatusCode <> 'IN'
	END
	ELSE IF(@Role = 'sponsor')
	BEGIN
		select DISTINCT spa.SPAD_ID as Id, ISNULL(spa.SPAD_LastLogin,GETDATE()) as LastLogin, CONVERT(BIT, 0) as InternalUser , CONVERT(bit, 0) as  hideSensitivePlans 
		from SponAdministrator spa 
		INNER JOIN Sponsor sp ON spa.SPAD_SPON_ID = sp.SPON_ID
		where spa.SPAD_UserID = @UserId and sp.SPON_ProviderID = @ProviderId
	END
END

