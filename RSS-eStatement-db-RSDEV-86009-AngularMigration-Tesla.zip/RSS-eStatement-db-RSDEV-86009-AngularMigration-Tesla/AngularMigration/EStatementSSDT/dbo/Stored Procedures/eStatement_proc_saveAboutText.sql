﻿
create procedure  [dbo].[eStatement_proc_saveAboutText]  
@AboutOrder int,
@AboutHeader varchar(100),
@AboutBody varchar(2000),
@ProviderID int,
@Active  bit

as
--insert into abouttext(aboutorder,aboutheader,aboutbody,providerid,active)
	insert into abouttext(AboutOrder,AboutHeader,AboutBody,ProviderID,Active)
	values(@AboutOrder,@AboutHeader,@AboutBody,@ProviderID,@Active);