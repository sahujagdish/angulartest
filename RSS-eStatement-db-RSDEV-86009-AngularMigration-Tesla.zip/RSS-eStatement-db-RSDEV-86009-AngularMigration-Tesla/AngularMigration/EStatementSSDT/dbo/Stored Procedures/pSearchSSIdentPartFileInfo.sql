﻿--CREATEBY: Dhiraj Dusane
--RSDEV-91966

create procedure dbo.pSearchSSIdentPartFileInfo 
@searchBy varchar(20) ,
@part_list api_type_varcar_col readonly,
@plan_name varchar(500),
@provID varchar(50),
@bsponsor bit,
@start           int = 0,
@limit           int = 20	
as

	create table #tmpParticipants
	(
		FILE_NAME       varchar(100),
		DATESUBMITTED	datetime,
		rowNum          int IDENTITY(1,1)
	)

    declare @sql nvarchar(2000)
    set @sql = '
	insert into #tmpParticipants ( FILE_NAME,DATESUBMITTED)
	SELECT  DISTINCT
                     FILE_NAME, DATESUBMITTED 
                     FROM 
                     SS_IDENT 
                     WHERE 1 = 1'
        
        if @searchBy = 'pLName'
        begin
           set @sql = @sql  + ' AND PART_ID IN (select varchar_col from @local_part_list) '
        end
        else if  @searchBy = 'pCode'
        begin
            set @sql = @sql  + ' AND PLAN_NUM LIKE '''+ @plan_name + '%''' 
        end
        else if  @searchBy = 'pName'
        begin
            set @sql = @sql  + ' AND PLAN_NUM IN 
                                 ( 
                                    SELECT PLAN_Plan_Num 
                                    FROM plans 
                                    WHERE plan_Plan_name LIKE '''+ @plan_name + '%''
                                    AND plan_provid = '''+@provID+'''
                                 ) '
        end
        
        set @sql = @sql  + '
         AND PROVID   = '''+ @provID + '''
                            AND  COMMUNICATIONTYPECD IN (
                                                            SELECT COMMUNICATIONTYPECD FROM tdCommunications
                                                            WHERE 
                                                            DESCRIP = ''Statements Combined'' '
        if @bsponsor = 1
        begin
            set @sql = @sql  + ' AND SCOPE   = ''SPONSOR'') '
        end
        else
        begin
            set @sql = @sql  + ' AND SCOPE   = ''ADMIN'') '
        end
        set @sql = @sql  + '  AND  FILELOCATIONTYPECD IN ( SELECT filelocationtypecd FROM tdFileLocation WHERE descrip = ''UI Repository'' ) AND ISACTIVE = 1'
		
		print @sql
	    EXEC sys.[sp_executesql] @sql  , N'@local_part_list api_type_varcar_col readonly', @part_list

		select *
		from #tmpParticipants
		where   RowNum >  @start 
		and RowNum <=  ( @start + @limit ) 

		select count(*) as totalCount from #tmpParticipants		
		drop table #tmpParticipants
go
