﻿
create PROCEDURE dbo.eStatement_proc_getMaxProviderID
@ProviderID int out
as
	SELECT @ProviderID=MAX( ProviderID) FROM Provider;
	return @ProviderID