﻿
create procedure dbo.api_proc_update_ss_ident 
@p_fname		varchar(20),
@p_uid 			varchar(50),
@p_lname		varchar(20)
as
	UPDATE	ss_ident
	SET		fname = @p_fname
			,lname = @p_lname
	WHERE	uid = @p_uid