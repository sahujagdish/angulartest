﻿CREATE procedure dbo.put_participant 	@p_ssn		 	varchar(11),
					@p_acctnumber	varchar(20),
					@p_fname		varchar(20),
					@p_mi			varchar(1),
					@p_lname		varchar(20),
					@p_email		varchar(80),
					@p_userid		varchar(10),
					@p_password		varchar(32),
					@p_statuscode	varchar(2),
					@p_providerid	integer,
					@p_vcode		varchar(10),
					@p_participantuuid 	char(35),
					@p_isRegSite 	varchar(5) = 'false',
    				@AgentEmail 		varchar(254) = null,
     				@AgentID 		char(18) = null,
     				@Agent_Ind 		char(1) = null,
     				@ElectCode 		char(2) = null,
     				@MMPrefix 		char(3) = null,
     				@PartC_Phon 		varchar(20) = null,
     				@Prefix 		varchar(4) = null,
     				@Suffix 		varchar(8) = null,
     				@AddressLine1 	varchar(35) = null,
     				@AddressLine2 	varchar(35) = null,
     				@AddressLine3 	varchar(35) = null,
     				@City 			varchar(35) = null,
     				@State 		char(2) = null,
     				@Country 		varchar(30) = null,
     				@Zip 			varchar(10) = null,
     				@VestedBalance 	varchar(13) = null,
     				@AgentPhone 		varchar(20) = null,
    				@AgentFirstName 	varchar(20) = null,
     				@AgentLastName 	varchar(20) = null,
     				@DateReferred 	datetime = null

as
set nocount on

if @p_participantuuid = ''
   set @p_participantuuid = left(cast(newid() as char(36)), 35)

if @p_isRegSite = 'true'
begin
	insert into participant (SSN,AcctNumber,FName,MI,LName,EMail, UserID,Password, StatusCode,LastChange,LastChangeID,ProviderID,VCode,LastLogin,ParticipantUUID,ValidEmail,ValidAsOf,isPasswordHashed,lastPasswordEdit,
					 AgentEmail, AgentID, Agent_Ind, ElectCode, MMPrefix,
     					  PartC_Phon, Prefix, Suffix, AddressLine1, AddressLine2,
     					  AddressLine3, City, State, Country, Zip,
     					  VestedBalance, AgentPhone, AgentFirstName, AgentLastName, DateReferred)
	values
		(@p_ssn, @p_acctnumber, @p_fname, @p_mi, @p_lname, @p_email, @p_userid, 
		@p_password, @p_statuscode, getdate(), 0,@p_providerid, @p_vcode, getdate(),@p_participantuuid, 1, getdate(),1,getdate(),
		@AgentEmail, @AgentID, @Agent_Ind, @ElectCode, @MMPrefix,
     		@PartC_Phon, @Prefix, @Suffix, @AddressLine1, @AddressLine2,
     		@AddressLine3, @City, @State, @Country, @Zip,
     		@VestedBalance, @AgentPhone, @AgentFirstName, @AgentLastName, @DateReferred)
end
else
begin
	insert into participant (SSN,AcctNumber,FName,MI,LName,EMail, UserID,Password, StatusCode,LastChange,LastChangeID,ProviderID,VCode,LastLogin,ParticipantUUID,ValidEmail,ValidAsOf,isPasswordHashed,lastPasswordEdit,
					 AgentEmail, AgentID, Agent_Ind, ElectCode, MMPrefix,
     					  PartC_Phon, Prefix, Suffix, AddressLine1, AddressLine2,
     					  AddressLine3, City, State, Country, Zip,
     					  VestedBalance, AgentPhone, AgentFirstName, AgentLastName, DateReferred)
	values
		(@p_ssn, @p_acctnumber, @p_fname, @p_mi, @p_lname, @p_email, @p_userid, 
		@p_password, @p_statuscode, getdate(), 0,@p_providerid, @p_vcode, NULL,@p_participantuuid, 1, getdate(),1,getdate(),
		@AgentEmail, @AgentID, @Agent_Ind, @ElectCode, @MMPrefix,
     		@PartC_Phon, @Prefix, @Suffix, @AddressLine1, @AddressLine2,
     		@AddressLine3, @City, @State, @Country, @Zip,
     		@VestedBalance, @AgentPhone, @AgentFirstName, @AgentLastName, @DateReferred)
end

select @@identity as participantid
from participant

if @@error <> 0
	begin
		return 1
	end


GO


