﻿
--Created by: Dhiraj Dusane
--JIRA: RSDEV-96645
create procedure dbo.pGetStatementDates  @uID api_type_varcar_col readonly,  @planNum api_type_varcar_col readonly ,  @provID varchar(50)
as

 ;with fetch_part_id(d_part_id) as (
 SELECT DISTINCT PART_ID as d_part_id
 FROM SS_IDENT
 WHERE UID	in (select varchar_col from @uID)
 AND PROVID = @provID)

 select distinct rpt_date from
  (SELECT  rpt_date,
  count(uid) over (partition by rpt_date) as dates
  FROM ss_ident 
  WHERE part_id IN (select d_part_id from fetch_part_id)
    and plan_num IN (select varchar_col from @planNum) 
    and ss_ident.provid = @provID
    and ss_ident.uid   in (select varchar_col from @uID)
    and isactive = 1 
    and CommunicationTypeCD = 1 ) subQuery

	where dates = (select count(*) from @uID)
	ORDER BY RPT_DATE DESC
