﻿create procedure [dbo].[pGetSponPlanForSponsor] @isid int, @superSponsor bit
as
	If @superSponsor = 1
        BEGIN
            SELECT DISTINCT rtrim(Plans.PLAN_Plan_Num) as PLAN_Plan_Num
			FROM SponPlan, Plans, SuperSponsor 
			WHERE SponPlan.SPPL_Plan_ID = Plans.PLAN_ID 
			AND SponPlan.SPPL_Spon_ID IN (
                SELECT SUPR_SPON_ID FROM SuperSponsor WHERE SUPR_SUPER_SPON_ID = @isid)
        END
    ELSE
        BEGIN
        	Exec nw_GetSponPlan @p_SPPL_Spon_ID = @isid
        END