﻿
--CreatedBy: Jagdish sahu
--CreatedDate: 28-09-2021
--UpdatedBy:
--UpdatedDate:
--Example: pGetPlanList 5,0,'ac'
CREATE PROCEDURE dbo.pGetPlanList
@ProviderID INT,
@HideSensitivePlans INT,
@PlanName VARCHAR(500) = ''
AS
BEGIN

	Declare @plan varchar(500);
	SET @plan = '%' + @PlanName + '%'

	SELECT plan_id AS 'PlanID',
	plan_plan_num AS 'PlanNumber',
	plan_plan_name as 'PlanName'	
	FROM plans
	WHERE plan_providerID = @ProviderID
	AND plan_active = 1 
	AND (@HideSensitivePlans = 1 OR Plan_Sensitive = @HideSensitivePlans)
	AND (@PlanName = '' OR plan_plan_name like @plan)
	ORDER BY plan_plan_name ASC

END