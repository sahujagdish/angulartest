﻿
create procedure [dbo].[eStatement_proc_GetProvAdminLinksByProviderIDandLinkID] 
@PRAD_ProviderID int,
@PRAD_LinkID int
as
	SELECT * FROM ProvAdminLinks WHERE PRAD_ProviderID = @PRAD_ProviderID and PRAD_LinkID=@PRAD_LinkID;