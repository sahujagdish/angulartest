﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE procedure [dbo].[pGetSponsorProfiles] @sppf_spon_id int, @activetype varchar(10)
as


--declare @activetype varchar(10)
--set @activetype = 'all'

--declare @sppf_spon_id int
--set @sppf_spon_id = 1

select distinct SPPF_ID,SPPF_Name,SPPF_SPON_ID,active, 
		cast(0 as bit) AS Updated

from SponProfiles
where 1 = 1 

and ACTIVE = case 
when @activetype = 'true'then 1 
when @activetype = 'false' then 0 else ACTIVE
end

and SPPF_SPON_ID = case
when @sppf_spon_id > 0 then @sppf_spon_id else SPPF_SPON_ID end

GO

