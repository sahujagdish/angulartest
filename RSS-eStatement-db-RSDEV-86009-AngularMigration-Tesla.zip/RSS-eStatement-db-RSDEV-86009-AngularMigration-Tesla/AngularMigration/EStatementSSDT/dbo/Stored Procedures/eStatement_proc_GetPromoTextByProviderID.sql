﻿
create procedure [dbo].[eStatement_proc_GetPromoTextByProviderID] 
@ProviderID int
as
	SELECT * FROM PromoText WHERE ProviderID = @ProviderID;