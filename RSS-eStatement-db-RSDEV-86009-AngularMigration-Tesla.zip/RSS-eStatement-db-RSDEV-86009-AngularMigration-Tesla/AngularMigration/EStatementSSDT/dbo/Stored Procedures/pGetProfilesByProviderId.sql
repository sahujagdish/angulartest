﻿
--CREATEBY: Jagdish sahu
--CREATE DATE: 05-11-2021
--Example: pGetProfilesByProviderId 10000105
CREATE PROCEDURE dbo.pGetProfilesByProviderId
@ProviderId INT
AS
BEGIN
	select profileid, profilename
	from Profiles
	where providerid = @ProviderId and active = 1
	order by profileid
END