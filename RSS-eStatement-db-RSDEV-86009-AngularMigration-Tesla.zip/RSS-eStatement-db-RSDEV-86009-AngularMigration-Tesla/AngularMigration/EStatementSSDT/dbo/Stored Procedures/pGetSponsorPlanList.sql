﻿
--CreatedBy: Jagdish sahu
--CreatedDate: 30-09-2021
--UpdatedBy:
--UpdatedDate:
--Example: pGetSponsorPlanList 4541
Create PROCEDURE dbo.pGetSponsorPlanList
@ISID INT
AS
BEGIN

	SELECT p.plan_id AS 'PlanID',
	p.plan_plan_num  AS 'PlanNumber',
	p.plan_plan_name AS 'PlanName'
	FROM plans    p, sponplan sp
	WHERE p.plan_id       = sp.sppl_plan_id
	AND sp.sppl_spon_id = @ISID
	AND p.plan_active   = 1  
	ORDER BY p.plan_plan_name ASC 	

END