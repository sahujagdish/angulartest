﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777


CREATE PROCEDURE [dbo].[pDeActivateSponProfiles]
	@sppfId int,
	@active bit
AS
	update SponProfiles
	set active= @active
	where SPPF_ID = @sppfId
go
