﻿

--CREATEDBY: Jagdish SAHU
--CREATEDDATE: 12-10-2021
--Modifiedby:
--ModifiedDate:
--EXAMPLE: pGetProviderAssignedSite 'demo'
CREATE PROCEDURE dbo.pGetProviderAssignedSite
@Code varchar(50)
AS
Declare @str varchar(500)
SELECT @str = concat(case when AdminSiteIsActive = 1 then 'Admin' else '' end,',', 
case when SponSiteIsActive = 1 then 'Sponsor' else null end,',',
case when ParSiteIsActive = 1 then 'Participant' else '' end
)
FROM Provider 
WHERE lower(VirtualDir) = lower(@Code) AND Active = 1

select value from [dbo].[tesla_fn_split_string](@str, ',')