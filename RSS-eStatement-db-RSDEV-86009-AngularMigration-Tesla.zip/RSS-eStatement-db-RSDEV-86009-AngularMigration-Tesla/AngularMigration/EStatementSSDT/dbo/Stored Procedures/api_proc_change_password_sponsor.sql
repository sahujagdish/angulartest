﻿
create procedure dbo.api_proc_change_password_sponsor @sponId int, @current_pass varchar(40), @new_pass varchar(40)
as
declare @r_rount int
declare @table_pass varchar(40)

		SELECT @table_pass = SPAD_Password
        FROM   sponAdministrator
        WHERE  SPAD_ID = @sponId
        AND SPAD_Password = @current_pass
		select @r_rount = @@Rowcount

		if @r_rount = 0
		begin
			select -1 as code, 'The value you entered for Current Password is invalid!' as msg
			return
		end

		 UPDATE sponAdministrator
         SET SPAD_password = @new_pass
             ,LastPasswordEdit = getdate()
             ,failedAuthAttempts = 0
             ,passwordEditByAdmin = 0
         WHERE SPAD_ID = @sponId

		 select 1 as code, 'Password changed' as msg