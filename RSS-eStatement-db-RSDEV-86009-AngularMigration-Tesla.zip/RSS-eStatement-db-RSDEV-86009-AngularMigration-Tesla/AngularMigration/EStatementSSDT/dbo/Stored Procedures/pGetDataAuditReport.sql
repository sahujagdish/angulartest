﻿
--CreatedBy: Jagdish sahu
--CreatedDate: 30-09-2021
--UpdatedBy:
--UpdatedDate:
--Example: pGetDataAuditReport 10711, 4541
CREATE PROCEDURE dbo.pGetDataAuditReport
@ApprovalId int,
@ProvId varchar(10)
AS
BEGIN
	SELECT APPR_DA_FILE
	FROM Approval
	WHERE APPR_PK = @ApprovalId 
	AND APPR_PROVID = @ProvId
END