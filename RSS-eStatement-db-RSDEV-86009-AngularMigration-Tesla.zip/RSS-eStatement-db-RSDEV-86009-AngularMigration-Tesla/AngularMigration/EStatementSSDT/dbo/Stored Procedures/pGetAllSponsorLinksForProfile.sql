﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pGetAllSponsorLinksForProfile] @spad_spon_id int
AS
	SELECT SponLinks.SPLI_Order,SponLinks.SPLI_Text,SponLinks.SPLI_ID
	FROM SponLinks,SponAdminLinks
	WHERE SponLinks.SPLI_ID = SponAdminLinks.SPAD_SPLI_ID
		 AND SponAdminLinks.SPAD_SPON_ID = @spad_spon_id
		 AND SponLinks.SPLI_Text != 'Login' AND 
		 SponLinks.SPLI_Text != 'Logout'
RETURN 0
