﻿
create procedure [dbo].[eStatement_proc_GetteProviderCommunicationsByProviderID] 
@ProviderID int
as
	SELECT * FROM teProviderCommunications WHERE ProviderID = @ProviderID;