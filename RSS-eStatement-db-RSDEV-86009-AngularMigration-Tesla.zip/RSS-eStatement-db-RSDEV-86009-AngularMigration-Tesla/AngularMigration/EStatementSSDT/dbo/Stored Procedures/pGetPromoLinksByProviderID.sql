﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

CREATE procedure dbo.pGetPromoLinksByProviderID 
@ProviderID int
as
SELECT LinkID,	LinkOrder,	LinkText, ISNULL( NewLinkURL,'') as LinkURL	, PopUp, ProviderID, Active, Secure	
FROM vPromoLinkRoutes WHERE ProviderID = @ProviderID;
