﻿

create PROCEDURE dbo.spGetNewsletter  @providerId int, @platformNum int
as
	SELECT NEWS_FileName,News_Text
	FROM Newsletter
	WHERE NEWS_ProviderID = @providerId
		AND News_Platform = @platformNum
		AND News_ExpiresOn > GETDATE()