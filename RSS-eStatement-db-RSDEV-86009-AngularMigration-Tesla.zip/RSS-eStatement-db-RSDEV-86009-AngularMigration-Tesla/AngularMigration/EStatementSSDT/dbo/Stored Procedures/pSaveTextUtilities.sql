﻿
--CREATEBY: Jagdish sahu
--CREATE DATE: 25-10-2021
--Example: pSaveTextUtilities 1, 'FAQ Text', '1,121,1111,1|2,131,1121,2'
CREATE PROCEDURE dbo.pSaveTextUtilities
@ProviderId INT,
@Type VARCHAR(50),
@Subject TEXT,
@Text TEXT,
@IPID int
AS
BEGIN	
	IF(@Type = 'Help')
	BEGIN	
		print 'Help'
		UPDATE PROVIDER
		SET HelpMsg = @Text,
		HelpMsgLastChangeID = @IPID,
		HelpMsgLastChange = GETDATE()
		WHERE PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Agreement')
	BEGIN
		PRINT 'Agreement'
		UPDATE PROVIDER
		SET AcceptMsg = @Text,
		AcceptMsgLastChangeID = @IPID,
		AcceptMsgLastChange = GETDATE()		
		WHERE PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'eNotification')
	BEGIN
		print 'eNotification'
		UPDATE PROVIDER
		SET EMailMsg = @Text,
		EMailMsgLastChangeID = @IPID,
		EMailMsgLastChange = GETDATE()
		WHERE PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Unsubscribe')
	BEGIN
		print 'Unsubscribe'
		UPDATE PROVIDER
		SET UnsubscribeMsg = @Text,
		UnsubscribeMsgLastChangeID = @IPID,
		UnsubscribeMsgLastChange = GETDATE()
		WHERE PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Login')
	BEGIN
		print 'Login'
		update PROVIDER
		set LoginMsg = @Text,
		LoginMsgLastChangeID = @IPID,
		LoginMsgLastChange = GetDate()
		where PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Sign-on')
	BEGIN
		print 'Sign-on'
		update PROVIDER
		set SignonMsg = @Text,
		SignOnMsgLastChangeID = @IPID,
		SignOnMsgLastChange = GetDate()
		where PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Pre-Unsubscribe')
	BEGIN
		print 'Pre-Unsubscribe'
		update PROVIDER
		set PreUnsubscribeMsg = @Text,
		PreUnsubscribeMsgLastChangeID = @IPID,
		PreUnsubscribeMsgLastChange   = GetDate()
		where PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Unsubscribe Email')
	BEGIN
		print 'Unsubscribe Email'
		update PROVIDER
		set UnsubscribeEmailSubjectMsg = @Subject,
		UnsubscribeEmailBodyMsg    = @Text,
		UnsubscribeEmailSubjectMsgLastChangeID = @IPID,
		UnsubscribeEmailBodyMsgLastChangeID    = @IPID,
		UnsubscribeEmailSubjectMsgLastChange   = GetDate(),
		UnsubscribeEmailBodyMsgLastChange      = GetDate()
		where PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Registration Email')
	BEGIN
		print 'Registration Email'
		update PROVIDER
		set RegistrationEmailBodyMsg = @Text,
		RegistrationEmailBodyMsgLastChangeID = @IPID,
		RegistrationEmailBodyMsgLastChange   = GetDate()
		where PROVIDERID = @ProviderId
	END
	ELSE IF(@Type = 'Validation')
	BEGIN
		print 'Validation'
		update PROVIDER
		set ValidationMsg = @Text,
		ValidationMsgLastChangeID = @IPID,
		ValidationMsgLastChange = GetDate()
		where PROVIDERID = @ProviderId
	END
END