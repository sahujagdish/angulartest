﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create procedure [dbo].[pSearchParticipantsWithOptionalLimit]
	@provID          varchar(4),
	@useSSNPin       tinyint,
	@sPartID         varchar(15)   = '',
	@lname		     varchar(40)   = '',
	@sponPlans       varchar(5000) = '',
    @planName		 varchar(500)  = '',
	@bSponsor        bit,
	@bAssetRetention bit,
	@providerID      int,
	@bSuperSponsor   bit,
	@accessCode      varchar(35) = '',
	@agentID         varchar(18) = '',
	@iSID            int,
	@start           int = 0,
	@limit           int = 20,
	@sortField       nvarchar(200) = 'partID', 
	@sortDir         varchar(4)    = 'ASC',
	@hideSensitivePlans	bit = 0,
	@totalCount      int OUTPUT	
as
begin
	set NOCOUNT on

	declare @q varchar(8000)

	if @sortField = 'partID'
	begin
		set @sortField = 'part_id'
	end

	-- holds plans for sponsor queries
	create table #tmpSponPlans(
		PLAN_Plan_Num char(405)
	)	

	-- main participants pen
	create table #tmpParticipants(
		uid             varchar(36),
		part_id         varchar(15),
		fname           varchar(30),
		lname           varchar(40),
		participantid   int,
		agentID         varchar(18) NULL,
		participantuuid varchar(35) NULL,
		planNum			varchar(405) NULL,
		rowNum          int         IDENTITY(1,1)
	)	

	-- if this is a sponsor query, get the plans
	if @bSponsor = 1 and @iSID > 0
	begin
		-- super sponsor
		if @bSuperSponsor = 1
		begin
			insert into #tmpSponPlans ( PLAN_Plan_Num )
			select distinct rtrim( Plans.PLAN_Plan_Num ) as PLAN_Plan_Num
			from SponPlan,
				 Plans,
				 SuperSponsor 
			where SponPlan.SPPL_Plan_ID = Plans.PLAN_ID 
				and SponPlan.SPPL_Spon_ID in ( select SUPR_SPON_ID
											   from SuperSponsor
											   where SUPR_SUPER_SPON_ID = @iSID )
		end
		-- plain sponsor
		else
		begin
			insert into #tmpSponPlans ( PLAN_Plan_Num )
			select Plans.PLAN_Plan_Num
			from SponPlan,
				 Plans
			where SponPlan.SPPL_Plan_ID = Plans.Plan_ID
				and SponPlan.SPPL_Spon_ID = @iSID
		end
	end

	if @bSponsor = 1
	-- ============================== sponsors ==============================
	begin
		set @q = 'insert into #tmpParticipants ( uid, part_id, fname, lname, participantid, agentID, participantuuid, planNum ) '
		set @q = @q + 'SELECT DISTINCT uid, part_id, fname, lname, participantid = null,  agentID, participantUUID = null, plan_num  FROM ( '
		set @q = @q + 'select ss_ident.uid, ss_ident.part_id, ss_ident.fname, ss_ident.lname, participant.participantid, participant.agentID, participant.participantuuid, ss_ident.plan_num '
		set @q = @q + ', RANK () OVER ( PARTITION BY part_id ORDER BY ss_ident.fname ) fname_rank '
		set @q = @q + 'from ss_ident '

		if @useSSNPin = 1 or @useSSNPin = 2
		begin
			-- set @q = @q + 'where ss_ident.part_id *= participant.ssn '
			-- use LEFT OUTER JOIN syntax instead of '*=' for SQL 2005/ANSI standards
			set @q = @q + 'LEFT OUTER JOIN participant on ss_ident.part_id = participant.ssn '
		end
		else
		begin
			--set @q = @q + 'where ss_ident.part_id *= participant.acctNumber '
			-- use LEFT OUTER JOIN syntax instead of '*=' for SQL 2005/ANSI standards
			set @q = @q + 'LEFT OUTER JOIN participant on ss_ident.part_id = participant.acctNumber '
		end

		set @q = @q + 'and participant.providerID = ' + convert( varchar, @providerID ) + ' '

		if @bAssetRetention = 1
		begin
			set @q = @q + 'and rtrim( participant.electcode ) in ( ''E'',''EL'' ) '
		end

		-- for super sponsors
		if len( @agentID ) != 0
		begin
			set @q = @q + 'and participant.agentID = ''' + @agentID + ''' '
		end
		
		set @q = @q + 'where ss_ident.provID = ''' + @provID + ''' '
		set @q = @q + 'and ss_ident.plan_num in ( select * from #tmpSponPlans ) '

		-- filter by last name
		if len( @lname ) != 0
		begin
			set @q = @q + 'and ss_ident.lname like ''' + @lname + '%'' '
		end

		-- filter by part_id
		if len( @sPartID ) != 0
		begin
			set @q = @q + 'and ss_ident.part_id = ''' + @sPartID + ''''
		end

		set @q = @q + ' ) X WHERE fname_rank = 1 '

		-- sorting
		set @q = @q + 'order by ' + @sortField + ' ' + @sortDir
		--PRINT @q
		exec( @q )
	end
	-- ============================== admins ==============================
	else
	begin
		set @q = 'insert into #tmpParticipants( uid, part_id, fname, lname, participantid, participantUUID, planNum ) '
		set @q = @q + 'SELECT DISTINCT uid, part_id, fname, lname, participantid = null, participantUUID = null, plan_num  FROM ( '
		set @q = @q + 'select ss_ident.uid, ss_ident.part_id, ss_ident.fname, ss_ident.lname, participantid = null, participantUUID = null, ss_ident.plan_num '
		set @q = @q + ', RANK () OVER ( PARTITION BY part_id ORDER BY fname ) fname_rank '
		set @q = @q + 'from ss_ident INNER JOIN
                      Plans ON ss_ident.provid = Plans.Plan_ProvID 
					AND ss_ident.plan_num = Plans.PLAN_Plan_Num '

		set @q = @q + 'where provID = ''' + @provID + ''''
		if @sPartID != ''
		begin
			set @q = @q + ' and part_id = ''' + @sPartID + ''''
		end
		if @lname != ''
		begin
			set @q = @q + ' and lname like ''' + @lname + '%'''
		end
		
		-- filter by plan name
		if @planName != ''
		begin
			set @q = @q + ' and ss_ident.plan_num = ''' + @planName + ''''
		end

		-- don't return sensitive plans if user is not allowed to view sensitive plans
		if @hideSensitivePlans = 1
		begin
			set @q = @q + ' and PLAN_Sensitive = 0'
		end

		set @q = @q + ' ) X WHERE fname_rank = 1 '

		-- sorting
		set @q = @q + 'order by ' + @sortField + ' ' + @sortDir
		print @q
		exec( @q )
	end

	-- get the total count
	select @totalCount = count(*) from #tmpParticipants

	-- get the requested page

	if @limit = 0
	begin
		select *
		from #tmpParticipants
	end
	else
	begin
		select *
		from #tmpParticipants
		where   RowNum >  convert( varchar(9), @start )
		and RowNum <= convert( varchar(9), ( @start + @limit ) )
	end


	drop table #tmpSponPlans	
	drop table #tmpParticipants
end
GO
