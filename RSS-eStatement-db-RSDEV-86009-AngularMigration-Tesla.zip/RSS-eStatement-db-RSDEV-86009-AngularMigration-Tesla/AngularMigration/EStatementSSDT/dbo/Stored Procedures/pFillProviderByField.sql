﻿

CREATE PROCEDURE dbo.pFillProviderByField @fieldName varchar(200), @fieldValue varchar(500), @needQuote bit
AS  
BEGIN
    declare @sql nvarchar(500)
    set @sql = 'select * from Provider where ' + @fieldName + ' = '
    
    if @needQuote = 1
    BEGIN
        set @sql = @sql + '''' +  @fieldValue + ''''
    END
    ELSE
    BEGIN
        set @sql = @sql +  @fieldValue 
    END

    print @sql
    EXEC sys.[sp_executesql] @sql   
END