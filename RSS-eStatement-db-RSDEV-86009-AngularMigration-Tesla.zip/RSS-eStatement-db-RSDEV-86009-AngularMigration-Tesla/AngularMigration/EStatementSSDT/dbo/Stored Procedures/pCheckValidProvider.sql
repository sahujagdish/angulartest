﻿
--CREATEDBY: Jagdish SAHU
--CREATEDDATE: 12-10-2021
--Modifiedby:
--ModifiedDate:
--EXAMPLE: pCheckValidProvider 'demo'
CREATE PROCEDURE dbo.pCheckValidProvider 
@Code varchar(50)
AS
SELECT providerid,VirtualDir as code,name
FROM Provider 
WHERE lower(VirtualDir) = lower(@Code) AND Active = 1