﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

CREATE procedure dbo.pGetSampleLinkByProviderID 
@ProviderID int
as
	select SampleID	,SampleOrder	,SampleText	, ISNULL( NewSampleURL,'') as SampleURL	,PopUp	,ProviderID	,Active	,Secure	
	FROM vSampleLinkRoutes WHERE ProviderID = @ProviderID;
