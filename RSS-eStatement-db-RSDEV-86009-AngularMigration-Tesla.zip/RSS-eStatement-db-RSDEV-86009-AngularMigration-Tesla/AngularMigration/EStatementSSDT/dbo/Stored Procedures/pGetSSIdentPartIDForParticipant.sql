﻿create procedure [dbo].[pGetSSIdentPartIDForParticipant] @partId varchar(20), @provid varchar(5), @assetRetention bit
as
	if @assetRetention = 1
		begin
			SELECT DISTINCT uid, platform, batch
			FROM ss_ident
			WHERE part_id = @partId
			AND PROVID = @provid
			AND platform < 100
		end
	else
		begin
			SELECT DISTINCT uid, platform, batch
			FROM ss_ident
			WHERE part_id = @partId
			AND PROVID = @provid
		end