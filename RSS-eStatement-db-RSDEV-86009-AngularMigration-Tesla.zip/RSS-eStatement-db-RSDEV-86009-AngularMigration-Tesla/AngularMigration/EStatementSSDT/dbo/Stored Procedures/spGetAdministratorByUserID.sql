﻿
create procedure dbo.spGetAdministratorByUserID 
@UserID varchar(10)
as
		BEGIN
			select userid 
			from administrator
			where userid= @UserID   
		END