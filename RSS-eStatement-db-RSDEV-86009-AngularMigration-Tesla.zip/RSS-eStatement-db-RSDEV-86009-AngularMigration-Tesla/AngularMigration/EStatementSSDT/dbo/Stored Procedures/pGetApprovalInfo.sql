﻿
--CreatedBy: Jagdish sahu
--CreatedDate: 28-09-2021
--UpdatedBy:
--UpdatedDate:
--Example: pGetApprovalInfo 5,0,
CREATE PROCEDURE dbo.pGetApprovalInfo
@ApprovalId INT,
@ProvId VARCHAR(10)
AS
BEGIN
	SELECT a.*, a.APPR_ZIP_FILE,a.APPR_DATE_APPROVED,a.APPR_PATH, p.Email, p.Name as ProviderName
	FROM Approval a join provider p on a.APPR_PROVID = p.provid
	WHERE APPR_PK = @ApprovalId
	AND APPR_PROVID = @ProvId
END