﻿
create procedure dbo.api_proc_change_password_administrator @adminId int,  @current_pass varchar(40), @new_pass varchar(40)
as
declare @r_rount int
declare @table_pass varchar(40)

        SELECT @table_pass = Password
        FROM   Administrator
        WHERE  AdministratorID = @adminId
        AND Password    = @current_pass
		select @r_rount = @@Rowcount
        
		if @r_rount = 0
		begin
			select -1 as code, 'The value you entered for Current Password is invalid!' as msg
			return
		end

		UPDATE Administrator
        SET Password = @new_pass
            ,LastPasswordEdit = getdate()
            ,failedAuthAttempts = 0
            ,passwordEditByAdmin =  0
        WHERE AdministratorID = @adminId

		select 1 as code, 'Password changed' as msg