﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pNewSponsor]
	@controlID int,
	@controlName varchar(100),
	@linkTable LinkDetailTableType readonly
AS

	DELETE
	FROM SponAdminLinks
	WHERE SPAD_SPON_ID = @controlID
					
	INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
	VALUES (1,@controlID)

	INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
	VALUES (2,@controlID)

	INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
	select SpliID,@controlID from @linkTable where Active = 1
	
	declare @MaxSPPF_ID int
	set @MaxSPPF_ID = 0
	begin TRANSACTION
		begin try
			INSERT INTO SponProfiles(SPPF_Spon_ID, SPPF_Name, active)
			VALUES(@controlID,'Admin', 1)
	
			
			SELECT @MaxSPPF_ID = MAX(SPPF_ID)
			FROM SponProfiles
			WHERE SPPF_Spon_ID = @controlID
	
			INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
			VALUES (@MaxSPPF_ID,1)
	
			COMMIT TRANSACTION
		end try
		begin catch
			rollback tran
			return 1
		end catch

	
	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	VALUES (@MaxSPPF_ID,2)

	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	select @MaxSPPF_ID,SpliID from @linkTable where Active = 1

RETURN 0
