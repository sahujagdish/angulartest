﻿
create procedure dbo.api_proc_get_uuid @uuid varchar(40), @providerid varchar(40)
as
      select participantUUID as 'uid'
      from participant
      where participantUUID = @uuid
        AND participant.providerid = @providerid
        AND participant.statuscode != 'DE'
        AND participant.statuscode != 'IN'