﻿
create procedure dbo.api_proc_change_password_participant 
@partID int, 
@current_pass varchar(40), 
@new_pass varchar(40),
@initialLogin bit
as

declare @table_uid varchar(40)
declare @table_pass varchar(40)
declare @table_code varchar(40)
declare @r_rount int

		SELECT @table_pass = Password, @table_code = StatusCode
        FROM Participant
        WHERE participant.ParticipantID = @partID AND Password = @current_pass
		
		select @r_rount = @@Rowcount

		if @r_rount = 0
		begin
			select -1 as code, 'The value you entered for Current Password is invalid!' as msg
			return
		end

		SELECT @table_uid = UserID
        FROM Participant
        WHERE participant.ParticipantID = @partID AND Password = @current_pass

		select @r_rount = @@Rowcount

		if @table_uid = @new_pass
		begin
			select -2 as code, 'The User ID and the Password should not be the same.' as msg
			return
		end

		declare @sql nvarchar(1000)
		set @sql = '
		UPDATE Participant
            SET Password =  ''' + @new_pass + ''' 
            , PrevPassword = ''' + @table_pass + ''' 
            , LastPasswordEdit = GETDATE()
            , LastLogin = GETDATE() 
			, failedAuthAttempts = 0
            , isPasswordHashed = 1'

		if @initialLogin = 1
		begin
		set @sql = @sql + ', PasswordEditByAdmin = 0 '
		end

		set @sql = @sql + ' WHERE ParticipantID = ' + CONVERT(nvarchar(10),@partID) + '  '

		print @sql
		EXEC sys.[sp_executesql] @sql

		select 1 as code, 'Password changed' as msg