--CREATEBY: Jagdish sahu
--CREATE DATE: 25-10-2021
--UPDATE DATE: 04-02-2022
--Example: pSaveOrderedTextUtilities 1, 'FAQ Text', '1,121,1111,1|2,131,1121,2'
CREATE PROCEDURE dbo.pSaveOrderedTextUtilities
@ProviderId INT,
@type VARCHAR(50),
@text TEXT
AS
BEGIN

	DECLARE @temp TABLE(
	id INT,
	[value] TEXT
	)

	CREATE TABLE #Ordertext (
	[order] INT,
	header VARCHAR(8000),
	body VARCHAR(8000),
	active BIT
	)

	DECLARE  @cnt INT = 0,  @row INT
	
	--@text1 VARCHAR(2000),
	--SET @text1 = '1,111,1111,1|2,111,1121,2'

	INSERT INTO @temp(id, [value])
	SELECT id,value FROM [dbo].[fn_split](@text,'|')

	SET @row = 1
	SELECT @cnt = count(*) FROM @temp

	WHILE @cnt >= @row
	BEGIN
		DECLARE @query VARCHAR(2000), @Val VARCHAR(2000)
		SELECT @Val = [value] FROM @temp WHERE id = @row
		SET @query = 'INSERT INTO #Ordertext ([order], header, body, active) values (' + @Val + ')'

		print @query;
	
		EXEC(@query)

		SET @row = @row +1
	END

	IF(@type = 'FAQ Text')
	BEGIN		
		print 'FAQ Text'
		DELETE FROM faqText WHERE ProviderId = @ProviderId

		INSERT INTO faqText (faqOrder, question, answer, active, ProviderId ) 
		SELECT [order],header,body,active,@ProviderId FROM #Ordertext
	END
	ELSE IF(@type = 'Promo Text')
	BEGIN			
		print 'Promo Text'
		DELETE FROM promoText WHERE ProviderId = @ProviderId

		INSERT INTO promoText (textOrder,textHeader, textBody, active, ProviderId)
		SELECT [order],header,body,active,@ProviderId FROM #Ordertext
	END
	ELSE IF(@type = 'About eStatements Text')
	BEGIN
		print 'About eStatements Text'
		DELETE FROM aboutText WHERE ProviderId = @ProviderId

		INSERT INTO aboutText(aboutOrder, aboutHeader, aboutBody, active, ProviderId)
		SELECT [order],header,body,active,@ProviderId FROM #Ordertext
	END
	ELSE IF(@type = 'About eDelivery Text')
	BEGIN
		print 'About eDelivery Text'
		DELETE FROM aboutText WHERE ProviderId = @ProviderId

		INSERT INTO aboutText(aboutOrder, aboutHeader, aboutBody, active, ProviderId)
		SELECT [order],header,body,active, @ProviderId FROM #Ordertext
	END
	DROP TABLE #Ordertext
END
