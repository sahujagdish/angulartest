﻿
--Created by: Jagdish sahu
--Created date: 20-10-2021
--Example: dbo.pGetAdminLinksOptions 63,1201
Create PROCEDURE dbo.pGetAdminLinksOptions
@ProviderId INT,
@ProfileId INT
AS
Declare @linktext table(
linkText varchar(500)
);

Declare @constArr table(
[value] varchar(50)
);

DECLARE @output table(
[type] varchar(50) 
);

INSERT @linktext (linkText)
SELECT adminlinks.linkText
FROM adminLinks,
provAdminLinks,
profileLinks
WHERE provAdminLinks.PRAD_LinkID = profileLinks.PRLI_LinkID
AND provAdminLinks.PRAD_LinkID = adminLinks.LinkID
AND provAdminLinks.PRAD_providerID = @ProviderId
AND PRLI_ProfileID = @ProfileId
AND adminLinks.active = 1

insert @constArr ([value])
SELECT value  FROM [dbo].[tesla_fn_split_string]('FAQ Text,Promo Text,About eStatements Text,About eDelivery Text', ',')

WHILE (SELECT count(*) FROM @linktext) > 0
BEGIN
	declare @link varchar(100)
	select top 1 @link = linkText from @linktext

	IF EXISTS(SELECT * FROM @constArr where lower(value) = lower(@link) )
	BEGIN
		IF(@link = 'FAQ Text')		
		BEGIN 
			INSERT INTO @output([type])VALUES('FAQ Text')
		END
		else if (@link = 'Promo Text')
		BEGIN
			INSERT INTO @output([type])VALUES('Promo Text')			
		END		
		else if (@link = 'About eStatements Text')
		BEGIN		
			INSERT INTO @output([type])Values('About eStatements Text')
		END		
	END

	delete @linktext where linkText = @link
END

select * from @output