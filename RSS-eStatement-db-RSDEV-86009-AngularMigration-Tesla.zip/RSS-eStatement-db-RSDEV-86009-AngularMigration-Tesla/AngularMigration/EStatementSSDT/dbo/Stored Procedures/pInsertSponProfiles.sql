﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pInsertSponProfiles] @sponId int, @controlName varchar(100),@linkTable LinkDetailTableType readonly
as
	declare @MaxSPPF_ID int
	begin tran
		begin try

			insert into SponProfiles (SPPF_Spon_ID, SPPF_Name, active)
			values 	(@sponId,@controlName,1)

			SELECT @MaxSPPF_ID = MAX(SPPF_ID)
			FROM SponProfiles
			WHERE SPPF_Spon_ID =  @sponId

			INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
			VALUES (@MaxSPPF_ID ,1)
			COMMIT TRANSACTION
		end try
		begin catch
			rollback tran
		end catch

	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	VALUES (@MaxSPPF_ID,2)	
	
	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	select @MaxSPPF_ID,SpliID from @linkTable where Active = 1
go