﻿
create procedure dbo.eStatement_proc_GetScopetdCommunicationsScope 
as
	SELECT DISTINCT Scope FROM tdCommunications;