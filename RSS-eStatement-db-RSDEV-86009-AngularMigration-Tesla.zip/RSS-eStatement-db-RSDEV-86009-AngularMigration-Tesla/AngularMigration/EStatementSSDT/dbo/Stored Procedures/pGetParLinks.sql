﻿
--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create procedure [dbo].[pGetParLinks]  @providerId int
as
	declare @p_handshake bit
	declare @parExitUrl varchar(100)

	select @p_handshake = Handshake , @parExitUrl = ParExitURL from Provider where providerid = @providerId

	declare	@sql varchar(1000)
	set @sql = ' SELECT distinct ap.LinkText,ap.NewLinkURL as LinkURL,ap.PopUp,ap.Secure,p.PRPA_LinkOrder
		FROM vParLinkRoutes ap left join ProvParLinks p on ap.LinkID = p.PRPA_LinkID  where 1=1'

	if @p_handshake = 1 and @parExitUrl = ''
	begin
		set @sql = @sql + ' AND (ap.Handshake = 1) '
	end
	else if @p_handshake = 1 and @parExitUrl <> ''
	begin
		set @sql = @sql + ' AND ((ap.Handshake = 1) OR (ap.LinkText = ''Logout'')) '
	end

	set @sql = @sql + ' ORDER BY p.PRPA_LinkOrder '  
	print @sql
	exec (@sql)
go