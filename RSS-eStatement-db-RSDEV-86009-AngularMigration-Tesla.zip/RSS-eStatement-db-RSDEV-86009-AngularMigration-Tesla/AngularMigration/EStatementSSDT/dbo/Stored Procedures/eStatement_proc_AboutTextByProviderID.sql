﻿
create procedure dbo.eStatement_proc_AboutTextByProviderID 
@ProviderID int
as
	SELECT * FROM AboutText WHERE ProviderID = @ProviderID;