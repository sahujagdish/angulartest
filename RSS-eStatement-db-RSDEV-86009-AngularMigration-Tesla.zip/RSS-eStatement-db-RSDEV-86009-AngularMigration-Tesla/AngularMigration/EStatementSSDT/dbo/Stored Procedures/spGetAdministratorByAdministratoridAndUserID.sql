﻿
create procedure dbo.spGetAdministratorByAdministratoridAndUserID 
@ProviderID int,
@AdministratorID int,
@active bit,
@hasSensitivePlans bit
as
	if (@hasSensitivePlans=1)
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid, hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0
			order by control_name, fname
	END
	ELSE
		BEGIN
			select administratorid as control_id, userid, 'PLACEHOLDERVALUE1!' as password,  
    			lname as control_name, dtnumber, internal_user as isInternalUser, 0 as updated, 1 as active,
				fname, profileid,0 as hidesensitiveplans
			from administrator
			where active= @active and providerid = @ProviderID and internaluser = 0 order by control_name, fname
		END