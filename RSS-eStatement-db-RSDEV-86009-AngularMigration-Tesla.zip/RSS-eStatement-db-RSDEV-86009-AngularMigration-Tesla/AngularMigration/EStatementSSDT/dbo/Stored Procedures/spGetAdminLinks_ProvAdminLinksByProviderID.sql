﻿
create procedure dbo.spGetAdminLinks_ProvAdminLinksByProviderID 
@ProviderID int
as
		BEGIN
			SELECT AdminLinks.LinkOrder,AdminLinks.LinkText,AdminLinks.LinkID
			FROM AdminLinks,ProvAdminLinks
			WHERE AdminLinks.LinkID = ProvAdminLinks.PRAD_LinkID AND 
			ProvAdminLinks.PRAD_ProviderID = @ProviderID
		    AND AdminLinks.LinkText != 'Login'
            AND AdminLinks.LinkText !=  'Logout'
		END