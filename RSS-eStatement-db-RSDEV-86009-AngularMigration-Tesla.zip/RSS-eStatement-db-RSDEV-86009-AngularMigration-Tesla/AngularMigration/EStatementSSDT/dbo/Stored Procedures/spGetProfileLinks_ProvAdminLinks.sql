﻿--CREATE BY: Atanu sen
--Updated By: Jagdish sahu
--Updated Date: 14-02-2022
CREATE PROCEDURE dbo.spGetProfileLinks_ProvAdminLinks 
@ProviderID INT,
@control_id INT
AS
BEGIN
	SELECT ProfileLinks.PRLI_LinkID
	FROM ProfileLinks,ProvAdminLinks
	WHERE ProvAdminLinks.PRAD_LinkID = ProfileLinks.PRLI_LinkID 
			and ProvAdminLinks.PRAD_ProviderID = @ProviderID
			and ProfileLinks.PRLI_ProfileID = @control_id
END