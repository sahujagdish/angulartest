﻿
--Created by: Jagdish sahu
--Created date: 20-10-2021
--Example: pGetAdminLinks 10000105,1225
CREATE PROCEDURE dbo.pGetAdminLinks
@ProviderId INT,
@ProfileId INT
AS
Declare @linktext table(
linkText varchar(500)
);

Declare @constArr table(
[value] varchar(50)
);

DECLARE @output table(
[order] int, 
header varchar(500), 
body text, 
active bit, 
isfaqheader bit, 
[type] varchar(50) 
);

INSERT @linktext (linkText)
SELECT adminlinks.linkText
FROM adminLinks,
provAdminLinks,
profileLinks
WHERE provAdminLinks.PRAD_LinkID = profileLinks.PRLI_LinkID
AND provAdminLinks.PRAD_LinkID = adminLinks.LinkID
AND provAdminLinks.PRAD_providerID = @ProviderId
AND PRLI_ProfileID = @ProfileId
AND adminLinks.active = 1

insert @constArr ([value])
SELECT value  FROM [dbo].[tesla_fn_split_string]('FAQ Text,Promo Text,About eStatements Text,About eDelivery Text', ',')

WHILE (SELECT count(*) FROM @linktext) > 0
BEGIN
	declare @link varchar(100)
	select top 1 @link = linkText from @linktext

	print @link

	IF EXISTS(SELECT * FROM @constArr where value = @link )
	BEGIN
		IF(@link = 'FAQ Text')
		BEGIN
			if exists(select * from provider where HasCustomFAQSection = 1 and ProviderID = @ProviderId)
			BEGIN
				insert @output([order],header,body,active, isfaqheader,[type])
				select faqOrder as 'order',
							   question as 'header',
							   answer   as 'body',
							   active, 
							   isfaqheader,
							   'FAQ Text'
						from faqText
						where providerID = @ProviderId
						order by FAQGroupOrder, faqOrder 
			END
			else
			BEGIN
				insert @output([order],header,body,active, isfaqheader,[type])
				select faqOrder as 'order',
							   question as 'header',
							   answer   as 'body',
							   active,
							   0,
							   'FAQ Text'
						from faqText
						where providerID = @ProviderId
						order by faqOrder asc 
			END
		END
		else if (@link = 'Promo Text')
		BEGIN
		insert @output([order],header,body,active, isfaqheader,[type])
			select textOrder  as 'order',
					textHeader as 'header',
					textBody   as 'body',
					active,
					0,
					'Promo Text'
			from promoText
			where providerID = @ProviderId
			order by textOrder asc
		END
		else if (@link = 'About eStatements Text')
		BEGIN
		insert @output([order],header,body,active, isfaqheader,[type])
			select aboutOrder  as 'order',
                    aboutHeader as 'header',
                    aboutBody   as 'body',
                    active,
					0,
					'About eStatements Text'
            from aboutText
            where providerID = @ProviderId
            order by aboutOrder asc
		END
		else if (@link = 'About eDelivery Text')
		BEGIN
		insert @output([order],header,body,active, isfaqheader,[type])
			select aboutOrder  as 'order',
                    aboutHeader as 'header',
                    aboutBody   as 'body',
                    active,
					0,
					'About eDelivery Text'
            from aboutText
            where providerID =  @ProviderId
            order by aboutOrder asc
		END
		
	END

	delete @linktext where linkText = @link
END

select * from @output