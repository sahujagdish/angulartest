﻿--CreatedBy:Jagdish sahu
--CreatedDate:13-10-2021
--Example: pDeleteExtractPlans
CREATE PROCEDURE [dbo].[pDeleteExtractPlans]
@DA_FILE VARCHAR(50),
@Id INT
AS
BEGIN
	UPDATE Approval
	SET APPR_DA_FILE = @DA_FILE
	WHERE APPR_PK = @Id
END
GO