﻿

--Created by: Jagdish sahu
--Created date: 20-10-2021
--Example: pGetAdminLinksByProviderId 126,'Promo Text'
CREATE PROCEDURE dbo.pGetAdminLinksByProviderId
@ProviderId INT,
@link varchar(100)
AS
IF(@link = 'FAQ Text')
BEGIN
	IF EXISTS(SELECT * FROM provider WHERE HasCustomFAQSection = 1 and ProviderID = @ProviderId)
	BEGIN				
		SELECT providerID, faqOrder AS 'order',
		question AS 'header',
		answer   AS 'body',
		active, 
		isfaqheader as IsFaqHeader
		FROM faqText
		WHERE providerID = @ProviderId and active =1
		ORDER BY FAQGroupOrder, faqOrder 
	END
	ELSE
	BEGIN
		SELECT faqOrder as 'order',
		question as 'header',
		answer   as 'body',
		active,
		convert(bit,0) as IsFaqHeader
		FROM faqText
		WHERE providerID = @ProviderId and active =1
		ORDER BY faqOrder asc 
	END
END
ELSE IF (@link = 'Promo Text')
BEGIN
	SELECT textOrder  AS 'order',
	textHeader AS 'header',
	textBody   AS 'body',
	active,
	convert(bit,0) as IsFaqHeader
	FROM promoText
	WHERE providerID = @ProviderId and active =1
	ORDER BY textOrder ASC
END
ELSE IF (@link = 'About eStatements Text')
BEGIN
	SELECT aboutOrder  AS 'order',
	aboutHeader as 'header',
	aboutBody   as 'body',
	active,
	convert(bit,0) as IsFaqHeader
	FROM aboutText
	WHERE providerID = @ProviderId and active =1
	ORDER BY aboutOrder asc
END
else if (@link = 'About eDelivery Text')
BEGIN
	SELECT aboutOrder  as 'order',
	aboutHeader as 'header',
	aboutBody   as 'body',
	active,
	convert(bit,0) as IsFaqHeader
	FROM aboutText
	WHERE providerID =  @ProviderId and active =1
	ORDER BY aboutOrder ASC
END