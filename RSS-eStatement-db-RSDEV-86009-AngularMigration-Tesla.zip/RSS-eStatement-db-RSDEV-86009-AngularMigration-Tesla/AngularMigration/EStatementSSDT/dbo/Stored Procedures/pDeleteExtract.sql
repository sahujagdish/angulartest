﻿
--CreatedBy:Jagdish sahu
--CreatedDate:13-10-2021
--Example: pDeleteExtract
CREATE PROCEDURE dbo.pDeleteExtract 
@DeletedBY VARCHAR(50),
@ApprovalId INT
AS
BEGIN
	UPDATE Approval
	SET APPR_DATE_DELETED = GETDATE(),
		APPR_DELETED_BY =  @DeletedBY,
		APPR_STATUS =  'Deleted'
	where APPR_PK = @ApprovalId
END