﻿--CREATEDBY: Jagdish SAHU
--CREATEDDATE: 23-11-2021
--Modifiedby:
--ModifiedDate:
--EXAMPLE: qGetParticipantUnsubcribeDetails 218, 11
CREATE PROCEDURE [dbo].[qGetParticipantUnsubcribeDetails]
@iPID INT,
@Providerid INT
AS	
BEGIN 
	SELECT participantid, email, fname, lname
	FROM participant 
	WHERE participantid = @iPID

	SELECT UnsubscribeEmailBodyMsg,UnsubscribeEmailSubjectMsg, MailAccount, ApplicationType FROM Provider 
	WHERE Providerid = @Providerid
END
GO