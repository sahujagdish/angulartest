﻿
create procedure dbo.api_proc_getSS_Ident_count @part_id varchar(20)
as
	SELECT	count(part_id) as part_count
	FROM	ss_ident
	WHERE	part_id = @part_id