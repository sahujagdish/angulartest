﻿
create procedure dbo.spIsParticipantEditable @useSSN bit, @providerid varchar(10), @provid varchar(10), @uid varchar(50)
as
        declare @sql nvarchar(500)
		set @sql = ' select	participantUUID
                     from	participant, ss_ident
                     where '
        if @useSSN = 1 
        begin
            set @sql = @sql + ' participant.SSN = ss_ident.part_id '
        end
        else
        begin
            set @sql = @sql + ' participant.acctnumber = ss_ident.part_id '
        end

        set @sql = @sql + ' and participant.ProviderID  = ' + CONVERT(varchar(10),  @providerid ) + '
                            and ss_ident.provid = ''' + CONVERT(varchar(50),  @provid ) + '''
                            and uid = ''' + CONVERT(varchar(50),  @uid ) + ''' '

        print @sql
        EXEC sys.[sp_executesql] @sql