﻿
create procedure [dbo].[eStatement_proc_PostteProviderCommunications]
@ProviderID int ,
@CommunicationTypeCD smallint ,
@DisplayOrder smallint

as
BEGIN
declare @maxCommunicationTypeCD smallint
	SELECT @maxCommunicationTypeCD =MAX(ProviderCommunicationTypeCD)  FROM teProviderCommunications;
	SET @maxCommunicationTypeCD= @maxCommunicationTypeCD+1;
	INSERT INTO teProviderCommunications (ProviderCommunicationTypeCD,CommunicationTypeCD, ProviderID, DisplayOrder) VALUES (@maxCommunicationTypeCD,@CommunicationTypeCD,@ProviderID,@DisplayOrder);  

END;