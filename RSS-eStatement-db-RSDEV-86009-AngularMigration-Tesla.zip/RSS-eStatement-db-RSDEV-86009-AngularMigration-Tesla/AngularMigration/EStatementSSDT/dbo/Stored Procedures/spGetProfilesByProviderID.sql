﻿
create procedure dbo.spGetProfilesByProviderID 
@ProviderID int,
@Active bit
as
	select ProfileID, ProfileName
	from Profiles
	where ProviderID=@ProviderID and Active = @Active
	order by ProfileID