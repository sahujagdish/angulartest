﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pGetAllSponsorLinks]  @providerId int
AS

declare @summaryRpt bit 
declare @assetRetention bit 
declare @appType varchar(100)

select @summaryRpt = SummaryRpt, @assetRetention = AssetRetention, @appType = ApplicationType from provider where providerid = @providerId

--set @summaryRpt = 0
--set @assetRetention = 1
--set @appType = 'edelivery'


 SELECT SPLI_Order,SPLI_Text,SPLI_ID
 FROM SponLinks
 WHERE 
 active = 1 AND
  SPLI_Text != 'Login'  AND SPLI_Text !=  'Logout'
 and SPLI_ID <> case 
 when @summaryRpt <> 1
 then  4
 else 0
 end

 and SPLI_ID <> case 
 when @assetRetention = 1 and @appType = 'edelivery'
 then 6 
 else 0
 end

  and SPLI_ID <> case 
 when @appType <> 'Statements' and @appType <> 'Both'
 then 10 
 else 0
 end

RETURN 0
