﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create procedure [dbo].[pGetAdminlinkRoutes] 	@p_providerid  integer, @p_profileID int = 0

WITH RECOMPILE
AS
SET NOCOUNT ON;

DECLARE @hasTextUtilities bit
DECLARE @hasOrderedTextUtilities bit

SET @hasTextUtilities = 0
SET @hasOrderedTextUtilities = 0

CREATE TABLE #tmpLinks (
	linkOrder int,
	linkID   int,
	linkText varchar(30),
	linkURL  varchar(100),
	popup    bit,
	secure   bit,
	show     bit
)

IF @p_profileID = 0
	BEGIN
		INSERT INTO #tmpLinks
		SELECT a.linkorder,
			   a.linkid,
			   a.linkText,
			   a.newlinkURL as linkURL,
			   a.popup,
			   a.secure,
			   a.show
		FROM vAdminlinkRoutes a,
			 provadminlinks
		WHERE a.linkid = provadminlinks.prad_linkid 
			and provadminlinks.prad_providerid = @p_providerID 
			and a.active = 1
		ORDER BY linkorder
	END
ELSE
	BEGIN
		INSERT INTO #tmpLinks
		SELECT a.linkorder,
			   a.linkid,
			   a.linkText,
			   a.newlinkURL as linkURL,
			   a.popup,
			   a.secure,
			   a.show
		FROM vAdminlinkRoutes a,
			 provadminlinks,
			 profilelinks
		WHERE a.linkid = provadminlinks.prad_linkid 
			and provAdminLinks.PRAD_LinkID = profileLinks.PRLI_LinkID
			and provadminlinks.prad_providerid = @p_providerID 
			and PRLI_ProfileID = @p_profileID
			and a.active = 1 
		ORDER BY linkorder
	END

-- are there text utilities?
SELECT @hasTextUtilities = case when count( linkid ) >= 1 then 1 else 0 end
						   from #tmpLinks
						   where linkid in ( 19, 20, 22, 23, 25, 26, 27, 47, 48, 49 )

-- are there ordered text utilities?
SELECT @hasOrderedTextUtilities = case when count( linkid ) >= 1 then 1 else 0 end
							      from #tmpLinks
							      where linkid in ( 15, 16, 17 )

SELECT *
FROM #tmpLinks
WHERE ( linkID != 35 or @hasTextUtilities = 1        )
  and ( linkID != 36 or @hasOrderedTextUtilities = 1 )
  ORDER BY linkorder

DROP TABLE #tmpLinks

IF @@error <> 0
	BEGIN
		return 1
	END

GO


