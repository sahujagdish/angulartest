﻿ 
create procedure dbo.spGetMaxProfileIDByProviderID 
@ProviderID int
as
		BEGIN
			SELECT MAX(profileID) as MaxProfileID
						FROM Profiles
						WHERE ProviderID =  @ProviderID
		END