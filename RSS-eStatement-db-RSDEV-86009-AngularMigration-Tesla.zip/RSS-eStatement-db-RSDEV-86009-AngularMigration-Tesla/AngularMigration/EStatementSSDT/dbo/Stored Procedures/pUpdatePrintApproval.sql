﻿
--CreatedDate: 30-09-2021
--UpdatedBy:
--UpdatedDate:
--Example: pUpdatePrintApproval 
CREATE PROCEDURE dbo.pUpdatePrintApproval
@ApprovalId int,
@ProvId VARCHAR(4),
@ApprovedBy int
AS
BEGIN
UPDATE Approval
SET APPR_DATE_APPROVED = Getdate(), 
APPR_APPROVED_BY = @ApprovedBy,
APPR_STATUS = 'Approved'
WHERE APPR_PK = @ApprovalId
AND APPR_PROVID = @ProvId
END