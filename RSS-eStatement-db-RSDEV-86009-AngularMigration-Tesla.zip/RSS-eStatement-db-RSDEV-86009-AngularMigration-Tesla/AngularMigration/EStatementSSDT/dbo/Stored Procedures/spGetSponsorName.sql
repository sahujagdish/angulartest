﻿create procedure dbo.spGetSponsorName @SPON_ID int
as
	BEGIN
		SELECT SPON_Name 	FROM Sponsor 	WHERE SPON_ID = @SPON_ID
	END