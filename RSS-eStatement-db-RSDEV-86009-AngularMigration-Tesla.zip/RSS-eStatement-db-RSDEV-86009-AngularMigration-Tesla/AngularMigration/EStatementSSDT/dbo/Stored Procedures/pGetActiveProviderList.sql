﻿
--CREATEDBY: Jagdish SAHU
--CREATEDDATE: 12-10-2021
--Modifiedby:
--ModifiedDate:
--EXAMPLE:pGetActiveProviderList 21
CREATE PROCEDURE dbo.pGetActiveProviderList
@Id INT = 0
AS
SELECT providerid, name
FROM Provider 
WHERE (@Id = 0 OR providerid = @Id) AND Active = 1
ORDER BY name