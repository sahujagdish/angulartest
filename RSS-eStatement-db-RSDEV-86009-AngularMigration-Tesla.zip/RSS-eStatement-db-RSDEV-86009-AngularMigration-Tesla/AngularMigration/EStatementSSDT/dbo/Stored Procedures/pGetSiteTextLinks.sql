﻿---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--use estatement
--CREATE BY Jagdish Sahu
--CREATED DATE: 04-11-2021
--Example: dbo.pGetSiteTextLinks 63, 1201
CREATE PROCEDURE dbo.pGetSiteTextLinks
 @ProviderID int,
 @ProfileID int
 as

Declare @linktext table(
linkText varchar(500)
);

Declare @constArr table(
[value] varchar(50)
);

INSERT @constArr ([value])
SELECT value  FROM [dbo].[tesla_fn_split_string]('Agreement Text,Email Text,Unsubscribe Text,Login Text,Sign-on Text,Pre-Unsubscribe Text,Unsubscribe Email Text,Registration Email Text,Validation Text,Help Text', ',')

DECLARE @output table(
label varchar(100), 
id varchar(100), 
fieldLabel varchar(100), 
name varchar(100),
value varchar(2000)
);

INSERT @linktext (linkText)
select distinct
(case 
	when adminlinks.linkText = 'Email Text' then 'eNotification'
	when adminlinks.linkText like '%Text%' then RTRIM(LTRIM(SUBSTRING(adminlinks.linkText,0,charindex('Text',adminlinks.linkText))))
	else adminlinks.linkText end) as linkText
from adminLinks,
    provAdminLinks,
    profileLinks
where provAdminLinks.PRAD_LinkID = profileLinks.PRLI_LinkID
    and provAdminLinks.PRAD_LinkID = adminLinks.LinkID
    and provAdminLinks.PRAD_providerID = @ProviderID
    and PRLI_ProfileID = @ProfileID
    and adminLinks.active = 1
	and adminlinks.linkText in(SELECT value FROM @constArr)

WHILE (SELECT count(*) FROM @linktext) > 0
BEGIN
	declare @link varchar(100)
	select top 1 @link = linkText from @linktext

	print @link
		IF(@link = 'Help')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Help', 'txtarea-content','Help','content',HelpMsg  from PROVIDER where  PROVIDERID = @ProviderID			
		END
		ELSE IF(@link = 'Agreement')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Agreement', 'txtarea-content','Agreement','content',AcceptMsg  from PROVIDER where  PROVIDERID = @ProviderID			
		END
		ELSE IF(@link = 'eNotification')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'eNotification', 'txtarea-content','eNotification','content',EmailMsg  from PROVIDER where  PROVIDERID = @ProviderID			
		END
		ELSE IF(@link = 'Unsubscribe')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Unsubscribe', 'txtarea-content','Unsubscribe','content',UnsubscribeMsg  from PROVIDER where  PROVIDERID = @ProviderID			

		END
		ELSE IF(@link = 'Login')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Login', 'txtarea-content','Login','content',LoginMsg  from PROVIDER where  PROVIDERID = @ProviderID
		END
		ELSE IF(@link = 'Sign-on')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Sign-on', 'txtarea-content','Sign-on','content',SignonMsg  from PROVIDER where  PROVIDERID = @ProviderID
		END
		ELSE IF(@link = 'Pre-Unsubscribe')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Pre-Unsubscribe', 'txtarea-content','Pre-Unsubscribe','content',PreUnsubscribeMsg  from PROVIDER where  PROVIDERID = @ProviderID
		END
		ELSE IF(@link = 'Validation')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Validation', 'txtarea-content','Validation','content',ValidationMsg  from PROVIDER where  PROVIDERID = @ProviderID
		END
		ELSE IF(@link = 'Unsubscribe Email')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Unsubscribe Email', 'txtfld-subject','Unsubscribe Email Subject','subject', UnsubscribeEmailSubjectMsg from PROVIDER where  PROVIDERID = @ProviderID

			INSERT @output(label, id, fieldLabel, name, value)
			select 'Unsubscribe Email', 'txtarea-content','Unsubscribe Email','content',UnsubscribeEmailBodyMsg  from PROVIDER where  PROVIDERID = @ProviderID
		END
		ELSE IF(@link = 'Registration Email')
		BEGIN
			INSERT @output(label, id, fieldLabel, name, value)
			select 'Registration Email', 'txtarea-content','Registration Email','content',RegistrationEmailBodyMsg from PROVIDER where  PROVIDERID = @ProviderID
		END

		delete @linktext where linkText = @link
END

select * from @output