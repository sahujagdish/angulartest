﻿--Dhiraj Dusane
--RSDEV-76338

create procedure dbo.pGetNameAndPartIds @uID api_type_varcar_col readonly, @providerid int ,  @provID varchar(50)
as

 ;with fetch_part_id(d_part_id) as (
 SELECT DISTINCT PART_ID as d_part_id
 FROM SS_IDENT
 WHERE UID	in (select varchar_col from @uID)
 AND PROVID = @provID)

   SELECT DISTINCT FNAME, LNAME
   FROM PARTICIPANT
   WHERE   SSN  IN (select d_part_id from fetch_part_id)
   AND PROVIDERID  = @providerid


 ;with fetch_part_id(d_part_id) as (
 SELECT DISTINCT PART_ID as d_part_id
 FROM SS_IDENT
 WHERE UID	in (select varchar_col from @uID)
 AND PROVID = @provID)

   select d_part_id from fetch_part_id
go

