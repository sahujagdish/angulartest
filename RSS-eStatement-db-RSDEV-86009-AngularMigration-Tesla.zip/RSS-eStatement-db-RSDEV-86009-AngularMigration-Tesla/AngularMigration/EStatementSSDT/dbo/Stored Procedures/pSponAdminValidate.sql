﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pSponAdminValidate]
	@spadUserId varchar(50),
	@spadId int
AS
if @spadId <> 0
begin
		select SPAD_UserID
		from SponAdministrator
		where SPAD_UserID= @spadUserId
        and SPAD_ID <> @spadId
end
else
begin
		select SPAD_UserID
		from SponAdministrator
		where SPAD_UserID= @spadUserId
end
RETURN 0
