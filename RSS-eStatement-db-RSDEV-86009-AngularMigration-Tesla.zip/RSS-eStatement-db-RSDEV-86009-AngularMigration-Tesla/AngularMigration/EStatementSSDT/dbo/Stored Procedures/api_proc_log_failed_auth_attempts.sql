﻿
create procedure dbo.api_proc_log_failed_auth_attempts @userid varchar(20), @mode varchar(20), @table_name varchar(20)
as

declare @sql nvarchar(500)

if  @mode = 'add'
begin

        declare @table_attempt int
        declare @rcount int

        set @sql = 'select @a = failedAuthAttempts from ' + @table_name
        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		set @sql = @sql + ' select @b = @@Rowcount'

		print @sql
        EXEC sys.[sp_executesql] @sql , N'@a int out , @b int out', @table_attempt out , @rcount out
        --select @rcount = @@Rowcount
		print @rcount
		print @table_attempt

        --------------------update attempts -------------

        if @rcount = 1
        begin
            set @table_attempt = 1 + @table_attempt 
        end
        else
        begin
            set @table_attempt = 1
        end

		print 'will add : ' +  convert(varchar(10),@table_attempt)

        set @sql = ' update ' + @table_name + ' set failedAuthAttempts = ' + convert(varchar(10),@table_attempt)

        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

		print @sql
        EXEC sys.[sp_executesql] @sql     
end
else if @mode = 'reset'
begin
        
        set @sql = ' update ' + @table_name + ' set failedAuthAttempts = 0 '

        if @table_name = 'sponadministrator'
        begin
            set @sql = @sql + ' where SPAD_UserID = ''' + convert(varchar(20),@userid ) + ''' '
        end
        else   
        begin
            set @sql = @sql + ' where userid = ''' + convert(varchar(20),@userid ) + ''' '
        end

        EXEC sys.[sp_executesql] @sql   
end