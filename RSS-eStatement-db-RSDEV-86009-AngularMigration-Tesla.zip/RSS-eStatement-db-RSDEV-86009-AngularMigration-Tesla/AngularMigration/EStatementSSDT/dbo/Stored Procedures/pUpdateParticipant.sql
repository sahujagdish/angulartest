﻿create procedure dbo.pUpdateParticipant 
@p_fname		varchar(20),
@p_mi			varchar(1),
@p_lname		varchar(20),
@p_email		varchar(80),
@p_password		varchar(32),
@p_statuscode	varchar(2),
@p_part_id int,
@p_acctnumber	varchar(20),
@p_bit_setAdmin bit
as

declare @sql nvarchar(2000)
declare @prev_pass nvarchar(50)

SELECT	@prev_pass = password
FROM	Participant
WHERE	ParticipantID = @p_part_id


set @sql = ' UPDATE	Participant SET	
            FName = ''' + @p_fname + '''
			,MI = ''' + @p_mi + '''
			,LName = ''' + @p_lname + '''
			,EMail = ''' + @p_email + ''' '
if @p_password	<> ''
begin
set @sql = @sql + ',Password = ''' + @p_password + ''' '
end

set @sql = @sql + ' ,StatusCode = ''' + @p_statuscode + '''
			,LastChange = getdate()
			,LastChangeID = ' + convert(varchar(10), @p_part_id ) 

if @p_acctnumber	<> ''
begin
set @sql = @sql + ',AcctNumber = ''' + @p_acctnumber + ''' '
end

if @p_bit_setAdmin = 1
begin
set @sql = @sql + ',PasswordEditByAdmin = 1
,PrevPassword = ''' + @prev_pass  + ''' '
end

set @sql = @sql + ' ,isPasswordHashed = 1
			        ,failedAuthAttempts = 0
			        WHERE	ParticipantID =  ''' + convert(varchar(10), @p_part_id)  + ''' '
					print @sql
EXEC sys.[sp_executesql] @sql 
go
