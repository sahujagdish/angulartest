﻿create procedure [dbo].[pGetSSIdentPartIDForSponsor] @uid varchar(50), @provid varchar(5),  @isin int, @superSponsor bit,@assetRetention bit
as
	if @assetRetention = 1
		begin

			create table #tmpTable
			(
				PLAN_Plan_Num varchar(100)   
			)
			
			insert into #tmpTable
			exec pGetSponPlanForSponsor @isin, @superSponsor

			SELECT distinct part_id, batch,plan_num
	        FROM ss_ident
	        WHERE uid = @uid
		    AND PROVID = @provid
			AND plan_num in (select PLAN_Plan_Num from #tmpTable)
			
			drop table #tmpTable
		end
	else
		begin
			SELECT distinct part_id, batch,plan_num
	        FROM ss_ident
	        WHERE uid = @uid
		    AND PROVID = @provid
		end
go