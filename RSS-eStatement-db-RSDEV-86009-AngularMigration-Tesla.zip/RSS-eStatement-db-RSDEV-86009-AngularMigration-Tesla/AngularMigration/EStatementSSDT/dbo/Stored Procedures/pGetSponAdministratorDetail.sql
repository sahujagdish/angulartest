﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777
--Example: pGetSponAdministratorDetail 1,2,0
create procedure [dbo].[pGetSponAdministratorDetail] @SPAD_Active bit, @SPAD_SPON_ID int, @isAssetRetention bit
as
	if @isAssetRetention = 0
		begin
			select SPAD_ID as control_id, 
			SPAD_UserID, 
			SPAD_Password, 
			SPAD_LName as control_name,  
			dtnumber, 
			internal_user as  isInternalUser,
			SPAD_FName, 
			SPAD_SPPF_ID, 
			SPAD_Num,SPAD_EMail,
			CAST(0 as bit) as updated, 
		 	CAST(1 as bit) as active, 
			'' as SPAD_AgentID,
			SPAD_LName
			from SponAdministrator
			where SPAD_Active = @SPAD_Active and SPAD_SPON_ID = @SPAD_SPON_ID
			order by control_name, SPAD_FName
		end
	else
		begin
			select SPAD_ID as control_id, 
			SPAD_UserID, 
			SPAD_Password, 
			SPAD_LName as control_name,  
			dtnumber, 
			internal_user as  isInternalUser,
			SPAD_FName, 
			SPAD_SPPF_ID, 
			SPAD_Num,
			SPAD_EMail,
			CAST(0 as bit) as updated, 
			CAST(1 as bit) as active,
			SPAD_AgentID,
			SPAD_LName
			from SponAdministrator
			where SPAD_Active = @SPAD_Active and SPAD_SPON_ID = @SPAD_SPON_ID
			order by control_name, SPAD_FName
		end
go
	