﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pUpdateSponProfiles]
	@controlID int,
	@controlName varchar(100),
	@linkTable LinkDetailTableType readonly
AS
	update SponProfiles
	set SPPF_Name= @controlName
	where SPPF_ID= @controlId

	DELETE 
	FROM SponProfileLinks
	WHERE SPPR_SPPF_ID = @controlId

	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	VALUES (@controlId,1)

	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	VALUES (@controlId,2)


	INSERT INTO SponProfileLinks(SPPR_SPPF_ID,SPPR_SPLI_ID)
	select @controlID,SpliID from @linkTable where Active = 1
go