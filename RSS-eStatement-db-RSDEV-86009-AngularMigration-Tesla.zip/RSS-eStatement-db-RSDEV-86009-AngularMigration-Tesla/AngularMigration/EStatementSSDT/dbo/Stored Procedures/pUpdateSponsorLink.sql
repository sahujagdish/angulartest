﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pUpdateSponsorLink]
	@controlID int,
	@active bit,
	@linkTable LinkDetailTableType readonly
AS

		DELETE
		FROM SponAdminLinks
		WHERE SPAD_SPON_ID = @controlID

		INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
		VALUES (1,@controlID)

		INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
		VALUES (2,@controlID)

		INSERT INTO SponAdminLinks(SPAD_SPLI_ID,SPAD_SPON_ID)
		select SpliID,@controlID from @linkTable where Active = 1

		UPDATE SPONSOR
		SET SPON_ACTIVE = @active
		WHERE SPON_ID = @controlID
go
