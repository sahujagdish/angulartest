﻿create procedure dbo.pGetSSIdentPartID @uid varchar(50), @provid varchar(5)
as
	SELECT DISTINCT PART_ID, PLATFORM, BATCH
	FROM SS_IDENT
	WHERE UID = @uid
		AND PROVID = @provid