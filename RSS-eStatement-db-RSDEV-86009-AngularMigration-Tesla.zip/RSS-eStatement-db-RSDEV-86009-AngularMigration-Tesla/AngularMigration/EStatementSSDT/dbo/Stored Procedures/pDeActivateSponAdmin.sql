﻿--CREATEBY: Dhiraj Dusane
--RSDEV-90777

CREATE PROCEDURE [dbo].[pDeActivateSponAdmin]
	@spadId int
AS
	update SponAdministrator
	set SPAD_Active= 0
	where SPAD_ID= @spadId
RETURN 0
