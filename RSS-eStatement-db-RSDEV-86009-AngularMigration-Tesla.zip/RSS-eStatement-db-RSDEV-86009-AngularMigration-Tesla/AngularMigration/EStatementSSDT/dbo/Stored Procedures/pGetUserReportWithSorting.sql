﻿--Pavan Chavan
--RSDEV-92003

create PROCEDURE [dbo].[pGetUserReportWithSorting]
	@providerID int,
	@statusCode varchar(2)    = '',
	@lname      varchar(40)   = '',
	@queryType  varchar(20)   = 'report',
	@iSID       int           = 0,
	@planNumber varchar(16)   = '',
	@start      int           = 0,
	@limit      int           = 20,
	@sortField  nvarchar(200) = 'lname',
	@sortDir    varchar(4)    = 'ASC',
	@hideSensitivePlans bit   = 0,
	@provID      varchar(4)   = '',
	@totalCount int OUTPUT
AS
BEGIN

	SET NOCOUNT ON;
	
	declare @q varchar(8000);
	
	create table #tmpUserReport(
		acctNumber    varchar(20),
		ssn           varchar(11),
		lname         varchar(40),
		fname         varchar(30),
		statusName    varchar(20),
		email         varchar(80),
		statusCode    varchar(2),
		planNum       varchar(16)		
		--rowNum        int IDENTITY(1,1)
	)

	create table #tmpUserReportPlanFiltered(
		acctNumber    varchar(20),
		ssn           varchar(11),
		lname         varchar(40),
		fname         varchar(30),
		statusName    varchar(20),
		email         varchar(80),
		statusCode    varchar(2),	
		planNum       varchar(16),	
		rowNum        int IDENTITY(1,1)
	)


IF @iSID > 0
	BEGIN
		insert into #tmpUserReport
		select * from (
			select distinct participant.acctnumber,
				   participant.ssn,
				   participant.lname,
				   participant.fname, 
				   statuscodes.statusname,
				   participant.email,
				   participant.statuscode,
				   PlanNum = ( select distinct top 1 plan_num
							   from ss_ident
							   where ssn = part_id 
								and provID = @provID)
			from participant,
				 statuscodes,
				 ss_ident
			where  participant.statuscode = statuscodes.statuscode
				   and participant.providerid = @providerID
				   and ( participant.statuscode = @statusCode or @statusCode = '' )
				   and ( participant.lname like @lname + '%' or @lname = '' )
				   and ss_ident.part_id = participant.ssn
				   and ss_ident.plan_num in ( select Plans.PLAN_Plan_Num
											from SponPlan,
												 Plans
											where SponPlan.SPPL_Plan_ID = Plans.Plan_ID
												and SponPlan.SPPL_Spon_ID = @iSID 
												and Plans.PLAN_ProvID =	@provID)
				   and ( ss_ident.plan_num = @planNumber or @planNumber = '' )
		) a 			
		order by
			case when @sortField = 'lname'      and @sortDir = 'DESC' then a.lname      END DESC,
			case when @sortField = 'lname'      and @sortDir = 'ASC'  then a.lname      END ASC,
			case when @sortField = 'fname'      and @sortDir = 'DESC' then a.fname      END DESC,
			case when @sortField = 'fname'      and @sortDir = 'ASC'  then a.fname      END ASC,
			case when @sortField = 'acctNumber' and @sortDir = 'DESC' then a.acctnumber END DESC,
			case when @sortField = 'acctNumber' and @sortDir = 'ASC'  then a.acctnumber END ASC,
			case when @sortField = 'ssn'        and @sortDir = 'DESC' then a.ssn        END DESC,
			case when @sortField = 'ssn'        and @sortDir = 'ASC'  then a.ssn        END ASC,
			case when @sortField = 'email'      and @sortDir = 'DESC' then a.email      END DESC,
			case when @sortField = 'email'      and @sortDir = 'ASC'  then a.email      END ASC,
			case when @sortField = 'statusName' and @sortDir = 'DESC' then a.statusname END DESC,
			case when @sortField = 'statusName' and @sortDir = 'ASC'  then a.statusname END ASC,
			case when @sortField = 'planNumber' and @sortDir = 'DESC' then a.planNum    END DESC,
			case when @sortField = 'planNumber' and @sortDir = 'ASC'  then a.planNum    END ASC

	END
ELSE
	BEGIN
		
		if @sortField = 'planNumber'
			set @sortField = 'planNum';

		set @q = 'insert into #tmpUserReport 
				 select * from (
					select distinct participant.acctnumber,
				   participant.ssn,
				   participant.lname,
				   participant.fname, 
				   statuscodes.statusname,
				   participant.email,
				   participant.statuscode,
				   PlanNum = ( select distinct top 1 plan_num
							   from ss_ident
							   where ssn = part_id and provid = ''' + @provID + ''')
			from participant,
				 statuscodes,
				ss_ident
			where  participant.statuscode = statuscodes.statuscode
				   and participant.providerid = ' + convert(varchar,@providerID) + 
				   ' and ss_ident.part_id = participant.ssn
					 and ss_ident.plan_num in ( select Plans.PLAN_Plan_Num 
												from SponPlan, Plans
												where SponPlan.SPPL_Plan_ID = Plans.Plan_ID 
													and Plans.PLAN_ProvID = ''' + @provID + '''' 
													if @hideSensitivePlans = 1
														set @q = @q + '	and Plans.PLAN_Sensitive = 0'
													set @q = @q + ') '	
			if @statusCode <> ''
				set @q = @q + ' and (participant.statuscode = ''' + @statusCode + ''') '	   
				
			if @lname <> ''
				set @q = @q + ' and ( participant.lname like ''' + @lname + '%'') '
			
			set	@q = @q + ') a order by ' + @sortField + ' ' + @sortDir
		
		print @q
		exec (@q)	
END

	-- filter by plan separately because when a user does not have statement data,
	-- they will not have data in the ss_ident table.
	if @planNumber = ''
		begin
			insert into #tmpUserReportPlanFiltered
			select *
			from #tmpUserReport		
		end
	else
		begin
			insert into #tmpUserReportPlanFiltered
			select distinct t.*
			from #tmpUserReport t,
				ss_ident s
			where s.part_id = t.ssn
				and (s.provid = @provID or @provID = '')
				and ( s.plan_num = @planNumber or @planNumber = '' )
		end

	IF @queryType = 'report'
	BEGIN
		select *
		from #tmpUserReportPlanFiltered
		where RowNum >  convert( varchar(9), @start              ) and
			  RowNum <= convert( varchar(9), ( @start + @limit ) ) 
			  order by
			case when @sortField = 'lname'      and @sortDir = 'DESC' then lname      END DESC,
			case when @sortField = 'lname'      and @sortDir = 'ASC'  then lname      END ASC,
			case when @sortField = 'fname'      and @sortDir = 'DESC' then fname      END DESC,
			case when @sortField = 'fname'      and @sortDir = 'ASC'  then fname      END ASC,
			case when @sortField = 'acctNumber' and @sortDir = 'DESC' then acctnumber END DESC,
			case when @sortField = 'acctNumber' and @sortDir = 'ASC'  then acctnumber END ASC,
			case when @sortField = 'ssn'        and @sortDir = 'DESC' then ssn        END DESC,
			case when @sortField = 'ssn'        and @sortDir = 'ASC'  then ssn        END ASC,
			case when @sortField = 'email'      and @sortDir = 'DESC' then email      END DESC,
			case when @sortField = 'email'      and @sortDir = 'ASC'  then email      END ASC,
			case when @sortField = 'statusName' and @sortDir = 'DESC' then statusname END DESC,
			case when @sortField = 'statusName' and @sortDir = 'ASC'  then statusname END ASC,
			case when @sortField = 'planNumber' and @sortDir = 'DESC' then planNum    END DESC,
			case when @sortField = 'planNumber' and @sortDir = 'ASC'  then planNum    END ASC

		select @totalCount = count(*) from #tmpUserReportPlanFiltered
	END
	ELSE
	BEGIN
		select *
		from #tmpUserReportPlanFiltered
		 order by
			case when @sortField = 'lname'      and @sortDir = 'DESC' then lname      END DESC,
			case when @sortField = 'lname'      and @sortDir = 'ASC'  then lname      END ASC,
			case when @sortField = 'fname'      and @sortDir = 'DESC' then fname      END DESC,
			case when @sortField = 'fname'      and @sortDir = 'ASC'  then fname      END ASC,
			case when @sortField = 'acctNumber' and @sortDir = 'DESC' then acctnumber END DESC,
			case when @sortField = 'acctNumber' and @sortDir = 'ASC'  then acctnumber END ASC,
			case when @sortField = 'ssn'        and @sortDir = 'DESC' then ssn        END DESC,
			case when @sortField = 'ssn'        and @sortDir = 'ASC'  then ssn        END ASC,
			case when @sortField = 'email'      and @sortDir = 'DESC' then email      END DESC,
			case when @sortField = 'email'      and @sortDir = 'ASC'  then email      END ASC,
			case when @sortField = 'statusName' and @sortDir = 'DESC' then statusname END DESC,
			case when @sortField = 'statusName' and @sortDir = 'ASC'  then statusname END ASC,
			case when @sortField = 'planNumber' and @sortDir = 'DESC' then planNum    END DESC,
			case when @sortField = 'planNumber' and @sortDir = 'ASC'  then planNum    END ASC

		select @totalCount = count(*) from #tmpUserReportPlanFiltered
	END

	drop table #tmpUserReport 
	drop table #tmpUserReportPlanFiltered 

END
GO


