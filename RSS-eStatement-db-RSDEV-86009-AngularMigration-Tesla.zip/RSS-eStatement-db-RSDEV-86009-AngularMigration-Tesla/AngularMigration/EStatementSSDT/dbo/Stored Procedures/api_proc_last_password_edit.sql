﻿
create procedure dbo.api_proc_last_password_edit @id int, @mode varchar(20)
as
if @mode = 'participant'
begin
        select LastPasswordEdit
        from participant
        where participantid = @id
end
else if @mode = 'administrator'
begin
        select LastPasswordEdit
        from administrator
        where administratorID = @id
end
else if @mode = 'sponadministrator'
begin
        select LastPasswordEdit
        from sponAdministrator
        where SPAD_ID =  @id
end
else
begin
		select convert(datetime,'1900-01-01')
end