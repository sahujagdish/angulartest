﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create procedure [dbo].[pGetSponLinks]  @providerID  int,  @spadID int
as
	declare @SponHandshake bit
	declare @SponExitURL varchar(100)

	declare @SpadSponID int
	declare @SpadSpppfID int

	select @SponHandshake = SponHandshake , @SponExitURL = SponExitURL from Provider where providerid = @spadID

	select @SpadSponID = SPAD_SPON_ID , @SpadSpppfID = SPAD_SPPF_ID from SponAdministrator where SPAD_ID = @spadID
	
	declare	@sql varchar(1000)
	set @sql =	'SELECT vSponLinkRoutes.SPLI_Text,vSponLinkRoutes.NewSPLI_URL as SPLI_URL ,vSponLinkRoutes.Popup,vSponLinkRoutes.Secure
			FROM vSponLinkRoutes,SponAdminLinks,SponProfileLinks,SponProfiles
			WHERE (vSponLinkRoutes.SPLI_ID = SponAdminLinks.SPAD_SPLI_ID)
				AND (SponProfileLinks.SPPR_SPPF_ID = SponProfiles.SPPF_ID)
				AND (vSponLinkRoutes.SPLI_ID = SponProfileLinks.SPPR_SPLI_ID)'

	set @sql = @sql + ' AND SponProfiles.SPPF_Spon_ID = ' + convert(varchar(10),@SpadSponID) +
				  ' AND SponAdminLinks.SPAD_SPON_ID = ' + convert(varchar(10),@SpadSponID) +
				  ' AND SponProfileLinks.SPPR_SPPF_ID = ' + convert(varchar(10),@SpadSpppfID)

	if @SponHandshake = 1 and @SponExitURL = ''
	begin
	set @sql = @sql + ' AND (vSponLinkRoutes.Handshake = 1	) '
	end
	else if  @SponHandshake = 1 and @SponExitURL <> ''
	begin
	set @sql = @sql + ' AND ((vSponLinkRoutes.Handshake = 1) OR (vSponLinkRoutes.SPLI_Text = ''Logout'')) '
	end
	
	set @sql = @sql + ' ORDER BY SPLI_Order '
	print @sql
	exec (@sql) 
go
