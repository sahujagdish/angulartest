﻿
create PROCEDURE dbo.eStatement_proc_qGetProviderCommunications
@ProviderID int
as
	SELECT tdCommunications.CommunicationTypeCD, tdCommunications.Descrip,teProviderCommunications.DisplayOrder
		FROM teProviderCommunications, tdCommunications 
		WHERE teProviderCommunications.CommunicationTypeCD = tdCommunications.CommunicationTypeCD 
			AND teProviderCommunications.ProviderID = @ProviderID 
			ORDER BY teProviderCommunications.DisplayOrder