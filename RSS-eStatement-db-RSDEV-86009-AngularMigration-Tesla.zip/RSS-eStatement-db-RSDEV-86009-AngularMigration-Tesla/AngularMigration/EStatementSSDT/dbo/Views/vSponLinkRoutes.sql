﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create view dbo.vSponLinkRoutes
as
select p.*,aa.NewSPLI_URL from SponLinks p left join SponLinkRoutes aa on p.SPLI_ID = aa.SPLI_ID
go