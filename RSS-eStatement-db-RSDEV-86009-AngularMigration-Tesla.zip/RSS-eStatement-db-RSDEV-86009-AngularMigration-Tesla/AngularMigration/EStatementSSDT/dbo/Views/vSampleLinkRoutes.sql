﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create view dbo.vSampleLinkRoutes
as
select p.*,aa.NewSampleURL from SampleLinks p left join SampleLinkRoutes aa on p.SampleID = aa.SampleID
go