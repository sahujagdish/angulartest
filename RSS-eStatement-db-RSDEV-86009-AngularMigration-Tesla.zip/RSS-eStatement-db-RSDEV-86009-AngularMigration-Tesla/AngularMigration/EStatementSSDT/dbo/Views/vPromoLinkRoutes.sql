﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

create view dbo.vPromoLinkRoutes
as
select p.*,aa.NewLinkURL from PromoLinks p left join PromoLinkRoutes aa on p.LinkID = aa.LinkID
go