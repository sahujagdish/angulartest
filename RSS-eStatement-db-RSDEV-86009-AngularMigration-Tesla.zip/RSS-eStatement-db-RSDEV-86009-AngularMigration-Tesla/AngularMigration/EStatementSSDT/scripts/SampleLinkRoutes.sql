﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

-- =============================================
-- Initialize SampleLinkRoutes table
-- =============================================

Merge Into dbo.[SampleLinkRoutes] AS Target 
Using (Values
	('View Sample Newsletter','newsletter'),
	('View Sample eStatement','eStatementSample.pdf')
	)
	As Source ([SampleText], [NewSampleURL]) join SampleLinks a on Source.[SampleText] = a.[SampleText]
On Target.[SampleID] = a.[SampleID]
When MATCHED Then 
	Update Set 
		[NewSampleURL] = Source.[NewSampleURL]
When Not Matched By Target Then 
	Insert ([SampleID], [NewSampleURL])
	Values ([SampleID], [NewSampleURL])
When Not Matched By Source Then 
Delete;
