﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

-- =============================================
-- Initialize AdminlinkRoutes table
-- =============================================

Merge Into dbo.[AdminlinkRoutes] AS Target 
Using (Values
	('Access Participant Information','access-participant-info'),
	('Audit Reports','auditReport'),
	('User Reports','userReport'),
	('Staff Access','staffAccess'),
	('Staff Profiles','staffProfiles'),
	('Sponsor Access','sponsor-access'),
	('Summary Reports','summaryReport'),
	('Site Text','siteText'),
	('Ordered Site Text','orderedSiteText'),
	('Statement Repository','statement-repo'),
	('Statement Print Approval','statement-print-approval'),
	('Message Board','message-board')
	)
	As Source ([LinkText], [NewLinkUrl]) join AdminLinks a on Source.[LinkText] = a.[LinkText]
On Target.[LinkID] = a.[LinkID]
When MATCHED Then 
	Update Set 
		[NewLinkUrl] = Source.[NewLinkUrl]
When Not Matched By Target Then 
	Insert ([LinkID], [NewLinkUrl])
	Values ([LinkID], [NewLinkUrl])
When Not Matched By Source Then 
Delete;
