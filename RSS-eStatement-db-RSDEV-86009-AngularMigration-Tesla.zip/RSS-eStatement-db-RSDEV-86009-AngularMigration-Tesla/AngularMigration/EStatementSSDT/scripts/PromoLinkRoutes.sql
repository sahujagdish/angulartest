﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

-- =============================================
-- Initialize PromoLinkRoutes table
-- =============================================

Merge Into dbo.[PromoLinkRoutes] AS Target 
Using (Values
	('Home','Home'),
	('About eStatements','About-eStatements'),
	('FAQ','faq'),
	('About eCommunications','About-eCommunications')
	)
	As Source ([LinkText], [NewLinkUrl]) join PromoLinks a on Source.[LinkText] = a.[LinkText]
On Target.[LinkID] = a.[LinkID]
When MATCHED Then 
	Update Set 
		[NewLinkUrl] = Source.[NewLinkUrl]
When Not Matched By Target Then 
	Insert ([LinkID], [NewLinkUrl])
	Values ([LinkID], [NewLinkUrl])
When Not Matched By Source Then 
Delete;
