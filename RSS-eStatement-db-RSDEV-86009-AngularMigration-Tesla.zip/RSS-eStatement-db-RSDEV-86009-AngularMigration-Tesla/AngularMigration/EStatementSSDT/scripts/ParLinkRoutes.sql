﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

-- =============================================
-- Initialize ParLinkRoutes table
-- =============================================

Merge Into dbo.[ParLinkRoutes] AS Target 
Using (Values
	('Statement','view-Statements'),
	('Update Profile','update-profile'),
	('Unsubscribe','unsubscribe'),
	('Newsletter','newsletter'),
	('Disclosure','disclosure'),
	('FAQ','faq')
	)
	As Source ([LinkText], [NewLinkUrl]) join ParLinks a on Source.[LinkText] = a.[LinkText]
On Target.[LinkID] = a.[LinkID]
When MATCHED Then 
	Update Set 
		[NewLinkUrl] = Source.[NewLinkUrl]
When Not Matched By Target Then 
	Insert ([LinkID], [NewLinkUrl])
	Values ([LinkID], [NewLinkUrl])
When Not Matched By Source Then 
Delete;
