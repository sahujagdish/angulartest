﻿--CREATEBY: Dhiraj Dusane
--RSDEV-93582

-- =============================================
-- Initialize SponLinkRoutes table
-- =============================================

Merge Into dbo.[SponLinkRoutes] AS Target 
Using (Values
	('Access Participant Information','access-participant-info'),
	('Summary Reports','summaryReport'),
	('Update Profile','update-profile'),
	('Audit Reports','auditReport'),
	('User Reports','userReport'),
	('Statement Repository','statement-repo')
	)
	As Source ([SPLI_Text], [NewSPLI_URL]) join SponLinks a on Source.[SPLI_Text] = a.[SPLI_Text]
	On Target.[SPLI_ID] = a.[SPLI_ID]
	When MATCHED Then 
		Update Set 
			[NewSPLI_URL] = Source.[NewSPLI_URL]
	When Not Matched By Target Then 
		Insert ([SPLI_ID], [NewSPLI_URL])
		Values ([SPLI_ID], [NewSPLI_URL])
	When Not Matched By Source Then 
	Delete;
