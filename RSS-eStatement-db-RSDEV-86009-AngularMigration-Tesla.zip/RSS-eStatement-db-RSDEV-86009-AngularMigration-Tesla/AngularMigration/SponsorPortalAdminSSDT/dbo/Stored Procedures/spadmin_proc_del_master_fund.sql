﻿
create PROCEDURE [dbo].spadmin_proc_del_master_fund
@masterFundIdList varchar(200),
@providerid uniqueidentifier
as
	declare @sql nvarchar(1000)
	set @sql = '	DELETE FROM [teMasterFund]
			WHERE
			MasterFundID in(' + @masterFundIdList + ')
			and
			ProviderId = ''' +  convert(nvarchar(36),@providerid) + ''
	EXEC sys.[sp_executesql] @sql