﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_instanced_content @planid int, @providerID  uniqueidentifier,@contentId int
as
		SELECT tePlan_Document.Plan_DocumentId, tdContentTypes.Name, tePlan_Document.InstanceId, 
        tdContentTypes.Name + ' ' + CAST(Format(tePlan_Document.dateUpdated, 'd', 'en-US') AS varchar(10)) AS InstancedName
		FROM tePlan INNER JOIN
		tePlan_Document ON tePlan.PlanId = tePlan_Document.PlanId INNER JOIN
		teSponsor ON tePlan.SponsorId = teSponsor.SponsorId INNER JOIN
		tdContentTypes ON tePlan_Document.ContentId = tdContentTypes.ContentId
		WHERE  tePlan.PlanId = @planid
		AND teSponsor.ProviderId = @providerID
		AND tePlan.isActive = 1
		AND tePlan_Document.ContentID = @contentId
		AND ((tePlan_Document.ExpirationDate IS NULL) or (tePlan_Document.ExpirationDate > getdate()))
		ORDER BY InstancedName