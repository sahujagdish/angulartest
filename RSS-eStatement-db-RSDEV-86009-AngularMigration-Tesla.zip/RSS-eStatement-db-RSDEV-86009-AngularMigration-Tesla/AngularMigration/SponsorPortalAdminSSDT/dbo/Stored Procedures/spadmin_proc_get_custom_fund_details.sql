﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_custom_fund_details @providerID  uniqueidentifier, @MasterFundID int
AS
				SELECT  
				CASE WHEN Name IS NOT NULL THEN Name ELSE '' END AS Name
				,CASE WHEN FundID IS NOT NULL THEN FundID ELSE '' END AS FundID
				,CASE WHEN Cusip IS NOT NULL THEN rtrim(cusip) ELSE '' END AS cusip
				,CASE WHEN Ticker IS NOT NULL THEN rtrim(ticker) ELSE '' END AS ticker
				,CASE WHEN CustomFundCode IS NOT NULL THEN CustomFundCode ELSE '' END AS CustomFundCode
				,CASE WHEN AssetClass IS NOT NULL THEN AssetClass ELSE '' END AS AssetClass
				,CASE WHEN OneMonth = - 999 OR OneMonth IS NULL THEN '' ELSE Cast(OneMonth AS varchar(10))END AS OneMonth
				,CASE WHEN ThreeMonth = - 999 OR ThreeMonth IS NULL THEN '' ELSE Cast(ThreeMonth AS varchar(10))END AS ThreeMonth
				,CASE WHEN OneYear = - 999 OR OneYear IS NULL THEN '' ELSE Cast(OneYear AS varchar(10))END AS OneYear
				,CASE WHEN ThreeYear = - 999 OR ThreeYear IS NULL THEN '' ELSE Cast(ThreeYear AS varchar(10))END AS ThreeYear
				,CASE WHEN FiveYear = - 999 OR FiveYear IS NULL THEN '' ELSE Cast(FiveYear AS varchar(10))END AS FiveYear
				,CASE WHEN TenYear = - 999 OR TenYear IS NULL THEN '' ELSE Cast(TenYear AS varchar(10))END AS TenYear
				,CASE WHEN AsOfDate IS NOT NULL THEN CONVERT(varchar(10), AsofDate, 101) ELSE '' END AS AsOfDate
				,CASE WHEN SinceInception = - 999 OR SinceInception IS NULL THEN '' ELSE Cast(SinceInception AS varchar(10))END AS SinceInception
				,CASE WHEN PrevYr1Return = - 999 OR PrevYr1Return IS NULL THEN '' ELSE Cast(PrevYr1Return AS varchar(10))END AS PrevYr1Return
				,CASE WHEN PrevYr2Return = - 999 OR PrevYr2Return IS NULL THEN '' ELSE Cast(PrevYr2Return AS varchar(10))END AS PrevYr2Return
				,CASE WHEN PrevYr3Return = - 999 OR PrevYr3Return IS NULL THEN '' ELSE Cast(PrevYr3Return AS varchar(10))END AS PrevYr3Return
				,CASE WHEN PrevYr4Return = - 999 OR PrevYr4Return IS NULL THEN '' ELSE Cast(PrevYr4Return AS varchar(10))END AS PrevYr4Return
				,CASE WHEN PrevYr5Return = - 999 OR PrevYr5Return IS NULL THEN '' ELSE Cast(PrevYr5Return AS varchar(10))END AS PrevYr5Return
				,CASE WHEN PrevYr6Return = - 999 OR PrevYr6Return IS NULL THEN '' ELSE Cast(PrevYr6Return AS varchar(10))END AS PrevYr6Return
				,CASE WHEN YTD = - 999 OR YTD IS NULL THEN '' ELSE Cast(YTD AS varchar(10))END AS YTD
				,CASE WHEN Inception IS NOT NULL THEN CONVERT(varchar(10), Inception, 101) ELSE '' END AS Inception
				,CASE WHEN ExpRatio = - 999 OR ExpRatio IS NULL THEN '' ELSE Cast(ExpRatio AS varchar(10))END AS ExpRatio
				,CASE WHEN ExpDate IS NOT NULL THEN Cast(rtrim(ExpDate) AS varchar(10)) ELSE '' END AS ExpDate
				,CASE WHEN NetExpRatio = - 999 OR NetExpRatio IS NULL THEN '' ELSE Cast(NetExpRatio AS varchar(11))END AS NetExpRatio
				,CASE WHEN MgmtStylePassive = 1 THEN 'Passive' 
                	  WHEN MgmtStylePassive = 0 THEN 'Active'  	
                      ELSE ''
                 END AS MgmtStylePassive     
				,CASE WHEN WebSite IS NOT NULL THEN WebSite ELSE '' END AS WebSite
				,CASE WHEN MorningStarCategory IS NOT NULL THEN MorningStarCategory ELSE '' END AS MorningStarCategory
				,CASE WHEN BenchmarkName IS NOT NULL THEN BenchmarkName ELSE '' END AS BenchmarkName
				,CASE WHEN BenchmarkOneMonth = - 999 OR BenchmarkOneMonth IS NULL THEN '' ELSE Cast(BenchmarkOneMonth AS varchar(11))END AS BenchmarkOneMonth
				,CASE WHEN BenchmarkThreeMonth = - 999 OR BenchmarkThreeMonth IS NULL THEN '' ELSE Cast(BenchmarkThreeMonth AS varchar(11))END AS BenchmarkThreeMonth
				,CASE WHEN BenchmarkOneYear = - 999 OR BenchmarkOneYear IS NULL THEN '' ELSE Cast(BenchmarkOneYear AS varchar(11))END AS BenchmarkOneYear
				,CASE WHEN BenchmarkThreeYear = - 999 OR BenchmarkThreeYear IS NULL THEN '' ELSE Cast(BenchmarkThreeYear AS varchar(11))END AS BenchmarkThreeYear
				,CASE WHEN BenchmarkFiveYear = - 999 OR BenchmarkFiveYear IS NULL THEN '' ELSE Cast(BenchmarkFiveYear AS varchar(11))END AS BenchmarkFiveYear
				,CASE WHEN BenchmarkTenYear = - 999 OR BenchmarkTenYear IS NULL THEN '' ELSE Cast(BenchmarkTenYear AS varchar(11))END AS BenchmarkTenYear
				,CASE WHEN BenchNote IS NOT NULL THEN BenchNote ELSE '' END AS BenchNote
				,CASE WHEN MgmtFee = - 999 OR MgmtFee IS NULL THEN '' ELSE Cast(MgmtFee AS varchar(11))END AS MgmtFee 
				,CASE WHEN Fee12B1 = - 999 OR Fee12B1 IS NULL THEN '' ELSE Cast(Fee12B1 AS varchar(11))END AS Fee12B1
				,CASE WHEN OtherFees = - 999 OR OtherFees IS NULL THEN '' ELSE Cast(OtherFees AS varchar(11))END AS OtherFees
				,CASE WHEN RedemptionFee = - 999 OR RedemptionFee IS NULL THEN '' ELSE Cast(RedemptionFee AS varchar(11))END AS RedemptionFee
				,CASE WHEN RedeemDays IS NULL THEN '' ELSE  Cast(RedeemDays AS varchar(3)) END AS RedeemDays
				,CASE WHEN FrontEndSalesCharge = - 999 OR FrontEndSalesCharge IS NULL THEN '' ELSE Cast(FrontEndSalesCharge AS varchar(11))END AS FrontEndSalesCharge
				,CASE WHEN DeferredSalesCharge = - 999 OR DeferredSalesCharge IS NULL THEN '' ELSE Cast(DeferredSalesCharge AS varchar(11))END AS DeferredSalesCharge
				,UseStandardPerformance
                ,customprospectus,customFundFactSheet
			FROM teMasterFund
			WHERE (ProviderId = @providerID)
				AND MasterFundID = @MasterFundID