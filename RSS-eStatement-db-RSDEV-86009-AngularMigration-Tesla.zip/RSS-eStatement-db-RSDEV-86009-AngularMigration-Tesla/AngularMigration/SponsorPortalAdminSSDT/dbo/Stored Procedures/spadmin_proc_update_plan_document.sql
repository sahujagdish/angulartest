﻿
CREATE PROCEDURE [dbo].spadmin_proc_update_plan_document @userid uniqueidentifier, @contentId int,@planId int, @instanceId int
as
if @instanceId > -1
begin
		UPDATE tePlan_Document
		SET isActive = 0 , dateUpdated = getdate() , UserId = @userid , publishedfrom = 2
		WHERE ContentID = @contentId
		AND PlanId = @planId
		AND isInProduction = 0
		AND InstanceId = @instanceId
end
else
begin
		UPDATE tePlan_Document
		SET isActive = 0 , dateUpdated = getdate() , UserId = @userid , publishedfrom = 2
		WHERE ContentID = @contentId
		AND PlanId = @planId
		AND isInProduction = 0
end