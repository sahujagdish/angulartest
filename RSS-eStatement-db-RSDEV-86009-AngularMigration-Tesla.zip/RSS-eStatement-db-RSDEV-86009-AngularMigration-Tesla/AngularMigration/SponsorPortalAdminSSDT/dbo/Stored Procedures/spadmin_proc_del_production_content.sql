﻿
create PROCEDURE [dbo].spadmin_proc_del_production_content 
@providerid uniqueidentifier,
@custfundcode varchar(50),
@isfund bit
as
	declare @sql nvarchar(2000)
	set @sql = ' DELETE
	FROM teProviderCustomInvestments
	WHERE CustomFundCode = ''' + @custfundcode + '''
	AND isInProduction = 1
	AND ProviderId = ''' +  convert(nvarchar(36),@providerid) + ''' '
	
	if @isfund = 1
	begin
		set @sql = @sql + ' AND isFund = 1 '
	end
	else
	begin
		set @sql = @sql + ' AND isProspectus = 1 '
	end

	EXEC sys.[sp_executesql] @sql