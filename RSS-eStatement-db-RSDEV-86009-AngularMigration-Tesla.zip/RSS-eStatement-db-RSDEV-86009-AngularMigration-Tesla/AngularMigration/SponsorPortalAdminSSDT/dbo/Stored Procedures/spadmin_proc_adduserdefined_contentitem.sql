﻿
CREATE PROCEDURE [dbo].spadmin_proc_adduserdefined_contentitem @scope varchar(10),
@contentCategoryId int , @fileType varchar(200), @contentName varchar(100),
@providerID  uniqueidentifier ,@useGenericMenuCategoriesForEBN bit
as

declare @p_next_id numeric
declare @p_error numeric

EXEC [dbo].[p_next_id]  'tdContentTypes' ,@p_next_id output, @p_error output 

if @p_error = 0
begin

	DECLARE @sProductCode varchar(20)
	set @sProductCode = 'UDC' + CONVERT(varchar(10),@p_next_id)

	select @fileType = rtrim(ltrim(@fileType))

	declare @sFileName varchar(200)
	set @sFileName = @sProductCode + '.' + @fileType;	


	if @useGenericMenuCategoriesForEBN = 1
	begin
				INSERT INTO tdContentTypes(ContentId,Name,Description,AdminSiteText,FileName,ContentCategoryId,isUploadable,ProductCode,ContentScope,StaticContent)
				VALUES(@p_next_id,@contentName ,@contentName ,@contentName ,@sFileName,@contentCategoryId,1,@sProductCode,@scope,0)
	end
	else
	begin
			INSERT INTO tdContentTypes(ContentId,Name,Description,AdminSiteText,FileName,ContentCategoryId,isUploadable,ProductCode)
				VALUES(@p_next_id, @contentName, @contentName, @contentName,@sFileName,@contentCategoryId,1,@sProductCode)
	end

	--implementation for 'qInsProvider_ContentTypes' function
	INSERT INTO teProvider_ContentTypes(ProviderID,ContentID)
	VALUES(@providerID,@p_next_id)
end

select @p_next_id  as NextID, @p_error as ErrorID