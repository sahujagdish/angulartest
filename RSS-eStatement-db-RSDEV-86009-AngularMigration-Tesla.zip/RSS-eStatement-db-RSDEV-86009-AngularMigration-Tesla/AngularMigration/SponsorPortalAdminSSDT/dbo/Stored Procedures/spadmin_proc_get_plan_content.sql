﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_plan_content @planid int
as

	SELECT tePlan_Document.ContentId, tePlan_Document.dateUpdated, tePlan_Document.isActive
    ,tePlan_Document.Plan_DocumentID, tePlan_Document.isInProduction, 
	tdContentTypes.Name, tdContentTypes.Name + ' ' + Cast(Format(tePlan_Document.dateUpdated, 'd','en-US') as varchar(10)) As InstancedName
    ,tePlan_Document.InstanceId, tdContentTypes.ProductCode, tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText
    FROM tePlan_Document, tdContentTypes 
    WHERE (tdContentTypes.ContentId = tePlan_Document.ContentId)
    AND (tePlan_Document.PlanId = @planid)
    AND (tdContentTypes.isUploadable = 1)
    AND ((tePlan_Document.ExpirationDate IS NULL) or (tePlan_Document.ExpirationDate > getdate()))
    ORDER BY Name, InstancedName