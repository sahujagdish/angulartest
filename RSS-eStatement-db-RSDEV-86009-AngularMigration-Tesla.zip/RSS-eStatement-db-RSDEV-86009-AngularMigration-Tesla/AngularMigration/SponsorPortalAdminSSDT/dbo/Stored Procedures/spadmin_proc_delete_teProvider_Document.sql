﻿
CREATE PROCEDURE [dbo].spadmin_proc_delete_teProvider_Document @providerid uniqueidentifier, @contentId int
as

		DELETE
		FROM teProvider_Document
		WHERE ContentID = @contentId
		AND isInProduction = 1
		AND ProviderId = @providerid