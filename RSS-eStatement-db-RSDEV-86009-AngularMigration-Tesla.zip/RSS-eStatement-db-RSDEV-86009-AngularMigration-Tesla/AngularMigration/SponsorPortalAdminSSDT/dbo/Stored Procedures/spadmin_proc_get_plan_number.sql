﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_plan_number  @planid int, @providerID  uniqueidentifier 
as
	SELECT tePlan.Number, tePlan.Name, teSponsor.Name as SponsorName
	FROM tePlan, teSponsor
	WHERE tePlan.SponsorId = teSponsor.SponsorId
	AND tePlan.PlanId =  @planid
	AND teSponsor.ProviderId = @providerID
	AND tePlan.isActive = 1