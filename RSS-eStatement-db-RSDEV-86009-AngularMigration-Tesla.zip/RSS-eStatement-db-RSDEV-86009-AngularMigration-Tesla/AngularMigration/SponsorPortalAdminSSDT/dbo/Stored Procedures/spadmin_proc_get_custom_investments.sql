﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_custom_investments @providerID  uniqueidentifier
AS
	SELECT MasterFundId, Name, CUSIP, FundID, Ticker, CustomFundCode
	FROM teMasterFund 
	WHERE (CustomFund = 1) AND (ProviderId = @providerID ) 
	ORDER BY Name