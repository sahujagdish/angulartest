﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_plan_link @planid int, @linkid int
as
		SELECT Plan_LinkID
		FROM tePlan_Link
		WHERE PlanID = @planid
		AND LinkId = @linkid