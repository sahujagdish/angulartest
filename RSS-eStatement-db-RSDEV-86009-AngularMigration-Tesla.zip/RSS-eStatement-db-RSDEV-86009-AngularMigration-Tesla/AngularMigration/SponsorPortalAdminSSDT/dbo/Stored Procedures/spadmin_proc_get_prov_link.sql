﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_prov_link @providerID  uniqueidentifier, @contentId int
as
		SELECT teLink.LinkId,teLink.sOrder,teLink.Description, teLink.ContentCategoryId
		FROM teLink, tdContentTypes 
		WHERE teLink.ContentCategoryId = tdContentTypes.ContentCategoryId 
		AND tdContentTypes.ContentId = @contentId
		AND teLink.ProviderId =@providerID