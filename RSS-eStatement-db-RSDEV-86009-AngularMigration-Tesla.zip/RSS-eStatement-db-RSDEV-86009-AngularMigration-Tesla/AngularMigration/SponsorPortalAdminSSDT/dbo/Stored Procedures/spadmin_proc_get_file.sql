﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_file @providerid uniqueidentifier, 
@customfundcode varchar(50), @invType varchar(50)
as

	declare @sql nvarchar(1000)
	set @sql = 'SELECT CustomFundCode FROM teProviderCustomInvestments
				WHERE CustomFundCode = '''+ @customfundcode + '''
				AND ProviderId = '''+  convert(nvarchar(36),@providerid) + '''
				AND isInProduction = 0'
	if @invType = 'fund'
	begin
		set @sql = @sql + ' AND isFund = 1'
	end
	else
	begin
		set @sql = @sql + ' AND isProspectus = 1'
	end

	EXEC sys.[sp_executesql] @sql