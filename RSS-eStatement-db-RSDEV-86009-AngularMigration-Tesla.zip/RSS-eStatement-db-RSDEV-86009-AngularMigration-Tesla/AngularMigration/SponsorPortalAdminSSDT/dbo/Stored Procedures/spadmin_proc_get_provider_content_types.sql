﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_provider_content_types @providerid uniqueidentifier, @useGenericMenuCategoriesForEBN bit
as
	declare @sql nvarchar(1000)
	set @sql = '
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, tdContentTypes.AdminSiteText + ''['' + tdContentTypes.ProductCode + '']'' as AdminSiteText
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories 
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
		AND tdContentTypes.isUploadable = 1
		AND teProvider_ContentTypes.ProviderID = ''' + CONVERT(varchar(50),  @providerid ) + ''''

	if @useGenericMenuCategoriesForEBN = 1
	begin
		set @sql =  @sql  + ' AND tdContentTypes.ContentScope = ''PROVIDER'''
	end
	else
	begin
		set @sql =  @sql +  ' AND tdContentCategories.Scope = ''PROVIDER'''
	end
	
	set @sql =  @sql +  ' ORDER BY tdContentTypes.Name'
	print @sql
	EXEC sys.[sp_executesql] @sql