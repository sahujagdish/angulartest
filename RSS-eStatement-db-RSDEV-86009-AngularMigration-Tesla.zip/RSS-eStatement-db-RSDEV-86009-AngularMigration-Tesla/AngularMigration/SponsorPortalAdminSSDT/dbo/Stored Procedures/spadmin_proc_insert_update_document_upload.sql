﻿
CREATE PROCEDURE [dbo].spadmin_proc_insert_update_document_upload @contentId int,@planId int, @instanceId int, @userId uniqueidentifier, @fileExisted bit
as
declare @count int
declare @sql nvarchar(1000)
set @sql = 'SELECT @c = count(*) 
		FROM tePlan_Document
		WHERE ContentID = ' + convert(nvarchar(12), @contentId)+ '
		AND PlanId = ' +convert(nvarchar(12), @planId) + '
		AND isInProduction = 0 '

		if @instanceId > 0
		begin
		set @sql = @sql + ' AND InstanceId = '+  CONVERT(varchar(10), @instanceId)
		end

		print @sql 
EXEC sys.[sp_executesql] @sql , N'@c int out', @count out

--if record exists update 
if @count > 0 and  @fileExisted = 1
begin
print 'in update'
	declare @sql_update nvarchar(2000)
	set @sql_update = '
		UPDATE tePlan_Document
		SET isActive = 0
			, dateUpdated = getdate()
			, UserId = '+ CONVERT(varchar(40), @userId) + '
			, publishedfrom =  2
		WHERE ContentID = '+  CONVERT(varchar(50),  @contentId )+ '
			AND PlanId = ' +  CONVERT(varchar(50),@planId) + '
			AND isInProduction = 0'

	if @instanceId > 0
	begin
		set @sql_update = ' AND InstanceId = ' +  CONVERT(varchar(50),@instanceId)
	end

	print @sql_update 

	EXEC sys.[sp_executesql] @sql_update
end
else
begin
print 'in insert'
	declare @sql_insert nvarchar(2000)
	set @sql_insert = '
	 INSERT INTO tePlan_Document(PlanId,ContentId,isActive,isInProduction,dateUpdated,UserId,PublishedFrom,InstanceId)
                VALUES('+ CONVERT(varchar(50), @planId )+ ', ' +  CONVERT(varchar(50), @contentId) + ',0,0,getdate(),'''+  CONVERT(varchar(50), @userId)+''',2'
				
	if @instanceId > 0
	begin
		set @sql_insert = @sql_insert + ' , ' + @instanceId + ')'
	end
	else
		begin
		set @sql_insert = @sql_insert + ' , null)'
	end
	print @sql_insert 

	EXEC sys.[sp_executesql] @sql_insert 
end