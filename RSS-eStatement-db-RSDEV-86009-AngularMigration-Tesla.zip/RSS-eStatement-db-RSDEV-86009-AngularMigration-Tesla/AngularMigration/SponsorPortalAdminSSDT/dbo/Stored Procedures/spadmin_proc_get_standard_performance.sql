﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_standard_performance @providerid uniqueidentifier, 
@fundfeedType varchar(50), @fundfeedTypeValue varchar(50)
as

declare @sqlcmd nvarchar(2000)
set @sqlcmd = 'SELECT MasterFundID   FROM [SponsorPortal].[dbo].[teMasterFund]
				 WHERE  providerid = ''' + convert(nvarchar(36), @providerid) + ''' AND ' + @fundfeedType + ' = '+  @fundfeedTypeValue + '
                    AND CustomFund  = 0'
print @sqlcmd		
EXEC sys.[sp_executesql] @sqlcmd