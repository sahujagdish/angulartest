﻿
CREATE PROCEDURE [dbo].spadmin_proc_getby_userdefinable
AS
SELECT * FROM tdContentCategories WHERE isUserDefinable = 1 ORDER BY Name