﻿
CREATE PROCEDURE [dbo].spadmin_proc_upd_provider_custom_investments @userId uniqueidentifier, @providerId uniqueidentifier, 
@customfundcode varchar(50), @invType varchar(50)
as

	declare @sql nvarchar(1000)
	set @sql = 'UPDATE teProviderCustomInvestments
			SET isActive = 0
				, dateUpdated = getdate()
				, UserId = '''+  convert(nvarchar(36),@userId )+ '''' 
	
	if @invType = 'fund'
	begin
		set @sql = ' ,isFund = 1'
	end
	else
	begin
		set @sql = ' ,isProspectus = 1'
	end

	set @sql = ' WHERE CustomFundCode = ''' + @customfundcode + ''' 
				AND ProviderId = ''' +  convert(nvarchar(36),@providerId )+ '''
				AND isInProduction = 0 '

	EXEC sys.[sp_executesql] @sql