﻿
CREATE PROCEDURE [dbo].spadmin_proc_getcontent_categories @useGenericMenuCategoriesForEBN bit, 
@providerID  uniqueidentifier, @ContentType varchar(50), @contentCategoryId varchar(10)
as
if @useGenericMenuCategoriesForEBN =1 
begin
		SELECT tdContentCategories.ContentCategoryId, teLink.Description AS Name 
		FROM tdContentCategories INNER JOIN
        teLink ON tdContentCategories.ContentCategoryId = teLink.ContentCategoryId INNER JOIN
        teProvider_ContentCategories ON tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		WHERE (teProvider_ContentCategories.ProviderID = @providerID) 
		AND (tdContentCategories.isUserDefinable = 1)
		ORDER BY teLink.sOrder
end
else
begin
	if  @ContentType = ''
	begin
		SELECT tdContentCategories.ContentCategoryId,tdContentCategories.Name
		FROM tdContentCategories, teProvider_ContentCategories
		WHERE  tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		AND teProvider_ContentCategories.ProviderID = @providerID
		AND (tdContentCategories.isUserDefinable = 1) 
		AND (tdContentCategories.ContentCategoryId != @contentCategoryId )
		ORDER BY tdContentCategories.Name
	end
	else
	begin
		SELECT tdContentCategories.ContentCategoryId,tdContentCategories.Name
		FROM tdContentCategories, teProvider_ContentCategories
		WHERE  tdContentCategories.ContentCategoryId = teProvider_ContentCategories.ContentCategoryID
		AND teProvider_ContentCategories.ProviderID = @providerID
		AND (tdContentCategories.isUserDefinable = 1) 
		AND (tdContentCategories.ContentCategoryId != @contentCategoryId )
		and (tdContentCategories.Scope = @ContentType or tdContentCategories.Scope = 'ALL')
		ORDER BY tdContentCategories.Name
	end
end