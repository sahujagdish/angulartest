﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_custom_funds @providerID  uniqueidentifier, @fundName varchar(200) , @CustomFundCode varchar(50),
@Cusip varchar(50),  @Ticker varchar(50),  @fundid varchar(50)
AS
	declare @sql nvarchar(1000)

	set @sql = 'SELECT MasterFundId, Name
				FROM teMasterFund 
				WHERE (ProviderId = '+  convert(nvarchar(36),@providerID) + ')
				AND CustomFund = 1'

	if @fundName <> ''
	begin
	set @sql = @sql + ' AND (Name LIKE '''+@fundName+ '%'') '
	end

	if @CustomFundCode <> ''
	begin
	set @sql = @sql + ' AND (CustomFundCode LIKE '''+@CustomFundCode+'%'') '
	end

	if @Cusip <> ''
	begin
	set @sql = @sql + ' AND (cusip LIKE '''+@Cusip+'%'') '
	end

	if @Ticker <> ''
	begin
	set @sql = @sql + ' AND (ticker LIKE '''+@Ticker+'%'') '
	end

	if @fundid <> ''
	begin
	set @sql = @sql + ' AND (fundid LIKE '''+@fundid+'%'') '
	end
	
	set @sql = @sql + '	ORDER BY NAME'

	EXEC sys.[sp_executesql] @sql