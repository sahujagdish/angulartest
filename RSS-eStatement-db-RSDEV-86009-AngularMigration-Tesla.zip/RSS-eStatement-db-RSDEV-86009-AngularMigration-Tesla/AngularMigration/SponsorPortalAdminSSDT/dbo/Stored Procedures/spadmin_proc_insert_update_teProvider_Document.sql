﻿
CREATE PROCEDURE [dbo].spadmin_proc_insert_update_teProvider_Document @userid uniqueidentifier,
@providerid uniqueidentifier, @contentId int, @fileExisted bit
as
if @fileExisted = 1
begin
		UPDATE teProvider_Document
		SET isActive = 0
		, dateUpdated = getdate()
		, UserId = @userid
		WHERE ContentID = @contentId
		AND ProviderId = @providerid
		AND isInProduction = 0
end
else
begin

		INSERT INTO teProvider_Document(ProviderId,ContentId,isActive,isInProduction,dateUpdated,UserId)
			VALUES(@providerid, @contentId,0,0, getdate(),@userid)
end