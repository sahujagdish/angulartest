﻿
CREATE PROCEDURE [dbo].spadmin_proc_fileName_with_contentId @providerid uniqueidentifier, @docId int
as

		SELECT FileName, teProvider_Document.ContentId
		FROM tdContentTypes, teProvider_Document 
		WHERE tdContentTypes.ContentId = teProvider_Document.ContentId 
		AND teProvider_Document.Provider_DocumentId = @docId
		AND teProvider_Document.ProviderId = @providerid