﻿
create PROCEDURE [dbo].spadmin_proc_del_teplan_fund
@masterFundIdList varchar(200)
as
	declare @sql nvarchar(1000)
	set @sql = '	IF EXISTS (SELECT MasterFundID FROM teplan_fund WHERE MasterFundID in(' + @masterFundIdList + '))
					begin
    					DELETE FROM teplan_fund WHERE MasterFundID in(' + @masterFundIdList + ')
					end '
	EXEC sys.[sp_executesql] @sql