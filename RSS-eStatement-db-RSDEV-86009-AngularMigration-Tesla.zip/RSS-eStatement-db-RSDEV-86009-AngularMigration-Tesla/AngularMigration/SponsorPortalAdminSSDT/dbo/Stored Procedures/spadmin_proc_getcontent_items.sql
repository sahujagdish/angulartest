﻿
CREATE PROCEDURE [dbo].spadmin_proc_getcontent_items @useGenericMenuCategoriesForEBN bit, 
@providerID  uniqueidentifier, @ContentCategoryId int, @ContentType varchar(50)
as

if @useGenericMenuCategoriesForEBN =1 
begin
	print 'Yes useGenericMenuCategoriesForEBN'
	if @ContentType = ''
	begin
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID 
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId
			ORDER BY tdContentTypes.AdminSiteText
	end
	else
	begin
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID 
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId			
			and tdContentTypes.ContentScope = @ContentType
			ORDER BY tdContentTypes.AdminSiteText	
	end
end
else
begin
	print 'not useGenericMenuCategoriesForEBN'
			SELECT tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as Name, tdContentCategories.Name as CategoryName
			FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories
			WHERE tdContentTypes.ContentId = teProvider_ContentTypes.ContentId
			AND tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId
			AND teProvider_ContentTypes.ProviderId = @providerID
			AND tdContentTypes.ContentCategoryId = @ContentCategoryId
			ORDER BY tdContentTypes.AdminSiteText	
end