﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_content_types @providerID  uniqueidentifier ,@useGenericMenuCategoriesForEBN bit
as

if @useGenericMenuCategoriesForEBN = 1
begin
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, 
		tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText, 
		tdContentTypes.isInstanced
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories  
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND (tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId)	
		AND (tdContentTypes.isUploadable = 1) 
		AND (teProvider_ContentTypes.ProviderID = @providerID)
		AND (tdContentTypes.ContentScope = 'PLAN')
		ORDER BY tdContentTypes.Name
end
else
begin
		SELECT tdContentTypes.Name, tdContentTypes.ContentId, 
		tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText, 
		tdContentTypes.isInstanced
		FROM tdContentTypes, teProvider_ContentTypes, tdContentCategories  
		WHERE (tdContentTypes.ContentId = teProvider_ContentTypes.ContentID) 
		AND (tdContentTypes.ContentCategoryId = tdContentCategories.ContentCategoryId)	
		AND (tdContentTypes.isUploadable = 1) 
		AND (teProvider_ContentTypes.ProviderID = @providerID)
		AND (tdContentCategories.Scope = 'PLAN')
		ORDER BY tdContentTypes.Name
end