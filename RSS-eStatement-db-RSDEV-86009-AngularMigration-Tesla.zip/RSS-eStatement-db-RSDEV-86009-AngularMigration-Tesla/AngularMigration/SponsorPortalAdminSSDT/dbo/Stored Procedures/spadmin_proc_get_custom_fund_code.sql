﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_custom_fund_code  @providerid uniqueidentifier, @customFundCode varchar(50)
as
	SELECT CustomFundCode
	FROM teMasterFund
	WHERE ProviderId = @providerid
	AND CustomFundCode = @customFundCode