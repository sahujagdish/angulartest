﻿

create PROCEDURE [dbo].spadmin_proc_get_fileName_for_invid 
@providerid uniqueidentifier,
@invid  int
as

	SELECT CustomFundCode,isFund,isProspectus
	FROM teProviderCustomInvestments 
	WHERE ProviderCustomInvestmentID = @invid 
	AND ProviderID = @providerid