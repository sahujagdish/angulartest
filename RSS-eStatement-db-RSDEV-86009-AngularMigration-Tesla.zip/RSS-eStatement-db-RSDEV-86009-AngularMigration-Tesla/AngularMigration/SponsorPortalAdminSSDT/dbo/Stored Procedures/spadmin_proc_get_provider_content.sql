﻿
CREATE PROCEDURE [dbo].spadmin_proc_get_provider_content @providerid uniqueidentifier 
as
	SELECT teProvider_Document.ContentId, teProvider_Document.dateUpdated, teProvider_Document.isActive
		,teProvider_Document.Provider_DocumentID, teProvider_Document.isInProduction
		,tdContentTypes.Name, tdContentTypes.ProductCode, tdContentTypes.AdminSiteText + ' [' + tdContentTypes.ProductCode + ']' as AdminSiteText
	FROM teProvider_Document, tdContentTypes 
	WHERE (tdContentTypes.ContentId = teProvider_Document.ContentId)
		AND (teProvider_Document.ProviderId = @providerid) 
		AND (tdContentTypes.isUploadable = 1)
		ORDER BY Name