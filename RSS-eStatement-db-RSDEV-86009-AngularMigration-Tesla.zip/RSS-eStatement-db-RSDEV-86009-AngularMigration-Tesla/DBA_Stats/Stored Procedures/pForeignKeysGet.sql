USE DBA_Stats

-- Drop procedure if it already exists
IF OBJECT_ID('dbo.pForeignKeysGet') IS NOT NULL
    DROP PROCEDURE dbo.pForeignKeysGet
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pForeignKeysGet.sql                                               $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pForeignKeysGet.sql          $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:38a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                Description
--  IN          @Database           The database to look in
--  IN          @TableName          The name of the table to get the keys for
--  IN          @DisplayOnly        Optional parameter that indicates whether or not
--                                  the foreign keys should be saved to the control
--                                  table or just displayed on the screen
--	
--  Return Value:
--      Nothing
--
--  Result Set(s):
--      Nothing
--
--  NOTES AND ASSUMPTIONS:
--      This procedure grabs all the foreign keys on the specified database and table and 
--      either stored them to the control table for use later or displays them on the screen
--
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pForeignKeysGet
    @Database VARCHAR(150),
    @TableName VARCHAR(150),
    @DisplayOnly BIT = 0
AS
    SET NOCOUNT ON
    
    DECLARE @executeSql NVARCHAR(MAX)
    
    SET @executeSql = ''
    
    IF NOT EXISTS (SELECT * FROM DBA_Stats.INFORMATION_SCHEMA.TABLES WHERE table_name = '__ForeignKeys') 
    BEGIN
        CREATE TABLE DBA_Stats..__ForeignKeys
        (
            FK_Database VARCHAR(150),
	        FK_Name VARCHAR(150),
	        ParentTable VARCHAR(150),
	        ParentColumn1 VARCHAR(150),
	        ParentColumn2 VARCHAR(150),
	        ParentColumn3 VARCHAR(150),
	        ParentColumn4 VARCHAR(150),
	        ParentColumn5 VARCHAR(150),
	        ParentColumn6 VARCHAR(150),
	        ParentColumn7 VARCHAR(150),
	        ParentColumn8 VARCHAR(150),
	        ParentColumn9 VARCHAR(150),
	        ParentColumn10 VARCHAR(150),
	        ParentColumn11 VARCHAR(150),
	        ParentColumn12 VARCHAR(150),
	        ParentColumn13 VARCHAR(150),
	        ParentColumn14 VARCHAR(150),
	        ParentColumn15 VARCHAR(150),
	        ParentColumn16 VARCHAR(150),
	        ChildTable VARCHAR(150),
	        ChildColumn1 VARCHAR(150),
	        ChildColumn2 VARCHAR(150),
	        ChildColumn3 VARCHAR(150),
	        ChildColumn4 VARCHAR(150),
	        ChildColumn5 VARCHAR(150),
	        ChildColumn6 VARCHAR(150),
	        ChildColumn7 VARCHAR(150),
	        ChildColumn8 VARCHAR(150),
	        ChildColumn9 VARCHAR(150),
	        ChildColumn10 VARCHAR(150),
	        ChildColumn11 VARCHAR(150),
	        ChildColumn12 VARCHAR(150),
	        ChildColumn13 VARCHAR(150),
	        ChildColumn14 VARCHAR(150),
	        ChildColumn15 VARCHAR(150),
	        ChildColumn16 VARCHAR(150)
        )
    END

    IF @DisplayOnly = 0
        SET @executeSql = ' USE ' + @Database + CHAR(13) +         
            ' INSERT INTO DBA_Stats..__ForeignKeys( ' + CHAR(13) +
            '   FK_Database, ' + CHAR(13) +
            '   FK_Name, ' + CHAR(13) +
            '   ParentTable, ' + CHAR(13) +
            '   ParentColumn1, ' + CHAR(13) +
            '   ParentColumn2, ' + CHAR(13) +
            '   ParentColumn3, ' + CHAR(13) +
            '   ParentColumn4, ' + CHAR(13) +
            '   ParentColumn5, ' + CHAR(13) +
            '   ParentColumn6, ' + CHAR(13) +
            '   ParentColumn7, ' + CHAR(13) +
            '   ParentColumn8, ' + CHAR(13) +
            '   ParentColumn9, ' + CHAR(13) +
            '   ParentColumn10, ' + CHAR(13) +
            '   ParentColumn11, ' + CHAR(13) +
            '   ParentColumn12, ' + CHAR(13) +
            '   ParentColumn13, ' + CHAR(13) +
            '   ParentColumn14, ' + CHAR(13) +
            '   ParentColumn15, ' + CHAR(13) +
            '   ParentColumn16, ' + CHAR(13) +
            '   ChildTable, ' + CHAR(13) +
            '   ChildColumn1, ' + CHAR(13) +
            '   ChildColumn2, ' + CHAR(13) +
            '   ChildColumn3, ' + CHAR(13) +
            '   ChildColumn4, ' + CHAR(13) +
            '   ChildColumn5, ' + CHAR(13) +
            '   ChildColumn6, ' + CHAR(13) +
            '   ChildColumn7, ' + CHAR(13) +
            '   ChildColumn8, ' + CHAR(13) +
            '   ChildColumn9, ' + CHAR(13) +
            '   ChildColumn10, ' + CHAR(13) +
            '   ChildColumn11, ' + CHAR(13) +
            '   ChildColumn12, ' + CHAR(13) +
            '   ChildColumn13, ' + CHAR(13) +
            '   ChildColumn14, ' + CHAR(13) +
            '   ChildColumn15, ' + CHAR(13) +
            '   ChildColumn16 ) ' + CHAR(13) +
            ' SELECT ''' + @Database + ''', ' + CHAR(13) +
            '   OBJECT_NAME(constid),  ' + CHAR(13) +
            '   OBJECT_NAME(rkeyid),  ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey1), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey2), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey3), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey4), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey5), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey6), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey7), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey8), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey9), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey10), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey11), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey12), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey13), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey14), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey15), ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey16), ' + CHAR(13) +
            '   OBJECT_NAME(fkeyid),  ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey1), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey2), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey3), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey4), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey5), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey6), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey7), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey8), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey9), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey10), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey11), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey12), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey13), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey14), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey15), ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey16) ' + CHAR(13) +
            ' FROM SYSREFERENCES ' + CHAR(13) +
            ' WHERE OBJECT_NAME(rkeyid) = ''' + @TableName + '''' + CHAR(13) +
            '   AND NOT EXISTS ( ' + CHAR(13) +
            '       SELECT * ' + CHAR(13) +
            '       FROM DBA_Stats..__ForeignKeys ' + CHAR(13) +
            '       WHERE FK_Name = OBJECT_NAME(rkeyid) ' + CHAR(13) +
            '   ) '
    ELSE
        SET @executeSql = ' USE ' + @Database + CHAR(13) +         
            ' SELECT ''' + @Database + ''' AS FK_Database, ' + CHAR(13) +
            '   OBJECT_NAME(constid) AS FK_Name,  ' + CHAR(13) +
            '   OBJECT_NAME(rkeyid) AS ParentTable,  ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey1) AS ParentColumn1, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey2) AS ParentColumn2, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey3) AS ParentColumn3, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey4) AS ParentColumn4, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey5) AS ParentColumn5, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey6) AS ParentColumn6, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey7) AS ParentColumn7, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey8) AS ParentColumn8, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey9) AS ParentColumn9, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey10) AS ParentColumn10, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey11) AS ParentColumn11, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey12) AS ParentColumn12, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey13) AS ParentColumn13, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey14) AS ParentColumn14, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey15) AS ParentColumn15, ' + CHAR(13) +
            '   COL_NAME(rkeyid , rkey16) AS ParentColumn16, ' + CHAR(13) +
            '   OBJECT_NAME(fkeyid) AS ChildTable,  ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey1) AS ChildColumn1, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey2) AS ChildColumn2, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey3) AS ChildColumn3, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey4) AS ChildColumn4, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey5) AS ChildColumn5, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey6) AS ChildColumn6, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey7) AS ChildColumn7, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey8) AS ChildColumn8, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey9) AS ChildColumn9, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey10) AS ChildColumn10, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey11) AS ChildColumn11, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey12) AS ChildColumn12, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey13) AS ChildColumn13, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey14) AS ChildColumn14, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey15) AS ChildColumn15, ' + CHAR(13) +
            '   COL_NAME(fkeyid , fkey16) AS ChildColumn16' + CHAR(13) +
            ' FROM SYSREFERENCES ' + CHAR(13) +
            ' WHERE OBJECT_NAME(rkeyid) = ''' + @TableName + ''''
    
    --RAISERROR( @executeSql, 0, 1 ) WITH NOWAIT
    --RAISERROR( '', 0, 1 ) WITH NOWAIT

    EXEC sp_sqlexec @executeSql

GO

-- Object Version Stamp  Footer --

IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'pStampVersion')
BEGIN 
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = replace (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = rtrim(ltrim(replace (@RevStamp, '$', '')))
   EXEC pStampVersion 'pForeignKeysGet', @RevStamp
END
GO

-- Object Version Stamp  Footer --

------------------------------------------------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pForeignKeysGet.sql $