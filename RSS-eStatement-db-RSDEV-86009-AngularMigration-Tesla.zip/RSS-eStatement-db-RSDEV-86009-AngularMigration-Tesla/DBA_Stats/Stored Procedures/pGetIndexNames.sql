USE DBA_Stats
GO 

-- Drop procedure if it already exists
IF ((OBJECT_ID('pGetIndexNames') IS NOT NULL) AND (OBJECTPROPERTY(OBJECT_ID('pGetIndexNames'), 'IsProcedure') = 1))
    DROP proc dbo.pGetIndexNames
GO 

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pGetIndexNames.sql                                                $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pGetIndexNames.sql           $
-- $Author:: Dbrown                                                              $
-- $Revision:: 2                                                                 $
-- $Modtime:: 8/24/10 3:43p                                                      $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                Description
--
--  Return Value:
--   None
--
--  Result SET(s):
--   None
--
----------------------------------------------------------------------------------
-- NOTES: Updates the teIndexNames table with the latest values.
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pGetIndexNames
AS
    
    SET NOCOUNT ON
    
    DECLARE @Names TABLE(
        DatabaseID INT,
        ObjectID INT,
        IndexID INT,
        DatabaseName VARCHAR(50),
        ObjectName VARCHAR(150),
        IndexName VARCHAR(250)
    )
    
    -- FinancialOne2One database
    INSERT INTO @Names
    SELECT 
        DB_ID('FinancialOne2One'),
        I.OBJECT_ID,
        I.Index_ID,
        'FinancialOne2One',
        O.Name,
        COALESCE( I.Name, 'HEAP' )
    FROM FinancialOne2One.sys.indexes I
    JOIN FinancialOne2One.sys.objects O
        ON O.OBJECT_ID = I.OBJECT_ID
    WHERE O.is_ms_shipped = 0
    
    DELETE N
    FROM @Names N
    WHERE DatabaseID = DB_ID('FinancialOne2One')
        AND IndexID = 0
        AND NOT EXISTS (
            SELECT *
            FROM FinancialOne2One.sys.indexes
            WHERE OBJECT_ID = N.ObjectID
                AND is_primary_key = 1
        )
        
    -- Investment database
    INSERT INTO @Names
    SELECT 
        DB_ID('Investment'),
        I.OBJECT_ID,
        I.Index_ID,
        'Investment',
        O.Name,
        COALESCE( I.Name, 'HEAP' )
    FROM Investment.sys.indexes I
    JOIN Investment.sys.objects O
        ON O.OBJECT_ID = I.OBJECT_ID
    WHERE O.is_ms_shipped = 0
    
    DELETE N
    FROM @Names N
    WHERE DatabaseID = DB_ID('Investment')
        AND IndexID = 0
        AND NOT EXISTS (
            SELECT *
            FROM Investment.sys.indexes
            WHERE OBJECT_ID = N.ObjectID
                AND is_primary_key = 1
        )
        
    -- MainOne2One database
    INSERT INTO @Names
    SELECT 
        DB_ID('MainOne2One'),
        I.OBJECT_ID,
        I.Index_ID,
        'MainOne2One',
        O.Name,
        COALESCE( I.Name, 'HEAP' )
    FROM MainOne2One.sys.indexes I
    JOIN MainOne2One.sys.objects O
        ON O.OBJECT_ID = I.OBJECT_ID
    WHERE O.is_ms_shipped = 0
    
    DELETE N
    FROM @Names N
    WHERE DatabaseID = DB_ID('MainOne2One')
        AND IndexID = 0
        AND NOT EXISTS (
            SELECT *
            FROM MainOne2One.sys.indexes
            WHERE OBJECT_ID = N.ObjectID
                AND is_primary_key = 1
        )
    
    -- Questionnaire database
    INSERT INTO @Names
    SELECT 
        DB_ID('Questionnaire'),
        I.OBJECT_ID,
        I.Index_ID,
        'Questionnaire',
        O.Name,
        COALESCE( I.Name, 'HEAP' )
    FROM Questionnaire.sys.indexes I
    JOIN Questionnaire.sys.objects O
        ON O.OBJECT_ID = I.OBJECT_ID
    WHERE O.is_ms_shipped = 0
        
    DELETE N
    FROM @Names N
    WHERE DatabaseID = DB_ID('Questionnaire')
        AND IndexID = 0
        AND NOT EXISTS (
            SELECT *
            FROM Questionnaire.sys.indexes
            WHERE OBJECT_ID = N.ObjectID
                AND is_primary_key = 1
        )
        
    -- Reporting Database 
    INSERT INTO @Names
    SELECT 
        DB_ID('Reporting'),
        I.OBJECT_ID,
        I.Index_ID,
        'Reporting',
        O.Name,
        COALESCE( I.Name, 'HEAP' )
    FROM Reporting.sys.indexes I
    JOIN Reporting.sys.objects O
        ON O.OBJECT_ID = I.OBJECT_ID
    WHERE O.is_ms_shipped = 0
    
    DELETE N
    FROM @Names N
    WHERE DatabaseID = DB_ID('Reporting')
        AND IndexID = 0
        AND NOT EXISTS (
            SELECT *
            FROM Reporting.sys.indexes
            WHERE OBJECT_ID = N.ObjectID
                AND is_primary_key = 1
        )
                
    DELETE I
    FROM teIndexNames I
    JOIN @Names N
        ON  N.DatabaseID = I.DatabaseID
        AND N.ObjectID = I.ObjectID
        AND N.IndexID = I.IndexID
        
    INSERT INTO teIndexNames
    SELECT *
    FROM @Names N
    WHERE NOT EXISTS (
            SELECT *
            FROM teIndexNames I
            WHERE   I.DatabaseID = N.DatabaseID
                AND I.ObjectID = N.ObjectID
                AND I.IndexID = N.IndexID
        )
        
GO

IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 2 $'
   SELECT @RevStamp = REPLACE (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = RTRIM(LTRIM(REPLACE (@RevStamp, '$', '')))
   EXEC pStampVersion 'pGetIndexNames', @RevStamp
END


GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pGetIndexNames.sql $
-- 
-- 2     8/31/10 12:08p Dbrown
-- Updated to correctly use the Reporting database instead of the
-- DBA_Stats database. Reviewed by RM.
-- 
-- 1     8/13/10 11:58a Dbrown
-- Gets the names of all the indexes in the MainOne2One, FinancialOne2One,
-- Reporting, Questionnaire, and Investment databases. Reviewed by RM.
-- 
 