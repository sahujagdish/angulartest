USE DBA_Stats

-- Drop procedure if it already exists
IF OBJECT_ID('dbo.pGetPrimaryKeyColumns') > 0
    DROP PROCEDURE dbo.pGetPrimaryKeyColumns

GO 

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pGetPrimaryKeyColumns.sql                                         $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pGetPrimaryKeyColumns.sql    $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:38a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                Description
--  IN          @DatabaseName       Name of the database the object is on
--  IN          @ObjectID           ID of a specific table/view/object to retrieve 
--                                  index usage information for
--  IN          @Result             The output variable used to return the results 
--                                  to the caller
--
-- Return Value:
--  Returns a text-based list of primary key column names, in key order, 
--  for the database/object combination passed
--
-- Result SET(s):
--   none.
--
----------------------------------------------------------------------------------
-- NOTES: Gets a comma separated list of columns making up the primary key of the specified table.
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------


CREATE PROCEDURE dbo.pGetPrimaryKeyColumns
    @DatabaseName VARCHAR(50), 
    @ObjectID INT,
    @Result VARCHAR(MAX) = NULL OUTPUT
AS 
BEGIN 

    SET NOCOUNT ON
    
    DECLARE @ExecuteSql NVARCHAR(MAX)

    SET @ExecuteSql = 
        'SET @ResultOUT = ''''

        SELECT @ResultOUT = @ResultOUT + CONVERT( VARCHAR(MAX), C.name ) + '',''
        FROM ' + @DatabaseName + '.sys.indexes I
        JOIN ' + @DatabaseName + '.sys.index_columns IC
            ON IC.OBJECT_ID = I.OBJECT_ID
            AND IC.index_id = I.index_id
        JOIN ' + @DatabaseName + '.sys.columns C
            ON C.OBJECT_ID = IC.OBJECT_ID
            AND C.column_id = IC.column_id
        WHERE I.is_primary_key = 1
            AND IC.key_ordinal > 0
            AND I.OBJECT_ID = ' + CONVERT( NVARCHAR(20), @ObjectID ) + '
        ORDER BY IC.key_ordinal

        SET @ResultOUT = LEFT( @ResultOUT, LEN( @ResultOUT ) - 1 )'

    EXECUTE sp_executesql @ExecuteSql, N'@ResultOUT VARCHAR(MAX) OUTPUT', @ResultOUT = @Result OUTPUT
END

GO

IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = REPLACE (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = RTRIM(LTRIM(REPLACE (@RevStamp, '$', '')))
   EXEC pStampVersion 'pGetIndexNames', @RevStamp
END


GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pGetPrimaryKeyColumns.sql $
-- 
-- 1     8/13/10 11:57a Dbrown
-- Gets a comma separated list of columns that make up the primary key of
-- the specified table. Reviewed by RM.
-- 
 