USE DBA_Stats

-- Drop procedure if it already exists
IF OBJECT_ID('dbo.pForeignKeysRecreate') IS NOT NULL
    DROP PROCEDURE dbo.pForeignKeysRecreate
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pForeignKeysRecreate.sql                                          $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pForeignKeysRecreate.sql     $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:37a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                Description
--	IN          @WithCheck          Optional parameter that controls how the foreign
--                                  keys are recreated. 0 will add the foreign key
--                                  using the WITH NOCHECK option then then after run
--                                  ALTER TABLE CHECK CONSTRAINT. If it is left as 1,
--                                  the constraint will be recreated using the 
--                                  WITH CHECK option.
--
--  Return Value:
--      Nothing
--
--  Result Set(s):
--      Nothing
--
--  NOTES AND ASSUMPTIONS:
--      This procedure will recreate all the foreign keys listed in the control table
--      __ForeignKeys.
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2009 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pForeignKeysRecreate
    @WithCheck BIT = 1
AS
    SET NOCOUNT ON
    
    DECLARE @executeSql NVARCHAR(MAX)
    DECLARE @checkClause NVARCHAR(20)
    DECLARE @Result INT
    
    DECLARE @Database VARCHAR(150)
    DECLARE @KeyName VARCHAR(150)
    DECLARE @ParentTable VARCHAR(150)
    DECLARE @ParentColumn1 VARCHAR(150)
    DECLARE @ParentColumn2 VARCHAR(150)
    DECLARE @ParentColumn3 VARCHAR(150)
    DECLARE @ParentColumn4 VARCHAR(150)
    DECLARE @ParentColumn5 VARCHAR(150)
    DECLARE @ParentColumn6 VARCHAR(150)
    DECLARE @ParentColumn7 VARCHAR(150)
    DECLARE @ParentColumn8 VARCHAR(150)
    DECLARE @ParentColumn9 VARCHAR(150)
    DECLARE @ParentColumn10 VARCHAR(150)
    DECLARE @ParentColumn11 VARCHAR(150)
    DECLARE @ParentColumn12 VARCHAR(150)
    DECLARE @ParentColumn13 VARCHAR(150)
    DECLARE @ParentColumn14 VARCHAR(150)
    DECLARE @ParentColumn15 VARCHAR(150)
    DECLARE @ParentColumn16 VARCHAR(150)
    DECLARE @ChildTable VARCHAR(150)
    DECLARE @ChildColumn1 VARCHAR(150)
    DECLARE @ChildColumn2 VARCHAR(150)
    DECLARE @ChildColumn3 VARCHAR(150)
    DECLARE @ChildColumn4 VARCHAR(150)
    DECLARE @ChildColumn5 VARCHAR(150)
    DECLARE @ChildColumn6 VARCHAR(150)
    DECLARE @ChildColumn7 VARCHAR(150)
    DECLARE @ChildColumn8 VARCHAR(150)
    DECLARE @ChildColumn9 VARCHAR(150)
    DECLARE @ChildColumn10 VARCHAR(150)
    DECLARE @ChildColumn11 VARCHAR(150)
    DECLARE @ChildColumn12 VARCHAR(150)
    DECLARE @ChildColumn13 VARCHAR(150)
    DECLARE @ChildColumn14 VARCHAR(150)
    DECLARE @ChildColumn15 VARCHAR(150)
    DECLARE @ChildColumn16 VARCHAR(150)
    
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE table_name = '__ForeignKeys') 
    BEGIN
        RAISERROR( 'The table DBA_Stats..__ForeignKeys does not exsit. There is nothing to do so the stored procedure is exiting', 16, 1 ) WITH NOWAIT
        RETURN
    END
    
    IF @WithCheck = 1
        SET @checkClause = 'WITH CHECK'
    ELSE
        SET @checkClause = 'WITH NOCHECK'

    DECLARE AddFK_Cursor CURSOR FOR
	SELECT FK_Database,
	    FK_Name, 
	    ParentTable, 
	    ParentColumn1, 
	    ParentColumn2, 
	    ParentColumn3, 
	    ParentColumn4, 
	    ParentColumn5, 
	    ParentColumn6, 
	    ParentColumn7, 
	    ParentColumn8, 
	    ParentColumn9, 
	    ParentColumn10, 
	    ParentColumn11, 
	    ParentColumn12, 
	    ParentColumn13, 
	    ParentColumn14, 
	    ParentColumn15, 
	    ParentColumn16, 
	    ChildTable,
	    ChildColumn1,
	    ChildColumn2,
	    ChildColumn3,
	    ChildColumn4,
	    ChildColumn5,
	    ChildColumn6,
	    ChildColumn7,
	    ChildColumn8,
	    ChildColumn9,
	    ChildColumn10,
	    ChildColumn11,
	    ChildColumn12,
	    ChildColumn13,
	    ChildColumn14,
	    ChildColumn15,
	    ChildColumn16
	FROM DBA_Stats..__ForeignKeys
	
	OPEN AddFK_Cursor

	FETCH NEXT 
	FROM AddFK_Cursor 
	INTO @Database,
	    @KeyName,
        @ParentTable,
        @ParentColumn1,
        @ParentColumn2,
        @ParentColumn3,
        @ParentColumn4,
        @ParentColumn5,
        @ParentColumn6,
        @ParentColumn7,
        @ParentColumn8,
        @ParentColumn9,
        @ParentColumn10,
        @ParentColumn11,
        @ParentColumn12,
        @ParentColumn13,
        @ParentColumn14,
        @ParentColumn15,
        @ParentColumn16,
        @ChildTable,
        @ChildColumn1,
        @ChildColumn2,
        @ChildColumn3,
        @ChildColumn4,
        @ChildColumn5,
        @ChildColumn6,
        @ChildColumn7,
        @ChildColumn8,
        @ChildColumn9,
        @ChildColumn10,
        @ChildColumn11,
        @ChildColumn12,
        @ChildColumn13,
        @ChildColumn14,
        @ChildColumn15,
        @ChildColumn16

	WHILE @@FETCH_STATUS = 0
	BEGIN
	    SET @executeSql = 'ALTER TABLE ' + @Database + '..' + @ChildTable + CHAR(13) + 
	        ' ' + @checkClause + ' ADD CONSTRAINT ' + @KeyName + ' FOREIGN KEY (' +
	            @ChildColumn1 + 
	            CASE WHEN @ChildColumn2 IS NULL THEN '' ELSE ', ' + @ChildColumn2 END + 
	            CASE WHEN @ChildColumn3 IS NULL THEN '' ELSE ', ' + @ChildColumn3 END + 
	            CASE WHEN @ChildColumn4 IS NULL THEN '' ELSE ', ' + @ChildColumn4 END + 
	            CASE WHEN @ChildColumn5 IS NULL THEN '' ELSE ', ' + @ChildColumn5 END + 
	            CASE WHEN @ChildColumn6 IS NULL THEN '' ELSE ', ' + @ChildColumn6 END + 
	            CASE WHEN @ChildColumn7 IS NULL THEN '' ELSE ', ' + @ChildColumn7 END + 
	            CASE WHEN @ChildColumn8 IS NULL THEN '' ELSE ', ' + @ChildColumn8 END + 
	            CASE WHEN @ChildColumn9 IS NULL THEN '' ELSE ', ' + @ChildColumn9 END + 
	            CASE WHEN @ChildColumn10 IS NULL THEN '' ELSE ', ' + @ChildColumn10 END + 
	            CASE WHEN @ChildColumn11 IS NULL THEN '' ELSE ', ' + @ChildColumn11 END + 
	            CASE WHEN @ChildColumn12 IS NULL THEN '' ELSE ', ' + @ChildColumn12 END + 
	            CASE WHEN @ChildColumn13 IS NULL THEN '' ELSE ', ' + @ChildColumn13 END + 
	            CASE WHEN @ChildColumn14 IS NULL THEN '' ELSE ', ' + @ChildColumn14 END + 
	            CASE WHEN @ChildColumn15 IS NULL THEN '' ELSE ', ' + @ChildColumn15 END + 
	            CASE WHEN @ChildColumn16 IS NULL THEN '' ELSE ', ' + @ChildColumn16 END + 
	        ') ' + CHAR(13) + 
	        ' REFERENCES ' + @Database + '..' + @ParentTable + '(' + 
	            @ParentColumn1 + 
	            CASE WHEN @ParentColumn2 IS NULL THEN '' ELSE ', ' + @ParentColumn2 END + 
	            CASE WHEN @ParentColumn3 IS NULL THEN '' ELSE ', ' + @ParentColumn3 END + 
	            CASE WHEN @ParentColumn4 IS NULL THEN '' ELSE ', ' + @ParentColumn4 END + 
	            CASE WHEN @ParentColumn5 IS NULL THEN '' ELSE ', ' + @ParentColumn5 END + 
	            CASE WHEN @ParentColumn6 IS NULL THEN '' ELSE ', ' + @ParentColumn6 END + 
	            CASE WHEN @ParentColumn7 IS NULL THEN '' ELSE ', ' + @ParentColumn7 END + 
	            CASE WHEN @ParentColumn8 IS NULL THEN '' ELSE ', ' + @ParentColumn8 END + 
	            CASE WHEN @ParentColumn9 IS NULL THEN '' ELSE ', ' + @ParentColumn9 END + 
	            CASE WHEN @ParentColumn10 IS NULL THEN '' ELSE ', ' + @ParentColumn10 END + 
	            CASE WHEN @ParentColumn11 IS NULL THEN '' ELSE ', ' + @ParentColumn11 END + 
	            CASE WHEN @ParentColumn12 IS NULL THEN '' ELSE ', ' + @ParentColumn12 END + 
	            CASE WHEN @ParentColumn13 IS NULL THEN '' ELSE ', ' + @ParentColumn13 END + 
	            CASE WHEN @ParentColumn14 IS NULL THEN '' ELSE ', ' + @ParentColumn14 END + 
	            CASE WHEN @ParentColumn15 IS NULL THEN '' ELSE ', ' + @ParentColumn15 END + 
	            CASE WHEN @ParentColumn16 IS NULL THEN '' ELSE ', ' + @ParentColumn16 END + 
	        ')'

        RAISERROR( @executeSql, 0, 1 ) WITH NOWAIT
        RAISERROR( '', 0, 1 ) WITH NOWAIT
        	        
        BEGIN TRY
        	EXEC sp_executesql @statement = @executeSql

            -- If we're recreating the foreign key without checking it on creation, we need to enable it by specifying
            -- 'CHECK CONSTRAINT', otherwise SQL will not be able to use the key.
            IF @WithCheck = 0
            BEGIN
                
	            SET @executeSql = 'ALTER TABLE ' + @Database + '..' + @ChildTable + ' CHECK CONSTRAINT ' + @KeyName

                RAISERROR( @executeSql, 0, 1 ) WITH NOWAIT
                RAISERROR( '', 0, 1 ) WITH NOWAIT
                	        
	            EXEC sp_executesql @statement = @executeSql
	            
	            -- Generate a select statement to verify the key
	            SET @executeSql =
	                ' SELECT @ResultOUT = COUNT(*) ' + CHAR(13) + 
	                ' FROM ' + @Database + '..' + @ChildTable + ' C ' + CHAR(13) +
	                ' WHERE NOT EXISTS(' + CHAR(13) +
	                '       SELECT * ' + CHAR(13) +
	                '       FROM ' + @Database + '..' + @ParentTable + ' P ' + CHAR(13) +
	                '       WHERE P.' + @ParentColumn1 + ' = C.' + @ChildColumn1 + CHAR(13) +
	                CASE WHEN @ParentColumn2 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn2 + ' = C.' + @ChildColumn2 + CHAR(13) END + 
	                CASE WHEN @ParentColumn3 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn3 + ' = C.' + @ChildColumn3 + CHAR(13) END + 
	                CASE WHEN @ParentColumn4 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn4 + ' = C.' + @ChildColumn4 + CHAR(13) END + 
	                CASE WHEN @ParentColumn5 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn5 + ' = C.' + @ChildColumn5 + CHAR(13) END + 
	                CASE WHEN @ParentColumn6 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn6 + ' = C.' + @ChildColumn6 + CHAR(13) END + 
	                CASE WHEN @ParentColumn7 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn7 + ' = C.' + @ChildColumn7 + CHAR(13) END + 
	                CASE WHEN @ParentColumn8 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn8 + ' = C.' + @ChildColumn8 + CHAR(13) END + 
	                CASE WHEN @ParentColumn9 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn9 + ' = C.' + @ChildColumn9 + CHAR(13) END + 
	                CASE WHEN @ParentColumn10 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn10 + ' = C.' + @ChildColumn10 + CHAR(13) END + 
	                CASE WHEN @ParentColumn11 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn11 + ' = C.' + @ChildColumn11 + CHAR(13) END + 
	                CASE WHEN @ParentColumn12 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn12 + ' = C.' + @ChildColumn12 + CHAR(13) END + 
	                CASE WHEN @ParentColumn13 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn13 + ' = C.' + @ChildColumn13 + CHAR(13) END + 
	                CASE WHEN @ParentColumn14 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn14 + ' = C.' + @ChildColumn14 + CHAR(13) END + 
	                CASE WHEN @ParentColumn15 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn15 + ' = C.' + @ChildColumn15 + CHAR(13) END + 
	                CASE WHEN @ParentColumn16 IS NULL THEN '' ELSE '       AND P.' + @ParentColumn16 + ' = C.' + @ChildColumn16 + CHAR(13) END +
	                '   ) AND C.' + @ChildColumn1 + ' IS NOT NULL  ' + CHAR(13) + 
	                CASE WHEN @ParentColumn2  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn2  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn3  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn3  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn4  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn4  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn5  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn5  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn6  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn6  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn7  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn7  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn8  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn8  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn9  IS NULL THEN '' ELSE 'AND C.' + @ChildColumn9  + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn10 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn10 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn11 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn11 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn12 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn12 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn13 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn13 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn14 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn14 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn15 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn15 + ' IS NOT NULL  ' + CHAR(13) END +
	                CASE WHEN @ParentColumn16 IS NULL THEN '' ELSE 'AND C.' + @ChildColumn16 + ' IS NOT NULL  ' + CHAR(13) END
	            
	            --RAISERROR( @executeSql, 0, 1 ) WITH NOWAIT
                --RAISERROR( '', 0, 1 ) WITH NOWAIT
                
	            EXECUTE sp_executesql @executeSql, N'@ResultOUT INT OUTPUT', @ResultOUT = @Result OUTPUT;
	            
	            IF @Result <> 0 
	                RAISERROR( 'Foreign key violation in %s', 16, 1, @ChildTable ) WITH NOWAIT
                ELSE 
                    RAISERROR( '%s passed foreign key check', 0, 1, @ChildTable ) WITH NOWAIT
	        END 

            DELETE FROM __ForeignKeys
            WHERE CURRENT OF AddFK_Cursor
        END TRY
        BEGIN CATCH
            DECLARE @ErrorMessage NVARCHAR(4000);
            DECLARE @ErrorSeverity INT;
            DECLARE @ErrorState INT;

	        SELECT 
                @ErrorMessage = ERROR_MESSAGE(),
                @ErrorSeverity = ERROR_SEVERITY(),
                @ErrorState = ERROR_STATE();
        	
        	CLOSE AddFK_Cursor
	        DEALLOCATE AddFK_Cursor
	        
	        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )
	        
            RETURN
        END CATCH
        
	    FETCH NEXT 
	    FROM AddFK_Cursor 
        INTO @Database,
	        @KeyName,
            @ParentTable,
            @ParentColumn1,
            @ParentColumn2,
            @ParentColumn3,
            @ParentColumn4,
            @ParentColumn5,
            @ParentColumn6,
            @ParentColumn7,
            @ParentColumn8,
            @ParentColumn9,
            @ParentColumn10,
            @ParentColumn11,
            @ParentColumn12,
            @ParentColumn13,
            @ParentColumn14,
            @ParentColumn15,
            @ParentColumn16,
            @ChildTable,
            @ChildColumn1,
            @ChildColumn2,
            @ChildColumn3,
            @ChildColumn4,
            @ChildColumn5,
            @ChildColumn6,
            @ChildColumn7,
            @ChildColumn8,
            @ChildColumn9,
            @ChildColumn10,
            @ChildColumn11,
            @ChildColumn12,
            @ChildColumn13,
            @ChildColumn14,
            @ChildColumn15,
            @ChildColumn16	
    END
	CLOSE AddFK_Cursor
	DEALLOCATE AddFK_Cursor


GO

-- Object Version Stamp  Footer --

IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'pStampVersion')
BEGIN 
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = replace (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = rtrim(ltrim(replace (@RevStamp, '$', '')))
   EXEC pStampVersion 'pForeignKeysRecreate', @RevStamp
END
GO

-- Object Version Stamp  Footer --

------------------------------------------------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pForeignKeysRecreate.sql $ 