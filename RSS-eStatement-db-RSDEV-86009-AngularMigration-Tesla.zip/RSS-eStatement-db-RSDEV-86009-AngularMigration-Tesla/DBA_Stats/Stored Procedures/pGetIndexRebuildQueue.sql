USE DBA_Stats
GO 

-- Drop procedure if it already exists
IF ((OBJECT_ID('pGetIndexRebuildQueue') IS NOT NULL) AND (OBJECTPROPERTY(OBJECT_ID('pGetIndexRebuildQueue'), 'IsProcedure') = 1))
    DROP proc dbo.pGetIndexRebuildQueue
GO 

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pGetIndexRebuildQueue.sql                                         $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pGetIndexRebuildQueue.sql    $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:38a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                Description
--
--  Return Value:
--   None
--
--  Result SET(s):
--   None
--
----------------------------------------------------------------------------------
-- NOTES: Updates the teIndexNames table with the latest values.
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pGetIndexRebuildQueue
AS
    
    SET NOCOUNT ON

    DECLARE @DatabaseID INT,
        @DatabaseName VARCHAR(50),
        @ObjectID INT,
        @ObjectName VARCHAR(150)
        
    RAISERROR( 'Gathering usage statistics...', 0, 1 ) WITH NOWAIT
    
    INSERT INTO teIndexRebuildQueue(
        DatabaseID,
        ObjectID,
        IndexID,
        UserSeeks,
        UserScans,
        UserLookups,
        UserUpdates
    )
    SELECT
        Database_ID,
        Object_ID,
        Index_ID,
        User_Seeks,
        User_Scans,
        User_Lookups,
        User_Updates
    FROM sys.dm_db_index_usage_stats U
    JOIN teIndexNames N
        ON  U.database_id = N.DatabaseID
        AND U.OBJECT_ID = N.ObjectID
        AND U.Index_ID = N.IndexID
    LEFT JOIN teIndexRebuildQueue R
        ON  U.database_id = R.DatabaseID
        AND U.OBJECT_ID = R.ObjectID
        AND U.Index_ID = R.IndexID
    WHERE R.DatabaseID IS NULL
    
    UPDATE R
    SET UserSeeks = U.user_seeks,
        UserScans = U.user_scans,
        UserLookups = U.user_lookups,
        UserUpdates = U.user_updates
    FROM sys.dm_db_index_usage_stats U
    JOIN teIndexRebuildQueue R
        ON  U.database_id = R.DatabaseID
        AND U.OBJECT_ID = R.ObjectID
        AND U.Index_ID = R.IndexID
    
    RAISERROR( 'Gathering sampled physical statistics...', 0, 1 ) WITH NOWAIT
    
    -- Since HEAPs have no logical ordering, the fragmentation value
    -- returned for them (when using DETAILED mode) is extent fragmentation.
    -- Again, since there is no logical ordering, we don't care that much.
    -- What we do care about is forwarded records, which can drastically slow 
    -- down data lookups, so we're going to use the percenage of forwarded rows
    -- as the basis of HEAP fragmentation.
    UPDATE R
    SET AverageFragmentationInPercent = 
            CASE
                WHEN S.index_id = 0 THEN 0
                ELSE S.avg_fragmentation_in_percent
            END,
        AverageRecordSizeInBytes = S.avg_record_size_in_bytes,
        PageDensity = avg_page_space_used_in_percent,
        PageCount = S.page_count,
        RecordCount = S.record_count,
        ForwardedRecordCount = COALESCE( S.forwarded_record_count * 100, 0 ),
        RangeScanCount = O.range_scan_count,
        Skipped = 0
    FROM teIndexRebuildQueue R
    JOIN sys.dm_db_index_physical_stats( NULL, NULL, NULL, NULL, 'SAMPLED' ) S
        ON  S.database_id = R.DatabaseID
        AND S.OBJECT_ID = R.ObjectID
        AND S.index_id = R.IndexID
        AND S.alloc_unit_type_desc = 'IN_ROW_DATA'
    JOIN sys.dm_db_index_operational_stats( NULL, NULL, NULL, NULL ) O
        ON  O.database_id = R.DatabaseID
        AND O.OBJECT_ID = R.ObjectID
        AND O.index_id = R.IndexID

    RAISERROR( 'Gathering heap extent fragmentation...', 0, 1 ) WITH NOWAIT
    
    DECLARE heaps CURSOR FAST_FORWARD FOR
        SELECT DatabaseID,
            DatabaseName,
            ObjectID,
            ObjectName
        FROM vIndexRebuildQueue
        WHERE IndexID = 0
            AND PageCount >= 8
        
    OPEN heaps
    
    -- update the extent fragmentation of heaps
    WHILE 1=1
    BEGIN
        FETCH NEXT
        FROM heaps
        INTO @DatabaseID,
            @DatabaseName,
            @ObjectID,
            @ObjectName
            
        IF @@FETCH_STATUS <> 0
            BREAK
            
        RAISERROR( '    Getting extent fragmentation for %s.%s', 0, 1, @DatabaseName, @ObjectName ) WITH NOWAIT
        
        UPDATE Q
        SET AverageFragmentationInPercent = (
            SELECT avg_fragmentation_in_percent
            FROM sys.dm_db_index_physical_stats( @DatabaseID, @ObjectID, 0, NULL, 'DETAILED' )
            WHERE alloc_unit_type_desc = 'IN_ROW_DATA'
        )
        FROM teIndexRebuildQueue Q
        WHERE DatabaseID = @DatabaseID
            AND ObjectID = @ObjectID
            AND IndexID = 0
    END
    
    CLOSE heaps
    DEALLOCATE heaps
    
    RAISERROR( 'Done', 0, 1 ) WITH NOWAIT
GO

IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = REPLACE (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = RTRIM(LTRIM(REPLACE (@RevStamp, '$', '')))
   EXEC pStampVersion 'pGetIndexRebuildQueue', @RevStamp
END


GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pGetIndexRebuildQueue.sql $
-- 
-- 1     8/13/10 11:58a Dbrown
-- Builds the index rebuild queue. Reviewed by RM.
-- 
