USE DBA_Stats
GO 

-- Drop procedure if it already exists
IF ((OBJECT_ID('pRebuildIndexes') IS NOT NULL) AND (OBJECTPROPERTY(OBJECT_ID('pRebuildIndexes'), 'IsProcedure') = 1))
    DROP proc dbo.pRebuildIndexes
GO 

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pRebuildIndexes.sql                                               $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pRebuildIndexes.sql          $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:38a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--  Direction   Name                    Description
--  IN          @StopTime               Either a DATETIME or just a DATE. If a DATETIME is specified,
--                                      that will be the stoptime. If just a time is specified, the 
--                                      stoptime will be:
--                                          a) if the time is greater that the current time, today
--                                              at the specified time
--                                          b) if the time is less than the current time, tomorrow
--                                              at the specified time
--  IN          @RebuildCutoffInPercent Used to specify the maximum amount of fragmentation
--                                      allowed in an index before it will be rebuilt. All
--                                      indexes that fall below this threshold will be ignored.
--
--  Return Value:
--   None
--
--  Result SET(s):
--   None
--
----------------------------------------------------------------------------------
--  NOTES: Starting with the first index in the queue that there is time to rebuild,
--      this procedure will rebuild all indexes in the queue until it either runs
--      out of time or has finished with everything in the queue.
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pRebuildIndexes
    @StopTime DATETIME,
    @RebuildCutoffInPercent FLOAT = 15.0
AS
    
    SET NOCOUNT ON
    
    -- declare the variables we're going to use
    DECLARE @RebuildID INT,
        @DatabaseID INT,
        @DatabaseName VARCHAR(50),
        @ObjectID INT,
        @ObjectName VARCHAR(150),
        @IndexID INT,
        @IndexName VARCHAR(250),
        @AverageFragmentationInPercent FLOAT,
        @PageDensity FLOAT,
        @PageCount INT,
        @UserUpdates INT,
        @ForwardedRecordCount INT,
        @TotalQueries BIGINT,
        @DaysSinceLastRebuild INT,
        @Priority FLOAT,
        @AverageRebuildTimeInSeconds INT,
        @RangeScanCount BIGINT,
        @ExecuteSql NVARCHAR(MAX),
        @ReturnValue INT,
        @KeyColumns VARCHAR(MAX),
        @ErrorMessage NVARCHAR(4000)
        
    DECLARE @StopHours DATETIME
    DECLARE @CurrentHours DATETIME
    
    -- make sure there are no items in the N1 job queue. If there are, quit.
    IF 0 < (
        SELECT COUNT(*)
        FROM MainOne2One..teJobQueueItem
        WHERE ProcessStatusTypeCD = 3 -- processing
    ) 
    BEGIN
        RAISERROR( 'WARNING: All index rebuilds have been skipped because there are items waiting in the job queue.', 0, 1, @ObjectName, @IndexName ) WITH NOWAIT
        RETURN
    END

    -- get just the time part of now and the stop time
    SET @CurrentHours = DATEADD( ss, DATEDIFF( ss, DATEADD( dd, DATEDIFF( dd, 0, GETDATE() ), 0 ), GETDATE() ), 0 )
    SET @StopHours = DATEADD( ss, DATEDIFF( ss, DATEADD( dd, DATEDIFF( dd, 0, @StopTime ), 0 ), @StopTime ), 0 )

    -- get the correct stop time. If we just got a time and not a date:
    --  If the time is greater than the current time, stop today at that time
    --  If the time is less than the current time, stop tomorrow at that time.
    IF DATEADD( dd, DATEDIFF( dd, 0, @StopTime ), 0 ) = '1900-01-01 00:00:00'
    BEGIN
        IF @StopHours > @CurrentHours
            SET @StopTime = DATEADD( ss, DATEDIFF( ss, 0, @StopTime ), DATEADD( dd, DATEDIFF( dd, 0, GETDATE() ), 0 ) )
        ELSE
            SET @StopTime = DATEADD( ss, DATEDIFF( ss, 0, @StopTime ), DATEADD( dd, DATEDIFF( dd, 0, GETDATE() ), 1 ) )
    END

    
    -- while we still have time left and there are indexes to rebuild
    WHILE GETDATE() < @StopTime 
    BEGIN
        -- get the first index to rebuild
        SELECT TOP 1 
            @DatabaseID = Q.DatabaseID,
            @DatabaseName = Q.DatabaseName,
            @ObjectID = Q.ObjectID,
            @ObjectName = Q.ObjectName,
            @IndexID = Q.IndexID,
            @IndexName = Q.IndexName,
            @AverageFragmentationInPercent = Q.AverageFragmentationInPercent,
            @PageDensity = Q.PageDensity,
            @PageCount = Q.PageCount,
            @UserUpdates = Q.UserUpdates,
            @ForwardedRecordCount = Q.ForwardedRecordCount,
            @TotalQueries = Q.TotalQueries,
            @RangeScanCount = Q.RangeScanCount,
            @DaysSinceLastRebuild = Q.DaysSinceLastRebuild,
            @Priority = Q.Priority
        FROM vIndexRebuildQueue Q
        WHERE Q.AverageFragmentationInPercent > @RebuildCutoffInPercent
            AND Q.Skipped = 0
            AND Q.PageCount > 8
        ORDER BY Q.Priority DESC
        
        -- if there are none left, quit
        IF @IndexID IS NULL OR @@ROWCOUNT = 0
            BREAK
            
        -- if the index is on a heap table and the heap needs to be rebuilt
        IF @IndexID = 0 
            OR (
                @IndexID <> 0 
                AND EXISTS (
                    SELECT *
                    FROM teIndexRebuildQueue Q
                    WHERE Q.DatabaseID = @DatabaseID
                        AND Q.ObjectID = @ObjectID
                        AND Q.IndexID = 0 -- a HEAP table
                        AND Q.AverageFragmentationInPercent > @RebuildCutoffInPercent
                        AND Q.Skipped = 0
                )
            )
        BEGIN
            -- rebuild an index on a table with a heap where the heap also needs to be rebuilt.
            
            -- get the average rebuild time for the heap
            SET @AverageRebuildTimeInSeconds = (
                SELECT COALESCE( AVG( S.RebuildTimeInSeconds ), 0 )
                FROM vIndexRebuildStatistics S
                WHERE   S.DatabaseID = @DatabaseID
                    AND S.ObjectID = @ObjectID
                    AND S.IndexID = 0
                    AND S.RebuildActionTypeCD = 1 -- Success
            )
            
            -- if we estimate that there is enough time left
            IF( @AverageRebuildTimeInSeconds < DATEDIFF( ss, GETDATE(), @StopTime ) )
            BEGIN
                -- only do the rebuild if we estimate that there is enough time left to rebuild the HEAP and all indexes on the table
                
                -- get the values for the HEAP in case the index we're currently on is not the HEAP
                SELECT @AverageFragmentationInPercent = Q.AverageFragmentationInPercent,
                    @ForwardedRecordCount = Q.ForwardedRecordCount,
                    @TotalQueries = Q.TotalQueries,
                    @RangeScanCount = Q.RangeScanCount
                FROM vIndexRebuildQueue Q
                WHERE Q.DatabaseID = @DatabaseID
                    AND Q.ObjectID = @ObjectID
                    AND Q.IndexID = 0 -- a HEAP table
                
                -- insert a record in the log for the heap
                INSERT INTO teIndexRebuildStatistics(
                    DatabaseID,
                    ObjectID,
                    IndexID,
                    RebuildActionTypeCD,
                    StartTime,
                    AverageFragmentationInPercent,
                    ForwardedRecordCount,
                    TotalUserQueries,
                    RangeScanCount
                )
                VALUES( 
                    @DatabaseID,
                    @ObjectID,
                    0, -- the HEAP
                    1, -- Rebuild
                    GETDATE(),
                    @AverageFragmentationInPercent,
                    @ForwardedRecordCount,
                    @TotalQueries,
                    @RangeScanCount
                )
                
                SET @RebuildID = @@IDENTITY
                
                BEGIN TRANSACTION
                
                BEGIN TRY
                    -- get all the foreign keys pointing to the table
                    EXEC DBA_Stats..pForeignKeysGet @DatabaseName, @ObjectName
                    
                    -- drop all the foreign keys on the table
                    EXEC DBA_Stats..pForeignKeysDrop
                    
                    -- get the primary key columns for the table
                    EXEC DBA_Stats..pGetPrimaryKeyColumns @DatabaseName, @ObjectID, @KeyColumns OUTPUT

                    -- rebuild the heap table and all its indexes
                    SET @ExecuteSql = 
                        N'ALTER INDEX ALL ' + 
                            N' ON ' + CONVERT( NVARCHAR(MAX), @DatabaseName ) + N'.dbo.' + CONVERT( NVARCHAR(MAX), @ObjectName ) + 
                            ' DISABLE;' + 
                        N'CREATE CLUSTERED INDEX xc' + CONVERT( NVARCHAR(MAX), @ObjectName ) + 
                            N' ON ' + CONVERT( NVARCHAR(MAX), @DatabaseName ) + N'.dbo.' + CONVERT( NVARCHAR(MAX), @ObjectName ) + N'(' +
                                CONVERT( NVARCHAR(MAX), @KeyColumns ) + 
                            N');' + 
                        N'DROP INDEX xc' + CONVERT( NVARCHAR(MAX), @ObjectName ) + 
                            N' ON ' + CONVERT( NVARCHAR(MAX), @DatabaseName ) + N'.dbo.' + CONVERT( NVARCHAR(MAX), @ObjectName ) + N';' +
                        N'ALTER INDEX ALL ' + 
                            N' ON ' + CONVERT( NVARCHAR(MAX), @DatabaseName ) + N'.dbo.' + CONVERT( NVARCHAR(MAX), @ObjectName ) + 
                            N' REBUILD WITH ( ' + 
                                N'FILLFACTOR = 90, ' + 
                                N'PAD_INDEX  = OFF, ' +
                                N'STATISTICS_NORECOMPUTE  = OFF, ' +
                                N'ALLOW_ROW_LOCKS  = ON, ' +
                                N'ALLOW_PAGE_LOCKS  = ON, ' +
                                N'ONLINE = OFF, ' +
                                N'SORT_IN_TEMPDB = ON ' +
                            N');'
                            
                    RAISERROR( @ExecuteSql, 0, 1 ) WITH NOWAIT
                    
                    EXEC @ReturnValue = sp_executesql @ExecuteSql

                    -- recreate the foreign keys
                    EXEC DBA_Stats..pForeignKeysRecreate
                    
                    COMMIT TRANSACTION
                    
                    -- update the rebuild log record for the heap
                    UPDATE teIndexRebuildStatistics
                    SET EndTime = GETDATE(),
                        LogMessage = 'Add/Drop Clustered Index and Rebuild All Indexes'
                    WHERE RebuildID = @RebuildID
                    
                    -- remove the heap and all related indexes from the queue since they were rebuilt sucessfully
                    DELETE 
                    FROM teIndexRebuildQueue
                    WHERE DatabaseID = @DatabaseID
                        AND ObjectID = @ObjectID
                    
                END TRY
                BEGIN CATCH
                    SELECT @ErrorMessage = ERROR_MESSAGE()
                    
                    ROLLBACK TRANSACTION
                    
                    RAISERROR( 'ERROR: %s', 0, 1, @ErrorMessage ) WITH NOWAIT
                    
                    -- update the rebuild log record for the heap
                    UPDATE teIndexRebuildStatistics
                    SET RebuildActionTypeCD = 3, -- Error rebuilding index
                        EndTime = GETDATE(),
                        LogMessage = @ErrorMessage
                    WHERE RebuildID = @RebuildID

                    -- mark all indexes on this table as skipped
                    UPDATE Q
                    SET Skipped = 1
                    FROM teIndexRebuildQueue Q
                    WHERE DatabaseID = @DatabaseID
                        AND ObjectID = @ObjectID
                END CATCH
                               
            END
            ELSE
            BEGIN
                -- if we don't have enough time, log the fact that we skipped it and continue
                INSERT INTO teIndexRebuildStatistics(
                    DatabaseID,
                    ObjectID,
                    IndexID,
                    RebuildActionTypeCD,
                    StartTime,
                    EndTime,
                    AverageFragmentationInPercent,
                    ForwardedRecordCount,
                    TotalUserQueries,
                    RangeScanCount,
                    LogMessage
                )
                VALUES( 
                    @DatabaseID,
                    @ObjectID,
                    @IndexID,
                    4, -- Skip because of insufficient time to rebuild heap table
                    GETDATE(),
                    GETDATE(),
                    @AverageFragmentationInPercent,
                    @ForwardedRecordCount,
                    @TotalQueries,
                    @RangeScanCount,
                    'Rebuild Skipped. Estimated rebuild time for heap and all indexes: ' + CONVERT( VARCHAR(MAX), @AverageRebuildTimeInSeconds ) + ', Time Remaining: ' + CONVERT( VARCHAR(MAX), DATEDIFF( s, GETDATE(), @StopTime ) )
                )
                
                -- mark all indexes on this table as skipped
                UPDATE Q
                SET Skipped = 1
                FROM teIndexRebuildQueue Q
                WHERE DatabaseID = @DatabaseID
                    AND ObjectID = @ObjectID
                    
                RAISERROR( 'Rebuild of HEAP %s skipped because of insufficient time', 0, 1, @ObjectName, @IndexName ) WITH NOWAIT
            END
        END
        ELSE
        BEGIN
            -- rebuild an index noramlly
            
            -- get the average rebuild time for the index
            SET @AverageRebuildTimeInSeconds = (
                SELECT COALESCE( AVG( S.RebuildTimeInSeconds ), 0 )
                FROM vIndexRebuildStatistics S
                WHERE   S.DatabaseID = @DatabaseID
                    AND S.ObjectID = @ObjectID
                    AND S.IndexID = @IndexID
                    AND S.RebuildActionTypeCD = 1
            )           
            
            -- if we estimate there is enough time left to rebuild it
            IF( @AverageRebuildTimeInSeconds < DATEDIFF( ss, GETDATE(), @StopTime ) )
            BEGIN
                -- only do the rebuild if we estimate that there is enough time left
                
                -- insert a log record for the index
                INSERT INTO teIndexRebuildStatistics(
                    DatabaseID,
                    ObjectID,
                    IndexID,
                    RebuildActionTypeCD,
                    StartTime,
                    AverageFragmentationInPercent,
                    ForwardedRecordCount,
                    TotalUserQueries,
                    RangeScanCount
                )
                VALUES( 
                    @DatabaseID,
                    @ObjectID,
                    @IndexID,
                    1, -- Rebuild
                    GETDATE(),
                    @AverageFragmentationInPercent,
                    @ForwardedRecordCount,
                    @TotalQueries,
                    @RangeScanCount
                )
                
                SET @RebuildID = @@IDENTITY
                
                -- rebuild the index
                SET @ExecuteSql = 
                    N'ALTER INDEX ' + CONVERT( NVARCHAR(MAX), @IndexName ) + 
                        N' ON ' + CONVERT( NVARCHAR(MAX), @DatabaseName ) + N'.dbo.' + CONVERT( NVARCHAR(MAX), @ObjectName ) + 
                        N' REBUILD WITH ( ' + 
                            N'FILLFACTOR = 90, ' + 
                            N'PAD_INDEX  = OFF, ' +
                            N'STATISTICS_NORECOMPUTE  = OFF, ' +
                            N'ALLOW_ROW_LOCKS  = ON, ' +
                            N'ALLOW_PAGE_LOCKS  = ON, ' +
                            N'ONLINE = OFF, ' +
                            N'SORT_IN_TEMPDB = ON ' +
                        N')'
                
                BEGIN TRY
                    RAISERROR( @ExecuteSql, 0, 1 ) WITH NOWAIT
                    
                    EXEC @ReturnValue = sp_executesql @ExecuteSql
                
                    -- update the log record for the index
                    UPDATE teIndexRebuildStatistics
                    SET EndTime = GETDATE()
                    WHERE RebuildID = @RebuildID
                
                    -- delete the index from the queue since it was successfully rebuilt
                    DELETE Q
                    FROM teIndexRebuildQueue Q
                    WHERE DatabaseID = @DatabaseID
                        AND ObjectID = @ObjectID
                        AND IndexID = @IndexID

                END TRY
                BEGIN CATCH
                    SELECT @ErrorMessage = ERROR_MESSAGE()
                    
                    RAISERROR( 'ERROR: %s', 0, 1, @ErrorMessage ) WITH NOWAIT
                    
                    -- log the error for the index rebuild
                    UPDATE teIndexRebuildStatistics
                    SET RebuildActionTypeCD = 3, -- Error rebuilding index
                        EndTime = GETDATE(),
                        LogMessage = @ErrorMessage
                    WHERE RebuildID = @RebuildID
                    
                    -- mark the index as skipped because there was an error
                    UPDATE Q
                    SET Skipped = 1
                    FROM teIndexRebuildQueue Q
                    WHERE DatabaseID = @DatabaseID
                        AND ObjectID = @ObjectID
                        AND IndexID = @IndexID
                        
                END CATCH
                
            END
            ELSE
            BEGIN
                -- if we don't have enough time, log the fact that we skipped it and continue
                INSERT INTO teIndexRebuildStatistics(
                    DatabaseID,
                    ObjectID,
                    IndexID,
                    RebuildActionTypeCD,
                    StartTime,
                    EndTime,
                    AverageFragmentationInPercent,
                    ForwardedRecordCount,
                    TotalUserQueries,
                    RangeScanCount,
                    LogMessage
                )
                VALUES( 
                    @DatabaseID,
                    @ObjectID,
                    @IndexID,
                    2, -- Skip because of insufficient time
                    GETDATE(),
                    GETDATE(),
                    @AverageFragmentationInPercent,
                    @ForwardedRecordCount,
                    @TotalQueries,
                    @RangeScanCount,
                    'Rebuild Skipped. Estimated rebuild time: ' + CONVERT( VARCHAR(MAX), @AverageRebuildTimeInSeconds ) + ', Time Remaining: ' + CONVERT( VARCHAR(MAX), DATEDIFF( s, GETDATE(), @StopTime ) )
                )
                
                -- mark the record as skipped because there wasn't enought time to rebuild it
                UPDATE Q
                SET Skipped = 1
                FROM teIndexRebuildQueue Q
                WHERE DatabaseID = @DatabaseID
                    AND ObjectID = @ObjectID
                    AND IndexID = @IndexID
                    
                RAISERROR( 'Rebuild of %s.%s skipped because of insufficient time', 0, 1, @ObjectName, @IndexName ) WITH NOWAIT
            END
        END
    END -- end while
    
    IF( GETDATE() > @StopTime )
        RAISERROR( 'The stop time has been reached. Ending index rebuilds.', 0, 1 ) WITH NOWAIT
        
    PRINT GETDATE()
GO
    
IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = REPLACE (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = RTRIM(LTRIM(REPLACE (@RevStamp, '$', '')))
   EXEC pStampVersion 'pRebuildIndexes', @RevStamp
END


GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pRebuildIndexes.sql $
-- 
-- 1     8/13/10 11:59a Dbrown
-- Rebuilds all the indexes in the queue that are more fragmented than the
-- cutoff supplied, not starting any new rebuilds after the specified
-- time. Reviewed by RM.
-- 
