USE DBA_Stats

-- Drop procedure if it already exists
IF OBJECT_ID('dbo.pForeignKeysDrop') IS NOT NULL
    DROP PROCEDURE dbo.pForeignKeysDrop
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: pForeignKeysDrop.sql                                              $
-- $Archive:: /Database/DBA_Stats/Stored Procedures/pForeignKeysDrop.sql         $
-- $Author:: Dbrown                                                              $
-- $Revision:: 1                                                                 $
-- $Modtime:: 8/13/10 11:39a                                                     $
----------------------------------------------------------------------------------
-- Parameters:
--   Direction  Name                 Description
--	
-- Return Value:
--   Nothing
--
-- Result Set(s):
--   Nothing
--
-- NOTES AND ASSUMPTIONS:
--      This procedure will drop all foreign keys listed in the control table __ForeignKeys
--
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2009 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.pForeignKeysDrop
AS
    SET NOCOUNT ON
    
    DECLARE @executeSql NVARCHAR(MAX)
    
    DECLARE @Database VARCHAR(150)
    DECLARE @KeyName VARCHAR(150)
    DECLARE @ParentTable VARCHAR(150)
    DECLARE @ParentColumn VARCHAR(150)
    DECLARE @ChildTable VARCHAR(150)
    DECLARE @ChildColumn VARCHAR(150)

    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE table_name = '__ForeignKeys') 
    BEGIN
        RAISERROR( 'The table DBA_Stats..__ForeignKeys does not exsit. There is nothing to do so the stored procedure is exiting', 16, 1 ) WITH NOWAIT
        RETURN
    END
    
    DECLARE DropFK_Cursor CURSOR FAST_FORWARD FOR 
        SELECT 
	        FK_Database,
	        FK_Name, 
	        ChildTable
	    FROM DBA_Stats..__ForeignKeys
	
	OPEN DropFK_Cursor

	FETCH NEXT 
	FROM DropFK_Cursor 
	INTO @Database,
	    @KeyName,
        @ChildTable
        
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    SET @executeSql = 'IF EXISTS (SELECT * FROM ' + @Database + '.sys.foreign_keys WHERE object_id = OBJECT_ID(N''' + @Database + '..' + @KeyName + ''') ' +
	        'AND parent_object_id = OBJECT_ID(N''' + @Database + '..' + @ChildTable + '''))' + CHAR(13) + 
	        '   ALTER TABLE ' + @Database + '..' + @ChildTable + ' DROP CONSTRAINT ' + @KeyName
	    
	    RAISERROR( @executeSql, 0, 1 ) WITH NOWAIT
	    RAISERROR( '', 0, 1 ) WITH NOWAIT
	    
	    EXEC sp_executesql @statement = @executeSql

	    FETCH NEXT 
	    FROM DropFK_Cursor 
	    INTO @Database,
            @KeyName,
            @ChildTable
    END

	CLOSE DropFK_Cursor
	DEALLOCATE DropFK_Cursor
GO

-- Object Version Stamp  Footer --

IF EXISTS (SELECT * FROM SYSOBJECTS WHERE name LIKE 'pStampVersion')
BEGIN 
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 1 $'
   SELECT @RevStamp = replace (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = rtrim(ltrim(replace (@RevStamp, '$', '')))
   EXEC pStampVersion 'pForeignKeysDrop', @RevStamp
END
GO

-- Object Version Stamp  Footer --

------------------------------------------------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Stored Procedures/pForeignKeysDrop.sql $ 