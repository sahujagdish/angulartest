USE DBA_Stats

IF OBJECT_ID('dbo.vIndexRebuildStatistics', 'V') IS NOT NULL
    DROP VIEW dbo.vIndexRebuildStatistics
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: vIndexRebuildStatistics.sql                                       $
--  $Archive:: /Database/DBA_Stats/Views/vIndexRebuildStatistics.sql             $
--   $Author:: Dbrown                                                            $
-- $Revision:: 1                                                                 $
--  $Modtime:: 8/13/10 11:30a                                                    $
----------------------------------------------------------------------------------
-- <Additional notes or comments go here?>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis,
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the
-- license.
--
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------
CREATE VIEW vIndexRebuildStatistics AS
    SELECT 
        S.RebuildID,
        S.DatabaseID,
        S.ObjectID,
        S.IndexID,
        I.DatabaseName,
        I.ObjectName,
        I.IndexName,
        S.RebuildActionTypeCD,
        CASE 
            WHEN S.IndexID = 0 THEN 'HEAP'
            WHEN S.IndexID = 1 THEN 'CLUSTERED INDEX'
            ELSE 'NONCLUSTERED INDEX'
        END AS IndexTypeDescrip,
        S.StartTime,
        S.EndTime,
        DATEDIFF( s, S.StartTime, S.EndTime ) AS RebuildTimeInSeconds,
        S.AverageFragmentationInPercent,
        S.ForwardedRecordCount,
        S.TotalUserQueries,
        S.RangeScanCount,
        S.LogMessage
    FROM teIndexRebuildStatistics S
    JOIN teIndexNames I
        ON  I.DatabaseID = S.DataBaseID
        AND I.ObjectID = S.ObjectID
        AND I.IndexID = S.IndexID
        
GO

-- Object Version Stamp  Footer --
IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
    DECLARE @vssRev VARCHAR(30)
    DECLARE @RevStamp VARCHAR(30)
    SELECT @VSSRev = '$Revision: 1 $'
    SELECT @RevStamp = REPLACE( @VSSRev, 'Revision:', '' )
    SELECT @RevStamp = RTRIM( LTRIM( REPLACE( @RevStamp, '$', '' )))
    EXEC pStampVersion 'vIndexRebuildStatistics', @RevStamp
END
GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Views/vIndexRebuildStatistics.sql $
-- 
-- 1     8/13/10 12:00p Dbrown
-- Adds calculated columns to those in teIndexRebuildStatistics and adds
-- the names and databases of all the items from the teIndexNames table.
-- Reviewed by RM.
-- 
