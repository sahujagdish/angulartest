USE DBA_Stats

IF OBJECT_ID('dbo.vIndexRebuildQueue', 'V') IS NOT NULL
    DROP VIEW dbo.vIndexRebuildQueue
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- $Workfile:: vIndexRebuildQueue.sql                                            $
--  $Archive:: /Database/DBA_Stats/Views/vIndexRebuildQueue.sql                  $
--   $Author:: Dbrown                                                            $
-- $Revision:: 1                                                                 $
--  $Modtime:: 8/13/10 11:29a                                                    $
----------------------------------------------------------------------------------
-- <Additional notes or comments go here�>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis,
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the
-- license.
--
-- Copyright (C) 2010 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------
CREATE VIEW vIndexRebuildQueue AS
    SELECT 
        R.DatabaseID,
        R.ObjectID,
        R.IndexID,
        I.DatabaseName,
        I.ObjectName,
        I.IndexName,
        CASE R.IndexID
            WHEN 0 THEN 'HEAP'
            WHEN 1 THEN 'CLUSTERED INDEX'
            ELSE 'NONCLUSTERED INDEX'
        END AS IndexTypeDescrip,
        R.AverageFragmentationInPercent,
        R.AverageRecordSizeInBytes,
        CEILING( CONVERT( FLOAT, ( R.PageCount * 8 ) ) / 1024.0 ) AS SizeInMB,
        R.PageDensity,
        R.PageCount,
        R.UserSeeks,
        R.UserScans,
        R.UserLookups,
        R.UserUpdates,
        R.RecordCount,
        R.ForwardedRecordCount,
        R.RangeScanCount,
        R.Skipped,
        (R.UserSeeks + R.UserScans + R.UserLookups) AS TotalQueries,
        ISNULL( 
            DATEDIFF( 
                d,
                GETDATE(), 
                ( 
                    SELECT MAX( EndTime )
                    FROM teIndexRebuildStatistics S
                    WHERE   S.DatabaseID = R.DatabaseID
                        AND S.ObjectID = R.ObjectID
                        AND S.IndexID = R.IndexID
                )
            ),
            50
        ) AS DaysSinceLastRebuild,
        (
            CEILING( CONVERT( FLOAT, R.PageCount ) / 10000.0 ) * 
            CEILING( CONVERT( FLOAT, (R.UserSeeks + R.UserScans + R.UserLookups) ) / 100000.0 ) * 
            ( CONVERT( FLOAT, R.AverageFragmentationInPercent ) / 100.0 ) * 
            CEILING( CONVERT( FLOAT, ( R.PageCount * 8 ) ) / 10240.0 ) *
            CASE
                WHEN ( R.UserSeeks + R.UserScans + R.UserLookups ) > 0
                    THEN ( 1 + ( RangeScanCount / (R.UserSeeks + R.UserScans + R.UserLookups) ) )
                ELSE 1
            END
        ) AS Priority
    FROM teIndexRebuildQueue R
    JOIN teIndexNames I
        ON  I.DatabaseID = R.DataBaseID
        AND I.ObjectID = R.ObjectID
        AND I.IndexID = R.IndexID
GO

-- Object Version Stamp  Footer --
IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN
    DECLARE @vssRev VARCHAR(30)
    DECLARE @RevStamp VARCHAR(30)
    SELECT @VSSRev = '$Revision: 1 $'
    SELECT @RevStamp = REPLACE( @VSSRev, 'Revision:', '' )
    SELECT @RevStamp = RTRIM( LTRIM( REPLACE( @RevStamp, '$', '' )))
    EXEC pStampVersion 'vIndexRebuildQueue', @RevStamp
END
GO

----------------------------------------------------------------------------------
-- $Log: /Database/DBA_Stats/Views/vIndexRebuildQueue.sql $
-- 
-- 1     8/13/10 12:00p Dbrown
-- Adds calculated columns to those in teIndexRebuildQueue and adds the
-- names and databases of all the items from the teIndexNames table.
-- Reviewed by RM.
-- 
