USE [estatements]
GO

IF OBJECT_ID( 'ss_ident_insert_trigger' ) IS NOT NULL
	DROP TRIGGER ss_ident_insert_trigger;

/****** Object:  Trigger [dbo].[ss_ident_insert_trigger]    Script Date: 9/12/2019 12:16:38 PM ******/
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

GO

CREATE TRIGGER [dbo].[ss_ident_insert_trigger] on [dbo].[ss_ident] 
FOR INSERT
AS

	DECLARE @Context VARBINARY(128);
	SET @Context = CONTEXT_INFO();

	-- when executing batch operations, or when the insert happens from a stored procedure,
	-- we don't want to run the trigger because we've already done this.
	IF( @Context = 0x99999 )
		RETURN;

	declare @v_uid uniqueidentifier, 
		@part_uid uniqueidentifier,
		@v_pk int,
		@v_partid varchar(15)

	select @v_pk = pk, 
		   @v_uid = uid,
		   @v_partid = part_id
	from inserted

	-- the the UID has already been provided by the inserting/updating entity, quit because we don't have to do anything
	if( @v_uid IS NOT NULL )
		RETURN;

	-- 4/27/05  If not a forfeiture account (i.e. part_id = '999-99-9999', then use the same uid value for that participant's records for that provider, else make sure the uid value is different for each distinct sponsor & plan for that provider
	--if rtrim(@v_partid) != '999-99-9999'
	-- 11/25/14 Modified to include all dummy SSNs in the forfeiture logic -TGM
	if rtrim(@v_partid) NOT IN( '999-99-9999', '888-88-8888', '777-77-7777', '666-66-6666', '555-55-5555', '444-44-4444',  '222-22-2222', '111-11-1111')
		begin 
			select top 1 @part_uid = a.uid
			from ss_ident a , inserted b
			where  a.part_id = b.part_id 
				and    a.provid = b.provid 
				and    a.pk <> b.pk
		end
	else
		begin
			select top 1 @part_uid = a.uid
			from ss_ident a
			join inserted b
				ON a.part_id = b.part_id 
				AND a.provid = b.provid 
				AND a.pk <> b.pk
				AND a.spon_num = b.spon_num
				AND a.plan_num = b.plan_num
		end
	
	If @part_uid is null
	   set @part_uid = newid()

	/* verify name of function that returns uuid/id */
	update 	ss_ident
	set 	uid= @part_uid
	where   pk=@v_pk

GO

ALTER TABLE [dbo].[ss_ident] ENABLE TRIGGER [ss_ident_insert_trigger]
GO


