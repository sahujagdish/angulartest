/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ProviderID]
      ,[Active]
      ,[ProvID]
      ,[NumberOfPeriodsToDisplay]
  FROM [eStatement].[dbo].[vprovider]