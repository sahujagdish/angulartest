
USE estatement
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vss_ident')
	BEGIN
		DROP  View vss_ident
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vss_ident AS

    SELECT 
        pk,
        file_name,
        part_id,
        position,
        pages,
        plan_num,
        rpt_date,
        isactive,
        timestamp,
        spon_num,
        provid,
        trans_no,
        fname,
        lname,
        uid,
        platform,
        batch,
        IsSmart,
        CommunicationTypeCD,
        FileLocationTypeCD,
        DateSubmitted
    FROM ss_ident
GO
