
USE estatements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vApproval')
	BEGIN
		DROP  View vApproval
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vApproval AS
    SELECT 
        APPR_PK, 
        APPR_PROVID, 
        APPR_YEAR, 
        APPR_QTR, 
        APPR_ZIP_FILE, 
        APPR_PATH, 
        APPR_DA_REPORT, 
        APPR_DATE_SENT, 
        APPR_DATE_APPROVED, 
        APPR_APPROVED_BY, 
        APPR_DA_FILE,
        APPR_LinkToFile
    FROM Approval 

GO
