
USE estatement
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'veStatement')
	BEGIN
		DROP  View veStatement
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.
--   Copyright 2020 by SSNC, Inc.
--   All Rights Reserved.

CREATE View veStatement AS

	SELECT DISTINCT 
		SS.uid,
		SS.part_id,
		SS.plan_num,
		SS.spon_num,
		P.plan_plan_name AS plan_name,
		SS.provid,
		PR.ProviderID,
		SS.rpt_date as statementDate,
		EP.ID AS StatementId,
		SS.fname AS firstname,
		SS.lname AS lastname
	FROM ss_ident SS
	JOIN plans P on SS.plan_num = P.PLAN_Plan_Num
	JOIN provider PR on SS.provid = PR.ProvID
	LEFT JOIN veStatementPDF EP ON SS.part_id = EP.part_id AND SS.plan_num = EP.plan_num  AND SS.rpt_date = EP.rpt_date
    
GO
