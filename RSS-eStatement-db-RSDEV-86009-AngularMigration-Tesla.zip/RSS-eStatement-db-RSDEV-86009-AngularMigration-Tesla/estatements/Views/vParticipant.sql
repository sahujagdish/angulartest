﻿
USE estatements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vParticipant')
	BEGIN
		DROP  View vParticipant
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vParticipant AS
    SELECT 
        ParticipantID,
        SSN,
        AcctNumber,
        FName,
        MI,
        LName,
        EMail,
        UserID,
        Password,
        StatusCode,
        LastChange,
        LastChangeID,
        ProviderID,
        VCode,
        LastLogin,
        ParticipantUUID,
        ValidEmail,
        ValidAsOf,
        LoginCount,
        PrevPassword,
        LastPasswordEdit,
        PasswordEditByAdmin,
        AgentEmail,
        AgentID,
        Agent_Ind,
        ElectCode,
        MMPrefix,
        PartC_Phon,
        Prefix,
        Suffix,
        AddressLine1,
        AddressLine2,
        AddressLine3,
        City,
        State,
        Country,
        Zip,
        VestedBalance,
        AgentPhone,
        AgentFirstName,
        AgentLastName,
        DateReferred,
        isPasswordHashed,
        failedAuthAttempts
    FROM Participant

GO
