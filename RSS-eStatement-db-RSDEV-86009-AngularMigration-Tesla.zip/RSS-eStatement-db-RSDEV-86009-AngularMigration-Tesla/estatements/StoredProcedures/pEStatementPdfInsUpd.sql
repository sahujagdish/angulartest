﻿USE estatement

IF OBJECT_ID( 'dbo.pEStatementPdfInsUpd' ) IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.pEStatementPdfInsUpd;
END

GO

CREATE PROCEDURE dbo.pEStatementPdfInsUpd
	 @part_id char(15),
	 @plan_num varchar(405),
	 @rpt_date DATETIME,
	 @eStatementPdf VARBINARY(MAX)

AS  
BEGIN

    SET NOCOUNT ON
    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT
    -- Track errors as you go. Only execute as long as no errors.
    DECLARE @intErr               INT
    --Signal to actually raise a formal error if first-time encountered.
    DECLARE @bitRaiseErr          BIT
    DECLARE @chrErrSup            VARCHAR(100)

    --
    -- Procedure Variables
    --
    DECLARE @exitingid INT

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@TRANCOUNT
    SET @intErr               = @@ERROR
    SET @bitRaiseErr          = 0
    SET @chrErrSup            = ''
   
    --
    -- PROCESSING
    --
    IF @intIncomingTranCount = 0
    BEGIN
      -- if there is no transaction already present,
      -- this proc must start one
      BEGIN TRANSACTION
      SET @intErr = @@ERROR
    END

	 --
    -- Check to see if a row with the same primary key value already exists
    --
    IF @intErr = 0
    BEGIN
        SELECT @exitingid = ID
          FROM teEStatementPdf
         WHERE part_id = @part_id AND plan_num = @plan_num AND rpt_date = @rpt_date

        SET @intErr = @@ERROR
    END
    
    --
    -- Update the existing record or insert a new one, as appropriate.
    --
    IF @intErr = 0
    BEGIN
        IF @exitingid IS NOT NULL
        BEGIN
            --
            -- Update existing record.
            --
            UPDATE teEStatementPdf
               SET eStatementPdf = @eStatementPdf
             WHERE ID = @exitingid

            SET @intErr = @@ERROR
        END
        ELSE
        BEGIN
            --
            -- Insert new record.
            --
            INSERT INTO teEStatementPdf (
                part_id, plan_num, rpt_date, eStatementPdf
            )
            VALUES (
                @part_id, @plan_num, @rpt_date, @eStatementPdf
            )

            SET @intErr = @@ERROR
        END
    END
	
    -- If an error occurred during execution of this proc raise the error
    -- to the caller if necessary. If there were no outer transactions
    -- active at the time this proc was called, perform a rollback.
    -- Otherwise we are going to assume the outer transaction will trap
    -- the error condition and handle the rollback.
    IF @intErr != 0
    BEGIN
        IF @bitRaiseErr = 1 RAISERROR(@intErr, 16, 1, @chrErrSup)
        IF @intIncomingTranCount = 0 ROLLBACK TRANSACTION
    END
    ELSE
        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0 COMMIT TRANSACTION

    RETURN @intErr
  
END
