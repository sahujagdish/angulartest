USE estatements

IF OBJECT_ID( 'dbo.pCleanup_ss_ident' ) IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.pCleanup_ss_ident;
END

GO

CREATE PROCEDURE dbo.pCleanup_ss_ident
	 @StagingID bigint
AS  
BEGIN
	DELETE NEW
	FROM tsSs_ident NEW
	WHERE NEW.StagingID = @StagingID;
END