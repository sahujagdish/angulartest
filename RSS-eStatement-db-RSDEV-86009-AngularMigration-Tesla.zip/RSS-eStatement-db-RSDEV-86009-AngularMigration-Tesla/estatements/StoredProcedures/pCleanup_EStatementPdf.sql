USE estatement

IF OBJECT_ID( 'dbo.pCleanup_EStatementPdf' ) IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.pCleanup_EStatementPdf;
END

GO

CREATE PROCEDURE dbo.pCleanup_EStatementPdf
	 @StagingID bigint
AS  
BEGIN
	DELETE NEW
	FROM tsEStatementPdf NEW
	WHERE NEW.StagingID = @StagingID;
END