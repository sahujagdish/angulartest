USE estatements

IF OBJECT_ID( 'dbo.pInsrt_ss_ident' ) IS NOT NULL
BEGIN
	DROP PROCEDURE [dbo].[pInsrt_ss_ident];
END

GO

CREATE PROCEDURE [dbo].[pInsrt_ss_ident]   
	 @file_name varchar(100),   
	 @part_id char(15),  
	 @fname varchar(30),  
	 @lname varchar(40),  
	 @plan_num varchar(405),  
	 @rpt_date datetime,  
	 @spon_num varchar(401),  
	 @provid char(4),  
	 @v_uid uniqueidentifier  OUTPUT,  
	 @IsSmart bit=0,  
	 @communicationtypecd smallint=1,  
	 @platform integer =0,  
	 @position int = NULL,  
	 @pages tinyint = NULL,  
	 @isactive bit = 1,  
	 @trans_no char(10) = NULL,  
	 @batch bit = 0  
AS  
BEGIN
	-- This is a special workaround to prevent the insert trigger on ss_ident from firing
	-- The trigger will look at the Context_Info and if it is this value, it will quit without doing anything
	-- This is necessary because there are places in the old FoxPro code that directly insert without calling
	-- the stored procedure.	DECLARE @CurrentContext VARBINARY(128) = CONTEXT_INFO();
	DECLARE @CurrentContext VARBINARY(128) = CONTEXT_INFO();
	IF @CurrentContext IS NULL
		SET @CurrentContext = 0x0;

	SET CONTEXT_INFO 0x99999;


	if rtrim(@part_id) NOT IN( '999-99-9999', '888-88-8888', '777-77-7777', '666-66-6666', '555-55-5555', '444-44-4444',  '222-22-2222', '111-11-1111')
		SET @v_uid = (
			select top 1 a.uid
			from ss_ident a 
			where	a.part_id = @part_id 
				AND a.provid = @provid
		)
	else
		SET @v_uid = (
			select top 1 a.uid
			from ss_ident a
			WHERE	a.part_id = @part_id 
				AND a.provid = @provid 
				AND a.spon_num = @spon_num
				AND a.plan_num = @plan_num
		)

	-- if we didn't find one, create a new one
	SET @v_uid = COALESCE( @v_uid, NEWID() );

	INSERT INTO ss_ident (  
		file_name, 
		part_id, 
		fname, 
		lname, 
		position, 
		pages,   
		plan_num, 
		rpt_date, 
		spon_num, 
		isactive, 
		provid, 
		trans_no, 
		batch, 
		IsSmart,  
		communicationtypecd, 
		[platform],
		[uid]
	 )   
	 VALUES(  
		@file_name, 
		@part_id, 
		@fname, 
		@lname, 
		@position, 
		@pages,  
		@plan_num, 
		@rpt_date, 
		@spon_num, 
		@isactive, 
		@provid, 
		@trans_no, 
		@batch, 
		@IsSmart,  
		@communicationtypecd, 
		@platform,
		@v_uid
	 )  
  
	SET CONTEXT_INFO @CurrentContext;
END