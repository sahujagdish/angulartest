﻿USE estatements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pAutoRegisterParInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pAutoRegisterParInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pAutoRegisterParInsUpd]
      @AutoRegister BIT,
	  @FName varchar(30),
      @MI char(1),
      @LName varchar(40),
      @EMail varchar(80),
      @StatusCode char(2),
      @ProviderID int,
	  @SSN varchar(11)
AS
    SET NOCOUNT ON

    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT
	-- Track errors as you go. Only execute as long as no errors.
    DECLARE @intErr               INT
	--Signal to actually raise a formal error if first-time encountered.
    DECLARE @bitRaiseErr          BIT
    DECLARE @chrErrSup            VARCHAR(100)

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@TRANCOUNT
    SET @intErr               = @@ERROR
    SET @bitRaiseErr          = 0
    SET @chrErrSup            = ''

    --
    -- Procedure Variables
    --
    DECLARE @existingID INT
    SET @existingID = NULL
    
    --
    -- PROCESSING
    --
    IF @intIncomingTranCount = 0
    BEGIN
      -- if there is no transaction already present,
      -- this proc must start one
      BEGIN TRANSACTION
      SET @intErr = @@ERROR
    END

   

	--
	-- Business Logic
	-- 

    IF @intErr = 0   -- input ok, insert.
    BEGIN
        IF @AutoRegister = 1
        BEGIN
            EXEC dbo.pAutoRegisterParticipant
                @FName = @FName,
                @MI = @MI,
                @LName = @LName,
                @EMail = @Email,
                @StatusCode = @StatusCode,
                @ProviderID = @ProviderID,
				@SSN = @SSN
        END
        ELSE
        BEGIN

            EXEC dbo.pAutoregisterAndUpdate
                @FName = @FName,
                @MI = @MI,
                @LName = @LName,
                @EMail = @Email,
                @StatusCode = @StatusCode,
                @ProviderID = @ProviderID,
				@SSN = @SSN
        END
    END
    
    -- If an error occurred during execution of this proc raise the error
    -- to the caller if necessary. If there were no outer transactions
    -- active at the time this proc was called, perform a rollback.
    -- Otherwise we are going to assume the outer transaction will trap
    -- the error condition and handle the rollback.
    IF @intErr != 0
    BEGIN
        IF @bitRaiseErr = 1 RAISERROR(@intErr, 16, 1, @chrErrSup)
        IF @intIncomingTranCount = 0 ROLLBACK TRANSACTION
    END
    ELSE
        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0 COMMIT TRANSACTION

    RETURN @intErr

GO

		
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pAutoRegisterParInsUpd.sql $', '$Revision: 1 $'
END

GO
 
-- 