USE estatements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pSS_IdentInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pSS_IdentInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE PROCEDURE [dbo].[pSS_IdentInsUpd]
        @PK INT OUTPUT,
        @File_name VARCHAR(100),
        @Part_id CHAR(15),
        @Position INT NULL,
        @Pages tinyint NULL,
        @Plan_num VARCHAR(405),
        @Rpt_date DATETIME,
        @Isactive BIT,
        @Spon_num VARCHAR(401),
        @Provid CHAR(4),
        @Trans_no CHAR(10) NULL,
        @Fname VARCHAR(30),
        @Lname VARCHAR(40),
        @Uid UNIQUEIDENTIFIER NULL,
        @Platform INT,
        @Batch BIT,
        @IsSmart BIT,
        @CommunicationTypeCD SMALLINT,
        @FileLocationTypeCD INT NULL,
        @DateSubmitted DATETIME NULL
AS
    SET NOCOUNT ON

    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT
	-- Track errors as you go. Only execute as long as no errors.
    DECLARE @intErr               INT
	--Signal to actually raise a formal error if first-time encountered.
    DECLARE @bitRaiseErr          BIT
    DECLARE @chrErrSup            VARCHAR(100)

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@TRANCOUNT
    SET @intErr               = @@ERROR
    SET @bitRaiseErr          = 0
    SET @chrErrSup            = ''

    --
    -- Procedure Variables
    --
    DECLARE @existingID INT
    SET @existingID = NULL
    
    --
    -- PROCESSING
    --
    IF @intIncomingTranCount = 0
    BEGIN
      -- if there is no transaction already present,
      -- this proc must start one
      BEGIN TRANSACTION
      SET @intErr = @@ERROR
    END

    --
    --see if entry already exists
    --
    IF @intErr = 0
    BEGIN
      
        SELECT @existingID = pk
            FROM estatements..ss_ident
            WHERE file_name = @File_name AND part_id = @Part_id

        SET @intErr = @@ERROR
       
    END
     IF @intErr = 0   -- input ok, insert.
    BEGIN
        IF @existingID IS NOT NULL
        BEGIN
            UPDATE estatements..ss_ident
               SET 		
                Position = @Position,
                Pages = @Pages,
                Rpt_date = @Rpt_date,
                Isactive = @Isactive,
                Spon_num = @Spon_num,
                Trans_no = @Trans_no,
                Fname = @Fname,
                Lname = @Lname,
                Uid = @Uid,
                Platform = @Platform,
                Batch = @Batch,
                IsSmart = @IsSmart,
                CommunicationTypeCD = @CommunicationTypeCD,
                FileLocationTypeCD = @FileLocationTypeCD,
                DateSubmitted = @DateSubmitted
             WHERE pk = @existingID

            SET @intErr = @@ERROR

        END
        ELSE
        BEGIN
            INSERT estatements..ss_ident(
			    File_name,
                Part_id,
                Position,
                Pages,
                Plan_num,
                Rpt_date,
                Isactive,
                Spon_num,
                Provid,
                Trans_no,
                Fname,
                Lname,
                Uid,
                Platform,
                Batch,
                IsSmart,
                CommunicationTypeCD,
                FileLocationTypeCD,
                DateSubmitted
            )
            VALUES( 
				@File_name,
                @Part_id,
                @Position,
                @Pages,
                @Plan_num,
                @Rpt_date,
                @Isactive,
                @Spon_num,
                @Provid,
                @Trans_no,
                @Fname,
                @Lname,
                @Uid,
                @Platform,
                @Batch,
                @IsSmart,
                @CommunicationTypeCD,
                @FileLocationTypeCD,
                @DateSubmitted
            )

			SET @PK = SCOPE_IDENTITY()
            SET @intErr = @@ERROR
        END
    END
    
    -- If an error occurred during execution of this proc raise the error
    -- to the caller if necessary. If there were no outer transactions
    -- active at the time this proc was called, perform a rollback.
    -- Otherwise we are going to assume the outer transaction will trap
    -- the error condition and handle the rollback.
    IF @intErr != 0
    BEGIN
        IF @bitRaiseErr = 1 RAISERROR(@intErr, 16, 1, @chrErrSup)
        IF @intIncomingTranCount = 0 ROLLBACK TRANSACTION
    END
    ELSE
        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0 COMMIT TRANSACTION

		RETURN @PK
    RETURN @intErr

GO


--GRANT EXECUTE
--    ON pProductionFeedInsUpd
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pProductionFeedInsUpd BY CERTIFICATE certStatements
--	WITH PASSWORD = 'Mens confusa'
		
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pSS_IdentInsUpd.sql $', '$Revision: 1 $'
END

GO
 