USE estatements

IF OBJECT_ID( 'dbo.pLoad_ss_ident' ) IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.pLoad_ss_ident;
END

GO

CREATE PROCEDURE dbo.pLoad_ss_ident
	 @StagingID bigint
AS  
BEGIN
	-- This is a special workaround to prevent the insert trigger on ss_ident from firing
	-- The trigger will look at the Context_Info and if it is this value, it will quit without doing anything
	-- This is necessary because there are places in the old FoxPro code that directly insert without calling
	-- the stored procedure.
	DECLARE @CurrentContext VARBINARY(128) = CONTEXT_INFO();
	IF @CurrentContext IS NULL
		SET @CurrentContext = 0x0;

	SET CONTEXT_INFO 0x99999;

	SET CONTEXT_INFO 0x99999;

	 WITH CTE AS(
		SELECT *
		FROM tsSs_Ident
		WHERE StagingID = @StagingID
	)
	MERGE INTO ss_ident AS SS
	USING CTE AS NEW
	ON NEW.part_id = SS.part_id AND NEW.plan_num = SS.plan_num AND NEW.rpt_date = SS.rpt_date
	WHEN MATCHED THEN
	UPDATE
		SET SS.file_name = NEW.file_name,
			SS.part_id = NEW.part_id, 
			SS.fname = ISNULL(NEW.fname, ''), 
            SS.lname = ISNULL(NEW.lname, ''), 
			SS.plan_num = NEW.plan_num, 
			SS.rpt_date = NEW.rpt_date, 
			SS.spon_num = NEW.spon_num, 
			SS.isactive = 1, 
			SS.provid = NEW.provid, 
			SS.batch = 0, 
			SS.IsSmart = 0,  
			SS.communicationtypecd = NEW.communicationtypecd, 
			SS.[platform] = NEW.[platform],
			SS.[uid] = NEW.[uid]
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (  
		file_name, 
		part_id, 
		fname, 
		lname, 
		plan_num, 
		rpt_date, 
		spon_num, 
		isactive, 
		provid, 
		batch, 
		IsSmart,  
		communicationtypecd, 
		[platform],
		[uid]
	 )   
	 VALUES( 
		NEW.file_name, 
		NEW.part_id, 
		ISNULL(NEW.fname, ''), 
        ISNULL(NEW.lname, ''), 
		NEW.plan_num, 
		NEW.rpt_date, 
		NEW.spon_num, 
		1, 
		NEW.provid, 
		0, 
		0,  
		NEW.communicationtypecd, 
		NEW.platform,
		COALESCE( (select top 1 SSI.uid from ss_ident SSI 
			where	SSI.part_id = NEW.part_id 
				AND SSI.provid = NEW.provid), NEWID() ) );


	 SET CONTEXT_INFO @CurrentContext;
  
END