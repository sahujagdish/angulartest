USE estatement

IF OBJECT_ID( 'dbo.pLoad_EStatementPdf' ) IS NOT NULL
BEGIN
	DROP PROCEDURE dbo.pLoad_EStatementPdf;
END

GO

CREATE PROCEDURE dbo.pLoad_EStatementPdf
	 @StagingID bigint
AS  
BEGIN
	-- This is a special workaround to prevent the insert trigger on ss_ident from firing
	-- The trigger will look at the Context_Info and if it is this value, it will quit without doing anything
	-- This is necessary because there are places in the old FoxPro code that directly insert without calling
	-- the stored procedure.
	DECLARE @CurrentContext VARBINARY(128) = CONTEXT_INFO();
	IF @CurrentContext IS NULL
		SET @CurrentContext = 0x0;

	SET CONTEXT_INFO 0x99999;

	SET CONTEXT_INFO 0x99999;

	 WITH CTE AS(
		SELECT *
		FROM tsEStatementPdf
		WHERE StagingID = @StagingID
	)
	MERGE INTO teEStatementPdf AS EPDF
	USING CTE AS NEW
	ON NEW.part_id = EPDF.part_id AND NEW.plan_num = EPDF.plan_num AND NEW.rpt_date = EPDF.rpt_date
	WHEN MATCHED THEN
	UPDATE
		SET EPDF.eStatementPdf = NEW.eStatementPdf
	WHEN NOT MATCHED BY TARGET THEN
	INSERT (  
		part_id, 
		plan_num, 
		rpt_date, 
		eStatementPdf
	 )   
	 VALUES( 
		NEW.part_id, 
		NEW.plan_num, 
		NEW.rpt_date, 
		NEW.eStatementPdf
	 );


	 SET CONTEXT_INFO @CurrentContext;
  
END
