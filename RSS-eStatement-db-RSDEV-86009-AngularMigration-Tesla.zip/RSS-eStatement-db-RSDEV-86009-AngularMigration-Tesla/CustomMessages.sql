----------------------------------------------------------------------------------
-- $Workfile:: CustomMessages.sql                                                $
--  $Archive:: /Database/CustomMessages.sql                                      $
--   $Author:: Cwagner                                                           $
-- $Revision:: 4                                                                 $
--  $Modtime:: 11/10/03 11:25a                                                   $
----------------------------------------------------------------------------------
-- Add custom messages to the server
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2003 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

set nocount on
exec sp_addmessage @msgnum = 51002, @severity = 16, @replace = 'replace', @msgtext = 'Non-unique value:%s'
exec sp_addmessage @msgnum = 51003, @severity = 16, @replace = 'replace', @msgtext = 'Invalid data combination:%s'
exec sp_addmessage @msgnum = 51005, @severity = 16, @replace = 'replace', @msgtext = 'Missing required data:%s'

select * from master.dbo.sysmessages where error >= 50000

----------------------------------------------------------------------------------
-- $Log: /Database/CustomMessages.sql $
-- 
-- 4     11/10/03 11:27a Cwagner
-- Added message 51002 'Non-unique value:%s'
-- 
-- 3     6/19/03 4:26p Cwagner
-- Add message 51003, 'Invalid data combination:%s'; added step to
-- retrieve messages as a confirmation
-- 
-- 2     6/19/03 4:14p Cwagner
-- Comment blocks added
