﻿//****************************************************************************
//*  $Archive:: /Database/StringSplitter/StringSplitter/SplitString.cs      $
//* $Workfile:: SplitString.cs                                              $
//*   $Author:: dbrown                                                      $
//* $Revision:: 1                                                           $
//*  $Modtime:: 2012-03-21 15:41:36-04:00                                   $
//****************************************************************************
//* Software distributed under the license is distributed on an "AS IS" basis,
//* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
//* for the specific language governing rights and limitations under the
//* license.
//*
//* Copyright (C) 2012 Newkirk Products Inc.
//* All Rights Reserved.
//****************************************************************************

#region Using
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
#endregion Using

namespace Newkirk.NewkirkOne.Sql
{
    /// <summary>
    ///     Partial Class defining the function to be added
    /// </summary>
    public partial class UserDefinedFunctions
    {
        /// <summary>
        ///     The function that will be available on the SQL server
        /// </summary>
        /// <param name="Input">The delimited string to split</param>
        /// <param name="Delimiter">The delimeter to split the string with</param>
        /// <returns>An enumerator pointing to the split string</returns>
        [Microsoft.SqlServer.Server.SqlFunction( FillRowMethodName = "FillRowSplitter", TableDefinition = "item nvarchar(4000)" )]
        public static IEnumerator ftSplitString(
            [SqlFacet( MaxSize = -1 )] SqlChars Input,
            [SqlFacet( MaxSize = 255 )] SqlChars Delimiter )
        {
            return (
                ( Input.IsNull || Delimiter.IsNull ) ?
                    new StringSplit( new char[0], new char[0] ) :
                    new StringSplit( Input.Value, Delimiter.Value )
            );
        }

        /// <summary>
        ///     Fills the rows of the table that will be returned
        /// </summary>
        /// <param name="obj">
        ///     The string to split
        /// </param>
        /// <param name="item">
        ///     The item that will be filled
        /// </param>
        public static void FillRowSplitter( object obj, out SqlString item )
        {
            item = new SqlString( (string)obj );
        }

        /// <summary>
        ///     An creates an enumerator that will walk through a delimited string
        /// </summary>
        public class StringSplit : IEnumerator
        {
            private int lastPos;
            private int nextPos;
            private readonly char[] theString;
            private readonly char[] delimiter;
            private readonly int stringLen;
            private readonly byte delimiterLen;
            private readonly bool isSingleCharDelim;

            /// <summary>
            ///     Constructor that sets up the private fields of the enmeriator
            /// </summary>
            /// <param name="TheString">
            ///     The string to split
            /// </param>
            /// <param name="Delimiter">
            ///     The enmerator to use
            /// </param>
            public StringSplit( char[] TheString, char[] Delimiter )
            {
                theString = TheString;
                stringLen = TheString.Length;
                delimiter = Delimiter;
                delimiterLen = (byte)( Delimiter.Length );
                isSingleCharDelim = ( delimiterLen == 1 );
                lastPos = 0;
                nextPos = delimiterLen * -1;
            }

            #region IEnumerator Members

            /// <summary>
            ///     Gets the current item
            /// </summary>
            public object Current
            {
                get
                {
                    return new string( theString, lastPos, nextPos - lastPos );
                }
            }

            /// <summary>
            ///     Moves the enumerator to the next item
            /// </summary>
            /// <returns></returns>
            public bool MoveNext()
            {
                if( nextPos >= stringLen )
                {
                    return false;
                }
                else
                {
                    lastPos = nextPos + delimiterLen;

                    for( int i = lastPos; i < stringLen; i++ )
                    {
                        bool matches = true;

                        //Optimize for single-character delimiters                    
                        if( isSingleCharDelim )
                        {
                            if( theString[i] != delimiter[0] )
                                matches = false;
                        }
                        else
                        {
                            for( byte j = 0; j < delimiterLen; j++ )
                            {
                                if( ( ( i + j ) >= stringLen ) || ( theString[i + j] != delimiter[j] ) )
                                {
                                    matches = false;
                                    break;
                                }
                            }
                        }

                        if( matches )
                        {
                            nextPos = i;

                            //Deal with consecutive delimiters                        
                            if( ( nextPos - lastPos ) > 0 )
                            {
                                return true;
                            }
                            else
                            {
                                i += ( delimiterLen - 1 );
                                lastPos += delimiterLen;
                            }
                        }
                    }

                    lastPos = nextPos + delimiterLen;
                    nextPos = stringLen;

                    if( ( nextPos - lastPos ) > 0 )
                        return true;
                    else
                        return false;
                }
            }

            /// <summary>
            ///     Resets the enumerator to the beginning of the string
            /// </summary>
            public void Reset()
            {
                lastPos = 0;
                nextPos = delimiterLen * -1;
            }

            #endregion

        }
    }
}