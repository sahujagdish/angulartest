to use this:
1. replace ~$~ with $
2. In Microsoft SQL Server Management Studio, do Query->Specify Values for Template Parameters
3. remove this line and everything above it
USE <DatabaseName, VARCHAR(17), Investment>

IF OBJECT_ID( 'dbo.<ViewName, VARCHAR(50), vRenameToYourViewName>', 'V' ) IS NOT NULL
    DROP VIEW dbo.<ViewName, VARCHAR(50), vRenameToYourViewName>
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- ~$~Workfile:: <ViewName, VARCHAR(50), vRenameToYourViewName>.sql                                                         ~$~
--  ~$~Archive:: /Database/<DatabaseName, VARCHAR(17), Investment>/Views/<ViewName, VARCHAR(50), vRenameToYourViewName>.sql                                                       ~$~
--   ~$~Author:: TBD                                                               ~$~
-- ~$~Revision:: 1                                                                 ~$~
--  ~$~Modtime:: d/mm/yy hh:mma                                                    ~$~
----------------------------------------------------------------------------------
-- <Additional notes or comments go here�>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis,
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the
-- license.
--
-- Copyright (C) 2011 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------
CREATE VIEW dbo.<ViewName, VARCHAR(50), vRenameToYourViewName>
AS
--<select statement>

GO

GRANT SELECT
	ON <ViewName, VARCHAR(50), vRenameToYourViewName>
	TO roleProcedureExecuter
GO

-- Object Version Stamp  Footer --
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '~$~Workfile: <ViewName, VARCHAR(50), vRenameToYourViewName>.sql ~$~', '~$~Revision: 1 ~$~'
END
GO
-- Object Version Stamp  Footer --
----------------------------------------------------------------------------------
-- ~$~Log: /Database/<DatabaseName, VARCHAR(17), Investment>/Views/<ViewName, VARCHAR(50), vRenameToYourViewName>.sql ~$~
-- 
