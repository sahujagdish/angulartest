to use this:
1. replace ~$~ with $
2. In Microsoft SQL Server Management Studio, do Query->Specify Values for Template Parameters
3. remove this line and everything above it
USE <DatabaseName, VARCHAR(17), Investment>

-- Drop procedure if it already exists
IF OBJECT_ID( '<ProcedureName, VARCHAR(50), pRenameToYourProcedureName>', 'P' ) IS NOT NULL
    DROP PROCEDURE dbo.<ProcedureName, VARCHAR(50), pRenameToYourProcedureName>
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- ~$~Workfile:: <ProcedureName, VARCHAR(50), pRenameToYourProcedureName>.sql                                                                          ~$~
--  ~$~Archive:: /Database/<DatabaseName, VARCHAR(17), Investment>/StoredProcedures/<ProcedureName, VARCHAR(50), pRenameToYourProcedureName>.sql                                                                                  ~$~
--   ~$~Author:: TBD                                                               ~$~
-- ~$~Revision:: 1                                                                 ~$~
--  ~$~Modtime:: d/mm/yy hh:mma                                                    ~$~
----------------------------------------------------------------------------------
-- Parameters:
--   Direction  Name                Description
--   IN/OUT     @<RequiredParameter1Name, VARCHAR(50), Parameter_1_Name>    
--   IN/OUT     @<RequiredParameter2Name, VARCHAR(50), Parameter_2_Name>    
--   IN/OUT     @<OptionalParameter1Name, VARCHAR(50), OptionalParameter_1_Name>    (optional) 
--   IN/OUT     @<OptionalParameter2Name, VARCHAR(50), OptionalParameter_2_Name>    (optional) 
--
-- Return Value:
--   <description of what return value contains>
--
-- Result Set(s):
--   <description of any result sets returned by the procedure>
--
----------------------------------------------------------------------------------
-- <Additional notes or comments go here�>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis,
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the
-- license.
--
-- Copyright (C) 2011 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE PROCEDURE dbo.<ProcedureName, VARCHAR(50), pRenameToYourProcedureName>
-- Required Parameters
    @<RequiredParameter1Name, VARCHAR(50), Parameter_1_Name>        <RequiredParameter1DataType, VARCHAR(50), Parameter_1_DataType>,
    @<RequiredParameter2Name, VARCHAR(50), Parameter_2_Name>        <RequiredParameter2DataType, VARCHAR(50), Parameter_2_DataType>

-- Optional Parameters
    @<OptionalParameter1Name, VARCHAR(50), OptionalParameter_1_Name> <OptionalParameter1DataType, VARCHAR(50), DataTypeOfOptionalParameter_1> = <OptionalParameter1Default, VARCHAR(50), DefaultValueOfOptionalParameter_1> ,
    @<OptionalParameter2Name, VARCHAR(50), OptionalParameter_2_Name> <OptionalParameter2DataType, VARCHAR(50), DataTypeOfOptionalParameter_2> = <OptionalParameter2Default, VARCHAR(50), DefaultValueOfOptionalParameter_2>
AS
    SET NOCOUNT ON

    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT

    --
    -- Procedure Variables
    --
--    <variables local to the procedure are declared here>

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@trancount

    BEGIN TRY
        --
        -- PROCESSING
        --
        IF @intIncomingTranCount = 0
        BEGIN
          -- if there is no transaction already present,
          -- this proc must start one
          BEGIN TRANSACTION
        END

        --
        -- Business Logic
        --


        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0
            COMMIT TRANSACTION

        RETURN 0
    END TRY
    BEGIN CATCH
        -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000)
        DECLARE @ErrorSeverity INT
        DECLARE @ErrorState INT
        DECLARE @ErrorNumber INT

        SELECT
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE(),
            @ErrorNumber =  ERROR_NUMBER()

        IF @intIncomingTranCount = 0 AND XACT_STATE() <> 0
            ROLLBACK TRANSACTION

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )

        RETURN @ErrorNumber
    END CATCH
GO

GRANT EXECUTE
    ON <ProcedureName, VARCHAR(50), pRenameToYourProcedureName>
    TO roleProcedureExecuter
GO

-- Object Version Stamp  Footer --
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '~$~Workfile: <ProcedureName, VARCHAR(50), pRenameToYourProcedureName>.sql ~$~', '~$~Revision: 1 ~$~'
END
GO
-- Object Version Stamp  Footer --

----------------------------------------------------------------------------------
-- ~$~Log: /Database/<DatabaseName, VARCHAR(17), Investment>/StoredProcedures/<ProcedureName, VARCHAR(50), pRenameToYourProcedureName>.sql ~$~
-- 
