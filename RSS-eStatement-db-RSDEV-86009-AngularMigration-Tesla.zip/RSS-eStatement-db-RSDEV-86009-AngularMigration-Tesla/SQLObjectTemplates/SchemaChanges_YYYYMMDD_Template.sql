----------------------------------------------------------------------------------
-- $Workfile::                                                                 $
-- $Archive::                                                                  $
-- $Author::                                                                   $
-- $Revision::                                                                 $
-- $Modtime::                                                                  $
----------------------------------------------------------------------------------
-- <Additional notes or comments go here�>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2003 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------



----------------------------------------------------------------------------------
-- $Log: $
