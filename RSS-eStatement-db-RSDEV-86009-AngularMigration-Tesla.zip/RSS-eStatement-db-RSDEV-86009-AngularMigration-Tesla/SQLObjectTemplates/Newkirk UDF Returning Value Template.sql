to use this:
1. replace ~$~ with $
2. In Microsoft SQL Server Management Studio, do Query->Specify Values for Template Parameters
3. remove this line and everything above it
USE <DatabaseName, VARCHAR(17), Investment>

IF OBJECT_ID( 'dbo.<FunctionName, VARCHAR(50), fvRenameToYourFunctionName>' ) IS NOT NULL
    DROP FUNCTION dbo.<FunctionName, VARCHAR(50), fvRenameToYourFunctionName>
GO

SET QUOTED_IDENTIFIER ON
GO

----------------------------------------------------------------------------------
-- ~$~Workfile:: <FunctionName, VARCHAR(50), fvRenameToYourFunctionName>.sql                                   ~$~
--  ~$~Archive:: /Database/<DatabaseName, VARCHAR(17), Investment>/UserDefinedFunctions/<FunctionName, VARCHAR(50), fvRenameToYourFunctionName>.sql                                                ~$~
--   ~$~Author:: TBD                                                               ~$~
-- ~$~Revision:: 1                                                                 ~$~
--  ~$~Modtime:: d/mm/yy hh:mma                                                    ~$~
----------------------------------------------------------------------------------
-- Parameters:
--   Direction	Name                Description
--   IN/OUT     @<Parameter1Name, VARCHAR(50), Parameter_1_Name>    
--   IN/OUT     @<Parameter2Name, VARCHAR(50), Parameter_2_Name>    
--
-- Return Value:
--   <description of what return value contains>
--
-- Result Set(s):
--   <description of any result sets returned by the procedure>
--
----------------------------------------------------------------------------------
-- <Additional notes or comments go here�>
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis,
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the
-- license.
--
-- Copyright (C) 2011 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------

CREATE FUNCTION dbo.<FunctionName, VARCHAR(50), fvRenameToYourFunctionName>(
   @<Parameter1Name, VARCHAR(50), Parameter_1_Name>        <Parameter1DataType, VARCHAR(50), Parameter_1_DataType>,
   @<Parameter2Name, VARCHAR(50), Parameter_2_Name>        <Parameter2DataType, VARCHAR(50), Parameter_2_DataType>
)
      RETURNS <ReturnVariableName, VARCHAR(50), ReturnVariable_Name>        <ReturnVariableDataType, VARCHAR(50), ReturnVariableDataType>
AS
BEGIN
    --
    -- Procedure Variables
    --
--    <variables local to the function are declared here>

    --
    -- Initialize variables
    --
--    <initialize local variables>

    --
    -- Business Logic
    --

--    RETURN  @<ReturnVariableName, VARCHAR(50), ReturnVariable_Name>
END

GO

GRANT EXECUTE
    ON <FunctionName, VARCHAR(50), fvRenameToYourFunctionName>
    TO roleProcedureExecuter
GO

-- Object Version Stamp  Footer --
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '~$~Workfile: <FunctionName, VARCHAR(50), fvRenameToYourFunctionName>.sql ~$~', '~$~Revision: 1 ~$~'
END
GO
-- Object Version Stamp  Footer --
----------------------------------------------------------------------------------
-- ~$~Log: /Database/<DatabaseName, VARCHAR(17), Investment>/UserDefinedFunctions/<FunctionName, VARCHAR(50), fvRenameToYourFunctionName>.sql ~$~
-- 
