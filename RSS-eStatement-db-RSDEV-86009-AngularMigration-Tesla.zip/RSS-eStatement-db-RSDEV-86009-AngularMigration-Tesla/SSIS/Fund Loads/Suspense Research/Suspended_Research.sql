USE Investment
GO
-- Get fund details to help resolve items that were put in the suspense table.
-- To use results, Resolve problems by NewkirkFundID_SUS group, as follows:
-- 1) Generally the top entries for a group will be active, have an NewkirkFundID_DB
--      and will have one M* entry (ReportingLevelID = A567C787-890C-4E8E-B9F4-09EBDD8688F4).
--      If so, these are the investments we will merge to.
-- 2) For each entry that has the reporter you're working on in the ReportingLevelID
--      column and a non-null value in the InvestmentID column

IF 0 = (SELECT COUNT(*) FROM InvestmentStaging..teImportSuspended)
BEGIN
    Print 'Thankfully, no investments were suspended!!'
    RETURN
END

IF 1 <> (SELECT COUNT(DISTINCT ReportingLevelID) FROM InvestmentStaging..teImportSuspended)
BEGIN
    RAISERROR( N'This script is typically run with one Reporter in the suspense table', 10, 1 )
    RETURN
END

DECLARE @MorningstarID UNIQUEIDENTIFIER
DECLARE @NewkirkID UNIQUEIDENTIFIER
SET @MorningstarID = 'A567C787-890C-4E8E-B9F4-09EBDD8688F4'
SET @NewkirkID = '636F6D6D-756E-696B-7370-617274796964'

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
SET @ReportingLevelID = (SELECT TOP 1 ReportingLevelID FROM InvestmentStaging..teImportSuspended)

DECLARE @SUS AS TABLE (
        NewkirkFundID CHAR(5),
        Ticker VARCHAR(10),
        CUSIP VARCHAR(10),
        FundName VARCHAR(100)
    )

INSERT @SUS (NewkirkFundID, Ticker, CUSIP, FundName)
(   SELECT SUS.ReporterFundIdentifier,
        RTRIM(LTRIM(M.Ticker)),
        RTRIM(LTRIM(M.CUSIP)),
        RTRIM(LTRIM(M.FundName))
    FROM InvestmentStaging..teImportSuspended SUS
    INNER JOIN InvestmentStaging..mstar_update_pip M
        ON  M.icdino = SUS.ReporterFundIdentifier
)

PRINT GETDATE()

DECLARE @Inv TABLE (
    InvestmentID UNIQUEIDENTIFIER,
    ReportingLevelID UNIQUEIDENTIFIER,
    NewkirkFundID CHAR(5) )

-- find any investments that match by Custom Identifier
IF @ReportingLevelID NOT IN (@MorningstarID, @NewkirkID)
INSERT @Inv (InvestmentID, ReportingLevelID, NewkirkFundID)
    (SELECT RFI_PI.InvestmentID, RFI_PI.ReportingLevelID, SUS.NewkirkFundID
    FROM    @SUS SUS
    JOIN teReporterFundIdentifier RFI_PI
      ON    RFI_PI.Identifier = SUS.NewkirkFundID
      AND   RFI_PI.ReporterKeyNameCD = 9 -- Custom Identifier
      AND   RFI_PI.ReportingLevelID = @ReportingLevelID)

PRINT GETDATE()

-- add in any investments that match by CUSIP or Ticker
INSERT @Inv (InvestmentID, ReportingLevelID, NewkirkFundID)
    (SELECT FP_C.InvestmentID, FP_C.ReportingLevelID, SUS.NewkirkFundID
    FROM    @SUS SUS
    JOIN    teFundPart FP_C
       ON   FP_C.FundPartTypeCD = 1 -- Info
    JOIN    teFundInfo FI_C
      ON    FI_C.FundPartID = FP_C.FundPartID
      AND   (FI_C.CUSIP = SUS.CUSIP
        OR   FI_C.Ticker = CASE WHEN SUS.Ticker IS NOT NULL AND LEN(SUS.Ticker) > 0
                THEN SUS.Ticker
                ELSE NULL
             END))

PRINT GETDATE()

-- add in a matching investment by provider for M* investment ID
INSERT @Inv (InvestmentID, ReportingLevelID, NewkirkFundID)
    (SELECT InvestmentID, @ReportingLevelID, NewkirkFundID
    FROM    @Inv Inv
    WHERE   ReportingLevelID = @MorningstarID)

PRINT GETDATE()

DECLARE @Inv2 TABLE (
    InvestmentID UNIQUEIDENTIFIER,
    ReportingLevelID UNIQUEIDENTIFIER,
    NewkirkFundID CHAR(5) )

INSERT @Inv2 (InvestmentID, ReportingLevelID, NewkirkFundID)
    (SELECT DISTINCT * FROM @Inv)

PRINT GETDATE()

CREATE TABLE #Results (
        NewkirkFundID_SUS CHAR(5),
        NewkirkFundID_DB CHAR(5),
        IsActive CHAR(1),
        ResourceCount TINYINT,
        Ticker_SUS VARCHAR(10),
        Ticker_DB VARCHAR(10),
        CUSIP_SUS VARCHAR(10),
        CUSIP_DB VARCHAR(10),
        FundName_SUS VARCHAR(100),
        FundName_DB VARCHAR(100),
        InvestmentID UNIQUEIDENTIFIER,
        ReportingLevelID UNIQUEIDENTIFIER,
        FundPartID UNIQUEIDENTIFIER)

INSERT #Results (NewkirkFundID_SUS, InvestmentID, IsActive, Ticker_SUS, CUSIP_SUS, FundName_SUS, ReportingLevelID)
(   SELECT SUS.NewkirkFundID,
        AI.InvestmentID,
        CASE WHEN AI.ReportingLevelID IS NULL
            THEN 'N'
            ELSE 'Y'
        END,
        SUS.Ticker,
        SUS.CUSIP,
        SUS.FundName,
        INV.ReportingLevelID
    FROM @SUS SUS
    LEFT JOIN @Inv2 INV
    ON   INV.NewkirkFundID = SUS.NewkirkFundID
    LEFT JOIN vActiveInvestment AI
        ON  AI.ReportingLevelID = INV.ReportingLevelID
        AND AI.InvestmentID = INV.InvestmentID
)

PRINT GETDATE()

UPDATE #Results SET
    FundPartID = (SELECT FP.FundPartID
        FROM teFundPart FP
        WHERE  FP.InvestmentID = #Results.InvestmentID
        AND FP.ReportingLevelID = #Results.ReportingLevelID
        AND FP.FundPartTypeCD = 1) -- Info

PRINT GETDATE()

UPDATE #Results SET
    NewkirkFundID_DB = (SELECT I.NewkirkFundID
         FROM   teInvestment I
         WHERE  I.InvestmentID = #Results.InvestmentID
         ),
    ResourceCount = (SELECT COUNT(*) FROM teInvestmentResource IR
         WHERE IR.InvestmentID = #Results.InvestmentID),
    Ticker_DB = (SELECT FI.Ticker
        FROM teFundInfo FI
        WHERE  FI.FundPartID = #Results.FundPartID),
    CUSIP_DB = (SELECT FI.CUSIP
        FROM teFundInfo FI
        WHERE  FI.FundPartID = #Results.FundPartID),
    FundName_DB = (SELECT FN.NamePrinted
        FROM teFundName FN
        WHERE  FN.FundPartID = #Results.FundPartID
        AND FN.LocaleCD=1033)

PRINT GETDATE()

SELECT DISTINCT
        NewkirkFundID_SUS,
        NewkirkFundID_DB,
        IsActive,
        ResourceCount,
        InvestmentID,
        (SELECT LongName FROM MainOne2One..teOrg
         WHERE OrgId = ReportingLevelID) AS Reporter,
        Ticker_SUS,
        Ticker_DB,
        CUSIP_SUS,
        CUSIP_DB,
        FundName_SUS,
        FundName_DB,
        ReportingLevelID
    FROM #Results
    ORDER BY NewkirkFundID_SUS, ResourceCount DESC, IsActive DESC, NewkirkFundID_DB DESC, InvestmentID, ReportingLevelID

DROP TABLE #Results