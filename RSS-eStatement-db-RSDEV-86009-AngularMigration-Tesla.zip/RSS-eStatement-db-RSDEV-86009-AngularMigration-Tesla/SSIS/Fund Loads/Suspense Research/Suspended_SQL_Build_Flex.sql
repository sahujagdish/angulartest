USE Investment

-- This SQL may be used to create the initial SQL statements that MAY
-- be used to fix suspended investments.  Following the full instuctions
-- in Suspended_Research.sql.

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @InvestmentTypeCD VARCHAR(2)
DECLARE @ReporterKeyNameCD VARCHAR(2)
DECLARE @DoMigration BIT
DECLARE @PrintedSomething BIT
DECLARE @MStarInvestmentID UNIQUEIDENTIFIER
DECLARE @MorningstarID UNIQUEIDENTIFIER
DECLARE @NewkirkID UNIQUEIDENTIFIER
SET @MorningstarID = 'A567C787-890C-4E8E-B9F4-09EBDD8688F4'
SET @NewkirkID = '636F6D6D-756E-696B-7370-617274796964'

DECLARE @NewkirkFundID CHAR(5)
DECLARE @Ticker VARCHAR(10)
DECLARE @CUSIP VARCHAR(10)

DECLARE NewkirkFundID_Cursor CURSOR FAST_FORWARD FOR
    SELECT 
        SUS.ReportingLevelID,
        SUS.ReporterFundIdentifier,
        RTRIM(LTRIM(M.Ticker)),
        RTRIM(LTRIM(M.CUSIP))
    FROM InvestmentStaging..teImportSuspended SUS
    INNER JOIN InvestmentStaging..mstar_update_pip M
        ON  M.icdino = SUS.ReporterFundIdentifier
    ORDER BY SUS.ReportingLevelID, 
        SUS.ReporterFundIdentifier
    
-- Do some initial data validation

IF 0 = (SELECT COUNT(*) FROM InvestmentStaging..teImportSuspended)
BEGIN
    Print 'Thankfully, no investments were suspended!!'
    RETURN
END

IF 1 <> (SELECT COUNT(DISTINCT InvestmentTypeCD) FROM InvestmentStaging..teImportSuspended)
BEGIN
    RAISERROR( N'This script must be run with one InvestmentTypeCD in the suspense table', 10, 1 )
    RETURN
END

PRINT 'Use Investment'
PRINT ''
PRINT 'DECLARE @InvestmentID UNIQUEIDENTIFIER'
PRINT 'DECLARE @ReportingLevelID UNIQUEIDENTIFIER'
PRINT ''
    
    
-- Pull out ReportingLevelID, InvestmentTypeCode & ReporterKeyNameCD from Suspense table
SELECT TOP 1
    @InvestmentTypeCD = CAST( InvestmentTypeCD AS VARCHAR(2) ),
    @ReporterKeyNameCD = CAST( ReporterKeyNameCD AS VARCHAR(2) )
FROM InvestmentStaging..teImportSuspended

-- Loop through investments from Suspense table

OPEN NewkirkFundID_Cursor

WHILE 1 = 1
BEGIN
    FETCH NewkirkFundID_Cursor INTO
        @ReportingLevelID, 
        @NewkirkFundID, 
        @Ticker, 
        @CUSIP

    IF @@FETCH_STATUS <> 0
        BREAK

    PRINT 'PRINT ''Migrating ' + @NewkirkFundID + ''''
    PRINT '    SET @ReportingLevelID = ''' + CAST( @ReportingLevelID AS VARCHAR(50) ) + ''''

    SET @PrintedSomething = 0

    -- Determine if NewkirkFundID on active investment at M* level
    IF @ReporterKeyNameCD = 4 -- NewkirkFundID (prev. ICDI)
	    SET @MStarInvestmentID = (SELECT I.InvestmentID
		    FROM teInvestment I
		    -- ensure investment is active @ M* level
		    JOIN vActiveInvestment AI
			    ON  AI.ReportingLevelID = @MorningstarID
			    AND AI.InvestmentID = I.InvestmentID
		    -- match by NewkirkFundID for M*
		    WHERE I.NewkirkFundID = @NewkirkFundID
		    -- limit to specific investment type
		      AND I.InvestmentTypeCD = @InvestmentTypeCD
		    )
    ELSE
	    SET @MStarInvestmentID = (SELECT RFI.InvestmentID
		    FROM teReporterFundIdentifier RFI
		    -- limit to specific investment type
		    JOIN teInvestment I
			    ON  I.InvestmentID = RFI.InvestmentID
			    AND I.InvestmentTypeCD = @InvestmentTypeCD
		    -- ensure investment is active @ M* level
		    JOIN vActiveInvestment AI
			    ON  AI.ReportingLevelID = @MorningstarID
			    AND AI.InvestmentID = I.InvestmentID
		    -- match by NewkirkFundID for M*
		    WHERE RFI.ReportingLevelID = @MorningstarID
		      AND RFI.ReporterKeyNameCD = @ReporterKeyNameCD
		      AND RFI.Identifier = @NewkirkFundID
		    )

    IF @MStarInvestmentID IS NOT NULL
    BEGIN
        -- Since we have a M* Investment ID, we know we can map to it for this client/reporter
        PRINT '    SET @InvestmentID = ''' + CAST( @MStarInvestmentID AS VARCHAR(50) ) + ''''
        PRINT ''
        PRINT '    EXEC dbo.pUpdateManuallyEnteredFunds @ReportingLevelID, @InvestmentID, @InvestmentID, 1' -- Fund Loaded Investment
        SET @PrintedSomething = 1
    END
    ELSE
    BEGIN
	    -- Since not found at M* level, try to find NewkirkFundID on active investment at Newkirk level
	    IF @ReporterKeyNameCD = 4 -- NewkirkFundID (prev. ICDI)
		    SET @MStarInvestmentID = (SELECT I.InvestmentID
			    FROM teInvestment I
			    -- ensure investment is active @ M* level
			    JOIN vActiveInvestment AI
				    ON  AI.ReportingLevelID = @NewkirkID
				    AND AI.InvestmentID = I.InvestmentID
			    -- match by NewkirkFundID for M*
			    WHERE I.NewkirkFundID = @NewkirkFundID
			    -- limit to specific investment type
			      AND I.InvestmentTypeCD = @InvestmentTypeCD
			    )
	    ELSE
		    SET @MStarInvestmentID = (SELECT RFI.InvestmentID
			    FROM teReporterFundIdentifier RFI
			    -- limit to specific investment type
			    JOIN teInvestment I
				    ON  I.InvestmentID = RFI.InvestmentID
				    AND I.InvestmentTypeCD = @InvestmentTypeCD
			    -- ensure investment is active @ Newkirk level
			    JOIN vActiveInvestment AI
				    ON  AI.ReportingLevelID = @NewkirkID
				    AND AI.InvestmentID = I.InvestmentID
			    -- match by NewkirkFundID for Newkirk
			    WHERE RFI.ReportingLevelID = @NewkirkID
			      AND RFI.ReporterKeyNameCD = @ReporterKeyNameCD
			      AND RFI.Identifier = @NewkirkFundID)

	    IF @MStarInvestmentID IS NOT NULL
	    BEGIN
		    -- Since we have a Newkirk Investment ID, we know we can map to it for this client/reporter
            PRINT '    SET @InvestmentID = ''' + CAST( @MStarInvestmentID AS VARCHAR(50) ) + ''''
            PRINT ''
            PRINT '    EXEC dbo.pUpdateManuallyEnteredFunds @ReportingLevelID, @InvestmentID, @InvestmentID, 1' -- Fund Loaded Investment
		    SET @PrintedSomething = 1
	    END
    END
    
    -- Loop through matches by CUSIP or Ticker for potential migration

    DECLARE @ReporterInvestmentID UNIQUEIDENTIFIER
    DECLARE Info_Cursor CURSOR FAST_FORWARD FOR
        SELECT FP.InvestmentID
            FROM teFundPart FP
            -- limit to specific investment type
            JOIN teInvestment I
                ON  I.InvestmentID = FP.InvestmentID
                AND I.InvestmentTypeCD = @InvestmentTypeCD
            -- ensure investment is active @ Reporter's level
		    JOIN vActiveInvestment AI
			    ON  AI.ReportingLevelID = @ReportingLevelID
			    AND AI.InvestmentID = I.InvestmentID
            -- pull in FundInfo to match by CUSIP or Ticker
            JOIN teFundInfo FI
                ON FI.FundPartID = FP.FundPartID
            -- match by CUSIP or Ticker for Reporter
            WHERE FP.ReportingLevelID = @ReportingLevelID
              AND FP.FundPartTypeCD = 1 -- Fund Info
              AND (
                FI.Cusip =
                    CASE WHEN @CUSIP = ''
                        THEN NULL -- to ensure no match
                        ELSE @CUSIP
                    END
                OR FI.Ticker = 
                    CASE WHEN @Ticker = ''
                        THEN NULL -- to ensure no match
                        ELSE @Ticker
                    END)

    OPEN Info_Cursor

    WHILE 1 = 1
    BEGIN
        FETCH Info_Cursor INTO @ReporterInvestmentID

        IF @@FETCH_STATUS <> 0
            BREAK

        IF @MStarInvestmentID IS NULL
        BEGIN
            SET @MStarInvestmentID = @ReporterInvestmentID
            SET @DoMigration = 1
        END
        ELSE IF @MStarInvestmentID <> @ReporterInvestmentID
            SET @DoMigration = 1
        ELSE
            SET @DoMigration = 0

        IF @DoMigration = 1
        BEGIN
            PRINT ''
            PRINT '    EXEC dbo.pUpdateManuallyEnteredFunds @ReportingLevelID, ''' +
                CAST( @ReporterInvestmentID AS VARCHAR(50) ) + ''', ''' +
                CAST( @MStarInvestmentID AS VARCHAR(50) ) + ''', ' +
                '1' -- Fund Loaded Investment
            SET @PrintedSomething = 1
        END
    END

    CLOSE Info_Cursor
    DEALLOCATE Info_Cursor

    IF @PrintedSomething = 0
    BEGIN
        -- Since printed nothing, so far, we must need to create investment
        PRINT '    SET @InvestmentID = ''' + CAST( NEWID() AS VARCHAR(50) ) + ''''
        PRINT ''
        PRINT '    INSERT INTO teInvestment (InvestmentID, InvestmentTypeCD, EnteredDttm, ModifiedDttm, NewkirkFundID)'
        PRINT '        VALUES (@InvestmentID, 2, GETDATE(), GETDATE(), ''' + @NewkirkFundID + ''')'
        PRINT '    INSERT INTO teFund (InvestmentID) VALUES (@InvestmentID)'
        PRINT '    EXEC dbo.pUpdateManuallyEnteredFunds @ReportingLevelID, @InvestmentID, @InvestmentID, 1'
    END
    PRINT ''
    PRINT ''
END

CLOSE NewkirkFundID_Cursor
DEALLOCATE NewkirkFundID_Cursor