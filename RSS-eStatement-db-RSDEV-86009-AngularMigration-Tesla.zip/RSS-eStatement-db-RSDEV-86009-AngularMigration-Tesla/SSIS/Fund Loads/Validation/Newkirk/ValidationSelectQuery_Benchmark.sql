USE Investment

SELECT
	indexname,
	mo1totret,
	mo3totret,
	yr1totret,
	ytdtotret,
	yr3annret,
	yr5annret,
	yr10annret,
	yr1,
	annret1,
	yr2,
	annret2,
	yr3,
	annret3,
	yr4,
	annret4,
	yr5,
	annret5,
	yr6,
	annret6,
	yr7,
	annret7,
	yr8,
	annret8,
	yr9,
	annret9,
	yr10,
	annret10,
	benchno,
	CONVERT( DATETIME, portasof )
FROM __benchmark_validation

--FROM InvestmentStaging..benchmark
WHERE benchno IS NOT NULL
ORDER BY benchno

