USE Investment

SELECT
	cat_id,
	category,
	benchno,
	CONVERT( DATETIME, portasof ) AS portasof,
	mo3catavg,
	ytdcatavg,
	yr1catavg,
	yr3catavg,
	yr5catavg,
	yr10catavg,
	yr1,
	cat_ann1,
	yr2,
	cat_ann2,
	yr3,
	cat_ann3,
	yr4,
	cat_ann4,
	yr5,
	cat_ann5,
	yr6,
	cat_ann6,
	yr7,
	cat_ann7,
	yr8,
	cat_ann8,
	yr9,
	cat_ann9,
	yr10,
	cat_ann10
FROM __category_validation
--FROM InvestmentStaging..category
WHERE cat_id IS NOT NULL
ORDER BY cat_id