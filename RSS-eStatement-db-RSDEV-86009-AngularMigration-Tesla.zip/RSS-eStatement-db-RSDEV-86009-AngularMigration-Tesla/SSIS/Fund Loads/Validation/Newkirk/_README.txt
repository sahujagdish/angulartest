USAGE
-----
Benchmark Load
--------------
1. (once) Run "Create __benchmark_validation.sql"
2. Run the Benchmark load batch file
3. Modify DataValidation_Benchmark.sql to have the proper as of date
4. Run DataValidation_Benchmark.sql
5. Modify the ValidationSelectQuery_Benchmark to run it against the InvestmentStaging..benchmark table
6. Run the ValidationSelectQuery_Benchmark and save the output to a PRE file
7. Modify the ValidationSelectQuery_Benchmark to run it against the Investment..__benchmark_validation table
8. Run the ValidationSelectQuery_Benchmark and save the output to a POST file
9. Compare the PRE & POST files

Category Load
-------------
do same as above, but replace "Benchmark" with "Category"

Newkirk Investment Load
-----------------------
1. Follow the steps in ..\README.txt, replacing "ValidationSelectQuery" with "ValidationSelectQuery_Newkirk"
2. do the same as "Benchmark Load", but replace "Benchmark" with "Ranking" or "NewkirkRanking" (as appropriate)