USE Investment

SELECT 
	R.icdino,
	CASE
		WHEN R.ytdcatrk IS NULL THEN 0.00
		ELSE R.ytdcatrk
	END AS ytdcatrk,
	CASE
		WHEN R.m3catrk IS NULL THEN 0.00
		ELSE R.m3catrk
	END AS m3catrk,
	CASE
		WHEN R.y1catrk IS NULL THEN 0.00
		ELSE R.y1catrk
	END AS y1catrk,
	CASE
		WHEN R.y3catrk IS NULL THEN 0.00
		ELSE R.y3catrk
	END AS y3catrk,
	CASE
		WHEN R.y5catrk IS NULL THEN 0.00
		ELSE R.y5catrk
	END AS y5catrk,
	CASE
		WHEN R.y10catrk IS NULL THEN 0.00
		ELSE R.y10catrk
	END AS y10catrk,
	R.yr1,
	CASE
		WHEN R.annret1rk IS NULL THEN 0.00
		ELSE R.annret1rk
	END AS annret1rk,
	R.yr2,
	CASE
		WHEN R.annret2rk IS NULL THEN 0.00
		ELSE R.annret2rk
	END AS annret2rk,
	R.yr3,
	CASE
		WHEN R.annret3rk IS NULL THEN 0.00
		ELSE R.annret3rk
	END AS annret3rk,
	R.yr4,
	CASE
		WHEN R.annret4rk IS NULL THEN 0.00
		ELSE R.annret4rk
	END AS annret4rk,
	R.yr5,
	CASE
		WHEN R.annret5rk IS NULL THEN 0.00
		ELSE R.annret5rk
	END AS annret5rk,
	R.yr6,
	CASE
		WHEN R.annret6rk IS NULL THEN 0.00
		ELSE R.annret6rk
	END AS annret6rk,
	R.yr7,
	CASE
		WHEN R.annret7rk IS NULL THEN 0.00
		ELSE R.annret7rk
	END AS annret7rk,
	R.yr8,
	CASE
		WHEN R.annret8rk IS NULL THEN 0.00
		ELSE R.annret8rk
	END AS annret8rk,
	R.yr9,
	CASE
		WHEN R.annret9rk IS NULL THEN 0.00
		ELSE R.annret9rk
	END AS annret9rk,
	R.yr10,
	CASE
		WHEN R.annret10rk IS NULL THEN 0.00
		ELSE R.annret10rk
	END AS annret10rk,
	CASE
		WHEN R.devrk3 IS NULL THEN 0.00
		ELSE R.devrk3
	END AS devrk3,
	CASE
		WHEN R.devrk5 IS NULL THEN 0.00
		ELSE R.devrk5
	END AS devrk5,
	CASE
		WHEN R.devrk10 IS NULL THEN 0.00
		ELSE R.devrk10
	END AS devrk10,
	CASE
		WHEN R.betark3 IS NULL THEN 0.00
		ELSE R.betark3
	END AS betark3,
	CASE
		WHEN R.betark5 IS NULL THEN 0.00
		ELSE R.betark5
	END AS betark5,
	CASE
		WHEN R.betark10 IS NULL THEN 0.00
		ELSE R.betark10
	END AS betark10,
	CASE
		WHEN R.alphark3 IS NULL THEN 0.00
		ELSE R.alphark3
	END AS alphark3,
	CASE
		WHEN R.alphark5 IS NULL THEN 0.00
		ELSE R.alphark5
	END AS alphark5,
	CASE
		WHEN R.alphark10 IS NULL THEN 0.00
		ELSE R.alphark10
	END AS alphark10,
	CASE
		WHEN R.rsqrk3 IS NULL THEN 0.00
		ELSE R.rsqrk3
	END AS rsqrk3,
	CASE
		WHEN R.rsqrk5 IS NULL THEN 0.00
		ELSE R.rsqrk5
	END AS rsqrk5,
	CASE
		WHEN R.rsqrk10 IS NULL THEN 0.00
		ELSE R.rsqrk10
	END AS rsqrk10,
	CASE
		WHEN R.rsqbestrk IS NULL THEN 0.00
		ELSE R.rsqbestrk
	END AS rsqbestrk,
	CASE
		WHEN R.betabestrk IS NULL THEN 0.00
		ELSE R.betabestrk
	END AS betabestrk,
	CASE
		WHEN R.alphbestrk IS NULL THEN 0.00
		ELSE R.alphbestrk
	END AS alphbestrk,
	CASE
		WHEN R.treybestrk IS NULL THEN 0.00
		ELSE R.treybestrk
	END AS treybestrk,
	CASE
		WHEN R.sharperk3 IS NULL THEN 0.00
		ELSE R.sharperk3
	END AS sharperk3,
	CASE
		WHEN R.sharperk5 IS NULL THEN 0.00
		ELSE R.sharperk5
	END AS sharperk5,
	CASE
		WHEN R.sharperk10 IS NULL THEN 0.00
		ELSE R.sharperk10
	END AS sharperk10,
	CASE
		WHEN R.sortinrk3 IS NULL THEN 0.00
		ELSE R.sortinrk3
	END AS sortinrk3,
	CASE
		WHEN R.sortinrk5 IS NULL THEN 0.00
		ELSE R.sortinrk5
	END AS sortinrk5,
	CASE
		WHEN R.sortinrk10 IS NULL THEN 0.00
		ELSE R.sortinrk10
	END AS sortinrk10,
	CASE
		WHEN R.treyrk3 IS NULL THEN 0.00
		ELSE R.treyrk3
	END AS treyrk3,
	CASE
		WHEN R.treyrk5 IS NULL THEN 0.00
		ELSE R.treyrk5
	END AS treyrk5,
	CASE
		WHEN R.treyrk10 IS NULL THEN 0.00
		ELSE R.treyrk10
	END AS treyrk10,
	CASE
		WHEN R.infork3 IS NULL THEN 0.00
		ELSE R.infork3
	END AS infork3,
	CASE 
		WHEN R.infork5 IS NULL THEN 0.00
		ELSE R.infork5
	END AS infork5,
	CASE
		WHEN R.infork10 IS NULL THEN 0.00
		ELSE R.infork10
	END AS infork10,
	CASE
		WHEN R.expgrossrk IS NULL THEN 0.00
		ELSE R.expgrossrk
	END AS expgrossrk,
	CASE
		WHEN R.expnetrk IS NULL THEN 0.00
		ELSE R.expnetrk
	END AS expnetrk,
	CASE
		WHEN R.turnrank IS NULL THEN 0.00
		ELSE R.turnrank
	END AS turnrank
FROM __ranking_validation R
WHERE R.icdino IS NOT NULL
ORDER BY R.icdino

--FROM InvestmentStaging..ranking R
--WHERE R.icdino IS NOT NULL
--ORDER BY R.icdino
--
