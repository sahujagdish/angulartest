USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @FirstYear DATETIME

SET @ReportingLevelID = '636F6D6D-756E-696B-7370-617274796964'
SET @CurrentAsOfDate = '2009-03-31'
SET @ReportingLevelAsOfDateID = (
	SELECT ReportingLevelAsOfDateID
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelID = @ReportingLevelID
      AND AsOfDate = @CurrentAsOfDate
)
SET @FirstYear = CAST( CAST( YEAR( @CurrentAsOfDate ) - 1 AS VARCHAR(4) ) + '-12-31' AS DATETIME )

TRUNCATE TABLE __ranking_validation

-- Initial Table Load
PRINT 'Table Insert'
INSERT INTO __ranking_validation( InvestmentID )
SELECT
	PYI.InvestmentID
FROM tePartyInvestment PYI
WHERE PYI.PartyID = @ReportingLevelID
	AND (PYI.ActiveEndDttm IS NULL OR PYI.ActiveEndDttm > GETDATE())


-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier'
UPDATE R
	SET icdino = CONVERT( char(5), RFI.Identifier )
FROM __ranking_validation R
LEFT JOIN teReporterFundIdentifier RFI
	ON R.InvestmentID = RFI.InvestmentID
		AND RFI.ReportingLevelID = @ReportingLevelID
		AND ReporterKeyNameCD = 4
	

-- Performance
PRINT 'Performance'
UPDATE R 
SET 
	m3catrk = MO3.PerformanceRank,
	y1catrk = Y1.PerformanceRank,
	y3catrk = Y3.PerformanceRank,
	y5catrk = Y5.PerformanceRank,
	y10catrk = Y10.PerformanceRank,
	ytdcatrk = TOT.PerformanceRank
FROM __ranking_validation R
JOIN teFundPart FP
	ON	FP.InvestmentID = R.InvestmentID
	AND FP.FundPartTypeCD = 16
	AND FP.ReportingLevelID = @ReportingLevelID
LEFT JOIN teFundPerformance MO3
	ON	MO3.FundPartID = FP.FundPartID
	AND MO3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND MO3.PerformanceTermTypeCD = 5
	AND MO3.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y1
	ON	Y1.FundPartID = FP.FundPartID
	AND Y1.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND Y1.PerformanceTermTypeCD = 6
	AND Y1.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y3
	ON	Y3.FundPartID = FP.FundPartID
	AND Y3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND Y3.PerformanceTermTypeCD = 7
	AND Y3.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y5
	ON	Y5.FundPartID = FP.FundPartID
	AND Y5.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND Y5.PerformanceTermTypeCD = 8
	AND Y5.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y10
	ON	Y10.FundPartID = FP.FundPartID
	AND Y10.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND Y10.PerformanceTermTypeCD = 9
	AND Y10.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance TOT
	ON	TOT.FundPartID = FP.FundPartID
	AND TOT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	AND TOT.PerformanceTermTypeCD = 10
	AND TOT.PerformanceTypeCD = 2

	
	
-- Annual Returns
PRINT 'Annual Returns'
UPDATE R
SET Yr1 = YEAR( @FirstYear ),
	Annret1rk = Y1.AnnualReturnRank,
	Yr2 = YEAR( @FirstYear ) - 1,
	Annret2rk = Y2.AnnualReturnRank,
	Yr3 = YEAR( @FirstYear ) - 2,
	Annret3rk = Y3.AnnualReturnRank,
	Yr4 = YEAR( @FirstYear ) - 3,
	Annret4rk = Y4.AnnualReturnRank,
	Yr5 = YEAR( @FirstYear ) - 4,
	Annret5rk = Y5.AnnualReturnRank,
	Yr6 = YEAR( @FirstYear ) - 5,
	Annret6rk = Y6.AnnualReturnRank,
	Yr7 = YEAR( @FirstYear ) - 6,
	Annret7rk = Y7.AnnualReturnRank,
	Yr8 = YEAR( @FirstYear ) - 7,
	Annret8rk = Y8.AnnualReturnRank,
	Yr9 = YEAR( @FirstYear ) - 8,
	Annret9rk = Y9.AnnualReturnRank,
	Yr10 = YEAR( @FirstYear ) - 9,
	Annret10rk = Y10.AnnualReturnRank
FROM __ranking_validation R
LEFT JOIN teFundPart FP
	ON R.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 14
LEFT JOIN teAnnualReturn Y1
	ON FP.FundPartID = Y1.FundPartID
		AND Y1.CalendarTypeCD = 1
		AND Y1.ReturnYear = @FirstYear
LEFT JOIN teAnnualReturn Y2
	ON FP.FundPartID = Y2.FundPartID
		AND Y2.CalendarTypeCD = 1
		AND Y2.ReturnYear = DATEADD( year, -1, @FirstYear )
LEFT JOIN teAnnualReturn Y3
	ON FP.FundPartID = Y3.FundPartID
		AND Y3.CalendarTypeCD = 1
		AND Y3.ReturnYear = DATEADD( year, -2, @FirstYear )
LEFT JOIN teAnnualReturn Y4
	ON FP.FundPartID = Y4.FundPartID
		AND Y4.CalendarTypeCD = 1
		AND Y4.ReturnYear = DATEADD( year, -3, @FirstYear )
LEFT JOIN teAnnualReturn Y5
	ON FP.FundPartID = Y5.FundPartID
		AND Y5.CalendarTypeCD = 1
		AND Y5.ReturnYear = DATEADD( year, -4, @FirstYear )
LEFT JOIN teAnnualReturn Y6
	ON FP.FundPartID = Y6.FundPartID
		AND Y6.CalendarTypeCD = 1
		AND Y6.ReturnYear = DATEADD( year, -5, @FirstYear )
LEFT JOIN teAnnualReturn Y7
	ON FP.FundPartID = Y7.FundPartID
		AND Y7.CalendarTypeCD = 1
		AND Y7.ReturnYear = DATEADD( year, -6, @FirstYear )
LEFT JOIN teAnnualReturn Y8
	ON FP.FundPartID = Y8.FundPartID
		AND Y8.CalendarTypeCD = 1
		AND Y8.ReturnYear = DATEADD( year, -7, @FirstYear )
LEFT JOIN teAnnualReturn Y9
	ON FP.FundPartID = Y9.FundPartID
		AND Y9.CalendarTypeCD = 1
		AND Y9.ReturnYear = DATEADD( year, -8, @FirstYear )
LEFT JOIN teAnnualReturn Y10
	ON FP.FundPartID = Y10.FundPartID
		AND Y10.CalendarTypeCD = 1
		AND Y10.ReturnYear = DATEADD( year, -9, @FirstYear )

-- Fund Metric Other Risk
PRINT 'Fund Metric Other Risk'
UPDATE R
SET  
	Devrk3 = MOR.StandardDeviation3YrRank,
	Devrk5 = MOR.StandardDeviation5YrRank,
	Devrk10 = MOR.StandardDeviation10YrRank,
	sharperk3 = MOR.SharpeRatio3YrRank,
	sharperk5 = MOR.SharpeRatio5YrRank,
	sharperk10 = MOR.SharpeRatio10YrRank,
	sortinrk3 = MOR.SortinoRatio3YrRank,
	sortinrk5 = MOR.SortinoRatio5YrRank,
	sortinrk10 = MOR.SortinoRatio10YrRank,
	infork3 = MOR.InformationRatio3YrRank,
	infork5 = MOR.InformationRatio5YrRank,
	infork10 = MOR.InformationRatio10YrRank
FROM __ranking_validation R
JOIN teFundPart FP
	ON R.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 21
JOIN teFundMetricOtherRisk MOR
	ON MOR.FundPartID = FP.FundPartID
		AND MOR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


-- Fund Metric MPT
PRINT 'Fund Metric MPT'
UPDATE R
SET 
	rsqrk3 = MPT.RSquare3YrRank,
	rsqbestrk = MPT.RSquare3YrBestFitRank,
	rsqrk5 = MPT.RSquare5YrRank,
	rsqrk10 = MPT.RSquare10YrRank,
	betark3 = MPT.Beta3YrRank,
	betabestrk = MPT.Beta3YrBestFitRank,
	betark5 = MPT.Beta5YrRank,
	betark10 = MPT.Beta10YrRank,
	alphark3 = MPT.Alpha3YrRank,
	alphbestrk = MPT.Alpha3YrBestFitRank,
	alphark5 = MPT.Alpha5YrRank,
	alphark10 = MPT.Alpha10YrRank,
	treyrk3 = MPT.TreynorRatio3YrRank,
	treybestrk = MPT.TreynorRatio3YrBestFitRank,
	treyrk5 = MPT.TreynorRatio5YrRank,
	treyrk10 = MPT.TreynorRatio10YrRank
FROM __ranking_validation R
JOIN teFundPart FP
	ON R.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 19
JOIN teFundMetricMPT MPT
	ON MPT.FundPartID = FP.FundPartID
		AND MPT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		
		
-- Fund Fee
PRINT 'Fund Fee'
UPDATE R
SET  
	expgrossrk = FEE.ExpenseRatioGrossRank,
	expnetrk = FEE.ExpenseRatioNetRank
FROM __ranking_validation R
JOIN teFundPart FP
	ON R.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 24
JOIN teFundFee FEE
	ON FEE.FundPartID = FP.FundPartID
		AND FEE.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		

-- Fund Metric Portfolio Statistic
PRINT 'Fund Metric Portfolio Statistic'
UPDATE R
SET
	turnrank = P.TurnOverRatioRank
FROM __ranking_validation R
JOIN teFundPart FP
	ON R.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 22
JOIN teFundMetricPortfolioStatistic P
	ON P.FundPartID = FP.FundPartID
		AND P.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
