USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @FirstYear DATETIME

SET @ReportingLevelID = '636F6D6D-756E-696B-7370-617274796964'
SET @CurrentAsOfDate = '2009-03-31'
SET @ReportingLevelAsOfDateID = (
	SELECT ReportingLevelAsOfDateID
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelID = @ReportingLevelID
      AND AsOfDate = @CurrentAsOfDate
)
SET @FirstYear = CAST( CAST( YEAR( @CurrentAsOfDate ) - 1 AS VARCHAR(4) ) + '-12-31' AS DATETIME )

TRUNCATE TABLE __benchmark_validation

-- Initial Table Load
PRINT 'Table Insert'
INSERT INTO __benchmark_validation( InvestmentID )
SELECT
	PYI.InvestmentID
FROM tePartyInvestment PYI
JOIN teInvestment I
	ON I.InvestmentID = PYI.InvestmentID
		AND I.InvestmentTypeCD = 4
WHERE PYI.PartyID = @ReportingLevelID
	AND (PYI.ActiveEndDttm IS NULL OR PYI.ActiveEndDttm > GETDATE())


-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier'
UPDATE B
	SET benchno = CONVERT( decimal(6, 0), RFI.Identifier )
FROM __benchmark_validation B
LEFT JOIN teReporterFundIdentifier RFI
	ON B.InvestmentID = RFI.InvestmentID
		AND RFI.ReportingLevelID = @ReportingLevelID
		AND ReporterKeyNameCD = 8


--ReportingLevelAsOfDate
PRINT 'ReportingLevelAsOfDate'
UPDATE __benchmark_validation
SET portasof = (
	SELECT AsOfDate
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
)


-- Annual Returns
PRINT 'Annual Returns'
UPDATE B
SET Yr1 = YEAR( @FirstYear ),
	Annret1 = ISNULL( Y1.AnnualReturnPct, -999.00 ),
	Yr2 = YEAR( @FirstYear ) - 1,
	Annret2 = ISNULL( Y2.AnnualReturnPct, -999.00 ),
	Yr3 = YEAR( @FirstYear ) - 2,
	Annret3 = ISNULL( Y3.AnnualReturnPct, -999.00 ),
	Yr4 = YEAR( @FirstYear ) - 3,
	Annret4 = ISNULL( Y4.AnnualReturnPct, -999.00 ),
	Yr5 = YEAR( @FirstYear ) - 4,
	Annret5 = ISNULL( Y5.AnnualReturnPct, -999.00 ),
	Yr6 = YEAR( @FirstYear ) - 5,
	Annret6 = ISNULL( Y6.AnnualReturnPct, -999.00 ),
	Yr7 =YEAR( @FirstYear ) - 6,
	Annret7 = ISNULL( Y7.AnnualReturnPct, -999.00 ),
	Yr8 = YEAR( @FirstYear ) - 7,
	Annret8 = ISNULL( Y8.AnnualReturnPct, -999.00 ),
	Yr9 = YEAR( @FirstYear ) - 8,
	Annret9 = ISNULL( Y9.AnnualReturnPct, -999.00 ),
	Yr10 = YEAR( @FirstYear ) - 9,
	Annret10 = ISNULL( Y10.AnnualReturnPct, -999.00 )
FROM __benchmark_validation B
JOIN teFundPart FP
	ON B.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 14
LEFT JOIN teAnnualReturn Y1
	ON FP.FundPartID = Y1.FundPartID
		AND Y1.CalendarTypeCD = 1
		AND Y1.ReturnYear = @FirstYear
LEFT JOIN teAnnualReturn Y2
	ON FP.FundPartID = Y2.FundPartID
		AND Y2.CalendarTypeCD = 1
		AND Y2.ReturnYear = DATEADD( year, -1, @FirstYear )
LEFT JOIN teAnnualReturn Y3
	ON FP.FundPartID = Y3.FundPartID
		AND Y3.CalendarTypeCD = 1
		AND Y3.ReturnYear = DATEADD( year, -2, @FirstYear )
LEFT JOIN teAnnualReturn Y4
	ON FP.FundPartID = Y4.FundPartID
		AND Y4.CalendarTypeCD = 1
		AND Y4.ReturnYear = DATEADD( year, -3, @FirstYear )
LEFT JOIN teAnnualReturn Y5
	ON FP.FundPartID = Y5.FundPartID
		AND Y5.CalendarTypeCD = 1
		AND Y5.ReturnYear = DATEADD( year, -4, @FirstYear )
LEFT JOIN teAnnualReturn Y6
	ON FP.FundPartID = Y6.FundPartID
		AND Y6.CalendarTypeCD = 1
		AND Y6.ReturnYear = DATEADD( year, -5, @FirstYear )
LEFT JOIN teAnnualReturn Y7
	ON FP.FundPartID = Y7.FundPartID
		AND Y7.CalendarTypeCD = 1
		AND Y7.ReturnYear = DATEADD( year, -6, @FirstYear )
LEFT JOIN teAnnualReturn Y8
	ON FP.FundPartID = Y8.FundPartID
		AND Y8.CalendarTypeCD = 1
		AND Y8.ReturnYear = DATEADD( year, -7, @FirstYear )
LEFT JOIN teAnnualReturn Y9
	ON FP.FundPartID = Y9.FundPartID
		AND Y9.CalendarTypeCD = 1
		AND Y9.ReturnYear = DATEADD( year, -8, @FirstYear )
LEFT JOIN teAnnualReturn Y10
	ON FP.FundPartID = Y10.FundPartID
		AND Y10.CalendarTypeCD = 1
		AND Y10.ReturnYear = DATEADD( year, -9, @FirstYear )


-- Performance
PRINT 'Performance'
UPDATE B
SET 
	mo1totret = ISNULL( MO1.PerformancePct, -999.00 ),
	mo3totret = ISNULL( MO3.PerformancePct, -999.00 ),
	yr1totret = ISNULL( Y1.PerformancePct, -999.00 ),
	yr3annret = ISNULL( Y3.PerformancePct, -999.00 ),
	yr5annret = ISNULL( Y5.PerformancePct, -999.00 ),
	yr10annret = ISNULL( Y10.PerformancePct, -999.00 ),
	ytdtotret = ISNULL( TOT.PerformancePct, -999.00 )
FROM __benchmark_validation B
JOIN teFundPart FP
	ON B.InvestmentID = FP.InvestmentID
		AND FP.FundPartTypeCD = 16
		AND FP.ReportingLevelID = @ReportingLevelID
LEFT JOIN teFundPerformance MO1
	ON MO1.FundPartID = FP.FundPartID
		AND MO1.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND MO1.PerformanceTermTypeCD = 4
		AND MO1.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance MO3
	ON MO3.FundPartID = FP.FundPartID
		AND MO3.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND MO3.PerformanceTermTypeCD = 5
		AND MO3.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y1
	ON Y1.FundPartID = FP.FundPartID
		AND Y1.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND Y1.PerformanceTermTypeCD = 6
		AND Y1.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y3
	ON Y3.FundPartID = FP.FundPartID
		AND Y3.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND Y3.PerformanceTermTypeCD = 7
		AND Y3.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y5
	ON Y5.FundPartID = FP.FundPartID
		AND Y5.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND Y5.PerformanceTermTypeCD = 8
		AND Y5.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y10
	ON Y10.FundPartID = FP.FundPartID
		AND Y10.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND Y10.PerformanceTermTypeCD = 9
		AND Y10.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance TOT
	ON TOT.FundPartID = FP.FundPartID
		AND TOT.ReportingLevelAsOfDateID = MO1.ReportingLevelAsOfDateID
		AND TOT.PerformanceTermTypeCD = 10
		AND TOT.PerformanceTypeCD = 2


-- Basic Fund Info	
PRINT 'Basic Fund Info'
UPDATE B 
SET IndexName = FN.NamePrinted
FROM __benchmark_validation B
JOIN teFundPart FP_BASIC
	ON B.InvestmentID = FP_BASIC.InvestmentId
		AND FP_BASIC.ReportingLevelID = @ReportingLevelID
		AND FP_BASIC.FundPartTypeCD = 1
LEFT JOIN teFundName FN
	ON FN.FundPartID = FP_BASIC.FundPartID
		AND FN.LocaleCD = 1033
