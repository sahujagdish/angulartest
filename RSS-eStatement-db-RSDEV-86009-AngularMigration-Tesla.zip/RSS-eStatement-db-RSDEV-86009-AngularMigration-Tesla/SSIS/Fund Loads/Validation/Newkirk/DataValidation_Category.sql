USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @FirstYear INT

SET @ReportingLevelID = '636F6D6D-756E-696B-7370-617274796964'
SET @CurrentAsOfDate = '2009-03-31'
SET @ReportingLevelAsOfDateID = (
	SELECT ReportingLevelAsOfDateID
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelID = @ReportingLevelID
      AND AsOfDate = @CurrentAsOfDate
)
SET @FirstYear = YEAR( @CurrentAsOfDate ) - 1

TRUNCATE TABLE __category_validation

-- Initial Table Load
PRINT 'Table Insert'
INSERT INTO __category_validation( StyleGroupID, cat_id, category, BenchmarkInvestmentID )
SELECT
	SG.StyleGroupID,
	SG.ReporterStyleGroupKey,
	SG.Descrip,
	SG.BenchmarkInvestmentID
FROM teStyleGroup SG
WHERE SG.ReportingLevelID = @ReportingLevelID
	AND SG.ReporterStyleGroupKey IS NOT NULL
	

--ReportingLevelAsOfDate
PRINT 'ReportingLevelAsOfDate'
UPDATE __category_validation
SET portasof = (
	SELECT AsOfDate
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
)

-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier'
UPDATE C
	SET benchno = CONVERT( decimal(6, 0), RFI.Identifier )
FROM __category_validation C
LEFT JOIN teReporterFundIdentifier RFI
	ON C.BenchmarkInvestmentID = RFI.InvestmentID
		AND RFI.ReportingLevelID = @ReportingLevelID
		AND ReporterKeyNameCD = 8


-- Annual Returns
PRINT 'Annual Returns'
UPDATE C
SET Yr1 = @FirstYear,
	Cat_ann1 = ISNULL( Y1.AverageValue, -999.00 ),
	Yr2 = @FirstYear - 1,
	Cat_ann2 = ISNULL( Y2.AverageValue, -999.00 ),
	Yr3 = @FirstYear - 2,
	Cat_ann3 = ISNULL( Y3.AverageValue, -999.00 ),
	Yr4 = @FirstYear - 3,
	Cat_ann4 = ISNULL( Y4.AverageValue, -999.00 ),
	Yr5 = @FirstYear - 4,
	Cat_ann5 = ISNULL( Y5.AverageValue, -999.00 ),
	Yr6 = @FirstYear - 5,
	Cat_ann6 = ISNULL( Y6.AverageValue, -999.00 ),
	Yr7 = @FirstYear - 6,
	Cat_ann7 = ISNULL( Y7.AverageValue, -999.00 ),
	Yr8 = @FirstYear - 7,
	Cat_ann8 = ISNULL( Y8.AverageValue, -999.00 ),
	Yr9 = @FirstYear - 8,
	Cat_ann9 = ISNULL( Y9.AverageValue, -999.00 ),
	Yr10 = @FirstYear - 9,
	Cat_ann10 = ISNULL( Y10.AverageValue, -999.00 )
FROM __category_validation C
LEFT JOIN teStyleGroupAnnualReturn Y1
	ON Y1.StyleGroupID = C.StyleGroupID
		AND Y1.Year = @FirstYear
LEFT JOIN teStyleGroupAnnualReturn Y2
	ON Y2.StyleGroupID = C.StyleGroupID
		AND Y2.Year = @FirstYear - 1
LEFT JOIN teStyleGroupAnnualReturn Y3
	ON Y3.StyleGroupID = C.StyleGroupID
		AND Y3.Year = @FirstYear - 2
LEFT JOIN teStyleGroupAnnualReturn Y4
	ON Y4.StyleGroupID = C.StyleGroupID
		AND Y4.Year = @FirstYear - 3
LEFT JOIN teStyleGroupAnnualReturn Y5
	ON Y5.StyleGroupID = C.StyleGroupID
		AND Y5.Year = @FirstYear - 4
LEFT JOIN teStyleGroupAnnualReturn Y6
	ON Y6.StyleGroupID = C.StyleGroupID
		AND Y6.Year = @FirstYear - 5
LEFT JOIN teStyleGroupAnnualReturn Y7
	ON Y7.StyleGroupID = C.StyleGroupID
		AND Y7.Year = @FirstYear - 6
LEFT JOIN teStyleGroupAnnualReturn Y8
	ON Y8.StyleGroupID = C.StyleGroupID
		AND Y8.Year = @FirstYear - 7
LEFT JOIN teStyleGroupAnnualReturn Y9
	ON Y9.StyleGroupID = C.StyleGroupID
		AND Y9.Year = @FirstYear - 8
LEFT JOIN teStyleGroupAnnualReturn Y10
	ON Y10.StyleGroupID = C.StyleGroupID
		AND Y10.Year = @FirstYear - 9


-- Performance
PRINT 'Performance'
UPDATE C
SET 
	mo3catavg = ISNULL( SGTR.AverageValue3Mo, -999.00 ),
	yr1catavg = ISNULL( SGTR.AverageValue1Yr, -999.00 ),
	yr3catavg = ISNULL( SGTR.AverageValue3Yr, -999.00 ),
	yr5catavg = ISNULL( SGTR.AverageValue5Yr, -999.00 ),
	yr10catavg = ISNULL( SGTR.AverageValue10Yr, -999.00 ),
	ytdcatavg = ISNULL( SGTR.AverageValueYTD , -999.00 )
FROM __category_validation C
LEFT JOIN teStyleGroupTrailingReturn SGTR
	ON SGTR.StyleGroupID = C.StyleGroupID
		AND SGTR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID