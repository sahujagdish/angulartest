USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @IsCustomFund BIT

SET @ReportingLevelID = '636F6D6D-756E-696B-7370-617274796964'
SET @IsCustomFund = 0

-- Pre Validation Query
--SELECT
--    Icdino,
--    CompositionTypeCD,
--    AsOfDate,
--    CONVERT( VARCHAR(60), SecurityName ) AS SecurityName,
--    CompositionPercent,
--    Rank
--FROM InvestmentStaging..CompositionData
--ORDER BY Icdino, CompositionTypeCD, RANK

-- Post Validation Query
--SELECT
--    AI.NewkirkFundID AS Icdino,
--    FCS.FundCompositionTypeCD AS CompositionTypeCD,
--    CASE
--        WHEN FCD.SortOrder = 1 THEN FCS.AsOfDate 
--        ELSE '1899-12-30 00:00:00.000'
--    END AS AsOfDate,
--    FCD.Descrip AS SecurityName,
--    CONVERT( DECIMAL( 5,2 ), FCD.PercentValue ) AS CompositionPercent,
--    FCD.SortOrder AS RANK
--FROM vActiveInvestment AI
--JOIN teFundPart FP
--    ON FP.InvestmentID = AI.InvestmentID
--        AND FP.ReportingLevelID = AI.ReportingLevelID
--        AND FP.FundPartTypeCD = 26
--JOIN teFundCompositionSummary FCS
--    ON FCS.FundPartID = FP.FundPartID
--JOIN teFundCompositionDetail FCD
--    ON FCD.FundPartID = FCS.FundPartID
--    AND FCD.FundCompositionTypeCD = FCS.FundCompositionTypeCD
--WHERE AI.ReportingLevelID = @ReportingLevelID
--AND AI.IsCustomFund = @IsCustomFund
--ORDER BY Icdino, CompositionTypeCD, RANK
