USE Investment
GO
SELECT
	V.SecurityID AS SECURITYID,
	CASE WHEN V.TotRetYtd = -999
        THEN NULL
        ELSE V.TotRetYtd
    END AS TotRetYtd
FROM InvestmentStaging..ML_GMYTDReturns V
JOIN __goalManager_YTDPerf_Validation O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID