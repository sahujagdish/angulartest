USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @NewkirkID UNIQUEIDENTIFIER

SET @CurrentAsOfDate = '2008-08-31'

SET @ReportingLevelID = '25A7E82C-C64E-4648-B915-EFF79B60160F'
SET @NewkirkID = '636F6D6D-756E-696B-7370-617274796964'
SET @ReportingLevelAsOfDateID = (SELECT ReportingLeveLAsOfDateID
    FROM teReportingLevelAsOfDate
    WHERE   ReportingLevelID = @ReportingLevelID
    AND     AsOfDate = @CurrentAsOfDate)

--select * from teReportingLevelAsOfDate WHERE ReportingLevelID = '440A1C4A-77DB-41C0-9660-9A39AE27E340' AND AsOfDate = '2008-06-30'

TRUNCATE TABLE __goalManager_YTDPerf_Validation 


PRINT 'Table Insert'
INSERT INTO __goalManager_YTDPerf_Validation( InvestmentID )
SELECT
	I.InvestmentID
FROM teInvestment I
JOIN tePartyInvestment P
	ON  P.InvestmentID = I.InvestmentID
	AND P.PartyID = @ReportingLevelID
	AND (P.ActiveEndDttm IS NULL OR P.ActiveEndDttm > GETDATE())
WHERE I.InvestmentTypeCD IN (2,6) -- Fund, Portfolio
	

-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier & Portfolio Performance Data'
UPDATE M
	SET SecurityID = (SELECT CONVERT( VARCHAR(30), RFI.Identifier )
        FROM teReporterFundIdentifier RFI
	    WHERE RFI.InvestmentID = M.InvestmentID
		    AND RFI.ReportingLevelID = @ReportingLevelID
		    AND ReporterKeyNameCD = 9), -- Custom Identifier
    YtdPerformancePct = (SELECT PP.YtdPerformancePct
        FROM tePortfolioPerformance PP
	    WHERE PP.FundPartID = (SELECT FP.FundPartID
                FROM teFundPart FP
	            WHERE FP.InvestmentID = M.InvestmentID
	                AND FP.ReportingLevelID = @ReportingLevelID
	                AND FP.FundPartTypeCD = 10)
		    AND PP.YtdPerformanceAsOfDate = @CurrentAsOfDate)
FROM __goalManager_YTDPerf_Validation M
