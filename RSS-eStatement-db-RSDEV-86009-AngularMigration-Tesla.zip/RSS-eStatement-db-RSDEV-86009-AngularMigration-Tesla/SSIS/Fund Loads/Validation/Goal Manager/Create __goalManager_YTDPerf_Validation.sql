USE Investment
GO
IF OBJECT_ID('__goalManager_YTDPerf_Validation') IS NOT NULL
	DROP TABLE dbo.__goalManager_YTDPerf_Validation
GO
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET ANSI_PADDING ON

GO
CREATE TABLE __goalManager_YTDPerf_Validation(
	InvestmentID UNIQUEIDENTIFIER,
	SecurityID VARCHAR(30),
	YtdPerformancePct DECIMAL(12,4)
) ON [PRIMARY]