USE Investment
GO
SELECT
	V.SecurityID AS SECURITYID,
	V.YtdPerformancePct*100 AS TotRetYtd
FROM __goalManager_Monthly_Validation V
JOIN InvestmentStaging..ML_GMYTDReturns O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID 

SELECT 
	V.SecurityID AS SECURITYID,
	V.TotRetYtd AS TotRetYtd
FROM InvestmentStaging..ML_GMYTDReturns V
JOIN __goalManager_Monthly_Validation O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID 

