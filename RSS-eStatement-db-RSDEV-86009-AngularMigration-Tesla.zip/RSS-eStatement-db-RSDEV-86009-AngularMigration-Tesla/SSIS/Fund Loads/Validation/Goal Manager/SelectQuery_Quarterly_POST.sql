USE Investment
GO
SELECT
	V.SecurityID AS SECURITYID,
	V.YTD AS CurQtrYTD,
	V.CTR3m AS TotRetCQTR,
	V.AR1Yr AS AnRet1Yr,
	V.AR3Yr AS AnRet3Yr,
	V.AR5Yr AS AnRet5Yr,
	V.AR10Yr AS AnRet10Yr,
	V.SinceInception AS AnRetSI,
	V.FPODate
FROM __goalManager_Quarterly_Validation V
JOIN InvestmentStaging..ML_GMReport_OnQtr O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID