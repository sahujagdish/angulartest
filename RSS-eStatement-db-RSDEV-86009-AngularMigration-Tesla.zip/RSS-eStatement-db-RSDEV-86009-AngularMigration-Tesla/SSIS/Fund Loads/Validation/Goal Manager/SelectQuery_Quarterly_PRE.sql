USE Investment
GO
SELECT 
	CONVERT( VARCHAR(30), V.SECURITYID) AS SECURITYID,
	V.CurQtrYTD,
	V.TotRetCQTR,
	V.AnRet1Yr,
	V.AnRet3Yr,
	V.AnRet5Yr,
	V.AnRet10Yr,
	V.AnRetSI,
	V.FPODate
FROM InvestmentStaging..ML_GMReport_OnQtr V
JOIN __goalManager_Quarterly_Validation O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID