USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @NewkirkID UNIQUEIDENTIFIER

SET @CurrentAsOfDate = '2008-12-31'

SET @ReportingLevelID = '25A7E82C-C64E-4648-B915-EFF79B60160F'
SET @NewkirkID = '636F6D6D-756E-696B-7370-617274796964'
SET @ReportingLevelAsOfDateID = (SELECT ReportingLeveLAsOfDateID
    FROM teReportingLevelAsOfDate
    WHERE   ReportingLevelID = @ReportingLevelID
    AND     AsOfDate = @CurrentAsOfDate)

--select * from teReportingLevelAsOfDate WHERE ReportingLevelID = '440A1C4A-77DB-41C0-9660-9A39AE27E340' AND AsOfDate = '2008-06-30'

TRUNCATE TABLE __goalManager_Quarterly_Validation 


PRINT 'Table Insert'
INSERT INTO __goalManager_Quarterly_Validation( InvestmentID )
SELECT
	I.InvestmentID
FROM teInvestment I
JOIN tePartyInvestment P
	ON  P.InvestmentID = I.InvestmentID
    AND P.PartyID = @ReportingLevelID
	AND (P.ActiveEndDttm IS NULL OR P.ActiveEndDttm > GETDATE())
WHERE I.InvestmentTypeCD IN (2,6) -- Fund or Portfolio
	

-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier & Basic Fund Info'
UPDATE M
	SET SecurityID = (SELECT CONVERT( VARCHAR(30), RFI.Identifier )
            FROM teReporterFundIdentifier RFI
	        WHERE RFI.InvestmentID = M.InvestmentID
	        AND RFI.ReportingLevelID = @ReportingLevelID
	        AND ReporterKeyNameCD = 9),
    FPODate = (SELECT FI.ShareClassInceptionDate
            FROM teFundInfo FI
	        WHERE FI.FundPartID = (SELECT FP_BASIC.FundPartID
                FROM teFundPart FP_BASIC
	            WHERE M.InvestmentID = FP_BASIC.InvestmentId
	            AND FP_BASIC.ReportingLevelID = @ReportingLevelID
	            AND FP_BASIC.FundPartTypeCD = 1))
FROM __goalManager_Quarterly_Validation M

	
-- Performance
PRINT 'Performance'
UPDATE M 
SET 
	CTR3m = (SELECT MO3.PerformancePct
        FROM teFundPerformance MO3
	    WHERE MO3.FundPartID = FP.FundPartID
		AND   MO3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND   MO3.PerformanceTermTypeCD = 5
		AND   MO3.PerformanceTypeCD = 2),
	YTD = (SELECT TOT.PerformancePct
        FROM teFundPerformance TOT
	    WHERE TOT.FundPartID = FP.FundPartID
		AND TOT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND TOT.PerformanceTermTypeCD = 10
		AND TOT.PerformanceTypeCD = 2),
	AR1Yr = (SELECT Y1.PerformancePct
        FROM teFundPerformance Y1
	    WHERE Y1.FundPartID = FP.FundPartID
		AND   Y1.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND   Y1.PerformanceTermTypeCD = 6
		AND   Y1.PerformanceTypeCD = 2),
	AR3Yr = (SELECT Y3.PerformancePct
        FROM teFundPerformance Y3
	    WHERE Y3.FundPartID = FP.FundPartID
		AND Y3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND Y3.PerformanceTermTypeCD = 7
		AND Y3.PerformanceTypeCD = 1),
	AR5Yr = (SELECT Y5.PerformancePct
        FROM teFundPerformance Y5
	    WHERE Y5.FundPartID = FP.FundPartID
		AND Y5.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND Y5.PerformanceTermTypeCD = 8
		AND Y5.PerformanceTypeCD = 1),
	AR10Yr = (SELECT Y10.PerformancePct
        FROM teFundPerformance Y10
	    WHERE Y10.FundPartID = FP.FundPartID
		AND Y10.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND Y10.PerformanceTermTypeCD = 9
		AND Y10.PerformanceTypeCD = 1),
	SinceInception = (SELECT INC.PerformancePct
        FROM teFundPerformance INC 
	    WHERE INC.FundPartID = FP.FundPartID
		AND INC.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		AND INC.PerformanceTermTypeCD = 11
		AND INC.PerformanceTypeCD = 1)
FROM __goalManager_Quarterly_Validation M
JOIN teFundPart FP
	ON FP.InvestmentID = M.InvestmentID
	AND FP.FundPartTypeCD = 16
	AND FP.ReportingLevelID = @ReportingLevelID
