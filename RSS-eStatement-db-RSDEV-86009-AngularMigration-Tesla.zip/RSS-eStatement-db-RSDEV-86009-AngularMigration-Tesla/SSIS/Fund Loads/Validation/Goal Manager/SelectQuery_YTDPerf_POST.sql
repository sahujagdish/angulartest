USE Investment
GO
SELECT
	V.SecurityID AS SECURITYID,
	V.YtdPerformancePct*100 AS TotRetYtd
FROM __goalManager_YTDPerf_Validation V
JOIN InvestmentStaging..ML_GMYTDReturns O
	ON V.SecurityID = LTRIM(RTRIM(O.SecurityID))
ORDER BY V.SecurityID