USAGE
-----
1. (once) Run "Create __goalManager_*_Validation.sql" scripts (2)
2. Run the Goal Manager load of your choice
3. For Monthly loads, you'll be using YTDPerf scripts, only.  For Quarterly, YTDPerf & Quarterly.
4. Modify the As Of Date in the appropriate LoadValidation script(s)
4. Run the appropriate LoadValidation script(s)
5. Run the PRE SelectQuery script(s), saving the resutls to file(s)
6. Run the POST SelectQuery script(s), saving the resutls to file(s)
7. Compare the PRE & POST file(s)

DETAILS
-------

In the Scripts starting with LoadValidation, the @CurrentAsOfDate variable needed to be set correctly depending on the date to be tested.

Scripts starting with SelectQuery will select from either the Investment..__mstar_update_validation table or the InvestmentStaging..mstar_update_pip table. There are commented FROM clauses at the bottom of the file which will do either one. Currently, they join from __mstar_update_validation to mstar_update_pip because of the missing investments that we had. Remove the JOIN to get a full list.

Depending on the comparison program used, the full field list is too long to usefully compare, so the comma (,) is comented out after Past10Date to allow all the succeeding fields to be commented and the select statement broken up into two different outputs.

