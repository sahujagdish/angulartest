USE Investment
GO

IF object_id('dbo.pLoadFundLoadValidation') IS NOT NULL
	DROP PROCEDURE dbo.pLoadFundLoadValidation
GO

----------------------------------------------------------------------------------
-- $Workfile:: pLoadFundLoadValidation.sql                                       $
-- $Author:: Psingleton                                                          $
-- $Revision:: 6                                                                 $
-- $Modtime:: 3/29/10 9:32a                                                      $
----------------------------------------------------------------------------------
-- Parameters:
--   Dir.   Name                Description
--   IN     @ReportingLevelID   GUID of client/reporter
--   IN     @AsOfDate           Reporting Date that was just loaded into N1
--
-- Return Value:
--   None
--
-- Result Set(s):
--   None
--
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2003-2008 Newkirk Products, Inc.
-- All Rights Reserved.
----------------------------------------------------------------------------------
CREATE PROCEDURE pLoadFundLoadValidation
    @ReportingLevelID UNIQUEIDENTIFIER,
    @AsOfDate DATETIME
AS

    DECLARE @BisysReporterID UNIQUEIDENTIFIER
    DECLARE @BokReporterID UNIQUEIDENTIFIER
    DECLARE @MorningstarReporterID UNIQUEIDENTIFIER
    DECLARE @NewkirkReporterID UNIQUEIDENTIFIER
    DECLARE @SunTrustReporterID UNIQUEIDENTIFIER
    SET @BisysReporterID = '440A1C4A-77DB-41C0-9660-9A39AE27E340'
    SET @BokReporterID = 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B'
    SET @MorningstarReporterID = 'A567C787-890C-4E8E-B9F4-09EBDD8688F4'
    SET @NewkirkReporterID = '636F6D6D-756E-696B-7370-617274796964'
    SET @SunTrustReporterID = 'F9138720-39B5-4DD5-8244-6741C8F3FE50'
    
    DECLARE @TempReporterID UNIQUEIDENTIFIER

    RAISERROR( 'Setup', 0, 1) WITH NOWAIT

    DECLARE @ReportingLevelAsOfDateID INT

    SET @ReportingLevelAsOfDateID = (
	    SELECT ReportingLevelAsOfDateID
	    FROM teReportingLevelAsOfDate
	    WHERE ReportingLevelID = @ReportingLevelID
          AND AsOfDate = @AsOfDate
    )

    -- Determine scoped ReportingLevelID
	DECLARE @ReportingLevelIDList VARCHAR(200)
	SET @ReportingLevelIDList = ''
	SELECT @ReportingLevelIDList =
		@ReportingLevelIDList + ',' + CAST( ReportingLevelID AS VARCHAR(36))
		FROM ftGetReportingLevelIDList( @ReportingLevelID )
	SET @ReportingLevelIDList = SUBSTRING( @ReportingLevelIDList, 2, 999 )

    TRUNCATE TABLE __mstar_update_validation

    RAISERROR( 'Table Insert', 0, 1) WITH NOWAIT
    INSERT INTO __mstar_update_validation(
        InvestmentID,
        ReportingLevelID,
        ReportingLevelAsOfDateID,
        portasof,
        icdino,
        commonname )
    SELECT
	    I.InvestmentID,
	    @ReportingLevelID,
	    @ReportingLevelAsOfDateID,
        @AsOfDate,
        I.NewkirkFundID,
        I.CommonName
    FROM teInvestment I
    JOIN vActiveInvestment AI
	    ON AI.ReportingLevelID = @ReportingLevelID
	    AND AI.InvestmentID = I.InvestmentID
    WHERE I.InvestmentTypeCD = 2

    IF @ReportingLevelID <> @MorningstarReporterID
    BEGIN
        RAISERROR( 'RFI Custom Identifier', 0, 1 ) WITH NOWAIT
        UPDATE M
        SET identifier = ISNULL( (SELECT CONVERT( char(10), RFI.Identifier )
                FROM teReporterFundIdentifier RFI
                WHERE RFI.InvestmentID = M.InvestmentID
                AND RFI.ReportingLevelID = @ReportingLevelID
                AND RFI.ReporterKeyNameCD = 9), '' )
        FROM __mstar_update_validation M
    END

    -- Benchno
    RAISERROR( 'Benchno', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET benchno = (SELECT CONVERT( decimal(6,0) , RFI.Identifier )
            FROM teReporterFundIdentifier RFI
	        WHERE RFI.InvestmentID = (SELECT IB.BmkInvestmentID
                FROM teInvestmentBenchmark IB
	            WHERE IB.InvestmentID = M.InvestmentID
		        AND IB.ReportingLevelID = @ReportingLevelID)
	        AND RFI.ReportingLevelID = @NewkirkReporterID
	        AND RFI.ReporterKeyNameCD = 8)
    FROM __mstar_update_validation M

    -- Style Group
    RAISERROR( 'Style Group', 0, 1 ) WITH NOWAIT
    SET @TempReporterID = dbo.fvReporterIdOfStyleGroups( @ReportingLevelIDList )
    UPDATE M
    SET Category = CONVERT( char(39), SG.Descrip),
	    Cat_id = CASE WHEN @TempReporterID IN (@MorningstarReporterID, @NewkirkReporterID)
                THEN CONVERT( char(10), SG.ReporterStyleGroupKey )
                ELSE ''
            END
    FROM __mstar_update_validation M
    JOIN teInvestmentStyleGroup ISG
	    ON M.InvestmentID = ISG.InvestmentId
    JOIN teStyleGroup SG
	    ON SG.StyleGroupID = ISG.StyleGroupID
		    AND SG.ReportingLevelID = @TempReporterID

    -- Basic Fund Info	
    RAISERROR( 'Basic Fund Info', 0, 1 ) WITH NOWAIT
    UPDATE M 
    SET Ticker = ISNULL( FI.Ticker, ''),
	    cusip = ISNULL( FI.Cusip, ''),
	    Inception = ISNULL( FI.ShareClassInceptionDate, '1899-12-30' ),
	    Inception2 = ISNULL( FI.FundInceptionDate, '1899-12-30' ),
	    FundName = SUBSTRING(FN.NamePrinted,1,74),
	    sp_name = ISNULL( FN.NamePrintedShort, '' ),
	    Objective = ISNULL( FIP.ObjectiveStatement, '' )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP_BASIC
	    ON M.InvestmentID = FP_BASIC.InvestmentId
		    AND FP_BASIC.ReportingLevelID = @ReportingLevelID
		    AND FP_BASIC.FundPartTypeCD = 1
    LEFT JOIN teFundName FN
	    ON FN.FundPartID = FP_BASIC.FundPartID
		    AND FN.LocaleCD = 1033
    LEFT JOIN teFundInfo FI
	    ON FI.FundPartID = FP_BASIC.FundPartID
    LEFT JOIN teFundInfoPolicy FIP
	    ON FIP.FundPartID = FP_BASIC.FundPartID
		    AND FIP.LocaleCD = 1033	


    -- Asset Group
    IF @ReportingLevelID <> @MorningstarReporterID
    BEGIN
        RAISERROR( 'Asset Group', 0, 1 ) WITH NOWAIT
		SET @TempReporterID = dbo.fvReporterIdOfStyleGroups( @ReportingLevelIDList )
        UPDATE M
        SET AssetClass = (SELECT
            CASE WHEN @TempReporterID IN (@MorningstarReporterID, @NewkirkReporterID)
                THEN AGD.Abbrev
                ELSE AGD.Descrip
            END
			FROM teInvestmentAssetGroup IAG
			JOIN teAssetGroup AG
				ON AG.AssetGroupID = IAG.AssetGroupID
					AND AG.ReportingLevelID = @TempReporterID
			JOIN teAssetGroupDescrip AGD
				ON AGD.AssetGroupID = AG.AssetGroupID
					AND AGD.LocaleCD = 1033
			WHERE IAG.InvestmentID = M.InvestmentID
			)
        FROM __mstar_update_validation M
    END
    	
    -- Performance
    RAISERROR( 'Performance', 0, 1 ) WITH NOWAIT
    UPDATE M 
    SET 
	    yld7day = ISNULL( Y7.PerformancePct, -999.00 ),
	    eff7day = ISNULL( E7.PerformancePct, -999.00 ),
	    yld30day = ISNULL( Y30.PerformancePct, -999.00 ),
	    mo1totret = ISNULL( MO1.PerformancePct, -999.00 ),
	    mo3totret = ISNULL( MO3.PerformancePct, -999.00 ),
	    yr1totret = ISNULL( Y1.PerformancePct, -999.00 ),
	    yr3annret = ISNULL( Y3.PerformancePct, -999.00 ),
	    yr5annret = ISNULL( Y5.PerformancePct, -999.00 ),
	    yr10annret = ISNULL( Y10.PerformancePct, -999.00 ),
	    ytdtotret = ISNULL( TOT.PerformancePct, -999.00 ),
	    inceptret = ISNULL( INC.PerformancePct, -999.00 ),
	    closing = ISNULL( C.PerformancePct, -999.00 ),
	    high52wk = ISNULL( H.PerformancePct, -999.00 ),
	    low52wk = ISNULL( L.PerformancePct, -999.00 )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON	FP.InvestmentID = M.InvestmentID
	    AND FP.FundPartTypeCD = 16
	    AND FP.ReportingLevelID = @ReportingLevelID
    LEFT JOIN teFundPerformance Y7
	    ON	Y7.FundPartID = FP.FundPartID
	    AND Y7.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y7.PerformanceTermTypeCD = 1
	    AND Y7.PerformanceTypeCD = 3
    LEFT JOIN teFundPerformance E7
	    ON	E7.FundPartID = FP.FundPartID
	    AND E7.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND E7.PerformanceTermTypeCD = 2
	    AND E7.PerformanceTypeCD = 3
    LEFT JOIN teFundPerformance Y30
	    ON	Y30.FundPartID = FP.FundPartID
	    AND Y30.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y30.PerformanceTermTypeCD = 3
	    AND Y30.PerformanceTypeCD = 3
    LEFT JOIN teFundPerformance MO1
	    ON	MO1.FundPartID = FP.FundPartID
	    AND MO1.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND MO1.PerformanceTermTypeCD = 4
	    AND MO1.PerformanceTypeCD = 2
    LEFT JOIN teFundPerformance MO3
	    ON	MO3.FundPartID = FP.FundPartID
	    AND MO3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND MO3.PerformanceTermTypeCD = 5
	    AND MO3.PerformanceTypeCD = 2
    LEFT JOIN teFundPerformance Y1
	    ON	Y1.FundPartID = FP.FundPartID
	    AND Y1.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y1.PerformanceTermTypeCD = 6
	    AND Y1.PerformanceTypeCD = 2
    LEFT JOIN teFundPerformance Y3
	    ON	Y3.FundPartID = FP.FundPartID
	    AND Y3.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y3.PerformanceTermTypeCD = 7
	    AND Y3.PerformanceTypeCD = 1
    LEFT JOIN teFundPerformance Y5
	    ON	Y5.FundPartID = FP.FundPartID
	    AND Y5.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y5.PerformanceTermTypeCD = 8
	    AND Y5.PerformanceTypeCD = 1
    LEFT JOIN teFundPerformance Y10
	    ON	Y10.FundPartID = FP.FundPartID
	    AND Y10.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND Y10.PerformanceTermTypeCD = 9
	    AND Y10.PerformanceTypeCD = 1
    LEFT JOIN teFundPerformance TOT
	    ON	TOT.FundPartID = FP.FundPartID
	    AND TOT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND TOT.PerformanceTermTypeCD = 10
	    AND TOT.PerformanceTypeCD = 2
    LEFT JOIN teFundPerformance INC 
	    ON	INC.FundPartID = FP.FundPartID
	    AND INC.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND INC.PerformanceTermTypeCD = 11
	    AND INC.PerformanceTypeCD = 1
    LEFT JOIN teFundPerformance C
	    ON	C.FundPartID = FP.FundPartID
	    AND C.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND C.PerformanceTermTypeCD = 14
	    AND C.PerformanceTypeCD = 4
    LEFT JOIN teFundPerformance H 
	    ON	H.FundPartID = FP.FundPartID
	    AND H.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND H.PerformanceTermTypeCD = 15
	    AND H.PerformanceTypeCD = 4
    LEFT JOIN teFundPerformance L
	    ON	L.FundPartID = FP.FundPartID
	    AND L.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	    AND L.PerformanceTermTypeCD = 16
	    AND L.PerformanceTypeCD = 4 
    	

    -- Annual Returns
    DECLARE @FirstYear INT
    SET @FirstYear = YEAR( @AsOfDate ) -
		CASE MONTH( @AsOfDate )
			WHEN 12 THEN 0
			ELSE 1
		END
    RAISERROR( 'Annual Returns', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET Yr1 = @FirstYear,
	    Annret1 = ISNULL( Y1.AnnualReturnPct, -999.00 ),
	    Yr2 = @FirstYear - 1,
	    Annret2 = ISNULL( Y2.AnnualReturnPct, -999.00 ),
	    Yr3 = @FirstYear - 2,
	    Annret3 = ISNULL( Y3.AnnualReturnPct, -999.00 ),
	    Yr4 = @FirstYear - 3,
	    Annret4 = ISNULL( Y4.AnnualReturnPct, -999.00 ),
	    Yr5 = @FirstYear - 4,
	    Annret5 = ISNULL( Y5.AnnualReturnPct, -999.00 ),
	    Yr6 = @FirstYear - 5,
	    Annret6 = ISNULL( Y6.AnnualReturnPct, -999.00 ),
	    Yr7 = @FirstYear - 6,
	    Annret7 = ISNULL( Y7.AnnualReturnPct, -999.00 ),
	    Yr8 = @FirstYear - 7,
	    Annret8 = ISNULL( Y8.AnnualReturnPct, -999.00 ),
	    Yr9 = @FirstYear - 8,
	    Annret9 = ISNULL( Y9.AnnualReturnPct, -999.00 ),
	    Yr10 = @FirstYear - 9,
	    Annret10 = ISNULL( Y10.AnnualReturnPct, -999.00 )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 14
    LEFT JOIN teAnnualReturn Y1
	    ON FP.FundPartID = Y1.FundPartID
		    AND Y1.CalendarTypeCD = 1
		    AND Y1.ReturnYear = CAST( @FirstYear AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y2
	    ON FP.FundPartID = Y2.FundPartID
		    AND Y2.CalendarTypeCD = 1
		    AND Y2.ReturnYear = CAST( @FirstYear - 1 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y3
	    ON FP.FundPartID = Y3.FundPartID
		    AND Y3.CalendarTypeCD = 1
		    AND Y3.ReturnYear = CAST( @FirstYear - 2 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y4
	    ON FP.FundPartID = Y4.FundPartID
		    AND Y4.CalendarTypeCD = 1
		    AND Y4.ReturnYear = CAST( @FirstYear - 3 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y5
	    ON FP.FundPartID = Y5.FundPartID
		    AND Y5.CalendarTypeCD = 1
		    AND Y5.ReturnYear = CAST( @FirstYear - 4 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y6
	    ON FP.FundPartID = Y6.FundPartID
		    AND Y6.CalendarTypeCD = 1
		    AND Y6.ReturnYear = CAST( @FirstYear - 5 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y7
	    ON FP.FundPartID = Y7.FundPartID
		    AND Y7.CalendarTypeCD = 1
		    AND Y7.ReturnYear = CAST( @FirstYear - 6 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y8
	    ON FP.FundPartID = Y8.FundPartID
		    AND Y8.CalendarTypeCD = 1
		    AND Y8.ReturnYear = CAST( @FirstYear - 7 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y9
	    ON FP.FundPartID = Y9.FundPartID
		    AND Y9.CalendarTypeCD = 1
		    AND Y9.ReturnYear = CAST( @FirstYear - 8 AS CHAR(4)) + '-12-31'
    LEFT JOIN teAnnualReturn Y10
	    ON FP.FundPartID = Y10.FundPartID
		    AND Y10.CalendarTypeCD = 1
		    AND Y10.ReturnYear = CAST( @FirstYear - 9 AS CHAR(4)) + '-12-31'


    -- Past Returns
    RAISERROR( 'Past Returns', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET Past1date = @AsOfDate,
	    Past1 = ISNULL( Y1.AnnualReturnPct, -999.00 ),
	    Past2date = DATEADD( year, -1, @AsOfDate ),
	    Past2 = ISNULL( Y2.AnnualReturnPct, -999.00 ),
	    Past3date = DATEADD( year, -2, @AsOfDate ),
	    Past3 = ISNULL( Y3.AnnualReturnPct, -999.00 ),
	    Past4date = DATEADD( year, -3, @AsOfDate ),
	    Past4 = ISNULL( Y4.AnnualReturnPct, -999.00 ),
	    Past5date = DATEADD( year, -4, @AsOfDate ),
	    Past5 = ISNULL( Y5.AnnualReturnPct, -999.00 ),
	    Past6date = DATEADD( year, -5, @AsOfDate ),
	    Past6 = ISNULL( Y6.AnnualReturnPct, -999.00 ),
	    Past7date = DATEADD( year, -6, @AsOfDate ),
	    Past7 = ISNULL( Y7.AnnualReturnPct, -999.00 ),
	    Past8date = DATEADD( year, -7, @AsOfDate ),
	    Past8 = ISNULL( Y8.AnnualReturnPct, -999.00 ),
	    Past9date = DATEADD( year, -8, @AsOfDate ),
	    Past9 = ISNULL( Y9.AnnualReturnPct, -999.00 ),
	    Past10date = DATEADD( year, -9, @AsOfDate ),
	    Past10 = ISNULL( Y10.AnnualReturnPct, -999.00 )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 14
    LEFT JOIN teAnnualReturn Y1
	    ON FP.FundPartID = Y1.FundPartID
		    AND Y1.CalendarTypeCD = 2
		    AND Y1.ReturnYear = @AsOfDate
    LEFT JOIN teAnnualReturn Y2
	    ON FP.FundPartID = Y2.FundPartID
		    AND Y2.CalendarTypeCD = 2
		    AND Y2.ReturnYear = DATEADD( year, -1, @AsOfDate )
    LEFT JOIN teAnnualReturn Y3
	    ON FP.FundPartID = Y3.FundPartID
		    AND Y3.CalendarTypeCD = 2
		    AND Y3.ReturnYear = DATEADD( year, -2, @AsOfDate )
    LEFT JOIN teAnnualReturn Y4
	    ON FP.FundPartID = Y4.FundPartID
		    AND Y4.CalendarTypeCD = 2
		    AND Y4.ReturnYear = DATEADD( year, -3, @AsOfDate )
    LEFT JOIN teAnnualReturn Y5
	    ON FP.FundPartID = Y5.FundPartID
		    AND Y5.CalendarTypeCD = 2
		    AND Y5.ReturnYear = DATEADD( year, -4, @AsOfDate )
    LEFT JOIN teAnnualReturn Y6
	    ON FP.FundPartID = Y6.FundPartID
		    AND Y6.CalendarTypeCD = 2
		    AND Y6.ReturnYear = DATEADD( year, -5, @AsOfDate )
    LEFT JOIN teAnnualReturn Y7
	    ON FP.FundPartID = Y7.FundPartID
		    AND Y7.CalendarTypeCD = 2
		    AND Y7.ReturnYear = DATEADD( year, -6, @AsOfDate )
    LEFT JOIN teAnnualReturn Y8
	    ON FP.FundPartID = Y8.FundPartID
		    AND Y8.CalendarTypeCD = 2
		    AND Y8.ReturnYear = DATEADD( year, -7, @AsOfDate )
    LEFT JOIN teAnnualReturn Y9
	    ON FP.FundPartID = Y9.FundPartID
		    AND Y9.CalendarTypeCD = 2
		    AND Y9.ReturnYear = DATEADD( year, -8, @AsOfDate )
    LEFT JOIN teAnnualReturn Y10
	    ON FP.FundPartID = Y10.FundPartID
		    AND Y10.CalendarTypeCD = 2
		    AND Y10.ReturnYear = DATEADD( year, -9, @AsOfDate )

    -- Fund Metric Other Risk
    RAISERROR( 'Fund Metric Other Risk', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET  
	    Stddev3a = ISNULL( MOR.StandardDeviation3YrValue, 0.00 ),
	    Stddev5a = ISNULL( MOR.StandardDeviation5YrValue, 0.00 ),
	    Stddev10a = ISNULL( MOR.StandardDeviation10YrValue, 0.00 ),
	    Sharpe3 = ISNULL( MOR.SharpeRatio3YrValue, 0.00 ),
	    Sharpe5 = ISNULL( MOR.SharpeRatio5YrValue, 0.00 ),
	    Sharpe10 = ISNULL( MOR.SharpeRatio10YrValue, 0.00 ),
	    Sortino3 = ISNULL( MOR.SortinoRatio3YrValue, 0.00 ),
	    Sortino5 = ISNULL( MOR.SortinoRatio5YrValue, 0.00 ),
	    Sortino10 = ISNULL( MOR.SortinoRatio10YrValue, 0.00 ),
	    Info3 = ISNULL( MOR.InformationRatio3YrValue, 0.00 ),
	    Info5 = ISNULL( MOR.InformationRatio5YrValue, 0.00 ),
	    Info10 = ISNULL( MOR.InformationRatio10YrValue, 0.00 )
    FROM __mstar_update_validation M
    JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 21
    JOIN teFundMetricOtherRisk MOR
	    ON MOR.FundPartID = FP.FundPartID
		    AND MOR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


    -- Fund Metric MPT
    RAISERROR( 'Fund Metric MPT', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET 
	    Rsquare3 = ISNULL( MPT.RSquare3YrValue, 0.00 ),
	    Rsqbest3 = ISNULL( MPT.RSquare3YrBestFitValue, 0.00 ),
	    Rsquare5 = ISNULL( MPT.RSquare5YrValue, 0.00 ),
	    Rsquare10 = ISNULL( MPT.RSquare10YrValue, 0.00 ),
	    Beta3 = ISNULL( MPT.Beta3YrValue, 0.00 ),
	    Betabest3 = ISNULL( MPT.Beta3YrBestFitValue, 0.00 ),
	    Beta5 = ISNULL( MPT.Beta5YrValue, 0.00 ),
	    Beta10 = ISNULL( MPT.Beta10YrValue, 0.00 ),
	    Alpha3 = ISNULL( MPT.Alpha3YrValue, 0.00 ),
	    Alphabest3 = ISNULL( MPT.Alpha3YrBestFitValue, 0.00 ),
	    Alpha5 = ISNULL( MPT.Alpha5YrValue, 0.00 ),
	    Alpha10 = ISNULL( MPT.Alpha10YrValue, 0.00 ),
	    Treynor3 = ISNULL( MPT.TreynorRatio3YrValue, 0.00 ),
	    Treybest3 = ISNULL( MPT.TreynorRatio3YrBestFitValue, 0.00 ),
	    Treynor5 = ISNULL( MPT.TreynorRatio5YrValue, 0.00 ),
	    Treynor10 = ISNULL( MPT.TreynorRatio10YrValue, 0.00 )
    FROM __mstar_update_validation M
    JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 19
    JOIN teFundMetricMPT MPT
	    ON MPT.FundPartID = FP.FundPartID
		    AND MPT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

    -- Fund Metric MorningStar
    RAISERROR( 'Fund Metric MorningStar', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET  
	    Rating3 = ISNULL( MOR.Morningstar3YrRating, 0.00 ),
	    Riskrate3 = ISNULL( MOR.Morningstar3YrRisk, 0.00 ),
	    Perfrate3 = ISNULL( MOR.Morningstar3YrReturn, 0.00 ),
	    Rating5 = ISNULL( MOR.Morningstar5YrRating, 0.00 ),
	    Riskrate5 = ISNULL( MOR.Morningstar5YrRisk, 0.00 ),
	    Perfrate5 = ISNULL( MOR.Morningstar5YrReturn, 0.00 ),
	    Rating10 = ISNULL( MOR.Morningstar10YrRating, 0.00 ),
	    Riskrate10 = ISNULL( MOR.Morningstar10YrRisk, 0.00 ),
	    Perfrate10 = ISNULL( MOR.Morningstar10YrReturn, 0.00 )
    FROM __mstar_update_validation M
    JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 20
    JOIN teFundMetricMorningstar MOR
	    ON MOR.FundPartID = FP.FundPartID
		    AND MOR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


    -- Fund Fee
    RAISERROR( 'Fund Fee', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET  
	    Redemption = ISNULL( FEE.RedemptionFeePct, 0 ) * 100,
	    Redeemdays = ISNULL( FEE.RedemptionPeriod, 0 ),
	    expratio = ISNULL( FEE.ExpenseRatioGrossValue, 0 ),
	    expnet = ISNULL( FEE.ExpenseRatioNetValue, 0 ),
	    expdate = ISNULL( FEE.ExpenseDate, '1899-12-30' ),
	    Fee12b1 = ISNULL( FEE.Fee12b1, 0 ),
	    mgtexpense = ISNULL( FEE.Mgmt_Expense, 0 )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 24
    LEFT JOIN teFundFee FEE
	    ON FEE.FundPartID = FP.FundPartID
		    AND FEE.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


    -- Fund Metric Portfolio Statistic
    RAISERROR( 'Fund Metric Portfolio Statistic', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET
	    nav = ISNULL( P.NetAssetValue, 0 ),
	    totass = ISNULL( P.TotalAssets, 0 ),
	    mkt_cap = ISNULL( P.AvgMarketCap, 0 ),
	    turnover = ISNULL( P.TurnoverRatioValue, 0 ),
	    no_secs = ISNULL( P.TotalHoldings, 0 ),
	    pct_top10 = ISNULL( P.HoldingsPctInTopTen, 0 )
    FROM __mstar_update_validation M
    JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 22
    JOIN teFundMetricPortfolioStatistic P
	    ON P.FundPartID = FP.FundPartID
		    AND P.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

    -- Fund Management
    RAISERROR( 'Fund Management', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET 
	    Manager = ISNULL( MGT.ManagerName, '' ),
	    Mgrsince = ISNULL( MGT.ManagerStart, '' ),
	    website = ISNULL( MGT.WebSite, ''),
	    phone = ISNULL( MGT.PhoneNbr, ''),
	    mgryrs = ISNULL( MGT.ManagerTenure, 0 ),
	    IndexFund = CASE MGT.ManagementStyleTypeCD
			WHEN 1 THEN 1
			WHEN 2 THEN 0
			ELSE NULL
			END
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 11
    LEFT JOIN teFundManagement MGT
	    ON MGT.FundPartID = FP.FundPartID
		    AND MGT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

    -- Fixed Income Statistic
    RAISERROR( 'Fixed Income Statistic', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET 
	    mat_days = ISNULL( F.WeightedAvgMaturityDays, 0 ),
	    maturity = ISNULL( F.WeightedAvgMaturityYears, 0 ),
	    duration = ISNULL( F.DurationYears, 0 )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON M.InvestmentID = FP.InvestmentID
		    AND FP.ReportingLevelID = @ReportingLevelID
		    AND FP.FundPartTypeCD = 23
    LEFT JOIN teFundMetricFixedIncomeStatistic F
	    ON F.FundPartID = FP.FundPartID
		    AND F.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
		    
    -- Fund App Support Style Box
    RAISERROR( 'App Support Style Box', 0, 1 ) WITH NOWAIT
    UPDATE M
    SET 
	    StyleBox = ISNULL( F.StyleBoxMask, '' )
    FROM __mstar_update_validation M
    LEFT JOIN teFundPart FP
	    ON	FP.InvestmentID = M.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 17
    LEFT JOIN teFundAppSupportStyleBox F
	    ON	F.FundPartID = FP.FundPartID

GRANT EXECUTE
    ON pLoadFundLoadValidation
    TO roleProcedureExecuter
GO

-- Object Version Stamp  Footer --

IF EXISTS (SELECT * FROM sysObjects WHERE name LIKE 'pStampVersion')
BEGIN 
   DECLARE @vssRev VARCHAR(30)
   DECLARE @RevStamp  VARCHAR(30)
   SELECT @VSSRev = '$Revision: 6 $'
   SELECT @RevStamp = REPLACE (@VSSRev, 'Revision:', '')
   SELECT @RevStamp = RTRIM(LTRIM(REPLACE (@RevStamp, '$', '')))
   EXEC pStampVersion 'pLoadFundLoadValidation', @RevStamp
END

GO

------------------------------------------------------------------------------
--- $Log: /Database/SSIS/Fund Loads/Validation/pLoadFundLoadValidation.sql $
-- 
-- 6     4/05/10 8:22a Psingleton
-- FundComposition:  Removed refrences to older composition items.
-- Reviewed by RM.
-- 
-- 5     12/08/09 2:31p Rmarsan
-- FlexFunds:  Changed to get investment universe from vActiveInvestment,
-- to get Newkirk Fund ID from teInvestment and to honder various provider
-- preferences.  Reviewed by SP.
-- 
-- 4     5/20/09 2:15p Rmarsan
-- Added FundManagment.ManagementStyleType &
-- AppSupportStyleBox.StyleGridMask.  Chagned Prints to Raiserror No Wait.
-- Added a lot of ISNULL logic. Reviewed by DB.
-- 
-- 3     5/14/09 2:01p Rmarsan
-- Lots of cleanup and a number of fixes.  Reviewed by DB.
-- 
-- 2     5/01/09 10:46a Rmarsan
-- PIP 2: Move Treynor Ratio columns to teFundMetricMPT from
-- teFundMetricOtherRisk.  Corrected hard-coded years to use supplied
-- Reporting As Of Date (@AsOfDate).  Added a bunch of NULL -> 0
-- conversions.  Reviewed by DB.
-- 
-- 1     11/18/08 2:21p Rmarsan
-- Replaced multiple DataValidation scripts with use of single SP
-- (pLoadFundLoadValidation).
