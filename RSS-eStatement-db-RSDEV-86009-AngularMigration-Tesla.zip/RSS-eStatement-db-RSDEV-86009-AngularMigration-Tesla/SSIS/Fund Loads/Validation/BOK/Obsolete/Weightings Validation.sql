USE Investment

DECLARE @InvestmentID UNIQUEIDENTIFIER
DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ModifiedByPartyID UNIQUEIDENTIFIER
DECLARE @TempFundPartID UNIQUEIDENTIFIER
DECLARE @TempWeightingID UNIQUEIDENTIFIER

DECLARE @AllocFundPartID UNIQUEIDENTIFIER
DECLARE @AllocWeightingID UNIQUEIDENTIFIER

DECLARE @HoldFundPartID UNIQUEIDENTIFIER
DECLARE @HoldWeightingID UNIQUEIDENTIFIER

DECLARE @DiversFundPartID UNIQUEIDENTIFIER
DECLARE @DiversWeightingID UNIQUEIDENTIFIER

SET @InvestmentID = '9F241C5B-1408-44DF-9ECC-08FB180DE1AF'
SET @ReportingLevelID = 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B'
SET @ModifiedByPartyID = 'EE106417-FA0D-4BFE-B341-D60D4BCFC22E'

SET @AllocFundPartID = 'D7DC0986-D22F-423B-8359-9420CD9B76D3'
SET @HoldFundPartID = '5EB26E37-AB42-4F98-90E8-954ECBF8893D'
SET @DiversFundPartID = '4FA818AA-E8F9-4BB6-92E2-0070E33C3BC4'

SET @AllocWeightingID = '62EF504E-7A83-4E23-940E-D6F3B1EDEC49'
SET @HoldWeightingID = '83B04F6B-3C06-4B3D-801E-C6701E119ABF'
SET @DiversWeightingID = 'D2F5F1F9-AF10-47E3-A3A2-715E80F11962'

EXEC pFundPartInsUpd @InvestmentID, @ReportingLevelID, 6, @AllocFundPartID, @ModifiedByPartyID
EXEC pFundPartInsUpd @InvestmentID, @ReportingLevelID, 5, @HoldFundPartID, @ModifiedByPartyID
EXEC pFundPartInsUpd @InvestmentID, @ReportingLevelID, 8, @DiversFundPartID, @ModifiedByPartyID
	
INSERT INTO teWeightingDistribution( WeightingGroupID, WeightingTypeCD ) VALUES( @AllocWeightingID, 4 )
INSERT INTO teWeightingDistribution( WeightingGroupID, WeightingTypeCD ) VALUES( @HoldWeightingID, 4 )
INSERT INTO teWeightingDistribution( WeightingGroupID, WeightingTypeCD ) VALUES( @DiversWeightingID, 4 )

INSERT INTO teDistributionValue( WeightingGroupID, OrderNbr, Descrip, ValueDecimal ) VALUES( @AllocWeightingID, 1, 'Test Alloc Descrip', 5.2 )
INSERT INTO teDistributionValue( WeightingGroupID, OrderNbr, Descrip, ValueDecimal ) VALUES( @HoldWeightingID, 1, 'Test Hold Descrip', 6.3 )
INSERT INTO teDistributionValue( WeightingGroupID, OrderNbr, Descrip, ValueDecimal ) VALUES( @DiversWeightingID, 1, 'Test Divers Descrip', 7.4 )

INSERT INTO teFundAssetAllocation( FundPartID, WeightingGroupID, AsOfDate ) VALUES( @AllocFundPartID, @AllocWeightingID, '2008-07-31' )
INSERT INTO teFundHoldings( FundPartID, WeightingGroupID, AsOfDate ) VALUES( @HoldFundPartID, @HoldWeightingID, '2008-07-31' )
INSERT INTO teFundDiversification( FundPartID, WeightingGroupID, AsOfDate ) VALUES( @DiversFundPartID, @DiversWeightingID, '2008-07-31' )

-- Asset Allocation
SET @InvestmentID = '9DF2FE54-1556-4851-9889-099B25200077'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 6
)

SET @TempWeightingID = (
	SELECT WeightingGroupID
	FROM teFundAssetAllocation
	WHERE FundPartID = @TempFundPartID
)

UPDATE teDistributionValue
SET ValueDecimal = 26.18
WHERE WeightingGroupID = @TempWeightingID
	AND OrderNbr = 1
	
UPDATE teFundAssetAllocation
SET AsOfDate = '1999-01-31'
WHERE FundPartID = @TempFundPartID
	
SET @InvestmentID = 'E6D25C1B-1279-4EFB-B897-0AD407C5FC5F'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 6
)

EXEC pAssetAllocationDel @TempFundPartID

-- Holdings
SET @InvestmentID = '61956D3B-25B9-4F29-971B-0045D71C7EEB'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 5
)

SET @TempWeightingID = (
	SELECT WeightingGroupID
	FROM teFundHoldings
	WHERE FundPartID = @TempFundPartID
)

UPDATE teDistributionValue
SET ValueDecimal = 26.18
WHERE WeightingGroupID = @TempWeightingID
	AND OrderNbr = 1
	
UPDATE teFundHoldings
SET AsOfDate = '1999-01-31'
WHERE FundPartID = @TempFundPartID

	
SET @InvestmentID = '70430856-A022-4C01-848C-E3583C99E72A'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 5
)

EXEC pHoldingsDel @TempFundPartID

-- Diversification
SET @InvestmentID = '04B79FF8-5C93-4B57-B9CF-09042A22FA5E'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 8
)

SET @TempWeightingID = (
	SELECT WeightingGroupID
	FROM teFundDiversification
	WHERE FundPartID = @TempFundPartID
)

UPDATE teDistributionValue
SET ValueDecimal = 26.18
WHERE WeightingGroupID = @TempWeightingID
	AND OrderNbr = 1
	
UPDATE teFundDiversification
SET AsOfDate = '1999-01-31'
WHERE FundPartID = @TempFundPartID
	
SET @InvestmentID = '5738F6C2-5495-4FB5-91B1-B08892C76BC9'
SET @TempFundPartID = (
	SELECT FundPartID
	FROM teFundPart
	WHERE InvestmentID = @InvestmentID
		AND ReportingLevelID = @ReportingLevelID
		AND FundPartTypeCD = 8
)

EXEC pDiversificationDel @TempFundPartID
--
--
--SELECT FundPartID, FundPartTypeCD
--	FROM teFundPart
--	WHERE InvestmentID = '04B79FF8-5C93-4B57-B9CF-09042A22FA5E'
--		AND 
--		ReportingLevelID = 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B'
--		AND FundPartTypeCD = 8
--		select InvestmentID from teFUndpart where FundPartID = 'C3176F24-AD8C-4F07-845F-02CD2188CEDA'
		
--select TOP 2 InvestmentID
--FROM __mstar_update_validation
--WHERE 
--	( hold1per <> 0.00
--		OR hold2per <> 0.00
--		OR hold3per <> 0.00
--		OR hold4per <> 0.00
--		OR hold5per <> 0.00
--		OR hold6per <> 0.00
--		OR hold7per <> 0.00
--		OR hold8per <> 0.00
--		OR hold9per <> 0.00
--		OR hold10per <> 0.00
--	) AND 
--	( alloc1per <> 0.00
--		OR alloc2per <> 0.00
--		OR alloc3per <> 0.00
--		OR alloc4per <> 0.00
--		OR alloc5per <> 0.00
--		OR alloc6per <> 0.00
--		OR alloc7per <> 0.00
--		OR alloc8per <> 0.00
--		OR alloc9per <> 0.00
--		OR alloc10per <> 0.00
--	) AND 
--	( divers1per <> 0.00
--		OR divers2per <> 0.00
--		OR divers3per <> 0.00
--		OR divers4per <> 0.00
--		OR divers5per <> 0.00
--		OR divers6per <> 0.00
--		OR divers7per <> 0.00
--		OR divers8per <> 0.00
--		OR divers9per <> 0.00
--		OR divers10per <> 0.00
--	)
--
--exec pImportCommonFundAssets 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B', 'EE106417-FA0D-4BFE-B341-D60D4BCFC22E'
--exec pImportCommonFundHoldings 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B', 'EE106417-FA0D-4BFE-B341-D60D4BCFC22E'
--exec pImportCommonFundDiversification 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B', 'EE106417-FA0D-4BFE-B341-D60D4BCFC22E'

-- select * from __mstar_update_validation order by icdino where investmentID = 'AE68D2C1-C9CA-48D0-83FB-00749E7186E4'
--select * 
--from teFundPart 
--where InvestmentID = '9F241C5B-1408-44DF-9ECC-08FB180DE1AF' 
--	AND ReportingLevelID = 'EBEED33E-0DCE-464C-B355-6EBE559BBE1B'
--	AND FundPartTypeCD IN (5,6,8)
--	
--select * from teFundHoldings where FundPartID = 'D560F651-C376-445B-89BB-D514F6C88486'
--select * from teDistributionValue where WeightingGroupID = 'EB6D94C1-FD64-48E2-829C-FE34DF81FFFF'
--
--select TOP 1 InvestmentID
--from __mstar_update_validation 
--where hold1 = ''
--	AND alloc1 = ''
--	AND divers1 = ''
		
