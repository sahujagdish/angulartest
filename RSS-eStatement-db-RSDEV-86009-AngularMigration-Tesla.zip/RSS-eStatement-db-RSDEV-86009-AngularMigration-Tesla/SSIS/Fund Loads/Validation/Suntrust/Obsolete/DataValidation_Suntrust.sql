USE Investment

DECLARE @ReportingLevelID UNIQUEIDENTIFIER
DECLARE @ReportingLevelAsOfDateID INT
DECLARE @CurrentAsOfDate DATETIME
DECLARE @NewkirkID UNIQUEIDENTIFIER

SET @CurrentAsOfDate = '2008-09-30'

SET @ReportingLevelID = 'F9138720-39B5-4DD5-8244-6741C8F3FE50'
SET @NewkirkID = '636F6D6D-756E-696B-7370-617274796964'
SET @ReportingLevelAsOfDateID = (
	SELECT ReportingLevelAsOfDateID
	FROM teReportingLevelAsOfDate
	WHERE ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
      AND AsOfDate = @CurrentAsOfDate
)

--select * from teReportingLevelAsOfDate WHERE ReportingLevelID = 'F9138720-39B5-4DD5-8244-6741C8F3FE50' AND AsOfDate = '2008-08-31'

TRUNCATE TABLE __mstar_update_validation 


PRINT 'Table Insert'
INSERT INTO __mstar_update_validation( InvestmentID, ReportingLevelID, ReportingLevelAsOfDateID )
SELECT
	PYI.InvestmentID,
	@ReportingLevelID,
	@ReportingLevelAsOfDateID
FROM tePartyInvestment PYI
WHERE PYI.PartyID = @ReportingLevelID
	AND (PYI.ActiveEndDttm IS NULL OR PYI.ActiveEndDttm > GETDATE())
	

-- Reporter Fund Identifier
PRINT 'Reporter Fund Identifier'
UPDATE M
	SET icdino = CONVERT( char(5), RFI.Identifier )
FROM __mstar_update_validation M
LEFT JOIN teReporterFundIdentifier RFI
	ON M.InvestmentID = RFI.InvestmentID
		AND RFI.ReportingLevelID = @ReportingLevelID
		AND ReporterKeyNameCD = 4


-- Benchno
PRINT 'Benchno'
UPDATE M
SET benchno = CONVERT( decimal(6,0) , RFI.Identifier )
FROM __mstar_update_validation M
JOIN teInvestmentBenchmark IB
	ON M.InvestmentID = IB.InvestmentID
		AND IB.ReportingLevelID = @ReportingLevelID
JOIN teReporterFundIdentifier RFI
	ON RFI.InvestmentID = IB.BmkInvestmentID
		AND RFI.ReportingLevelID = @NewkirkID
		AND RFI.ReporterKeyNameCD = 8


--ReportingLevelAsOfDate
PRINT 'ReportingLevelAsOfDate'
UPDATE M
SET portasof = R.AsOfDate
FROM __mstar_update_validation M
JOIN teReportingLevelAsOfDate R
	ON M.ReportingLevelAsOfDateID = R.ReportingLevelAsOfDateID
		

-- Investment
PRINT 'Investment'
UPDATE M
	SET commonname = I.CommonName
FROM __mstar_update_validation M
JOIN teInvestment I
	ON M.InvestmentID = I.InvestmentID

-- Style Group
PRINT 'Style Group'
UPDATE M
SET Category = CONVERT( char(39), SG.Descrip),
	Cat_id = ''
FROM __mstar_update_validation M
JOIN teInvestmentStyleGroup ISG
	ON M.InvestmentID = ISG.InvestmentId
JOIN teStyleGroup SG
	ON SG.StyleGroupID = ISG.StyleGroupID
		AND SG.ReportingLevelID = @ReportingLevelID

	

-- Basic Fund Info	
PRINT 'Basic Fund Info'
UPDATE M 
SET Ticker = FI.Ticker,
	cusip = FI.Cusip,
	Inception = FI.ShareClassInceptionDate,
	Inception2 = FI.FundInceptionDate,
	FundName = SUBSTRING(FN.NamePrinted,1,74),
	sp_name = FN.NamePrintedShort,
	Objective = FIP.ObjectiveStatement
FROM __mstar_update_validation M
JOIN teFundPart FP_BASIC
	ON M.InvestmentID = FP_BASIC.InvestmentId
		AND FP_BASIC.ReportingLevelID = @ReportingLevelID
		AND FP_BASIC.FundPartTypeCD = 1
LEFT JOIN teFundName FN
	ON FN.FundPartID = FP_BASIC.FundPartID
		AND FN.LocaleCD = 1033
LEFT JOIN teFundInfo FI
	ON FI.FundPartID = FP_BASIC.FundPartID
LEFT JOIN teFundInfoPolicy FIP
	ON FP_BASIC.FundPartID = FIP.FundPartID
		AND FIP.LocaleCD = 1033	


-- Asset Group
PRINT 'Asset Group'
UPDATE M
SET AssetClass = AGD.Descrip
FROM __mstar_update_validation M
JOIN teInvestmentAssetGroup IAG
	ON IAG.InvestmentID = M.InvestmentID
JOIN teAssetGroup AG
	ON IAG.AssetGroupID = AG.AssetGroupID
		AND AG.ReportingLevelID = @ReportingLevelId
JOIN teAssetGroupDescrip AGD
	ON AGD.AssetGroupID = AG.AssetGroupID
		AND AGD.LocaleCD = 1033
	
-- Performance
PRINT 'Performance'
UPDATE M 
SET 
	yld7day = 
		CASE
			WHEN Y7.PerformancePct IS NULL THEN -999.00
			ELSE Y7.PerformancePct
		END,
	eff7day = 
		CASE
			WHEN E7.PerformancePct IS NULL THEN -999.00
			ELSE E7.PerformancePct
		END,
	yld30day = 
		CASE
			WHEN Y30.PerformancePct IS NULL THEN -999.00
			ELSE Y30.PerformancePct
		END,
	mo1totret = 
		CASE
			WHEN MO1.PerformancePct IS NULL THEN -999.00
			ELSE MO1.PerformancePct
		END,
	mo3totret = 
		CASE
			WHEN MO3.PerformancePct IS NULL THEN -999.00
			ELSE MO3.PerformancePct
		END,
	yr1totret = 
		CASE
			WHEN Y1.PerformancePct IS NULL THEN -999.00
			ELSE Y1.PerformancePct
		END,
	yr3annret = 
		CASE
			WHEN Y3.PerformancePct IS NULL THEN -999.00
			ELSE Y3.PerformancePct
		END,
	yr5annret = 
		CASE
			WHEN Y5.PerformancePct IS NULL THEN -999.00
			ELSE Y5.PerformancePct
		END,
	yr10annret = 
		CASE
			WHEN Y10.PerformancePct IS NULL THEN -999.00
			ELSE Y10.PerformancePct
		END,
	ytdtotret = 
		CASE
			WHEN TOT.PerformancePct IS NULL THEN -999.00
			ELSE TOT.PerformancePct
		END,
	inceptret = 
		CASE
			WHEN INC.PerformancePct IS NULL THEN -999.00
			ELSE INC.PerformancePct
		END,
	closing = 
		CASE
			WHEN C.PerformancePct IS NULL THEN -999.00
			ELSE C.PerformancePct
		END,
	high52wk = 
		CASE
			WHEN H.PerformancePct IS NULL THEN -999.00
			ELSE H.PerformancePct
		END,
	low52wk = 
		CASE
			WHEN L.PerformancePct IS NULL THEN -999.00
			ELSE L.PerformancePct
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.FundPartTypeCD = 16
		AND FP.ReportingLevelID = @ReportingLevelID
LEFT JOIN teFundPerformance Y7
	ON Y7.FundPartID = FP.FundPartID
		AND Y7.PerformanceTermTypeCD = 1
		AND Y7.PerformanceTypeCD = 3
LEFT JOIN teFundPerformance E7
	ON E7.FundPartID = Y7.FundPartID
		AND E7.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND E7.PerformanceTermTypeCD = 2
		AND E7.PerformanceTypeCD = 3
LEFT JOIN teFundPerformance Y30
	ON Y30.FundPartID = Y7.FundPartID
		AND Y30.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND Y30.PerformanceTermTypeCD = 3
		AND Y30.PerformanceTypeCD = 3
LEFT JOIN teFundPerformance MO1
	ON MO1.FundPartID = Y7.FundPartID
		AND MO1.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND MO1.PerformanceTermTypeCD = 4
		AND MO1.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance MO3
	ON MO3.FundPartID = Y7.FundPartID
		AND MO3.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND MO3.PerformanceTermTypeCD = 5
		AND MO3.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y1
	ON Y1.FundPartID = Y7.FundPartID
		AND Y1.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND Y1.PerformanceTermTypeCD = 6
		AND MO3.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance Y3
	ON Y3.FundPartID = Y7.FundPartID
		AND Y3.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND Y3.PerformanceTermTypeCD = 7
		AND Y3.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y5
	ON Y5.FundPartID = Y7.FundPartID
		AND Y5.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND Y5.PerformanceTermTypeCD = 8
		AND Y5.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance Y10
	ON Y10.FundPartID = Y7.FundPartID
		AND Y10.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND Y10.PerformanceTermTypeCD = 9
		AND Y10.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance TOT
	ON TOT.FundPartID = Y7.FundPartID
		AND TOT.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND TOT.PerformanceTermTypeCD = 10
		AND TOT.PerformanceTypeCD = 2
LEFT JOIN teFundPerformance INC 
	ON INC.FundPartID = Y7.FundPartID
		AND INC.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND INC.PerformanceTermTypeCD = 11
		AND INC.PerformanceTypeCD = 1
LEFT JOIN teFundPerformance C
	ON C.FundPartID = Y7.FundPartID
		AND C.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND C.PerformanceTermTypeCD = 14
		AND C.PerformanceTypeCD = 4
LEFT JOIN teFundPerformance H 
	ON H.FundPartID = Y7.FundPartID
		AND H.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND H.PerformanceTermTypeCD = 15
		AND H.PerformanceTypeCD = 4
LEFT JOIN teFundPerformance L
	ON L.FundPartID = Y7.FundPartID
		AND L.ReportingLevelAsOfDateID = Y7.ReportingLevelAsOfDateID
		AND L.PerformanceTermTypeCD = 16
		AND L.PerformanceTypeCD = 4
WHERE Y7.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
	

-- Annual Returns
PRINT 'Annual Returns'
UPDATE M
SET Yr1 = 2007,
	Annret1 = 
		CASE
			WHEN Y1.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y1.AnnualReturnPct
		END,
	Yr2 = 2006,
	Annret2 = 
		CASE
			WHEN Y2.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y2.AnnualReturnPct
		END,
	Yr3 = 2005,
	Annret3 = 
		CASE
			WHEN Y3.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y3.AnnualReturnPct
		END,
	Yr4 = 2004,
	Annret4 = 
		CASE
			WHEN Y4.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y4.AnnualReturnPct
		END,
	Yr5 = 2003,
	Annret5 = 
		CASE
			WHEN Y5.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y5.AnnualReturnPct
		END,
	Yr6 = 2002,
	Annret6 = 
		CASE
			WHEN Y6.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y6.AnnualReturnPct
		END,
	Yr7 = 2001,
	Annret7 = 
		CASE
			WHEN Y7.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y7.AnnualReturnPct
		END,
	Yr8 = 2000,
	Annret8 = 
		CASE
			WHEN Y8.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y8.AnnualReturnPct
		END,
	Yr9 = 1999,
	Annret9 = 
		CASE
			WHEN Y9.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y9.AnnualReturnPct
		END,
	Yr10 = 1998,
	Annret10 = 
		CASE
			WHEN Y10.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y10.AnnualReturnPct
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 14
LEFT JOIN teAnnualReturn Y1
	ON FP.FundPartID = Y1.FundPartID
		AND Y1.CalendarTypeCD = 1
		AND Y1.ReturnYear = '2007-12-31'
LEFT JOIN teAnnualReturn Y2
	ON FP.FundPartID = Y2.FundPartID
		AND Y2.CalendarTypeCD = 1
		AND Y2.ReturnYear = '2006-12-31'
LEFT JOIN teAnnualReturn Y3
	ON FP.FundPartID = Y3.FundPartID
		AND Y3.CalendarTypeCD = 1
		AND Y3.ReturnYear = '2005-12-31'
LEFT JOIN teAnnualReturn Y4
	ON FP.FundPartID = Y4.FundPartID
		AND Y4.CalendarTypeCD = 1
		AND Y4.ReturnYear = '2004-12-31'
LEFT JOIN teAnnualReturn Y5
	ON FP.FundPartID = Y5.FundPartID
		AND Y5.CalendarTypeCD = 1
		AND Y5.ReturnYear = '2003-12-31'
LEFT JOIN teAnnualReturn Y6
	ON FP.FundPartID = Y6.FundPartID
		AND Y6.CalendarTypeCD = 1
		AND Y6.ReturnYear = '2002-12-31'
LEFT JOIN teAnnualReturn Y7
	ON FP.FundPartID = Y7.FundPartID
		AND Y7.CalendarTypeCD = 1
		AND Y7.ReturnYear = '2001-12-31'
LEFT JOIN teAnnualReturn Y8
	ON FP.FundPartID = Y8.FundPartID
		AND Y8.CalendarTypeCD = 1
		AND Y8.ReturnYear = '2000-12-31'
LEFT JOIN teAnnualReturn Y9
	ON FP.FundPartID = Y9.FundPartID
		AND Y9.CalendarTypeCD = 1
		AND Y9.ReturnYear = '1999-12-31'
LEFT JOIN teAnnualReturn Y10
	ON FP.FundPartID = Y10.FundPartID
		AND Y10.CalendarTypeCD = 1
		AND Y10.ReturnYear = '1998-12-31'


-- Past Returns
PRINT 'Past Returns'
UPDATE M
SET Past1date = DATEADD( year, 0, @CurrentAsOfDate ),
	Past1 = 
		CASE 
			WHEN Y1.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y1.AnnualReturnPct
		END,
	Past2date = DATEADD( year, -1, @CurrentAsOfDate ),
	Past2 = 
		CASE 
			WHEN Y2.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y2.AnnualReturnPct
		END,
	Past3date = DATEADD( year, -2, @CurrentAsOfDate ),
	Past3 = 
		CASE 
			WHEN Y3.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y3.AnnualReturnPct
		END,
	Past4date = DATEADD( year, -3, @CurrentAsOfDate ),
	Past4 = 
		CASE 
			WHEN Y4.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y4.AnnualReturnPct
		END,
	Past5date = DATEADD( year, -4, @CurrentAsOfDate ),
	Past5 = 
		CASE 
			WHEN Y5.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y5.AnnualReturnPct
		END,
	Past6date = DATEADD( year, -5, @CurrentAsOfDate ),
	Past6 = 
		CASE 
			WHEN Y6.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y6.AnnualReturnPct
		END,
	Past7date = DATEADD( year, -6, @CurrentAsOfDate ),
	Past7 = 
		CASE 
			WHEN Y7.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y7.AnnualReturnPct
		END,
	Past8date = DATEADD( year, -7, @CurrentAsOfDate ),
	Past8 = 
		CASE 
			WHEN Y8.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y8.AnnualReturnPct
		END,
	Past9date = DATEADD( year, -8, @CurrentAsOfDate ),
	Past9 = 
		CASE 
			WHEN Y9.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y9.AnnualReturnPct
		END,
	Past10date = DATEADD( year, -9, @CurrentAsOfDate ),
	Past10 = 
		CASE 
			WHEN Y10.AnnualReturnPct IS NULL THEN -999.00
			ELSE Y10.AnnualReturnPct
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 14
LEFT JOIN teAnnualReturn Y1
	ON FP.FundPartID = Y1.FundPartID
		AND Y1.CalendarTypeCD = 2
		AND Y1.ReturnYear = DATEADD( year, 0, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y2
	ON FP.FundPartID = Y2.FundPartID
		AND Y2.CalendarTypeCD = 2
		AND Y2.ReturnYear = DATEADD( year, -1, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y3
	ON FP.FundPartID = Y3.FundPartID
		AND Y3.CalendarTypeCD = 2
		AND Y3.ReturnYear = DATEADD( year, -2, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y4
	ON FP.FundPartID = Y4.FundPartID
		AND Y4.CalendarTypeCD = 2
		AND Y4.ReturnYear = DATEADD( year, -3, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y5
	ON FP.FundPartID = Y5.FundPartID
		AND Y5.CalendarTypeCD = 2
		AND Y5.ReturnYear = DATEADD( year, -4, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y6
	ON FP.FundPartID = Y6.FundPartID
		AND Y6.CalendarTypeCD = 2
		AND Y6.ReturnYear = DATEADD( year, -5, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y7
	ON FP.FundPartID = Y7.FundPartID
		AND Y7.CalendarTypeCD = 2
		AND Y7.ReturnYear = DATEADD( year, -6, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y8
	ON FP.FundPartID = Y8.FundPartID
		AND Y8.CalendarTypeCD = 2
		AND Y8.ReturnYear = DATEADD( year, -7, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y9
	ON FP.FundPartID = Y9.FundPartID
		AND Y9.CalendarTypeCD = 2
		AND Y9.ReturnYear = DATEADD( year, -8, @CurrentAsOfDate )
LEFT JOIN teAnnualReturn Y10
	ON FP.FundPartID = Y10.FundPartID
		AND Y10.CalendarTypeCD = 2
		AND Y10.ReturnYear = DATEADD( year, -9, @CurrentAsOfDate )


-- Fund Metric Other Risk
PRINT 'Fund Metric Other Risk'
UPDATE M
SET  
	Stddev3a = 
		CASE
			WHEN MOR.StandardDeviation3YrValue IS NULL THEN 0.00
			ELSE MOR.StandardDeviation3YrValue
		END,
	Stddev5a = 
		CASE
			WHEN MOR.StandardDeviation5YrValue IS NULL THEN 0.00
			ELSE MOR.StandardDeviation5YrValue
		END,
	Stddev10a = 
		CASE
			WHEN MOR.StandardDeviation10YrValue IS NULL THEN 0.00
			ELSE MOR.StandardDeviation10YrValue
		END,
	Sharpe3 = 
		CASE
			WHEN MOR.SharpeRatio3YrValue IS NULL THEN 0.00
			ELSE MOR.SharpeRatio3YrValue
		END,
	Sharpe5 = 
		CASE
			WHEN MOR.SharpeRatio5YrValue IS NULL THEN 0.00
			ELSE MOR.SharpeRatio5YrValue
		END,
	Sharpe10 = 
		CASE
			WHEN MOR.SharpeRatio10YrValue IS NULL THEN 0.00
			ELSE MOR.SharpeRatio10YrValue
		END,
	Sortino3 = 
		CASE
			WHEN MOR.SortinoRatio3YrValue IS NULL THEN 0.00
			ELSE MOR.SortinoRatio3YrValue
		END,
	Sortino5 = 
		CASE
			WHEN MOR.SortinoRatio5YrValue IS NULL THEN 0.00
			ELSE MOR.SortinoRatio5YrValue
		END,
	Sortino10 = 
		CASE
			WHEN MOR.SortinoRatio10YrValue IS NULL THEN 0.00
			ELSE MOR.SortinoRatio10YrValue
		END,
	Info3 = 
		CASE
			WHEN MOR.InformationRatio3YrValue IS NULL THEN 0.00
			ELSE MOR.InformationRatio3YrValue
		END,
	Info5 = 
		CASE
			WHEN MOR.InformationRatio5YrValue IS NULL THEN 0.00
			ELSE MOR.InformationRatio5YrValue
		END,
	Info10 = 
		CASE
			WHEN MOR.InformationRatio10YrValue IS NULL THEN 0.00
			ELSE MOR.InformationRatio10YrValue
		END,
	Treynor3 = 
		CASE
			WHEN MOR.TreynorRatio3YrValue IS NULL THEN 0.00
			ELSE MOR.TreynorRatio3YrValue
		END,
	Treybest3 = 
		CASE
			WHEN MOR.TreynorRatio3YrBestFitValue IS NULL THEN 0.00
			ELSE MOR.TreynorRatio3YrBestFitValue
		END,
	Treynor5 = 
		CASE
			WHEN MOR.TreynorRatio5YrValue IS NULL THEN 0.00
			ELSE MOR.TreynorRatio5YrValue
		END,
	Treynor10 = 
		CASE
			WHEN MOR.TreynorRatio10YrValue IS NULL THEN 0.00
			ELSE MOR.TreynorRatio10YrValue
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 21
JOIN teFundMetricOtherRisk MOR
	ON MOR.FundPartID = FP.FundPartID
		AND MOR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


-- Fund Metric MPT
PRINT 'Fund Metric MPT'
UPDATE M
SET 
	Rsquare3 = 
		CASE
			WHEN MPT.RSquare3YrValue IS NULL THEN 0.00
			ELSE MPT.RSquare3YrValue
		END,
	Rsqbest3 = 
		CASE
			WHEN MPT.RSquare3YrBestFitValue IS NULL THEN 0.00
			ELSE MPT.RSquare3YrBestFitValue
		END,
	Rsquare5 = 
		CASE
			WHEN MPT.RSquare5YrValue IS NULL THEN 0.00
			ELSE MPT.RSquare5YrValue
		END,
	Rsquare10 = 
		CASE
			WHEN MPT.RSquare10YrValue IS NULL THEN 0.00
			ELSE MPT.RSquare10YrValue
		END,
	Beta3 = 
		CASE
			WHEN MPT.Beta3YrValue IS NULL THEN 0.00
			ELSE MPT.Beta3YrValue
		END,
	Betabest3 = 
		CASE
			WHEN MPT.Beta3YrBestFitValue IS NULL THEN 0.00
			ELSE MPT.Beta3YrBestFitValue
		END,
	Beta5 = 
		CASE
			WHEN MPT.Beta5YrValue IS NULL THEN 0.00
			ELSE MPT.Beta5YrValue
		END,
	Beta10 = 
		CASE
			WHEN MPT.Beta10YrValue IS NULL THEN 0.00
			ELSE MPT.Beta10YrValue
		END,
	Alpha3 = 
		CASE
			WHEN MPT.Alpha3YrValue IS NULL THEN 0.00
			ELSE MPT.Alpha3YrValue
		END,
	Alphabest3 = 
		CASE
			WHEN MPT.Alpha3YrBestFitValue IS NULL THEN 0.00
			ELSE MPT.Alpha3YrBestFitValue
		END,
	Alpha5 = 
		CASE
			WHEN MPT.Alpha5YrValue IS NULL THEN 0.00
			ELSE MPT.Alpha5YrValue
		END,
	Alpha10 = 
		CASE
			WHEN MPT.Alpha10YrValue IS NULL THEN 0.00
			ELSE MPT.Alpha10YrValue
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 19
JOIN teFundMetricMPT MPT
	ON MPT.FundPartID = FP.FundPartID
		AND MPT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

-- Fund Metric MorningStar
PRINT 'Fund Metric MorningStar'
UPDATE M
SET  
	Rating3 = 
		CASE
			WHEN MOR.Morningstar3YrRating IS NULL THEN 0.00
			ELSE MOR.Morningstar3YrRating
		END,
	Riskrate3 = 
		CASE
			WHEN MOR.Morningstar3YrRisk IS NULL THEN 0.00
			ELSE MOR.Morningstar3YrRisk
		END,
	Perfrate3 = 
		CASE
			WHEN MOR.Morningstar3YrReturn IS NULL THEN 0.00
			ELSE MOR.Morningstar3YrReturn
		END,
	Rating5 = 
		CASE
			WHEN MOR.Morningstar5YrRating IS NULL THEN 0.00
			ELSE MOR.Morningstar5YrRating
		END,
	Riskrate5 = 
		CASE
			WHEN MOR.Morningstar5YrRisk IS NULL THEN 0.00
			ELSE MOR.Morningstar5YrRisk
		END,
	Perfrate5 = 
		CASE
			WHEN MOR.Morningstar5YrReturn IS NULL THEN 0.00
			ELSE MOR.Morningstar5YrReturn
		END,
	Rating10 = 
		CASE
			WHEN MOR.Morningstar10YrRating IS NULL THEN 0.00
			ELSE MOR.Morningstar10YrRating
		END,
	Riskrate10 = 
		CASE
			WHEN MOR.Morningstar10YrRisk IS NULL THEN 0.00
			ELSE MOR.Morningstar10YrRisk
		END,
	Perfrate10 = 
		CASE
			WHEN MOR.Morningstar10YrReturn IS NULL THEN 0.00
			ELSE MOR.Morningstar10YrReturn
		END
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 20
JOIN teFundMetricMorningstar MOR
	ON MOR.FundPartID = FP.FundPartID
		AND MOR.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


-- Fund Fee
PRINT 'Fund Fee'
UPDATE M
SET  
	Redemption = FEE.RedemptionFeePct,
	Redeemdays = FEE.RedemptionPeriod,
	expratio = FEE.ExpenseRatioGrossValue,
	expnet = FEE.ExpenseRatioNetValue,
	expdate = FEE.ExpenseDate,
	Fee12b1 = FEE.Fee12b1,
	mgtexpense = FEE.Mgmt_Expense
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 24
JOIN teFundFee FEE
	ON FEE.FundPartID = FP.FundPartID
		AND FEE.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


-- Fund Metric Portfolio Statistic
PRINT 'Fund Metric Portfolio Statistic'
UPDATE M
SET
	nav = P.NetAssetValue,
	totass = P.TotalAssets,
	mkt_cap = P.AvgMarketCap,
	turnover = P.TurnoverRatioValue,
	no_secs = P.TotalHoldings,
	pct_top10 = P.HoldingsPctInTopTen
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 22
JOIN teFundMetricPortfolioStatistic P
	ON P.FundPartID = FP.FundPartID
		AND P.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

-- Fund Management
PRINT 'Fund Management'
UPDATE M
SET 
	Manager = MGT.ManagerName,
	Mgrsince = MGT.ManagerStart,
	website = MGT.WebSite,
	phone = MGT.PhoneNbr,
	mgryrs = MGT.ManagerTenure
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 11
JOIN teFundManagement MGT
	ON MGT.FundPartID = FP.FundPartID
		AND MGT.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID


-- Fixed Income Statistic
PRINT 'Fixed Income Statistic'
UPDATE M
SET 
	mat_days = F.WeightedAvgMaturityDays,
	maturity = F.WeightedAvgMaturityYears,
	duration = F.DurationYears
FROM __mstar_update_validation M
JOIN teFundPart FP
	ON M.InvestmentID = FP.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 23
JOIN teFundMetricFixedIncomeStatistic F
	ON F.FundPartID = FP.FundPartID
		AND F.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

-- Holdings
UPDATE M
SET 
	holdasof = 
		CASE 
			WHEN FH.AsOfDate IS NULL THEN '1899-12-30'
			ELSE FH.AsOfDate
		END,
	holdtot = 
		CASE 
			WHEN WD.valueTotal IS NULL THEN 0.00
			ELSE WD.valueTotal
		END,		
	hold1 = 
		CASE
			WHEN DV1.Descrip IS NULL THEN ''
			ELSE DV1.Descrip
		END,
	hold1per = 
		CASE
			WHEN DV1.ValueDecimal IS NULL THEN 0.00
			ELSE DV1.ValueDecimal
		END,
	hold2 = 
		CASE
			WHEN DV2.Descrip IS NULL THEN ''
			ELSE DV2.Descrip
		END,
	hold2per = 
		CASE
			WHEN DV2.ValueDecimal IS NULL THEN 0.00
			ELSE DV2.ValueDecimal
		END,
	hold3 = 
		CASE
			WHEN DV3.Descrip IS NULL THEN ''
			ELSE DV3.Descrip
		END,
	hold3per = 
		CASE
			WHEN DV3.ValueDecimal IS NULL THEN 0.00
			ELSE DV3.ValueDecimal
		END,
	hold4 = 
		CASE
			WHEN DV4.Descrip IS NULL THEN ''
			ELSE DV4.Descrip
		END,
	hold4per = 
		CASE
			WHEN DV4.ValueDecimal IS NULL THEN 0.00
			ELSE DV4.ValueDecimal
		END,
	hold5 = 
		CASE
			WHEN DV5.Descrip IS NULL THEN ''
			ELSE DV5.Descrip
		END,
	hold5per = 
		CASE
			WHEN DV5.ValueDecimal IS NULL THEN 0.00
			ELSE DV5.ValueDecimal
		END,
	hold6 = 
		CASE
			WHEN DV6.Descrip IS NULL THEN ''
			ELSE DV6.Descrip
		END,
	hold6per = 
		CASE
			WHEN DV6.ValueDecimal IS NULL THEN 0.00
			ELSE DV6.ValueDecimal
		END,
	hold7 = 
		CASE
			WHEN DV7.Descrip IS NULL THEN ''
			ELSE DV7.Descrip
		END,
	hold7per = 
		CASE
			WHEN DV7.ValueDecimal IS NULL THEN 0.00
			ELSE DV7.ValueDecimal
		END,
	hold8 = 
		CASE
			WHEN DV8.Descrip IS NULL THEN ''
			ELSE DV8.Descrip
		END,
	hold8per = 
		CASE
			WHEN DV8.ValueDecimal IS NULL THEN 0.00
			ELSE DV8.ValueDecimal
		END,
	hold9 = 
		CASE
			WHEN DV9.Descrip IS NULL THEN ''
			ELSE DV9.Descrip
		END,
	hold9per = 
		CASE
			WHEN DV9.ValueDecimal IS NULL THEN 0.00
			ELSE DV9.ValueDecimal
		END,
	hold10 = 
		CASE
			WHEN DV10.Descrip IS NULL THEN ''
			ELSE DV10.Descrip
		END,
	hold10per = 
		CASE
			WHEN DV10.ValueDecimal IS NULL THEN 0.00
			ELSE DV10.ValueDecimal
		END
FROM __mstar_update_validation M
LEFT JOIN teFundPart FP
	ON FP.InvestmentID = M.InvestmentID
		AND FP.ReportingLevelID = @ReportingLevelID
		AND FP.FundPartTypeCD = 5
LEFT JOIN teFundHoldings FH
	ON FH.FundPartID = FP.FundPartID
LEFT JOIN teWeightingDistribution WD
	ON WD.WeightingGroupID = FH.WeightingGroupID
LEFT JOIN teDistributionValue DV1
	ON DV1.WeightingGroupID = WD.WeightingGroupID
		AND DV1.OrderNbr = 1
LEFT JOIN teDistributionValue DV2
	ON DV2.WeightingGroupID = WD.WeightingGroupID
		AND DV2.OrderNbr = 2
LEFT JOIN teDistributionValue DV3
	ON DV3.WeightingGroupID = WD.WeightingGroupID
		AND DV3.OrderNbr = 3
LEFT JOIN teDistributionValue DV4
	ON DV4.WeightingGroupID = WD.WeightingGroupID
		AND DV4.OrderNbr = 4
LEFT JOIN teDistributionValue DV5
	ON DV5.WeightingGroupID = WD.WeightingGroupID
		AND DV5.OrderNbr = 5
LEFT JOIN teDistributionValue DV6
	ON DV6.WeightingGroupID = WD.WeightingGroupID
		AND DV6.OrderNbr = 6
LEFT JOIN teDistributionValue DV7
	ON DV7.WeightingGroupID = WD.WeightingGroupID
		AND DV7.OrderNbr = 7
LEFT JOIN teDistributionValue DV8
	ON DV8.WeightingGroupID = WD.WeightingGroupID
		AND DV8.OrderNbr = 8
LEFT JOIN teDistributionValue DV9
	ON DV9.WeightingGroupID = WD.WeightingGroupID
		AND DV9.OrderNbr = 9
LEFT JOIN teDistributionValue DV10
	ON DV10.WeightingGroupID = WD.WeightingGroupID
		AND DV10.OrderNbr = 10