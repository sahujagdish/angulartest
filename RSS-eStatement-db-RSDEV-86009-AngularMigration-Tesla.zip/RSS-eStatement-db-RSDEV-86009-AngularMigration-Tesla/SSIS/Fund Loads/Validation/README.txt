USAGE
-----
1. (once) Run "Create __mstar_update_validation.sql"
2. (once) Run "pLoadFundLoadValidation.sql"
3. Run the fund load of your choice
4. EXEC pLoadFundLoadValidation passing in ReportingLevelID & As Of Date
7. Modify the ValidationSelectQuery to run it against the InvestmentStaging..mstar_update_pip table
8. Run the ValidationSelectQuery and save the output to a PRE file
5. Modify the ValidationSelectQuery to run it against the Investment..__mstar_update_validation table
6. Run the ValidationSelectQuery and save the output to a POST file
9. Compare the PRE & POST files

DETAILS
-------

The stored procedure pLoadFundLoadValidation will gather data back out of the Investment Database and put it in the __mstar_update_validation table.  The Scripts starting with DataValidation are now obsolete.  When they were used, the @CurrentAsOfDate variable needed to be set correctly depending on the date to be tested.

Scripts starting with ValidationSelectQuery will select from either the Investment..__mstar_update_validation table or the InvestmentStaging..mstar_update_pip table. There are commented FROM clauses at the bottom of the file which will do either one. Currently, they join from __mstar_update_validation to mstar_update_pip because of the missing investments that we had. Remove the JOIN to get a full list.

Depending on the comparison program used, the full field list is too long to usefully compare, so the comma (,) is comented out after Past10Date to allow all the succeeding fields to be commented and the select statement broken up into two different outputs.

