USE Statements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pStatementInvestmentPerformanceInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pStatementInvestmentPerformanceInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pStatementInvestmentPerformanceInsUpd]
	@ID INT OUTPUT,
	@ProviderId UNIQUEIDENTIFIER,
	@FundName VARCHAR(100),
	@CUSIP VARCHAR(50),
	@DAY7 DECIMAL(12,4 ) = NULL,
    @Month1 DECIMAL(12,4 ) = NULL,
	@QTR DECIMAL(12,4 ) = NULL,
	@YR1 DECIMAL(12,4 ) = NULL,
	@YR3 DECIMAL(12,4 ) = NULL,
	@YR5 DECIMAL(12,4 ) = NULL,
	@YR10 DECIMAL(12,4 ) = NULL,
	@Inception DECIMAL(12,4 ) = NULL,
    @YTD DECIMAL(12,4) = NULL,
	@AsOfDate DATETIME,
	@Inc_Date DATETIME = NULL,
	@Class VARCHAR(50) = NULL,
	@Ticker VARCHAR(50) = NULL,
	@Ref1 DECIMAL(12,4 ) = NULL,
	@Expratio DECIMAL(12,4 ) = NULL,
	@Expdate DATETIME = NULL,
	@Perfsup VARCHAR(50) = NULL,
	@Redemption VARCHAR(50) = NULL,
	@Redeemdays SMALLINT = NULL,
	@Max_front DECIMAL(12,4 ) = NULL,
	@Max_defer DECIMAL(12,4 ) = NULL,
	@Website VARCHAR(100) = NULL,
	@Benchno INT = NULL,
    @NewkirkFundId CHAR(5) = NULL,
    @FixedActRate DECIMAL(12,4) = NULL,
	@Yield DECIMAL(12,4) = NULL,
	@YieldExp DECIMAL(12,4) = NULL,
	@VRUCode INT = NULL,
	@Risk INT = NULL
AS
      SET NOCOUNT ON

     BEGIN TRY
        --
        -- Update the existing record or insert a new one, as appropriate.
        --
     
        UPDATE Statements..teStatementInvestmentPerformance
            SET 
		        ProviderId = @ProviderId,
	            FundName = @FundName,
                CUSIP = @CUSIP,
	            DAY7 = @DAY7,
                Month1 = @Month1,
	            QTR = @QTR,
	            YR1 = @YR1,
	            YR3 = @YR3,
	            YR5 = @YR5,
	            YR10 = @YR10,
	            Inception = @Inception,
                YTD = @YTD,
	            AsOfDate = @AsOfDate,
	            Inc_Date = @Inc_Date,
	            Class = @Class,
	            Ticker = @Ticker,
	            Ref1 = @Ref1,
	            Expratio = @Expratio,
	            Expdate = @Expdate,
	            Perfsup = @Perfsup,
	            Redemption = @Redemption,
	            Redeemdays = @Redeemdays,
	            Max_front = @Max_front,
	            Max_defer = @Max_defer,
	            Website = @Website,
	            Benchno = @Benchno,
                NewkirkFundId = @NewkirkFundId,
                FixedActRate = @FixedActRate,
	            Yield = @Yield,
	            YieldExp = @YieldExp,
	            VRUCode = @VRUCode,
	            Risk = @Risk
            WHERE ProviderId = @ProviderId AND CUSIP = @CUSIP AND Ticker = @Ticker
            AND AsOfDate = @AsOfDate

        --
        -- Insert new record.
        --
        IF @@ROWCOUNT = 0
            INSERT INTO Statements..teStatementInvestmentPerformance (   
                ProviderId,
	            FundName,
                CUSIP,
	            DAY7,
	            QTR,
                Month1,
	            YR1,
	            YR3,
	            YR5,
	            YR10,
	            Inception,
                YTD,
	            AsOfDate,
	            Inc_Date,
	            Class,
	            Ticker,
	            Ref1,
	            Expratio,
	            Expdate,
	            Perfsup,
	            Redemption,
	            Redeemdays,
	            Max_front,
	            Max_defer,
	            Website,
	            Benchno,
                NewkirkFundId,
                FixedActRate,
	            Yield,
	            YieldExp,
	            VRUCode,
	            Risk
            )
            VALUES (
                @ProviderId,
	            @FundName,
                @CUSIP,
	            @DAY7,
                @Month1,
	            @QTR,
	            @YR1,
	            @YR3,
	            @YR5,
	            @YR10,
	            @Inception,
                @YTD,
	            @AsOfDate,
	            @Inc_Date,
	            @Class,
	            @Ticker,
	            @Ref1,
	            @Expratio,
	            @Expdate,
	            @Perfsup,
	            @Redemption,
	            @Redeemdays,
	            @Max_front,
	            @Max_defer,
	            @Website,
	            @Benchno,
                @NewkirkFundId,
                @FixedActRate,
	            @Yield,
	            @YieldExp,
	            @VRUCode,
	            @Risk
            )

        --SET @ID = SCOPE_IDENTITY()
        RETURN 0
    END TRY
    BEGIN CATCH
        -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000)
        DECLARE @ErrorSeverity INT
        DECLARE @ErrorState INT
        DECLARE @ErrorNumber INT

        SELECT
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE(),
            @ErrorNumber =  ERROR_NUMBER()

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )

        RETURN @ErrorNumber
    END CATCH

GO