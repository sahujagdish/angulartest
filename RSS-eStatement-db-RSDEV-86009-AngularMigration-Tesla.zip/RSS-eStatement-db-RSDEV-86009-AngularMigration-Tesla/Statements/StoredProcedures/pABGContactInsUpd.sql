USE Statements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pABGContactInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pABGContactInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pABGContactInsUpd]
	@ProviderId UNIQUEIDENTIFIER,
    @ExternalPlanId VARCHAR(40),
	@Web VARCHAR(205) NULL,
	@Phone VARCHAR(40) NULL,
	@Email VARCHAR(250) NULL,
	@IsShowModelLanguage BIT,
	@RebalanceFrequency VARCHAR (250) NULL,
	@IsChargeForRebalance BIT,
	@IsModelOnly BIT
AS
      SET NOCOUNT ON

     BEGIN TRY
        --
        -- Update the existing record or insert a new one, as appropriate.
        --
        UPDATE Statements..teABGContact
            SET 
		   	WEB = @Web,
	        Phone = @Phone,
	        Email = @Email,
	        IsShowModelLanguage = @IsShowModelLanguage,
	        RebalanceFrequency = @RebalanceFrequency,
	        IsChargeForRebalance = @IsChargeForRebalance,
	        IsModelOnly = @IsModelOnly
        WHERE ProviderId = @ProviderId
            AND ExternalPlanId = @ExternalPlanId

        --
        -- Insert new record.
        --
        IF @@ROWCOUNT = 0
            INSERT INTO Statements..teABGContact (   
                ProviderId,
                ExternalPlanId,
	            Web,
	            Phone,
	            Email,
	            IsShowModelLanguage,
	            RebalanceFrequency,
	            IsChargeForRebalance,
	            IsModelOnly
            )
            VALUES (
                @ProviderId,
                @ExternalPlanId,
	            @Web,
	            @Phone,
	            @Email,
	            @IsShowModelLanguage,
	            @RebalanceFrequency,
	            @IsChargeForRebalance,
	            @IsModelOnly
            )
            
        RETURN 0
    END TRY
    BEGIN CATCH
        -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000)
        DECLARE @ErrorSeverity INT
        DECLARE @ErrorState INT
        DECLARE @ErrorNumber INT

        SELECT
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE(),
            @ErrorNumber =  ERROR_NUMBER()

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )

        RETURN @ErrorNumber
    END CATCH

GO


--GRANT EXECUTE
--    ON pPlanMessageInsUpd
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pPlanMessageInsUpd BY CERTIFICATE certStatements
--	WITH PASSWORD = 'Mens confusa'
		
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pABGContactInsUpd.sql $', '$Revision: 1 $'
END

GO