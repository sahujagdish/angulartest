﻿USE Statements
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'pGetStatementsCustomPerformance')
	BEGIN
		DROP  PROCEDURE  pGetStatementsCustomPerformance
	END

GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.
CREATE PROCEDURE [dbo].[pGetStatementsCustomPerformance]
    @ProviderId UNIQUEIDENTIFIER,
	@AsOfDate DateTime
 AS

    SET NOCOUNT ON

    BEGIN TRY
        SELECT 
            CP.ID,
            CP.ProviderId,
            CP.FundName,
            CP.CUSIP,
            CP.DAY7,
            CP.Month1,
            CP.QTR,
            CP.YR1,
            CP.YR3,
            CP.YR5,
            CP.YR10,
            CP.Inception,
            CP.YTD,
            CP.AsOfDate,
            CP.Inc_Date,
            CP.Class,
            CP.Ticker,
            CP.Ref1,
            CP.Expratio,
            CP.Expdate,
            CP.Perfsup,
            CP.Redemption,
            CP.Redeemdays,
            CP.Max_front,
            CP.Max_defer,
            CP.Website,
            CP.Benchno,
            CP.NewkirkFundId
        FROM vStatementInvestmentPerformance CP
        WHERE CP.ProviderId = @ProviderId
            AND CP.AsOfDate = @AsOfDate
	
	END TRY
    BEGIN CATCH
       -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )
    END CATCH
   
GO

--GRANT EXECUTE
--    ON pAreAllJobsQueueItemsCompletedByOrderIDAndJobType
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pAreAllJobsQueueItemsCompletedByOrderIDAndJobType BY CERTIFICATE certMainOne2One
--	WITH PASSWORD = 'Mens confusa'

IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pGetStatementsCustomPerformance.sql $', '$Revision: 1 $'
END

GO
