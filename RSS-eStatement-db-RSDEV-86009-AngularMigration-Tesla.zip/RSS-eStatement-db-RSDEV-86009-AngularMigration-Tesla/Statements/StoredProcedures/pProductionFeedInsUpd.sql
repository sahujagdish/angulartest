USE Statements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pProductionFeedInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pProductionFeedInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pProductionFeedInsUpd]
	  @ProviderId UNIQUEIDENTIFIER,
      @DataFeedId UNIQUEIDENTIFIER,
      @FeedSourcePartyID UNIQUEIDENTIFIER,
      @AreAllFilesReceived BIT,
      @AreWaitingOnStatementTypeSS BIT,
      @StartDttm DATETIME,
      @IsProcessing BIT,

      @StatementGroupType TINYINT
AS
    SET NOCOUNT ON

    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT
	-- Track errors as you go. Only execute as long as no errors.
    DECLARE @intErr               INT
	--Signal to actually raise a formal error if first-time encountered.
    DECLARE @bitRaiseErr          BIT
    DECLARE @chrErrSup            VARCHAR(100)

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@TRANCOUNT
    SET @intErr               = @@ERROR
    SET @bitRaiseErr          = 0
    SET @chrErrSup            = ''

    --
    -- Procedure Variables
    --
    DECLARE @existingDataFeedID UNIQUEIDENTIFIER
    DECLARE @dtmNow                     DATETIME
    SET @existingDataFeedID = NULL
    SET @dtmNow                     = GETDATE()
    
    --
    -- PROCESSING
    --
    IF @intIncomingTranCount = 0
    BEGIN
      -- if there is no transaction already present,
      -- this proc must start one
      BEGIN TRANSACTION
      SET @intErr = @@ERROR
    END

    --
    --see if entry already exists
    --
    IF @intErr = 0
    BEGIN
       
        SELECT @existingDataFeedID = dataFeedID
            FROM Statements..teProductionFeed
            WHERE DataFeedID = @DataFeedID

        SET @intErr = @@ERROR
       
    END

	--
	-- Business Logic
	-- 

    IF @intErr = 0   -- input ok, insert.
    BEGIN
        IF @existingDataFeedID IS NOT NULL
        BEGIN
            UPDATE Statements..teProductionFeed
               SET 	AreAllFilesReceived = @AreAllFilesReceived,
                    AreWaitingOnStatementTypeSS = @AreWaitingOnStatementTypeSS,
					StartDttm = @StartDttm,
					IsProcessing = @IsProcessing,
                    StatementGroupType = @StatementGroupType
                    
             WHERE DataFeedId = @DataFeedId

            SET @intErr = @@ERROR

        END
        ELSE
        BEGIN
            INSERT Statements..teProductionFeed(
		        ProviderId,
                DataFeedId,
                FeedSourcePartyID,
		        AreAllFilesReceived,
		        AreWaitingOnStatementTypeSS,
		        StartDttm,
		        IsProcessing,

				StatementGroupType
            )
            VALUES( 
		        @ProviderId,
                @DataFeedId,
                @FeedSourcePartyID,
				@AreAllFilesReceived,
				@AreWaitingOnStatementTypeSS,
				@StartDttm,
				@IsProcessing,
				@StatementGroupType
            )

            SET @intErr = @@ERROR
        END
    END
    
    -- If an error occurred during execution of this proc raise the error
    -- to the caller if necessary. If there were no outer transactions
    -- active at the time this proc was called, perform a rollback.
    -- Otherwise we are going to assume the outer transaction will trap
    -- the error condition and handle the rollback.
    IF @intErr != 0
    BEGIN
        IF @bitRaiseErr = 1 RAISERROR(@intErr, 16, 1, @chrErrSup)
        IF @intIncomingTranCount = 0 ROLLBACK TRANSACTION
    END
    ELSE
        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0 COMMIT TRANSACTION

    RETURN @intErr

GO


--GRANT EXECUTE
--    ON pProductionFeedInsUpd
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pProductionFeedInsUpd BY CERTIFICATE certStatements
--	WITH PASSWORD = 'Mens confusa'
		
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pProductionFeedInsUpd.sql $', '$Revision: 1 $'
END

GO
 
-- 