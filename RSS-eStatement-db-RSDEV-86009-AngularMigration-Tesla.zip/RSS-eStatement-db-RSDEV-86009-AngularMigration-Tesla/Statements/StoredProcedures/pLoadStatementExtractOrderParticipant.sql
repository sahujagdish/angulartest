USE [Statements]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2020 by DST Systems, Inc.
*   All Rights Reserved.
*/

IF OBJECT_ID('pLoadStatementExtractOrderParticipant') IS NOT NULL
    DROP PROCEDURE dbo.pLoadStatementExtractOrderParticipant
GO

CREATE PROCEDURE [dbo].[pLoadStatementExtractOrderParticipant]
   @StagingID UNIQUEIDENTIFIER
WITH RECOMPILE
AS
   SET NOCOUNT ON;   
    
    WITH CTE AS(
		SELECT *
		FROM Statements.dbo.tsStatementExtractOrderParticipant
		WHERE StagingID = @StagingID
	)
	MERGE INTO Statements.dbo.teStatementExtractOrderParticipant AS ES
    USING CTE AS ESS
        ON 	ESS.StatementOrderId = ES.StatementOrderId AND
		ESS.PlanId = ES.PlanId AND
		ESS.ParticipantId = ES.ParticipantId
        
    WHEN MATCHED THEN
        UPDATE 
            SET OutputFileName = ESS.OutputFileName,
                ReferenceID = ESS.ReferenceID,
                HasActiveEmail = ESS.HasActiveEmail,
                IsEmailSent = ESS.IsEmailSent,
                EmailProcessingDttm = ESS.EmailProcessingDttm,
				eStatementPdf = COALESCE( ESS.eStatementPdf, ES.eStatementPdf )
    WHEN NOT MATCHED BY TARGET THEN
      	 INSERT (
            StatementOrderId,
            PlanId,
	        ParticipantId,
	        OutputFileName,
	        StatementQuarter,
	        StatementYear,
	        ReferenceID,
            HasActiveEmail,
            IsEmailSent,
            EmailProcessingDttm,
			eStatementPdf
        )
        VALUES (
            ESS.StatementOrderId,
            ESS.PlanId,
	        ESS.ParticipantId,
	        ESS.OutputFileName,
	        ESS.StatementQuarter,
	        ESS.StatementYear,
	        ESS.ReferenceID,
            ESS.HasActiveEmail,
            ESS.IsEmailSent,
            ESS.EmailProcessingDttm,
			ESS.eStatementPdf
       );
GO



