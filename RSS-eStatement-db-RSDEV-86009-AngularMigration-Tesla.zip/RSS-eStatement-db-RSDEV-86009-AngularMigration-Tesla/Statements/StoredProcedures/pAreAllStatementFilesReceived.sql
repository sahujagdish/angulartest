USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'pAreAllStatementFilesReceived')
	BEGIN
		DROP  PROCEDURE  pAreAllStatementFilesReceived
	END

GO

----------------------------------------------------------------------------------
-- $Workfile:: pAreAllJobsQueueItemsCompletedByOrderIDAndJobType.sql              $
-- $Archive:: /Database/MainOne2One/StoredProcedures/pAreAllJobsQueueItemsCompletedByOrderIDAndJobType.sql $
-- $Author:: smcveigh                                                             $
-- $Revision:: 4                                                                  $
-- $Modtime:: 2016-04-26 08:09:27-04:00                                           $
----------------------------------------------------------------------------------
-- Parameters:
--   Direction   Name                 Description
--
-- Return Value:
--   Returns a status code indicating success or failure of the operation.
--
-- Result Set(s):
--   none.
--
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
-- Software distributed under the license is distributed on an "AS IS" basis, 
-- WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
-- for the specific language governing rights and limitations under the 
-- license.
-- 
-- Copyright (C) 2014 Newkirk, A DST Company
-- All Rights Reserved.
----------------------------------------------------------------------------------
CREATE PROCEDURE pAreAllStatementFilesReceived
    @DataFeedId UNIQUEIDENTIFIER
AS

    SET NOCOUNT ON
    DECLARE @result int;
	DECLARE @IsProcessing int;
    DECLARE @intIncomingTranCount INT
    
    SET @intIncomingTranCount = @@TRANCOUNT
    
    BEGIN TRY
		EXEC @result = sp_getapplock @Resource = 'pAreAllStatementFilesReceived',  @LockMode = 'Exclusive'
	
		SELECT PF.IsProcessing
		FROM Statements..vProductionFeed PF (XLOCK)
        WHERE PF.DataFeedId = @DataFeedId
        
		UPDATE teProductionFeed
		SET IsProcessing = 1
		WHERE DataFeeedID = @DataFeedId
		
	    EXEC @result = sp_releaseapplock @Resource = 'pAreAllStatementFilesReceived'
	END TRY
    BEGIN CATCH
        EXEC @result = sp_releaseapplock @Resource = 'pAreAllStatementFilesReceived'
       -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        IF @intIncomingTranCount = 0 AND XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )
    END CATCH
    
    
	
GO

--GRANT EXECUTE
--    ON pAreAllJobsQueueItemsCompletedByOrderIDAndJobType
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pAreAllJobsQueueItemsCompletedByOrderIDAndJobType BY CERTIFICATE certMainOne2One
--	WITH PASSWORD = 'Mens confusa'

IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pAreAllStatementFilesReceived.sql $', '$Revision: 1 $'
END

GO


--