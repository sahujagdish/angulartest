﻿USE Statements
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'pGetStatementsPerformance')
	BEGIN
		DROP  PROCEDURE  pGetStatementsPerformance
	END

GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.
CREATE PROCEDURE [dbo].[pGetStatementsPerformance]
    @ReportingLevelID UNIQUEIDENTIFIER,
	@ReportingLevelAsOfDateID INT,
	@FundIdentifiers VARCHAR (8000)
AS
    SET NOCOUNT ON
    DECLARE @FundData TABLE (InvestmentID uniqueidentifier,
                             NewkirkFundID CHAR(5),
                             IsCustomFund BIT,
							 ReportingLevelTypeCD SMALLINT, 
                             CUSIP CHAR(9),
                             TICKER CHAR(5),
                             CommonName VARCHAR(200),
                             AssetGroup VARCHAR(50),
                             FundInceptionDate DATETIME,
                             ExpenseRatioGrossValue DECIMAL(15,2),
                             ExpenseDate DATETIME,
                             RedemptionFeePct DECIMAL(5,4),
							 RedemptionPeriod SMALLINT );

   DECLARE @BmkData TABLE (InvestmentID uniqueidentifier,
                           BmkInvestmentID uniqueIdentifier,
                           BenchmarkName VARCHAR(200), 
						   InvestmentName VARCHAR(200) );
                             
    DECLARE @FundPerf TABLE ( InvestmentID UNIQUEIDENTIFIER, ReportingLevelAsOfDateID INT, PerformanceTypeCD TINYINT, PerformanceTermTypeCD TINYINT, PerformancePct DECIMAL(12,4) )
    DECLARE @FundPerfDistinct TABLE ( InvestmentID UNIQUEIDENTIFIER, ReportingLevelAsOfDateID INT, PerformanceTypeCD TINYINT, PerformanceTermTypeCD TINYINT, PerformancePct DECIMAL(12,4) )
	DECLARE @BmkFundPerf TABLE ( BmkInvestmentID UNIQUEIDENTIFIER, ReportingLevelAsOfDateID INT, PerformanceTypeCD TINYINT, PerformanceTermTypeCD TINYINT, PerformancePct DECIMAL(12,4) )
    DECLARE @BmkFundPerfDistinct TABLE ( BmkInvestmentID UNIQUEIDENTIFIER, ReportingLevelAsOfDateID INT, PerformanceTypeCD TINYINT, PerformanceTermTypeCD TINYINT, PerformancePct DECIMAL(12,4) )
	DECLARE @Performance TABLE ( InvestmentID UNIQUEIDENTIFIER, PerformanceTypeCD TINYINT, ThreeMonth DECIMAL(12,4), OneYear DECIMAL(12,4), ThreeYear DECIMAL(12,4), FiveYear DECIMAL(12,4) ,TenYear DECIMAL(12,4) ,YearToDate DECIMAL(12,4) ,SinceInception DECIMAL(12,4) )
	DECLARE @BmkPerformance TABLE ( BmkInvestmentID UNIQUEIDENTIFIER, PerformanceTypeCD TINYINT, ThreeMonth DECIMAL(12,4), OneYear DECIMAL(12,4), ThreeYear DECIMAL(12,4), FiveYear DECIMAL(12,4) ,TenYear DECIMAL(12,4) ,YearToDate DECIMAL(12,4) ,SinceInception DECIMAL(12,4) )
	DECLARE @Idenifier TABLE ( Identifier VARCHAR(20 ) )
    BEGIN TRY
	
    ;WITH StrCTE(start, stop) AS
    (
      SELECT  1, CHARINDEX(',' , @FundIdentifiers )
      UNION ALL
      SELECT  stop + 1, CHARINDEX(',' ,@FundIdentifiers  , stop + 1)
      FROM StrCTE
      WHERE stop > 0
    )
    INSERT INTO @Idenifier
    SELECT   SUBSTRING(@FundIdentifiers , start, CASE WHEN stop > 0 THEN stop-start ELSE 8000 END) AS stringValue
    FROM StrCTE
	option (maxrecursion 0);

	INSERT INTO @FundData ( InvestmentID, NewkirkFundID, IsCustomFund, ReportingLevelTypeCD, CUSIP, TICKER, CommonName, AssetGroup, FundInceptionDate, ExpenseRatioGrossValue, ExpenseDate, RedemptionFeePct, RedemptionPeriod )
                            ( SELECT AI.InvestmentID,
                                     AI.NewkirkFundID,
                                     AI.IsCustomFund,
									 AI.ReportingLevelTypeCD,
                                     FI.Cusip,
                                     FI.Ticker,
                                     FN.Name AS CommonName,
                                     IAG.Descrip as AssetGroup,                           
	                                 FI.FundInceptionDate,
                                     FF.ExpenseRatioGrossValue,
                                     FF.ExpenseDate,
                                     FF.RedemptionFeePct,
									 FF.RedemptionPeriod
                             FROM Investment..vActiveInvestment AI
                             INNER JOIN Investment..vFundInfo FI
                                ON  FI.FundPartID = Investment.dbo.fvGetScopedFundPartID( 
                                                    AI.ReportingLevelID, 
                                                    AI.InvestmentID, 
                                                    1,
                                                    AI.IsCustomFund, 
                                                    AI.ReportingLevelTypeCD)
                             INNER JOIN @Idenifier RLIST
	                            ON FI.CUSIP = RLIST.Identifier OR FI.Ticker = RLIST.Identifier
	                         INNER JOIN Investment..vFundName FN
                                ON  FN.FundPartID = Investment.dbo.fvGetScopedFundPartID( 
                                                    AI.ReportingLevelID, 
                                                    AI.InvestmentID, 
                                                    27,
                                                    AI.IsCustomFund, 
                                                    AI.ReportingLevelTypeCD)
                             LEFT OUTER JOIN Investment..vInvestmentAssetGroup IAG 
                                ON  IAG.ReportingLevelID = @ReportingLevelID
                                    AND IAG.InvestmentID = AI.InvestmentID 
                             INNER JOIN Investment..vFundFee FF
	                            ON FF.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID
                                AND FF.FundPartID = Investment.dbo.fvGetScopedFundPartID( 
                                                    AI.ReportingLevelID, 
                                                    AI.InvestmentID, 
                                                    24,
                                                    AI.IsCustomFund, 
                                                    AI.ReportingLevelTypeCD) 
							  
                            WHERE AI.ReportingLevelID = @ReportingLevelID )


	  SELECT FD.InvestmentId,
             FD.NewkirkFundID, 
             FD.CUSIP, 
             FD.TICKER, 
             FD.CommonName, 
             FD.AssetGroup, 
             FD.FundInceptionDate, 
             FD.ExpenseRatioGrossValue, 
             FD.ExpenseDate, 
             FD.RedemptionFeePct, 
             FD.RedemptionPeriod, 
             FM.WebSite
      FROM @FundData FD
      LEFT OUTER JOIN Investment..vFundManagement FM
	    ON FM.FundPartID = Investment.dbo.fvGetScopedFundPartID( 
                           @ReportingLevelID, 
                           FD.InvestmentID, 
                           11,
                           FD.IsCustomFund, 
                           FD.ReportingLevelTypeCD) 
		    AND FM.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID

	 INSERT INTO @FundPerf ( InvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct )
		( SELECT FD.InvestmentID, P.ReportingLevelAsOfDateID, P.PerformanceTypeCD, P.PerformanceTermTypeCD, P.PerformancePct
			FROM Investment..teFundPart FP
			JOIN @FundData FD ON FD.InvestmentID = FP.InvestmentID
		    JOIN Investment..teFundPerformance P
			ON P.FundPartID = FP.FundPartID
		  WHERE FP.ReportingLevelID = @ReportingLevelID
			AND P.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID )

      INSERT INTO @FundPerfDistinct (InvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct) 
      (SELECT DISTINCT InvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct FROM @FundPerf )

	 INSERT INTO @Performance (InvestmentID , PerformanceTypeCD , ThreeMonth , OneYear, ThreeYear , FiveYear,TenYear ,YearToDate ,SinceInception )
		(SELECT InvestmentID, PerformanceTypeCD, [5] As 'ThreeMonth',[6] As 'OneYear',[7] As 'ThreeYear',[8] As 'FiveYear',[9] As 'TenYear',[10] As 'YearToDate', [11] As 'SinceInception'
		FROM @FundPerfDistinct
		PIVOT
		(
			SUM(PerformancePct)
			FOR PerformanceTermTypeCD
			IN ([5],[6],[7],[8],[9],[10],[11])
		)As PivotTable )
	 
		SELECT InvestmentID,
			SUM(ThreeMonth) as ThreeMonth,
			SUM(OneYEAR) AS OneYear,
			SUM(ThreeYear) as ThreeYear,
			SUM(FiveYear) as FiveYear,
			SUM(TenYear) as TenYear,
			SUM(YearToDate) as YearToDate,
			SUM(SinceInception) as SinceInception from @Performance
		GROUP BY InvestmentID

	 INSERT INTO @BmkData ( InvestmentID, BmkInvestmentID, BenchmarkName, InvestmentName )
		(SELECT BM.InvestmentID, BM.BmkInvestmentID, BM.BenchmarkName, BM.InvestmentName
		 FROM Investment..vInvestmentBenchmark BM
	     WHERE  BM.ReportingLevelID =  @ReportingLevelID AND BM.InvestmentBenchmarkTypeCD = 1 AND BM.InvestmentID IN ( SELECT F.InvestmentID FROM @FundData F ) )

	 INSERT INTO @BmkFundPerf ( BmkInvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct )
		(SELECT P.InvestmentID, P.ReportingLevelAsOfDateID, P.PerformanceTypeCD, P.PerformanceTermTypeCD, P.PerformancePct
		 FROM Investment..vFundPerformance P
         WHERE P.InvestmentID IN ( SELECT BmkInvestmentID FROM @BmkData )
            AND p.ReportingLevelAsOfDateID = @ReportingLevelAsOfDateID )

     INSERT INTO @BmkFundPerfDistinct (BmkInvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct) 
     (SELECT DISTINCT BmkInvestmentID, ReportingLevelAsOfDateID, PerformanceTypeCD, PerformanceTermTypeCD, PerformancePct FROM @BmkFundPerf )

	 INSERT INTO @BmkPerformance (BmkInvestmentID , PerformanceTypeCD , ThreeMonth , OneYear, ThreeYear , FiveYear,TenYear ,YearToDate ,SinceInception )
		(SELECT BmkInvestmentID, PerformanceTypeCD, [5] As 'ThreeMonth',[6] As 'OneYear',[7] As 'ThreeYear',[8] As 'FiveYear',[9] As 'TenYear',[10] As 'YearToDate', [11] As 'SinceInception'
		FROM @BmkFundPerfDistinct
		PIVOT
		(
			SUM(PerformancePct)
			FOR PerformanceTermTypeCD
			IN ([5],[6],[7],[8],[9],[10],[11])
		)As PivotTable )
	 
	 SELECT InvestmentID, 
			BmkInvestmentID, 
			BenchmarkName, 
			InvestmentName
	 FROM @BmkData

	 SELECT BmkInvestmentID,
		SUM(ThreeMonth) as ThreeMonth,
		SUM(OneYEAR) AS OneYear,
		SUM(ThreeYear) as ThreeYear,
		SUM(FiveYear) as FiveYear,
		SUM(TenYear) as TenYear,
		SUM(YearToDate) as YearToDate,
		SUM(SinceInception) as SinceInception from @BmkPerformance
	 GROUP BY BmkInvestmentID
	END TRY

    BEGIN CATCH
       -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )
    END CATCH
   
   GO

--GRANT EXECUTE
--    ON pAreAllJobsQueueItemsCompletedByOrderIDAndJobType
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pAreAllJobsQueueItemsCompletedByOrderIDAndJobType BY CERTIFICATE certMainOne2One
--	WITH PASSWORD = 'Mens confusa'

IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pAreAllStatementFilesReceived.sql $', '$Revision: 1 $'
END

GO