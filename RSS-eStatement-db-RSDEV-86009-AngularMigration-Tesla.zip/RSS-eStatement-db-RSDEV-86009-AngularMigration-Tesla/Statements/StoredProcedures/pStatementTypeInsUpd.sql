﻿USE Statements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pStatementTypeInsUpd') IS NOT NULL
	DROP PROCEDURE dbo.pStatementTypeInsUpd
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].[pStatementTypeInsUpd]
	@ProviderId UNIQUEIDENTIFIER,
	@ExternalPlanId VARCHAR(100),
	@StatementType VARCHAR(20),
	@Fees BIT,
	@YRYW_Mess BIT,
	@Alloc_Pies BIT,
	@Mbu BIT,
	@Src_Detail BIT,
	@QFees BIT, 
    @Per_Disp BIT,
    @Activity BIT,
    @Perf_Reg BIT,
    @Perf_Expan BIT,
    @Models BIT, 
    @Ed_Art BIT, 
    @Projector BIT,
    @Loan_Disp BIT, 
    @Vesting BIT,
    @Acct_bal BIT
	 
AS
      SET NOCOUNT ON

     BEGIN TRY
        --
        -- Update the existing record or insert a new one, as appropriate.
        --
        UPDATE Statements..teStatementType
            SET 
		    ProviderId = @ProviderId,
		    ExternalPlanId = @ExternalPlanId,
		    StatementType = @StatementType,
		    Fees = @Fees,   
            YRYW_Mess = @YRYW_Mess,
            Alloc_Pies = @Alloc_Pies,
            Mbu = @Mbu,
            Src_Detail = @Src_Detail,
            QFees = @QFees,
            Per_Disp = @Per_Disp,
            Activity = @Activity,
            Perf_Reg = @Perf_Reg,
            Perf_Expan = @Perf_Expan,
            Models = @Models, 
            Ed_Art = @Ed_Art,   
            Projector = @Projector,
            Loan_Disp = @Loan_Disp,
            Vesting = @Vesting,
            Acct_bal = @Acct_bal
        WHERE ProviderId = @ProviderId
            AND ExternalPlanId = @ExternalPlanId

        --
        -- Insert new record.
        --
        IF @@ROWCOUNT = 0
            INSERT INTO Statements..teStatementType (   
                ProviderId,
			    ExternalPlanId,
			    StatementType,
			    Fees,
			    YRYW_Mess,
			    Alloc_Pies,
			    Mbu,
			    Src_Detail,
			    QFees,
			    Per_Disp,
			    Activity,
			    Perf_Reg,
			    Perf_Expan,
			    Models, 
			    Ed_Art,
			    Projector,
			    Loan_Disp,
			    Vesting,
			    Acct_bal
            )
            VALUES (
                @ProviderId,
			    @ExternalPlanId,
			    @StatementType,
			    @Fees,
			    @YRYW_Mess,
			    @Alloc_Pies,
			    @Mbu,
			    @Src_Detail,
			    @QFees,
			    @Per_Disp,
			    @Activity,
			    @Perf_Reg,
			    @Perf_Expan,
			    @Models, 
			    @Ed_Art,
			    @Projector,
			    @Loan_Disp,
			    @Vesting,
			    @Acct_bal
            )
            
        RETURN 0
    END TRY
    BEGIN CATCH
        -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000)
        DECLARE @ErrorSeverity INT
        DECLARE @ErrorState INT
        DECLARE @ErrorNumber INT

        SELECT
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE(),
            @ErrorNumber =  ERROR_NUMBER()

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )

        RETURN @ErrorNumber
    END CATCH

GO


--GRANT EXECUTE
--    ON pProductionFeedInsUpd
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pStatementExtractOrderInsUpd BY CERTIFICATE certStatements
--	WITH PASSWORD = 'Mens confusa'
		
IF OBJECT_ID( 'pStampVersion', 'P' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: pStatementTypeInsUpd.sql $', '$Revision: 1 $'
END

GO