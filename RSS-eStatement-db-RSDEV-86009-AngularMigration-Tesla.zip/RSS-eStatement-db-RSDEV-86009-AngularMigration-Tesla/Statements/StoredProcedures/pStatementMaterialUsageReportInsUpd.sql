USE Statements
GO
-- Drop procedure if it already exists
IF OBJECT_ID('pStatementMaterialUsageReportInsUpd') IS NOT NULL
	DROP PROCEDURE [dbo].[pStatementMaterialUsageReportInsUpd]
GO

SET QUOTED_IDENTIFIER ON
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.


CREATE PROCEDURE [dbo].pStatementMaterialUsageReportInsUpd
	@StatementOrderId INT OUTPUT,
 	@ProviderId UNIQUEIDENTIFIER,
 	@ProviderName VARCHAR(100),
 	@EStatementExtractId INT,
 	@OutputFileName UNIQUEIDENTIFIER,
 	@OutputFileNumber SMALLINT,
 	@PrintFileName VARCHAR(100),
 	@JT_NUM VARCHAR(10),
 	@CUSTNUM VARCHAR(7),
 	@ShipDate DATETIME,
 	@ParticipantCount INT,
 	@StatementType VARCHAR(7),
 	@JobQuantity INT,	
 	@Material1 VARCHAR(15),
 	@Material2 VARCHAR(15),
 	@Material2Qty INT,
 	@Material3 VARCHAR(15),
 	@Envelope VARCHAR(15),
 	@InsertMaterial1 VARCHAR(15),
 	@InsertMaterial2 VARCHAR(15),
 	@InsertMaterial3 VARCHAR(15),
 	@InsertMaterial4 VARCHAR(15),
 	@InsertMaterial5 VARCHAR(15),
 	@InsertMaterial6 VARCHAR(15)
AS
    SET NOCOUNT ON

    --
    -- Standard handling:
    --
    DECLARE @intIncomingTranCount INT
	-- Track errors as you go. Only execute as long as no errors.
    DECLARE @intErr               INT
	--Signal to actually raise a formal error if first-time encountered.
    DECLARE @bitRaiseErr          BIT
    DECLARE @chrErrSup            VARCHAR(100)

    --
    -- Initialize variables
    --
    SET @intIncomingTranCount = @@TRANCOUNT
    SET @intErr               = @@ERROR
    SET @bitRaiseErr          = 0
    SET @chrErrSup            = ''

    --
    -- Procedure Variables
    --
    DECLARE @existingID INT
    SET @existingID = NULL
    
    --
    -- PROCESSING
    --
    IF @intIncomingTranCount = 0
    BEGIN
      -- if there is no transaction already present,
      -- this proc must start one
      BEGIN TRANSACTION
      SET @intErr = @@ERROR
    END

    --
    --see if entry already exists
    --
    IF @intErr = 0
    BEGIN
       
        SELECT @existingID = EStatementExtractId
            FROM Statements..teStatementMaterialUsageReport
            WHERE OutputFileName = @OutputFileName AND OutputFileNumber = @OutputFileNumber

        SET @intErr = @@ERROR
       
    END

	--
	-- Business Logic
	-- 

    IF @intErr = 0   -- input ok, insert.
    BEGIN
        IF @existingID IS NOT NULL
        BEGIN
            UPDATE Statements..teStatementMaterialUsageReport
               SET				 					 	
				 	PrintFileName	= @PrintFileName,
				 	JT_NUM			= @JT_NUM,
				 	CUSTNUM			= @CUSTNUM,
				 	ShipDate		= @ShipDate,
				 	ParticipantCount = @ParticipantCount,
				 	StatementType	= @StatementType,
				 	JobQuantity		= @JobQuantity,
				 	Material1		= @Material1,
				 	Material2Qty	= @Material2Qty,
				 	Material2		= @Material2,
				 	Material3		= @Material3,
				 	Envelope		= @Envelope,
				 	InsertMaterial1 = @InsertMaterial1,
				 	InsertMaterial2 = @InsertMaterial2,
				 	InsertMaterial3 = @InsertMaterial3,
				 	InsertMaterial4 = @InsertMaterial4,
				 	InsertMaterial5 = @InsertMaterial5,
 					InsertMaterial6 = @InsertMaterial6			   	
             WHERE EStatementExtractId = @existingID AND OutputFileName = @OutputFileName AND OutputFileNumber = @OutputFileNumber

            SET @intErr = @@ERROR

        END
        ELSE
        BEGIN
            INSERT Statements..teStatementMaterialUsageReport (
				ProviderID,
				ProviderName,
				EStatementExtractId,
				OutputFileName,
				OutputFileNumber,
				PrintFileName,
				JT_NUM,
				CUSTNUM,
				ShipDate,
				ParticipantCount,
				StatementType,
				JobQuantity,
				Material1,
				Material2,
				Material2Qty,
				Material3,
				Envelope,
				InsertMaterial1,
				InsertMaterial2,
				InsertMaterial3,
				InsertMaterial4,
				InsertMaterial5,
				InsertMaterial6			
            )
            VALUES(
                @ProviderId,
                @ProviderName,
                @EStatementExtractId,
                @OutputFileName,
                @OutputFileNumber,
                @PrintFileName,
                @JT_NUM,
                @CUSTNUM,
                @ShipDate,
                @ParticipantCount,
                @StatementType,
                @JobQuantity,
                @Material1,
                @Material2,
                @Material2Qty,
                @Material3,
                @Envelope,
                @InsertMaterial1,
                @InsertMaterial2,
                @InsertMaterial3,
                @InsertMaterial4,
                @InsertMaterial5,
                @InsertMaterial6	
            )
            SET @intErr = @@ERROR
        END
    END
    
    -- If an error occurred during execution of this proc raise the error
    -- to the caller if necessary. If there were no outer transactions
    -- active at the time this proc was called, perform a rollback.
    -- Otherwise we are going to assume the outer transaction will trap
    -- the error condition and handle the rollback.
    IF @intErr != 0
    BEGIN
        IF @bitRaiseErr = 1 RAISERROR(@intErr, 16, 1, @chrErrSup)
        IF @intIncomingTranCount = 0 ROLLBACK TRANSACTION
    END
    ELSE
        -- No error occurred, so commit the transaction if there is no
        -- outer transaction already present.
        IF @intIncomingTranCount = 0 COMMIT TRANSACTION

    RETURN @intErr

GO
