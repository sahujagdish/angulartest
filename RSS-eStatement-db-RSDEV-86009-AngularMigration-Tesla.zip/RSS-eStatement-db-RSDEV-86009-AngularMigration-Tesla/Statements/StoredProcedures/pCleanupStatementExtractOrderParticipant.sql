USE [Statements]
GO

-- Drop procedure if it already exists
IF OBJECT_ID('pCleanupStatementExtractOrderParticipantStaging') IS NOT NULL
	DROP PROCEDURE dbo.pCleanupStatementExtractOrderParticipantStaging
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2020 by DST Systems, Inc.
*   All Rights Reserved.
*/

CREATE PROCEDURE [dbo].[pCleanupStatementExtractOrderParticipantStaging]
	@StagingID UNIQUEIDENTIFIER
AS
    SET NOCOUNT ON;

    DELETE FROM Statements.dbo.tsStatementExtractOrderParticipant
    WHERE StagingID = @StagingID;

GO


