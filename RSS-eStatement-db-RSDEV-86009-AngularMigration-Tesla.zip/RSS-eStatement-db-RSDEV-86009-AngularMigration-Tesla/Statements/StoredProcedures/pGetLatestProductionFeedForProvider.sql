﻿USE Statements

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'pGetLatestProductionFeedForProvider')
	BEGIN
		DROP PROCEDURE dbo.pGetLatestProductionFeedForProvider
	END
GO


CREATE PROCEDURE dbo.pGetLatestProductionFeedForProvider
    @ProviderId UNIQUEIDENTIFIER,
    @FeedSourcePartyID UNIQUEIDENTIFIER,
    @StatementGroupType INT,
    @FilePath VARCHAR(500),
    @FeedSourceID UNIQUEIDENTIFIER,
    @IsGlobalFile BIT
AS
 SET NOCOUNT ON
    DECLARE @result int
	DECLARE @RC int
    DECLARE @intIncomingTranCount INT
    
    SET @intIncomingTranCount = @@TRANCOUNT
    
    BEGIN TRY
	    EXEC @result = sp_getapplock @Resource = 'pGetLatestProductionFeedForProvider',  @LockMode = 'Exclusive'

        DECLARE @Count INT
        SET @Count = ( SELECT TOP 1 COUNT(*)
                       FROM Statements..vProductionFeed PF 
                       WHERE PF.ProviderId = @ProviderId 
                        AND PF.FeedSourcePartyID = @FeedSourcePartyID AND PF.IsProcessing = 0  
                        AND PF.StatementGroupType = @StatementGroupType  
                        AND PF.AreAllFilesReceived = 0  )

        IF @COUNT = 0
            BEGIN
            DECLARE @StartDttm DATETIME = GETDATE()
            DECLARE @DataFeedID UNIQUEIDENTIFIER = NEWID()
			

            -- Add New Data Feed\
            EXECUTE @RC = UpdateProxy..pDataFeedInsUpd
                            @XMLFileData = '[See File]',
                            @DataFeedID = @DataFeedID,
                            @ModifiedByPartyID = @FeedSourceID,
                            @FeedSourcePartyID = @FeedSourceID,
                            @SourceFilePath = @FilePath,
                            @DataFeedTypeCD = 1,
                            @ConfirmationNbr = 0,
                            @HasProcessingErrors = 0,
                            @FeedComplete = 0,
                            @XMLSchemaVersion = '5.1',
                            @OriginalFilePath = @FilePath,
                            @ProcessingEndDttm = NULL,
                            @ParticipantCount = 0

            -- Add New Production Feed
            EXEC Statements..pProductionFeedInsUpd
                            @ProviderId = @ProviderId,
                            @DataFeedId = @DataFeedID,
                            @FeedSourcePartyID = @FeedSourcePartyID,
                            @AreAllFilesReceived = @IsGlobalFile,
                            @AreWaitingOnStatementTypeSS = 0,
                            @StartDttm = @StartDttm,
                            @IsProcessing = @IsGlobalFile,
							@StatementGroupType = @StatementGroupType

            
            END
       
        SELECT TOP 1
            PF.ProviderId, 
            PF.DataFeedId, 
            PF.FeedSourcePartyID, 
            PF.AreAllFilesReceived, 
            PF.FeedSourcePartyID, 
            PF.AreWaitingOnStatementTypeSS, 
            PF.StartDttm, 
            PF.IsProcessing, 
            PF.StatementGroupType 
        FROM Statements..vProductionFeed PF 
        WHERE PF.ProviderId = @ProviderId 
            AND PF.FeedSourcePartyID = @FeedSourcePartyID AND PF.IsProcessing = 0  
            AND PF.StatementGroupType = @StatementGroupType  
            AND PF.AreAllFilesReceived = 0 
        ORDER BY PF.StartDttm DESC 

	    EXEC @result = sp_releaseapplock @Resource = 'pGetLatestProductionFeedForProvider'
	END TRY
    BEGIN CATCH
        EXEC @result = sp_releaseapplock @Resource = 'pGetLatestProductionFeedForProvider'
       -- If an error occurred during execution of this proc raise the error
        -- to the caller if necessary. If there were no outer transactions
        -- active at the time this proc was called, perform a rollback.
        -- Otherwise we are going to assume the outer transaction will trap
        -- the error condition and handle the rollback.
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        IF @intIncomingTranCount = 0 AND XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        IF @ErrorState = 0
            SET @ErrorState = 1

        RAISERROR ( @ErrorMessage, @ErrorSeverity, @ErrorState )
    END CATCH
    
    
	
GO

--GRANT EXECUTE
--    ON pGetLatestProductionFeedForProvider
--    TO rMTAccess
--GO

--ADD SIGNATURE TO pGetLatestProductionFeedForProvider BY CERTIFICATE certFinancialOne2One
--	WITH PASSWORD = 'Mens confusa'

GO
