USE [Statements]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
* COPYRIGHT:
*
*   The computer systems, procedures, data bases and programs
*   created and maintained by DST Systems, Inc., are proprietary
*   in nature and as such are confidential.  Any unauthorized
*   use or disclosure of such information may result in civil
*   liabilities.
*
*   Copyright 2017 by DST Systems, Inc.
*   All Rights Reserved.
*/

IF OBJECT_ID('pLoadStatementInvestmentPerformance') IS NOT NULL
    DROP PROCEDURE dbo.pLoadStatementInvestmentPerformance
GO


CREATE PROCEDURE [dbo].[pLoadStatementInvestmentPerformance]
   @StagingID UNIQUEIDENTIFIER
WITH RECOMPILE
AS
   SET NOCOUNT ON;   
    
    /* INSERT OR UPDATE TO the tsPlanParticipantOrderReport TABLE */
    WITH CTE AS(
		SELECT *
		FROM Statements.dbo.tsStatementInvestmentPerformance
		WHERE StagingID = @StagingID
	)
	MERGE INTO Statements.dbo.teStatementInvestmentPerformance AS SFP
    USING CTE AS SFPS
        ON SFPS.ProviderId = SFP.ProviderId
		AND SFPS.CUSIP = SFP.CUSIP
		AND SFPS.TICKER = SFP.TICKER
        AND SFPS.AsOfDate = SFP.AsOfDate
    WHEN MATCHED THEN
        UPDATE 
            SET FundName = SFPS.FundName,
            DAY7 = SFPS.DAY7,
            Month1 = SFPS.Month1,
            QTR = SFPS.QTR,
            YR1 = SFPS.YR1,
            YR3 = SFPS.YR3,
            YR5 = SFPS.YR5,
            YR10 = SFPS.YR10,
            Inception = SFPS.Inception,
            YTD = SFPS.YTD,
            AsOfDate = SFPS.AsOfDate,
            Inc_Date = SFPS.Inc_Date,
            Class = SFPS.Class,
            Ref1 = SFPS.Ref1,
            Expratio = SFPS.Expratio,
            Expdate = SFPS.Expdate,
            Perfsup = SFPS.Perfsup,
            Redemption = SFPS.Redemption,
            Redeemdays = SFPS.Redeemdays,
            Max_front = SFPS.Max_front,
            Max_defer = SFPS.Max_defer,
            Website = SFPS.Website,
            Benchno = SFPS.Benchno,
            FixedActRate = SFPS.FixedActRate,
            Yield = SFPS.Yield,
            YieldExp = SFPS.YieldExp,
            VRUCode = SFPS.VRUCode,
            Risk = SFPS.Risk
    WHEN NOT MATCHED BY TARGET THEN
      	 INSERT (
            ProviderId,
            FundName,
            CUSIP,
            DAY7,
            Month1,
            QTR,
            YR1,
            YR3,
            YR5,
            YR10,
            Inception,
            YTD,
            AsOfDate,
            Inc_Date,
            Class,
            Ticker,
            Ref1,
            Expratio,
            Expdate,
            Perfsup,
            Redemption,
            Redeemdays,
            Max_front,
            Max_defer,
            Website,
            Benchno,
            NewkirkFundId,
            FixedActRate,
            Yield,
            YieldExp,
            VRUCode,
            Risk
        )
        VALUES (
            SFPS.ProviderId,
            SFPS.FundName,
            SFPS.CUSIP,
            SFPS.DAY7,
            SFPS.Month1,
            SFPS.QTR,
            SFPS.YR1,
            SFPS.YR3,
            SFPS.YR5,
            SFPS.YR10,
            SFPS.Inception,
            SFPS.YTD,
            SFPS.AsOfDate,
            SFPS.Inc_Date,
            SFPS.Class,
            SFPS.Ticker,
            SFPS.Ref1,
            SFPS.Expratio,
            SFPS.Expdate,
            SFPS.Perfsup,
            SFPS.Redemption,
            SFPS.Redeemdays,
            SFPS.Max_front,
            SFPS.Max_defer,
            SFPS.Website,
            SFPS.Benchno,
            SFPS.NewkirkFundId,
            SFPS.FixedActRate,
            SFPS.Yield,
            SFPS.YieldExp,
            SFPS.VRUCode,
            SFPS.Risk
       );
GO

EXEC sys.sp_addextendedproperty @name=N'Version', @value=N'1' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'PROCEDURE',@level1name=N'pLoadStatementInvestmentPerformance'
GO

