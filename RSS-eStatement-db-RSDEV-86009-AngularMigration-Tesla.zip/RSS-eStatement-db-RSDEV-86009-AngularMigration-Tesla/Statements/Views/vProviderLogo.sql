﻿USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vProviderLogo')
	BEGIN
		DROP  View vProviderLogo
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vProviderLogo AS

    SELECT 
		ProviderId,
		LogoId,
		Thumbnail
    FROM teProviderLogo
GO

--GRANT SELECT ON vProviderLogo TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vProviderLogo.sql $', '$Revision: 1 $'
END

GO
 