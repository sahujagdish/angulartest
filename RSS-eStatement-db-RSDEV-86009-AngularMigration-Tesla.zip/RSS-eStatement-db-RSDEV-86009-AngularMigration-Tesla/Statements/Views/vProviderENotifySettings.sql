﻿
USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vProviderENotifySettings')
	BEGIN
		DROP  View vProviderENotifySettings
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vProviderENotifySettings AS

    SELECT 
		ProviderId,
        Fromaddr,
        Fromname,
        EMailSubject,
        EmailBody, 
        Replyaddr,
        Replyname,
        EmailBatchSize,
        HoursBetweenBatch,
        AreEmailSentOnWeekendHoliday,
        IsSundaySkipped,
		IsMondaySkipped,
		IsTuesdaySkipped,
    	IsWednesdaySkipped,
		IsThursdaySkipped,
		IsFridaySkipped,
		IsSaturdaySkipped
    FROM teProviderENotifySettings
GO

--GRANT SELECT ON vProviderENotifySettings TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vProviderENotifySettings.sql $', '$Revision: 1 $'
END

GO
