USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vProviderSettings')
	BEGIN
		DROP  View vProviderSettings
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vProviderSettings AS

    SELECT
        ProviderId,
        ProviderAbbrev,
        ProviderName,
        EStatementProviderId,
        CUSTNUM,
        ReportingLevelId,
        FTPSite,
        FTPLocationId,
        Spath,
        Powerprt,
        Shname,
        Shadr1,
        Shadr2,
        Shadr3,
        City,
        State,
        Zip,
        Provadd,
        Pname,
        Padr1,
        Padr2,
        Padr3,
        Class1,
        Class2,
        Class3,
        Class4,
        Class5,
        Class6,
        NewClass, 
        MBU,
        Ror,
        Ytdror,
        abgpg1mess,
        Noloan,
        Vestbal,
        Bold_funds,
        Smart_ben,
        Lipper,
        Units,
        abgmodel,
        Bookkeeper,
        Sm_cont_hd,
        Sm_acct_hd,
        Feediscl,
        Modelhead,
        abgflag,
        Indices,
        Loandisp,
        Smart_plm,
        Expenses,
        Sourcedet,
        Dist,
        Srctotals,
        Expdisplay,
        Rebatename,
        Expratio,
        Header1,
        Header1a,
        Header2,
        BoldFunds,
	    Demography,
	    TickerFlag,
        Smart_mes,
        Smart_pg2,
        Smart_acc,
        Smart_acc2,
        Smart_all,
        Smart_all2,
        ProofNum,
        GetProofParsFromFile,
        GetProofParsFromFeed,
        EStatement,
        ENotify,
	    EAutoReg,
        UseBadAddresses,
        CanUseLicensedIndices,
        IsEnvelopeSealedSponsor,
        IsEnvelopeSealedProvider,
        ProductionDays,
	    AreAllDaysUsedFromProductionTime,
        NoSpace,
        EdArt,
        RebalDate,
        IsPerformanceMasked,
        IsSMRCreated,
	    IsParticipantDataInSMR,
        IsUsingDSTPerformance,
        IsUsingCustomFunds,
	    IsFundPerformanceUsed,
        IsStatementTypeUsed,
        IsBadAddressReportUsed,
	    IsBadAllocationReportUsed,
	    IsNoActivityReportUsed,
	    IsAuditReportUsed,
        CustomReportingLevelId,
        ProductionDelay,
        IsLoanInvestmentAdded,
        eStatementQuarters,
        ActiveParsIsForPrintAndEStatements
    FROM teProviderSettings
GO


--GRANT SELECT ON vProviderSettings TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vProviderSettings.sql $', '$Revision: 1 $'
END

GO


