﻿USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vProviderMessage')
	BEGIN
		DROP  View vProviderMessage
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vProviderMessage AS

    SELECT 
		ProviderId,
        MessageName,
		MessageId,
		CompuSetMessage,
        OriginalMessage
    FROM teProviderMessage
GO

--GRANT SELECT ON vProviderMessage TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vProviderMessage.sql $', '$Revision: 1 $'
END

GO
