﻿USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vProviderPlans')
	BEGIN
		DROP  View vProviderPlans
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vProviderPlans AS

   SELECT P.ProviderId,
       P.ExternalPlanId,
       P.PlanName1,
       P.PlanName2,
	   PL.LogoId,
	   ( SELECT MessageId FROM vPlanMessage WHERE MessageLocation = 1 and ExternalPlanId = P.ExternalPlanId AND ProviderId = P.ProviderId ) AS Message1Id,
	   ( SELECT MessageId FROM vPlanMessage WHERE MessageLocation = 2 and ExternalPlanId = P.ExternalPlanId AND ProviderId = P.ProviderId ) AS Message2Id,
	   ( SELECT MessageId FROM vPlanMessage WHERE MessageLocation = 3 and ExternalPlanId = P.ExternalPlanId AND ProviderId = P.ProviderId ) AS Message3Id,
	   ( SELECT MessageId FROM vPlanMessage WHERE MessageLocation = 4 and ExternalPlanId = P.ExternalPlanId AND ProviderId = P.ProviderId ) AS Message4Id,
	   ( SELECT MessageId FROM vPlanMessage WHERE MessageLocation = 5 and ExternalPlanId = P.ExternalPlanId AND ProviderId = P.ProviderId ) AS Message5Id
  FROM tePlan P
  LEFT JOIN tePlanLogo PL 
	ON P.ExternalPlanId = Pl.ExternalPlanId
		AND P.ProviderId = PL.ProviderId
 
GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vProviderPlans.sql $', '$Revision: 1 $'
END

GO
