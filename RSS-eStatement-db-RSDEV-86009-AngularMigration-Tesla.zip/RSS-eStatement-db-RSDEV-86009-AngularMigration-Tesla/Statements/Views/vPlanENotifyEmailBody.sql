﻿CREATE VIEW [dbo].[vPlanENotifyEmailBody]
    AS SELECT * FROM [SomeTableOrView]



    GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vPlanENotifyEmailBody')
	BEGIN
		DROP  View vPlanENotifyEmailBody
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vPlanENotifyEmailBody AS

    SELECT 
		ProviderId,
		ExternalPlanId,
		EmailBody
    FROM tePlanENotifyEmailBody
GO

--GRANT SELECT ON vPlanLogo TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vPlanENotifyEmailBody.sql $', '$Revision: 1 $'
END

GO

