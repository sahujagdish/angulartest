USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vABGContact')
	BEGIN
		DROP  View vABGContact
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vABGContact AS
    SELECT 
        ProviderId,
        ExternalPlanId, 
        Web,
        Phone,
        Email,
        IsShowModelLanguage,
        RebalanceFrequency,
        IsChargeForRebalance,
        IsModelOnly
    FROM teABGContact
GO

--GRANT SELECT ON vFeedFiles TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vABGContact.sql $', '$Revision: 1 $'
END

GO

