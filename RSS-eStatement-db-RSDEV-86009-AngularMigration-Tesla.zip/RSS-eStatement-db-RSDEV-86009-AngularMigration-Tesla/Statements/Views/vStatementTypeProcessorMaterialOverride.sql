USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vStatementTypeProcessorMaterialOverride')
	BEGIN
		DROP  View vStatementTypeProcessorMaterialOverride
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2020 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vStatementTypeProcessorMaterialOverride AS

    SELECT 
        ProviderID,
        StatementType,
        Material1,
        Material2,
        Material3,
        EnvelopeNI,
        EnvelopeIND,
        InsertMaterial1,
        InsertMaterial2,
        InsertMaterial3
    FROM teStatementTypeProcessorMaterialOverride

GO

--GRANT SELECT ON vStatementTypeProcessor TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vStatementTypeProcessorMaterialOverride.sql $', '$Revision: 1 $'
END

GO
