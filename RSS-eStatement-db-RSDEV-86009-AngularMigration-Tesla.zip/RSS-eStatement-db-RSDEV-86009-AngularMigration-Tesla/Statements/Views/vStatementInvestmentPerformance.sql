USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vStatementInvestmentPerformance')
	BEGIN
		DROP  View vStatementInvestmentPerformance
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vStatementInvestmentPerformance AS

    SELECT 
        ID,
        ProviderId,
        FundName,
        CUSIP,
        DAY7,
        Month1,
        QTR,
        YR1,
        YR3,
        YR5,
        YR10,
        Inception,
        YTD,
        AsOfDate,
        Inc_Date,
        Class,
        Ticker,
        Ref1,
        Expratio,
        Expdate,
        Perfsup,
        Redemption,
        Redeemdays,
        Max_front,
        Max_defer,
        Website,
        Benchno,
        NewkirkFundId,
        FixedActRate,
	    Yield,
	    YieldExp,
	    VRUCode,
	    Risk
    FROM teStatementInvestmentPerformance
GO

--GRANT SELECT ON vProviderMessage TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vStatementInvestmentPerformance.sql $', '$Revision: 1 $'
END

GO
