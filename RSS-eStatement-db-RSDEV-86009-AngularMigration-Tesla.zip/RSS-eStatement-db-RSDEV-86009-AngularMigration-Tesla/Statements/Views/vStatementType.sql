﻿USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vStatementType')
	BEGIN
		DROP  View vStatementType
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vStatementType AS

    SELECT 
		ProviderId,
        ExternalPlanId,
        StatementType,
        Fees,
        YRYW_Mess,
        Alloc_Pies,
        Mbu,
        Src_Detail,
        QFees,
        Per_Disp,
        Activity,
        Perf_Reg,
        Perf_Expan,
        Models,
        Ed_Art,
        Projector,
        Loan_Disp,
        Vesting,
        Acct_bal
    FROM teStatementType
GO

--GRANT SELECT ON vStatementTypeProcessor TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vStatementType.sql $', '$Revision: 1 $'
END

GO
