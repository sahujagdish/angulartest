USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vMessageCharReplacement')
	BEGIN
		DROP  View vMessageCharReplacement
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vMessageCharReplacement AS

    SELECT 
		RTFChar,
		ReplacementChr,
		Sequence
    FROM teMessageCharReplacement
GO

--GRANT SELECT ON vMessageCharReplacement TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vMessageCharReplacement.sql $', '$Revision: 1 $'
END

GO

