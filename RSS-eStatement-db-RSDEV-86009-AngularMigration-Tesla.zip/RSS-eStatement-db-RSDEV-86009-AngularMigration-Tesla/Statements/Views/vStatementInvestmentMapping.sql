﻿USE Statements
GO

IF EXISTS (SELECT * FROM sysobjects WHERE type = 'V' AND name = 'vStatementInvestmentMapping')
	BEGIN
		DROP  View vStatementInvestmentMapping
	END
GO

-- COPYRIGHT:
--  The computer systems, procedures, data bases and programs
--  created and maintained by DST Systems, Inc., are proprietary
--  in nature and as such are confidential.  Any unauthorized
-- use or disclosure of such information may result in civil
--  liabilities.

--   Copyright 2018 by DST Systems, Inc.
--   All Rights Reserved.

CREATE View vStatementInvestmentMapping AS

    SELECT 
        ProviderId,
        ACT1,
        ACT1Field,
        ACT2,
        ACT2Field,
        ACT3,
        ACT3Field,
        ACT4,
        ACT4Field,
        ACT5,
        ACT5Field,
        ACT6,
        ACT6Field,
        ACT7,
        ACT7Field,
        ACT8,
        ACT8Field,
        ACT9,
        ACT9Field,
        ACT10,
        ACT10Field,
        ACT11,
        ACT11Field,
        ACT12,
        ACT12Field,
        ACT13,
        ACT13Field,
        ACT14,
        ACT14Field,
        ACT15,
        ACT15Field,
        ACT16,
        ACT16Field,
        ACT17,
        ACT17Field,
        ACT18,
        ACT18Field,
        ACT19,
        ACT19Field,
        ACT20,
        ACT20Field
    FROM teStatementInvestmentMapping
GO

--GRANT SELECT ON vProviderMessage TO rMTaccess
--GO

IF OBJECT_ID( 'pStampVersion', 'V' ) IS NOT NULL
BEGIN
    EXEC pStampVersion '$Workfile: vStatementInvestmentMapping.sql $', '$Revision: 1 $'
END

GO
