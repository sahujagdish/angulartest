﻿//****************************************************************************
//*  $Archive:: /Database/SqlCLR/UserDefined/Functions/Aggregates/faMaxSortableGuid.cs $
//* $Workfile:: faMaxSortableGuid.cs                                        $
//*   $Author:: dbrown                                                      $
//* $Revision:: 1                                                           $
//*  $Modtime:: 2011-09-14 17:16:31-04:00                                   $
//****************************************************************************
//* Software distributed under the license is distributed on an "AS IS" basis,
//* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
//* for the specific language governing rights and limitations under the
//* license.
//*
//* Copyright (C) 2011 Newkirk Products Inc.
//* All Rights Reserved.
//****************************************************************************

#region Using
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
#endregion Using

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedAggregate( Format.UserDefined, MaxByteSize = 40 )]
public struct faMaxSortableGuid : IBinarySerialize
{
    #region Fields
    SortableGuid currentGuid;
    #endregion

    #region Properties
    /// <summary>
    ///     Gets the current aggregate item
    /// </summary>
    public SortableGuid CurrentGuid
    {
        get
        {
            return currentGuid;
        }
    }
    #endregion

    #region Required Methdos
    /// <summary>
    ///     Initializes the aggregate
    /// </summary>
    public void Init()
    {
        currentGuid = new SortableGuid( SqlInt32.MinValue, SqlGuid.Null );
    }

    /// <summary>
    ///     Accumulates the next item into the aggregate
    /// </summary>
    /// <param name="value">
    ///     The item to accumulate
    /// </param>
    public void Accumulate( SortableGuid value )
    {
        if( value > currentGuid )
            currentGuid = value;
    }

    /// <summary>
    ///     Merges an aggregate group with the current item
    /// </summary>
    /// <param name="group">
    ///     The group to merge
    /// </param>
    public void Merge( faMaxSortableGuid group )
    {
        if( group.CurrentGuid > currentGuid )
            currentGuid = group.CurrentGuid;
    }

    /// <summary>
    ///     Ends the aggregate call and returns the value
    /// </summary>
    /// <returns>
    ///     The value of the aggregate
    /// </returns>
    public SqlGuid Terminate()
    {
        return currentGuid.Value;
    }
    #endregion

    #region IBinarySerialize Members
    /// <summary>
    ///     Deserializes the aggregate from a stream
    /// </summary>
    /// <param name="r">
    ///     The stream to read from
    /// </param>
    public void Read( System.IO.BinaryReader reader )
    {
        currentGuid = SortableGuid.Parse( reader.ReadString() );
    }

    /// <summary>
    ///     Serializes the aggregate to a a stream
    /// </summary>
    /// <param name="w">
    ///     The stream to write to
    /// </param>
    public void Write( System.IO.BinaryWriter writer )
    {
        if( !currentGuid.Value.IsNull )
            writer.Write( currentGuid.ToString() );
    }

    #endregion
}

//****************************************************************************
//* $Log: /Database/SqlCLR/UserDefined/Functions/Aggregates/faMaxSortableGuid.cs $
// 
// Revision: 1   Date: 2011-09-14 21:16:32Z   User: dbrown 
// 
