﻿//****************************************************************************
//*  $Archive:: /Database/SqlCLR/UserDefined/Types/SortableGuid.cs          $
//* $Workfile:: SortableGuid.cs                                             $
//*   $Author:: dbrown                                                      $
//* $Revision:: 1                                                           $
//*  $Modtime:: 2011-09-14 17:16:32-04:00                                   $
//****************************************************************************
//* Software distributed under the license is distributed on an "AS IS" basis,
//* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the license
//* for the specific language governing rights and limitations under the
//* license.
//*
//* Copyright (C) 2011 Newkirk Products Inc.
//* All Rights Reserved.
//****************************************************************************

#region Using
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
#endregion Using

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedType( Format.UserDefined, MaxByteSize = 40 )]
public struct SortableGuid : INullable, IBinarySerialize
{
    #region Fields
    private SqlInt32 sortOrder;
    private SqlGuid value;

    private bool m_Null;
    #endregion

    #region Properties
    /// <summary>
    ///     Gets the sort order for this guid
    /// </summary>
    public SqlInt32 SortOrder
    {
        get { return sortOrder; }
    }

    /// <summary>
    ///     Gets the value of the guid
    /// </summary>
    public SqlGuid Value
    {
        get { return value; }
    }

    /// <summary>
    ///     Gets whether or not this guid is NULL
    /// </summary>
    public bool IsNull
    {
        get
        {
            return m_Null;
        }
    }

    /// <summary>
    ///     Gets a null SortableGuid
    /// </summary>
    public static SortableGuid Null
    {
        get
        {
            SortableGuid h = new SortableGuid( SqlInt32.Null, SqlGuid.Null );
            h.m_Null = true;
            return h;
        }
    }

    #endregion

    #region Constructors
    /// <summary>
    ///     Initializes a SortableGuid withe the specified valud and sort order
    /// </summary>
    /// <param name="sortOrder">
    ///     The sort order of the guid
    /// </param>
    /// <param name="value">
    ///     The value of the guid
    /// </param>
    public SortableGuid( SqlInt32 sortOrder, SqlGuid value )
    {
        this.sortOrder = sortOrder;
        this.value = value;

        m_Null = false;
    }
    #endregion

    #region Public Methods
    /// <summary>
    ///     Returns a string representation of this object
    /// </summary>
    /// <returns>
    ///     This object as a string in the form SortOrder,Guid
    /// </returns>
    public override string ToString()
    {
        System.Text.StringBuilder builder = new System.Text.StringBuilder();

        if( !IsNull )
        {
            builder.Append( sortOrder.ToString() );
            builder.Append( "," );
            builder.Append( value.ToString() );
        }

        return builder.ToString();

    }

    /// <summary>
    ///     Parses a SortableGuid from the input string
    /// </summary>
    /// <param name="value">
    ///     The string to parse
    /// </param>
    /// <returns>
    ///     A SortablGuid parsed from the input string 
    ///     -or- 
    ///     a NULL SortableGuid if the string is not valid
    /// </returns>
    [SqlMethod( OnNullCall = false )]
    public static SortableGuid Parse( SqlString value )
    {
        int firstComma = value.Value.IndexOf( ',' );

        if( firstComma > 0 && firstComma < value.Value.Length - 1 )
        {
            SqlInt32 b = new SqlInt32( byte.Parse( value.Value.Substring( 0, firstComma ) ) );
            SqlGuid s = new SqlGuid( value.Value.Substring( firstComma + 1 ) );
            return new SortableGuid( b, s );
        }
        else
        {
            return Null;
        }
    }
    #endregion

    #region Operators
    /// <summary>
    ///     Overloaded operator to determine if one SortableGuid is less than other one
    /// </summary>
    /// <param name="a">
    ///     The first operand
    /// </param>
    /// <param name="b">
    ///     The second operand
    /// </param>
    /// <returns>
    ///     True if the first operand is less than the second, false otherwise
    /// </returns>
    public static SqlBoolean operator <( SortableGuid a, SortableGuid b )
    {
        return a.SortOrder < b.SortOrder;
    }

    /// <summary>
    ///     Overloaded operator to determine if one SortableGuid is greater than other one
    /// </summary>
    /// <param name="a">
    ///     The first operand
    /// </param>
    /// <param name="b">
    ///     The second operand
    /// </param>
    /// <returns>
    ///     True if the first operand is greater than the second, false otherwise
    /// </returns>
    public static SqlBoolean operator >( SortableGuid a, SortableGuid b )
    {
        return a.SortOrder > b.SortOrder;
    }

    /// <summary>
    ///     Overloaded operator to determine if one SortableGuid is less than or equal to other one
    /// </summary>
    /// <param name="a">
    ///     The first operand
    /// </param>
    /// <param name="b">
    ///     The second operand
    /// </param>
    /// <returns>
    ///     True if the first operand is less than or equal to the second, false otherwise
    /// </returns>
    public static SqlBoolean operator <=( SortableGuid a, SortableGuid b )
    {
        return a.SortOrder <= b.SortOrder;
    }

    /// <summary>
    ///     Overloaded operator to determine if one SortableGuid is greater than or equal to other one
    /// </summary>
    /// <param name="a">
    ///     The first operand
    /// </param>
    /// <param name="b">
    ///     The second operand
    /// </param>
    /// <returns>
    ///     True if the first operand is greater than or equal to the second, false otherwise
    /// </returns>
    public static SqlBoolean operator >=( SortableGuid a, SortableGuid b )
    {
        return a.SortOrder >= b.SortOrder;
    }
    #endregion

    #region IBinarySerialize Members
    /// <summary>
    ///     Reads a stream and populates this object from its contents. 
    ///     The Null SortableGuid will be used if the stream is not valid or empty.
    /// </summary>
    /// <param name="reader">
    ///     Reader of a binary stream
    /// </param>
    public void Read( System.IO.BinaryReader reader )
    {
        if( reader.PeekChar() > 0 )
        {
            sortOrder = new SqlInt32( reader.ReadInt32() );
            value = new SqlGuid( reader.ReadBytes( 36 ) );
        }
        else
        {
            sortOrder = SqlInt32.Null;
            value = SqlGuid.Null;
            m_Null = true;
        }
    }

    /// <summary>
    ///     If this object is not Null, writes it to a stream. 
    ///     Otherwise, does nothing.
    /// </summary>
    /// <param name="w">
    ///     The writer to use
    /// </param>
    public void Write( System.IO.BinaryWriter writer )
    {
        if( !IsNull )
        {
            writer.Write( sortOrder.Value );
            writer.Write( value.Value.ToByteArray() );
        }
    }
    #endregion
}

//****************************************************************************
//* $Log: /Database/SqlCLR/UserDefined/Types/SortableGuid.cs $
// 
// Revision: 1   Date: 2011-09-14 21:16:32Z   User: dbrown 
// 
