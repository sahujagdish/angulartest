import { DashboardComponent } from './dashboard/dashboard.component';
// import { ReturnrequestComponent } from './returnrequest/returnrequest.component';

import { ErrorComponent } from './error/error.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { loginlayoutcomponent } from './layout/loginlayout.component';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
import { AuthGuard } from './security/auth.guard';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { homelayoutcomponent } from './layout/homelayout.component';

// const appRoutes: Routes = [
//   { path: '', redirectTo: 'home', pathMatch: 'full' },
//   { path: 'home', component: LandingpageComponent },
//   { path: 'error', component: ErrorComponent, pathMatch: 'full' },
//    { path: 'returnrequest', loadChildren: './returnrequest/returnrequest.module#RequestModule'},
//   { path: 'dashboard', component: DashboardComponent},
//   { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule) },
//   { path: '**', redirectTo: '' }
// ];

export const appRoutes: Routes = [
  {
      path: '',
      component: homelayoutcomponent,
      children:[
      { path: '', redirectTo: 'home', pathMatch: 'full'},
      { path: 'home', component: LandingpageComponent, canActivate: [AuthGuard] },      
      { path: 'returnrequest', loadChildren: () => import('./returnrequest/returnrequest.module').then(r => r.RequestModule)},
      { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule), canActivate: [AuthGuard]},
      { path: 'error', component: ErrorComponent, pathMatch:'full'}
      ]
  },{
      path: '',
      component: loginlayoutcomponent,
      children:[
          { path: 'login', component: LoginComponent},
          { path: 'logout', component: LogoutComponent},         
          { path: 'accessdenied', component: AccessdeniedComponent}          
      ]
  },
  { path: '**', redirectTo: '' }   
  ];

  
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
