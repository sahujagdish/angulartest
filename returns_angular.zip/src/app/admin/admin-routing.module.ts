import { RoleaddressComponent } from './roleaddresses/roleaddresses.component';
import { ReasoncodesComponent } from './reasoncodes/reasoncodes.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RolesComponent } from './roles/roles.component';

export const adminRoutes: Routes = [
  {
    path: '', children: [
      { path: 'roles', component: RolesComponent },
      { path: 'reasoncodes', component: ReasoncodesComponent },
      { path: 'roleaddresses', component: RoleaddressComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
