
import { AdminService } from './../../services/admin.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminRoutingModule } from './admin-routing.module';
import { RolesComponent } from './roles/roles.component';
import { ReasoncodesComponent } from './reasoncodes/reasoncodes.component';
import { RoleaddressComponent } from './roleaddresses/roleaddresses.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ConfigFactory, ConfigService, dev } from 'src/services/config.service';




@NgModule({
  declarations: [RolesComponent, ReasoncodesComponent, RoleaddressComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    CommonModule,
    NgxPaginationModule
  ],
  providers:[AdminService,ConfigService,
    { provide:'config.json', useValue:'./assets/config.json'}, 
  { provide:'BASE-API-VARIABLE',useValue:'config'},
  {
    provide:dev, useFactory:ConfigFactory,
    deps:[ConfigService,'config.json','BASE-API-VARIABLE']
  }]
})

export class AdminModule { }
