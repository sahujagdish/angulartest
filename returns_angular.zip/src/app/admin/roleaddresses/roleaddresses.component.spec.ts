import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleaddressesComponent } from './roleaddresses.component';

describe('RoleaddressesComponent', () => {
  let component: RoleaddressesComponent;
  let fixture: ComponentFixture<RoleaddressesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoleaddressesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleaddressesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
