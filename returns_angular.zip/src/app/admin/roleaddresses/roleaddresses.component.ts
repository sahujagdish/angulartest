import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { AdminService } from '../../../services/admin.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../../services/storage.service';
import { AlertService } from '../../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { environment } from '../../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'roleaddresses',
  templateUrl: './roleaddresses.component.html'
})
export class RoleaddressComponent implements OnInit {
  items: any;
  RoleList: any;
  @ViewChild('addroleaddress') el: ElementRef;
  private route: ActivatedRoute;
  roleaddressId: number;
  addshowhide: boolean = true;
  EditShowHide: boolean = true;
  CreateShowHide: boolean = false;
  UpdateShowHide: boolean = false;
  CancelShowHide = false;
  reverse: boolean = false;
  frmroleaddress = new FormGroup({
    Roleid: new FormControl('', [Validators.required]),
    roleaddress: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'roleaddress',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
  };

  roleaddressParam = environment.pagination;

  constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _AdminService: AdminService, private alertService: AlertService, private storage: StorageService) { }

  ngOnInit() {
    this.roleaddressParam.PageSelected = 0;
    this.Getroleaddress();
    this.GetRoles();
  }

  SortOder(sortBy) {
    if (this.roleaddressParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.roleaddressParam.SortOrder = "DESC"
    } else {
      this.roleaddressParam.SortOrder = "ASC"
    }
    this.roleaddressParam.SortColumnName = sortBy;
    this.Getroleaddress();
  }

  Cancel() {
    this.roleaddressId = 0;
    this.frmroleaddress.setValue({ roleaddress: "", Roleid: "" });
    this.addshowhide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide = false;
    this.CancelShowHide = false;
  }

  Getroleaddress() {
    debugger;
    this.SpinnerService.show();
    this._AdminService.getroleaddresssdetail(this.roleaddressParam).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;
      this.config.totalItems = JSON.parse(data).page.TotalCount;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.roleaddressParam.PageSelected = event;
    this.Getroleaddress();
  }

  Editroleaddress(item) {

    debugger;
    this.roleaddressId = item.Id;
    this.frmroleaddress.setValue({
      Roleid: item.Roleid,
      roleaddress: item.Addresses
    });

    this.EditShowHide = false;
    this.addshowhide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide = true;
    this.CancelShowHide = true;
  }

  Deleteroleaddress(roleaddressId) {
    var meet = confirm("Are you sure you want to delete this record?");
    if (meet) {
      this.SpinnerService.show();

      this._AdminService.Deleteroleaddress(roleaddressId).subscribe((data: any) => {
        if (data == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record deleted successfully");
          this.roleaddressParam.SortOrder = "DESC";
          this.Getroleaddress();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while deleteing the record");
        }
      });
    }
  }

  addAddress() {
    this.roleaddressId = 0;
    this.addshowhide = false;
    this.EditShowHide = false;
    this.CreateShowHide = true;
    this.UpdateShowHide = false;
    this.CancelShowHide = true;
  }

  validateEmail(email) {
    const regularExpression = /^([\w+-.%]+@[\w.-]+\.[A-Za-z]{2,4})([\W]*;{1}[\W]*[\w+-.%]+@[\w.-]+\.[A-Za-z]{2,4})*$/;
    
    ///^([\w+-.%]+@[\w-.]+\.[A-Za-z ]{2,4},?)+$/;
    
    ///^[\W]*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4}[\W]*,{1}[\W]*)*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4})[\W]*$/ ;
    
    
    return regularExpression.test(String(email).toLowerCase());
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';
      Object.keys(frmM.controls).forEach((key) => {
        if (key === "Roleid") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please select a role" + "<br/>";
            } else {
              invalidfield += "Please select a role" + "<br/>";
            }
          }
        }
        if (key === "roleaddress") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter role address" + "<br/>";
            } else {
              invalidfield += "Please enter role address" + "<br/>";
            }
          }
          debugger;         
          if (!this.validateEmail(frmM.get(key).value)) {
            if (invalidfield == '') {
              invalidfield = "Please enter correct emailid in role addresses" + "<br/>";
            } else {
              invalidfield += "Please enter correct emailid in role addresses" + "<br/>";
            }
          }
          
        }
        
      });
      if(invalidfield != ""){
        this.alertService.showError(invalidfield);
      }     
    
    return invalidfield;
  }

  GetRoles() {
    this._AdminService.GetRoles().subscribe((data: any) => {
      this.RoleList = JSON.parse(data);
    });
  }

  Createroleaddress() {
    var isvalid =  this.Validation(this.frmroleaddress);
    if(isvalid != "") {
       return;
    }   
    let roleaddressModel = {
      Id: 0,
      Roleid: this.frmroleaddress.get('Roleid').value,
      Addresses: this.frmroleaddress.get('roleaddress').value
      //Createdby: "jagdish"
    }
    this.SpinnerService.show();
    let retvalue = this._AdminService.InsertUpdateroleaddress(roleaddressModel);
    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        this.alertService.showError("Error while creating the record");
        return of(null);
      })).subscribe((value: any) => {
        debugger;
        if (value == "roleaddressexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Role address already exists");
          return;
        }
        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record created successfully");
          this.roleaddressParam.SortOrder = "DESC";
          this.Getroleaddress();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating the record");
        }
      })
  }

  Updateroleaddress() {
    var isvalid =  this.Validation(this.frmroleaddress);
    if(isvalid != "") {
       return;
    }

    let roleaddressModel = {
      Id: this.roleaddressId,
      Roleid: this.frmroleaddress.get('Roleid').value,
      Addresses: this.frmroleaddress.get('roleaddress').value
      //Modifiedby: "jagdish"
    }

    debugger;
    this.SpinnerService.show();
    let retvalue = this._AdminService.InsertUpdateroleaddress(roleaddressModel);

    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        alert("Error while creating record!!!");
        return of(null);
      })).subscribe((value: any) => {
        if (value == "roleaddressexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Role address already exists");
          return;
        }
        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record updated successfully");
          this.roleaddressParam.SortOrder = "DESC";
          this.Getroleaddress();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating the record");
        }
      })
  }
}