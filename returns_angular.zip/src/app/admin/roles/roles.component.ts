import { AdminService } from './../../../services/admin.service';
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { AlertService } from 'src/services/alert.service';



@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {

  roles: string[] = [];

  constructor(private _adminService: AdminService, private _spinnerService: NgxSpinnerService, private _alertService: AlertService) {
  }

  ngOnInit(): void {
    this.GetRoles();
  }

  GetRoles() {
    this._spinnerService.show();
    this._adminService.GetRoles().subscribe((data: any) => {
      this.roles = JSON.parse(data);
      setTimeout(() => { this._spinnerService.hide(); }, 500);
    },error => {
        console.log(error.message);
        setTimeout(() => { this._spinnerService.hide() }, 500);
        this._alertService.showError("Error occurred while loading the roles");
      });

  }
}
