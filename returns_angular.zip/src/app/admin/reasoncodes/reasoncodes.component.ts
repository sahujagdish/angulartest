import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { AdminService } from '../../../services/admin.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../../services/storage.service';
import { AlertService } from '../../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { environment } from '../../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'reasoncode',
  templateUrl: './reasoncodes.component.html'
})
export class ReasoncodesComponent implements OnInit {
  items: any;
  @ViewChild('addreasoncode') el: ElementRef;
  private route: ActivatedRoute;
  reasoncodeId: number;
  addshowhide: boolean = true;
  EditShowHide: boolean = true;
  CreateShowHide: boolean = false;
  UpdateShowHide: boolean = false;
  CancelShowHide = false;
  reverse: boolean = false;
  frmreasoncode = new FormGroup({
    reasoncode: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'reasoncode',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
  };

  reasoncodeParam = environment.pagination;

  constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _AdminService: AdminService, private alertService: AlertService, private storage: StorageService) { }

  ngOnInit() {
    this.reasoncodeParam.PageSelected = 0;
    this.Getreasoncode();
  }

  SortOder(sortBy) {
    if (this.reasoncodeParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.reasoncodeParam.SortOrder = "DESC"
    } else {
      this.reasoncodeParam.SortOrder = "ASC"
    }
    this.reasoncodeParam.SortColumnName = sortBy;
    this.Getreasoncode();
  }

  Cancel() {
    this.reasoncodeId = 0;
    this.frmreasoncode.setValue({ reasoncode: "" });
    this.addshowhide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide = false;
    this.CancelShowHide = false;
  }

  Getreasoncode() {
    this.SpinnerService.show();
    debugger;
    this._AdminService.getreasoncodesdetail(this.reasoncodeParam).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;
      this.config.totalItems = JSON.parse(data).page.TotalCount;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.reasoncodeParam.PageSelected = event;
    this.Getreasoncode();
  }

  Editreasoncode(item) {
    debugger;
    this.reasoncodeId = item.Id;
    this.frmreasoncode.setValue({
      reasoncode: item.Reasoncode
    });

    this.EditShowHide = false;
    this.addshowhide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide = true;
    this.CancelShowHide = true;
  }

  Deletereasoncode(reasoncodeId) {
    var meet = confirm("Are you sure you want to delete this record?");
    if (meet) {
      this.SpinnerService.show();

      this._AdminService.Deletereasoncode(reasoncodeId).subscribe((data: any) => {
        if (data == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record deleted successfully");
          this.reasoncodeParam.SortOrder = "DESC";
          this.Getreasoncode();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while deleteing the record");
        }
      });
    }
  }

  addreason() {
    debugger;
    this.reasoncodeId = 0;
    this.addshowhide = false;
    this.EditShowHide = false;
    this.CreateShowHide = true;
    this.UpdateShowHide = false;
    this.CancelShowHide = true;
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';

    if (frmM.invalid) {
      Object.keys(frmM.controls).forEach((key) => {
        if (key === "reasoncode") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter a reason code" + "<br/>";
            } else {
              invalidfield += "Please enter a reason code" + "<br/>";
            }
          }
        }
      });
      this.alertService.showError(invalidfield);
    }
  }

  Createreasoncode() {
    if (this.frmreasoncode.invalid) {
      this.Validation(this.frmreasoncode);
      return;
    }
    let reasoncodeModel = {
      Reasoncode: this.frmreasoncode.get('reasoncode').value
     // Createdby: "jagdish"
    }
    this.SpinnerService.show();
    let retvalue = this._AdminService.InsertUpdatereasoncode(reasoncodeModel);
    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        this.alertService.showError("Error while creating the record");
        return of(null);
      })).subscribe((value: any) => {
        debugger;
        if (value == "reasoncodeexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Reason code already exists");
          return;
        }
        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record created successfully");
          this.reasoncodeParam.SortOrder = "DESC";
          this.Getreasoncode();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating the record");
        }
      })
  }

  Updatereasoncode() {
    if (this.frmreasoncode.invalid) {
      this.Validation(this.frmreasoncode);
      return;
    }

    let reasoncodeModel = {
      Id: this.reasoncodeId,
      Reasoncode: this.frmreasoncode.get('reasoncode').value
      //Modifiedby: "jagdish"
    }

    this.SpinnerService.show();
    let retvalue = this._AdminService.InsertUpdatereasoncode(reasoncodeModel);

    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        alert("Error while creating record");
        return of(null);
      })).subscribe((value: any) => {
        if (value == "reasoncodeexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Reason code already exists");
          return;
        }
        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record updated successfully");
          this.reasoncodeParam.SortOrder = "DESC";
          this.Getreasoncode();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating the record");
        }
      })
  }
}