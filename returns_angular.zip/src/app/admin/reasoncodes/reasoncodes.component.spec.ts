import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasoncodesComponent } from './reasoncodes.component';

describe('ReasoncodesComponent', () => {
  let component: ReasoncodesComponent;
  let fixture: ComponentFixture<ReasoncodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReasoncodesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasoncodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
