import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/services/common.service';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

  public errormessage: any;
  private _serviceSubscription;

  constructor(private service: CommonService, private SpinnerService: NgxSpinnerService,private route: ActivatedRoute, private router: Router) {
    this.SpinnerService.hide();
    debugger;
    this._serviceSubscription = this.service.onChange.subscribe({
      next: (event: any) => {
        debugger;
          console.log(`Received message # ${event.message["message"]}`);
          if(this.errormessage != undefined)
          this.errormessage = event.message["message"];
      }
    })
   }

  ngOnInit() {
    
  }
}
