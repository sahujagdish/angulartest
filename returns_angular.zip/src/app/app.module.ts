import { AlertService } from './../services/alert.service';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, ErrorHandler, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { FooterComponent } from './menu/footer.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { ErrorComponent } from './error/error.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxSpinnerModule } from 'ngx-spinner';
import {NgxPaginationModule} from 'ngx-pagination'
import { ToastrModule } from 'ngx-toastr';
import { DashboardComponent } from './dashboard/dashboard.component';
import { loginlayoutcomponent } from './layout/loginlayout.component';
import { homelayoutcomponent } from './layout/homelayout.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthenticateService } from 'src/services/authenticate.service';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
import { StorageService } from 'src/services/storage.service';
import { AuthService } from './security/auth.service';
import { AuthGuard } from './security/auth.guard';
import { CustomAuthInterceptor } from 'src/services/custom-auth.interceptor';
import { globalerrorhandler } from 'src/services/globalerrorhandler';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonService } from 'src/services/common.service';
import { ConfigFactory, ConfigService, dev } from 'src/services/config.service';
@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    FooterComponent,
    LandingpageComponent,
    ErrorComponent,
    DashboardComponent,
    AccessdeniedComponent,
    loginlayoutcomponent,
    LogoutComponent,
    LoginComponent,
    homelayoutcomponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxSpinnerModule,
    BrowserAnimationsModule,
    NgxPaginationModule,
    ToastrModule.forRoot()
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  providers: [AlertService, AuthenticateService, StorageService, CommonService, ConfigService, AuthService, AuthGuard,    
    { provide: HTTP_INTERCEPTORS, useClass: CustomAuthInterceptor, multi: true },     
    { provide:ErrorHandler, useClass:globalerrorhandler},
    { provide:'config.json', useValue:'./assets/config.json'}, 
    { provide:'BASE-API-VARIABLE',useValue:'config'},
    {
      provide:dev, useFactory:ConfigFactory,
      deps:[ConfigService,'config.json','BASE-API-VARIABLE']
    }
  ],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
