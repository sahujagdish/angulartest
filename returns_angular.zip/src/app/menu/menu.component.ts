import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './../security/auth.service'; 
import { StorageService } from '../../services/storage.service'; 
import jwt_decode from "jwt-decode";
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  username : any;        
    isLoggedIn$: Observable<boolean>;
    groups : any;
    isAdmin:boolean = false;
    isUser:boolean = false;
    hotUser:boolean = false;
    constructor(private router: Router, private activatedRoute: ActivatedRoute, public storage: StorageService, private authService: AuthService) {
       
        const items = { ...localStorage };
        if(items.TokenInfo != undefined) {
            var clienttoken = jwt_decode(JSON.parse(items.TokenInfo).access_token); 
            console.log(clienttoken);      
            this.username = clienttoken["firstname"] + " " + clienttoken["lastname"];
            this.groups = clienttoken["groups"].split(',');
            this.isAdmin = this.groups.indexOf("GPI - HOT- Admin",0) != -1;
            this.isUser = this.groups.indexOf("GPI - HOT- User",0) != -1;
            this.hotUser = this.isAdmin || this.isUser;
            if(!this.hotUser){
                this.router.navigate(['/accessdenied']);
            }
        }
    }

    onLogout() {
        this.authService.logout();
    }

    ngOnInit() { 
    }   

    ngOnChanges() {   
         
    }

}
