import { TestBed, async, ComponentFixture, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminService } from '../../services/admin.service';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { RolesComponent } from '../admin/roles/roles.component';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from '../admin/admin-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { DebugElement, Renderer2 } from '@angular/core';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { ReturnServiceMock } from 'src/services/ReturnServiceMock.service';
describe('RolesComponent', () => {

  let component: RolesComponent;
  let fixture: ComponentFixture<RolesComponent>;
  let AdminService: AdminService;
  let alertService: AlertService;
  let toastService: ToastrService;


  beforeEach(async(() => {

    // declaring Mills component 
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AdminRoutingModule,
        CommonModule,
        FormsModule,
        ToastrModule.forRoot(),
        ReactiveFormsModule,
        NgxPaginationModule,
        HttpClientModule
      ],
      declarations: [RolesComponent],
      providers: [AdminService, AlertService, NgxSpinnerService, StorageService]
    }
    );

    // Configuring component with mock services

    TestBed.overrideComponent(
      RolesComponent,
      {
        set: {
          providers: [{ provide: AdminService, useClass: ReturnServiceMock }]
        //   { provide: AlertService, useClass: AlertServiceMock }]
        }
      }
    );

    // creating component fixture
    fixture = TestBed.createComponent(RolesComponent)

    // get the component from fixturew
    component = fixture.componentInstance;

    AdminService = fixture.debugElement.injector.get(AdminService);
    alertService = fixture.debugElement.injector.get(AlertService);
    fixture.autoDetectChanges(true);
  }));

  it('RolesComponent', () => {    
    expect(component).toBeTruthy;
  });

  it('Mills title', () => {
      const bannerDe: DebugElement = fixture.debugElement;
      const bannerEl: HTMLElement = bannerDe.nativeElement;
      const p = bannerEl.querySelector('h4');
      console.log(p.textContent);
      fixture.detectChanges();
      expect(p.textContent).toEqual('Roles');
  });
});