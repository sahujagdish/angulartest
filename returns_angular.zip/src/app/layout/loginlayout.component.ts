import { Component } from '@angular/core';

@Component({
    selector: 'app-login-layout',
    template: `<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"><a class="navbar-brand logo" href="#"></a></nav><router-outlet></router-outlet><app-footer></app-footer>
    <ngx-spinner bdColor="rgba(140,140,140,0.8)" size="medium"></ngx-spinner>`
})

export class loginlayoutcomponent {

}
