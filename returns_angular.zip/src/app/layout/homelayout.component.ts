import {Component} from '@angular/core';

@Component({
    selector:'app-home-layout',
    template:`<app-menu></app-menu><router-outlet></router-outlet><app-footer></app-footer><ngx-spinner bdColor="rgba(140,140,140,0.8)" size="medium">
    </ngx-spinner>`
})

export class homelayoutcomponent{

}