import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ReturnrequestComponent} from '../returnrequest/returnrequest.component';

export const returnrequestRoutes: Routes = [
  {
    path: '', component: ReturnrequestComponent,
        children:[
          {path: 'requestdetails', loadChildren: () => import('../returnrequest/requestdetails/requestdetails.module').then(m => m.RequestdetailsModule)}, 
          {path: 'requestdetails/:id', loadChildren: () => import('../returnrequest/requestdetails/requestdetails.module').then(m => m.RequestdetailsModule)}, 
          {path:'processtype', loadChildren: () => import('../returnrequest/processtype/processtype.module').then(p => p.ProcesstypeModule)},
          {path:'processtrackercommentary', loadChildren: () => import('../returnrequest/processtrackercommentary/processtrackercommentary.module').then(p => p.ProcesstrackercommentaryModule)},
          {path:'processtrackercommentary/:id', loadChildren: () => import('../returnrequest/processtrackercommentary/processtrackercommentary.module').then(p => p.ProcesstrackercommentaryModule)},
          {path:'batchorder', loadChildren: () => import('../returnrequest/batchorder/batchorder.module').then(p => p.BatchorderModule)},
          {path:'summary', loadChildren: () => import('../returnrequest/summary/summary.module').then(p => p.SummaryModule)},
          {path:'logs', loadChildren: () => import('../returnrequest/logs/logs.module').then(p => p.logsModule)},
        ]
      },
      // { path: 'requestdetails', loadChildren: () => import('../returnrequest/requestdetails/requestdetails.module').then(m => m.RequestdetailsModule)},   
    
];

@NgModule({
  imports: [RouterModule.forChild(returnrequestRoutes)],
  exports: [RouterModule]
})
export class RequestRoutingModule { }
