import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestdetailsComponent } from './requestdetails.component';

export const requestdetailsRoutes: Routes = [
    {path: '', component: RequestdetailsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(requestdetailsRoutes)],
  exports: [RouterModule]
})
export class RequestdetailsRoutingModule { }
