import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { RequestService } from 'src/services/request.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AlertService } from 'src/services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'requestdetails',
  templateUrl: './requestdetails.component.html'
})
export class RequestdetailsComponent implements OnInit {  
 
  constructor(private SpinnerService: NgxSpinnerService, private alertService: AlertService, private requestService: RequestService) { }
  
  ngOnInit() {
    this.Getreasoncode();
  }

  @ViewChild('fileInput') fileInput: ElementRef;

  filename = '';
  file:File;
  reasoncodelist:any;
  Excuteshpmntoutsidesystem:boolean = false;
  Freightcostreqd:boolean = false;
  frmrequestdetail = new FormGroup({
    Prioritylevel: new FormControl('', [Validators.required]),
    Reasoncodeid: new FormControl('', [Validators.required]),
    Reasonforrequest: new FormControl(''),
    //Attachments: new FormControl(''),
    Custreqpickupdate: new FormControl('', [Validators.required]),
    Custreqpickuptime: new FormControl('', [Validators.required]),
    Carrschdpickupdate: new FormControl('', [Validators.required]),
    Carrschdpickuptime: new FormControl('', [Validators.required]),
    Freightcostreqd: new FormControl(false, [Validators.required]),
    Freightcostamount: new FormControl('', [Validators.required]),
    Excuteshpmntoutsidesystem: new FormControl(false, [Validators.required]),
    Pickaddrandcontactinfo: new FormControl('', [Validators.required]),
    Delivaddrandcontactinfo: new FormControl('', [Validators.required]),
    Custdelivinstructions: new FormControl('', [Validators.required])
  }); 

  setFilename = function(files){
    if (files[0]) {
      var filesize = ((files[0].size/1024)/1024).toFixed(4);
      if(parseFloat(filesize) > 2.0) {
      this.filename = "";
      files = "";
      this.fileInput.nativeElement.value = "";
      this.alertService.showError("File size cannot be greate than 2 MB ");
      } else {        
        this.file = files[0];
        this.filename = files[0].name;
      }
    }
  }

  Getreasoncode() {
    this.SpinnerService.show();
    debugger;
    this.requestService.getreasoncode().subscribe((data: any) => {
      debugger;
      this.reasoncodelist = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';
      Object.keys(frmM.controls).forEach((key) => {
        if (key === "Prioritylevel") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please select Prioritylevel" + "<br/>";
            } else {
              invalidfield += "Please select Prioritylevel" + "<br/>";
            }
          }
        }
        if (key === "Reasoncodeid") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please select Reason code" + "<br/>";
            } else {
              invalidfield += "Please select Reason code" + "<br/>";
            }
          }
        }
           
        if (key === "Custreqpickupdate") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter Customer Requested Pickup Date" + "<br/>";
            } else {
              invalidfield += "Please enter Customer Requested Pickup Date" + "<br/>";
            }
          }
        }
        if (key === "Custreqpickuptime") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter Customer Requested Pickup time" + "<br/>";
            } else {
              invalidfield += "Please enter Customer Requested Pickup time" + "<br/>";
            }
          }
        }
        if (key === "Carrschdpickupdate") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter Carrier Scheduled Pickup Date" + "<br/>";
            } else {
              invalidfield += "Please enter Carrier Scheduled Pickup Date" + "<br/>";
            }
          }
        }
        if (key === "Freightcostamount") {
          debugger;
          if (frmM.get("Freightcostreqd").value == true) {
            if (frmM.get("Freightcostamount").value == "") {
              if (invalidfield == '') {
                invalidfield = "Please enter Freight Cost Amount " + "<br/>";
              } else {
                invalidfield += "Please enter Freight Cost Amount" + "<br/>";
              }
            }
          }
        }
        if (key === "Pickaddrandcontactinfo") {
          if (frmM.get("Excuteshpmntoutsidesystem").value == true) {
          if (frmM.get("Pickaddrandcontactinfo").value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter Pick-up Address & Contact Information" + "<br/>";
            } else {
              invalidfield += "Please enter Pick-up Address & Contact Information" + "<br/>";
            }
          }
        }
        }
        if (key === "Delivaddrandcontactinfo") {
          if (frmM.get("Excuteshpmntoutsidesystem").value == true) {
          if (frmM.get("Delivaddrandcontactinfo").value == "") {
            if (invalidfield == '') {
              invalidfield = "Please enter Delivery Address & Contact Information" + "<br/>";
            } else {
              invalidfield += "Please enter Delivery Address & Contact Information" + "<br/>";
            }
          }
        }
        }
        // if (key === "Custdelivinstructions") {
        //   if (frmM.get(key).value == "") {
        //     if (invalidfield == '') {
        //       invalidfield = "Please enter Customer Delivery Instructions" + "<br/>";
        //     } else {
        //       invalidfield += "Please enter Customer Delivery Instructions" + "<br/>";
        //     }
        //   }
        // }
        
      });
      if(invalidfield != ""){
        this.alertService.showError(invalidfield);
      }     
    
    return invalidfield;
  }

  save() {

    var isvalid =  this.Validation(this.frmrequestdetail);
    if(isvalid != "") {
       return;
    } 

    const formData = new FormData();
    if (this.file) {
      formData.append("attachments", this.file);
    }

  let requestdetailmodel = {
    Id:0,
    Status:0,
    Prioritylevel: this.frmrequestdetail.get('Prioritylevel').value,
    Reasoncodeid: this.frmrequestdetail.get('Reasoncodeid').value,
    Reasonforrequest: this.frmrequestdetail.get('Reasonforrequest').value,
    //Attachments: files[0].name,
    Custreqpickupdate: this.frmrequestdetail.get('Custreqpickupdate').value,
    Custreqpickuptime: this.frmrequestdetail.get('Custreqpickuptime').value,
    Carrschdpickupdate: this.frmrequestdetail.get('Carrschdpickupdate').value,
    Carrschdpickuptime: this.frmrequestdetail.get('Carrschdpickuptime').value,
    Freightcostreqd: this.frmrequestdetail.get('Freightcostreqd').value  == "" ? false:  this.frmrequestdetail.get('Freightcostreqd').value,
    Freightcostamount: this.frmrequestdetail.get('Freightcostamount').value == "" ? 0.00 : parseFloat(this.frmrequestdetail.get('Freightcostamount').value),
    Excuteshpmntoutsidesystem: this.frmrequestdetail.get('Excuteshpmntoutsidesystem').value == "" ? false: this.frmrequestdetail.get('Excuteshpmntoutsidesystem').value,
    Pickaddrandcontactinfo: this.frmrequestdetail.get('Pickaddrandcontactinfo').value,
    Delivaddrandcontactinfo: this.frmrequestdetail.get('Delivaddrandcontactinfo').value,
    Custdelivinstructions: this.frmrequestdetail.get('Custdelivinstructions').value
    };

  formData.append("data",JSON.stringify(requestdetailmodel));
//requestdetailmodel

    this.SpinnerService.show();
    //let retvalue = this.requestService.InsertUpdateRequest(requestdetailmodel);
    let retvalue = this.requestService.upload(formData);
    retvalue.subscribe((value: any) => {
        debugger;        
        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record saved successfully");
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating the record");
        }
      })

  }
}
