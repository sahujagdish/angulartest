
import { RequestService } from '../../../services/request.service';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { RequestdetailsRoutingModule } from './requestdetails-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {RequestdetailsComponent} from './requestdetails.component';
import { TwoDigitDecimaNumberDirective } from '../../Custom/directives/TwoDigitDecimaNumberDirective';

@NgModule({
  declarations: [RequestdetailsComponent, TwoDigitDecimaNumberDirective],
  imports: [
    RequestdetailsRoutingModule,
    CommonModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
  ],
 
  providers:[RequestService]
})

export class RequestdetailsModule { }
