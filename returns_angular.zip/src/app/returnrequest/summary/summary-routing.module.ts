import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SummaryComponent} from '../summary/summary.component';
export const summaryRoutes: Routes = [
  {
    path: '', component: SummaryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(summaryRoutes)],
  exports: [RouterModule]
})
export class SummaryRoutingModule { }
