
import { RequestService } from '../../../services/request.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { SummaryRoutingModule } from './summary-routing.module';
// import {SummaryComponent} from '../summary/summary.component';

@NgModule({
  declarations: [],
  imports: [
    SummaryRoutingModule,
    CommonModule,
    NgxPaginationModule,
    // SummaryComponent
  ],
  providers:[RequestService]
})

export class SummaryModule { }
