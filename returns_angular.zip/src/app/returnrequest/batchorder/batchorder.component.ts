import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'batchorder',
  templateUrl: './batchorder.component.html',
  styleUrls: ['./batchorder.component.css']
})
export class BatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
