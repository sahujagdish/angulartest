import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BatchComponent} from './batchorder.component';

export const batchorderRoutes: Routes = [
  {
    path: '', component: BatchComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(batchorderRoutes)],
  exports: [RouterModule]
})
export class BatchorderRoutingModule { }
