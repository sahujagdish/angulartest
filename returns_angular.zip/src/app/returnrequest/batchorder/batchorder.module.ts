
import { RequestService } from '../../../services/request.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { BatchorderRoutingModule } from './batchorder-routing.module';
// import { BatchComponent } from './batchorder.component';

@NgModule({
  declarations: [],
  imports: [
    BatchorderRoutingModule,
    CommonModule,
    NgxPaginationModule,
  ],
  providers:[RequestService]
})

export class BatchorderModule { }
