import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnrequestComponent } from './batchorder.component';

describe('ReturnrequestComponent', () => {
  let component: ReturnrequestComponent;
  let fixture: ComponentFixture<ReturnrequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReturnrequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReturnrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
