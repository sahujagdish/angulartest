import { RequestService } from '../../../services/request.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { ProcesstrackercommentaryRoutingModule } from './processtrackercommentary-routing.module';
import {ProcesstrackercommentaryComponent} from './processtrackercommentary.component';
import { SplitAttendeesPipe } from '../../Custom/pipes/CustomPipes';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [ProcesstrackercommentaryComponent, SplitAttendeesPipe],
  imports: [
    ProcesstrackercommentaryRoutingModule,
    CommonModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers:[RequestService]
})

export class ProcesstrackercommentaryModule { }
