import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { RequestService } from 'src/services/request.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'Processtrackercommentary',
  templateUrl: './processtrackercommentary.component.html',
  styleUrls: ['./processtrackercommentary.component.css'], 
  encapsulation: ViewEncapsulation.None,
})
export class ProcesstrackercommentaryComponent implements OnInit {

  requestId : number;
  processtracker : [];
  frmprocesstracker: FormGroup;
  public processtrackerlist: FormArray;

  config = {
    id: 'roleaddress',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
  };

  constructor(private route: ActivatedRoute, private SpinnerService: NgxSpinnerService, private alertService: AlertService, private requestService: RequestService, private fb: FormBuilder) { }
  
  ngOnInit(): void {
    
    this.frmprocesstracker = this.fb.group({
      processtracker: this.fb.array([]),
      comment: new FormControl(""),
    });

    this.processtrackerlist = this.frmprocesstracker.get('processtracker') as FormArray;

    this.route.params.subscribe(params => {
      debugger;
     this.requestId = params.id; // --> Name must match wanted parameter
      if(params.id != undefined || params.id == "")
        this.GetProcessTrackerCommentary();
      });
  }

  getNotify(index:number) : FormArray {
    return this.processtrackerlist.at(index).get("roleaddress") as FormArray
  }

  markcomplete(val){
    debugger;
    let processtypemodel = {
      RequestId: this.requestId,
      Processstepsconfigid:val.value.processstepsconfigid,
    }

    this.SpinnerService.show();
      let retvalue = this.requestService.markcomplete(processtypemodel);
      retvalue.subscribe((value: any) => {
          debugger;        
          if (value > 0) {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showSuccess("Record saved successfully");
          } else {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showError("Error while creating the record");
          }
        })
  }

  save(){
    let processtypemodel = [];
    this.processtrackerlist.controls.forEach(element => {
      if(element['controls'].documentNumber.touched){
        let model = {DocumentNumber: element['controls'].documentNumber.value, 
                    Processstepsconfigid: element['controls'].processstepsconfigid.value};

        processtypemodel.push(model);
      }
    });

    let processTrackerInsertModel = { processTrackerCommentaryModel : processtypemodel, 
                                      RequestId: this.requestId, 
                                      Comment: this.frmprocesstracker.get('comment').value }

    this.SpinnerService.show();
      let retvalue = this.requestService.InsertUpdateProcessTracker(processTrackerInsertModel);
      retvalue.subscribe((value: any) => {
          debugger;        
          if (value > 0) {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showSuccess("Record saved successfully");
          } else {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showError("Error while creating the record");
          }
        })
  }

  public GetProcessTrackerCommentary() {
    this.SpinnerService.show();
    this.requestService.GetProcessTrackerCommentary(this.requestId).subscribe((data: any) => {     
      data.forEach((item, i) => {
        debugger;
        let fg = this.fb.group({
          statusName : item.statusName,
          step : item.step,
          role : item.role,
          facility:this.fb.array([]),
          roleaddress: this.fb.array([]),
          timestamp: item.timestamp,
          documentType:item.documentType,
          documentNumber : item.documentNumber,
          processstepsconfigid: item.processstepsconfigid,
          requestStatus: item.requestStatus
        });

        item.roleAddress.forEach((iter, i) => {
          let rd = this.fb.group({
            id:iter.id,
            name:iter.name,
            checked:false
          });

          (fg.controls.roleaddress as FormArray).push(rd);
        });

        debugger;
        item.facility.forEach((f, i) => {
          let fl = this.fb.group({
            id:f.id,
            name:f.name,
            checked:false
          });

          (fg.controls.facility as FormArray).push(fl);
        });
       
        this.processtrackerlist.push(fg);
      });
      setTimeout(() => { this.SpinnerService.hide() }, 0);
    });
  }


}
