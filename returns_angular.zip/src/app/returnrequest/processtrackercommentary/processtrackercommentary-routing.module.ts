import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ProcesstrackercommentaryComponent} from './processtrackercommentary.component';

export const processtrackercommentaryRoutes: Routes = [
  
    { path: '', component: ProcesstrackercommentaryComponent},
    // children:[
    //   { path: '/:id', component: ProcesstrackercommentaryComponent},
    // ]}
    //{ path: ':id', component: ProcesstrackercommentaryComponent},
    // path: '', children: [
    //    { path: 'processtrackercommentary', component: ProcesstrackercommentaryComponent  },   
    // ]
  
];

@NgModule({
  imports: [RouterModule.forChild(processtrackercommentaryRoutes)],
  exports: [RouterModule]
})
export class ProcesstrackercommentaryRoutingModule { }
