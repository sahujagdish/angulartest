import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcesstrackercommentaryComponent } from './processtrackercommentary.component';

describe('ReturnrequestComponent', () => {
  let component: ProcesstrackercommentaryComponent;
  let fixture: ComponentFixture<ProcesstrackercommentaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcesstrackercommentaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcesstrackercommentaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
