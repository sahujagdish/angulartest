import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcesstypeComponent } from './processtype.component';

describe('ProcessrequestComponent', () => {
  let component: ProcesstypeComponent;
  let fixture: ComponentFixture<ProcesstypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcesstypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcesstypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
