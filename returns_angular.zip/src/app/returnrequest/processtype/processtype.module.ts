
import { RequestService } from '../../../services/request.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { ProcesstypeRoutingModule } from './processtype-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {ProcesstypeComponent} from './processtype.component';

@NgModule({
  declarations: [ProcesstypeComponent],
  imports: [
    ProcesstypeRoutingModule,
    CommonModule,
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers:[RequestService]
})

export class ProcesstypeModule { }
