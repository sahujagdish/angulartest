import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProcesstypeComponent } from './processtype.component';

export const processtypeRoutes: Routes = [
  { path: '', component: ProcesstypeComponent }
];

@NgModule({
  imports: [RouterModule.forChild(processtypeRoutes)],
  exports: [RouterModule]
})
export class ProcesstypeRoutingModule { }
