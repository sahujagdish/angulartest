import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RequestService } from 'src/services/request.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AlertService } from 'src/services/alert.service';

@Component({
  selector: 'processtype',
  templateUrl: './processtype.component.html',
  styleUrls: ['./processtype.component.css']
})
export class ProcesstypeComponent implements OnInit,AfterViewInit {

  processtypevalue:string ="";
  items: item[];
  
  frmprocess = new FormGroup({
    Processtype: new FormControl("", [Validators.required]),
    DTShipmentOrigin: new FormControl("", [Validators.required]),
    DTOrgShipmentMaterial: new FormControl("", [Validators.required]),
    DTOrgShipmentTo: new FormControl("", [Validators.required]),
    DTDiversionTransferTo: new FormControl("", [Validators.required]),
    soldto: new FormControl("", [Validators.required]),
    soldtoaddress: new FormControl("", [Validators.required]),
    shipto: new FormControl("", [Validators.required]),
    shiptoaddress: new FormControl("", [Validators.required]),
    NPSOShipmentOrigin: new FormControl("", [Validators.required]),
    NPSOShipmentMaterial: new FormControl("", [Validators.required]),
    NPSODiversionTransferTo: new FormControl("", [Validators.required]),
    NPSOSoldTo: new FormControl("", [Validators.required]),
    NPSOSoldToAddress: new FormControl("", [Validators.required]),
    NPSOShipTo: new FormControl("", [Validators.required]),
    NPSOShipToAddress: new FormControl("", [Validators.required]),
    OvrgShipmentOrigin: new FormControl("", [Validators.required]),
    OvrgOrgShipmentMaterial: new FormControl("", [Validators.required]),
    OvrgOrgShipmentTo: new FormControl("", [Validators.required]),    
    PRShipmentOrigin: new FormControl("", [Validators.required]),
    PROrgShipmentMaterial: new FormControl("", [Validators.required]),
    PROrgShipmentTo: new FormControl("", [Validators.required]),
    SRShipmentReversal: new FormControl("", [Validators.required]),
    ShortageShipmentOrigin: new FormControl("", [Validators.required]),
    ShortageOrgShipmentMaterial: new FormControl("", [Validators.required]),
    ShortageOrgShipmentTo: new FormControl("", [Validators.required]),
    SPOShipmentOrigin: new FormControl("", [Validators.required]),
    SPOOrgShipmentMaterial: new FormControl("", [Validators.required]),
    SPOOrgShipmentTo: new FormControl("", [Validators.required]),
    VRShipmentOrigin: new FormControl("", [Validators.required]),
    VROrgShipmentMaterial: new FormControl("", [Validators.required]),
    VROrgShipmentTo: new FormControl("", [Validators.required]),
    ZKROrgShipmentMaterial: new FormControl("", [Validators.required]),
  });

  dtDiversionsortransferitems:[];
  dtOriginalshipmentmaterialitems:[];
  dtOriginalshipmenttoitems:[];
  dtShipmentoriginitems:[];
  NPSOShipmentOriginitems:[];
  NPSOShipmentMaterialitems:[];
  NPSODiversionTransferToitems:[];
  OvrgShipmentOriginitems:[];
  OvrgOrgShipmentMaterialitems:[];
  OvrgOrgShipmentToitems:[];
  PRShipmentOriginitems:[];
  PROrgShipmentMaterialitems:[];
  PROrgShipmentToitems:[];
  SRShipmentReversalitems:[];
  ShortageShipmentOriginitems:[];
  ShortageOrgShipmentMaterialitems:[];
  ShortageOrgShipmentToitems:[];
  SPOShipmentOriginitems:[];
  SPOOrgShipmentMaterialitems:[];
  SPOOrgShipmentToitems:[];
  VRShipmentOriginitems:[];
  VROrgShipmentMaterialitems:[];
  VROrgShipmentToitems:[];
  zkritems:[];

  constructor(private SpinnerService: NgxSpinnerService, private alertService: AlertService, private requestService: RequestService) { }
  ngOnInit(){
    this.FillProcesstype();    
  }

  public onProcesstypeSelected(event) {
      const value = event.target.value;
      let selectedtype = this.items.filter(function(e){ return e.id == value});
      console.log(value);
      this.processtypevalue = selectedtype[0].code;
      this.FillList();
  }  

  FillList(){
    if(this.processtypevalue == "dt"){
      this.GetDTDiversionsortransfer();
      this.GetDTOriginalshipmentmaterial();
      this.GetDTOriginalshipmentto()
      this.GetDTShipmentorigin();
    } else if(this.processtypevalue == "so"){  
      this.GetNPSOShipmentOrigin();
      this.GetNPSODiversionTransferTo();
      this.GetNPSOShipmentMaterial();
    } else if(this.processtypevalue == "ov"){
      this.GetOvrgShipmentOrigin();
      this.GetOvrgOrgShipmentMaterial();
      this.GetOvrgOrgShipmentTo();
    } else if(this.processtypevalue == "pr"){
      this.GetPROrgShipmentMaterial();
      this.GetPROrgShipmentTo();
      this.GetPRShipmentOrigin();
    } else if(this.processtypevalue == "sr"){
      this.GetSRShipmentReversal();
    } else if(this.processtypevalue == "sh"){
      this.GetShortageOrgShipmentMaterial();
      this.GetShortageOrgShipmentTo();
      this.GetShortageShipmentOrigin();
    } else if(this.processtypevalue == "sp"){
      this.GetSPOOrgShipmentMaterial();
      this.GetSPOOrgShipmentTo();
      this.GetSPOShipmentOrigin();
    } else if(this.processtypevalue == "vr"){
      this.GetVROrgShipmentMaterial();
      this.GetVROrgShipmentTo();
      this.GetVRShipmentOrigin();
    } else if(this.processtypevalue == "zk"){
      this.GetZKROriginalshipmentmaterials();
    }
  }

  public GetSoldtoAddress(event) {
    this.SpinnerService.show();
    this.requestService.GetCustomerAddress(event.target.value).subscribe((data: any) => {     
      this.frmprocess.controls.soldtoaddress.setValue(Object.values(data["eS_ADDRESS"]).splice(1).join(' '));
      setTimeout(() => { this.SpinnerService.hide() }, 0);
    });
  }

  public GetShiptoAddress(event) {
    this.SpinnerService.show();
    this.requestService.GetCustomerAddress(event.target.value).subscribe((data: any) => {
      this.frmprocess.controls.shiptoaddress.setValue(Object.values(data["eS_ADDRESS"]).splice(1).join(' '));
      setTimeout(() => { this.SpinnerService.hide() }, 0);
    });
  }

  public FillProcesstype() {    
    this.SpinnerService.show();
    this.requestService.GetProcessType().subscribe((data: any) => {
      debugger;
      this.items = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  } 

  public GetDTDiversionsortransfer() {    
    this.SpinnerService.show();
    this.requestService.GetDTDiversionsortransfer().subscribe((data: any) => {     
      this.dtDiversionsortransferitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetDTOriginalshipmentmaterial() {    
    this.SpinnerService.show();
    this.requestService.GetDTOriginalshipmentmaterial().subscribe((data: any) => {     
      this.dtOriginalshipmentmaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetDTOriginalshipmentto() {    
    this.SpinnerService.show();
    this.requestService.GetDTOriginalshipmentto().subscribe((data: any) => {     
      this.dtOriginalshipmenttoitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetDTShipmentorigin() {
    this.SpinnerService.show();
    this.requestService.GetDTShipmentorigin().subscribe((data: any) => {     
      this.dtShipmentoriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetNPSOShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetNPSOShipmentOrigin().subscribe((data: any) => {     
      this.NPSOShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetNPSOShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetNPSOShipmentMaterial().subscribe((data: any) => {     
      this.NPSOShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetNPSODiversionTransferTo() {    
    this.SpinnerService.show();
    this.requestService.GetNPSODiversionTransferTo().subscribe((data: any) => {     
      this.NPSODiversionTransferToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetOvrgShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetOvrgShipmentOrigin().subscribe((data: any) => {     
      this.OvrgShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetOvrgOrgShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetOvrgOrgShipmentMaterial().subscribe((data: any) => {     
      this.OvrgOrgShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetOvrgOrgShipmentTo() {    
    this.SpinnerService.show();
    this.requestService.GetOvrgOrgShipmentTo().subscribe((data: any) => {     
      this.OvrgOrgShipmentToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetPRShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetPRShipmentOrigin().subscribe((data: any) => {     
      this.PRShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetPROrgShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetPROrgShipmentMaterial().subscribe((data: any) => {     
      this.PROrgShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetPROrgShipmentTo() {    
    this.SpinnerService.show();
    this.requestService.GetPROrgShipmentTo().subscribe((data: any) => {     
      this.PROrgShipmentToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetSRShipmentReversal() {    
    this.SpinnerService.show();
    this.requestService.GetSRShipmentReversal().subscribe((data: any) => {     
      this.SRShipmentReversalitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetShortageShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetShortageShipmentOrigin().subscribe((data: any) => {     
      this.ShortageShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetShortageOrgShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetShortageOrgShipmentMaterial().subscribe((data: any) => {     
      this.ShortageOrgShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetShortageOrgShipmentTo() {    
    this.SpinnerService.show();
    this.requestService.GetShortageOrgShipmentTo().subscribe((data: any) => {     
      this.ShortageOrgShipmentToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetSPOShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetSPOShipmentOrigin().subscribe((data: any) => {     
      this.SPOShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetSPOOrgShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetSPOOrgShipmentMaterial().subscribe((data: any) => {     
      this.SPOOrgShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetSPOOrgShipmentTo() {    
    this.SpinnerService.show();
    this.requestService.GetSPOOrgShipmentTo().subscribe((data: any) => {     
      this.SPOOrgShipmentToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetVRShipmentOrigin() {    
    this.SpinnerService.show();
    this.requestService.GetVRShipmentOrigin().subscribe((data: any) => {     
      this.VRShipmentOriginitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetVROrgShipmentMaterial() {    
    this.SpinnerService.show();
    this.requestService.GetVROrgShipmentMaterial().subscribe((data: any) => {     
      this.VROrgShipmentMaterialitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetVROrgShipmentTo() {    
    this.SpinnerService.show();
    this.requestService.GetVROrgShipmentTo().subscribe((data: any) => {     
      this.VROrgShipmentToitems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  public GetZKROriginalshipmentmaterials() {    
    this.SpinnerService.show();
    this.requestService.GetZKROriginalShipmentMaterials().subscribe((data: any) => {     
      this.zkritems = data;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  

  ngAfterViewInit(){
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';
      Object.keys(frmM.controls).forEach((key) => {
       
        if (key === "Processtype") {
          if (frmM.get(key).value == "") {
            if (invalidfield == '') {
              invalidfield = "Please select Processtype" + "<br/>";
            } else {
              invalidfield += "Please select Processtype" + "<br/>";
            }
          }
        }

        if (this.processtypevalue  === "dt") {
          if (key === "DTShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin" + "<br/>";
              }
            }
          }
          if (key === "DTOrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "DTOrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment To" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment To" + "<br/>";
              }
            }
          }
          if (key === "DTDiversionTransferTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Diversion/Transfer To" + "<br/>";
              } else {
                invalidfield += "Please select Diversion/Transfer To" + "<br/>";
              }
            }
          }
          if (key === "soldto") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Sold To" + "<br/>";
              } else {
                invalidfield += "Please select Sold To" + "<br/>";
              }
            }
          }
          if (key === "soldtoaddress") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Address" + "<br/>";
              } else {
                invalidfield += "Please select Address" + "<br/>";
              }
            }
          }
          if (key === "shipto") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Ship To" + "<br/>";
              } else {
                invalidfield += "Please select Ship To" + "<br/>";
              }
            }
          }
          if (key === "shiptoaddress") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Address" + "<br/>";
              } else {
                invalidfield += "Please select Address" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "so") {
          if (key === "NPSOShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin " + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin " + "<br/>";
              }
            }
          }

          if (key === "NPSOShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Material" + "<br/>";
              }
            }
          }

          if (key === "NPSODiversionTransferTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Diversion/Trasnfer To" + "<br/>";
              } else {
                invalidfield += "Please select Diversion/Trasnfer To" + "<br/>";
              }
            }
          }

          if (key === "NPSOSoldTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Sold To" + "<br/>";
              } else {
                invalidfield += "Please select Sold To" + "<br/>";
              }
            }
          }

          if (key === "NPSOSoldToAddress") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Sold To Address" + "<br/>";
              } else {
                invalidfield += "Please select Sold To Address" + "<br/>";
              }
            }
          }
          if (key === "NPSOShipTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Ship To" + "<br/>";
              } else {
                invalidfield += "Please select Ship To" + "<br/>";
              }
            }
          }
          if (key === "NPSOShipToAddress") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Ship To Address" + "<br/>";
              } else {
                invalidfield += "Please select Ship To Address" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "ov") {
          if (key === "OvrgShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin" + "<br/>";
              }
            }
          }
          if (key === "OvrgOrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "OvrgOrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Prioritylevel" + "<br/>";
              } else {
                invalidfield += "Please select Prioritylevel" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "pr") {
          if (key === "PRShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin" + "<br/>";
              }
            }
          }
          if (key === "PROrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "PROrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment To" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment To" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "sr") {
          if (key === "SRShipmentReversal") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "sh") {
          if (key === "ShortageShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin " + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin " + "<br/>";
              }
            }
          }
          if (key === "ShortageOrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "ShortageOrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment To" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment To" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "sp") {
          if (key === "SPOShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin" + "<br/>";
              }
            }
          }
          if (key === "SPOOrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "SPOOrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment To" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment To" + "<br/>";
              }
            }
          }
        }

        if (this.processtypevalue  === "vr") {
          if (key === "VRShipmentOrigin") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Shipment Origin" + "<br/>";
              } else {
                invalidfield += "Please select Shipment Origin" + "<br/>";
              }
            }
          }
          if (key === "VROrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
          if (key === "VROrgShipmentTo") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment To" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment To" + "<br/>";
              }
            }
          }          
        }

        if (this.processtypevalue  === "zk") {
          if (key === "ZKROrgShipmentMaterial") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Original Shipment Material" + "<br/>";
              } else {
                invalidfield += "Please select Original Shipment Material" + "<br/>";
              }
            }
          }
        }

      });
      if(invalidfield != ""){
        this.alertService.showError(invalidfield);
      }     
    
      return invalidfield;
    }

  save(){
    debugger;
    var isvalid =  this.Validation(this.frmprocess);
    if(isvalid != "") {
       return;
    }

    let processtypemodel = {
      Id:0,
      Status:0,
      Processtypeid: this.frmprocess.get('Processtype').value == "" ? null : parseInt(this.frmprocess.get('Processtype').value),
      Dtshipmentorigin: this.frmprocess.get('DTShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('DTShipmentOrigin').value),
      Dtoriginalshipmentmaterial: this.frmprocess.get('DTOrgShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('DTOrgShipmentMaterial').value),
      Dtoriginalshipmentto: this.frmprocess.get('DTOrgShipmentTo').value == "" ? null : parseInt(this.frmprocess.get('DTOrgShipmentTo').value),
      Dtdiversionortransfersto: this.frmprocess.get('DTDiversionTransferTo').value == "" ? null : parseInt(this.frmprocess.get('DTDiversionTransferTo').value),
      Dtsoldto: this.frmprocess.get('soldto').value,
      Dtsoldtoaddress: this.frmprocess.get('soldtoaddress').value,
      Dtshipto: this.frmprocess.get('shipto').value,
      Dtshiptoaddress: this.frmprocess.get('shiptoaddress').value,
      Npsoshipmentorigin: this.frmprocess.get('NPSOShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('NPSOShipmentOrigin').value),
      Npsoshipmentmaterial: this.frmprocess.get('NPSOShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('NPSOShipmentMaterial').value),
      Npsodiversionortransfersto: this.frmprocess.get('NPSODiversionTransferTo').value == "" ? null : parseInt(this.frmprocess.get('NPSODiversionTransferTo').value),
      Npsosoldto: this.frmprocess.get('NPSOSoldTo').value,
      Npsosoldtoaddress: this.frmprocess.get('NPSOSoldToAddress').value,
      Npsoshipto: this.frmprocess.get('NPSOShipTo').value,
      Npsoshiptoaddress: this.frmprocess.get('NPSOShipToAddress').value,
      Ovrgshipmentorigin: this.frmprocess.get('OvrgShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('OvrgShipmentOrigin').value),
      Ovrgoriginalshipmentmaterial: this.frmprocess.get('OvrgOrgShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('OvrgOrgShipmentMaterial').value),
      Ovrgoriginalshipmentto: this.frmprocess.get('OvrgOrgShipmentTo').value == "" ? null : parseInt(this.frmprocess.get('OvrgOrgShipmentTo').value),    
      Prshipmentorigin: this.frmprocess.get('PRShipmentOrigin').value == ""? null : parseInt(this.frmprocess.get('PRShipmentOrigin').value),
      Proriginalshipmentmaterial: this.frmprocess.get('PROrgShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('PROrgShipmentMaterial').value),
      Proriginalshipmentto: this.frmprocess.get('PROrgShipmentTo').value == "" ? null : parseInt(this.frmprocess.get('PROrgShipmentTo').value),
      Srshipmentorigin: this.frmprocess.get('SRShipmentReversal').value == "" ? null : parseInt(this.frmprocess.get('SRShipmentReversal').value),
      Shortageshipmentorigin: this.frmprocess.get('ShortageShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('ShortageShipmentOrigin').value),
      Shortageoriginalshipmentmaterial: this.frmprocess.get('ShortageOrgShipmentMaterial').value == "" ? null: parseInt(this.frmprocess.get('ShortageOrgShipmentMaterial').value),
      Shortageoriginalshipmentto: this.frmprocess.get('ShortageOrgShipmentTo').value == "" ? null : parseInt(this.frmprocess.get('ShortageOrgShipmentTo').value),
      Sposhipmentorigin: this.frmprocess.get('SPOShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('SPOShipmentOrigin').value),
      Spooriginalshipmentmaterial: this.frmprocess.get('SPOOrgShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('SPOOrgShipmentMaterial').value),
      Spooriginalshipmentto: this.frmprocess.get('SPOOrgShipmentTo').value == "" ? null : parseInt( this.frmprocess.get('SPOOrgShipmentTo').value),
      Vrshipmentorigin: this.frmprocess.get('VRShipmentOrigin').value == "" ? null : parseInt(this.frmprocess.get('VRShipmentOrigin').value),
      Vroriginalshipmentmaterial: this.frmprocess.get('VROrgShipmentMaterial').value == "" ? null : parseInt(this.frmprocess.get('VROrgShipmentMaterial').value),
      Vroriginalshipmentto: this.frmprocess.get('VROrgShipmentTo').value == "" ? null : parseInt(this.frmprocess.get('VROrgShipmentTo').value),
      Zkroriginalshipmentmaterial: this.frmprocess.get('ZKROrgShipmentMaterial').value =="" ? null: parseInt(this.frmprocess.get('ZKROrgShipmentMaterial').value),
      Processtypecode : this.processtypevalue
      };   
  
      this.SpinnerService.show();
      debugger;
      let retvalue = this.requestService.InsertUpdateProcessType(processtypemodel);
      retvalue.subscribe((value: any) => {
          debugger;        
          if (value == "1") {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showSuccess("Record saved successfully");
          } else {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showError("Error while creating the record");
          }
        })
  
    }

    CloseReturnRequest(){

    }

    CancelReturnRequest() {
      var meet = confirm("Are you sure you want to delete this record?");
      if (meet) {
        this.SpinnerService.show();
        let requestmodel = {Id:0,Status:0};

        this.requestService.CancelReturnRequest(requestmodel).subscribe((data: any) => {
          if (data == "1") {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showSuccess("Record deleted successfully");
          } else {
            setTimeout(() => { this.SpinnerService.hide() }, 500);
            this.alertService.showError("Error while deleteing the record");
          }
        });
      }
    }

}

class item {
  name: string;
  code:string
  id: number;
}