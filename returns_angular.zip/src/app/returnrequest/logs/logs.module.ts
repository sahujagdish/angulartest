
import { RequestService } from '../../../services/request.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { LogsRoutingModule } from './logs-routing.module';
// import { LogsComponent} from './logs.component'

@NgModule({
  declarations: [],
  imports: [
    LogsRoutingModule,
    // LogsComponent,
    CommonModule,
    NgxPaginationModule
  ],
  providers:[RequestService]
})

export class logsModule { }
