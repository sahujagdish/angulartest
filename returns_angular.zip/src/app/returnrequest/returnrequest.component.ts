import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'returnrequest',
  templateUrl: './returnrequest.component.html',
  styleUrls: ['./returnrequest.component.css']
})
export class ReturnrequestComponent implements OnInit {
  
  tab: any = "requestdetails";
  tab1: any;
  tab2: any;
  tab3: any;
  
  constructor(private router: Router) { }
  ngOnInit() {   
    //this.onClick('requestdetails') ;
   // this.onClick('processtype') ;
  }

  onClick(check) {
    if (check == 'requestdetails') {
        this.tab = "requestdetails";
        this.router.navigateByUrl("returnrequest/requestdetails");
    } else if (check == 'processtype') {
        this.tab = "processtype";
        this.router.navigateByUrl("returnrequest/processtype");
    } else if (check == 'processtrackercommentary')  {
        this.tab = "processtrackercommentary";
        this.router.navigateByUrl("returnrequest/processtrackercommentary");
    } else if (check == 'batchorder')  {
        this.tab = "batchorder";
        this.router.navigateByUrl("returnrequest/batchorder");
    } else if (check == 'summary')  {
        this.tab = "summary";
        this.router.navigateByUrl("returnrequest/summary");
    } else if (check == 'logs')  {
        this.tab = "logs";
        this.router.navigateByUrl("returnrequest/logs");
    } 
    // else {
    //   this.tab = "requestdetails";
    //   this.router.navigateByUrl("returnrequest/requestdetails");
    // }

  }
}