
import { RequestService } from '../../services/request.service';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPaginationModule } from 'ngx-pagination';
import { RequestRoutingModule } from './returnrequest-routing.module';
import { ReturnrequestComponent } from './returnrequest.component';
//import { RequestdetailsComponent} from './requestdetails/requestdetails.component';
//import {ProcesstypeComponent} from '../returnrequest/processtype/processtype.component';
import {LogsComponent} from '../returnrequest/logs/logs.component';

import {BatchComponent} from '../returnrequest/batchorder/batchorder.component';
import {SummaryComponent} from '../returnrequest/summary/summary.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
@NgModule({
  declarations: [ReturnrequestComponent,BatchComponent,SummaryComponent, LogsComponent],
  imports: [
    RequestRoutingModule,    
    CommonModule,
    NgxPaginationModule
  ],
  schemas:[NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  providers:[RequestService]
})

export class RequestModule { }
