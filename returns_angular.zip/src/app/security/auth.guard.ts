import { Inject, Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ConfigService, dev } from '../../services/config.service';

@Injectable()
export class AuthGuard implements CanActivate {
  token: any;
  url = environment.hostName;
  appName = environment.appName;
  userSession: any;
  hostURL = environment.hostName + '/oauth2/authorize/'+ environment.appName +'?response_type=code&redirect_uri='
  redirectURL: string = '';
  redirectHost: string = '';
  dashboardURL: any;
  conf:any;
  constructor(public router: Router, private route: ActivatedRoute) {}
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
            const token = localStorage.getItem('TokenInfo');
            if (token) {
                return true;
            } 
            this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    }
 
}