import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { StorageService } from '../../services/storage.service';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { environment } from '../../environments/environment';
import { AuthenticateService } from 'src/services/authenticate.service';

@Injectable()
export class AuthService {
  
  hostURL = environment.hostName;
  logoutURL = environment.redirectURLForLogout;

  constructor(private router: Router, private storage: StorageService, private httpClient: HttpClient, private authenticateService: AuthenticateService) { 
  }

  
  logout() {    
      localStorage.clear();
      debugger;
      const logout = this.hostURL + '/oauth2/endsession?post_logout_redirect_uri='+ this.logoutURL;
      window.location.href = logout;
  }
}