import { Pipe, PipeTransform } from '@angular/core';
import { stringify } from 'querystring';

@Pipe({ name: 'splitattendees' })
export class SplitAttendeesPipe implements PipeTransform {
  transform(value:any, [separator]):string { 
      debugger;
    let attendess : [];
    let formatstr : string;
    value = value.split(separator);

    if(value.length >= 1) {   

        formatstr = "<ul class='list-unstyled'>";
        for (var i = 0; i < value.length;  i++) {
            if(formatstr == undefined ) {
                formatstr = `<li>${value[i]}</li>`;
            } else {
                formatstr += `<li>${value[i]}</li>`;
            }        
        }

        formatstr += '</ul>';
    } else {
        formatstr = '';
    }
    return formatstr;    
  }
}