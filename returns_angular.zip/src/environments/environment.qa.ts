export const environment = {
    production: true,
    env:'qa', 
    "API_URL":"https://hotordertool.azurewebsites.net/api/v1",
    "pagination":{PageSelected:0, pagesize:10, SortColumnName : "Modifieddate", SortOrder :"DESC"},
    hostName: 'https://gpi.my.idaptive.app',
    appName: 'oauthcustomserverapp',
    logo: 'assets/images/logo-gpi.svg',
    redirectURL: 'http://localhost:4200/login',
    redirectURLForLogout: 'http://localhost:4200/logout',
    enableIdaptive: 'true'
  };
  