import { EventEmitter } from "@angular/core";

export class CommonService {
    public onChange: EventEmitter<any> = new EventEmitter<any>();

    public doSomething(message: any) {
        // do something, then...
        this.onChange.emit({message: message});
    }
}