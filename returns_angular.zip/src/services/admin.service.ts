import { environment } from './../environments/environment';
import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigService, dev } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseUrl: any;
  options: any = {
    headers: new HttpHeaders().set('Content-Type', 'application/json')
      .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
      .set('Access-Control-Allow-Origin', '*')
      .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE')
  };
 
  constructor(private httpClient: HttpClient, private configservice:ConfigService, @Inject(dev) config:any,) { // @Inject(root) env:any, , 
    this.baseUrl = config.API_URL;
}

  public getreasoncodesdetail(param:any) {
    debugger;
    return this.httpClient.post(this.baseUrl  + "/GetReasoncodeDetail", param, this.options);
  }

  public InsertUpdatereasoncode(OrderTypeModel) {   
    return this.httpClient.post(this.baseUrl + "/InsertUpdateReasoncode", OrderTypeModel, this.options);
  }

 public Deletereasoncode(id: number){
    return this.httpClient.post(this.baseUrl + "/DeleteReasoncode/" + id,"", this.options);
 }

 public getroleaddresssdetail(param:any) {  
  return this.httpClient.post(this.baseUrl + "/GetRoleAddressDetail", param, this.options);
}

public getMailing(id: number) {
  return this.httpClient.get(this.baseUrl + "/MailingList/" + id, this.options);
}

public InsertUpdateroleaddress(MillsModel) {   
  debugger;
  return this.httpClient.post(this.baseUrl + "/InsertUpdateRoleAddress", MillsModel, this.options);
}

public Deleteroleaddress(id: number){
  return this.httpClient.post(this.baseUrl + "/DeleteRoleAddress/" + id,"", this.options);
}

public GetRoles() {
  return this.httpClient.get(this.baseUrl + "/Roles", this.options);
}



}
