import { environment } from './../environments/environment';
import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';;
import { ConfigService, dev } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class RequestService {
  baseUrl: any;
  options: any = {
    headers: new HttpHeaders().set('Content-Type', 'application/json')
      .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
      .set('Access-Control-Allow-Origin', '*')
      .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE')
  };
 
constructor(private httpClient: HttpClient, private configservice:ConfigService, @Inject(dev) config:any) {
    this.baseUrl = config.API_URL;
}

public upload(formData: FormData) {

  let uploadoption: any = {
    headers: new HttpHeaders()
      .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
      .set('Access-Control-Allow-Origin', '*')
      .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE')
  };

  return this.httpClient.post<{path: string}>(
    this.baseUrl +'/upload',
    formData, uploadoption
  );
}

public getreasoncode(){
  return this.httpClient.get(this.baseUrl + "/reasoncode", this.options);  
}

public InsertUpdateProcessType(requestdetailmodel) {
  return this.httpClient.post(this.baseUrl + "/InsertUpdateProcessType", requestdetailmodel, this.options);
}

public Deleteroleaddress(id: number){
  return this.httpClient.post(this.baseUrl + "/DeleteRoleAddress/" + id,"", this.options);
}

public GetRequest() {
  return this.httpClient.get(this.baseUrl + "/request", this.options);
}

public CancelReturnRequest(requestmodel: any) {
  return this.httpClient.post(this.baseUrl + "/CancelReturnRequest",requestmodel, this.options);
}

public GetCustomerAddress(customer: string) {
  return this.httpClient.post(this.baseUrl + "/GetCustomerAddress",JSON.stringify(customer), this.options);
}

public GetProcessType() {
  return this.httpClient.get(this.baseUrl + "/processtype", this.options);
}

public GetProcessTrackerCommentary(requestid) {
  return this.httpClient.get(this.baseUrl + "/ProcessTracker/"+ requestid, this.options);
}

public markcomplete(ProcessTrackerModel:any) {
  return this.httpClient.post(this.baseUrl + "/markcomplete",ProcessTrackerModel, this.options);
}

public InsertUpdateProcessTracker(ProcessTrackerModel:any) {
  return this.httpClient.post(this.baseUrl + "/InsertUpdateProcessTracker/",ProcessTrackerModel, this.options);
}

public GetDTDiversionsortransfer() {
  return this.httpClient.get(this.baseUrl + "/DTDiversionsortransfer", this.options);
}

public GetDTOriginalshipmentmaterial() {
  return this.httpClient.get(this.baseUrl + "/DTOriginalshipmentmaterial", this.options);
}

public GetDTOriginalshipmentto() {
  return this.httpClient.get(this.baseUrl + "/DTOriginalshipmentto", this.options);
}

public GetDTShipmentorigin() {
  return this.httpClient.get(this.baseUrl + "/DTShipmentorigin", this.options);
}

public GetNPSOShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/NPSOShipmentorigins", this.options);
}

public GetNPSODiversionTransferTo() {
  return this.httpClient.get(this.baseUrl + "/NPSODiversionTransferTo", this.options);
}
public GetNPSOShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/NPSOShipmentmaterial", this.options);
}
public GetOvrgShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/OvrgShipmentOrigin", this.options);
}

public GetOvrgOrgShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/OvrgOrgShipmentMaterial", this.options);
}
public GetOvrgOrgShipmentTo() {
  return this.httpClient.get(this.baseUrl + "/OvrgOriginalshipmenttos", this.options);
}
public GetPROrgShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/PROrgShipmentMaterial", this.options);
}
public GetPROrgShipmentTo() {
  return this.httpClient.get(this.baseUrl + "/PROrgShipmentTo", this.options);
}
public GetPRShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/PRShipmentOrigin", this.options);
}
public GetSRShipmentReversal() {
  return this.httpClient.get(this.baseUrl + "/SRShipmentReversal", this.options);
}
public GetShortageOrgShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/ShortageOrgShipmentMaterial", this.options);
}
public GetShortageOrgShipmentTo() {
  return this.httpClient.get(this.baseUrl + "/ShortageOrgShipmentTo", this.options);
}
public GetShortageShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/ShortageShipmentOrigin", this.options);
}
public GetSPOOrgShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/SPOOrgShipmentMaterial", this.options);
}
public GetSPOOrgShipmentTo() {
  return this.httpClient.get(this.baseUrl + "/SPOOrgShipmentTo", this.options);
}
public GetSPOShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/SPOShipmentOrigin", this.options);
}

public GetVROrgShipmentMaterial() {
  return this.httpClient.get(this.baseUrl + "/VROrgShipmentMaterial", this.options);
}

public GetVROrgShipmentTo() {
  return this.httpClient.get(this.baseUrl + "/VROrgShipmentTo", this.options);
}

public GetVRShipmentOrigin() {
  return this.httpClient.get(this.baseUrl + "/VRShipmentOrigin", this.options);
}

public GetZKROriginalShipmentMaterials() {
  return this.httpClient.get(this.baseUrl + "/zkroriginalshipmentmaterials", this.options);
}

}
