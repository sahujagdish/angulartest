import { Injectable, ErrorHandler, Injector, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgZone } from '@angular/core';
import { CommonService } from 'src/services/common.service';

@Injectable({
    providedIn: 'root'
  })
  export class globalerrorhandler implements ErrorHandler {
   public error: EventEmitter<any> = new EventEmitter();
    constructor(private commonservice: CommonService,private SpinnerService: NgxSpinnerService, private injector: Injector, private zone: NgZone) {
     
    }
    handleError(error:any):void {
        debugger;
     const router = this.injector.get(Router);     
      this.SpinnerService.hide();
     // console.error("Error occured: " + error.error);
      if (error instanceof HttpErrorResponse) {
        if(error.status == 401) {
          this.zone.run(() => router.navigate(["/accessdenied"]))
        } else {
          this.commonservice.doSomething(error);
          this.zone.run(() => router.navigateByUrl('/error'));
        }
      //  console.error("HTTP Status code: " + error.status);
       // console.error("HTTP Response body: " + error.message);
      } else {
        console.log("Error occured: " + error.message);
      }

      this.SpinnerService.hide();
    }
  }