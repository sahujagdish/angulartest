import { Injectable, Inject } from '@angular/core';
import { environment } from '../environments/environment';
import { observable, EMPTY, of } from 'rxjs';

// export class Mills {

// }

@Injectable()
export class ReturnServiceMock {
  baseUrl: any;

  constructor() { // @Inject(root) env:any
    this.baseUrl = environment.API_URL;
  }


  

  public getMillsList(param:any) {
    let mills = "{\"PagedDataModel\":[{\"MillId\":9,\"Millnumber\":\"aa\",\"Millname\":\"aa\",\"Createdby\":\"jagdish\",\"Createddate\":\"2020-09-06T09:09:47.753\",\"Modifiedby\":\"jagdish\",\"Modifieddate\":\"2020-09-06T09:09:47.753\"},{\"MillId\":8,\"Millnumber\":\"9991\",\"Millname\":\"ECO1\",\"Createdby\":\"jagdish\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"jagdish\",\"Modifieddate\":\"2020-09-06T09:09:25.717\"},{\"MillId\":1,\"Millnumber\":\"0241\",\"Millname\":\"Texarkana\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"},{\"MillId\":2,\"Millnumber\":\"0525\",\"Millname\":\"Prosperity\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"},{\"MillId\":3,\"Millnumber\":\"0660\",\"Millname\":\"Augusta\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"}],\"page\":{\"TotalCount\":5,\"PageSelected\":0,\"PageSize\":10}}";
    return of(mills); //this.dataService.post(this.baseUrl + "/GetMillsDetail", param);
  }

  public getMills() {  
    return of();  //this.dataService.get(this.baseUrl + "/Mills");
  }

}