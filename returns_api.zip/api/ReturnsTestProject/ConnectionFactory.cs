﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Returns.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReturnsTestProject
{
    public class ConnectionFactory : IDisposable
    {


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        public ReturnsContext CreateContextForInMemory()
        {
            var option = new DbContextOptionsBuilder<ReturnsContext>().UseInMemoryDatabase(databaseName: "Test_Database").Options;

            var context = new ReturnsContext(option);
            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }

            return context;
        }

        public ReturnsContext CreateContextForSQLite()
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();

            var option = new DbContextOptionsBuilder<ReturnsContext>().UseSqlite(connection).Options;

            var context = new ReturnsContext(option);

            if (context != null)
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }

            return context;
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
