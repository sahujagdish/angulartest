﻿using Returns.BusinessModel;
using Returns.Data.Model;
using Returns.Data.Model.Entity;
using Returns.Service;
using ReturnsTestProject.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ReturnsTestProject
{
    public class RoleAddressServiceTest
    {
        ReturnsContext context;
        public RoleAddressServiceTest()
        {
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_ReasoncodeService_Test_Data(context);
        }

        [Fact]
        public void GetRoleAddressDetail()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            LookupModel lookupModel = new LookupModel();
            lookupModel.SortColumnName = "Addresses";
            var query = new RoleAddressService(context, utilities);
            var result = query.GetRoleAddressDetail(lookupModel);
            Assert.Equal(3, result.PagedDataModel.Count);
        }

        private void Seed_ReasoncodeService_Test_Data(ReturnsContext context)
        {
            var role = new[]
            {
                new Roles{Id = 1, Role = "Customer service", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Roles{Id = 2, Role = "Customer service", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Roles{Id = 3, Role = "Customer service", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
            };

            context.Roles.AddRange(role);
            context.SaveChanges();

            var roleaddresscodes = new[]
            {
                new Roleaddresses{Roleid = 1, Addresses = "7108", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Roleaddresses{Roleid = 2, Addresses = "7109", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Roleaddresses{Roleid = 1, Addresses = "7102", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
            };

            context.Roleaddresses.AddRange(roleaddresscodes);
            context.SaveChanges();
        }

    }
}
