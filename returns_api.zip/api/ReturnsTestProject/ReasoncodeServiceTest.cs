﻿using Returns.BusinessModel;
using Returns.Data.Model;
using Returns.Data.Model.Entity;
using Returns.Service;
using ReturnsTestProject.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ReturnsTestProject
{
    public class ReasoncodeServiceTest
    {
       ReturnsContext context;
        public ReasoncodeServiceTest()
        {
            var factory = new ConnectionFactory();
            context = factory.CreateContextForSQLite();
            Seed_ReasoncodeService_Test_Data(context);
        }

        [Fact]
        public void GetReasoncodesDetail()
        {
            IUtilities utilities = new Utilities();
            // Arrange
            LookupModel lookupModel = new LookupModel();
            lookupModel.SortColumnName = "Reasoncode";
            var query = new ReasoncodeService(context, utilities);
            var result = query.GetReasoncodeDetail(lookupModel);
            Assert.Equal(3, result.PagedDataModel.Count);
        }

        private void Seed_ReasoncodeService_Test_Data(ReturnsContext context)
        {
            var reasoncodes = new []
            {
                new Reasoncodes{Reasoncode = "7108", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Reasoncodes{Reasoncode = "0660", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
                new Reasoncodes{Reasoncode = "0661", Createddate=UtilitiesTest.GetCSTNow(), Createdby ="Jagdish", Modifiedby="jagdish", Modifieddate=UtilitiesTest.GetCSTNow() },
            };

            context.Reasoncodes.AddRange(reasoncodes);
            context.SaveChanges();
        }

    }
}
