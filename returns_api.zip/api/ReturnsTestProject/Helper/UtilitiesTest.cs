﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReturnsTestProject.Helper
{
    public class UtilitiesTest
    {
        public static DateTime GetCSTNow()
        {
            DateTime cstNow;
            try
            {
                TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                cstNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cstZone);
            }
            catch
            {
                cstNow = DateTime.UtcNow;
            }
            return cstNow;
        }
    }
}
