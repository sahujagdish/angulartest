﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Returns.BusinessModel;
using Returns.Service;
using System;

namespace ReturnsAPI.Controllers
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    //[CheckAuthToken("admin,user")]
    public class ReasoncodeController : ControllerBase
    {
        private readonly IReasoncodeService reasoncodeService;
        private readonly ILogger<ReasoncodeController> logger;
        IConfiguration config;
        
        public ReasoncodeController(IReasoncodeService _reasoncodeService, ILogger<ReasoncodeController> _logger, IConfiguration _config)
        {
            reasoncodeService = _reasoncodeService;
            logger = _logger;
            config = _config;
        }

        [HttpPost]
        [Route("GetReasoncodeDetail")]
        public IActionResult GetReasoncodeDetail([FromBody] LookupModel lookupModel)
        {
            ModelPaged<ReasoncodeModel> Reasoncode = new ModelPaged<ReasoncodeModel>();
            try
            {                
                Reasoncode = reasoncodeService.GetReasoncodeDetail(lookupModel);
                return Ok(JsonConvert.SerializeObject(Reasoncode));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetReasoncodeDetail");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("reasoncode")]
        public IActionResult GetReasoncodes()
        {
            try
            {
                return Ok(reasoncodeService.GetReasoncode());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "getreasoncodes");
                return StatusCode(500);
            }
        }


        [HttpPost]
        [Route("InsertUpdateReasoncode")]
        public IActionResult InsertUpdateReasoncode(ReasoncodeModel ReasoncodeModel)
        {
            try
            {
                return Ok(reasoncodeService.InsertUpdateReasoncode(ReasoncodeModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "InsertUpdateReasoncode");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("DeleteReasoncode/{id}")]
        public IActionResult DeleteReasoncode(int id)
        {
            try
            {
                return Ok(reasoncodeService.DeleteReasoncode(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "DeleteReasoncode");
                return StatusCode(500);
            }
        }
    }
}
