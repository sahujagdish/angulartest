﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Returns.BusinessModel;
using Returns.Service;
using System;
namespace ReturnsAPI
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    public class FillRequestlistController : ControllerBase
    {
        private readonly IFillProcesstypelistService fillProcesstypelistService;
        private readonly ILogger<FillRequestlistController> logger;
        IConfiguration config;

        public FillRequestlistController(IFillProcesstypelistService _fillProcesstypelistService, ILogger<FillRequestlistController> _logger, IConfiguration _config)
        {
            fillProcesstypelistService = _fillProcesstypelistService;
            logger = _logger;
            config = _config;
        }

        [HttpGet]
        [Route("processtype")]
        public IActionResult GetProcessType()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetProcessType());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetProcessType");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("DTDiversionsortransfer")]
        public IActionResult GetDTDiversionsortransfer()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetDTDiversionsortransfer());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetDTDiversionsortransfer");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("DTOriginalshipmentmaterial")]
        public IActionResult GetDTOriginalshipmentmaterial()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetDTOriginalshipmentmaterial());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetDTOriginalshipmentmaterial");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("DTOriginalshipmentto")]
        public IActionResult GetDTOriginalshipmentto()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetDTOriginalshipmentto());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetDTOriginalshipmentto");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("DTShipmentorigin")]
        public IActionResult GetDTShipmentorigin()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetDTShipmentorigin());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetDTShipmentorigin");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("NPSODiversionTransferTo")]
        public IActionResult GetNPSODiversionortransfersto()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetNPSODiversionortransfersto());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "NPSODiversionTransferTo");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("NPSOShipmentmaterial")]
        public IActionResult GetNPSOShipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetNPSOShipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetNPSOShipmentmaterial");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("NPSOShipmentorigins")]
        public IActionResult GetNPSOShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetNPSOShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetNPSOShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("OVRGOriginalshipmentmaterials")]
        public IActionResult GetOVRGOriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetOVRGOriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetOVRGOriginalshipmentmaterials");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("OvrgOriginalshipmenttos")]
        public IActionResult GetOVRGOriginalshipmenttos()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetOVRGOriginalshipmenttos());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetOVRGOriginalshipmenttos");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("OvrgShipmentOrigin")]
        public IActionResult GetOVRGShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetOVRGShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetOVRGShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("OvrgOrgShipmentMaterial")]
        public IActionResult GetOvrgOrgShipmentMaterial()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetOVRGOriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetOVRGShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("PROrgShipmentMaterial")]
        public IActionResult GetPROriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetPROriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetPROriginalshipmentmaterials");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("PROrgShipmentTo")]
        public IActionResult GetPROriginalshipmenttos()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetPROriginalshipmenttos());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetPROriginalshipmenttos");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("PRShipmentOrigin")]
        public IActionResult GetPRShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetPRShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetPRShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("SRShipmentReversal")]
        public IActionResult GetSRshipmentreversals()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetSRshipmentreversals());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetSRshipmentreversals");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("ShortageOrgShipmentMaterial")]
        public IActionResult GetShortageOriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetShortageOriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetShortageOriginalshipmentmaterials");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("ShortageOrgShipmentTo")]
        public IActionResult GetShortageOriginalshipmenttos()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetShortageOriginalshipmenttos());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetShortageOriginalshipmenttos");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("ShortageShipmentOrigin")]
        public IActionResult GetShortageShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetShortageShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetShortageShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("SPOOrgShipmentMaterial")]
        public IActionResult GetSPOOriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetSPOOriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetSPOOriginalshipmentmaterials");
                return StatusCode(500);
            }
        }

        [Route("SPOOrgShipmentTo")]
        public IActionResult GetSPOOriginalshipmenttos()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetSPOOriginalshipmenttos());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetSPOOriginalshipmenttos");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("SPOShipmentOrigin")]
        public IActionResult GetSPOShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetSPOShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetSPOShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("VROrgShipmentMaterial")]
        public IActionResult GetVROriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetVROriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetVROriginalshipmentmaterials");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("VROrgShipmentTo")]
        public IActionResult GetVROriginalshipmenttos()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetVROriginalshipmenttos());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetVROriginalshipmenttos");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("VRShipmentOrigin")]
        public IActionResult GetVRShipmentorigins()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetVRShipmentorigins());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetVRShipmentorigins");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("zkroriginalshipmentmaterials")]
        public IActionResult GetZKROriginalshipmentmaterials()
        {
            try
            {
                return Ok(fillProcesstypelistService.GetZKROriginalshipmentmaterials());
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetZKROriginalshipmentmaterials");
                return StatusCode(500);
            }
        }
    }
}

