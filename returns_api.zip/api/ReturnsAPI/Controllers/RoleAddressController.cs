﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Returns.BusinessModel;
using Returns.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnsAPI.Controllers
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    //[CheckAuthToken("admin,user")]
    public class RoleAddressController : ControllerBase
    {
        private readonly IRoleAddressService roleAddressService;
        private readonly ILogger<RoleAddressController> logger;
        IConfiguration config;

        public RoleAddressController(IRoleAddressService _roleAddressService, ILogger<RoleAddressController> _logger, IConfiguration _config)
        {
            config = _config;
            roleAddressService = _roleAddressService;
            logger = _logger;

        }

        [HttpGet]
        [Route("Roles")]
        public IActionResult GetRoles()
        {
            try
            {
                return Ok(JsonConvert.SerializeObject(roleAddressService.GetRoles()));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetRoles");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("GetRoleAddressDetail")]
        public IActionResult GetRoleAddressDetail([FromBody] LookupModel lookupModel)
        {
            ModelPaged<RoleAddressModel> RoleAddress = new ModelPaged<RoleAddressModel>();
            try
            {
                RoleAddress = roleAddressService.GetRoleAddressDetail(lookupModel);
                return Ok(JsonConvert.SerializeObject(RoleAddress));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetRoleAddress");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("InsertUpdateRoleAddress")]
        public IActionResult InsertUpdateRoleAddress(RoleAddressModel RoleAddressModel)
        {
            try
            {
                return Ok(roleAddressService.InsertUpdateRoleAddress(RoleAddressModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "InsertUpdateRoleAddress");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("DeleteRoleAddress/{id}")]
        public IActionResult DeleteRoleAddress(int id)
        {
            try
            {
                return Ok(roleAddressService.DeleteRoleAddress(id));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "DeleteRoleAddress");
                return StatusCode(500);
            }
        }
    }
}
