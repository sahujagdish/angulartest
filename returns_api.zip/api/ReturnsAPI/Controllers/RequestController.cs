﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Returns.BusinessModel;
using Returns.Service;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnsAPI.Controllers 
{
    [Produces("application/json")]
    [ApiController]
    [Route("api/v1")]
    //[CheckAuthToken("admin,user")]
    public class RequestController : ControllerBase
    {
        private readonly IRequestService requestService;
        private readonly ILogger<RequestController> logger;
        IConfiguration config;
        private IBlobService blobService;
        public ICustomer customer;
        IBatchDetailsService batchDetailsService;

        public RequestController(ICustomer _customer, IBatchDetailsService _batchDetailsService, IBlobService _blobService, IRequestService _requestService, ILogger<RequestController> _logger, IConfiguration _config)
        {
            customer = _customer;
            blobService = _blobService;
            requestService = _requestService;
            logger = _logger;
            config = _config;
            batchDetailsService = _batchDetailsService;
    }

        [HttpPost]
        [Route("GetCustomerAddress")]
        public IActionResult GetCustomerAddress([FromBody] string cust)
        {            
            try
            {
                return Ok(customer.GetCustomerAddress(config.GetValue<string>("customerdetails"), cust));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetCustomerAddress");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("GetBatchDetails")]
        public IActionResult GetBatchDetails([FromBody] string cust)
        {
            try
            {
                return Ok(batchDetailsService.GetBatchDetails(config.GetValue<string>("batchdetails"), cust));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetBatchDetails");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("CancelReturnRequest")]
        public ActionResult CancelReturnRequest(CancelRequestModel requestModel)
        {
            try
            {
                return Ok(requestService.CancelReturnRequest(requestModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "CancelReturnRequest");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("upload")]
        public async Task<ActionResult> upload()
        {
            string formdata = "";
            try
            {
                FormCollection fc = (FormCollection)Request.Form;

                foreach (var key in fc.Keys)
                {
                    if (fc["data"] != "")
                    {
                        formdata = fc["data"].ToString();
                    }
                }
                var requestModel = JsonConvert.DeserializeObject<RequestModel>(formdata);

                if (Request.Form.Files.Count > 0)
                {
                    IFormFile file = Request.Form.Files[0];
                    if (file == null)
                    {
                        return BadRequest();
                    }

                    string container = config.GetValue<string>("AzureBlobStorage");
                    var result = await blobService.UploadFileBlobAsync(container, file.OpenReadStream(), file.ContentType, file.FileName);

                    //requestModel.Attachments = result.ToString();
                }              

                return Ok(requestService.InsertUpdateRequest(requestModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "upload");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("InsertUpdateProcessType")]
        public ActionResult InsertUpdateProcessType(ProcessTypeModel processTypeModel)
        {           
            try
            {               
                return Ok(requestService.InsertUpdateProcessType(processTypeModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "InsertUpdateProcessType");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("InsertUpdateProcessTracker")]
        public ActionResult InsertUpdateProcessTracker(ProcessTrackerInsertModel processTrackerInsertModel)
        {
            try
            {
                return Ok(requestService.InsertUpdateProcessTracker(processTrackerInsertModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "InsertUpdateProcessTracker");
                return StatusCode(500);
            }
        }

        [HttpPost]
        [Route("markcomplete")]
        public ActionResult MarkCompleteProcessTracker(ProcessTrackerCommentaryModel processTrackerCommentaryModel)
        {
            try
            {
                return Ok(requestService.MarkCompleteProcessTracker(processTrackerCommentaryModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "InsertUpdateProcessTracker");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("GetRequestDetail")]
        public IActionResult GetReasoncodeDetail([FromBody] LookupModel lookupModel)
        {
            ModelPaged<RequestModel> requestModel = new ModelPaged<RequestModel>();
            try
            {
                requestModel = requestService.GetRequestDetail(lookupModel);
                return Ok(JsonConvert.SerializeObject(requestModel));
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetRequestDetail");
                return StatusCode(500);
            }
        }

        [HttpGet]
        [Route("ProcessTracker/{id}")]
        public IActionResult GetProcessTracker(int id)
        {
            try
            {
                var processTrackerCommentaryModel = requestService.GetProcessTrackerCommentary(id);
                return Ok(processTrackerCommentaryModel);
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message + ex.InnerException + ex.StackTrace, "GetProcessTracker");
                return StatusCode(500);
            }
        }
    }
}
