using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Returns.Data.Model;
using Returns.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using Azure.Storage.Blobs;

namespace ReturnsAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            var roles = new string[1];
            services.AddScoped(x => new BlobServiceClient(Configuration.GetValue<string>("StorageConnection")));
            services.AddDbContext<ReturnsContext>(options => options.UseSqlServer(Configuration["ConnectionStrings:DatabaseConnection"]), ServiceLifetime.Transient);
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddCors();
            services.AddTransient<IReasoncodeService, ReasoncodeService>();
            services.AddTransient<IRoleAddressService, RoleAddressService>();
            services.AddSingleton<IUtilities, Utilities>();
            services.AddScoped<CheckAuthToken>(x => new CheckAuthToken(roles));
            services.AddScoped<ValidateModelAttribute>(x => new ValidateModelAttribute());            
            services.AddScoped<IBlobService, BlobService>();
            services.AddScoped<IRequestService, RequestService>();
            services.AddScoped<IFillProcesstypelistService, FillProcesstypelistService>();
            services.AddScoped<IFetchProcesstypeConfiguration, ProcesstypeConfiguration>();            
            services.AddScoped<ICustomer, CustomerDetailService>();
            services.AddScoped<IBatchDetailsService, BatchDetailsService>();            
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ReturnsAPI", Version = "v1" });
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(options => options.WithOrigins("*").AllowAnyMethod().AllowAnyHeader());

            app.UseForwardedHeaders(new ForwardedHeadersOptions { ForwardedHeaders = Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.All });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ReturnsAPI v1"));
            }

            app.UseSerilogRequestLogging();

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
