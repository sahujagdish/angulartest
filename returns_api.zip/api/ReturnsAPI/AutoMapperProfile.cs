﻿using AutoMapper;
using Returns.BusinessModel;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Service
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<RequestModel, ReturnRequest>();
            CreateMap<ReasoncodeModel,Reasoncodes>();
            CreateMap<RoleAddressModel,Roleaddresses>();
            CreateMap<CommonModel,Processtypes>();
            CreateMap<ProcessTrackerCommentaryModel,Processstepsconfig>();
        }
    }

  


}
