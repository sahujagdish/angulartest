﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.BusinessModel
{
    public class CommonModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }


    public enum ReturnRequestStatus
    {
        draft = 1,
        inprocess = 2,
        completed = 3,
        cancel = 4,
    }

    public enum ProcessTrackerStatus
    {
        pending = 1,
        completed = 2,
        future = 3
    }


    public enum Process
    {
        dt,
        so,
        ov,
        pr,
        sr,
        sh,
        sp,
        vr,
        zk
    }
}
