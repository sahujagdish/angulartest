﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.BusinessModel
{
    public class RoleAddressModel : BaseModel
    {
        public int Id { get; set; }
        public int Roleid { get; set; }
        public string Role { get; set; }
        public string Addresses { get; set; }       
    }
}
