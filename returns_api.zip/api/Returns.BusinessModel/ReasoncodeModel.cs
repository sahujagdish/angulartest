﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.BusinessModel
{
    public class ReasoncodeModel : BaseModel
    {
        public int Id { get; set; }
        public string Reasoncode { get; set; }      
    }
}
