﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.BusinessModel
{
    public class LookupModel
    {
        public string SortColumnName { get; set; } = "";
        public string SortOrder { get; set; }
        public int PageSelected { get; set; }
        public int PageSize { get; set; }
    }
}
