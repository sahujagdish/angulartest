﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Mapping
{
    public class ProcessstepsconfigMap : IEntityTypeConfiguration<Processstepsconfig>
    {
        public void Configure(EntityTypeBuilder<Processstepsconfig> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.Instructions).HasColumnName("instructions").IsUnicode(false).IsRequired();
            builder.Property(e => e.Processtypeconfigid).HasColumnName("processtypeconfigid").IsUnicode(false).IsRequired();
            builder.Property(e => e.Roleid).HasColumnName("roleid").IsUnicode(false).IsRequired();
            builder.Property(e => e.Step).HasColumnName("step").IsUnicode(false).IsRequired();
            builder.Property(e => e.Steporder).HasColumnName("steporder").IsUnicode(false).IsRequired();
            builder.Property(e => e.Documenttype).HasColumnName("documenttype").IsUnicode(false);
            builder.Property(e => e.Workflownumber).HasColumnName("workflownumber").IsUnicode(false).IsRequired();
            builder.Property(e => e.Timestamp).HasColumnName("timestamp").IsUnicode(false);
            builder.HasOne(d => d.Processtypeconfig).WithMany(e => e.processstepsconfig).OnDelete(DeleteBehavior.ClientSetNull).HasForeignKey(f => f.Processtypeconfigid).HasConstraintName("FK_processstepconfig_processtypeconfig");
            builder.HasOne(d => d.Roles).WithMany(e => e.Processstepsconfig).OnDelete(DeleteBehavior.ClientSetNull).HasForeignKey(f => f.Roleid).HasConstraintName("FK_processstepsconfig_roles");

            builder.ToTable("processstepsconfig");
        }
    }
}
