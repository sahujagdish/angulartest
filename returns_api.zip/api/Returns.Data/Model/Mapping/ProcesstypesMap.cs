﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Mapping
{
    public class ProcesstypesMap : IEntityTypeConfiguration<Processtypes>
    {
        public void Configure(EntityTypeBuilder<Processtypes> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.Code).HasColumnName("code").IsRequired();
            builder.Property(e => e.Name).HasColumnName("name").IsRequired();
            builder.Property(e => e.isActive).HasColumnName("isactive").IsRequired();
            builder.ToTable("processtypes");
        }
    }
}
