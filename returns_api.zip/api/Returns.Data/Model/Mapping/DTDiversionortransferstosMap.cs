﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class DTDiversionortransferstosMap : IEntityTypeConfiguration<DTDiversionortransferstos>
    {
        public void Configure(EntityTypeBuilder<DTDiversionortransferstos> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.DTDiversionortransfersto).HasColumnName("dtdiversionortransfersto").IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            builder.ToTable("dtdiversionortransferstos");
        }
    }
}
