﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Mapping
{
    public class StatuslogMap : IEntityTypeConfiguration<Statuslog>
    {
        public void Configure(EntityTypeBuilder<Statuslog> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.Returnrequestid).HasColumnName("returnrequestid").IsRequired();
            builder.Property(e => e.User).HasColumnName("user").IsRequired();
            builder.Property(e => e.Createddate).HasColumnName("createddate").IsRequired();
            builder.Property(e => e.Comment).HasColumnName("comment");
            builder.HasOne(d => d.Returnrequest).WithMany(e => e.statuslog).OnDelete(DeleteBehavior.ClientSetNull).HasForeignKey(f => f.Returnrequestid).HasConstraintName("FK_statuslog_returnrequest");
            builder.ToTable("statuslog");
        }
    }
}
