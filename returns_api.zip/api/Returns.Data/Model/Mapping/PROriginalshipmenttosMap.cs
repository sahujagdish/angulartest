﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class PROriginalshipmenttosMap : IEntityTypeConfiguration<PROriginalshipmenttos>
    {
        public void Configure(EntityTypeBuilder<PROriginalshipmenttos> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.PROriginalshipmentto).HasColumnName("proriginalshipmentto").IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            builder.ToTable("proriginalshipmenttos");
        }
    }
}
