﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Mapping
{
    class ReturnRequestProcessStepsMappingMap : IEntityTypeConfiguration<ReturnRequestProcessStepsMapping>
    {
        public void Configure(EntityTypeBuilder<ReturnRequestProcessStepsMapping> builder)
        {
            builder.Property(e => e.Requestid).HasColumnName("requestid").IsUnicode(false);
            builder.Property(e => e.Processstepsconfigid).HasColumnName("processstepsconfigid").IsUnicode(false);
            builder.Property(e => e.DocumentNumber).HasColumnName("documentnumber").IsUnicode(false);
            builder.Property(e => e.Notify).HasColumnName("notify").IsUnicode(false);
            builder.Property(e => e.Status).HasColumnName("status").IsUnicode(false);
            builder.HasOne(d => d.ReturnRequest).WithMany(e => e.returnrequestprocessstepsmapping).OnDelete(DeleteBehavior.ClientSetNull)
                .HasForeignKey(f => f.Requestid).HasConstraintName("FK_Processstepsconfigmapping_returnrequest");
            builder.HasOne(d => d.Processstepsconfig).WithMany(e => e.returnrequestprocessstepsmapping).OnDelete(DeleteBehavior.ClientSetNull)
                .HasForeignKey(f => f.Processstepsconfigid).HasConstraintName("FK_Processstepsconfigmapping_Processstepsconfig");
            builder.ToTable("returnrequestprocessstepsmapping");
        }

    }
}
