﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class PROriginalshipmentmaterialsMap : IEntityTypeConfiguration<PROriginalshipmentmaterials>
    {
        public void Configure(EntityTypeBuilder<PROriginalshipmentmaterials> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.PROriginalshipmentmaterial).HasColumnName("proriginalshipmentmaterial").IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            
            builder.ToTable("proriginalshipmentmaterials");
        }
    }
}
