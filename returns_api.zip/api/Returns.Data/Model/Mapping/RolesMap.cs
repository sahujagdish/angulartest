﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class RolesMap : IEntityTypeConfiguration<Roles>
    {
        public void Configure(EntityTypeBuilder<Roles> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.FacilityId).HasColumnName("facilityid").IsUnicode(false);
            builder.Property(e => e.Role).HasColumnName("role").IsRequired();
            builder.Property(e => e.Createdby).HasColumnName("createdby").HasMaxLength(100).IsUnicode(false).IsRequired();
            builder.Property(e => e.Createddate).HasColumnName("createddate").HasColumnType("datetime").IsRequired();
            builder.Property(e => e.Modifiedby).HasColumnName("modifiedby").HasMaxLength(100).IsUnicode(false).IsRequired();
            builder.Property(e => e.Modifieddate).HasColumnName("modifieddate").HasColumnType("datetime").IsRequired();

            builder.ToTable("roles");
        }
    }
}
