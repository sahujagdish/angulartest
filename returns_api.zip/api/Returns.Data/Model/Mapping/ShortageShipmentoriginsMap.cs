﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class ShortageShipmentoriginsMap : IEntityTypeConfiguration<ShortageShipmentorigins>
    {
        public void Configure(EntityTypeBuilder<ShortageShipmentorigins> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.ShortageShipmentorigin).HasColumnName("shortageshipmentorigin").IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            builder.ToTable("shortageshipmentorigins");
        }
    }
}
