﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class ZKROriginalshipmentmaterialsMap : IEntityTypeConfiguration<ZKROriginalshipmentmaterials>
    {
        public void Configure(EntityTypeBuilder<ZKROriginalshipmentmaterials> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.ZKROriginalshipmentmaterial).HasColumnName("zkroriginalshipmentmaterial").IsUnicode(false).IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            
            builder.ToTable("zkroriginalshipmentmaterials");
        }
    }
}
