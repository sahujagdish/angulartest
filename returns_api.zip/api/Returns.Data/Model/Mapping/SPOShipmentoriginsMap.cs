﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class SPOShipmentoriginsMap : IEntityTypeConfiguration<SPOShipmentorigins>
    {
        public void Configure(EntityTypeBuilder<SPOShipmentorigins> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.SPOShipmentorigin).HasColumnName("sposhipmentorigin").IsRequired();
            builder.Property(e => e.IsActive).HasColumnName("isactive").IsRequired();
            builder.ToTable("sposhipmentorigins");
        }
    }
}
