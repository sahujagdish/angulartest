﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Mapping
{
   public class ProcesstypesconfigMap : IEntityTypeConfiguration<Processtypesconfig>
    {
        public void Configure(EntityTypeBuilder<Processtypesconfig> builder)
        {
            builder.Property(e => e.Id).HasColumnName("id").ValueGeneratedOnAdd();
            builder.Property(e => e.Processtypeid).HasColumnName("processtypeid").IsUnicode(false);
            builder.Property(e => e.Dtshipmentorigin).HasColumnName("dtshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Dtoriginalshipmentmaterial).HasColumnName("dtoriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Dtoriginalshipmentto).HasColumnName("dtoriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Dtdiversionortransfersto).HasColumnName("dtdiversionortransfersto").IsUnicode(false);          
            builder.Property(e => e.Npsoshipmentorigin).HasColumnName("npsoshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Npsoshipmentmaterial).HasColumnName("npsoshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Npsodiversionortransfersto).HasColumnName("npsodiversionortransfersto").IsUnicode(false);          
            builder.Property(e => e.Ovrgshipmentorigin).HasColumnName("ovrgshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Ovrgoriginalshipmentmaterial).HasColumnName("ovrgoriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Ovrgoriginalshipmentto).HasColumnName("ovrgoriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Prshipmentorigin).HasColumnName("prshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Proriginalshipmentmaterial).HasColumnName("proriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Proriginalshipmentto).HasColumnName("proriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Srshipmentreversal).HasColumnName("srshipmentreversal").IsUnicode(false);
            builder.Property(e => e.Shortageshipmentorigin).HasColumnName("shortageshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Shortageoriginalshipmentmaterial).HasColumnName("shortageoriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Shortageoriginalshipmentto).HasColumnName("shortageoriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Sposhipmentorigin).HasColumnName("sposhipmentorigin").IsUnicode(false);
            builder.Property(e => e.Spooriginalshipmentmaterial).HasColumnName("spooriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Spooriginalshipmentto).HasColumnName("spooriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Vrshipmentorigin).HasColumnName("vrshipmentorigin").IsUnicode(false);
            builder.Property(e => e.Vroriginalshipmentmaterial).HasColumnName("vroriginalshipmentmaterial").IsUnicode(false);
            builder.Property(e => e.Vroriginalshipmentto).HasColumnName("vroriginalshipmentto").IsUnicode(false);
            builder.Property(e => e.Zkroriginalshipmentmaterial).HasColumnName("zkroriginalshipmentmaterial").IsUnicode(false);
            builder.HasOne(d => d.processtypes).WithMany(e => e.processtypesconfig).OnDelete(DeleteBehavior.ClientSetNull).HasForeignKey(f => f.Processtypeid).HasConstraintName("FK_Processtypesconfig_Processtypes");

            builder.ToTable("processtypesconfig");
        }
    }
}
