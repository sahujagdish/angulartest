﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Mapping
{
    public class ReturnRequestMap : IEntityTypeConfiguration<ReturnRequest>
    {
        public void Configure(EntityTypeBuilder<ReturnRequest> builder)
        {

            builder.Property(e => e.Id).HasColumnName("id").HasColumnType("int").IsRequired();
            builder.Property(e => e.RequestNumber).HasColumnName("requestnumber").IsUnicode(false);
            builder.Property(e => e.Status).HasColumnName("status").IsUnicode(false);
            builder.Property(e => e.Createdby).HasColumnName("createdby").IsUnicode(false);
            builder.Property(e => e.Createddate).HasColumnName("createddate").IsUnicode(false);
            builder.Property(e => e.Modifiedby).HasColumnName("modifiedby").IsUnicode(false);
            builder.Property(e => e.Modifieddate).HasColumnName("modifieddate").IsUnicode(false);
            builder.Property(e => e.Prioritylevel).HasColumnName("prioritylevel").IsUnicode(false);
            builder.Property(e => e.Reasoncodeid).HasColumnName("reasoncodeid").IsUnicode(false);
            builder.Property(e => e.Reasonforequest).HasColumnName("reasonforequest").IsUnicode(false);
            builder.Property(e => e.Attachments).HasColumnName("attachments").IsUnicode(false);
            builder.Property(e => e.Custreqpickupdate).HasColumnName("custreqpickupdate").IsUnicode(false);
            builder.Property(e => e.Custreqpickuptime).HasColumnName("custreqpickuptime").IsUnicode(false);
            builder.Property(e => e.Carrschdpickupdate).HasColumnName("carrschdpickupdate").IsUnicode(false);
            builder.Property(e => e.Carrschdpickuptime).HasColumnName("carrschdpickuptime").IsUnicode(false);
            builder.Property(e => e.Freightcostreqd).HasColumnName("freightcostreqd").IsUnicode(false);
            builder.Property(e => e.Freightcostamount).HasColumnName("freightcostamount").IsUnicode(false);
            builder.Property(e => e.Excuteshpmntoutsidesystem).HasColumnName("excuteshpmntoutsidesystem").IsUnicode(false);
            builder.Property(e => e.Pickaddrandcontactinfo).HasColumnName("pickaddrandcontactinfo").IsUnicode(false);
            builder.Property(e => e.Delivaddrandcontactinfo).HasColumnName("delivaddrandcontactinfo").IsUnicode(false);
            builder.Property(e => e.Custdelivinstructions).HasColumnName("custdelivinstructions").IsUnicode(false);
            builder.Property(e => e.Dtsoldto).HasColumnName("dtsoldto").IsUnicode(false);
            builder.Property(e => e.Dtsoldtoaddress).HasColumnName("dtsoldtoaddress").IsUnicode(false);
            builder.Property(e => e.Dtshipto).HasColumnName("dtshipto").IsUnicode(false);
            builder.Property(e => e.Dtshiptoaddress).HasColumnName("dtshiptoaddress").IsUnicode(false);
            builder.Property(e => e.Npsosoldto).HasColumnName("npsosoldto").IsUnicode(false);
            builder.Property(e => e.Npsosoldtoaddress).HasColumnName("npsosoldtoaddress").IsUnicode(false);
            builder.Property(e => e.Npsoshipto).HasColumnName("npsoshipto").IsUnicode(false);
            builder.Property(e => e.Npsoshiptoaddress).HasColumnName("npsoshiptoaddress").IsUnicode(false);
            builder.Property(e => e.Processtypesconfigid).HasColumnName("processtypesconfigid").IsUnicode(false);
            //builder.Property(e => e.Processtypeid).HasColumnName("processtypeid").IsUnicode(false);
            //builder.Property(e => e.Dtshipmentorigin).HasColumnName("dtshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Dtoriginalshipmentmaterial).HasColumnName("dtoriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Dtoriginalshipmentto).HasColumnName("dtoriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Dtdiversionortransfersto).HasColumnName("dtdiversionortransfersto").IsUnicode(false);
            //builder.Property(e => e.Dtsoldto).HasColumnName("dtsoldto").IsUnicode(false);
            //builder.Property(e => e.Dtsoldtoaddress).HasColumnName("dtsoldtoaddress").IsUnicode(false);
            //builder.Property(e => e.Dtshipto).HasColumnName("dtshipto").IsUnicode(false);
            //builder.Property(e => e.Dtshiptoaddress).HasColumnName("dtshiptoaddress").IsUnicode(false);
            //builder.Property(e => e.Npsoshipmentorigin).HasColumnName("npsoshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Npsoshipmentmaterial).HasColumnName("npsoshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Npsodiversionortransfersto).HasColumnName("npsodiversionortransfersto").IsUnicode(false);
            //builder.Property(e => e.Npsosoldto).HasColumnName("npsosoldto").IsUnicode(false);
            //builder.Property(e => e.Npsosoldtoaddress).HasColumnName("npsosoldtoaddress").IsUnicode(false);
            //builder.Property(e => e.Npsoshipto).HasColumnName("npsoshipto").IsUnicode(false);
            //builder.Property(e => e.Npsoshiptoaddress).HasColumnName("npsoshiptoaddress").IsUnicode(false);
            //builder.Property(e => e.Ovrgshipmentorigin).HasColumnName("ovrgshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Ovrgoriginalshipmentmaterial).HasColumnName("ovrgoriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Ovrgoriginalshipmentto).HasColumnName("ovrgoriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Prshipmentorigin).HasColumnName("prshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Proriginalshipmentmaterial).HasColumnName("proriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Proriginalshipmentto).HasColumnName("proriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Srshipmentorigin).HasColumnName("srshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Shortageshipmentorigin).HasColumnName("shortageshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Shortageoriginalshipmentmaterial).HasColumnName("shortageoriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Shortageoriginalshipmentto).HasColumnName("shortageoriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Sposhipmentorigin).HasColumnName("sposhipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Spooriginalshipmentmaterial).HasColumnName("spooriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Spooriginalshipmentto).HasColumnName("spooriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Vrshipmentorigin).HasColumnName("vrshipmentorigin").IsUnicode(false);
            //builder.Property(e => e.Vroriginalshipmentmaterial).HasColumnName("vroriginalshipmentmaterial").IsUnicode(false);
            //builder.Property(e => e.Vroriginalshipmentto).HasColumnName("vroriginalshipmentto").IsUnicode(false);
            //builder.Property(e => e.Zkroriginalshipmentmaterial).HasColumnName("zkroriginalshipmentmaterial").IsUnicode(false);

            builder.HasOne(d => d.Processtypesconfig).WithMany(e => e.returnRequest).OnDelete(DeleteBehavior.ClientSetNull).HasForeignKey(f => f.Processtypesconfigid).HasConstraintName("FK_Processtypesconfig_returnrequest");

            builder.ToTable("returnrequest");
        }
    }
}
