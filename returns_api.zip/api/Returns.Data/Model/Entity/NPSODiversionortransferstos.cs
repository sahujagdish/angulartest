﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class NPSODiversionortransferstos
    {
        public int Id { get; set; }
        public string NPSODiversionortransfersto { get; set; }
        public bool IsActive { get; set; }
    }
}
