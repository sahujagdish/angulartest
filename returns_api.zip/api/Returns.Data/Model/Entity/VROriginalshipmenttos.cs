﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class VROriginalshipmenttos
    {
        public int Id { get; set; }
        public string VROriginalshipmentto { get; set; }
        public bool IsActive { get; set; }
    }
}
