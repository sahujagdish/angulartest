﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class PROriginalshipmentmaterials
    {
        public int Id { get; set; }
        public string PROriginalshipmentmaterial { get; set; }
        public bool IsActive { get; set; }
    }
}
