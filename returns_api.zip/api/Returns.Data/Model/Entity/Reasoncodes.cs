﻿using System;

namespace Returns.Data.Model.Entity
{
    public partial class Reasoncodes
    {
        public int Id { get; set; }
        public string Reasoncode { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime Modifieddate { get; set; }
    }
}
