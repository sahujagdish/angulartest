﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class ReturnRequest

    {
        public ReturnRequest()
        {
            
        }

        public int Id { get; set; }
        public string RequestNumber { get; set; }
        public int Status { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime Modifieddate { get; set; }
        public string Prioritylevel { get; set; }
        public string Reasoncodeid { get; set; }
        public string Reasonforequest { get; set; }
        public string Attachments { get; set; }
        public DateTime Custreqpickupdate { get; set; }
        public string Custreqpickuptime { get; set; }
        public DateTime Carrschdpickupdate { get; set; }
        public string Carrschdpickuptime { get; set; }
        public bool Freightcostreqd { get; set; }
        public decimal Freightcostamount { get; set; }
        public bool Excuteshpmntoutsidesystem { get; set; }
        public string Pickaddrandcontactinfo { get; set; }
        public string Delivaddrandcontactinfo { get; set; }
        public string Custdelivinstructions { get; set; }
        public string Dtsoldto { get; set; }
        public string Dtsoldtoaddress { get; set; }
        public string Dtshipto { get; set; }
        public string Dtshiptoaddress { get; set; }
        public string Npsosoldto { get; set; }
        public string Npsosoldtoaddress { get; set; }
        public string Npsoshipto { get; set; }
        public string Npsoshiptoaddress { get; set; }       
        public int? Processtypesconfigid { get; set; }

        //public int? Processtypeid { get; set; }
        //public int? Dtshipmentorigin { get; set; }
        //public int? Dtoriginalshipmentmaterial { get; set; }
        //public int? Dtoriginalshipmentto { get; set; }
        //public int? Dtdiversionortransfersto { get; set; }
        //public string Dtsoldto { get; set; }
        //public string Dtsoldtoaddress { get; set; }
        //public string Dtshipto { get; set; }
        //public string Dtshiptoaddress { get; set; }
        //public int? Npsoshipmentorigin { get; set; }
        //public int? Npsoshipmentmaterial { get; set; }
        //public int? Npsodiversionortransfersto { get; set; }
        //public string Npsosoldto { get; set; }
        //public string Npsosoldtoaddress { get; set; }
        //public string Npsoshipto { get; set; }
        //public string Npsoshiptoaddress { get; set; }
        //public int? Ovrgshipmentorigin { get; set; }
        //public int? Ovrgoriginalshipmentmaterial { get; set; }
        //public int? Ovrgoriginalshipmentto { get; set; }
        //public int? Prshipmentorigin { get; set; }
        //public int? Proriginalshipmentmaterial { get; set; }
        //public int? Proriginalshipmentto { get; set; }
        //public int? Srshipmentorigin { get; set; }
        //public int? Shortageshipmentorigin { get; set; }
        //public int? Shortageoriginalshipmentmaterial { get; set; }
        //public int? Shortageoriginalshipmentto { get; set; }
        //public int? Sposhipmentorigin { get; set; }
        //public int? Spooriginalshipmentmaterial { get; set; }
        //public int? Spooriginalshipmentto { get; set; }
        //public int? Vrshipmentorigin { get; set; }
        //public int? Vroriginalshipmentmaterial { get; set; }
        //public int? Vroriginalshipmentto { get; set; }
        //public int? Zkroriginalshipmentmaterial { get; set; }
        public virtual ICollection<Statuslog> statuslog { get; set; }
        public virtual ICollection<Processcommentarylog> processcommentarylog { get; set; }        
        public virtual ICollection<Notificationlog> notificationlog { get; set; }

        //public virtual Processtypes processtypes { get; set; }
        public virtual Processtypesconfig Processtypesconfig { get; set; }

        public virtual ICollection<ReturnRequestProcessStepsMapping> returnrequestprocessstepsmapping { get; set; }
        

    }
}
