﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class ShortageShipmentorigins
    {
        public int Id { get; set; }
        public string ShortageShipmentorigin { get; set; }
        public bool IsActive { get; set; }
    }
}
