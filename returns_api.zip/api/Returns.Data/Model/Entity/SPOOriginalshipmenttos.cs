﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class SPOOriginalshipmenttos
    {
        public int Id { get; set; }
        public string SPOOriginalshipmentto { get; set; }
        public bool IsActive { get; set; }
    }
}
