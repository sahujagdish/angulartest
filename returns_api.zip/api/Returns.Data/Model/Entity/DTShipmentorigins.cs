﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class DTShipmentorigins
    {
        public int Id { get; set; }
        public string DTShipmentorigin { get; set; }
        public bool IsActive { get; set; }
    }
}
