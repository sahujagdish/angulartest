﻿using System;
using System.Collections.Generic;

namespace Returns.Data.Model.Entity
{
    public partial class Roles
    {
        public Roles()
        {
            Roleaddresses = new HashSet<Roleaddresses>();
        }

        public int Id { get; set; }
        public int? FacilityId { get; set; }
        public string Role { get; set; }
        public string Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime Modifieddate { get; set; }
        public virtual ICollection<Roleaddresses> Roleaddresses { get; set; }
        public virtual ICollection<Processstepsconfig> Processstepsconfig { get; set; }
    }
}
