﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class NPSOShipmentmaterials
    {
        public int Id { get; set; }
        public string NPSOShipmentmaterial { get; set; }
        public bool IsActive { get; set; }
    }
}
