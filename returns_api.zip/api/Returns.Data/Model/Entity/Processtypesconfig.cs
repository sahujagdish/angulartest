﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
   public class Processtypesconfig
    {
        public int Id { get; set; }
        public int Processtypeid { get; set; }
        public int? Dtshipmentorigin { get; set; }
        public int? Dtoriginalshipmentmaterial { get; set; }
        public int? Dtoriginalshipmentto { get; set; }
        public int? Dtdiversionortransfersto { get; set; }        
        public int? Npsoshipmentorigin { get; set; }
        public int? Npsoshipmentmaterial { get; set; }
        public int? Npsodiversionortransfersto { get; set; }        
        public int? Ovrgshipmentorigin { get; set; }
        public int? Ovrgoriginalshipmentmaterial { get; set; }
        public int? Ovrgoriginalshipmentto { get; set; }
        public int? Prshipmentorigin { get; set; }
        public int? Proriginalshipmentmaterial { get; set; }
        public int? Proriginalshipmentto { get; set; }
        public int? Srshipmentreversal { get; set; }
        public int? Shortageshipmentorigin { get; set; }
        public int? Shortageoriginalshipmentmaterial { get; set; }
        public int? Shortageoriginalshipmentto { get; set; }
        public int? Sposhipmentorigin { get; set; }
        public int? Spooriginalshipmentmaterial { get; set; }
        public int? Spooriginalshipmentto { get; set; }
        public int? Vrshipmentorigin { get; set; }
        public int? Vroriginalshipmentmaterial { get; set; }
        public int? Vroriginalshipmentto { get; set; }
        public int? Zkroriginalshipmentmaterial { get; set; }
        public virtual Processtypes processtypes { get; set; }
        public virtual ICollection<ReturnRequest> returnRequest { get; set; }
        public virtual ICollection<Processstepsconfig> processstepsconfig { get; set; }
    }
}
