﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class ShortageOriginalshipmenttos
    {
        public int Id { get; set; }
        public string ShortageOriginalshipmentto { get; set; }
        public bool IsActive { get; set; }
    }
}
