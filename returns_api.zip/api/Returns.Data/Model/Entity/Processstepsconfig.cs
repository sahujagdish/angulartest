﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class Processstepsconfig
    {
        public int Id { get; set; }
        public int Processtypeconfigid { get; set; }
        public int Steporder { get; set; }
        public string Instructions { get; set; }
        public string Step { get; set; }
        public int Roleid { get; set; }
        public string Documenttype { get; set; }
        public string Timestamp { get; set; }
        public int Workflownumber { get; set; }
        public virtual Processtypesconfig Processtypeconfig { get; set; }
        public virtual Roles Roles { get; set; }
        public virtual ICollection<ReturnRequestProcessStepsMapping> returnrequestprocessstepsmapping { get; set; }

    }
}
