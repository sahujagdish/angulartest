﻿


using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class VRShipmentorigins
    {
        public int Id { get; set; }
        public string VRShipmentorigin { get; set; }
        public bool IsActive { get; set; }
    }
}
