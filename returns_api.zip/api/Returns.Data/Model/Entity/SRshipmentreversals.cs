﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class SRshipmentreversals
    {
        public int Id { get; set; }
        public string SRshipmentreversal { get; set; }
        public bool IsActive { get; set; }

    }
}
