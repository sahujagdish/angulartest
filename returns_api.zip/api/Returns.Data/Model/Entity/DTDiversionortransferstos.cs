﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class DTDiversionortransferstos
    {
        public int Id { get; set; }
        public string DTDiversionortransfersto { get; set; }
        public bool IsActive { get; set; }
    }
}
