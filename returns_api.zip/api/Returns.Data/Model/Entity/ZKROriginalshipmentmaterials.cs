﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class ZKROriginalshipmentmaterials
    {
        public int Id { get; set; }
        public string ZKROriginalshipmentmaterial { get; set; }
        public bool IsActive { get; set; }
    }
}
