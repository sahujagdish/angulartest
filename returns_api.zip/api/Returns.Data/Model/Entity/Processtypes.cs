﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class Processtypes
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public bool isActive { get; set; }
        //public virtual ICollection<ReturnRequest> returnRequest { get; set; }
        public virtual ICollection<Processtypesconfig> processtypesconfig { get; set; }
    }
}
