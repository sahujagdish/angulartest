﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class ReturnRequestProcessStepsMapping
    {
        public int Id { get; set; }
        public int Requestid { get; set; }
        public int Processstepsconfigid { get; set; }
        public int Status { get; set; }
        public string DocumentNumber { get; set; }
        public bool Notify { get; set; }
        public virtual ReturnRequest ReturnRequest { get; set; }
        public virtual Processstepsconfig Processstepsconfig { get; set; }
    }
}
