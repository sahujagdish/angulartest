﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Data.Model.Entity
{
    public class Statuslog
    {
        public Statuslog()
        {

        }

        public int Id { get; set; }
        public int Returnrequestid { get; set; }
        public string User { get; set; }
        public DateTime Createddate { get; set; }
        public string Comment { get; set; }

        public ReturnRequest Returnrequest { get; set; }
    }
}
