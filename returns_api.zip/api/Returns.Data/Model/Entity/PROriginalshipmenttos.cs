﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class PROriginalshipmenttos
    {
        public int Id { get; set; }
        public string PROriginalshipmentto { get; set; }
        public bool IsActive { get; set; }
    }
}
