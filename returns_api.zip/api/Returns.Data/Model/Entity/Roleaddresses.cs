﻿using System;


namespace Returns.Data.Model.Entity
{
    public partial class Roleaddresses
    {
        public int Id { get; set; }
        public int Roleid { get; set; }
        public string Addresses { get; set; }
        public string  Createdby { get; set; }
        public DateTime Createddate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime Modifieddate { get; set; }
        public virtual Roles Roles { get; set; }
    }
}
