﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class NPSOShipmentorigins
    {
        public int Id { get; set; }
        public string NPSOShipmentorigin { get; set; }
        public bool IsActive { get; set; }
    }
}
