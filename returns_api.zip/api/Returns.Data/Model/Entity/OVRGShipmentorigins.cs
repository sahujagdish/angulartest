﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Data.Model.Entity
{
    public class OVRGShipmentorigins
    {
        public int Id { get; set; }
        public string OVRGShipmentorigin { get; set; }
        public bool IsActive { get; set; }
    }
}
