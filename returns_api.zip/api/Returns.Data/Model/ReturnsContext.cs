﻿using System;
using System.Net;
using Microsoft.EntityFrameworkCore;
using Returns.Data.Model.Entity;
using Returns.Data.Model.Mapping;

namespace Returns.Data.Model
{
    public partial class ReturnsContext : DbContext
    {
        public ReturnsContext()
        {

        }

        public ReturnsContext(DbContextOptions<ReturnsContext> options) : base(options)
        {
        }

        public virtual DbSet<DTDiversionortransferstos> DTDiversionsortransfers { get; set; }
        public virtual DbSet<DTOriginalshipmentmaterials> DTOriginalshipmentmaterials { get; set; }
        public virtual DbSet<DTOriginalshipmenttos> DTOriginalshipmenttos { get; set; }
        public virtual DbSet<DTShipmentorigins> DTShipmentorigins { get; set; }
        public virtual DbSet<Reasoncodes> Reasoncodes { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<Roleaddresses> Roleaddresses { get; set; }
        public virtual DbSet<NPSOShipmentmaterials> NPSOShipmentmaterials { get; set; }
        public virtual DbSet<NPSODiversionortransferstos> NPSODiversionortransferstos { get; set; }
        public virtual DbSet<NPSOShipmentorigins> NPSOShipmentorigins { get; set; }
        public virtual DbSet<OVRGOriginalshipmentmaterials> OVRGOriginalshipmentmaterials { get; set; }
        public virtual DbSet<OVRGOriginalshipmenttos> OVRGOriginalshipmenttos { get; set; }
        public virtual DbSet<OVRGShipmentorigins> OVRGShipmentorigins { get; set; }
        public virtual DbSet<PROriginalshipmentmaterials> PROriginalshipmentmaterials { get; set; }
        public virtual DbSet<PROriginalshipmenttos> PROriginalshipmenttos { get; set; }
        public virtual DbSet<PRShipmentorigins> PRShipmentorigins { get; set; }
        public virtual DbSet<SPOOriginalshipmentmaterials> SPOOriginalshipmentmaterials { get; set; }
        public virtual DbSet<SPOOriginalshipmenttos> SPOOriginalshipmenttos { get; set; }
        public virtual DbSet<SPOShipmentorigins> SPOShipmentorigins { get; set; }
        public virtual DbSet<ShortageOriginalshipmentmaterials> ShortageOriginalshipmentmaterials { get; set; }
        public virtual DbSet<ShortageOriginalshipmenttos> ShortageOriginalshipmenttos { get; set; }
        public virtual DbSet<ShortageShipmentorigins> ShortageShipmentorigins { get; set; }
        public virtual DbSet<VROriginalshipmentmaterials> VROriginalshipmentmaterials { get; set; }
        public virtual DbSet<VROriginalshipmenttos> VROriginalshipmenttos { get; set; }
        public virtual DbSet<VRShipmentorigins> VRShipmentorigins { get; set; }
        public virtual DbSet<ZKROriginalshipmentmaterials> ZKROriginalshipmentmaterials { get; set; }

        public virtual DbSet<Processtypes> Processtypes { get; set; }
        public virtual DbSet<Processtypesconfig> Processtypesconfig { get; set; }
        public virtual DbSet<Processstepsconfig> Processstepsconfig { get; set; }
        public virtual DbSet<ReturnRequestProcessStepsMapping> ReturnRequestProcessStepsMapping { get; set; }
        public virtual DbSet<ReturnRequest> ReturnRequest { get; set; }
        public virtual DbSet<Statuslog> Statuslog { get; set; }
        public virtual DbSet<Notificationlog> Notificationlog { get; set; }
        public virtual DbSet<Processcommentarylog> Processcommentarylog { get; set; }
        public virtual DbSet<SRshipmentreversals> SRshipmentreversals { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //optionsBuilder.UseSqlServer("Server=s02asqld349;Initial Catalog=USAZR3D-Returns;User ID=returnsuser;Password=H@f6dQ*^qm;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new DTDiversionortransferstosMap());
            modelBuilder.ApplyConfiguration(new DTOriginalshipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new DTOriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new DTShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new NPSODiversionortransferstosMap());
            modelBuilder.ApplyConfiguration(new NPSOShipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new NPSOShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new OVRGOriginalshipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new OVRGOriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new OVRGShipmentoriginsMap());

            modelBuilder.ApplyConfiguration(new PROriginalshipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new PROriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new PRShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new ReasoncodesMap());
            modelBuilder.ApplyConfiguration(new RolesMap());
            modelBuilder.ApplyConfiguration(new RoleaddressesMap());
            modelBuilder.ApplyConfiguration(new SPOOriginalshipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new SPOOriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new SPOShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new ShortageOriginalshipmentmaterialsMap());
            modelBuilder.ApplyConfiguration(new ShortageOriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new ShortageShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new VROriginalshipmentmaterialsMap());            
            modelBuilder.ApplyConfiguration(new VROriginalshipmenttosMap());
            modelBuilder.ApplyConfiguration(new VRShipmentoriginsMap());
            modelBuilder.ApplyConfiguration(new ZKROriginalshipmentmaterialsMap());

            modelBuilder.ApplyConfiguration(new ProcesstypesMap());
            modelBuilder.ApplyConfiguration(new ProcesstypesconfigMap());
            modelBuilder.ApplyConfiguration(new ProcessstepsconfigMap());
            modelBuilder.ApplyConfiguration(new ReturnRequestProcessStepsMappingMap());
            modelBuilder.ApplyConfiguration(new ReturnRequestMap());
            modelBuilder.ApplyConfiguration(new StatuslogMap());
            modelBuilder.ApplyConfiguration(new ProcesscommentarylogMap());
            modelBuilder.ApplyConfiguration(new NotificationlogMap());
            modelBuilder.ApplyConfiguration(new SRshipmentreversalsMap());
            
            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);


    }
}
