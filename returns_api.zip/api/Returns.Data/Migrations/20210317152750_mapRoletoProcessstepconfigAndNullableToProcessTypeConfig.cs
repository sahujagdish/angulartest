﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class mapRoletoProcessstepconfigAndNullableToProcessTypeConfig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "roleaddressid",
                table: "processstepsconfig",
                newName: "roleid");

            migrationBuilder.AlterColumn<int>(
                name: "zkroriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vrshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "srshipmentreversal",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "sposhipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "prshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsodiversionortransfersto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtdiversionortransfersto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.CreateIndex(
                name: "IX_processstepsconfig_roleid",
                table: "processstepsconfig",
                column: "roleid");

            migrationBuilder.AddForeignKey(
                name: "FK_processstepsconfig_roles",
                table: "processstepsconfig",
                column: "roleid",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_processstepsconfig_roles",
                table: "processstepsconfig");

            migrationBuilder.DropIndex(
                name: "IX_processstepsconfig_roleid",
                table: "processstepsconfig");

            migrationBuilder.RenameColumn(
                name: "roleid",
                table: "processstepsconfig",
                newName: "roleaddressid");

            migrationBuilder.AlterColumn<int>(
                name: "zkroriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vrshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "srshipmentreversal",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "sposhipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "prshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsodiversionortransfersto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipmentorigin",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentmaterial",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtdiversionortransfersto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);
        }
    }
}
