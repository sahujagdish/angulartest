﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class correctedmappingtable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReturnRequestProcessStepsMapping_processstepsconfig_Processstepsconfigid",
                table: "ReturnRequestProcessStepsMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_ReturnRequestProcessStepsMapping_returnrequest_ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ReturnRequestProcessStepsMapping",
                table: "ReturnRequestProcessStepsMapping");

            migrationBuilder.DropIndex(
                name: "IX_ReturnRequestProcessStepsMapping_ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping");

            migrationBuilder.DropColumn(
                name: "ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping");

            migrationBuilder.RenameTable(
                name: "ReturnRequestProcessStepsMapping",
                newName: "returnrequestprocessstepsmapping");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "returnrequestprocessstepsmapping",
                newName: "status");

            migrationBuilder.RenameColumn(
                name: "Requestid",
                table: "returnrequestprocessstepsmapping",
                newName: "requestid");

            migrationBuilder.RenameColumn(
                name: "Processstepsconfigid",
                table: "returnrequestprocessstepsmapping",
                newName: "processstepsconfigid");

            migrationBuilder.RenameColumn(
                name: "Notify",
                table: "returnrequestprocessstepsmapping",
                newName: "notify");

            migrationBuilder.RenameColumn(
                name: "DocumentNumber",
                table: "returnrequestprocessstepsmapping",
                newName: "documentnumber");

            migrationBuilder.RenameIndex(
                name: "IX_ReturnRequestProcessStepsMapping_Processstepsconfigid",
                table: "returnrequestprocessstepsmapping",
                newName: "IX_returnrequestprocessstepsmapping_processstepsconfigid");

            migrationBuilder.AlterColumn<string>(
                name: "documentnumber",
                table: "returnrequestprocessstepsmapping",
                type: "varchar(max)",
                unicode: false,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_returnrequestprocessstepsmapping",
                table: "returnrequestprocessstepsmapping",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_returnrequestprocessstepsmapping_requestid",
                table: "returnrequestprocessstepsmapping",
                column: "requestid");

            migrationBuilder.AddForeignKey(
                name: "FK_Processstepsconfigmapping_Processstepsconfig",
                table: "returnrequestprocessstepsmapping",
                column: "processstepsconfigid",
                principalTable: "processstepsconfig",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Processstepsconfigmapping_returnrequest",
                table: "returnrequestprocessstepsmapping",
                column: "requestid",
                principalTable: "returnrequest",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Processstepsconfigmapping_Processstepsconfig",
                table: "returnrequestprocessstepsmapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Processstepsconfigmapping_returnrequest",
                table: "returnrequestprocessstepsmapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_returnrequestprocessstepsmapping",
                table: "returnrequestprocessstepsmapping");

            migrationBuilder.DropIndex(
                name: "IX_returnrequestprocessstepsmapping_requestid",
                table: "returnrequestprocessstepsmapping");

            migrationBuilder.RenameTable(
                name: "returnrequestprocessstepsmapping",
                newName: "ReturnRequestProcessStepsMapping");

            migrationBuilder.RenameColumn(
                name: "status",
                table: "ReturnRequestProcessStepsMapping",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "requestid",
                table: "ReturnRequestProcessStepsMapping",
                newName: "Requestid");

            migrationBuilder.RenameColumn(
                name: "processstepsconfigid",
                table: "ReturnRequestProcessStepsMapping",
                newName: "Processstepsconfigid");

            migrationBuilder.RenameColumn(
                name: "notify",
                table: "ReturnRequestProcessStepsMapping",
                newName: "Notify");

            migrationBuilder.RenameColumn(
                name: "documentnumber",
                table: "ReturnRequestProcessStepsMapping",
                newName: "DocumentNumber");

            migrationBuilder.RenameIndex(
                name: "IX_returnrequestprocessstepsmapping_processstepsconfigid",
                table: "ReturnRequestProcessStepsMapping",
                newName: "IX_ReturnRequestProcessStepsMapping_Processstepsconfigid");

            migrationBuilder.AlterColumn<string>(
                name: "DocumentNumber",
                table: "ReturnRequestProcessStepsMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(max)",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping",
                type: "int",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ReturnRequestProcessStepsMapping",
                table: "ReturnRequestProcessStepsMapping",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRequestProcessStepsMapping_ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping",
                column: "ReturnRequestId");

            migrationBuilder.AddForeignKey(
                name: "FK_ReturnRequestProcessStepsMapping_processstepsconfig_Processstepsconfigid",
                table: "ReturnRequestProcessStepsMapping",
                column: "Processstepsconfigid",
                principalTable: "processstepsconfig",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ReturnRequestProcessStepsMapping_returnrequest_ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping",
                column: "ReturnRequestId",
                principalTable: "returnrequest",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
