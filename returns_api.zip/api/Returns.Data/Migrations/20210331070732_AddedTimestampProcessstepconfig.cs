﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class AddedTimestampProcessstepconfig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "timestamp",
                table: "processstepsconfig",
                type: "varchar(max)",
                unicode: false,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "timestamp",
                table: "processstepsconfig");
        }
    }
}
