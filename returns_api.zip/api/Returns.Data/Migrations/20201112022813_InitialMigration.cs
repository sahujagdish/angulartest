﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "reasoncodes",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    reasoncode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createdby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_reasoncodes", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "roles",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createdby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_roles", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "roleaddresses",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    roleid = table.Column<int>(type: "int", nullable: false),
                    addresses = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createdby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime", nullable: false),
                    modifiedby = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    modifieddate = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_roleaddresses", x => x.id);
                    table.ForeignKey(
                        name: "FK_roleaddresses_roles",
                        column: x => x.roleid,
                        principalTable: "roles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_roleaddresses_roleid",
                table: "roleaddresses",
                column: "roleid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "reasoncodes");

            migrationBuilder.DropTable(
                name: "roleaddresses");

            migrationBuilder.DropTable(
                name: "roles");
        }
    }
}
