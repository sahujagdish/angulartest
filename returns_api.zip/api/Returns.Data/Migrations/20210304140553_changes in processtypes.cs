﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class changesinprocesstypes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_processtypes_returnrequest_returnRequestId",
            //    table: "processtypes");

            //migrationBuilder.DropIndex(
            //    name: "IX_processtypes_returnRequestId",
            //    table: "processtypes");

            //migrationBuilder.DropColumn(
            //    name: "returnRequestId",
            //    table: "processtypes");

            //migrationBuilder.CreateIndex(
            //    name: "IX_returnrequest_processtypeid",
            //    table: "returnrequest",
            //    column: "processtypeid");

            migrationBuilder.AddForeignKey(
                name: "FK_Processtypes_returnrequest",
                table: "returnrequest",
                column: "processtypeid",
                principalTable: "processtypes",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Processtypes_returnrequest",
                table: "returnrequest");

            migrationBuilder.DropIndex(
                name: "IX_returnrequest_processtypeid",
                table: "returnrequest");

            migrationBuilder.AddColumn<int>(
                name: "returnRequestId",
                table: "processtypes",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_processtypes_returnRequestId",
                table: "processtypes",
                column: "returnRequestId");

            migrationBuilder.AddForeignKey(
                name: "FK_processtypes_returnrequest_returnRequestId",
                table: "processtypes",
                column: "returnRequestId",
                principalTable: "returnrequest",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
