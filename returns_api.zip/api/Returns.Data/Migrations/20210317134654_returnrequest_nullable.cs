﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class returnrequest_nullable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "zkroriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vrshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "srshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "sposhipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "prshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "processtypeid",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "npsodiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);

            migrationBuilder.AlterColumn<int>(
                name: "dtdiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "zkroriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vrshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "vroriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "srshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "sposhipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "spooriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "shortageoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "prshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "proriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "processtypeid",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "ovrgoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsosoldto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsoshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "npsodiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtsoldto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "dtdiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldUnicode: false,
                oldNullable: true);
        }
    }
}
