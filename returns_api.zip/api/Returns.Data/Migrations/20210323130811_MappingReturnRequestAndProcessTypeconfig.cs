﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class MappingReturnRequestAndProcessTypeconfig : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Processtypes_returnrequest",
                table: "returnrequest");

            migrationBuilder.DropIndex(
                name: "IX_returnrequest_processtypeid",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtdiversionortransfersto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtoriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtoriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtshipto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtshiptoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtsoldto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtsoldtoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsodiversionortransfersto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshipto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshiptoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsosoldto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsosoldtoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "ovrgoriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "ovrgoriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "ovrgshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "processtypeid",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "proriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "proriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "prshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "shortageoriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "shortageoriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "shortageshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "spooriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "spooriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "sposhipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "srshipmentorigin",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "vroriginalshipmentmaterial",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "vroriginalshipmentto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "vrshipmentorigin",
                table: "returnrequest");

            migrationBuilder.RenameColumn(
                name: "zkroriginalshipmentmaterial",
                table: "returnrequest",
                newName: "Processtypesconfigid");

            migrationBuilder.CreateIndex(
                name: "IX_returnrequest_Processtypesconfigid",
                table: "returnrequest",
                column: "Processtypesconfigid");

            migrationBuilder.AddForeignKey(
                name: "FK_Processtypesconfig_returnrequest",
                table: "returnrequest",
                column: "Processtypesconfigid",
                principalTable: "processtypesconfig",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Processtypesconfig_returnrequest",
                table: "returnrequest");

            migrationBuilder.DropIndex(
                name: "IX_returnrequest_Processtypesconfigid",
                table: "returnrequest");

            migrationBuilder.RenameColumn(
                name: "Processtypesconfigid",
                table: "returnrequest",
                newName: "zkroriginalshipmentmaterial");

            migrationBuilder.AddColumn<int>(
                name: "dtdiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtshipto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtshiptoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtsoldto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtsoldtoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsodiversionortransfersto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsoshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsoshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsoshipto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsoshiptoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsosoldto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsosoldtoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ovrgoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ovrgoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ovrgshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "processtypeid",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "proriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "proriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "prshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "shortageoriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "shortageoriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "shortageshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "spooriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "spooriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "sposhipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "srshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "vroriginalshipmentmaterial",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "vroriginalshipmentto",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "vrshipmentorigin",
                table: "returnrequest",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_returnrequest_processtypeid",
                table: "returnrequest",
                column: "processtypeid");

            migrationBuilder.AddForeignKey(
                name: "FK_Processtypes_returnrequest",
                table: "returnrequest",
                column: "processtypeid",
                principalTable: "processtypes",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
