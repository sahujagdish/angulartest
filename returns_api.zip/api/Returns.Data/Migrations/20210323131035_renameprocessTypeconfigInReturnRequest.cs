﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class renameprocessTypeconfigInReturnRequest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Processtypesconfigid",
                table: "returnrequest",
                newName: "processtypesconfigid");

            migrationBuilder.RenameIndex(
                name: "IX_returnrequest_Processtypesconfigid",
                table: "returnrequest",
                newName: "IX_returnrequest_processtypesconfigid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "processtypesconfigid",
                table: "returnrequest",
                newName: "Processtypesconfigid");

            migrationBuilder.RenameIndex(
                name: "IX_returnrequest_processtypesconfigid",
                table: "returnrequest",
                newName: "IX_returnrequest_Processtypesconfigid");
        }
    }
}
