﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class disableroleidreferences : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_roleaddresses_roles",
                table: "roleaddresses");

            migrationBuilder.DropIndex(
                name: "IX_roleaddresses_roleid",
                table: "roleaddresses");

            migrationBuilder.AddColumn<int>(
                name: "RolesId",
                table: "roleaddresses",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_roleaddresses_RolesId",
                table: "roleaddresses",
                column: "RolesId");

            migrationBuilder.AddForeignKey(
                name: "FK_roleaddresses_roles_RolesId",
                table: "roleaddresses",
                column: "RolesId",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_roleaddresses_roles_RolesId",
                table: "roleaddresses");

            migrationBuilder.DropIndex(
                name: "IX_roleaddresses_RolesId",
                table: "roleaddresses");

            migrationBuilder.DropColumn(
                name: "RolesId",
                table: "roleaddresses");

            migrationBuilder.CreateIndex(
                name: "IX_roleaddresses_roleid",
                table: "roleaddresses",
                column: "roleid");

            migrationBuilder.AddForeignKey(
                name: "FK_roleaddresses_roles",
                table: "roleaddresses",
                column: "roleid",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
