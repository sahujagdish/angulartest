﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class addedrequetnumberandfacilityid : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "facilityid",
                table: "roles",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "requestnumber",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "facilityid",
                table: "roles");

            migrationBuilder.DropColumn(
                name: "requestnumber",
                table: "returnrequest");
        }
    }
}
