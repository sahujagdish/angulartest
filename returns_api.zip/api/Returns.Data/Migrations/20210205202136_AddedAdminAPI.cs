﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class AddedAdminAPI : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DeleteData(
            //    table: "roles",
            //    keyColumn: "id",
            //    keyValue: 1);

            migrationBuilder.CreateTable(
                name: "dtdiversionortransferstos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dtdiversionortransfersto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_dtdiversionortransferstos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "dtoriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dtoriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_dtoriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "dtoriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dtoriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_dtoriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "dtshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dtshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_dtshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "npsodiversionortransferstos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    npsodiversionortransfersto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_npsodiversionortransferstos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "npsoshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    npsoshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_npsoshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "npsoshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    npsoshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_npsoshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ovrgoriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ovrgoriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ovrgoriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ovrgoriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ovrgoriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ovrgoriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ovrgshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OVRGShipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ovrgshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "proriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_proriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "proriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_proriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "prshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PRShipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_prshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Shipmentreversals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Shipmentreversal = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Createdby = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Createddate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Modifiedby = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Modifieddate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shipmentreversals", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "spooriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    spooriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_spooriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "spooriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    spooriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_spooriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sposhipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    sposhipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sposhipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "storageoriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    storageoriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageoriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "storageoriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    storageoriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageoriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "storageshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    storageshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "vroriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    vroriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vroriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "vroriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    vroriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vroriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "vrshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    vrshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vrshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "zkroriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    zkroriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_zkroriginalshipmentmaterials", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "dtdiversionortransferstos");

            migrationBuilder.DropTable(
                name: "dtoriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "dtoriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "dtshipmentorigins");

            migrationBuilder.DropTable(
                name: "npsodiversionortransferstos");

            migrationBuilder.DropTable(
                name: "npsoshipmentmaterials");

            migrationBuilder.DropTable(
                name: "npsoshipmentorigins");

            migrationBuilder.DropTable(
                name: "ovrgoriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "ovrgoriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "ovrgshipmentorigins");

            migrationBuilder.DropTable(
                name: "proriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "proriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "prshipmentorigins");

            migrationBuilder.DropTable(
                name: "Shipmentreversals");

            migrationBuilder.DropTable(
                name: "spooriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "spooriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "sposhipmentorigins");

            migrationBuilder.DropTable(
                name: "storageoriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "storageoriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "storageshipmentorigins");

            migrationBuilder.DropTable(
                name: "vroriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "vroriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "vrshipmentorigins");

            migrationBuilder.DropTable(
                name: "zkroriginalshipmentmaterials");

            migrationBuilder.InsertData(
                table: "roles",
                columns: new[] { "id", "createdby", "createddate", "modifiedby", "modifieddate", "role" },
                values: new object[] { 1, "Administrator", new DateTime(2020, 12, 1, 13, 25, 35, 636, DateTimeKind.Local).AddTicks(4674), "Administrator", new DateTime(2020, 12, 1, 13, 25, 35, 636, DateTimeKind.Local).AddTicks(4674), "Customer Service" });
        }
    }
}
