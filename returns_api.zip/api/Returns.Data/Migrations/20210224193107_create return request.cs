﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class createreturnrequest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_roleaddresses_roles_RolesId",
                table: "roleaddresses");

            migrationBuilder.DropTable(
                name: "storageoriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "storageoriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "storageshipmentorigins");

            migrationBuilder.DropIndex(
                name: "IX_roleaddresses_RolesId",
                table: "roleaddresses");

            migrationBuilder.DropColumn(
                name: "RolesId",
                table: "roleaddresses");

            migrationBuilder.RenameColumn(
                name: "OVRGShipmentorigin",
                table: "ovrgshipmentorigins",
                newName: "ovrgshipmentorigin");

            migrationBuilder.CreateTable(
                name: "returnrequest",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    status = table.Column<int>(type: "int", unicode: false, nullable: false),
                    createdby = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    createddate = table.Column<DateTime>(type: "datetime2", unicode: false, nullable: false),
                    modifiedby = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    modifieddate = table.Column<DateTime>(type: "datetime2", unicode: false, nullable: false),
                    prioritylevel = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    reasoncodeid = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    reasonforequest = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    attachments = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    custreqpickupdate = table.Column<DateTime>(type: "datetime2", unicode: false, nullable: false),
                    custreqpickuptime = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    carrschdpickupdate = table.Column<DateTime>(type: "datetime2", unicode: false, nullable: false),
                    carrschdpickuptime = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    freightcostreqd = table.Column<bool>(type: "bit", unicode: false, nullable: false),
                    freightcostamount = table.Column<decimal>(type: "decimal(18,2)", unicode: false, nullable: false),
                    excuteshpmntoutsidesystem = table.Column<bool>(type: "bit", unicode: false, nullable: false),
                    pickaddrandcontactinfo = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    delivaddrandcontactinfo = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    custdelivinstructions = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    processtypeid = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtdiversionortransfersto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtsoldto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtsoldtoaddress = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    dtshipto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtshiptoaddress = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    npsoshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsodiversionortransfersto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsosoldto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsosoldtoaddress = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    npsoshipto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshiptoaddress = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    ovrgshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    ovrgoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    ovrgoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    prshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    proriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    proriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    srshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    sposhipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    spooriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    spooriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vrshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vroriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vroriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    zkroriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_returnrequest", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "shortageoriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    shortageoriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shortageoriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "shortageoriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    shortageoriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shortageoriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "shortageshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    shortageshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shortageshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "srshipmentreversals",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SRshipmentreversal = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_srshipmentreversals", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "notificationlog",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    returnrequestid = table.Column<int>(type: "int", nullable: false),
                    user = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    comment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_notificationlog", x => x.id);
                    table.ForeignKey(
                        name: "FK_notificationlog_returnrequest",
                        column: x => x.returnrequestid,
                        principalTable: "returnrequest",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "processcommentarylog",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    returnrequestid = table.Column<int>(type: "int", nullable: false),
                    user = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    comment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_processcommentarylog", x => x.id);
                    table.ForeignKey(
                        name: "FK_processcommentarylog_returnrequest",
                        column: x => x.returnrequestid,
                        principalTable: "returnrequest",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "processtypes",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    returnRequestId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_processtypes", x => x.id);
                    table.ForeignKey(
                        name: "FK_processtypes_returnrequest_returnRequestId",
                        column: x => x.returnRequestId,
                        principalTable: "returnrequest",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "statuslog",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    returnrequestid = table.Column<int>(type: "int", nullable: false),
                    user = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    createddate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    comment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_statuslog", x => x.id);
                    table.ForeignKey(
                        name: "FK_statuslog_returnrequest",
                        column: x => x.returnrequestid,
                        principalTable: "returnrequest",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "processtypesconfig",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    processtypeid = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtdiversionortransfersto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtsoldto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtsoldtoaddress = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtshipto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    dtshiptoaddress = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsodiversionortransfersto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsosoldto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsosoldtoaddress = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshipto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    npsoshiptoaddress = table.Column<int>(type: "int", unicode: false, nullable: false),
                    ovrgshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    ovrgoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    ovrgoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    prshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    proriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    proriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    srshipmentreversal = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageoriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    shortageoriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    sposhipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    spooriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    spooriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vrshipmentorigin = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vroriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false),
                    vroriginalshipmentto = table.Column<int>(type: "int", unicode: false, nullable: false),
                    zkroriginalshipmentmaterial = table.Column<int>(type: "int", unicode: false, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_processtypesconfig", x => x.id);
                    table.ForeignKey(
                        name: "FK_Processtypesconfig_Processtypes",
                        column: x => x.processtypeid,
                        principalTable: "processtypes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "processstepsconfig",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    processtypeconfigid = table.Column<int>(type: "int", nullable: false),
                    steporder = table.Column<int>(type: "int", nullable: false),
                    instructions = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    step = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    roleaddressid = table.Column<int>(type: "int", nullable: false),
                    Documenttype = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    workflownumber = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_processstepsconfig", x => x.id);
                    table.ForeignKey(
                        name: "FK_processstepconfig_processtypeconfig",
                        column: x => x.processtypeconfigid,
                        principalTable: "processtypesconfig",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_roleaddresses_roleid",
                table: "roleaddresses",
                column: "roleid");

            migrationBuilder.CreateIndex(
                name: "IX_notificationlog_returnrequestid",
                table: "notificationlog",
                column: "returnrequestid");

            migrationBuilder.CreateIndex(
                name: "IX_processcommentarylog_returnrequestid",
                table: "processcommentarylog",
                column: "returnrequestid");

            migrationBuilder.CreateIndex(
                name: "IX_processstepsconfig_processtypeconfigid",
                table: "processstepsconfig",
                column: "processtypeconfigid");

            migrationBuilder.CreateIndex(
                name: "IX_processtypes_returnRequestId",
                table: "processtypes",
                column: "returnRequestId");

            migrationBuilder.CreateIndex(
                name: "IX_processtypesconfig_processtypeid",
                table: "processtypesconfig",
                column: "processtypeid");

            migrationBuilder.CreateIndex(
                name: "IX_statuslog_returnrequestid",
                table: "statuslog",
                column: "returnrequestid");

            migrationBuilder.AddForeignKey(
                name: "FK_roleaddresses_roles",
                table: "roleaddresses",
                column: "roleid",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_roleaddresses_roles",
                table: "roleaddresses");

            migrationBuilder.DropTable(
                name: "notificationlog");

            migrationBuilder.DropTable(
                name: "processcommentarylog");

            migrationBuilder.DropTable(
                name: "processstepsconfig");

            migrationBuilder.DropTable(
                name: "shortageoriginalshipmentmaterials");

            migrationBuilder.DropTable(
                name: "shortageoriginalshipmenttos");

            migrationBuilder.DropTable(
                name: "shortageshipmentorigins");

            migrationBuilder.DropTable(
                name: "srshipmentreversals");

            migrationBuilder.DropTable(
                name: "statuslog");

            migrationBuilder.DropTable(
                name: "processtypesconfig");

            migrationBuilder.DropTable(
                name: "processtypes");

            migrationBuilder.DropTable(
                name: "returnrequest");

            migrationBuilder.DropIndex(
                name: "IX_roleaddresses_roleid",
                table: "roleaddresses");

            migrationBuilder.RenameColumn(
                name: "ovrgshipmentorigin",
                table: "ovrgshipmentorigins",
                newName: "OVRGShipmentorigin");

            migrationBuilder.AddColumn<int>(
                name: "RolesId",
                table: "roleaddresses",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "storageoriginalshipmentmaterials",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    storageoriginalshipmentmaterial = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageoriginalshipmentmaterials", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "storageoriginalshipmenttos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    storageoriginalshipmentto = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageoriginalshipmenttos", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "storageshipmentorigins",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    storageshipmentorigin = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_storageshipmentorigins", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_roleaddresses_RolesId",
                table: "roleaddresses",
                column: "RolesId");

            migrationBuilder.AddForeignKey(
                name: "FK_roleaddresses_roles_RolesId",
                table: "roleaddresses",
                column: "RolesId",
                principalTable: "roles",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
