﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class addedcodetoprocesstype : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "code",
                table: "processtypes",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "code",
                table: "processtypes");
        }
    }
}
