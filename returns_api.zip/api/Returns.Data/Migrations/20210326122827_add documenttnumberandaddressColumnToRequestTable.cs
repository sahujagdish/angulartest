﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class adddocumenttnumberandaddressColumnToRequestTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "dtshipto",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "dtshiptoaddress",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "dtsoldto",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "dtsoldtoaddress",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "npsoshipto",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "npsoshiptoaddress",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "npsosoldto",
                table: "processtypesconfig");

            migrationBuilder.DropColumn(
                name: "npsosoldtoaddress",
                table: "processtypesconfig");

            migrationBuilder.AddColumn<string>(
                name: "documentNumber",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtshipto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtshiptoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtsoldto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "dtsoldtoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsoshipto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsoshiptoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsosoldto",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "npsosoldtoaddress",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "documentNumber",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtshipto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtshiptoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtsoldto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "dtsoldtoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshipto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsoshiptoaddress",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsosoldto",
                table: "returnrequest");

            migrationBuilder.DropColumn(
                name: "npsosoldtoaddress",
                table: "returnrequest");

            migrationBuilder.AddColumn<int>(
                name: "dtshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtsoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dtsoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsoshipto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsoshiptoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsosoldto",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "npsosoldtoaddress",
                table: "processtypesconfig",
                type: "int",
                unicode: false,
                nullable: true);
        }
    }
}
