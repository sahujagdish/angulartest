﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Returns.Data.Migrations
{
    public partial class addmappingtable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "documentNumber",
                table: "returnrequest");

            migrationBuilder.CreateTable(
                name: "ReturnRequestProcessStepsMapping",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Requestid = table.Column<int>(type: "int", nullable: false),
                    Processstepsconfigid = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    DocumentNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Notify = table.Column<bool>(type: "bit", nullable: false),
                    ReturnRequestId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReturnRequestProcessStepsMapping", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ReturnRequestProcessStepsMapping_processstepsconfig_Processstepsconfigid",
                        column: x => x.Processstepsconfigid,
                        principalTable: "processstepsconfig",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ReturnRequestProcessStepsMapping_returnrequest_ReturnRequestId",
                        column: x => x.ReturnRequestId,
                        principalTable: "returnrequest",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRequestProcessStepsMapping_Processstepsconfigid",
                table: "ReturnRequestProcessStepsMapping",
                column: "Processstepsconfigid");

            migrationBuilder.CreateIndex(
                name: "IX_ReturnRequestProcessStepsMapping_ReturnRequestId",
                table: "ReturnRequestProcessStepsMapping",
                column: "ReturnRequestId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ReturnRequestProcessStepsMapping");

            migrationBuilder.AddColumn<string>(
                name: "documentNumber",
                table: "returnrequest",
                type: "varchar(max)",
                unicode: false,
                nullable: true);
        }
    }
}
