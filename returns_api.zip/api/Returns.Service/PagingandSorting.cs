﻿using Returns.BusinessModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Returns.Service
{
    public class ModelPaged<T>
    {
        public List<T> PagedDataModel;
        public Paging page;
    }

    public static class SortingandPagingInfo
    {
        public static IEnumerable<TSource> Paging<TSource>(this IEnumerable<TSource> source, LookupModel lookupModel, out Paging outModel)
        {
            Paging paging = new Paging();
            paging.TotalCount = source.Count();
            outModel = paging;
            if (lookupModel.PageSize != 0)
            {
                if (lookupModel.PageSelected >0)
                {
                    lookupModel.PageSelected -= 1;
                }
                source = source.Skip(lookupModel.PageSelected * lookupModel.PageSize).Take(lookupModel.PageSize);
            }
            return source;
        }

        public static IQueryable<T> SortBy<T>(this IQueryable<T> source, string propertyName, string direction)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (String.IsNullOrEmpty(propertyName)) return source;

            var parameter = Expression.Parameter(source.ElementType, ".");

            //  create the selector part, but support child properties (it works without . too)
            String[] childProperties = propertyName.Split('.');
            MemberExpression property = Expression.Property(parameter, childProperties[0]);
            for (int i = 1; i < childProperties.Length; i++)
            {
                property = Expression.Property(property, childProperties[i]);
            }

            LambdaExpression selector = Expression.Lambda(property, parameter);

            string methodName = direction == "ASC" ? "OrderBy" : "OrderByDescending";

            MethodCallExpression resultExp = Expression.Call(typeof(Queryable), methodName,
                                            new Type[] { source.ElementType, property.Type },
                                            source.Expression, Expression.Quote(selector));

            return source.Provider.CreateQuery<T>(resultExp);
        }
    }
}
