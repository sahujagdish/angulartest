﻿using Returns.BusinessModel;
using Returns.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Service
{   

    public interface IFetchProcesstypeConfiguration
    {
        int GetProcessTypeDiversion(ProcessTypeModel processTypeModel);
    }
    public class ProcesstypeConfiguration : IFetchProcesstypeConfiguration
    {
        ReturnsContext context;
        public ProcesstypeConfiguration(ReturnsContext _context)
        {
            context = _context;
        }

        public int GetProcessTypeDiversion(ProcessTypeModel processTypeModel)
        {
            int id = 0;
            if (processTypeModel.Processtypecode == Process.dt.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Dtdiversionortransfersto == processTypeModel.Dtdiversionortransfersto
                                                            && x.Dtoriginalshipmentmaterial == processTypeModel.Dtoriginalshipmentmaterial
                                                            && x.Dtoriginalshipmentto == processTypeModel.Dtoriginalshipmentto
                                                            && x.Dtshipmentorigin == processTypeModel.Dtshipmentorigin
                                                            ).FirstOrDefault().Id;
            } 
            else if (processTypeModel.Processtypecode == Process.so.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Npsodiversionortransfersto == processTypeModel.Npsodiversionortransfersto
                                                            && x.Npsoshipmentmaterial == processTypeModel.Npsoshipmentmaterial
                                                            && x.Npsoshipmentorigin == processTypeModel.Npsoshipmentorigin
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.ov.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Ovrgoriginalshipmentmaterial == processTypeModel.Ovrgoriginalshipmentmaterial
                                                            && x.Ovrgoriginalshipmentto == x.Ovrgoriginalshipmentto
                                                            && x.Ovrgshipmentorigin == x.Ovrgshipmentorigin).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.pr.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Proriginalshipmentmaterial == processTypeModel.Proriginalshipmentmaterial
                                                            && x.Proriginalshipmentto == processTypeModel.Proriginalshipmentto                                                            
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.sh.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Shortageoriginalshipmentmaterial == processTypeModel.Shortageoriginalshipmentmaterial
                                                            && x.Shortageoriginalshipmentto == processTypeModel.Shortageoriginalshipmentto
                                                            && x.Shortageshipmentorigin == processTypeModel.Shortageshipmentorigin
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.sp.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Spooriginalshipmentmaterial == processTypeModel.Spooriginalshipmentmaterial
                                                            && x.Spooriginalshipmentto == processTypeModel.Spooriginalshipmentto
                                                            && x.Sposhipmentorigin == processTypeModel.Sposhipmentorigin
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.sr.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Srshipmentreversal == processTypeModel.Srshipmentorigin
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.vr.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Vroriginalshipmentmaterial == processTypeModel.Vroriginalshipmentmaterial
                                                            && x.Vroriginalshipmentto == processTypeModel.Vroriginalshipmentto
                                                            && x.Vrshipmentorigin == processTypeModel.Vrshipmentorigin
                                                            ).FirstOrDefault().Id;
            }
            else if (processTypeModel.Processtypecode == Process.zk.ToString())
            {
                id = context.Processtypesconfig.Where(x => x.Processtypeid == processTypeModel.Processtypeid
                                                            && x.Zkroriginalshipmentmaterial == processTypeModel.Zkroriginalshipmentmaterial
                                                            ).FirstOrDefault().Id;
            }
            return id;
        }
    }
}
