﻿using Returns.BusinessModel;
using Returns.Data.Model;
using System.Collections.Generic;
using System.Linq;

namespace Returns.Service
{
    public interface IFillProcesstypelistService
    {
        List<CommonModel> GetProcessType();
        List<CommonModel> GetDTOriginalshipmentmaterial();
        List<CommonModel> GetDTDiversionsortransfer();
        List<CommonModel> GetDTOriginalshipmentto();
        List<CommonModel> GetDTShipmentorigin();
        List<CommonModel> GetNPSODiversionortransfersto();
        List<CommonModel> GetNPSOShipmentmaterials();
        List<CommonModel> GetNPSOShipmentorigins();
        List<CommonModel> GetOVRGOriginalshipmentmaterials();
        List<CommonModel> GetOVRGOriginalshipmenttos();
        List<CommonModel> GetOVRGShipmentorigins();
        List<CommonModel> GetPROriginalshipmentmaterials();
        List<CommonModel> GetPROriginalshipmenttos();
        List<CommonModel> GetPRShipmentorigins();
        List<CommonModel> GetSRshipmentreversals();        
        List<CommonModel> GetShortageOriginalshipmentmaterials();
        List<CommonModel> GetShortageOriginalshipmenttos();
        List<CommonModel> GetShortageShipmentorigins();
        List<CommonModel> GetSPOOriginalshipmentmaterials();
        List<CommonModel> GetSPOOriginalshipmenttos();
        List<CommonModel> GetSPOShipmentorigins();
        List<CommonModel> GetVROriginalshipmentmaterials();
        List<CommonModel> GetVROriginalshipmenttos();
        List<CommonModel> GetVRShipmentorigins();
        List<CommonModel> GetZKROriginalshipmentmaterials();
    }

    public class FillProcesstypelistService : IFillProcesstypelistService
    {
        ReturnsContext context;
        IUtilities utilities;

        public FillProcesstypelistService(ReturnsContext _context, IUtilities _utilities)
        {
            context = _context;
            utilities = _utilities;
        }

        public List<CommonModel> GetProcessType()
        {
            return context.Processtypes.Where(x => x.isActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Code = x.Code,
                    Name = x.Name
                }).ToList();
        }

        public List<CommonModel> GetDTDiversionsortransfer()
        {
            return context.DTDiversionsortransfers.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.DTDiversionortransfersto
                }).ToList();
        }

        public List<CommonModel> GetDTOriginalshipmentmaterial()
        {
            return context.DTOriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.DTOriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetDTOriginalshipmentto()
        {
            return context.DTOriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.DTOriginalshipmentto
                }).ToList();
        }


        public List<CommonModel> GetDTShipmentorigin()
        {
            return context.DTShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.DTShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetNPSODiversionortransfersto()
        {
            return context.NPSODiversionortransferstos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.NPSODiversionortransfersto
                }).ToList();
        }

        public List<CommonModel> GetNPSOShipmentmaterials()
        {
            return context.NPSOShipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.NPSOShipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetNPSOShipmentorigins()
        {
            return context.NPSOShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.NPSOShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetOVRGOriginalshipmentmaterials()
        {
            return context.OVRGOriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.OVRGOriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetOVRGOriginalshipmenttos()
        {
            return context.OVRGOriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.OVRGOriginalshipmentto
                }).ToList();
        }

        public List<CommonModel> GetOVRGShipmentorigins()
        {
            return context.OVRGShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.OVRGShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetPROriginalshipmentmaterials()
        {
            return context.PROriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.PROriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetPROriginalshipmenttos()
        {
            return context.PROriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.PROriginalshipmentto
                }).ToList();
        }

        public List<CommonModel> GetPRShipmentorigins()
        {
            return context.PRShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.PRShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetSRshipmentreversals()
        {
            return context.SRshipmentreversals.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.SRshipmentreversal
                }).ToList();
        }        

        public List<CommonModel> GetShortageOriginalshipmentmaterials()
        {
            return context.ShortageOriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.ShortageOriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetShortageOriginalshipmenttos()
        {
            return context.ShortageOriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.ShortageOriginalshipmentto
                }).ToList();
        }

        public List<CommonModel> GetShortageShipmentorigins()
        {
            return context.ShortageShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.ShortageShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetSPOOriginalshipmentmaterials()
        {
            return context.SPOOriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.SPOOriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetSPOOriginalshipmenttos()
        {
            return context.SPOOriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.SPOOriginalshipmentto
                }).ToList();
        }

        public List<CommonModel> GetSPOShipmentorigins()
        {
            return context.SPOShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.SPOShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetVROriginalshipmentmaterials()
        {
            return context.VROriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.VROriginalshipmentmaterial
                }).ToList();
        }

        public List<CommonModel> GetVROriginalshipmenttos()
        {
            return context.VROriginalshipmenttos.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.VROriginalshipmentto
                }).ToList();
        }

        public List<CommonModel> GetVRShipmentorigins()
        {
            return context.VRShipmentorigins.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.VRShipmentorigin
                }).ToList();
        }

        public List<CommonModel> GetZKROriginalshipmentmaterials()
        {
            return context.ZKROriginalshipmentmaterials.Where(x => x.IsActive == true).Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.ZKROriginalshipmentmaterial
                }).ToList();
        }
    }
}
