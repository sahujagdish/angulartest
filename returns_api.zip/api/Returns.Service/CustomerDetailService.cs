﻿using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Service
{
    public interface ICustomer
    {
        CustomerDetail GetCustomerAddress(string webMethodsUrl, string customer);
    }

    public class CustomerDetailService : ICustomer
    {
        public CustomerDetailService()
        {

        }

        public CustomerDetail GetCustomerAddress(string webMethodsUrl, string customer)
        {
            try
            {
                WebRequest requestObj = WebRequest.Create(webMethodsUrl);
                requestObj.Method = "POST";
                requestObj.ContentType = "application/json";
                customer = "{ \"IN_CUSTOMER\" : " + customer + "}";

                string postData =  JsonConvert.SerializeObject(customer);

                CustomerDetail customerDetail = new CustomerDetail();
                Log.Information("Webmethodurl: " + webMethodsUrl);

                using (var streamWriter = new StreamWriter(requestObj.GetRequestStream()))
                {
                    streamWriter.Write(customer);
                    streamWriter.Flush();
                    streamWriter.Close();
                    var httpResponse = (HttpWebResponse)requestObj.GetResponse();

                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        customerDetail = (CustomerDetail)JsonConvert.DeserializeObject(streamReader.ReadToEnd(), typeof(CustomerDetail));
                    }
                }

                return customerDetail;
            }
            catch (Exception ex)
            {
                Log.Error("Customer details exception : " + ex);
                throw ex;
            }
        }
    }

    public class CustomerDetail
    {
        public CustomerAddress ES_ADDRESS { get; set; }
    }

    public class CustomerAddress
    {
        public string CUSTOMER { get; set; }
        public string NAME { get; set; }
        public string STREET { get; set; }
        public string CITY { get; set; }
        public string REGION { get; set; }
        public string POSTAL_CODE { get; set; }
        public string COUNTRY { get; set; }
    }
    
}
