﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Returns.Service
{
    public class Paging
    {
        public int TotalCount { get; set; }
        public int PageSelected { get; set; }
        public int PageSize { get; set; }
    }
}
