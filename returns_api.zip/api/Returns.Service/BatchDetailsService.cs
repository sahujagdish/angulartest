﻿using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Service
{
    public interface IBatchDetailsService
    {
        BatchDetails GetBatchDetails(string webMethodsUrl, BatchDetailsParam batchDetails);
    }
    public class BatchDetailsService : IBatchDetailsService
    {
        public BatchDetailsService()
        {

        }
        public BatchDetails GetBatchDetails(string webMethodsUrl, BatchDetailsParam batchparam)
        {
            try
            {
                WebRequest requestObj = WebRequest.Create(webMethodsUrl);
                requestObj.Method = "POST";
                requestObj.ContentType = "application/json";

                string param = "";
                if (batchparam.ITSHIPNOS != "")
                {
                    param = "{ \"IT_SHIPNOS\": [{ \"TKNUM\": " + batchparam.ITSHIPNOS + " }] } ";
                } else {
                    param = "{ \"IT_DELIVERIES\": [{ \"VBELN\": " + batchparam.ITDELIVERIES + " }] }";
                }

                //string postData = JsonConvert.SerializeObject(param);
                BatchDetails batchDetails = new BatchDetails();
                Log.Information("Webmethodurl: " + webMethodsUrl);

                using (var streamWriter = new StreamWriter(requestObj.GetRequestStream()))
                {
                    streamWriter.Write(param);
                    streamWriter.Flush();
                    streamWriter.Close();
                    var httpResponse = (HttpWebResponse)requestObj.GetResponse();

                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        batchDetails = (BatchDetails)JsonConvert.DeserializeObject(streamReader.ReadToEnd(), typeof(BatchDetails));
                    }
                }
                return batchDetails;
            }
            catch (Exception ex)
            {
                Log.Error("Customer details exception : " + ex);
                throw ex;
            }

        }
    }

    public class BatchDetails
    {
        public BatchDetail[] ES_Details { get; set; }
    }

    public class BatchDetail
    {
        public string DELIV_UOM { get; set; }
        public string SOLDTO_NAME { get; set; }
        public string MATERIAL { get; set; }
        public string BATCH { get; set; }
        public string DELIVERY { get; set; }
        public string INVOICE { get; set; }
        public string DELIV_QTY { get; set; }
        public string SALESORDER_LINE { get; set; }
        public string SHIPMENT { get; set; }
        public string SHIPTO { get; set; }
        public string WEIGHT_UOM { get; set; }
        public string SALESORDER { get; set; }
        public string STO_SHIPMENT { get; set; }
        public string DELIVERY_LINE { get; set; }
        public string SOLDTO { get; set; }
        public string FACILITY { get; set; }
        public string SHIPTO_NAME { get; set; }
        public string STO { get; set; }
        public string GROSS_WEIGHT { get; set; }
    }

    public class BatchDetailsParam
    {
        public string ITSHIPNOS { get; set; }
        public string ITDELIVERIES { get; set; }
    }

    //public class ShipmentDetail
    //{
    //    public IT_SHIPNOS ITSHIPNOS { get; set; }
    //    public IT_DELIVERIES ITDELIVERIES { get; set; }
    //}

    //public class IT_SHIPNOS {
    //    public string TKNUM { get; set; }
    //}

    //public class IT_DELIVERIES
    //{
    //    public string VBELN { get; set; }
    //}   
}
