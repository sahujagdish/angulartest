﻿using AutoMapper;
using Returns.BusinessModel;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Returns.Service
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<ReturnRequest, RequestModel>();
                //.ForMember(dest => dest.City, opt => opt.MapFrom(src => src.CurrentCity))
                //.ForMember(dest => dest.IsAdult, opt => opt.MapFrom(src => src.Age > 18 ? true : false));
            CreateMap<Reasoncodes, ReasoncodeModel>();
            CreateMap<Roleaddresses, RoleAddressModel>();
            CreateMap<Processtypes, CommonModel>();
        }
    }
}
