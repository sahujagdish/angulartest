﻿using Microsoft.EntityFrameworkCore;
using Returns.BusinessModel;
using Returns.Data.Model;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Returns.Service
{
    public interface IReasoncodeService
    {
        ModelPaged<ReasoncodeModel> GetReasoncodeDetail(LookupModel lookupModel);
        string InsertUpdateReasoncode(ReasoncodeModel reasoncodeModel);
        string DeleteReasoncode(int id);
        List<CommonModel> GetReasoncode();
    }

    public class ReasoncodeService : IReasoncodeService
    {
        ReturnsContext context;
        IUtilities utilities;

        public ReasoncodeService(ReturnsContext _context, IUtilities _utilities)
        {
            context = _context;
            utilities = _utilities;
        }
        public List<CommonModel> GetReasoncode()
        {
            return context.Reasoncodes.Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.Reasoncode
                }).ToList();
        }


        public ModelPaged<ReasoncodeModel> GetReasoncodeDetail(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var query = context.Reasoncodes.Select(x =>
               new ReasoncodeModel()
               {
                   Id = x.Id,
                   Reasoncode = x.Reasoncode,
                   Createdby = x.Createdby,
                   Createddate = x.Createddate,
                   Modifiedby = x.Modifiedby,
                   Modifieddate = x.Modifieddate
               }
            );

            var result = new List<ReasoncodeModel>();
            result = query.ToList();


            var propertyInfo = typeof(ReasoncodeModel).GetProperty(lookupModel.SortColumnName);


            if (lookupModel.SortOrder == "ASC")
                result = result.ToList().OrderBy(x => propertyInfo.GetValue(x, null)).ToList();
            else
                result = result.ToList().OrderByDescending(x => propertyInfo.GetValue(x, null)).ToList();

            var fresult = new ModelPaged<ReasoncodeModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return fresult;
        }

        public string InsertUpdateReasoncode(ReasoncodeModel reasoncodeModel)
        {
            var duplicatecheck = context.Reasoncodes.Where(x => x.Reasoncode == reasoncodeModel.Reasoncode).FirstOrDefault();

            if (duplicatecheck != null)
            {
                return "reasoncodeexists";
            }

            DateTime cst = utilities.GetCSTNow();
            Reasoncodes reasoncodeexists = context.Reasoncodes.Where(x => x.Id == reasoncodeModel.Id).FirstOrDefault();
            if (reasoncodeexists != null)
            {
                reasoncodeexists.Reasoncode = reasoncodeModel.Reasoncode;
                reasoncodeexists.Modifiedby = reasoncodeModel.Modifiedby;
                reasoncodeexists.Modifieddate = cst;
                context.Reasoncodes.Attach(reasoncodeexists);
                this.context.Entry(reasoncodeexists).State = EntityState.Modified;
            }
            else
            {
                context.Reasoncodes.Add(new Reasoncodes()
                {
                    Reasoncode = reasoncodeModel.Reasoncode,
                    Createdby = reasoncodeModel.Createdby,
                    Createddate = cst,
                    Modifiedby = reasoncodeModel.Createdby,
                    Modifieddate = cst,
                });
            }

            return Convert.ToString(context.SaveChanges());
        }

        public string DeleteReasoncode(int id)
        {
            Reasoncodes reasoncodeexists = context.Reasoncodes.Where(x => x.Id == id).FirstOrDefault();

            if (reasoncodeexists != null)
            {
                context.Reasoncodes.Remove(reasoncodeexists);
                return Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }
    }

}
