﻿using Microsoft.EntityFrameworkCore;
using Returns.BusinessModel;
using Returns.Data.Model;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Returns.Service
{
    public interface IRoleAddressService
    {
        ModelPaged<RoleAddressModel> GetRoleAddressDetail(LookupModel lookupModel);
        string InsertUpdateRoleAddress(RoleAddressModel roleAddressModel);
        List<CommonModel> GetRoles();
        string DeleteRoleAddress(int id);
    }



    public class RoleAddressService : IRoleAddressService
    {
        ReturnsContext context;
        IUtilities utilities;

        public RoleAddressService(ReturnsContext _context, IUtilities _utilities)
        {
            context = _context;
            utilities = _utilities;
        }

        public string DeleteRoleAddress(int id)
        {
            Roleaddresses roleaddressexists = context.Roleaddresses.Where(x => x.Id == id).FirstOrDefault();

            if (roleaddressexists != null)
            {
                context.Roleaddresses.Remove(roleaddressexists);
                return Convert.ToString(context.SaveChanges());
            }
            else
            {
                return "0";
            }
        }

        public ModelPaged<RoleAddressModel> GetRoleAddressDetail(LookupModel lookupModel)
        {
            Paging outModel = new Paging();

            var query = context.Roleaddresses.Include(a => a.Roles)
                        .Select(e => new RoleAddressModel
                        {
                            Id = e.Id,
                            Addresses = e.Addresses,
                            Roleid = e.Roleid,
                            Role = e.Roles.Role,
                            Createdby = e.Createdby,
                            Createddate = e.Createddate,
                            Modifiedby = e.Modifiedby,
                            Modifieddate = e.Modifieddate,
                        });

            var result = new List<RoleAddressModel>();
            result = query.ToList();


            var propertyInfo = typeof(RoleAddressModel).GetProperty(lookupModel.SortColumnName);


            if (lookupModel.SortOrder == "ASC")
                result = result.ToList().OrderBy(x => propertyInfo.GetValue(x, null)).ToList();
            else
                result = result.ToList().OrderByDescending(x => propertyInfo.GetValue(x, null)).ToList();

            var fresult = new ModelPaged<RoleAddressModel>()
            {
                PagedDataModel = result.Paging(lookupModel, out outModel).ToList(),
                page = new Paging()
                {
                    TotalCount = outModel.TotalCount,
                    PageSelected = lookupModel.PageSelected,
                    PageSize = lookupModel.PageSize
                }
            };
            return fresult;
        }

        public List<CommonModel> GetRoles()
        {
            return context.Roles.Select(
                x => new CommonModel()
                {
                    Id = x.Id,
                    Name = x.Role
                }).ToList();
        }

        public string InsertUpdateRoleAddress(RoleAddressModel roleAddressModel)
        {

            var duplicatecheck = context.Roleaddresses.Where(x => x.Roleid == roleAddressModel.Roleid && x.Id != roleAddressModel.Id).FirstOrDefault();

            if (duplicatecheck != null)
            {
                return "roleaddressexists";
            }
            DateTime cst = utilities.GetCSTNow();
            Roleaddresses roleAddressexists = context.Roleaddresses.Where(x => x.Id == roleAddressModel.Id).FirstOrDefault();
            if (roleAddressexists != null)
            {
                roleAddressexists.Roleid = roleAddressModel.Roleid;
                roleAddressexists.Addresses = roleAddressModel.Addresses;
                roleAddressexists.Modifiedby = roleAddressModel.Modifiedby;
                roleAddressexists.Modifieddate = cst;
                context.Roleaddresses.Attach(roleAddressexists);
                this.context.Entry(roleAddressexists).State = EntityState.Modified;
            }
            else
            {
                context.Roleaddresses.Add(
                    new Roleaddresses()
                    {
                        Roleid = roleAddressModel.Roleid,
                        Addresses = roleAddressModel.Addresses,
                        Createdby = roleAddressModel.Createdby,
                        Createddate = cst,
                        Modifiedby = roleAddressModel.Createdby,
                        Modifieddate = cst,
                    });
            }

            return Convert.ToString(context.SaveChanges());
        }
    }
}
