﻿using System;
using System.Runtime.InteropServices;
using Serilog;

namespace Returns.Service
{
    public interface IUtilities
    {
        DateTime GetCSTNow();
    }
    public class Utilities : IUtilities
    {
        public DateTime GetCSTNow()
        {
            DateTime cstNow;
            try
            {
                TimeZoneInfo cstZone = null;
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                else
                    cstZone = TimeZoneInfo.FindSystemTimeZoneById("America/Chicago");

                cstNow = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, cstZone);
            }
            catch (TimeZoneNotFoundException ex) 
            {
                cstNow = DateTime.UtcNow;
                Log.Error(ex, "Error occured. Used UTC instead of CST");
            }
            catch (InvalidTimeZoneException ex)
            {
                cstNow = DateTime.UtcNow;
                Log.Error(ex, "Error occured. Used UTC instead of CST");
            }
            return cstNow;
        }
    }
}
