﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Returns.BusinessModel;
using Returns.Data.Model;
using Returns.Data.Model.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Returns.Service
{
    public interface IRequestService
    {
        int InsertUpdateRequest(RequestModel requestModel);
        int InsertUpdateProcessType(ProcessTypeModel processTypeModel);
        int InsertUpdateProcessTracker(ProcessTrackerInsertModel processTrackerInsertModel);
        ModelPaged<RequestModel> GetRequestDetail(LookupModel lookupModel);
        string DeleteRequest(int requestId);
        int CancelReturnRequest(CancelRequestModel requestModel);
        List<ProcessTrackerCommentaryModel> GetProcessTrackerCommentary(int requestid);
        int MarkCompleteProcessTracker(ProcessTrackerCommentaryModel processTrackerCommentaryModel);
    }
    public class RequestService : IRequestService
    {

        ReturnsContext context;
        IUtilities utilities;
        private readonly IMapper mapper;
        IFetchProcesstypeConfiguration fetchProcesstypeConfiguration;

        public RequestService(ReturnsContext _context, IUtilities _utilities, IMapper _mapper, IFetchProcesstypeConfiguration _fetchProcesstypeConfiguration)
        {
            context = _context;
            utilities = _utilities;
            mapper = _mapper;
            fetchProcesstypeConfiguration = _fetchProcesstypeConfiguration;
        }

        public string DeleteRequest(int requestId)
        {
            throw new NotImplementedException();
        }

        public ModelPaged<RequestModel> GetRequestDetail(LookupModel lookupModel)
        {
            throw new NotImplementedException();
        }

        public int InsertUpdateRequest(RequestModel requestModel)
        {
            DateTime cst = utilities.GetCSTNow();
            int retvalue = 0;
            var request = mapper.Map<ReturnRequest>(requestModel);
            context.ReturnRequest.Add(request);
            retvalue = context.SaveChanges();
            return retvalue;
        }

        public int InsertUpdateProcessType(ProcessTypeModel processTypeModel)
        {
            int retvalue = 0;
            DateTime cst = utilities.GetCSTNow();

            try
            {
                int configid = fetchProcesstypeConfiguration.GetProcessTypeDiversion(processTypeModel);

                if (processTypeModel.RequestId != 0)
                {                    
                    ReturnRequest returnRequest = context.ReturnRequest.Where(x => x.Id == processTypeModel.RequestId).FirstOrDefault();

                    if (returnRequest.Status == Convert.ToInt32(ReturnRequestStatus.draft)) {
                        returnRequest.Processtypesconfigid = configid;
                        var request = mapper.Map<ReturnRequest>(returnRequest);
                        context.ReturnRequest.Attach(request);
                        this.context.Entry(request).State = EntityState.Modified;
                        retvalue = context.SaveChanges();
                    }
                }
                else
                {
                    context.ReturnRequest.Add(
                        new ReturnRequest()
                        {
                            Status = 0,
                            Dtshipto = processTypeModel.Dtshipto,
                            Dtshiptoaddress = processTypeModel.Dtshiptoaddress,
                            Dtsoldto = processTypeModel.Dtsoldto,
                            Dtsoldtoaddress = processTypeModel.Dtsoldtoaddress,
                            Npsoshipto = processTypeModel.Npsoshipto,
                            Npsoshiptoaddress = processTypeModel.Npsoshiptoaddress,
                            Npsosoldto = processTypeModel.Npsosoldto,
                            Npsosoldtoaddress = processTypeModel.Npsosoldtoaddress,
                            Processtypesconfigid = configid,
                            Createdby = processTypeModel.Createdby,
                            Createddate = cst,
                            Modifiedby = processTypeModel.Createdby,
                            Modifieddate = cst,
                        });

                    retvalue = context.SaveChanges();

                    var step = context.Processstepsconfig.Where(x => x.Processtypeconfigid == configid).OrderBy(x => x.Steporder).ToList();

                    ReturnRequestProcessStepsMapping[] returnRequestProcessStepsMapping = new ReturnRequestProcessStepsMapping[step.Count()];

                    int idx = 0;
                    step.ForEach(x =>
                    {
                        returnRequestProcessStepsMapping.Append(new ReturnRequestProcessStepsMapping
                        {
                            Processstepsconfigid = x.Id,
                            Requestid = retvalue,
                            Status = idx == 0 ? Convert.ToInt32(ProcessTrackerStatus.pending) : Convert.ToInt32(ProcessTrackerStatus.future),
                            Notify = false,
                        });

                        idx++;
                    });

                    context.ReturnRequestProcessStepsMapping.AddRange(returnRequestProcessStepsMapping);
                    context.Database.CommitTransaction();
                }
            }
            catch (Exception ex)
            {
                context.Database.RollbackTransaction();
            }

            return retvalue;
        }

        public int CancelReturnRequest(CancelRequestModel requestModel)
        {
            DateTime cst = utilities.GetCSTNow();
            int retvalue = 0;

            ReturnRequest returnRequest = context.ReturnRequest.Where(x => x.Id == requestModel.Id).FirstOrDefault();
            returnRequest.Status = requestModel.Status;
            returnRequest.Modifiedby = requestModel.Modifiedby;
            returnRequest.Modifieddate = cst;            
            context.ReturnRequest.Add(returnRequest);
            context.Entry(returnRequest).State = EntityState.Modified;
            retvalue = context.SaveChanges();

            return retvalue;
        }

        public List<ProcessTrackerCommentaryModel> GetProcessTrackerCommentary(int requestid)
        {

            int millpandd = context.Roles.Where(r => r.Role == "Mill PS&D").FirstOrDefault().Id;
            var ptcModel = (from req in context.ReturnRequest
                            join rpm in context.ReturnRequestProcessStepsMapping on req.Id equals rpm.Requestid into rrp
                            from rrpsm in rrp.DefaultIfEmpty()
                            join ps in context.Processstepsconfig.Include(x => x.Roles) on rrpsm.Processstepsconfigid equals ps.Id into g
                            from reqps in g.DefaultIfEmpty()
                            where req.Id == requestid
                            select req.Processtypesconfigid == null ? null : new ProcessTrackerCommentaryModel
                            {
                                Processstepsconfigid = reqps.Id,
                                RequestStatusId = rrpsm.ReturnRequest.Status,
                                Status = rrpsm.Status,
                                DocumentNumber = rrpsm.DocumentNumber,
                                RoleAddress = reqps.Roles.Roleaddresses.ToList().Count > 0 ? reqps.Roles.Roleaddresses
                                                        .Select(r => new CommonModel()
                                                        {
                                                            Name = r.Addresses,
                                                            Id = r.Id
                                                        }).ToList() : new List<CommonModel>(),
                                Facility = reqps.Roles.Role == "Mill PS&D" ? context.Roles.Where(r => r.FacilityId == millpandd)
                                                        .Select(r => new CommonModel()
                                                        {
                                                            Name = r.Role,
                                                            Id = r.Id
                                                        }).ToList() : new List<CommonModel>(),
                                Documenttype = reqps.Documenttype,
                                Instructions = reqps.Instructions,
                                Step = reqps.Step,
                                Role = reqps.Roles.Role,
                                RoleId = reqps.Roleid,
                                Timestamp = reqps.Timestamp
                            }).ToList();

            ptcModel.ForEach(x =>
            {
                x.StatusName = Enum.GetName(typeof(ProcessTrackerStatus), x.Status);
                x.RequestStatus = Enum.GetName(typeof(ReturnRequestStatus), x.Status);
            });

            return ptcModel;
        }

        public int InsertUpdateProcessTracker(ProcessTrackerInsertModel processTrackerInsertModel)
        {
            DateTime currDate = utilities.GetCSTNow();
            int retvalue;
            try
            {
                DateTime cst = utilities.GetCSTNow();
                List<ReturnRequestProcessStepsMapping> returnRequestProcessStepsMapping = new List<ReturnRequestProcessStepsMapping>();

                context.Database.BeginTransaction();
                processTrackerInsertModel.processTrackerCommentaryModel.ForEach(x =>
                {
                    var requestProcessStepsMapping = context.ReturnRequestProcessStepsMapping.Where(y => y.Requestid == processTrackerInsertModel.RequestId && y.Processstepsconfigid == x.Processstepsconfigid).FirstOrDefault();
                    requestProcessStepsMapping.DocumentNumber = x.DocumentNumber;

                    context.ReturnRequestProcessStepsMapping.Attach(requestProcessStepsMapping);
                    context.Entry(requestProcessStepsMapping).State = EntityState.Modified;
                });

                if (processTrackerInsertModel.Comment != string.Empty)
                {
                    Processcommentarylog processcommentarylog = new Processcommentarylog();
                    processcommentarylog.Comment = processTrackerInsertModel.Comment;
                    processcommentarylog.Returnrequestid = processTrackerInsertModel.RequestId;
                    processcommentarylog.User = "Jagdish";
                    processcommentarylog.Createddate = currDate;
                    context.Processcommentarylog.Add(processcommentarylog);
                }

                retvalue = context.SaveChanges();

                if(retvalue > 0)
                context.Database.CommitTransaction();

                return retvalue;
            }
            catch ( Exception ex)
            {
                context.Database.RollbackTransaction();
                throw ex;
            }
        }

        public int MarkCompleteProcessTracker(ProcessTrackerCommentaryModel processTrackerCommentaryModel)
        {
            DateTime cst = utilities.GetCSTNow();

            var returnRequestProcessStepsMapping = context.ReturnRequestProcessStepsMapping.Where(x => x.Requestid == processTrackerCommentaryModel.RequestId && x.Processstepsconfigid == processTrackerCommentaryModel.Processstepsconfigid).FirstOrDefault();

            returnRequestProcessStepsMapping.Status = Convert.ToInt32(ProcessTrackerStatus.completed);

            context.ReturnRequestProcessStepsMapping.Attach(returnRequestProcessStepsMapping);
            context.Entry(returnRequestProcessStepsMapping).State = EntityState.Modified;

            return context.SaveChanges();
        }


    }

    public static class AutoMapperExtensions
    {
        public static List<TDestination> MapList<TSource, TDestination>(this IMapper mapper, List<TSource> source)
        {
            return mapper.Map<List<TDestination>>(source);
        }
    }
}
