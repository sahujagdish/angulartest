
export class HelpScreen{
    static ActiveLink:number=0;
    static ToggleHelp:boolean=false;
    HelpData:string[]=[];
    constructor(){
        this.HelpData=[
            "Intro",
            "ProgramOverview",
            "NewParticipant",
            "ExisitngParticipant",
            "AuditReport",
            "UserReport",
            "StaffAccess",
            "StaffProfiles",
            "SponsorAccess",
            "SummaryReports",
            "Tracking",
            "PromoText",
            "StatementsText",
            "AgreementText",
            "NotificationText",
            "UnsubscribeText",
            "LoginText",
            "SignOnText"
        ];
    }
}



