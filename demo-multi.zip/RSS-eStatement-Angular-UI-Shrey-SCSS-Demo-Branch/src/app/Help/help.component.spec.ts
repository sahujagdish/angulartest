import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpComponent } from './help.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

describe('HelpComponent', () => {
  let component: HelpComponent;
  let fixture: ComponentFixture<HelpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HelpComponent ],
      imports:[HttpClientModule,RouterTestingModule
      ],
      providers:[
        {
          provide: ActivatedRoute, useValue: {
            params: { page: 'Intro' },
            snapshot: {
              parent: {
                params: {
                  participant: 'nyha'
                },
                paramMap: {
                  get(name: string): string {
                    return 'nyha';
                  }
                }
              },
              paramMap: {
                get(name: string): string {
                  return 'nyha';
                }
              }
            },
          }
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    sessionStorage.setItem("User",'{"userid":"Admin","ProviderID":126,"ProviderName":"ABG Houston","UUID":"114EABC8-AA97-9AD9-B1465E9462AAAD3D","Role":"admin","Provider":"null"}');

    fixture = TestBed.createComponent(HelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
