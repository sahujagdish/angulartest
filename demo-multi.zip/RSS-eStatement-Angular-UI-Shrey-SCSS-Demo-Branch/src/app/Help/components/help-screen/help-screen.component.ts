import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HelpScreen } from '../../models/HelpScreenData';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-help-screen',
  templateUrl: './help-screen.component.html',
  styleUrls: ['./help-screen.component.css'],
  encapsulation: ViewEncapsulation.None,

})
export class HelpScreenComponent implements OnInit {

  HTMlScreenText:string="";
  provider:string="";
  page:String="";
  HelpData!:string[];
  helpScreen:any=HelpScreen;
  User:any;
  constructor(private http:HttpClient,private router:ActivatedRoute,public route:Router) {
    this.User = JSON.parse(String(sessionStorage.getItem("User"))); 
    router.params.subscribe(val => {
      this.loadPageData();
      this.ngOnInit();
    });
  }

  loadPageData(){
    this.provider = String(this.router.snapshot.pathFromRoot[2].paramMap.get('participant'));
    this.page = String(this.router.snapshot.paramMap.get('page'));
  }

  ngOnInit(): void {
    
    let data:HelpScreen = new HelpScreen();
    this.HelpData = data.HelpData;
    let path = String(this.HelpData[HelpScreen.ActiveLink]);
    this.loadHTMLData(path);
  }
  nextTab(){
    if(HelpScreen.ActiveLink<this.HelpData.length){
    HelpScreen.ActiveLink = HelpScreen.ActiveLink+1;
    this.route.navigate(["../../Help",this.HelpData[HelpScreen.ActiveLink]],{relativeTo:this.router});

    //this.loadHTMLData(this.HelpData[HelpScreen.ActiveLink]);
    //this.ngOnInit();
    }
  }
  previousTab(){
    if(HelpScreen.ActiveLink>0){
    HelpScreen.ActiveLink = HelpScreen.ActiveLink-1;
    this.route.navigate(["../../Help",this.HelpData[HelpScreen.ActiveLink]],{relativeTo:this.router});

    // this.loadHTMLData(this.HelpData[HelpScreen.ActiveLink]);
    }
  }

  closeHelp(){
    HelpScreen.ToggleHelp = false;
    this.route.navigate(["../../"+this.User!.Role+"/welcome-page"],{relativeTo:this.router});
  }

  loadHTMLData(path:string){
    this.http.get("assets/Help-Screens/"+path+".html",{responseType:'text'}).subscribe(resp=>{
      this.HTMlScreenText = String(resp);
    },error=>{
    })
  }

}
