import { Injectable } from '@angular/core';
import { URL } from '../../models/URLHelper';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  search(searchSettings: any, token: string) {
    return this.http.post<any[]>(this.EStatementURL + URL.search, searchSettings);
  }

  isEditable(useSSN: boolean, providerID: string, provID: string, uuid: string, token: string) {
    return this.http.post<any>(this.EStatementURL + URL.editable + "?useSSN=" + useSSN + "&providerid=" + providerID + "&provid=" + provID + "&uid=" + uuid, '');
  }

  getDates(Dates: any, token: any) {
    return this.http.post<any[]>(this.EStatementURL + URL.dates, Dates);
  }

  getParticipantData(ParticipantObject: any, token: string) {
    return this.http.post<any[]>(this.EStatementURL + URL.participant, ParticipantObject);
  }

  updateParticipant(ParticipantObject: any, token: string) {
    return this.http.patch(this.EStatementURL + URL.participant_patch, ParticipantObject);
  }
  processStatements(ProcessObject: any, token: string) {
    return this.http.post<any[]>(this.EStatementURL + URL.process, ProcessObject);
  }

  getStatements(SearchObject: any, token: string) {
    return this.http.post<any[]>(this.EStatementURL + URL.ss_ident_partid, SearchObject);
  }

  updateProfile(ProfileObject: any, token: string) {
    return this.http.put(this.EStatementURL + URL.participant, ProfileObject);
  }

  getPlanList(PlanList: any, token: string) {
    return this.http.post<any[]>(this.EStatementURL + URL.plan_list, PlanList);
  }

  getSponPlanName(ISID:string){
    return this.http.post<any[]>(this.EStatementURL + URL.sponsor_plan_list+"?ISID="+ISID,"");
  }

  unsubscribe(ParticipantID:string,providerID:string){
    return this.http.post<any>(this.EStatementURL + URL.participant_unsubscribe+"?iPID="+ParticipantID+"&providerId="+providerID, "");  
  }

}
