import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getProfiles(ProviderId:string,Active:boolean) {
    return this.http.get<any[]>(this.EStatementURL + URL.profiles+"?ProviderID="+ProviderId+"&Active="+Active);
  }

  addProfile(ProfileObject:any){
    return this.http.post<any[]>(this.EStatementURL + URL.profiles,ProfileObject);  
  }

  getProfileObject(){
    return this.http.get<any>(this.EStatementURL + URL.profiles+"-empty");  
  }

  getAllLinks(ProviderId:string) {
    return this.http.get<any[]>(this.EStatementURL + URL.all_links+"?ProviderID="+ProviderId);
  }


  
  getLinks(ProviderId:string,ProfileID:string) {
    return this.http.get<any[]>(this.EStatementURL + URL.profile_links+"?ProviderID="+ProviderId+"&control_id="+ProfileID);
  }

  deleteProfile(ProfileID:string){
    return this.http.delete<any[]>(this.EStatementURL + URL.profiles+"/"+ProfileID);
  }

  updateProfile(ProfileID:string,ProfileName:string,ProviderID:string){
    return this.http.put<boolean>(this.EStatementURL + URL.profiles+"/"+ProfileID+"?ProviderID="+ProviderID+"&control_name="+ProfileName,"");//put changed
  }

  deleteProfileLinks(ProfileID:string){
    return this.http.delete<any[]>(this.EStatementURL + URL.profileLinks+"/"+ProfileID);
  }

  updateProfileLinks(ProfileID:string,Link:any[]){
    return this.http.post<any[]>(this.EStatementURL + URL.profileLinks+"?control_id="+ProfileID,Link);
  }

  getLastProfileID(ProviderID:string){
    return this.http.get<number>(this.EStatementURL + URL.max_profiles+"?ProviderID="+ProviderID);
  }

  //Staff Access

  getUsers(ProviderId:string,Active:boolean,hasSensitivePlans:boolean){
    return this.http.get<any[]>(this.EStatementURL + URL.users+"?ProviderID="+ProviderId+"&Active="+Active+"&hasSensitivePlans="+hasSensitivePlans);
  }

  updateUser(UserObject:any,ProviderID:string){
    return this.http.put<any>(this.EStatementURL + URL.users+"?ProviderID",UserObject);
  }

  AddUser(UserObject:any){
    return this.http.post<any>(this.EStatementURL + URL.users,UserObject);  
  }

  DeleteUser(control_id:string){
    return this.http.put<any>(this.EStatementURL + URL.delete_user+control_id,"");  
  }

}
