import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class LogoService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getLogo(ProviderID: string) {
    return this.http.get<any>(this.MMAPIURL + URL.logo + "/" + ProviderID + "/plevel");
  }

  getLogos(ProviderID: string) {
    return this.http.get<any[]>(this.MMAPIURL + URL.logo + "/" + ProviderID);
  }

}
