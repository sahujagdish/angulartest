import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { URL } from '../../models/URLHelper';
import { environment } from '../../../../environments/environment';
import { isGeneratedFile } from '@angular/compiler/src/aot/util';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  private Client: string = "";
  private UserType: string = "";
  private Provider: any = {}; 
  private Role:any=""; 
  public CurrentPage:any="";
  constructor(private http: HttpClient) { }


  //API calls

  changePassword(passwordObject: any, token: string) {
    return this.http.post(this.EStatementURL + URL.changePassword, passwordObject).toPromise();
  }

  AuthToken(tokenObject: any) {
    return this.http.post<any>(this.EStatementURL + URL.auth, tokenObject,{responseType:'json'});
  }

  CheckActiveProvider(ProviderID: string) {
    return this.http.post<any>(this.EStatementURL + URL.validate_provider + "?provider=" + ProviderID, "");
  }

  GetAssignedProviderSites(ProviderID: string){
    return this.http.post<any[]>(this.EStatementURL + URL.provider_assigned_site + "?provider=" + ProviderID, "");   
  }

  getUserDetails(UserId:string,Role:string){
    let role = "";
    switch(Role){
      case "admin":
            role="administrator";
            break;
      case "par":
            role="participant";
            break;
      case "spon":
            role="sponsor";
            break;              
    }
    return this.http.post<any>(this.EStatementURL + URL.user_details + "?userid=" + UserId+"&role="+role, "");   
  }

  getSideLinks(ProviderID:string,ProfileID:string){
    return this.http.post<any>(this.EStatementURL + URL.side_links + "?providerId=" + ProviderID+"&profileId"+ProfileID, "");   
  }


  //Getter Setter functions

  getRole(){
    return this.Role;
  }

  setRole(role:string){
    this.Role = role;
  }

  getClients() {
    return this.Client;
  }
  getUserType() {
    return this.UserType;
  }

  getProvider() {
    return this.Provider;
  }

  setProvider(provider: any) {
    this.Provider = provider;
  }
  setClients(Client: string) {
    this.Client = Client;
  }
  setUserType(UserType: string) {
    this.UserType = UserType;
  }

}
