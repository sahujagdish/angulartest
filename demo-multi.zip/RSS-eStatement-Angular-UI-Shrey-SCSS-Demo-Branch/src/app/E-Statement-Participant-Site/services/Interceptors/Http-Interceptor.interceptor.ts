import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { OAuthService } from 'angular-oauth2-oidc';
@Injectable({
    providedIn: 'root'
})
export class HttpInterceptorService implements HttpInterceptor {
    constructor(private route: Router,private oauthService: OAuthService) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        let token = this.oauthService.getAccessToken();

        let headers = { Authorization: 'Bearer ' + this.oauthService.getAccessToken() };

        if (req.url.includes('mmapi')) {
            headers = { Authorization: 'Bearer ' + sessionStorage.getItem('token') };
        }

        if (token!=undefined) {
            let tokenizedReq = req.clone({
                setHeaders: headers
            });
            return next.handle(tokenizedReq);
        }
        else {
            return next.handle(req);
        }
    }
}

