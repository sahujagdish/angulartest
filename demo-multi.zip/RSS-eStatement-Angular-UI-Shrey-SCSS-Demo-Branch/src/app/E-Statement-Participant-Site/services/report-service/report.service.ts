import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getAuditReports(AuditObject: any, token: string) {
    return this.http.post<any>(this.EStatementURL + URL.audit_report, AuditObject);
  }

  getUserReports(UserObject: any, token: string) {
    return this.http.post<any>(this.EStatementURL + URL.user_report, UserObject);
  }

  getAuditType(accept: boolean, validateCode: boolean, assertRetention: boolean, handshake: boolean) {
    return this.http.post<any>(this.EStatementURL + URL.audit_types + "?accept=" + accept + "&validatecode=" + validateCode + "&assetretention=" + assertRetention + "&handshake=" + handshake, '');
  }

  getStatusCode(accept: boolean, validateCode: boolean, match: boolean) {
    return this.http.post<any>(this.EStatementURL + URL.status_code + "?accept=" + accept + "&validatecode=" + validateCode + "&match=" + match, '');
  }
}