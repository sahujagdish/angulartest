import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class DownloadService {
  
  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  downloadStatementPDF(StatementObject: any) {

    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.post<any>(this.EStatementURL + URL.download_Statement_Report, StatementObject, requestOptions);
  }

  downloadAuditReport(AuditObject: any) {
    return this.http.post<any>(this.EStatementURL + URL.download_Audit_Report, AuditObject);
  }

  downloadUserReport(UserObject: any) {
    return this.http.post<any>(this.EStatementURL + URL.download_User_Report, UserObject);
  }

  
  downloadViewStatementPDF(query: any) {

    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.get<any>(this.EStatementURL + URL.download_statement+"?"+query, requestOptions);
  }
}
