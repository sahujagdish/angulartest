import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class StatementService {

  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) { }

  getApprovalList(ApprovalObject: any) {
    return this.http.post<any>(this.EStatementURL + URL.approval_list, ApprovalObject);
  }

  getApprovalInfo(approvalArray: any[]) {
    return this.http.post<any[]>(this.EStatementURL + URL.approval_info, approvalArray);
  }

  getPlans(approvalId: string) {
    return this.http.get<any[]>(this.EStatementURL + URL.plans + "/" + approvalId + "/plans");
  }

  generateProof(approvalId: string) {
    return this.http.get<any[]>(this.EStatementURL + URL.generateProof + "/" + approvalId + "/generateProof");
  }

  extractReport(approvalId: string, reportType: string) {
    return this.http.get<any>(this.EStatementURL + URL.extract_report + "/" + approvalId + "/reports/" + reportType);
  }

  deletePlans(DeleteObject: any) {
    return this.http.post<any>(this.EStatementURL + URL.delete_plan, DeleteObject);
  }

  checkAuditReportPath(ApproverID:string,ProvID:string){
    return this.http.post<any>(this.EStatementURL + URL.delete_plan+"?approvalId="+ApproverID+"&provId="+ProvID,"");
    }

  delete(approvalId: string, deleteBy: string) {
    return this.http.post<any>(this.EStatementURL + URL.delete + "?approvalId=" + approvalId + "&deleteBy=" + deleteBy, "");
  }

  approve(approvalId: string, provID: string, approvedBy: string) {
    return this.http.post<any>(this.EStatementURL + URL.approve + "?approvalId=" + approvalId + "&provId=" + provID + "&approvedBy=" + approvedBy, "");
  }

  getDataAuditExtractReport(approvalId: string) {
    const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
    const requestOptions: Object = {
      headers: headers,
      responseType: 'text'
    }
    return this.http.get<String>(this.MMAPIURL + URL.dataExtractReport + "/" + approvalId + "/reports/1", requestOptions);
  }

  getENotificationData(providerId:string,externalPlanId:string="default"){
    let query = externalPlanId=="default"?"":("?externalPlanId="+externalPlanId)
    return this.http.get<any[]>(this.EStatementURL + URL.e_notification+"/"+providerId+query);  
  }
  sendENotificationPlanData(providerId:string,Planid:string,PlanObject:any){
    return this.http.post<any[]>(this.EStatementURL + URL.e_notification+"/"+providerId+"/enotification/settings/"+Planid,PlanObject);     
  }

  sendENotificationData(providerId:string,PlanObject:any){
    return this.http.put<any[]>(this.EStatementURL + URL.e_notification+"/"+providerId+"/provider",PlanObject);     
  }

  getStatementsDataAdmin(StatementObject:any){
    return this.http.post<any>(this.EStatementURL + URL.statement+"/admin",StatementObject);       
  }
  
  getStatementsDataPar(StatementObject:any){
    return this.http.post<any>(this.EStatementURL + URL.statement+"/participant",StatementObject);       
  }
  
  getStatementsDataSpon(StatementObject:any){
    return this.http.post<any>(this.EStatementURL + URL.statement+"/sponsor",StatementObject);       
  }

  downloadStatementFile(FilePath:string){
    return this.http.get<any>(this.EStatementURL + URL.downloadFile+"?partialFileName="+FilePath);         
  }
}
