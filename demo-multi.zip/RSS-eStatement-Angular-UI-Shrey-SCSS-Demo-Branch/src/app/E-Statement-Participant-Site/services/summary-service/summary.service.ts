import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { URL } from '../../models/URLHelper';

@Injectable({
  providedIn: 'root'
})
export class SummaryService {
  private EStatementURL = environment.eStatementAPI;
  private MMAPIURL = environment.MMAPI;
  constructor(private http: HttpClient) {
    
   }

   getSponsorSearch(data:any) {
 
    return this.http.post<any[]>(this.EStatementURL + URL.sponsor_search, data).toPromise();;
  }
  getSummaryReport(data:any) {
 
    return this.http.post<any[]>(this.EStatementURL + URL.summary_report, data).toPromise();;
  }
  getSponsorSummaryReport(p_providerid:number ,p_spon_id:number) {
    return this.http.get<any[]>(this.EStatementURL + URL.sponsor_summary_report+"?p_providerid="+p_providerid+"&p_spon_id="+p_spon_id ).toPromise();;
  }
  downloadSummaryReport(StatementObject: any) {

    const requestOptions: Object = {
      headers: new HttpHeaders(
        {
          'Accept': 'application/json',
          'responseType': 'blob'
        }
      ),
      responseType: 'blob'
    }
    return this.http.post<any>(this.EStatementURL + URL.download_Statement_Report, StatementObject, requestOptions);
  }
}
