import { Component, OnInit, Inject } from '@angular/core';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { dates, ProcessInfo } from '../../models/ObjectHelper';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-enter-process-information',
  templateUrl: './enter-process-information.component.html',
  styleUrls: ['./enter-process-information.component.css']
})
export class EnterProcessInformationComponent implements OnInit {

  Dates: any = dates;
  UserData: any[] = [];
  Statements: string[] = [];
  Response: any = null;
  User:any;

  selectedDates:string="";
  selectedFileSize:string="";
  selectedLocation:string="";

  Email:string[]=[]

  constructor(private dialogRef: MatDialogRef<EnterProcessInformationComponent>, private participantService: ParticipantService, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.UserData = this.data.processStatement;
    this.User = JSON.parse(String(sessionStorage.getItem("User")));

  }

  ngOnInit(): void {
    var uuids: any[] = [];
    var plan_num: any[] = [];
    this.UserData.forEach(data => {
      uuids.push(data.uid);
      plan_num.push(data.planNum);
    });
    this.Dates.u_uds = uuids;
    this.Dates.plan_num = plan_num;
    this.getDates();
    console.log(this.Statements);
    console.log(this.UserData);
  }

  getDates() {
    this.participantService.getDates(this.Dates, String(sessionStorage.getItem("token"))).subscribe((resp: any[]) => {
      resp.forEach(dates => {
        this.Statements.push(String(dates).split('T')[0])
      })
    })
  }

  ProcessInformation() {
    
    this.UserData.forEach(users => {
      var process = ProcessInfo;
      process.u_uids = this.Dates.u_uds;
      process.lastName = users.lname;
      process.firstName = users.fname;
      process.partId = users.part_id;
      process.planNum = users.planNum;
      process.plan_num = users.planNum;
      process.uid = users.uid;
      process.agentID = users.agentID;
      process.email = this.Email.toString();
      process.provider_id = this.User.ProviderID;
      process.prov_id = this.User.Provider;
      process.statementDates = this.selectedDates;
      process.isOutputToFTP = this.selectedLocation=='ftp'?true:false;
      process.isSingleFile = this.selectedFileSize=='single'?true:false;
      process.agentID = users.agentID;



      this.participantService.processStatements(process, String(sessionStorage.getItem("token"))).toPromise().then(resp => {
        this.Response = "Participant Proccessed Successfully!!";
        this.dialogRef.close();
      }).catch(error => {
        this.Response = error.error;
      })

    })

  }

  closeDialogue() {
    this.dialogRef.close();
  }

}
