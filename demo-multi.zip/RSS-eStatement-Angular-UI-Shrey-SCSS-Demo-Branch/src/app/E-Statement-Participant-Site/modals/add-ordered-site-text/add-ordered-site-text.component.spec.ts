import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOrderedSiteTextComponent } from './add-ordered-site-text.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('AddOrderedSiteTextComponent', () => {
  let component: AddOrderedSiteTextComponent;
  let fixture: ComponentFixture<AddOrderedSiteTextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOrderedSiteTextComponent ],
      imports:[HttpClientModule,RouterTestingModule,MatDialogModule,BrowserAnimationsModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOrderedSiteTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
