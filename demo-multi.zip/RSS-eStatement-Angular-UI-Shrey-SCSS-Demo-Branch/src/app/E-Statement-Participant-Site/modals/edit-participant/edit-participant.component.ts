import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-participant',
  templateUrl: './edit-participant.component.html',
  styleUrls: ['./edit-participant.component.css']
})
export class EditParticipantComponent implements OnInit {

  ParticipantData: any;
  ParticipantForm!: FormGroup;
  constructor(private dialogRef: MatDialogRef<EditParticipantComponent>, private participantService: ParticipantService, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.ParticipantData = this.data.partcipant;
    this.ParticipantForm = new FormGroup({
      fname: new FormControl(this.ParticipantData.FName == undefined ? "" : this.ParticipantData.FName),
      mi: new FormControl(this.ParticipantData.MI == undefined ? "" : this.ParticipantData.MI),
      lname: new FormControl(this.ParticipantData.LName == undefined ? "" : this.ParticipantData.LName),
      email: new FormControl(this.ParticipantData.EMail == undefined ? "" : this.ParticipantData.EMail),
      password: new FormControl(this.ParticipantData.password == undefined ? "" : this.ParticipantData.password),
      statuscode: new FormControl(this.ParticipantData.statusname == undefined ? "" : this.ParticipantData.statusname),
      part_id: new FormControl(this.ParticipantData.ParticipantID == undefined ? 0 : this.ParticipantData.ParticipantID),
      acctnumber: new FormControl(this.ParticipantData.AcctNumber == undefined ? "" : this.ParticipantData.AcctNumber),
      setAdmin: new FormControl(true),
      uuid: new FormControl(this.data.uuid == undefined ? "" : this.data.uuid)
    })
  }

  saveInformation() {
    this.participantService.updateParticipant(this.ParticipantForm.value, String(sessionStorage.getItem("token"))).toPromise().then(resp => {
      this.dialogRef.close();
    })
  }

}
