import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { JsonPipe } from '@angular/common';
import { ProfileService } from '../../services/profile-service/profile.service';
import { existingUser, update_user, add_user } from '../../models/ObjectHelper';

@Component({
  selector: 'app-staff-access',
  templateUrl: './staff-access.component.html',
  styleUrls: ['./staff-access.component.css']
})
export class StaffAccessComponent implements OnInit {

  staffaccess!: FormGroup;
  Users:any[]=[];
  User:any;

  selectedUser:any=null;
  constructor(private profile_service:ProfileService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }


  ngOnInit(): void {

    this.staffaccess = new FormGroup({
      lname: new FormControl('', Validators.required),
      fname: new FormControl('', Validators.required),
      userid: new FormControl('', [Validators.required,Validators.maxLength(10)]),
      password: new FormControl('', Validators.required),
      profileid: new FormControl('', Validators.required),
      HideSensitivePlans: new FormControl(false),
      InternalUser: new FormControl(false),
      dtnumber: new FormControl('', Validators.required)

    });

    this.getUsers(this.User.ProviderID);

  }

  ViewRecords(event:any){
    let value = event.target.value;
    this.selectedUser = this.Users.filter(ele=>ele.control_id==value)[0];
    this.FillForm();
  }

  FillForm(){
    this.staffaccess.patchValue({
      lname: this.selectedUser.control_name,
      fname: this.selectedUser.fname,
      userid: this.selectedUser.userid,
      password: this.selectedUser.password,
      profileid: this.selectedUser.profileid,
      HideSensitivePlans: this.selectedUser.hidesensitiveplans,
      InternalUser: this.selectedUser.isInternalUser,
      dtnumber: this.selectedUser.dtnumber

    })
  }

  getUsers(ProviderID:string){
    this.profile_service.getUsers(ProviderID,true,true).subscribe(resp=>{
      this.Users = resp;
    },error=>{
      throw new Error(error.error.message);
    })
  }


  SaveIt() {
    if (this.staffaccess.valid) {
      alert("Saved record" + JSON.stringify(this.staffaccess.value));
    } else {
      alert("Please fill the required data points");
    }
  }

  Add(){
    if(this.staffaccess.valid){
    let Add_User= add_user;
    let values = this.staffaccess.value;
    Add_User.control_name = values.lname;
    Add_User.fname = values.fname;
    Add_User.userid = values.userid;
    Add_User.userPassword = values.password;
    Add_User.profileid = values.profileid;
    Add_User.hidesensitiveplans = values.HideSensitivePlans;
    Add_User.InternalUser = false;
    Add_User.isinternaluser = values.InternalUser;
    Add_User.dtnumber = values.dtnumber;
    Add_User.ProviderID = this.User.ProviderID;
    this.profile_service.AddUser(Add_User).toPromise().then(resp=>{

      this.getUsers(this.User.ProviderID);
    }).catch(error=>{

    })
  }
  }

  Update(){
    if(this.staffaccess.valid){
      let Update_User= update_user
      let values = this.staffaccess.value;
      Update_User.control_id = this.selectedUser.control_id;
      Update_User.failedAuthAttempts = this.selectedUser.failedAuthAttempts;
      Update_User.control_name = values.lname;
      Update_User.fname = values.fname;
      Update_User.userid = values.userid;
      Update_User.password = values.password;
      Update_User.profileid = values.profileid;
      Update_User.hidesensitiveplans = values.HideSensitivePlans;
      Update_User.isInternalUser = values.InternalUser;
      Update_User.isInternalUser = values.InternalUser;
      Update_User.dtnumber = values.dtnumber;
      this.profile_service.updateUser(Update_User,this.User.ProviderID).toPromise().then(resp=>{
  
        this.getUsers(this.User.ProviderID);
      }).catch(error=>{
  
      })
    }
  }

  Delete(){
    this.profile_service.DeleteUser(this.selectedUser.control_id).toPromise().then(resp=>{
      alert("User Deleted Successfully");
      this.getUsers(this.User.ProviderID);
    }).catch(error=>{

    })
  }
}
