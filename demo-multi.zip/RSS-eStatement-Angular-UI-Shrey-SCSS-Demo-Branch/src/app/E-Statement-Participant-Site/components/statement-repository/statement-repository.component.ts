import { Component, OnInit } from '@angular/core';
import { search_statement_repo, downloadPDF } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';

@Component({
  selector: 'app-statement-repository',
  templateUrl: './statement-repository.component.html',
  styleUrls: ['./statement-repository.component.css']
})
export class StatementRepositoryComponent implements OnInit {

  StatementPdf: any = [];

  SearchOption: string = "";
  SearchValue: string = "";
  User:any;

  selectedIndex: number = -1;
  LoadingStatement: boolean = false;

  errorStatus: boolean = false;
  errorText:string="";

  selectedOption(index: number) {
    this.selectedIndex = index;
  }

  constructor(private service: ParticipantService, private security_service: SecurityService,private download_service:DownloadService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
  }

  search() {
    this.LoadingStatement = true;
    var search = search_statement_repo;
    if (this.SearchOption == "PN") {
      search.search_request.planName = this.SearchValue;
      search.ss_ident_request.plan_name = this.SearchValue;
    }
    if (this.SearchOption == "PC") {
      search.search_request.planName = this.SearchValue;
      search.ss_ident_request.plan_name = this.SearchValue;
    }
    if (this.SearchOption == "PLN") {
      search.search_request.lname = this.SearchValue;
    }
    search.search_request.provID = this.security_service.getClients();
    search.ss_ident_request.provID = search.search_request.provID;
    search.search_request.providerID = this.User.ProviderID;
    search.search_request.iSID = this.User.Role=='spon'?this.User.userid:0;
    search.search_request.SpadID = this.User.Role=='spon'?this.User.userid:0;
    search.search_request.AdminID = this.User.Role=='admin'?this.User.userid:0;
    search.search_request.bSponsor = this.User.Role=='spon'?true:false;
    
    this.service.getStatements(search, String(sessionStorage.getItem("token"))).subscribe((resp: any[]) => {
      this.StatementPdf = resp;
      this.LoadingStatement = false;
    }, error => {
      this.errorStatus = true;
      this.errorText="No Statement found for these settings"
      this.LoadingStatement = false;
    })

  }

  downloadPDF(){
    let downloadPDFObject = downloadPDF;
    downloadPDFObject.FileName = this.StatementPdf[this.selectedIndex].FILE_NAME;
    downloadPDFObject.Date = this.StatementPdf[this.selectedIndex].DATESUBMITTED;
    downloadPDFObject.ProviderId = 63;
    this.download_service.downloadStatementPDF(downloadPDFObject).toPromise().then(resp=>{
      var blob = new Blob([resp], {type: "application/pdf"});
      var link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = downloadPDFObject.FileName+".pdf";
      link.click();
    }).catch(error=>{
      this.errorText="Unable to download PDF"
    })
  }



}
