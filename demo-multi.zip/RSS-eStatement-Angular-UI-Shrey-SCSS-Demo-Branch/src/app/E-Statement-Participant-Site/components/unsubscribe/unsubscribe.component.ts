import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../../services/participant-service/participant.service';

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent implements OnInit {

  Unsubscribed: boolean = false;
  User:any;
  constructor(private participant_service:ParticipantService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
  }

  unsubscribe() {
    this.participant_service.unsubscribe(this.User.userid,this.User.ProviderID).toPromise().then(resp=>{
      this.Unsubscribed = true;
    })
    
  }

}
