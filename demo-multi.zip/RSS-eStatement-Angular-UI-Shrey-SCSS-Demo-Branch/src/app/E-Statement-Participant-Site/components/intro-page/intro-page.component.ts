import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AdminUser, ParUser, SponUser } from '../../models/User';
import { SecurityService } from '../../services/security-service/security.service';
import { OAuthService } from 'angular-oauth2-oidc';
import { authConfig } from '../../../config/auth.config';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { ProfileService } from '../../services/profile-service/profile.service';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-intro-page',
  templateUrl: './intro-page.component.html',
  styleUrls: ['./intro-page.component.css']
})
export class IntroPageComponent implements OnInit {

  provider!: string;

  UserForm: FormGroup = new FormGroup({
    userid: new FormControl('', Validators.required),
    password: new FormControl(''),
    role: new FormControl(''),
  });

  AboutPage: boolean = false;
  HomePage: boolean = true;
  FAQ: boolean = false;

  Roles:Map<string,string>=new Map<string,string>();

  ValidLogin: number = 0;
  User: any = null;

  PromoData:any[]=[];
  URL:string="";
  constructor(private router: ActivatedRoute, private route: Router, private service: SecurityService,private oauthService: OAuthService,private profile_service:ProfileService) {
    this.provider = String(this.service.getProvider().Code);
    console.log(String(router.snapshot.parent!.paramMap.get('participant')));
    this.User = JSON.parse(String(sessionStorage.getItem("User")))
    
    let token = this.oauthService.getAccessToken();
    if(token != null){
    }
    this.config();
  }

  ngOnInit(): void {
    console.log(this.service.CurrentPage);
    this.getAssignedProviderSites();
  }
  navigateBack() {
    this.route.navigateByUrl("estatement" + "/" + this.service.getClients() + "/" + this.User.Role+"/welcome-page");
  }

  public config(){
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin();
  }


  getAssignedProviderSites(){
    this.service.GetAssignedProviderSites(this.service.getProvider().Code).toPromise().then(resp=>{
      resp.forEach(role=>{
        if(role!=""){
            if(role=="Admin"){
              this.Roles.set("admin",role);
            }
            if(role=="Participant"){
              this.Roles.set("par",role);
            }
            if(role=="Sponsor"){
              this.Roles.set("spon",role);
            }
        }
      })
  }).catch(error=>{
    throw new Error(error.error.message);
  })
  }

 

  openCommunication(Link: string) {
    if (Link == "AboutPage") {
      this.AboutPage = true;
      this.HomePage = false;
      this.FAQ = false;
    }
    if (Link == "FAQ") {

      this.AboutPage = false;
      this.HomePage = false;
      this.FAQ = true;
    }

    if (Link == "HomePage") {
      this.AboutPage = false;
      this.HomePage = true;
      this.FAQ = false;
    }
  }

  logout() { this.oauthService.logOut(); }


   login() {
    let formdata = this.UserForm.value;
    console.log(formdata.role);
    if(formdata.role!=""){
      sessionStorage.setItem("Role",btoa(formdata.role));
      this.oauthService.initImplicitFlow();
    }
/*
    if(formdata.role=="admin"){
    this.profile_service.getProfiles(this.service.getProvider().Id,true).toPromise().then(resp=>{
    let ProfileID:number = resp[0].ProfileID;
    this.setupUserData(formdata,ProfileID);
    })
  }else{
    this.setupUserData(formdata,0);
  }
    
  */
 this.setupUserData(formdata,1201);

  }

  setupUserData(formdata:any,ProfileID:number){
    switch(formdata.role){
      case "admin":
              let user_admin: AdminUser = new AdminUser();
              user_admin.Role = formdata.role;
              user_admin.userid = formdata.userid;
              user_admin.Provider = this.provider;
              user_admin.ProviderID = this.service.getProvider().Id;
              user_admin.ProviderName = this.service.getProvider().Name;
              user_admin.ProfileId = String(ProfileID);
              sessionStorage.setItem("User", JSON.stringify(user_admin));
              break;
      case "par":
              let user_par: ParUser = new ParUser();
              user_par.Role = formdata.role;
              user_par.Provider = this.provider;
              user_par.ProviderID = this.service.getProvider().Id;
              user_par.ProviderName = this.service.getProvider().Name;
              sessionStorage.setItem("User", JSON.stringify(user_par));
              break;
      case "spon":
              let user_spon: SponUser = new SponUser();
              user_spon.Role = formdata.role;
              user_spon.Provider = this.provider;
              user_spon.ProviderID = this.service.getProvider().Id;
              user_spon.ProviderName = this.service.getProvider().Name;
              sessionStorage.setItem("User", JSON.stringify(user_spon));
              break;
    }
  }
  
 

}
