import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unsubscribe-edelivery',
  templateUrl: './unsubscribe-edelivery.component.html',
  styleUrls: ['./unsubscribe-edelivery.component.css']
})
export class UnsubscribeEDeliveryComponent implements OnInit {

  Unsubscribed:boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

  unsubscribe(){
    this.Unsubscribed = true;
  }


}
