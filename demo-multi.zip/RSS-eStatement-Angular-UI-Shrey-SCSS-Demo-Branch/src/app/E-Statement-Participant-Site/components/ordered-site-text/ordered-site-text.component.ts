import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddOrderedSiteTextComponent } from '../../modals/add-ordered-site-text/add-ordered-site-text.component';
import { trigger, state, transition, style, animate } from '@angular/animations';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-ordered-site-text',
  templateUrl: './ordered-site-text.component.html',
  styleUrls: ['./ordered-site-text.component.css'],
  animations: [
    trigger('openClose', [
      state('true', style({ width: '*', display: '*', overflow: '*' })),
      state('false', style({ width: '0%', display: 'none', overflow: 'hidden' })),
      transition('false <=> true', animate(500))
    ]),
    trigger('expand', [
      state('true', style({ width: '*' })),
      state('false', style({ width: '90%' })),
      transition('false <=> true', animate(500))
    ]),
    trigger('openClosePreview', [
      state('false', style({ width: '0%', display: 'none' })),
      state('true', style({ width: '*', display: '*' })),
      transition('false <=> true', animate(500))
    ])
  ]
})
export class OrderedSiteTextComponent implements OnInit {

  State: boolean = true;
  User: any;

  UtilitiesData: any[] = [];
  FilteredUtilitiesData: any[] = [];
  UtilitiesType: string[] = [];

  selectedIndex: number = -1;
  selectedType: string = "";
  constructor(private utility_service: UtilityService, public dialog: MatDialog) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.loadOrderedTextUtilitiesOptions();
    this.loadOrderedTextUtilities();
  }

  loadOrderedTextUtilitiesOptions() {

    this.utility_service.getOrderedTextUtilitiesOptions(this.User.ProviderID, this.User.ProfileId).then(resp => {    
      debugger;
      this.UtilitiesType = resp;
    }).catch(error => {

    });
  }

  loadOrderedTextUtilities() {

    this.utility_service.getOrderedTextUtilities(this.User.ProviderID, this.User.ProfileId).then(resp => {
      debugger;
      this.UtilitiesData = resp;
     // let utilities: Set<string> = new Set<string>();
     // this.UtilitiesData.forEach(data => {
       // utilities.add(data.Type);
     // })
      //this.UtilitiesType = Array.from(utilities);
    }).catch(error => {

    });
  }

  orderedUtilitySelect() {
    this.FilteredUtilitiesData = this.UtilitiesData.filter(data => data.Type == this.selectedType);
    debugger;
  }


  add() {
    let dialogue = this.dialog.open(AddOrderedSiteTextComponent);
    
    dialogue.afterClosed().toPromise().then(resp => {
      debugger;
      this.UtilitiesData.push({
        Order: this.UtilitiesData.length,
        Header: resp.data.Header,
        Body: resp.data.editorText,
        Active: resp.data.Active,
        IsFaqHeader: false,
        Type: this.selectedType
      });      
      this.orderedUtilitySelect();

      this.SaveData();

    }).catch(error => {

    })
  }

  edit() {
    let dialogue = this.dialog.open(AddOrderedSiteTextComponent, { data: this.FilteredUtilitiesData[this.selectedIndex] });
    dialogue.afterClosed().toPromise().then(resp => {
      debugger;
      let index = this.UtilitiesData.indexOf(this.FilteredUtilitiesData[this.selectedIndex]);
      this.UtilitiesData[index] = {
        Order: index,
        Header: resp.data.Header,
        Body: resp.data.editorText,
        Active: resp.data.Active,
        IsFaqHeader: false,
        Type: this.selectedType
      };
      this.orderedUtilitySelect();
      this.SaveData();
    }).catch(error => {

    })
  }

  generateOrderedtext(): string {
    let text = "";
    debugger;
    this.FilteredUtilitiesData.forEach(data => {
      text += data.Order + ",'" + (String(data.Header).replace(',', '')) + "','" + (String(data.Body).replace(',', '')) + "'," + (data.Active == true ? 1 : 0) + "|";
    });
    return text.substring(0, text.length - 1);
  }

  SaveData() {
    this.utility_service.saveOrderedTextUtilities(this.User.ProviderID, this.selectedType, this.generateOrderedtext()).then(resp => {
     this.orderedUtilitySelect();
    
    }).catch(error => {

    })
  }

  delete() {
    debugger;
    this.FilteredUtilitiesData.splice(this.selectedIndex, 1);
    this.UtilitiesData.splice(this.selectedIndex, 1);
    this.SaveData();
  }

  moveUp() {
    if (this.selectedIndex != 0) {
      let prevObject = this.FilteredUtilitiesData[this.selectedIndex - 1];
      this.FilteredUtilitiesData[this.selectedIndex - 1] = this.FilteredUtilitiesData[this.selectedIndex];
      this.FilteredUtilitiesData[this.selectedIndex] = prevObject;
      this.selectedIndex = this.selectedIndex - 1;
    }
  }


  moveDown() {
    if (this.selectedIndex != (this.FilteredUtilitiesData.length - 1)) {
      let prevObject = this.FilteredUtilitiesData[this.selectedIndex + 1];
      this.FilteredUtilitiesData[this.selectedIndex + 1] = this.FilteredUtilitiesData[this.selectedIndex];
      this.FilteredUtilitiesData[this.selectedIndex] = prevObject;
      this.selectedIndex = this.selectedIndex + 1;
    }
  }

  selectedOption(index: number) {
    this.selectedIndex = index;
  }

  action_preview() {
    if (this.State) {
      this.State = false;
    } else {
      this.State = true;
    }
  }

}
