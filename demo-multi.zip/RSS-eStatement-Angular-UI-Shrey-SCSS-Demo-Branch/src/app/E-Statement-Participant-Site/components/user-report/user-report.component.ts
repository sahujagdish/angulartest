import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { user_repot } from '../../models/ObjectHelper';
import { ReportService } from '../../services/report-service/report.service';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';

@Component({
  selector: 'app-user-report',
  templateUrl: './user-report.component.html',
  styleUrls: ['./user-report.component.css']
})
export class UserReportComponent implements OnInit {

  UserReport: any[] = [];
  FilteredUserReport: any[] = [];

  PageSize: number = 6;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.UserReport.length / this.PageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.PageSize;
  selectedIndex: number = -1;

  errorStatus: boolean = false;
  LoadingUserReport: boolean = false;
  UserObject: any;

  Provider!: string;
  UserForm: FormGroup = new FormGroup({
    statusCode: new FormControl(''),
    planName: new FormControl(''),
    lastName: new FormControl(''),
  })

  User:any;

  StatusCode: any[] = [];
  constructor(public route: Router, public router: ActivatedRoute, private report_service: ReportService, private security_service: SecurityService, private download_service: DownloadService) {
    this.Provider = String(this.router.snapshot.paramMap.get("participant"));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));

  }

  ngOnInit(): void {
    this.UserReport = [];
    this.getStatusCode();
  }

  setupPage() {
    this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);
    this.totalPage = Math.ceil(this.UserReport.length / this.PageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;

  }

  selectedOption(index: number) {
    this.selectedIndex = index;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.FilteredUserReport = this.UserReport.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }
  }

  getStatusCode() {
    this.report_service.getStatusCode(true, false, false).toPromise().then(resp => {
      this.StatusCode = resp;
    }, error => {

    })
  }

  getUserReports() {
    this.LoadingUserReport = true;

    this.UserObject = user_repot;
    // UserObject.StatusCode = this.UserForm.value.statusCode;
    this.UserObject.PlanNumber = this.UserForm.value.planName;
    this.UserObject.LastName = this.UserForm.value.lastName;
    this.UserObject.ProvID = this.security_service.getClients();
    this.UserObject.ProviderID = this.User.ProviderID;
    this.report_service.getUserReports(this.UserObject, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
      this.UserReport = resp.list;
      this.setupPage();
      this.LoadingUserReport = false;
    }, error => {
      this.errorStatus = true;

      this.LoadingUserReport = false;
    })
  }

  donwloadUserReport() {

    this.download_service.downloadUserReport(this.UserObject).toPromise().then(resp => {

      let report = atob(resp.FileContents);
      this.exportToCsv((resp.FileDownloadName == "" ? "UserReport.csv" : resp.FileDownloadName) , report);

    }).catch(error => {

    })
  }

  exportToCsv(filename: string, csvContent: string) {

    const blob = new Blob([csvContent], { type: 'application/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

}
