import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ReportService } from '../../services/report-service/report.service';
import { audit_repot, planlist } from '../../models/ObjectHelper';
import { FormGroup, FormControl } from '@angular/forms';
import { SecurityService } from '../../services/security-service/security.service';
import { DownloadService } from '../../services/download-service/download.service';
import { ParticipantService } from '../../services/participant-service/participant.service';

@Component({
  selector: 'app-audit-report',
  templateUrl: './audit-report.component.html',
  styleUrls: ['./audit-report.component.css']
})
export class AuditReportComponent implements OnInit {

  AuditReport: any[] = [];
  FilteredAuditReport: any[] = [];

  FilteredPlanList: any[] = [];
  PlanList: any[] = [];


  PageSize: number = 6;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.AuditReport.length / this.PageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.PageSize;
  selectedIndex: number = -1;

  errorStatus: boolean = false;
  LoadingReport: boolean = false;

  AuditObject: any;

  AuditTypes: any[] = []
  Provider!: string;
  AuditForm: FormGroup = new FormGroup({
    auditType: new FormControl(0),
    planName: new FormControl(''),
    lastName: new FormControl(''),
    SSN: new FormControl(''),
    From: new FormControl(''),
    To: new FormControl('')
  })

  User:any=null;

  constructor(public route: Router, public router: ActivatedRoute,private participantService: ParticipantService, private report_service: ReportService, private security_service: SecurityService, private download_service: DownloadService) {
    this.Provider = String(this.router.snapshot.paramMap.get("participant"));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));

  }

  ngOnInit(): void {
    this.setupPage();
    this.loadAuditTypes();
    this.onChange();
  }

  setupPage() {
    this.FilteredAuditReport = this.AuditReport.slice(this.startIndex, this.endIndex);
    this.totalPage = Math.ceil(this.AuditReport.length / this.PageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;

  }

  onChange() {
    let plan_list = planlist;
    plan_list.PlanName = this.AuditForm.value.planName;
    plan_list.ProviderID = this.User.ProviderID;
    plan_list.AdminID = this.User.userid;
    this.participantService.getPlanList(plan_list, String(sessionStorage.getItem("token"))).subscribe(resp => {
      this.PlanList = resp;
      this.FilteredPlanList = resp;
    }, error => {
      this.errorStatus = true;
    })
  }
  filter() {
    this.FilteredPlanList = this.PlanList.filter(plan => plan.PlanName.toUpperCase().includes(this.AuditForm.value.planName.toUpperCase()));
  }


  selectedOption(index: number) {
    this.selectedIndex = index;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.FilteredAuditReport = this.AuditReport.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.FilteredAuditReport = this.AuditReport.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }
  }

  getAuditReports() {

    if(this.AuditForm.value.From!="" && this.AuditForm.value.To!=""){
    this.LoadingReport = true;

    this.AuditObject = audit_repot;
    this.AuditObject.AuditCode = this.AuditForm.value.auditType;
    this.AuditObject.PlanNumber = this.AuditForm.value.planName;
    this.AuditObject.LastName = this.AuditForm.value.lastName;
    this.AuditObject.SSN = this.AuditForm.value.SSN;
    this.AuditObject.StartDate = this.AuditForm.value.From;
    this.AuditObject.EndDate = this.AuditForm.value.To;
    this.AuditObject.ProvID = this.User.Provider;
    this.AuditObject.ProviderID = this.User.ProviderID;
    this.AuditObject.iSID = this.User.Role=='spon'?this.User.userid:0;  

    this.report_service.getAuditReports(this.AuditObject, String(sessionStorage.getItem("token"))).subscribe((resp: any) => {
      this.AuditReport = resp.list;
      this.setupPage();
      this.LoadingReport = false;
    }, error => {
      this.errorStatus = true;
      this.LoadingReport = false;
    })
  }else{
    alert("Please Input To and From Date");
  }
  }

  loadAuditTypes() {
    this.report_service.getAuditType(true, false, false, true).toPromise().then(resp => {
      this.AuditTypes = resp;
    });
  }

  donwloadAuditReport() {

    this.download_service.downloadAuditReport(this.AuditObject).toPromise().then(resp => {

      let report = atob(resp.FileContents);
      this.exportToCsv((resp.FileDownloadName == "" ? "AuditReport.csv" : resp.FileDownloadName) , report);

    }).catch(error => {

    })
  }

  exportToCsv(filename: string, csvContent: string) {

    const blob = new Blob([csvContent], { type: 'application/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }



}
