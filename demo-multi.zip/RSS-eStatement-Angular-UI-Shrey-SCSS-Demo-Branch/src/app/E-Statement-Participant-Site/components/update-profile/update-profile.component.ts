import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { participant } from '../../models/ObjectHelper';
import { environment } from '../../../../environments/environment';
import { profile } from '../../models/ObjectHelper'
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  profileForm!: FormGroup;
  ProfileObject: any;
  isUpdated: boolean = false;
  errorStatus: boolean = false;
  User:any;
  constructor(private participant_service: ParticipantService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));

  }

  ngOnInit(): void {
    var edit = participant;
    edit.parUUID = this.User.PartUUID;

    this.participant_service.getParticipantData(edit, String(sessionStorage.getItem("token"))).subscribe(resp => {
      this.ProfileObject = resp[0];
      this.setupProfile(resp[0]);
    }, error => {
      this.errorStatus = true;
      //this.setupProfile(undefined);
    })

  }

  setupProfile(ProfileObject: any) {
    this.profileForm = new FormGroup({
      fname: new FormControl(ProfileObject.FName == undefined ? '' : ProfileObject.FName),
      mi: new FormControl(ProfileObject.MI == undefined ? '' : ProfileObject.MI),
      lname: new FormControl(ProfileObject.LName == undefined ? '' : ProfileObject.LName),
      email: new FormControl(ProfileObject.EMail == undefined ? '' : ProfileObject.EMail),
      userid: new FormControl(ProfileObject.UserID == undefined ? '' : ProfileObject.UserID),
      password: new FormControl(ProfileObject.password == undefined ? '' : ProfileObject.password),
      confirmpass: new FormControl(ProfileObject.password == undefined ? '' : ProfileObject.password),
    }, { validators: this.checkPasswords });

  }

  checkPasswords: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
    let pass = group.get('password')!.value;
    let confirmPass = group.get('confirmpass')!.value
    return pass === confirmPass ? null : { notSame: true }
  }

  updateProfile() {
    this.isUpdated = true;
    
   this.participant_service.updateProfile(this.setupProfileObject(),String(sessionStorage.getItem("token"))).toPromise().then(resp=>{
   }).catch(error=>{
   })
  }

  setupProfileObject() {
    var profiles = profile;
    var updatedprofile = this.profileForm.value;
    profiles.fname = updatedprofile.fname;
    profiles.mi = updatedprofile.mi;
    profiles.lname = updatedprofile.lname;
    profiles.email = updatedprofile.email;
    profiles.userid = updatedprofile.userid;
    profiles.password = updatedprofile.password;
    profiles.account_number = this.ProfileObject.AcctNumber;
    profiles.participantuuid = this.User.PartUUID;
    profiles.vcode = this.ProfileObject.vcode;
    profiles.statuscode = this.ProfileObject.StatusCode;
    profiles.ssn = this.ProfileObject.SSN;
    return profiles;
  }

  reset() {
    this.profileForm.reset();
  }

}
