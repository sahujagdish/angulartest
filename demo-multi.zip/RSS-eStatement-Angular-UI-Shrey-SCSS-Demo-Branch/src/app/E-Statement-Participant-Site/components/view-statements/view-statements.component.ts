import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SecurityService } from '../../services/security-service/security.service';
import { StatementService } from '../../services/statement-service/statement.service';
import { statement_admin, statement_par, statement_spon } from '../../models/ObjectHelper';
import { DownloadService } from '../../services/download-service/download.service';

@Component({
  selector: 'app-view-statements',
  templateUrl: './view-statements.component.html',
  styleUrls: ['./view-statements.component.css']
})
export class ViewStatementsComponent implements OnInit {

  Statements: any;
  ProviderId: string = "";
  User: any;
  PartID: string = "";
  UUID: string = "";
  error:boolean=false;
  constructor(private route: Router, private router: ActivatedRoute, private security_service: SecurityService, private statement_service: StatementService, private download_service: DownloadService) {
    this.ProviderId = this.security_service.getClients();
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.UUID = String(router.snapshot.queryParamMap.get("uid"));
    this.PartID = String(router.snapshot.queryParamMap.get("partid"));
  }

  ngOnInit(): void {
    this.getViewStatementData(this.User.Role);
  }

  getViewStatementData(Role: string) {
    switch (Role) {
      case "admin":
        this.getStatementDataforAdmin(this.UUID, this.PartID, this.User.Provider);
        break;
      case "par":
        this.getStatementDataforPar(this.User.PartId, this.User.Provider);
        break;
      case "spon":
        this.getStatementDataforSpon(this.User.Provider, this.UUID, this.User.ISIN);
        break;
    }
  }

  getStatementDataforAdmin(UUID: string, PartID: string, Provider: string) {
    let statementObject = statement_admin;
    statementObject.UID = UUID;
    statementObject.VirtualDir = Provider;
    this.statement_service.getStatementsDataAdmin(statementObject).toPromise().then(resp => {
      this.Statements = resp;
    }).catch(error => {
      throw new Error(error.error.message);
    })
  }
  getStatementDataforPar(PartID: string, Provider: string) {
    let statementObject = statement_par;
    statementObject.ParticipantId = Number(PartID);
    statementObject.VirtualDir = Provider;
    this.statement_service.getStatementsDataPar(statementObject).toPromise().then(resp => {
      if(resp.Header=="Statements"){
        this.Statements = resp;
        }else{
          this.Statements.BlockList=[];
        }
    }).catch(error => {
      throw new Error(error.error.message);
    })
  }
  getStatementDataforSpon(Provider: string, UID: string, ISIN: string) {
    let statementObject = statement_spon;
    statementObject.VirtualDir = "demo";
    statementObject.UID = UID;
    statementObject.ISIN = Number(ISIN);
    this.statement_service.getStatementsDataSpon(statementObject).toPromise().then(resp => {
      this.Statements = resp;
    }).catch(error => {
      throw new Error(error.error.message);
    })
  }

  getStatement(downloadQuery: string) {
    if (downloadQuery != "") {
      this.download_service.downloadViewStatementPDF(downloadQuery).toPromise().then(resp => {

      }).catch(error => {

      })
    } else {
      alert("No Statement File Available");
    }
  }


  back() {
    this.route.navigate(["../../access-participant-info"], { relativeTo: this.router });
  }



}
