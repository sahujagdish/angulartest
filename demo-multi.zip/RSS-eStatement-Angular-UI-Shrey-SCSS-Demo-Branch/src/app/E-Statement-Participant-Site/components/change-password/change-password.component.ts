import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import { SecurityService } from '../../services/security-service/security.service';
import { Md5 } from 'ts-md5/dist/md5';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  passwordControl!: FormGroup;
  passwordChangeStatus: boolean = false;
  errorMessage: string = "";
  PasswordObject: any = {
    UUId: 0,
    Current_pass: "",
    New_pass: "",
    InitialLogin: true,
    TargetType: "Administrator"
  }

  User:any;
  constructor(private security_service: SecurityService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.PasswordObject.UUId = this.User.UUID;
    this.passwordControl = new FormGroup({
      currentPassword: new FormControl(''),
      newPassword: new FormControl('', [Validators.required, Validators.minLength(8)]),
      confirmPassword: new FormControl('')
    }, { validators: this.checkPasswords });
  }

  checkPasswords: ValidatorFn = (group: AbstractControl): ValidationErrors | null => {
    let pass = group.get('newPassword')!.value;
    let confirmPass = group.get('confirmPassword')!.value
    return pass === confirmPass ? null : { notSame: true }
  }

  changePassword() {
    if (this.passwordControl.valid) {
      this.PasswordObject.Current_pass = new Md5().appendStr(this.passwordControl.value.currentPassword).end();
      this.PasswordObject.New_pass = new Md5().appendStr(this.passwordControl.value.newPassword).end();

      if (sessionStorage.getItem("token") != null) {

        this.security_service.changePassword(this.PasswordObject, String(sessionStorage.getItem("token"))).then(response => {
          this.passwordChangeStatus = true;
        }).catch(error => {
          this.errorMessage = error.error;
          this.passwordChangeStatus = false;
        });

      }
    }

  }

}
