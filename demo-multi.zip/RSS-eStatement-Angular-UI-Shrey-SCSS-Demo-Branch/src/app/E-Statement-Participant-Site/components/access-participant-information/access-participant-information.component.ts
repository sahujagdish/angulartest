import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EditParticipantComponent } from '../../modals/edit-participant/edit-participant.component';
import { EnterProcessInformationComponent } from '../../modals/enter-process-information/enter-process-information.component';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { search, participant, planlist } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-access-participant-information',
  templateUrl: './access-participant-information.component.html',
  styleUrls: ['./access-participant-information.component.css']
})
export class AccessParticipantInformationComponent implements OnInit {

  ParticipantStatement: any[] = [];
  FilteredParticipantStatement: any[] = [];

  ParticipantProcess: any[] = [];
  FilteredParticipantProcess: any[] = [];

  PlanList: any[] = [];
  FilteredPlanList: any[] = [];

  PageSize: number = 6;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.ParticipantStatement.length / this.PageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.PageSize;
  selectedIndex: number = -1;

  Provider!: string;

  SelectedItem: number = -1;
  SearchForm!: FormGroup;

  errorStatus: boolean = false;
  LoadingPartStatement: boolean = false;
  User: any;

  constructor(public dialog: MatDialog, public route: Router, public router: ActivatedRoute, private participantService: ParticipantService, private securityService: SecurityService) {
    this.Provider = String(this.router.snapshot.parent!.paramMap.get("participant"));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {


    this.SearchForm = new FormGroup({
      SSN: new FormControl('',[Validators.maxLength(11),Validators.minLength(11),Validators.pattern('^[0-9-]+$')]),
      Lname: new FormControl(''),
      Pname: new FormControl('')
    });

    let prevval = "";
      
    this.SearchForm.valueChanges.subscribe(resp => {
      let currentval = resp.SSN;
      if(resp.SSN.length==3 || resp.SSN.length==6){
        if(currentval.length>=prevval.length){
        resp.SSN = resp.SSN+"-";
        this.SearchForm.setValue(resp);
        }
      }
      prevval = currentval;
    });

    this.setupPage();
    this.onChange();
  }

  onChange() {
    if(this.User.Role=='spon'){
      this.getSponList();
    }else{
    this.getPlanList();
    }
  }

  getPlanList(){
    let plan_list = planlist;
    plan_list.PlanName = this.SearchForm.value.Pname;
    plan_list.ProviderID = this.User.ProviderID;
    plan_list.AdminID = this.User.userid;
    this.participantService.getPlanList(plan_list, String(sessionStorage.getItem("token"))).subscribe(resp => {
      this.PlanList = resp;
      this.FilteredPlanList = resp;
    }, error => {
      this.errorStatus = true;
    })
  }

  getSponList(){
   this.participantService.getSponPlanName(this.User.ISIN).toPromise().then(resp=>{
    this.SearchForm.patchValue({
      Pname:resp[0].PlanNumber
    });
   }).catch(error=>{

   }) 
  }

  filter() {
    this.FilteredPlanList = this.PlanList.filter(plan => plan.PlanName.toUpperCase().includes(this.SearchForm.value.Pname.toUpperCase()));
  }

  setupPage() {
    this.FilteredParticipantStatement = this.ParticipantStatement.slice(this.startIndex, this.endIndex);
    this.totalPage = Math.ceil(this.ParticipantStatement.length / this.PageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.FilteredParticipantStatement = this.ParticipantStatement.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.FilteredParticipantStatement = this.ParticipantStatement.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }
  }

  selectedOption(option: any, index: number) {
    this.selectedIndex = index;


  }

  selectedItem(option: any, index: number) {
    this.SelectedItem = index;
  }

  add() {
    if (!this.ParticipantProcess.includes(this.FilteredParticipantStatement[this.selectedIndex]) && this.selectedIndex != -1) {
      this.ParticipantProcess.push(this.FilteredParticipantStatement[this.selectedIndex]);
    }
  }

  addPage() {
    this.FilteredParticipantStatement.forEach(ele => {
      if (!this.ParticipantProcess.includes(ele)) {
        this.ParticipantProcess.push(ele);
      }
    })
  }

  ProcessAll(event: any) {

    if (event.checked) {
      this.ParticipantStatement.forEach(statementinfo => {
        if (!this.ParticipantProcess.includes(statementinfo)) {
          this.ParticipantProcess.push(statementinfo);
        }
      })
    }
  }


  search() {
    console.log(this.SearchForm.valid);
    if(this.SearchForm.value.SSN!=''||this.SearchForm.value.Pname!=''|| this.SearchForm.value.Lname){
    this.LoadingPartStatement = true;
    let Search = search;
    Search.sPartID = this.SearchForm.value.SSN;
    Search.lname = this.SearchForm.value.Lname;
    Search.planName = this.SearchForm.value.Pname;
    Search.providerID = this.securityService.getProvider().Id;
    Search.provID = this.securityService.getClients();
    Search.bSponsor = this.User.Role=='spon'?true:false;
    Search.iSID = this.User.Role=='spon'?this.User.userid:0;
    Search.SpadID = this.User.Role=='spon'?this.User.userid:0;
    Search.AdminID = this.User.Role=='admin'?this.User.userid:0;

    this.participantService.search(Search, String(sessionStorage.getItem("token"))).subscribe((resp: any[]) => {
      this.ParticipantStatement = resp;
      this.setupPage();
      this.LoadingPartStatement = false;
    }, (error: any) => {
      this.errorStatus = true;
    })
  }else{
    alert("Please Enter Search Value");
  }

  }

  EditPar() {
    this.participantService.isEditable(true, "63", this.User.Provider, this.FilteredParticipantStatement[this.selectedIndex].uid, String(sessionStorage.getItem("token"))).toPromise()
      .then((resp: any) => {
        if (resp.is_editable) {
          var edit = participant;
          edit.uid = this.FilteredParticipantStatement[this.selectedIndex].uid;
          edit.parUUID = resp.participant_UUID;

          this.participantService.getParticipantData(edit, String(sessionStorage.getItem("token"))).subscribe(resp => {
            this.dialog.open(EditParticipantComponent, { data: { partcipant: resp[0], uuid: edit.uid } });
          }, (error: any) => {
            this.errorStatus = true;
          })



        }
      }).catch((error: any) => {
        this.errorStatus = true;
      })

  }

  ProcessInfo() {
    if (this.ParticipantProcess.length > 0) {
      this.dialog.open(EnterProcessInformationComponent, {
        data: {
          processStatement: this.ParticipantProcess
        }
      });
    }
  }
  //?uid="+this.FilteredParticipantStatement[this.selectedIndex].uid+"&partid="+this.FilteredParticipantStatement[this.selectedIndex].participantid
  viewStatement() {
    this.route.navigate(["../view-Statements"], { relativeTo: this.router,queryParams:{
      uid:this.FilteredParticipantStatement[this.selectedIndex].uid,
      partid:this.FilteredParticipantStatement[this.selectedIndex].participantid
    } });
  }

  removeAll() {
    this.ParticipantProcess = [];
  }

  remove() {
    this.ParticipantProcess.splice(this.SelectedItem, 1);
  }

}
