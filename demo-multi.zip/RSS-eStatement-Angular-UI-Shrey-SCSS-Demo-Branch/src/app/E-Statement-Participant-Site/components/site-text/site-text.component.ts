import { Component, OnInit } from '@angular/core';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { UtilityService } from '../../services/utility-service/utility.service';
import { StatementService } from '../../services/statement-service/statement.service';
import { planlist, planeNotification, eNotification, saveTextObject } from '../../models/ObjectHelper';
import { ParticipantService } from '../../services/participant-service/participant.service';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-site-text',
  templateUrl: './site-text.component.html',
  styleUrls: ['./site-text.component.css']
})
export class SiteTextComponent implements OnInit {

  public Editor = ClassicEditor;
  editorText: string = "";
  UtilityHeader: string = "";
  NotificationType: string = "default";

  ENotificationData: any = null;
  PlanDetails: any = [];

  PlanENotification: FormGroup = new FormGroup({
    planid: new FormControl(''),
    FromAddress: new FormControl(''),
    FromName: new FormControl('')
  })

  User: any;
  SiteTextUtilities: any[] = [];
  SiteTextUtilitiesType: string[] = [];

  Successfull:boolean=false;
  onSuccessText:string="";
  Error:boolean = false;
  onErrorText:string="";

  UnSubscribeEmailSubject:string="Hello";
  constructor(private service: UtilityService, private statement_service: StatementService, private participantService: ParticipantService) {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getSiteTextData();
    //this.getENotificationData();
  }

  getENotificationData() {
    let planid = String(this.PlanENotification.value.planid).replace(String(this.User.Provider).toUpperCase(), "");
    let externalPlanId = this.NotificationType == 'default' ? "default" : planid;
    this.statement_service.getENotificationData(this.User.ProviderID, externalPlanId).subscribe(resp => {
      this.ENotificationData = resp;
      this.editorText = this.ENotificationData[0].Data.value;     
      if (this.NotificationType == 'plan') {
        this.PlanENotification.patchValue({
          FromAddress: this.ENotificationData[1].Data.value,
          FromName: this.ENotificationData[2].Data.value
        });
      }
    }, error => {
      this.Error = true;
      this.onSuccessText = "An Error Occuered while Loading "+this.UtilityHeader;
    })

  }

  PlanSelected() {
    this.getENotificationData();
  }

  getPlans() {
    let plan_list = planlist;
    plan_list.ProviderID = this.User.ProviderID;
    plan_list.AdminID = this.User.userId;
    this.participantService.getPlanList(plan_list, "").subscribe(resp => {
      this.PlanDetails = resp;
    }, error => {
      this.Error = true;
      this.onSuccessText = "An Error Occuered while Loading Plans";
    })
  }



  getSiteTextData() {
    this.service.getSiteTextUtilities(this.User.ProviderID, this.User.ProfileId).then(resp => {
      this.SiteTextUtilities = resp;
      let utilities: Set<string> = new Set<string>();
      this.SiteTextUtilities.forEach(data => {
        utilities.add(data.Label);
      })

      this.SiteTextUtilitiesType = Array.from(utilities);
    }).catch(error => {
      this.Error = true;
      this.onSuccessText = "An Error Occuered while Loading "+this.UtilityHeader;
    });
  }

  UtilitySelected(event: any) {
    this.editorText="";
    this.UtilityHeader = event.target.value;
    if (this.UtilityHeader == "eNotification") {
      this.getENotificationData();
    }else
    if (this.UtilityHeader == "Unsubscribe Email") {
      this.setUnSubscribeEmail();
    }else{
      this.setOtherPage();
    }
  }

  setUnSubscribeEmail(){
    this.SiteTextUtilities.forEach(ele=>{
      
      if(ele.Label=="Unsubscribe Email" && ele.Name=="subject"){
        this.UnSubscribeEmailSubject = ele.Value;
      }
      if(ele.Label=="Unsubscribe Email" && ele.Name=="content"){
        this.editorText = ele.Value;
      }
    })
  }

  setOtherPage(){
    this.SiteTextUtilities.forEach(ele=>{
      if(ele.Label==this.UtilityHeader && ele.Name=="content"){
        this.editorText = ele.Value;
      }
    })
  }

  NotificationTypeSelected(event: any) {
    this.NotificationType = event.target.value;
    if (event.target.value == 'plan') {
      this.getPlans();
    }
    this.getENotificationData();
  }


  save(type:string){
    let planObject = saveTextObject;
      
    if(type=="Unsubscribe Email"){
      planObject.ProviderId = this.User.ProviderID;
      planObject.Type = this.UtilityHeader;
      planObject.Text = this.editorText;
      planObject.Subject = this.UnSubscribeEmailSubject;
      
    }else{
      planObject.ProviderId = this.User.ProviderID;
      planObject.Type = this.UtilityHeader;
      planObject.Text = this.editorText; 
    }

    this.service.saveText(planObject).then(resp=>{
      this.Successfull=true;
      this.onSuccessText=this.UtilityHeader+" Updated Successfully"
    }).catch(error=>{
      this.Error = true;
      this.onSuccessText = "An Error Occuered while Updating "+this.UtilityHeader;
    })
  }


  saveData() {
    if (this.NotificationType == "plan") {
      let planObject = planeNotification;
      planObject.utilityType = this.ENotificationData.fieldLabel;
      planObject.fromaddress = this.PlanENotification.value.FromAddress;
      planObject.fromname = this.PlanENotification.value.FromName;
      planObject.emailbody = this.editorText;
      let planid = String(this.PlanENotification.value.planid).replace(String(this.User.Provider).toUpperCase(), "");
      this.statement_service.sendENotificationPlanData(this.User.ProviderID, planid, planObject).subscribe(resp => {
        this.Successfull=true;
        this.onSuccessText=this.UtilityHeader+" Updated Successfully"
      }, error => {

        this.Error = true;
        this.onSuccessText = "An Error Occuered while Updating "+this.UtilityHeader;
      })
    } else {
      let planObject = eNotification;
      planObject.utilityType = this.ENotificationData.fieldLabel;
      planObject.emailbody = this.editorText;
      this.statement_service.sendENotificationData(this.User.ProviderID, planObject).subscribe(resp => {
        this.Successfull=true;
        this.onSuccessText=this.UtilityHeader+" Updated Successfully"
      }, error => {

        this.Error = true;
        this.onSuccessText = "An Error Occuered while Updating "+this.UtilityHeader;
      })
    }
  }



}
