import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from '../welcome/welcome.component';
import { AccessParticipantInformationComponent } from '../access-participant-information/access-participant-information.component';
import { StatementRepositoryComponent } from '../statement-repository/statement-repository.component';
import { ChangePasswordComponent } from '../change-password/change-password.component';
import { ViewStatementsComponent } from '../view-statements/view-statements.component';
import { AuditReportComponent } from '../audit-report/audit-report.component';
import { UserReportComponent } from '../user-report/user-report.component';
import { StaffAccessComponent } from '../staff-access/staff-access.component';
import { StaffProfilesComponent } from '../staff-profiles/staff-profiles.component';
import { SummaryReportComponent } from '../summary-report/summary-report.component';
import { SiteTextComponent } from '../site-text/site-text.component';
import { OrderedSiteTextComponent } from '../ordered-site-text/ordered-site-text.component';
import { StatementPrintApprovalComponent } from '../statement-print-approval/statement-print-approval.component';
import { MyDocumentsComponent } from '../my-documents/my-documents.component';
import { ViewCommunicationComponent } from '../view-communication/view-communication.component';
import { PersonalizedInformationComponent } from '../personalized-information/personalized-information.component';
import { UnsubscribeComponent } from '../unsubscribe/unsubscribe.component';
import { UnsubscribeEDeliveryComponent } from '../unsubscribe-edelivery/unsubscribe-edelivery.component';
import { FAQComponent } from '../faq/faq.component';
import { UpdateProfileComponent } from '../update-profile/update-profile.component';
import { DisclosureComponent } from '../disclosure/disclosure.component';
import { NewsletterComponent } from '../newsletter/newsletter.component';
import { NgModule } from '@angular/core';
import { HomePageComponent } from './home-page.component';

const routes: Routes = [
    {path:'',component:HomePageComponent,children:[
        {path:'welcome-page',component:WelcomeComponent},
        {path:'access-participant-info',component:AccessParticipantInformationComponent},
        {path:'statement-repo',component:StatementRepositoryComponent},
        {path:'changePassword',component:ChangePasswordComponent},
        {path:'view-Statements',component:ViewStatementsComponent},
        {path:'auditReport',component:AuditReportComponent},
        {path:'userReport',component:UserReportComponent},
        {path:'staffAccess',component:StaffAccessComponent},
        {path:'staffProfiles',component:StaffProfilesComponent},
        {path:'summaryReport',component:SummaryReportComponent},
        {path:'siteText',component:SiteTextComponent},
        {path:'orderedSiteText',component:OrderedSiteTextComponent},
        {path:'statement-print-approval',component:StatementPrintApprovalComponent},
        {path:'my-documents',component:MyDocumentsComponent},
        {path:'view-communications',component:ViewCommunicationComponent},
        {path:'personalized-information',component:PersonalizedInformationComponent},
        {path:'unsubscribe',component:UnsubscribeComponent},
        {path:'unsubscribe-eDelivery',component:UnsubscribeEDeliveryComponent},
        {path:'faq',component:FAQComponent},
        {path:'update-profile',component:UpdateProfileComponent},
        {path:'disclosure',component:DisclosureComponent},
        {path:'newsletter',component:NewsletterComponent},
        {path:'Welcome',redirectTo:'welcome-page'},
        {path:'message-board',loadChildren:()=>import('../../../smb/smb.app.module').then(m=>m.SmbAppModule)}
    ]}
];
//routes = routes.concat(EStatementParticipantroute);
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoute { }
