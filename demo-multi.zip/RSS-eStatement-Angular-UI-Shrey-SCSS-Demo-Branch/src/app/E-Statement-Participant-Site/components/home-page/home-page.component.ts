import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from '../../services/security-service/security.service';
import { Links } from '../../models/Links';
import { Subject } from 'rxjs';
import { OAuthService } from 'angular-oauth2-oidc';
import { ProfileService } from '../../services/profile-service/profile.service';
import { HelpScreen } from '../../../Help/models/HelpScreenData';
import { authConfig } from '../../../config/auth.config';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: [ './home-page.component.css']
})
export class HomePageComponent implements OnInit {

  provider!: string;
  user!: string;
  User:any;
  ToggleHelp: boolean = false;
  Links: any[] = [];
  ActiveLink: number = -1;

  userActivity: any;
  userInactive: Subject<any> = new Subject();

  
  userActivityalert: any;
  userInactivealert: Subject<any> = new Subject();

  UserState:string="start";
  //ActiveLink:number=0;
  constructor(private router: ActivatedRoute, public route: Router, private service: SecurityService,private oauthService: OAuthService,private profile_service:ProfileService) {
    this.user = atob(String(sessionStorage.getItem("Role")));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.getProfile();

    
    this.setTimeout();
    
    //Session Timeout Alert
    this.userInactivealert.subscribe(()=>{
      this.UserState="confirm";
      if(confirm("Session will expire soon. Do you want to extend it")){
        this.UserState="resume";
        clearTimeout(this.userActivity);
        clearTimeout(this.userActivityalert);
        this.setTimeout();
      }else{
      this.UserState="resume";
      }
    })

    //Session timed out
    this.userInactive.subscribe(() => {
      this.UserState="end";
      alert("Session has expired!");
      this.logout();
      sessionStorage.removeItem("SessionActive");
    });

    if (Links.get(this.user) != undefined) {
      this.service.setUserType(this.user);
    } else {
      this.route.navigate(["/error"]);
    }
  }
  ngOnInit(): void {
    this.config();
    this.getSideLinks();
  }

  public config(){
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin();
  }


  getProfile(){
    this.profile_service.getProfiles(this.User.ProviderID,true).toPromise().then(resp=>{
      let ProfileID:number = resp[0].ProfileID;
      this.User.ProfileId = String(ProfileID);
      this.getUserData();
      })
  }

  getUserData(){
    let token = this.oauthService.getAccessToken();
    let tokenObject = JSON.parse(atob(token.split('.')[1]));
    let userid = tokenObject.preferred_username;
    this.service.getUserDetails(userid,this.User.Role).toPromise().then(resp=>{
      let id = resp.UserId;
      //if(id!="0"){
      this.User.userid = String(id);
      sessionStorage.setItem("User",JSON.stringify(this.User));
      //}else{
      //alert("User doesnot exisit for "+this.User.Role+" role");
      //this.logout();
      //}
    })
  }

  getSideLinks(){
    this.service.getSideLinks(this.User.ProviderID,this.User.ProviderID).toPromise().then(resp=>{
      console.log(resp);
      this.Links = Links.get(this.service.getUserType());
    }).catch(error=>{

    })
  }

  setTimeout() {
    let state = sessionStorage.getItem("SessionActive");
    if(state!=undefined && state=="true"){
    this.userActivity = setTimeout(() => this.userInactive.next(undefined), 60000*5);
    this.userActivityalert = setTimeout(() => this.userInactivealert.next(undefined), 60000*4); 
    }
  }


  @HostListener('document:mousemove')
  @HostListener('document:keypress')
  @HostListener('document:click')
  @HostListener('document:wheel')
  refreshUserStateKeys() {
    console.log("Hello");
    if(this.UserState!="confirm"){
    clearTimeout(this.userActivity);
    clearTimeout(this.userActivityalert);
    this.setTimeout();
    }
  }

  change(index: number) {
    this.ActiveLink = index;
  }

  toggleHelpSection() {
    HelpScreen.ToggleHelp = true;
    this.route.navigate(["../Help/Intro"], { relativeTo: this.router });
  }

  logout() {
    this.oauthService.logOut();;
    sessionStorage.clear();

    //this.route.navigateByUrl("estatement/" + this.service.getClients() + "/Home");
  }

}
