import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboute-communications',
  templateUrl: './aboute-communications.component.html',
  styleUrls: ['./aboute-communications.component.css']
})
export class AbouteCommunicationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
