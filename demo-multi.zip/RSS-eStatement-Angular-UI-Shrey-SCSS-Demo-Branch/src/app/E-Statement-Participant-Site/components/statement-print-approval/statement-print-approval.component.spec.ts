import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StatementPrintApprovalComponent } from './statement-print-approval.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MatDialogModule } from '@angular/material/dialog';

describe('StatementPrintApprovalComponent', () => {
  let component: StatementPrintApprovalComponent;
  let fixture: ComponentFixture<StatementPrintApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StatementPrintApprovalComponent ],
      imports:[HttpClientModule,RouterTestingModule,MatDialogModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StatementPrintApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
