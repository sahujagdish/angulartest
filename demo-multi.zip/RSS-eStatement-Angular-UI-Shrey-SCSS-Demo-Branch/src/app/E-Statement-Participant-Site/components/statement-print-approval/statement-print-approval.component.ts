import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddOrderedSiteTextComponent } from '../../modals/add-ordered-site-text/add-ordered-site-text.component';
import { Router, ActivatedRoute } from '@angular/router';
import { StatementService } from '../../services/statement-service/statement.service';
import { approval_list, deleteObject } from '../../models/ObjectHelper';
import { ApproveComponent } from '../../modals/approve/approve.component';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-statement-print-approval',
  templateUrl: './statement-print-approval.component.html',
  styleUrls: ['./statement-print-approval.component.css']
})
export class StatementPrintApprovalComponent implements OnInit {

  StatementPrintData: any[] = [];
  FilteredStatementPrintData: any[] = [];

  PageSize: number = 6;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.StatementPrintData.length / this.PageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.PageSize;
  selectedIndex: number = -1;

  Provider!: string;
  User: any;

  PlanData: any[] = [];
  FilteredPlanData: any[] = [];

  PageSize1: number = 6;
  startIndex1: number = 0;
  totalPage1: number = Math.ceil(this.PlanData.length / this.PageSize1);
  currentPage1: number = this.totalPage > 0 ? 1 : 0;
  endIndex1: number = this.startIndex + this.PageSize;
  selectedIndex1: number = -1;

  FilterOption: string[] = [];
  LoadingStatementPrintData: boolean = false;
  LoadingPlanData: boolean = false;

  isProofGenerated: boolean = false;
  constructor(public dialog: MatDialog, public route: Router, public router: ActivatedRoute, private statement_service: StatementService, private security_service: SecurityService) {
    this.Provider = String(this.router.snapshot.paramMap.get("participant"));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getData();

  }

  getData() {
    this.LoadingStatementPrintData = true;
    this.StatementPrintData = [];

    let ApprovalObject = approval_list;
    ApprovalObject.ProvId = this.security_service.getClients();
    this.statement_service.getApprovalList(ApprovalObject).subscribe(resp => {

      let list: any[] = resp.list;
      let approvalid: any[] = [];
      
      list.forEach(ele => {
        let optionExist: boolean = this.FilterOption.filter(opt => opt == ele.Status).length > 0;
        if (optionExist == false) {
          this.FilterOption.push(ele.Status);
        }
        var approveDate = ele.Status == "Approved" ? ele.ApprovedDate : "";
        this.StatementPrintData.push({
          ZIP_FileName: ele.ZIP_FileName,
          DateSent: ele.DateSent,
          Status: ele.Status + " " + approveDate,
          Proof_date: "N/A",
          Reports: [],
          ApproverId: ele.ApproverId
        });
        approvalid.push(ele.ApproverId);
      });
    
     
      this.statement_service.getApprovalInfo(approvalid).toPromise().then(resp => {
        let report = resp[0];
        let Proof_date = new Map(Object.entries(report.proofDates))//report.proofDates;
        let report_types = new Map(Object.entries(report.reportTypes));

        for (let i = 0; i < this.StatementPrintData.length; i++) {
          let statementObject = this.StatementPrintData[i];
          statementObject.Proof_date = Proof_date.get(String(statementObject.ApproverId));
          let report:any = report_types.get(String(statementObject.ApproverId));
           statementObject.Reports = report.length>0?report:[];
          this.StatementPrintData[i] = statementObject;
        }

        

        console.log(this.StatementPrintData);

        this.setupPage();
        this.LoadingStatementPrintData = false;

      }).catch(error => {
        
        //this.LoadingStatementPrintData = false;
      });
      
     this.setupPage();
        this.LoadingStatementPrintData = false;

    }, error => {
      console.error(error.message);
    })
  }


  setupPage() {
    this.FilteredStatementPrintData = this.StatementPrintData.slice(this.startIndex, this.endIndex);
    this.totalPage = Math.ceil(this.StatementPrintData.length / this.PageSize);
    this.currentPage = this.totalPage > 0 ? 1 : 0;

  }

  setupPlanPage() {
    this.FilteredPlanData = this.PlanData.slice(this.startIndex1, this.endIndex1);
    this.totalPage1 = Math.ceil(this.PlanData.length / this.PageSize1);
    this.currentPage1 = this.totalPage1 > 0 ? 1 : 0;

  }

  generateLink(reportType: string, id: string) {
    this.statement_service.extractReport(id, reportType).toPromise().then(resp => {
    })
  }

  getProof(approverId: string) {
    this.statement_service.extractReport(approverId, "Proof").toPromise().then(resp => {
    }).catch(error => {

    })
  }

  selectedOption(index: number) {
    this.LoadingPlanData = true;
    this.selectedIndex = index;

    this.isProofGenerated = this.FilteredStatementPrintData[this.selectedIndex].Proof_date != ""
    this.FilteredPlanData = [];

    if (String(this.FilteredStatementPrintData[index].Status).includes("UnApproved")) {
      this.statement_service.getPlans(this.FilteredStatementPrintData[this.selectedIndex].ApproverId).toPromise().then(resp => {
        this.PlanData = resp;
        this.setupPlanPage();
        this.LoadingPlanData = false;
      }).catch(error => {

        this.LoadingPlanData = false;
      })
    }
  }

  selectedOptionPlans(index: number) {
    this.selectedIndex1 = index;
  }

  isGenerateProof() {
    return;
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.FilteredStatementPrintData = this.StatementPrintData.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.FilteredStatementPrintData = this.StatementPrintData.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }

  }

  filterData(event: any) {
    let val = event.target.value;
    this.FilteredStatementPrintData = this.StatementPrintData.filter(ele => ele.Status.includes(val));
  }

  openApproveDialogue() {
    if (this.selectedIndex != -1 && !(String(this.FilteredStatementPrintData[this.selectedIndex].Status)=="Approved")) {
      this.statement_service.checkAuditReportPath(this.FilteredStatementPrintData[this.selectedIndex].ApproverId,this.User.ProviderID).toPromise().then(resp=>{
        this.dialog.open(ApproveComponent, {
          width: '700px', data: {
            approvalId: this.FilteredStatementPrintData[this.selectedIndex].ApproverId
          }
        });
      }).catch(error=>{
        alert("The Report Path Doesnot Exist for the given Statement")
      });
      
    }
  }

  refresh() {
    this.getData();
  }

  deleteExtractPlan() {
    if(confirm("Are you sure you want to delete?")){
    let deletePlan = this.PlanData.filter(ele => ele.isDeleted == true);
    let deleteoptions: any[] = [];
    deletePlan.forEach(ele => {
      deleteoptions.push(ele.externalPlanId);
    })
    let deletePlanObject = deleteObject;
    deletePlanObject.ApprovalId = this.FilteredStatementPrintData[this.selectedIndex].ApproverId;
    deletePlanObject.ExtractPlansToDelete = deleteoptions;

    this.statement_service.deletePlans(deletePlanObject).toPromise().then(resp => {
      alert("Approval Deleted Successfully");
    }).catch(error => {

    })
  }


  }

  delete() {
    if(confirm("Are you sure you want to delete?")){

    this.statement_service.delete(this.FilteredStatementPrintData[this.selectedIndex].ApproverId, this.User.UUID).toPromise().then(resp => {
      alert("Approval Deleted Successfully");
  
    }).catch(error => {
      alert("Unable to delete the Plan");
    });
  }
  }

  generateProof() {
    this.statement_service.generateProof(this.FilteredStatementPrintData[this.selectedIndex].ApproverId).toPromise().then(resp => {
    }).catch(error => {
      console.error(error);
    });

  }

  nextPlanPage() {
    if (this.currentPage1 < this.totalPage1) {
      this.startIndex1 = this.endIndex1;
      this.endIndex1 = this.startIndex1 + this.PageSize1;
      this.FilteredPlanData = this.PlanData.slice(this.startIndex1, this.endIndex1);
      this.currentPage1++;
    }
  }

  previousPlanPage() {
    if (this.currentPage1 > 1) {
      this.endIndex1 = this.startIndex1;
      this.startIndex1 = this.startIndex1 - this.PageSize1;
      this.FilteredPlanData = this.PlanData.slice(this.startIndex1, this.endIndex1);
      this.currentPage1--;
    }

  }



}

/*



*/


