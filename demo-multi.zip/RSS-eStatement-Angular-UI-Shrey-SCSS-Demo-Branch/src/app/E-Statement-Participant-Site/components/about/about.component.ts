import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../../services/utility-service/utility.service';
import { SecurityService } from '../../services/security-service/security.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {


  PromoText: any[] = []

  Communication: any[] = [
    { Link: "About eStatement", LinkURL: "About-eStatements" },
    { Link: "About eCommunication", LinkURL: "About-eCommunications" },
    { Link: "FAQ", LinkURL: "faq" },
  ]

  Sample: any[] = [
    { Link: "View Sample eStatement", LinkURL: "" },
    { Link: "View Sample Newsletter", LinkURL: "" },

  ]


  constructor(private service: SecurityService,private utility_service:UtilityService) { }

  ngOnInit(): void {
    this.getPromoText();
  }

  calculateRowheight(){
    return "72vh";
  }

  getPromoText(){
    this.utility_service.getLandingPageData(this.service.getProvider().Id,"Promo Text").then(resp=>{
      this.PromoText = resp;
    }).catch(error=>{

    })
  }


}
