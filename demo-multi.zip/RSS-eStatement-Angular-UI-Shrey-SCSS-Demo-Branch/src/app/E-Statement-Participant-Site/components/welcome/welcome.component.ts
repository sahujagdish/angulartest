import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../services/security-service/security.service';
import { Links } from '../../models/Links';
import { Message } from '../../models/WelcomeMessage';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  Links: any[] = [];
  WelcomeMessages: any[] = [];
  UserType: string = "";
  User: any;
  constructor(private security_service: SecurityService) {
    this.UserType = this.security_service.getUserType();
    this.User = JSON.parse(String(sessionStorage.getItem("User")));


  }

  ngOnInit(): void {
    this.Links = Links.get(this.security_service.getUserType());
    let Messages = Message.get(this.security_service.getUserType());
    Messages.forEach((message: any) => {
      if (this.Links.filter(link => link.LinkURL.includes(message.Link)).length > 0) {
        this.WelcomeMessages.push(message);
      }
    });
  }

}
