import { Component, OnInit } from '@angular/core';
import { Documents } from '../../models/ObjectHelper';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-newsletter',
  templateUrl: './newsletter.component.html',
  styleUrls: ['./newsletter.component.css']
})
export class NewsletterComponent implements OnInit {


  NewsLetters: any[] = []

  User:any;
  constructor(private service:UtilityService) { 
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
  }

  ngOnInit(): void {
    this.getNewsLetters();
  }

  getNewsLetters(){
    this.service.getNewsletters(this.User.ProviderID).then(resp=>{
      this.NewsLetters = resp;
    }).catch(error=>{

    })
  }

}
