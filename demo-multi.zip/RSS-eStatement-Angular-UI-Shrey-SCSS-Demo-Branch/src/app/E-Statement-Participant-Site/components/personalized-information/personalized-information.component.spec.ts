import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalizedInformationComponent } from './personalized-information.component';

describe('PersonalizedInformationComponent', () => {
  let component: PersonalizedInformationComponent;
  let fixture: ComponentFixture<PersonalizedInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalizedInformationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalizedInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
