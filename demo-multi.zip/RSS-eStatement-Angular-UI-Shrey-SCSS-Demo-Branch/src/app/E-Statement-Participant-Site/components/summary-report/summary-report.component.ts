import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { SummaryService } from '../../services/summary-service/summary.service'; 
import { search_statement_repo, downloadPDF } from '../../models/ObjectHelper';


interface summaryReport {
  sponsorID: number, //SPON_ID
  sponsorName: string, //SPON_Name
  sponsorCode: string, //SPON_Num
  planCode: string,//PLAN_plan_num
  status: boolean,//SPON_Active
}
@Component({
  selector: 'app-summary-report',
  templateUrl: './summary-report.component.html',
  styleUrls: ['./summary-report.component.css']
})
export class SummaryReportComponent implements OnInit {

  SummaryReport: any[] = [];
  SponsorSummaryReport: any[] = [];
  FilteredSummaryReport: any[] = [];
  role: string = 'sponsor';


  PageSize: number = 6;
  startIndex: number = 0;
  totalPage: number = Math.ceil(this.SummaryReport.length / this.PageSize);
  currentPage: number = this.totalPage > 0 ? 1 : 0;
  endIndex: number = this.startIndex + this.PageSize;
  selectedIndex: number = -1;

  Provider!: string;
  User: any;

  StatementPdf: any = [];

  searchSponsorForm = new FormGroup({
    planCode: new FormControl(''),
    sponsorName: new FormControl(''),
    sponsorCode: new FormControl(''),
    sponsorActive: new FormControl(''),
  });
  constructor(public route: Router, public router: ActivatedRoute, private summary_service: SummaryService,) {
    this.Provider = String(this.router.snapshot.paramMap.get("participant"));
  }

  ngOnInit(): void {
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
    this.role = this.User.Role;
    if (this.role == "admin") {
      const dataToSend = {
        providerID: this.User.ProviderID,
        sponsorID: 0,
        planCode: "",
        sponsorName: "",
        sponsorCode: "",
        sponsorActive: "",
        start: 0,
        limit: 20,
        psortField: "sponsorName",
        sortDir: "ASC",
        phideSensitivePlans: false,
      }
      this.SummaryReport = [];
      this.summary_service.getSponsorSearch(dataToSend).then(res => {

        this.SummaryReport = res;
        this.FilteredSummaryReport = this.SummaryReport.slice(this.startIndex, this.endIndex);
        this.totalPage = Math.ceil(this.SummaryReport.length / this.PageSize);
        this.currentPage = this.totalPage > 0 ? 1 : 0;
      })
    } else {
      this.summary_service.getSponsorSummaryReport(this.User.ProviderID, this.User.ISIN).then(res => {
        console.log(res);
        this.SponsorSummaryReport = res;

      })
    }

  }

  downloadSummaryReport(){
    let downloadPDFObject = downloadPDF;
    downloadPDFObject.FileName = this.StatementPdf[this.selectedIndex].FILE_NAME;
    downloadPDFObject.Date = this.StatementPdf[this.selectedIndex].DATESUBMITTED;
    downloadPDFObject.ProviderId = 63;
    this.summary_service.downloadSummaryReport(downloadPDFObject).toPromise().then(resp=>{
      var blob = new Blob([resp], {type: "application/pdf"});
      var link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = downloadPDFObject.FileName+".pdf";
      link.click();
    }).catch(error=>{

    })
  }

  resetSearch() {
    this.searchSponsorForm.value.planCode = '';
    this.searchSponsorForm.value.sponsorName = '';
    this.searchSponsorForm.value.sponsorCode = '';
    this.searchSponsorForm.value.sponsorActive = '';
  }


  selectedOption(index: number, spon_id: number) {
    this.selectedIndex = index;
    //alert(spon_id)
    const dataToSend = {
      providerID: this.User.ProviderID,
      sponsorID: spon_id,
      start: 0,
      limit: 20,
    }

    this.summary_service.getSummaryReport(dataToSend).then(res => {
      //alert("res: " + JSON.stringify(res));
    });
  }

  nextPage() {
    if (this.currentPage < this.totalPage) {
      this.startIndex = this.endIndex;
      this.endIndex = this.startIndex + this.PageSize;
      this.FilteredSummaryReport = this.SummaryReport.slice(this.startIndex, this.endIndex);
      this.currentPage++;
    }

  }

  previousPage() {
    if (this.currentPage > 1) {
      this.endIndex = this.startIndex;
      this.startIndex = this.startIndex - this.PageSize;
      this.FilteredSummaryReport = this.SummaryReport.slice(this.startIndex, this.endIndex);
      this.currentPage--;
    }
  }

  sponsorSearch() {
    //console.log("Form Data: ")
    //console.log(this.searchSponsorForm.value)
    const dataToSend = {
      providerID: this.User.ProviderID,
      sponsorID: 0,
      planCode: this.searchSponsorForm.value.planCode,
      sponsorName: this.searchSponsorForm.value.sponsorName,
      sponsorCode: this.searchSponsorForm.value.sponsorCode,
      sponsorActive: this.searchSponsorForm.value.sponsorActive,
      start: 0,
      limit: 20,
      psortField: "sponsorName",
      sortDir: "ASC",
      phideSensitivePlans: false,
    }
    this.SummaryReport = [];
    this.summary_service.getSponsorSearch(dataToSend).then(res => {
      this.SummaryReport = res;
      //console.log(res)
      this.FilteredSummaryReport = this.SummaryReport.slice(this.startIndex, this.endIndex);
      this.totalPage = Math.ceil(this.SummaryReport.length / this.PageSize);
      this.currentPage = this.totalPage > 0 ? 1 : 0;
    })

  }

}
