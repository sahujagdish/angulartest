import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbouteStatementsComponent } from './aboute-statements.component';

describe('AbouteStatementsComponent', () => {
  let component: AbouteStatementsComponent;
  let fixture: ComponentFixture<AbouteStatementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbouteStatementsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbouteStatementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
