import { Component, OnInit } from '@angular/core';
import { SecurityService } from '../../services/security-service/security.service';
import { UtilityService } from '../../services/utility-service/utility.service';

@Component({
  selector: 'app-aboute-statements',
  templateUrl: './aboute-statements.component.html',
  styleUrls: ['./aboute-statements.component.css']
})
export class AbouteStatementsComponent implements OnInit {

  constructor(private service: SecurityService,private utility_service:UtilityService) { }

  ngOnInit(): void {
    this.getPromoText();
  }


  getPromoText(){
    this.utility_service.getLandingPageData(this.service.getProvider().Id,"About eStatements").then(resp=>{
      //this.PromoText = resp;
    }).catch(error=>{

    })
  }
}
