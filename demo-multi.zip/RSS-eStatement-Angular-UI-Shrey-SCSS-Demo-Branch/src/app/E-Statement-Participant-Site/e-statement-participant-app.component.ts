import { Component, OnInit, HostListener, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SecurityService } from './services/security-service/security.service';
import { Links } from './models/Links';
import { LogoService } from './services/logo-service/logo.service';
import { environment } from '../../environments/environment';

import { OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { authConfig } from '../config/auth.config';
import { config } from 'rxjs';
import { delay } from 'q';
import { promise } from 'protractor';


@Component({
  selector: 'app-e-statement-paticipant-app',
  templateUrl: './e-statement-participant-app.component.html',
  styleUrls: ['./e-statement-participant-app.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class EStatementPaticipantAppComponent implements OnInit {

  provider!: string;
  user!: string;

  ProviderLogo: any;
  User: any;

  AuthObject = {
    clientid: "",
    username: "",
    password: ""
  }

  loadingData: boolean = false;
  constructor(private route: Router, router: ActivatedRoute, private service: SecurityService, private logoservice: LogoService,private oauthService: OAuthService) {
    this.provider = String(router.snapshot.paramMap.get('participant'));
    this.User = JSON.parse(String(sessionStorage.getItem("User")));
   

  }

  public config(){
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin().then(()=>{
      let user = JSON.parse(String(sessionStorage.getItem("User")));
      if (user != undefined) {
        this.checkActiveProvider(user.Provider);
      } else {
        this.checkActiveProvider(this.provider);
      } 
    });
  }

  ngOnInit(): void {
    this.loadingData = true;    
    //this.Authenticate();
    this.config();    
  }

  // Authenticate(){    
  //     let user = JSON.parse(String(sessionStorage.getItem("User")));
  //     if (user != undefined) {
  //       this.checkActiveProvider(user.Provider);
  //     } else {
  //       this.checkActiveProvider(this.provider);
  //     }

     
  //    // set Auth token in session
  // }


  checkActiveProvider(Provider: string) {
    //debugger;
    this.service.CheckActiveProvider(Provider).toPromise().then(resp => {
      if(resp.Code!=null){
      let val:any = resp;
      this.service.setProvider(val);
      this.setupApplication();
      }else{
        this.loadingData=false;
        this.route.navigateByUrl( this.provider +"/error");
      }
      

    }).catch(error => {
      console.error(error);
      this.loadingData = false;
      this.route.navigateByUrl( this.provider + "/error");
    })
  }


  setupApplication() {
    this.service.setClients(this.provider);
    let token = this.oauthService.getAccessToken();
    if (token == undefined) {
      sessionStorage.clear();
      this.loadingData = false;
      this.route.navigateByUrl( this.provider + "/Home");
    } else {
    //debugger;
      let tokenObject = JSON.parse(atob(token.split('.')[1]));
      let role  = atob(String(sessionStorage.getItem("Role")));
      let allowed_roles:string[] = tokenObject.resource_access.eStatement.roles;
      let role_exist = false;
  //debugger;
      if(this.User != undefined) {
        this.AuthObject.clientid = this.service.getProvider().Id;
        this.AuthObject.username = tokenObject.name;
        this.service.AuthToken(this.AuthObject).subscribe(resp => {
          //debugger
          let token = resp.Result.access_token;
          sessionStorage.setItem("token", token);
      
          allowed_roles.forEach(allowed_role=>{
            if(allowed_role.toLowerCase().includes(role.toLowerCase())){
              role_exist = true;
            }
          })
          
          sessionStorage.setItem("SessionActive","true");
    
          if(role_exist){
            this.loadingData = false;
            this.route.navigateByUrl( this.provider + "/"+role+"/welcome-page");
          }else{
            alert("Access not Allowed");
            sessionStorage.clear();
            this.loadingData = false;
            this.route.navigateByUrl( this.provider + "/Home");
          }
          
        },error=>{
          this.loadingData = false;
          this.oauthService.logOut();
          alert("Invalid User for the given role");
        });
        }

      
    }

    if(token!=undefined){
    
    this.logoservice.getLogo(this.service.getProvider().Id).subscribe(resp => {

      this.logoservice.getLogos(this.service.getProvider().Id).toPromise().then(response => {
        let logos: any[] = response;
        logos = logos.filter(ele => ele.logoId == resp.logoId);
        this.ProviderLogo = logos[0];
      })
    }, error => {
      this.ProviderLogo = undefined;
    })
  
  }

  }

}
