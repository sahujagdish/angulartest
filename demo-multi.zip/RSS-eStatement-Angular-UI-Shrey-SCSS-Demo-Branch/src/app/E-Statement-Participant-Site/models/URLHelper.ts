export var URL = {
    //Security
    changePassword: "security/changepassword",
    auth: "Account/auth",
    validate_provider: "account/validate-provider",
    provider_assigned_site:"account/provider-assignedsite",
    user_details:"account/user-details",
    side_links:"account/sidebar-Links",

    // Participant
    search: "participant/statement/search",
    editable: "participant/iseditable",
    dates: "participant/statement/dates",
    participant: "participant",
    participant_patch: "participant/Patch_Participant",
    process: "participant/statement/process",
    ss_ident_partid: "participant/statement/search/ss_ident_partid",
    plan_list: "participant/plan-list",
    sponsor_plan_list:"participant/sponsor-plan-list",
    participant_unsubscribe:"participant/participant-unsubscribe",

    //Report
    audit_report: "report/audit-report",
    user_report: "report/user-report",
    audit_types: "report/audit-types",
    status_code: "report/statuscodes",
    audit_report_path:"/report/audit-report-path",
    
    //Logo
    logo: "api/v1/Statement/logos",
    
    //Statement
    approval_list: "statement/approval-list",
    approval_info: "statement/extract/approvalinfo",
    plans: "statement/extract",
    extract_report: "statement/extract",
    proof: "statement/getproof",
    delete_plan: "statement/delete-extractplans",
    delete: "statement/delete-extract",
    approve: "statement/approve",
    dataExtractReport: "api/v1/Statement/extract",
    generateProof: "statement/extract",
    e_notification:"statement/enotification",
    statement:"statement",
    
    //Utilities
    orderedTextUtilities: "Utility/orderedtext-utilities",
    orderedTextUtilitiesoptions: "Utility/orderedtext-utilities-options",
    save_orderedtext: "Utility/save-orderedtext",
    siteTextUtilities:"Utility/sitetext-utilities",
    save_text:"Utility/save-text",
    downloadFile:"Utility/download-file",
    landing_page_data:"Utility/orderedtext-Provider",
    newsletter:"Utility/news-letter",
    
    //Profiles
    profiles:"account/profiles",
    profileLinks:"account/profilelinks",
    all_links:"account/all-links",
    max_profiles:"account/max-profile",
    profile_links:"account/links",
    users:"account/administrator",
    delete_user:"account/deactivate-administrator/",

    //Download
    download_Statement_Report:"report/report-repo/download",
    download_Audit_Report:"report/audit-report/download",
    download_User_Report:"report/user-report/download",
    download_statement:"Utility/download-file",

    //summary report
    sponsor_search:"report/sponsor-search",
    summary_report:"report/summary-reports",
    sponsor_summary_report:"report/sponsor-summary-report",
}