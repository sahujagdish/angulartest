export class AdminUser {
    userid: string = "";
    Role!: string;
    Provider!: string;
    ProviderID: number = 63;
    ProviderName: string = "";
    UUID: string = "114EABC8-AA97-9AD9-B1465E9462AAAD3D";
    ProfileId: string = "1201";
}

export class ParUser{
    Role!: string;
    Provider!: string;
    ProviderID: number = 0;
    ProviderName: string = "";
    PartUUID:string="C0F0A1E5-3A58-4001-87C8-1C46F9FCED6";
    PartId:string="1256543";
    //SSN:string="000-00-0002"
}

export class SponUser{
    Role!: string;
    Provider!: string;
    ProviderID: number = 0;
    ProviderName: string = "";
    UID:string="C4362DC4-6457-11D6-AB19-00A0C974E97D";
    ISIN:string="1";
    PlanID:string="ABC";
}

export const Role = {
    Administrator: "admin",
    Participant: "par",
    Sponsor: "spon"
}
