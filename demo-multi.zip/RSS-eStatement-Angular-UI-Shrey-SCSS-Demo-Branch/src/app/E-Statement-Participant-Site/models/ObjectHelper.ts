export let search = {
  provID: "",
  sPartID: "",
  lname: "",
  sponPlans: "",
  planName: "",
  bSponsor: true,
  providerID: 0,
  iSID: 0,
  start: 0,
  limit: 20,
  sortField: "lname",
  sortDir: "ASC",
  AdminID: 0,
  SpadID: 0,
  SpadSponID: 0,
  useSSNPin: 0,
  bAssetRetention: true,
  bSuperSponsor: true,
  accessCode: "",
  agentID: "",
  hideSensitivePlans: true
}

export let dates = {
  prov_id: "nyha",
  u_uds: [],
  plan_num: []
}

export let participant = {
  providerID: 63,
  useSSNPin: 2,
  uid: "",
  parUUID: ""
}

export let ProcessInfo = {
  prov_id: "nyha",
  u_uids: [],
  provider_id: 63,
  firstName: "",
  lastName: "",
  nameList: "",
  statementDates: "",
  email: "",
  isOutputToFTP: true,
  isProcessAll: false,
  isSingleFile: true,
  neptuneCustNo: "",
  partId: "",
  planNum: "",
  plan_num: "",
  uid: "",
  userType: "Admin",
  providerid: "63",
  isSuperSponsor: "false",
  assetRetention: "",
  agentID: "",
  iSID: "",
  hideSensitivePlans: "false",
  useSSNPin: "true"
}

export let search_statement_repo = {
  ss_ident_request: {
    searchBy: "",
    part_list: [],
    plan_name: "",
    provID: "",
    sponsor: ""
  },
  search_request: {
    provID: "",
    sPartID: "",
    lname: "",
    sponPlans: "",
    planName: "",
    bSponsor: true,
    providerID: 0,
    iSID: 0,
    start: 0,
    limit: 20,
    sortField: "lname",
    sortDir: "ASC",
    AdminID: 0,
    SpadID: 0,
    SpadSponID: 0,
    useSSNPin: 0,
    bAssetRetention: true,
    bSuperSponsor: true,
    accessCode: "",
    agentID: "",
    hideSensitivePlans: true
  }
}

export let audit_repot = {
  ProviderID: "",
  AuditCode: 0,
  StartDate: "",
  EndDate: "",
  QueryType: "report",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  SSN: "",
  AccountNumber: "",
  Start: 0,
  Limit: 20,
  SortField: "auditDate",
  SortDirection: "DESC",
  HideSensitivePlans: 0,
  ProvID: ""
}


export let user_repot = {
  ProviderID: "",
  StatusCode: "",
  QueryType: "report",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  Start: 0,
  Limit: 20,
  SortField: "lname",
  SortDirection: "DESC",
  HideSensitivePlans: 0,
  ProvID: ""
}

export let profile = {
  ssn: "",
  account_number: "",
  fname: "",
  mi: "",
  lname: "",
  email: "",
  userid: "",
  password: "",
  statuscode: "",
  vcode: "",
  participantuuid: "",
  providerid: 0,
  isRegSite: true
}

export let planlist = {
  ProviderID: 0,
  AdminID: 0,
  PlanName: "",
  HideSensitivePlans: false
}

export let statementlist = {
  Start: 0,
  Limit: 20,
  SortDirection: "ASC",
  SortField: "Lname",
  ProvID: 0,
  UseSSNPin: 0,
  PartID: "",
  LastName: "",
  SponsorPlans: "",
  PlanName: "",
  IsSponsor: true,
  IsAssetRetention: true,
  ProviderID: 0,
  IsSuperSponsor: true,
  AccessCode: "",
  AgentID: "",
  ISID: 0,
  HideSensitivePlans: 0,
  TotalCount: 0
}

export let approval_list = {
  Start: 0,
  Limit: 5,
  SortDirection: "ASC",
  SortField: "",
  ProvId: "",
  StatusFilter: "All",
  Year: 0,
  Quarter: 0
}

export let deleteObject = {
  ApprovalId: 0,
  ExtractPlansToDelete: [""]
}

export interface Documents {
  Name: string;
  documents: any[];
}

export let planeNotification={
  utilityType: "",
  emailbody: "",
  fromaddress: "",
  fromname: ""
}

export let existingUser={
  userid: "",
  userPassword: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  isInternalUser: true,
  fname: "",
  profileid: 0,
  ProviderID: 0,
  hidesensitiveplans: true,
  isinternaluser: true,
  hasSensitivePlans: true
}

export let saveText={
  ProviderId: 0,
  Type: "",
  Subject: "",
  Text: "",
  IPId: 0
}

export let eNotification={
  utilityType: "",
  emailbody: ""
}

export let statement_admin={
  UID: "",
  VirtualDir: "",
}

export let statement_par={
  VirtualDir: "",
  ParticipantId: 0
}

export let statement_spon={
  UID: "",
  VirtualDir: "",
  ISIN: 0
}

export let downloadPDF={
  ProviderId: 0,
  PlanNum: "",
  UID: "",
  PartId: "",
  Date: "",
  FileName: ""
}

export let downloadAudit={
  ProviderID: 0,
  AuditCode: 0,
  StartDate: "",
  EndDate: "",
  QueryType: "",
  ISID: 0,
  PlanNumber: "",
  LastName: "",
  SSN: "",
  AccountNumber: "",
  Start: 0,
  Limit: 0,
  SortField: "",
  SortDirection: "",
  HideSensitivePlans: 0,
  ProvID: "",
  UseSSNPin: 0
}

export let saveTextObject={
  ProviderId: 0,
  Type: "",
  Subject: "",
  Text: "",
  IPId: 0
}


export let update_user={
  control_id: 0,
  userid: "",
  password: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  isInternalUser: true,
  fname: "",
  profileid: 0,
  hidesensitiveplans: true,
  passwordEditByAdmin: true,
  internal_user: true
}

export let add_user={
  userid: "",
  userPassword: "",
  control_name: "",
  failedAuthAttempts: 0,
  dtnumber: "",
  InternalUser: true,
  fname: "",
  profileid: 0,
  ProviderID: 0,
  hidesensitiveplans: true,
  isinternaluser: true,
  hasSensitivePlans: true
}






