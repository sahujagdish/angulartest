import { environment } from '../../../environments/environment';

export let AdminLinks: any[] = [
  { LinkText: "Access Participant Information", LinkURL: "access-participant-info" },
  { LinkText: "Statement Repository", LinkURL: "statement-repo" },
  { LinkText: "Audit Reports", LinkURL: "auditReport" },
  { LinkText: "User Reports", LinkURL: "userReport" },
  { LinkText: "Staff Access", LinkURL: "staffAccess" },
  { LinkText: "Staff Profiles", LinkURL: "staffProfiles" },
  { LinkText: "Summary Reports", LinkURL: "summaryReport" },
  { LinkText: "Tracking", LinkURL: "track" },
  { LinkText: "Site Text", LinkURL: "siteText" },
  { LinkText: "Ordered Site Text", LinkURL: "orderedSiteText" },
  { LinkText: "Statement Print Approval", LinkURL: "statement-print-approval" },
  { LinkText: "Message Board", LinkURL: "message-board" }
]

export let ParLinks: any[] = [
  { LinkText: "Statements", LinkURL: "view-Statements" },
  { LinkText: "My Documents", LinkURL: "my-documents" },
  { LinkText: "View Communications", LinkURL: "view-communications" },
  { LinkText: "Personalized Information", LinkURL: "personalized-information" },
  { LinkText: "Unsubscribe", LinkURL: "unsubscribe" },
  { LinkText: "Unsubscribe to eDelivery", LinkURL: "unsubscribe-eDelivery" },
  { LinkText: "Update Profile", LinkURL: "update-profile" },
  { LinkText: "FAQ", LinkURL: "faq" },
  { LinkText: "Disclosure", LinkURL: "disclosure" },
  { LinkText: "Newsletter", LinkURL: "newsletter" }

]

export let SponLinks: any[] = [
  { LinkText: "Access Participant Information", LinkURL: "access-participant-info" },
  { LinkText: "Statement Repository", LinkURL: "statement-repo" },
  { LinkText: "Audit Reports", LinkURL: "auditReport" },
  { LinkText: "User Reports", LinkURL: "userReport" },
]


export let Links: Map<String, any> = new Map([
  ["admin", AdminLinks],
  ["par", ParLinks],
  ["spon", SponLinks]
])