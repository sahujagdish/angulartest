export let AdminMessage: any[] = [
    { Link: "statement-print-approval", Message: "Approve the statements." },
    { Link: "access-participant-info", Message: "Access the participant information and request & view the statement for a particular participant." },
    { Link: "auditReport", Message: "View and download the Audit, the User, and the summary report." },
    { Link: "staffAccess", Message: "Create the Staff Profile and provide access to the staff." },
    { Link: "siteText", Message: "Manage Site text" },
    { Link: "message-board", Message: "Manage message board." }
]

export let ParMessage: any[] = [
    { Link: "newsletters", Message: "View the Newsletters" },
    { Link: "view-Statements", Message: "View the Statements." },
    { Link: "update-profile", Message: "Update your profile" },
    { Link: "faq", Message: "View the frequently asked questions." },
]
export let SponMessage: any[] = [
    { Link: "access-participant-info", Message: "Access the participant information and request & view the statement for a particular participant." },
    { Link: "auditReport", Message: "View and download the Audit, the User, and the summary report." },

]


export let Message: Map<string, any> = new Map([
    ["admin", AdminMessage],
    ["par", ParMessage],
    ["spon", SponMessage]
])
