import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {

  SearchForm:FormGroup=new FormGroup({
    Plan_Name:new FormControl(),
    Assignee:new FormControl()
  });
  constructor() { }

  ngOnInit(): void {
  }

}
