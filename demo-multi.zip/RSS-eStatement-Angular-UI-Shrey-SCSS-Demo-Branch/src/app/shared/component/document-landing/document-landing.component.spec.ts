import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentLandingComponent } from './document-landing.component';

describe('DocumentLandingComponent', () => {
  let component: DocumentLandingComponent;
  let fixture: ComponentFixture<DocumentLandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentLandingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
