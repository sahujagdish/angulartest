import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-landing',
  templateUrl: './document-landing.component.html',
  styleUrls: ['./document-landing.component.scss']
})
export class DocumentLandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
