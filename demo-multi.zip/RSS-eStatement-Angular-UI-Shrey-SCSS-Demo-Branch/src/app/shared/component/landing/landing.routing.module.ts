import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LandingComponent } from './landing.component';
import { DocumentLandingComponent } from '../document-landing/document-landing.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { SummaryComponent } from '../../../proposal/component/summary/summary.component';

const routes: Routes = [
    {path:':client',component:LandingComponent,children:[
        {path:'page/:type',component:DocumentLandingComponent,children:[
            {path:'summary',component:SummaryComponent}
        ]},
        {path:'dashboard',component:DashboardComponent},
    ]}
];
//routes = routes.concat(EStatementParticipantroute);
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LandingRoute { }
