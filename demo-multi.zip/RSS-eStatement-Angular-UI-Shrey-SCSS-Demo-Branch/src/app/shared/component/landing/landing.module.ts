import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { DocumentLandingComponent } from '../document-landing/document-landing.component';
import { LandingComponent } from './landing.component';
import { LandingRoute } from './landing.routing.module';
import { InputComponent } from '../../../proposal/directives/input/input.component';
import { SummaryComponent } from '../../../proposal/component/summary/summary.component';

/* MD Bootstrap Library */
import { MdbAccordionModule } from 'mdb-angular-ui-kit/accordion';
import { MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import { MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbPopoverModule } from 'mdb-angular-ui-kit/popover';
import { MdbRadioModule } from 'mdb-angular-ui-kit/radio';
import { MdbScrollspyModule } from 'mdb-angular-ui-kit/scrollspy';
import { MdbTabsModule } from 'mdb-angular-ui-kit/tabs';
import { MdbTooltipModule } from 'mdb-angular-ui-kit/tooltip';
import { MdbValidationModule } from 'mdb-angular-ui-kit/validation';


@NgModule({
    declarations: [LandingComponent, DashboardComponent, DocumentLandingComponent, InputComponent, SummaryComponent],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        LandingRoute,
        MdbAccordionModule,
        MdbCheckboxModule,
        MdbCollapseModule,
        MdbDropdownModule,
        MdbFormsModule,
        MdbModalModule,
        MdbPopoverModule,
        MdbRadioModule,
        MdbScrollspyModule,
        MdbTabsModule,
        MdbTooltipModule,
        MdbValidationModule,
        ],
    exports: [
        FormsModule,
        ReactiveFormsModule
    ],
    providers: []
})
export class LandingModule { }