import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {

  ClientCode:string="";

  
  constructor(@Inject(DOCUMENT) private document: Document,private router:ActivatedRoute) {
    this.ClientCode = String(this.router.snapshot.paramMap.get("client")).toUpperCase();
    this.loadStyle("theme/clients/"+this.ClientCode+"/generic.css");
  }

  ngOnInit(){

  }

  loadStyle(styleName: string) {
    
    const head = this.document.getElementsByTagName('head')[0];

    let themeLink = this.document.getElementById(
      'client-theme'
    ) as HTMLLinkElement;
    if (themeLink) {
      themeLink.href = styleName;
    } else {
      const style = this.document.createElement('link');
      style.id = 'client-theme';
      style.rel = 'stylesheet';
      style.type = 'text/css';
      style.href = `${styleName}`;

      head.appendChild(style);
    }    

  }

}
