// export interface Logo{
//   providerId: string;
//   logoId: string;
//   thumbnail: string;
// }

export class Logo{
  public providerId: string;
  public logoId: string;
  public thumbnail: string;

  constructor (providerId: string, logoId: string, thumbnail: string) {
    this.providerId = providerId;
    this.logoId = logoId;
    this.thumbnail = thumbnail;
  }
  // constructor (public providerId: string, logoId: string, thumbnail: string) {}
}

