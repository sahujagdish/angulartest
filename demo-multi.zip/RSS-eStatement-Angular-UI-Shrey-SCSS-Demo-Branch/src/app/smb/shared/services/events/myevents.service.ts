import { Injectable } from '@angular/core';
import { AsyncSubject, Subject, ReplaySubject } from 'rxjs';
import { MyEvent } from '../../model/myevent.model';
import { MyEventType } from '../../model/myenums.enum';

@Injectable({
    providedIn: 'root'
})
export class MyEventsService {
    // Observable MyEvent sources...Use Subject so initial value isnt read on Components Init
    private logoUploadComplete = new Subject<MyEvent>();
    private logoDeleteComplete = new Subject<MyEvent>();
    private assignLogoComplete = new Subject<MyEvent>();
    private logoReplacementComplete = new Subject<MyEvent>();
    private planLogoDeleteComplete = new ReplaySubject<MyEvent>(1, 500);

    private messageCreateComplete = new Subject<MyEvent>();
    private messageUpdateComplete = new Subject<MyEvent>();
    private messageDeleteComplete = new Subject<MyEvent>();
    private messageAssignmentComplete = new ReplaySubject<MyEvent>(1, 500);
    private removeMessageAssignmentComplete = new Subject<MyEvent>();
    private removeLogoAssignmentComplete = new Subject<MyEvent>();

    private planCreateComplete = new Subject<MyEvent>();
    private planUpdateComplete = new Subject<MyEvent>();
    private planDeleteComplete = new Subject<MyEvent>();
    private planAssignmentComplete = new Subject<MyEvent>();
    // private planMessageDeleteComplete = new AsyncSubject<MyEvent>();
    private planMessageDeleteComplete = new ReplaySubject<MyEvent>(1, 500);


    // Observable MyEvent streams
    currentLogoUploadComplete = this.logoUploadComplete.asObservable();
    currentLogoDeleteComplete = this.logoDeleteComplete.asObservable();
    currentAssignLogoComplete = this.assignLogoComplete.asObservable();
    currentLogoReplacementComplete = this.logoReplacementComplete.asObservable();
    currentPlanLogoDeleteComplete = this.planLogoDeleteComplete.asObservable();

    currentMessageCreateComplete = this.messageCreateComplete.asObservable();
    currentMessageUpdateComplete = this.messageUpdateComplete.asObservable();
    currentMessageDeleteComplete = this.messageDeleteComplete.asObservable();
    currentMessageAssignmentComplete = this.messageAssignmentComplete.asObservable();
    currentMessageRemoveAssignmentComplete = this.removeMessageAssignmentComplete.asObservable();
    currentLogoRemoveAssignmentComplete = this.removeLogoAssignmentComplete.asObservable();

    currentPlanCreateComplete = this.planCreateComplete.asObservable();
    currentPlanUpdateComplete = this.planUpdateComplete.asObservable();
    currentPlanDeleteComplete = this.planDeleteComplete.asObservable();
    currentPlanAssignmentComplete = this.planAssignmentComplete.asObservable();
    currentPlanMessageDeleteComplete = this.planMessageDeleteComplete.asObservable();

    constructor() { }

    triggerMyEvent(mySuccess: boolean, myType: MyEventType, myMessage: string = '') {
        let myEvent: MyEvent = {
            success: mySuccess,
            type: myType,
            message: myMessage,
        };
        // emit MyEvent to appropriate Observable source, based on MyEventType
        switch (myType) {
            case MyEventType.UploadComplete:
                this.logoUploadComplete.next(myEvent);
                break;
            case MyEventType.DeleteComplete:
                this.logoDeleteComplete.next(myEvent);
                break;
            case MyEventType.AssignLogoComplete:
                this.assignLogoComplete.next(myEvent);
                break;
            case MyEventType.CreateMessageComplete:
                this.messageCreateComplete.next(myEvent);
                break;
            case MyEventType.UpdateMessageComplete:
                this.messageUpdateComplete.next(myEvent);
                break;
            case MyEventType.DeleteMessageComplete:
                this.messageDeleteComplete.next(myEvent);
                break;
            case MyEventType.DeletePlanMessageComplete:
                this.planMessageDeleteComplete.next(myEvent);
                // this.planMessageDeleteComplete.complete();
                break;
            case MyEventType.AssignMessageComplete:
                this.messageAssignmentComplete.next(myEvent);
                break;
            case MyEventType.CreatePlanComplete:
                this.planCreateComplete.next(myEvent);
                break;
            case MyEventType.UpdatePlanComplete:
                this.planUpdateComplete.next(myEvent);
                break;
            case MyEventType.DeletePlanComplete:
                this.planDeleteComplete.next(myEvent);
                break;
            case MyEventType.DeletePlanLogoComplete:
                this.planLogoDeleteComplete.next(myEvent);
                break;
            case MyEventType.AssignPlanComplete:
                this.planAssignmentComplete.next(myEvent);
                break;
            case MyEventType.ReplaceLogoComplete:
                this.logoReplacementComplete.next(myEvent);
                break;
            case MyEventType.RemoveAssignMessageComplete:
                this.removeMessageAssignmentComplete.next(myEvent);
                break;
            case MyEventType.RemoveAssignLogoComplete:
                this.removeLogoAssignmentComplete.next(myEvent);
                break;
            default:
                break;
        }
    }

}
