
import { Injectable } from '@angular/core';
import { AppCacheModel } from '../model/appCache.model';

@Injectable({
  providedIn: 'root'
})
export class AppcacheService {

    constructor(private appCache: AppCacheModel) { }

    public getAppCache(): AppCacheModel {
        return this.appCache;
    }

    public setAppCache(key, value): void {
        this.appCache[key] = value;
    }
}

