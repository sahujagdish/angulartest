import { ModalContentDirective } from './modal-content.directive';

describe('ModalContentDirective', () => {
  it('should create an instance', () => {
    const directive = new ModalContentDirective();
    expect(directive).toBeTruthy();
  });
});
