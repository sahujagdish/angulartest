import { Component, OnInit, Input, ComponentFactoryResolver, Output, EventEmitter, ViewChild, ElementRef, Renderer2, AfterContentInit, HostListener } from '@angular/core';
import { ModalLoaderService } from '../../services/modal/modal-loader.service';
import { ModalContentDirective } from "./modal-content.directive";
@Component({
    selector: 'app-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit, AfterContentInit {
    @Input() componentName: any;
    @Input() componentData: string;
    @Input() componentData2: string;
    @Input() modalDialogComponentReference: any;
    @Output() destroyEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    @ViewChild(ModalContentDirective) appModalContent: ModalContentDirective;
    modalSize: string = 'large'; // This can be small medium or large based on componentName passed in and set in ngOnInit

    @HostListener('document:keyup', ['$event']) onKeyHandler(event: KeyboardEvent) {
        if (event.keyCode == 27)
            this.closeModal();
    }

    constructor(
        private el: ElementRef,
        private ren: Renderer2,
        private resolver: ComponentFactoryResolver,
        private loaderService: ModalLoaderService
    ) { }

    public div = this.ren.createElement('div');

    ngOnInit() {
        if(this.componentName == 'ChangePlanLogoFromLibraryComponent')
            this.modalSize = 'medium';
    }

    ngAfterContentInit() {
        this.ren.addClass(this.el.nativeElement.ownerDocument.body, 'modal-open');
        this.ren.appendChild(this.el.nativeElement, this.div);
        this.ren.setAttribute(this.div, 'class', 'modal-backdrop fade in');
        this.createModalPopup();
    }

    createModalPopup() {
        const name = this.loaderService.getComponent(this.componentName);
        const myComponentFactory = this.resolver.resolveComponentFactory(<any>name);
        const viewContainerRef = this.appModalContent.viewContainerRef;
        viewContainerRef.clear();
        const myComponentRef = viewContainerRef.createComponent(myComponentFactory);
        // pass in any data needed
        myComponentRef.instance['componentData'] = this.componentData;
        myComponentRef.instance['componentData2'] = this.componentData2;
        //make sure the dynamic child component created outputs closeEvent boolean when it wants to close modal
        myComponentRef.instance['closeEvent'].subscribe(
            e => {
                if (e) {
                    this.closeModal();
                }
            }
        );
    }

    closeModal() {
        // destroy modal that was created in Directive
        this.destroyEvent.emit(true);
        this.ren.removeClass(this.el.nativeElement.ownerDocument.body, 'modal-open');
        this.ren.removeChild(this.el.nativeElement, this.div);
        this.el.nativeElement.remove();
    }
}
