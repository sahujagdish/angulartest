export interface IPlanMessages  {
  planId: string;
  messageId: string;
  messageSlot: number;
}
