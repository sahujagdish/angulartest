// import { Message } from '../shared/message';

// export class IPlan {
//   planId: string;
//   planName1: string;
//   planName2: string;
//   planMessages: Message[] ;
//   planLogo: string;
//   planLogoId: string;
//   planChecked: boolean;
// }


export class Plan {
  providerId: string;
  externalPlanId: string;
  planName1: string;
  planName2: string;
  logoId: string;
  message1Id: string;
  message2Id: string;
  message3Id: string;
  message4Id: string;
  message5Id: string;
}
