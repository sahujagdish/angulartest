export class AppCacheModel {
    newPlanName1: string;
    newPlanName2: string;
    newPlanId: string;
    newLogoId: string;
    newMessageId1: string;
    newMessageName1: string;
    newMessage1: string;
    newMessageId2: string;
    newMessageName2: string;
    newMessage2: string;
    newMessageId3: string;
    newMessageName3: string;
    newMessage3: string;
    newMessageId4: string;
    newMessageName4: string;
    newMessage4: string;
    newMessageId5: string;
    newMessageName5: string;
    newMessage5: string;
    providerId: any;
    planName1: string;
    planName2: string;
    externalPlanId: string;
    logoId: string;
    thumbnail: string;
    message1Id: string;
    message1: string;
    message2Id: string;
    message2: string;
    message3Id: string;
    message3: string;
    message4Id: string;
    message4: string;
    message5Id: string;
    message5: string;


    // benchmarkTypes: Array<any>;
    // isSso: boolean;
    // allowSso: boolean;
    // dateTypes: any;
}
