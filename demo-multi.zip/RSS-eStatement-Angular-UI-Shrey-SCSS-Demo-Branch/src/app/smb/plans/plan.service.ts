import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Plan } from '../shared/plan';
import { environment } from '../../../environments/environment';
import { ErrorHandlingService } from '../shared/services/error/error-handling.service';
import { MyEventType } from '../shared/model/myenums.enum';
import { MyEventsService } from '../shared/services/events/myevents.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization' : 'Bearer ' + sessionStorage.getItem('token')
  }),
  observe: 'response'
};



@Injectable({
    providedIn: 'root'
})

// This service will CRUD the local dataStore in sync with REST calls
// This will allow us to just use from local memory dataStore and only pull once from server
export class PlanService {
    plans: Observable<Plan[]>
    private _plans: BehaviorSubject<Plan[]>;
    private planUrl: string;
    private dataStore: {
        plans: Plan[]
    };

    constructor(private _http: HttpClient, private _errorHandlingService: ErrorHandlingService, private _myEventsService: MyEventsService) {
        this.planUrl = environment.MMApiURL;
        this.dataStore = { plans: [] };
        // Observable Plan source...Use BehaviorSubject so value is available immediatly when subscribed too and after next is called.
        this._plans = <BehaviorSubject<Plan[]>>new BehaviorSubject([]);
        // Observable Plan stream
        this.plans = this._plans.asObservable();
    }

    getAllPlans(provId: any) {
        // if local observable source is empty...call to get from server..Otherwise its already available in observable stream
        if (!this._plans.getValue().length) {
            this._http.get<Plan[]>(this.planUrl + 'plans/' + provId,{headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization' : 'Bearer ' + sessionStorage.getItem('token')
            }),
            observe: 'response'} ).pipe(
                catchError(this._errorHandlingService.handleHttpErrorResponse)
            ).subscribe(resp => {
                const status = resp.status;
                console.log('getAllPlans Status Code: ' + status);
                // Need to use spread operator to create a copy of itself. Otherwise the value is still actually the same and view doesnt refresh
                this.dataStore.plans = [...this.dataStore.plans];
                // set data returned to dataStore
                this.dataStore.plans = resp.body;
                //create a copy and emit to observable
                this._plans.next(Object.assign({}, this.dataStore).plans);
            }
            );
        }
    }

    getMessagePlans(provId: any, messageId: any) {
      return this._http.get(this.planUrl + 'plans/' + provId + '/msg/' + messageId, { observe: 'response' });
    }

    getLogoPlans(provId: any, logoId: any) {
      return this._http.get(this.planUrl + 'plans/' + provId + '/logo/' + logoId, { observe: 'response' });
    }    

    deletePlan(provId, planID) {
      this._http.delete(this.planUrl + 'plans/' + provId + '/' + planID).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
      ).subscribe(
          resp => {
              console.log('Response for deleting a logo: ' + resp);
              // Need to use spread operator to create a copy of itself. Otherwise the value of plans is still actually the same and view doesnt refresh
              this.dataStore.plans = [...this.dataStore.plans];
              // remove logo from dataStore that was deleted from server
              this.dataStore.plans.forEach((t, i) => {
                  if (t.externalPlanId === planID) {
                      this.dataStore.plans.splice(i, 1);
                  }
              });
              //create a copy and emit to observable
              this._plans.next(Object.assign({}, this.dataStore).plans);
              this._myEventsService.triggerMyEvent(true, MyEventType.DeletePlanComplete, 'Plan has been deleted!');
          },
          err => {
              this._myEventsService.triggerMyEvent(false, MyEventType.DeletePlanComplete, 'Plan delete has failed!');
          }
      );
  }

  createPlan(provId, planID, planName1, planName2) {

    const options = {

        headers: new HttpHeaders({
          'Content-Type':  'application/json'
        })
        //  , params: new HttpParams()
        //  .set( 'planId', planID )
        //  .set( 'name1', planName1 )
        //  .set( 'name2', planName2 )

      };

     // this._http.post(this.planUrl + 'plans/' + provId + '?planId=' + planID + '&name1=' + planName1 + '&name2=' + planName2, options).pipe(
    this._http.post<any>(this.planUrl + 'plans/' + provId + '?planId=' + planID + '&name1=' + planName1 + '&name2=' + planName2, options).pipe(
     // this._http.post<any>(this.planUrl + 'plans/' + provId, options).pipe(
        catchError(this._errorHandlingService.handleHttpErrorResponse)
    ).subscribe(
        resp => {
            console.log('Response for updating a plan: ' + resp);
            // Need to use spread operator to create a copy of itself. Otherwise the value of plans is still actually the same and view doesnt refresh
             this.dataStore.plans = [...this.dataStore.plans];
            // push new to dataStore that was returned from server
             this.dataStore.plans.push(resp);
            // this._plans.next(Object.assign({}, this.dataStore).plans);
            this._myEventsService.triggerMyEvent(true, MyEventType.CreatePlanComplete, 'Plan has been created!');
        },
        err => {
            this._myEventsService.triggerMyEvent(false, MyEventType.CreatePlanComplete, 'Plan creation has failed!');
        }
    );
  }

  updatePlan(provId, planID, planName1, planName2) {

    const options = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
      // , params: new HttpParams()
      // .set( 'name1', planName1 )
      // .set( 'name2', planName2 )

    };

     this._http.put<any>(this.planUrl + 'plans/' + provId + '/' + planID + '?name1=' + planName1 + '&name2=' + planName2, options ).pipe(
    // this._http.put<any>(this.planUrl + 'plans/' + provId + '/' + planID, options ).pipe(
        catchError(this._errorHandlingService.handleHttpErrorResponse)
      ).subscribe(
        resp => {
            console.log('Response for updating a plan: ' + resp);
            // Need to use spread operator to create a copy of itself. Otherwise the value of plans is still actually the same and view doesnt refresh
            this.dataStore.plans = [...this.dataStore.plans];
            // update dataStore
            this.dataStore.plans.forEach((t, i) => {
                if (t.externalPlanId === planID) {
                    this.dataStore.plans[i].planName1 = planName1;
                    this.dataStore.plans[i].planName2 = planName2;
                }
            });

            this._plans.next(Object.assign({}, this.dataStore).plans);
            this._myEventsService.triggerMyEvent(true, MyEventType.UpdatePlanComplete, 'Plan has been updated!');
        },
        err => {
            this._myEventsService.triggerMyEvent(false, MyEventType.UpdatePlanComplete, 'Plan update has failed!');
        }
    );
  }

       
  GetPlanMessageLogoAssignmentReport( provId: number ) 
  {
     return this._http.get( this.planUrl + 'plans/' + provId + '/Reports/ML',   { responseType: 'blob' } );
  }
}

