import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatePipe, formatDate} from '@angular/common';
// import {MatFormFieldModule} from '@angular/material/form-field';
import { Plan } from '../shared/plan';
import { Logo } from '../shared/logo';
import { Message } from '../shared/message';
import { PlanService } from './plan.service';
import { MessageService } from '../messages/message.service';
import { LogoService } from '../logos/logo.service';
import { Everything } from '../shared/model/everything';
import { EverythingService } from '../shared/services/everything.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { tap, map, last } from 'rxjs/operators';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling/';
import { ViewChild } from '@angular/core';
import * as FileSaver from 'file-saver';
import { SpinnerService } from '../shared/services/spinner-service.service';
// import { forEach } from '@angular/router/src/utils/collection';/core/src/metadata/di

declare var jQuery: any;

declare var $: any;

@Component({
  // selector: 'app-plan-list',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.css']
})
export class PlanListComponent implements OnInit, OnDestroy {
  // Experimenting with CdkVirtualScrollViewport
   @ViewChild(CdkVirtualScrollViewport)
   viewport: CdkVirtualScrollViewport;

  config: any;
  
  planIDToToggle: any;
  provId: any;
  errorMessage: string;
  _listFilter: string;
  // filteredPlans: Plan[] = [];
  // plans: Plan[] = [];
  filteredPlans: Everything[] = [];
  plans: Everything[] = [];
  newPlanname1: string = '';
  newPlanname2: string = '';
  newPlanid: string = '';
  _plansToDelete: any = [];
  _externalPlanIdToDelete: any = [];
  clientId: number;
  editorValue: string = '';
  fullPage: false;
  CkeditorConfig = {};
  myToken: any;
  mySessionToken: any;
  theDate = new Date();
  theYear = this.theDate.getFullYear();
  editMessageIdValue: string;
  editMessageNameValue: string;
  logos: Logo[] = [];
  messages: Message[] = [];
  currentLogosSubscription: Subscription;
  currentPlanLogoDeleteComplete: Subscription;
  currentMessagesSubscription: Subscription;
  currentPlanMessageDeleteComplete: Subscription;
  currentMessageAssignmentComplete: Subscription;
  currentAssignLogoComplete: Subscription;
  currentPlanCreateComplete: Subscription;
  currentPlanUpdateComplete: Subscription;
  currentPlanDeleteComplete: Subscription;
  currentMessageUpdateComplete: Subscription;

  public ImgURL = '';

  constructor(private _planService: PlanService, _appCacheService: AppcacheService, private _everythingService: EverythingService
    , private _messageService: MessageService, private _logoService: LogoService, private _myEventsService: MyEventsService,private spinnerService: SpinnerService) {
    this.provId = _appCacheService.getAppCache().providerId;
    this.filteredPlans = this.plans;
    this.listFilter = '';
    this.editMessageIdValue = '';

	this.config = {
		itemsPerPage: 25,
		currentPage: 1,
		totalItems: this.filteredPlans.length 
	};

    this.CkeditorConfig = {
      height: 200,
      toolbar: [
        { name: 'editing', groups: [ 'find', 'selection', 'spellchecker' ], items: [ 'Find', 'Replace', '-',  'SelectAll', '-', 'Scayt' ] },
        { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ], items: [ 'Bold', 'Italic', 'Underline', '-', 'RemoveFormat' ] }
    ]
  };
 }

  pageChanged(event) {
  	this.config.currentPage = event;
  }

  ngOnInit(): void {
    (<HTMLFormElement>document.getElementById('SaveNewPlanButton')).disabled = true;

    // this._planService.getPlans().subscribe(
    //   plans => {
    //     this.plans = plans,
    //     this.filteredPlans = this.plans;
    //   },
    //   error => this.errorMessage = <any>error
    // );

     // setup subscription for PlanMessageDeleteComplete event.
     this.currentPlanMessageDeleteComplete = this._myEventsService.currentPlanMessageDeleteComplete.subscribe(
      (deleteComplete: MyEvent) => {
          if (deleteComplete.success) {
              window.alert(deleteComplete.message);
              // put call to getEverything function
              this.loadEverthing(true);
              //this._listFilter = ''; // clear out the search box              
          } else {
              window.alert(deleteComplete.message);
          }
        }
      );

     // setup subscription for PlanMessageDeleteComplete event.
     this.currentMessageAssignmentComplete = this._myEventsService.currentMessageAssignmentComplete.subscribe(
      (planMessageAssignmentComplete: MyEvent) => {
          if (planMessageAssignmentComplete.success) {
              // window.alert(planMessageAssignmentComplete.message);
              this.loadEverthing(true);
              //this._listFilter = ''; // clear out the search box
          } else {
              // window.alert(planMessageAssignmentComplete.message);
          }
        }
      );


      // setup subscription for PlanLogoDeleteComplete event.
     this.currentPlanLogoDeleteComplete = this._myEventsService.currentPlanLogoDeleteComplete.subscribe(
      (deletePlanLogoComplete: MyEvent) => {
          if (deletePlanLogoComplete.success) {
              window.alert(deletePlanLogoComplete.message);
              // put call to getEverything function
              this.loadEverthing(true);
              //this._listFilter = ''; // clear out the search box
          } else {
              window.alert(deletePlanLogoComplete.message);
          }
        }
      );


       // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
      this.currentAssignLogoComplete = this._myEventsService.currentAssignLogoComplete.subscribe(
        (assignLogoComplete: MyEvent) => {
            if (assignLogoComplete.success) {
                //  this.closeEvent.emit(true);

                this.loadEverthing(true);
                window.alert(assignLogoComplete.message);
                //this._listFilter = ''; // clear out the search box

            } else {
                window.alert(assignLogoComplete.message);
            }
        }
      );


      // setup subscription for PlanCreateComplete event.
     this.currentPlanCreateComplete = this._myEventsService.currentPlanCreateComplete.subscribe(
      (createPlanComplete: MyEvent) => {
          if (createPlanComplete.success) {
              window.alert(createPlanComplete.message);
              // put call to getEverything function
              this.loadEverthing();
              this._listFilter = ''; // clear out the search box
          } else {
              window.alert(createPlanComplete.message);
          }
        }
      );


      // setup subscription for PlanUpdateComplete event.
      this.currentPlanUpdateComplete = this._myEventsService.currentPlanUpdateComplete.subscribe(
      (updatePlanComplete: MyEvent) => {
          if (updatePlanComplete.success) {
              window.alert(updatePlanComplete.message);
              // put call to getEverything function
              this.loadEverthing();
              this._listFilter = ''; // clear out the search box
          } else {
              window.alert(updatePlanComplete.message);
          }
        }
      );


      // setup subscription for PlanDeleteComplete event.
     this.currentPlanDeleteComplete = this._myEventsService.currentPlanDeleteComplete.subscribe(
      (deletePlanComplete: MyEvent) => {
          if (deletePlanComplete.success) {
              window.alert(deletePlanComplete.message);
              // put call to getEverything function
              this.loadEverthing();
              this._listFilter = ''; // clear out the search box
          } else {
              window.alert(deletePlanComplete.message);
          }
        }
      );


      // setup subscription for UpdateMessageComplete event.
      this.currentMessageUpdateComplete = this._myEventsService.currentMessageUpdateComplete.subscribe(
        (updateMessageComplete: MyEvent) => {
            if (updateMessageComplete.success) {
                //window.alert(updateMessageComplete.message);
                // put call to getEverything function
                this.loadEverthing(true);
                //this._listFilter = ''; // clear out the search box
            } else {
                //window.alert(updateMessageComplete.message);
            }
          }
        );


      this.loadEverthing();


    // subscribe to logos observable which will be emitted from service and set return to local logos
    this.currentLogosSubscription = this._logoService.logos.subscribe(logos => {
      this.logos = logos;
      // this.filteredLogos = logos;
    });

    // Call to get logos. Service will handle if it needs to call the server or not
    this._logoService.getAllLogos(this.provId);


    // subscribe to messages observable which will be emitted from service and set return to local messages
    this.currentMessagesSubscription = this._messageService.messages.subscribe(messages => {
      this.messages = messages;
    });

    // call to get messages. Service will handle if it needs to call the server or not
    this._messageService.getAllMessages(this.provId);


  }


  get listFilter(): string {  	
    return this._listFilter;
  }

  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredPlans = this._listFilter ? this.performFilter(this.listFilter) : this.plans;
  }

  performFilter(filterBy: string): Everything[] {
    filterBy = filterBy.toLocaleLowerCase();
	this.config.currentPage = 1;
    return this.plans.filter((plan: Plan) =>
        (plan.planName1  !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
        || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
        || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
  }

  //put this here for now so build works. html is calling it but wasnt here
  ChangePlanLogo(){}

  clearSearchBox() {
    (<HTMLFormElement>document.getElementById('listFilter')).value = '';
  }

  prepareChangeLogoModal(data: any): void {
    console.log('I am in the prepareChangeLogoModal compontent');
    console.log(data);
    alert('here!');

  }


  ResetTheForm (planFormId, IndexNumber) {  
    
    this.plans.forEach((t, i) => {

      if (t.externalPlanId.toLocaleLowerCase() === planFormId.trim().toLocaleLowerCase()) {

          let PlanNameOne = 'planname1-' + planFormId;
          let PlanNameTwo = 'planname2-' + planFormId;

          (<HTMLFormElement>document.getElementById(PlanNameOne)).value = t.planName1;
          (<HTMLFormElement>document.getElementById(PlanNameTwo)).value = t.planName2;
      }

    });

    // (<HTMLFormElement>document.getElementById(planFormId)).reset();
	this.viewport.scrollToIndex(IndexNumber);

  }

  loadEditMessage(data: any) {
    // alert(data);
    return this.editMessageIdValue = data;
  }


  performPlanFilter(filterBy: string): Everything[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.plans.filter((plan: Everything) =>
          plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  getPlanIndex (PlanID: string) {
    let plan : number;
    //  this.plans.forEach((t, i) => {
    //   if (t.externalPlanId === PlanID) {
    //       return i;
    //   }
    // });

    // this.plans.some(function (currentPlan, index, _arr): any {
    //    // console.log(index + ': ' + value);
    //     if (currentPlan.externalPlanId === PlanID) {
    //       return index;
    //     }
    // });

    for (let i = 0; i < this.plans.length; i++) {
      if (this.plans[i].externalPlanId.toLocaleLowerCase() === PlanID.toLocaleLowerCase()) {
        plan = i;
      }
    }
    return plan;
  }

  setPlanIDToToggle(planID) {
    this.planIDToToggle = planID;
  }

  togglePlanForm(){
    setTimeout(()=>{(<HTMLFormElement>document.getElementById("ClickEditPlan-"+this.planIDToToggle)).click();}, 200);
  }

  loadEverthing (togglePlanForm?: any) {
      this.spinnerService.show();

      this._everythingService.getEverything(this.provId)
      .subscribe(
        resp => {
          const status = resp.status;
          this.plans = resp.body;
          this.filteredPlans = this._listFilter ? this.performFilter(this.listFilter) : this.plans;
          this.spinnerService.hide();
          if(togglePlanForm) {
            this.togglePlanForm();
          }                                
        }
        ,
        error => this.errorMessage = <any>error
      );
  }

  removeChosenPlan(data: any) {
      // alert(data.target.parentElement.value);
      const confirmPlanRemoval = confirm('Are you sure you wish to delete PlanID ' + data + '?');

      if (confirmPlanRemoval === true) {
          // this._LogoService.deleteLogo(this.provId, data.target.parentElement.value);
          this._planService.deletePlan(this.provId, data);
      }
  }


  removeMessage(location, planId, messageNumber)  {

    const result = confirm('Are you sure you want to remove this message?\n\n Removing this message will only remove it from this plan.');

    if (result) {

        // Call service to remove the message from the plan
        this._messageService.deletePlanMessage(this.provId, planId, location);


          // for (let i = 0; i < this.plans.length; i++) {
          //   if (this.plans[i].externalPlanId === planId) {
          //       switch (location) {
          //         case 1:
          //           this.plans[i].message1Id = '';
          //           this.plans[i].message1 = '';
          //           this.plans[i].message1Name = '';
          //           break;
          //         case 2:
          //           this.plans[i].message2Id = '';
          //           this.plans[i].message2 = '';
          //           this.plans[i].message2Name = '';
          //           break;
          //         case 3:
          //           this.plans[i].message3Id = '';
          //           this.plans[i].message3 = '';
          //           this.plans[i].message3Name = '';
          //           break;
          //         case 4:
          //           this.plans[i].message4Id = '';
          //           this.plans[i].message4 = '';
          //           this.plans[i].message4Name = '';
          //           break;
          //         case 5:
          //           this.plans[i].message5Id = '';
          //           this.plans[i].message5 = '';
          //           this.plans[i].message5Name = '';
          //       }
          //       break;
          //   }
          // }

          // alert('Message has been removed from this plan!');

     }

   }



  removeLogo(LogoID, PlanID, IndexNumber) {
    // Experimenting with scrollToIndex
    // removeLogo(LogoID, PlanID, IndexNumber) {
    // alert(this.viewport.getDataLength());
    // alert(IndexNumber);
    // this.viewport.scrollToIndex(IndexNumber);
   let result = confirm('Are you sure you want to remove this logo?\n\n Removing this logo will only remove it from this plan.');
    if (result) {
      this._logoService.deletePlanLogo(this.provId, PlanID, LogoID);
       // alert('Logo has been removed!!');
    }

  }


  SavePlanData(IndexNumber, PlanId?: string) {
    const PlanName1ElementName = PlanId ? 'planname1-' + PlanId : 'newPlanname1';
    const PlanName2ElementName = PlanId ? 'planname2-' + PlanId : 'newPlanname2';
    const NewPlanIDElementName = 'newPlanid';
    var planID = PlanId;
    const planName1 =  (<HTMLFormElement>document.getElementById(PlanName1ElementName)).value;
    const planName2 =  (<HTMLFormElement>document.getElementById(PlanName2ElementName)).value;
    // add
    if (!PlanId) {
        planID = (<HTMLFormElement>document.getElementById(NewPlanIDElementName)).value;
        if (!planID.trim() || !planName1.trim()) {
          alert('Please ensure that both Plan Name 1 and Plan ID are filled in.');
        } else {


          let PlanIdIsUnique = true;
          // Ensure the new PlanID is unique
          this.plans.forEach((t, i) => {

            if (t.externalPlanId.toLocaleLowerCase() === planID.trim().toLocaleLowerCase()) {
                alert('The Plan ID you entered is already being used. Please enter a unique Plan ID value.');
                PlanIdIsUnique = false;
            }

          });


          if (PlanIdIsUnique) {
            // Call service to create new plan
            this._planService.createPlan(this.provId, planID.trim(), planName1.trim(), planName2.trim());
            // (<HTMLFormElement>document.getElementById('newPlanname1')).value = '';
            // (<HTMLFormElement>document.getElementById('newPlanname2')).value = '';
            // (<HTMLFormElement>document.getElementById('newPlanid')).value = '';
            // (<HTMLFormElement>document.getElementById('CancelNewPlanButton')).click();
            this.newPlanname1 = '';
            this.newPlanname2 = '';
            this.newPlanid = '';

          }

        }
    } else {
      if (!planName1.trim()) {
        alert('Please ensure that Plan Name 1 is filled in.');
      } else {
        // Call service to update the planname1 & planname2
        this._planService.updatePlan(this.provId, planID.trim(), planName1.trim(), planName2.trim());
      }
    }
	
	//alert(IndexNumber);
	this.viewport.scrollToIndex(IndexNumber);
	
  }



  toggleNewPlanSaveButton(data) {
    // Enable/disable Save button

    if (data === 'add') {
      if (this.newPlanname1 !== null && this.newPlanname1.trim().length > 0
          && this.newPlanid !== null && this.newPlanid.trim().length > 0) {
            (<HTMLFormElement>document.getElementById('SaveNewPlanButton')).disabled = false;
        } else {
            (<HTMLFormElement>document.getElementById('SaveNewPlanButton')).disabled = true;
        }
    } else {
      const EditSaveBtn = 'SaveEditedPlanButton-' + data;
      const EditPlanName1 = 'planname1-' + data;
      let editPlanName1 = 0;
      editPlanName1 = (<HTMLFormElement>document.getElementById(EditPlanName1)).value.trim().length;

      // alert (EditPlanName1);
      // alert(editPlanName1);

      if (editPlanName1 > 0) {
        (<HTMLFormElement>document.getElementById(EditSaveBtn)).disabled = false;
      } else {
        (<HTMLFormElement>document.getElementById(EditSaveBtn)).disabled = true;
      }
    }

  }

  OnDownloadMessageLogoAssignmentReport() : void
  {  
      this.spinnerService.show();
      this._planService.GetPlanMessageLogoAssignmentReport( this.provId ).subscribe(
          res => {
              this.spinnerService.hide();
              var blob = new Blob( [res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }); 
              FileSaver.saveAs( blob, 'PlanMessageLogoAssignment-' + formatDate(new Date(), 'yyyy-MM-dd-hh-mm', 'en') + '.xlsx'); 
          }
      );
  }


  ngOnDestroy() {
    this.currentMessagesSubscription.unsubscribe();
    this.currentPlanMessageDeleteComplete.unsubscribe();
    this.currentLogosSubscription.unsubscribe();
    this.currentPlanLogoDeleteComplete.unsubscribe();
    this.currentMessageAssignmentComplete.unsubscribe();
    this.currentAssignLogoComplete.unsubscribe();
    this.currentPlanCreateComplete.unsubscribe();
    this.currentPlanUpdateComplete.unsubscribe();
    this.currentPlanDeleteComplete.unsubscribe();
    this.currentMessageUpdateComplete.unsubscribe();
  }



}
