import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveLogoPlanAssignmentComponent } from './remove-logo-plan-assignment.component';

describe('RemoveLogoPlanAssignmentComponent', () => {
  let component: RemoveLogoPlanAssignmentComponent;
  let fixture: ComponentFixture<RemoveLogoPlanAssignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveLogoPlanAssignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveLogoPlanAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
