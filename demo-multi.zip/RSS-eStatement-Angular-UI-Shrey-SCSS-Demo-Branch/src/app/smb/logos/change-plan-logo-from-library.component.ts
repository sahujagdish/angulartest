import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Logo } from '../shared/logo';
import { LogoService } from './logo.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { async } from '@angular/core/testing';
import { ArrayType } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-change-plan-logo-from-library',
  templateUrl: './change-plan-logo-from-library.component.html',
  styleUrls: ['./change-plan-logo-from-library.component.css']
})
export class ChangePlanLogoFromLibraryComponent implements OnInit {
  @Input() componentData: string;
  @Input() componentData2: string;
  private appCache;
  provId: any;
  _newLogoId: string;
  newLogoId: string;
  PlanID: any = [];
  LogoToReplace: string = '';
  logos: Logo[] = [];
  _listFilter: string;
  filteredLogos: Logo[] = [];
  base64: any;
  ReplacementLogo: any;
  currentLogosSubscription: Subscription;
  // currentLogoReplacementCompleteSubscription: Subscription;

  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();


  constructor(private _LogoService: LogoService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService
    , private sanitizer: DomSanitizer) {
      this.appCache = this._appCacheService.getAppCache();
      this.provId = this.appCache.providerId;
      this.filteredLogos = this.logos;
      this.listFilter = '';
  }

  ngOnInit(): void {
    this.PlanID.push(this.componentData2);

    // setup subscription for DeleteComplete event.
    // this.currentLogoReplacementCompleteSubscription = this._myEventsService.currentLogoReplacementComplete.subscribe(
    //   (replaceLogoComplete: MyEvent) => {
    //       if (replaceLogoComplete.success) {
    //           this.closeModal();
    //           window.alert(replaceLogoComplete.message);
    //       } else {
    //           window.alert(replaceLogoComplete.message);
    //       }
    //   }
    // );

    // subscribe to logos observable which will be emitted from service and set return to local logos
    this.currentLogosSubscription = this._LogoService.logos.subscribe(logos => {
        this.logos = logos;
        this.filteredLogos = logos;
    });

    // Call to get logos. Service will handle if it needs to call the server or not
    this._LogoService.getAllLogos(this.provId);

}


get listFilter(): string {
    return this._listFilter;
}

set listFilter(value: string) {
    this._listFilter = value;
    this.filteredLogos = this._listFilter ? this.performFilter(this.listFilter) : this.logos;
}

performFilter(filterBy: string): Logo[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.logos.filter((logo: Logo) =>
        logo.logoId.toLocaleLowerCase().indexOf(filterBy) !== -1);
    // || this.logos.filter(deleteThese => this._logosToDelete));
}


assignLogoToPlan(chosenLogoId): void {

  const confirmAddLogoToPlan = confirm('Are you sure you wish to assign Logo ID ' + chosenLogoId + ' to Plan ID ' + this.PlanID + '?');

  if (confirmAddLogoToPlan === true) {
        // alert('Making a new logo assignment...');
        this._LogoService.planLogoAssignment(this.provId, chosenLogoId, this.PlanID);
        this.closeModal();
    } else {
      // this.closeModal();
    }

}


closeModal() {
  this.closeEvent.emit(true);
}

ngOnDestroy() {
    this.currentLogosSubscription.unsubscribe();
    // this.currentDeleteCompleteSubscription.unsubscribe();
  }


}
