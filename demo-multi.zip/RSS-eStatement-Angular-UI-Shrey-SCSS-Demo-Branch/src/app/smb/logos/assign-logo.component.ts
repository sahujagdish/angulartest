import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { LogoService } from './logo.service';
import { Plan } from '../shared/plan';
import { PlanService } from '../plans/plan.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';

@Component({
    selector: 'app-assign-logo',
    templateUrl: './assign-logo.component.html',
    styleUrls: ['./assign-logo.component.css']
})
export class AssignLogoComponent implements OnInit, OnDestroy {
    @Input() componentData: string;
    @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
    currentAssignLogoCompleteSubscription: Subscription;
    currentPlansSubscription: Subscription;
    private appCache;
    provId: any;
    chosenLogoId: string;
    filteredPlans: Plan[] = [];
    plans: Plan[] = [];
    _planListFilter: string;
    _plansToAddLogo: any = [];
    _plansToAddLogoDisplay: any = [];

    // [{'PlanName1': '', 'PlanName2': '', 'PlanID': ''}];

    constructor(private _LogoService: LogoService, private _planService: PlanService, private _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {
        this.appCache = this._appCacheService.getAppCache();
        this.provId = this.appCache.providerId;
        this.filteredPlans = this.plans;
        this.planListFilter = '';
    }

    ngOnInit() {
        // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
        this.currentAssignLogoCompleteSubscription = this._myEventsService.currentAssignLogoComplete.subscribe(
            (assignLogoComplete: MyEvent) => {
                if (assignLogoComplete.success) {
                  window.alert(assignLogoComplete.message);
                  this.closeModal();
                } else {
                    window.alert(assignLogoComplete.message);
                }
            }
        );

        this.chosenLogoId = this.componentData;
        // subscribe to plans observable which will be emitted from service and set return to local plans
        this.currentPlansSubscription = this._planService.plans.subscribe(plans => {
            this.plans = plans
            this.filteredPlans = plans;
        });
        //call to get plans. Service will handle if it needs to call the server or not
        this._planService.getAllPlans(this.provId);
    }

    get planListFilter(): string {
        return this._planListFilter;
    }

    set planListFilter(value: string) {
        this._planListFilter = value;
        this.filteredPlans = this._planListFilter ? this.performPlanFilter(this.planListFilter) : this.plans;
    }

    performPlanFilter(filterBy: string): Plan[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.plans.filter((plan: Plan) =>
            (plan.planName1  !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
            || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
    }


    assignLogoToPlans(): void {

        const confirmAddLogoToPlans = confirm('Are you sure you wish to assign Logo ID ' + this.chosenLogoId + ' to the selected plan(s)?');

        if (confirmAddLogoToPlans === true) {
              // alert('Making a new logo assignment...');
              this._LogoService.planLogoAssignment(this.provId, this.chosenLogoId, this._plansToAddLogo);
              // this.closeModal(); // Commented out the call to closeModal() in this location...handle in currentAssignLogoCompleteSubscription instead.
          } else {
            // this.closeModal();
          }

    }


    updateLogoPlansList(PlanName1, PlanName2, PlanID): void {

        if (this._plansToAddLogo.indexOf(PlanID) === -1) {
              this._plansToAddLogo.push(PlanID);
              this._plansToAddLogoDisplay.push(
                {'PlanName1': PlanName1,'PlanName2': PlanName2,'PlanID': PlanID}
              );
        }

        this.toggleSubmitButton();
    }


    RemovePlanFromAssignmentList(planID) {

      const removePlanIndex = this._plansToAddLogo.indexOf(planID);

      if (removePlanIndex > -1) {
          this._plansToAddLogo.splice(removePlanIndex, 1);
          this._plansToAddLogoDisplay.splice(removePlanIndex, 1);
        }

        this.toggleSubmitButton();

    }


    toggleSubmitButton() {
        if (this._plansToAddLogoDisplay.length > 0) {
          (<HTMLFormElement>document.getElementById('AddLogoToPlansBtn')).disabled = false;
        } else {
          (<HTMLFormElement>document.getElementById('AddLogoToPlansBtn')).disabled = true;
      }
    }



    SelectAllPlans() {
        for (let i = 0; i < this.plans.length; i++) {
            this.updateLogoPlansList(this.plans[i].planName1, this.plans[i].planName2, this.plans[i].externalPlanId);
        }
    }


    clearCheckboxes() {
        for (let x = 0; x < document.getElementsByTagName('input').length; x++) {
            if (document.getElementsByTagName('input').item(x).type === 'checkbox') {
                document.getElementsByTagName('input').item(x).checked = false;
                // return true;
            }
        }
    }

    closeModal() {
        this.closeEvent.emit(true);
    }

    ngOnDestroy() {
        this.currentAssignLogoCompleteSubscription.unsubscribe();
        this.currentPlansSubscription.unsubscribe();
    }

}
