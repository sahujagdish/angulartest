//import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ScrollingModule  } from '@angular/cdk/scrolling';
import { CKEditorModule } from 'ngx-ckeditor';
// import { AngularWebStorageModule } from 'angular-web-storage';
import { AngularFileUploaderModule } from 'angular-file-uploader';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatRadioModule} from '@angular/material/radio';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AppComponent } from './app.component';
import { PlanListComponent } from './plans/plan-list.component';
import { MessageListComponent } from './messages/message-list.component';
import { SafeHtmlPipe } from './messages/safe-html';
import { LogoListComponent } from './logos/logo-list.component';
import { PlanAddComponent } from './plans/plan-add.component';
import { TestComponent } from './test/test.component';
import { TestmessageComponent } from './messages/testmessage.component';
import { TokenInterceptorService } from './shared/services/token-interceptor.service';
import { AppCacheModel } from './shared/model/appCache.model';
import { ModalComponent } from './shared/component/modal/modal.component';
import { ModalDirective } from './shared/component/modal/modal.directive';
import { UploadLogoComponent } from './logos/upload-logo.component';
import { ReplaceLogoComponent } from './logos/replace-logo.component';
import { ModalContentDirective } from './shared/component/modal/modal-content.directive';
import { AssignLogoComponent } from './logos/assign-logo.component';
import { AssignMessageComponent } from './messages/assign-message.component';
import { CreateMessageComponent } from './messages/create-message.component';
import { UpdateMessageComponent } from './messages/update-message.component';
import { AddMessageOptionsComponent } from './messages/add-message-options.component';
import { AddPlanMessageFromLibraryComponent } from './messages/add-plan-message-from-library.component';
import { PlanMessagesViewallComponent } from './plans/plan-messages-viewall.component';
import { ChangePlanLogoOptionsComponent } from './logos/change-plan-logo-options.component';
import { ChangePlanLogoFromLibraryComponent } from './logos/change-plan-logo-from-library.component';
import { ChangePlanLogoFromUploadComponent } from './logos/change-plan-logo-from-upload.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { RemoveMessagePlanAssignmentComponent } from './messages/remove-message-plan-assignment.component';
import { RemoveLogoPlanAssignmentComponent } from './logos/remove-logo-plan-assignment.component';
import { CommonModule } from '@angular/common';
import { AppcacheService } from './shared/services/appcache.service';


@NgModule({
  declarations: [
    AppComponent,
    PlanListComponent,
    PlanAddComponent,
    PlanMessagesViewallComponent,

    MessageListComponent,
    AssignMessageComponent,
    CreateMessageComponent,
    UpdateMessageComponent,
    AddMessageOptionsComponent,
    AddPlanMessageFromLibraryComponent,
	
	SafeHtmlPipe,

    LogoListComponent,
    UploadLogoComponent,
    ReplaceLogoComponent,
    AssignLogoComponent,
    ChangePlanLogoOptionsComponent,
    ChangePlanLogoFromLibraryComponent,
    ChangePlanLogoFromUploadComponent,

    TestComponent,
    TestmessageComponent,

    ModalComponent,
    ModalDirective,
    ModalContentDirective,
    RemoveMessagePlanAssignmentComponent,
    RemoveLogoPlanAssignmentComponent,

    ModalComponent,
    PlanMessagesViewallComponent,
    AssignMessageComponent,
    CreateMessageComponent,
    UpdateMessageComponent,
    AddMessageOptionsComponent,
    AddPlanMessageFromLibraryComponent,
    ReplaceLogoComponent,
    UploadLogoComponent,
    AssignLogoComponent,
    ChangePlanLogoOptionsComponent,
    ChangePlanLogoFromLibraryComponent,
    ChangePlanLogoFromUploadComponent,
    RemoveMessagePlanAssignmentComponent,
    RemoveLogoPlanAssignmentComponent
  ],
 
  imports: [
    CommonModule,
    //BrowserModule,
    //BrowserAnimationsModule,
    MatTooltipModule,
    MatButtonModule,
    MatCheckboxModule,
    MatRadioModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    HttpClientModule,
    ScrollingModule,
    CKEditorModule,
    // AngularWebStorageModule,
    AngularFileUploaderModule,
	NgxPaginationModule,
    // AppRoutingModule
    RouterModule.forChild([
      {
        path:'',component: AppComponent, children:[
      { path: 'plans', component: PlanListComponent},
      { path: 'plans/add', component: PlanAddComponent},
      { path: 'messages', component: MessageListComponent},
      { path: 'logos', component: LogoListComponent },
      { path: 'test', component: TestComponent },
      { path: 'testmessages', component: TestmessageComponent },
      { path: '', redirectTo: 'plans', pathMatch: 'full' },
      { path: '**', redirectTo: 'plans', pathMatch: 'full' }
        ]
      }
    ]
    // ,
    // {
    //   onSameUrlNavigation: 'reload'
    // }
    // ,
    // {
      // Tell the router to use the hash instead of HTML5 pushstate.
      // useHash: true,

      // In order to get anchor / fragment scrolling to work at all, we need to
      // enable it on the router.
      // anchorScrolling: 'enabled',

      // Once the above is enabled, the fragment link will only work on the
      // first click. This is because, by default, the Router ignores requests
      // to navigate to the SAME URL that is currently rendered. Unfortunately,
      // the fragment scrolling is powered by Navigation Events. As such, we
      // have to tell the Router to re-trigger the Navigation Events even if we
      // are navigating to the same URL.
      // onSameUrlNavigation: 'reload',

      // Let's enable tracing so that we can see the aforementioned Navigation
      // Events when the fragment is clicked.
      // enableTracing: true,
      // scrollPositionRestoration: 'enabled'
    // }
  )
  ],
  providers: [
    // {
    //   provide: APP_INITIALIZER,
    //   useFactory: (preapp: PreAppService) => () => preapp.load(),
    //   deps: [PreAppService],
    //   multi: true
    // },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },
    AppcacheService,
    AppCacheModel
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
  // entryComponents: [
  //   ModalComponent,
  //   PlanMessagesViewallComponent,
  //   AssignMessageComponent,
  //   CreateMessageComponent,
  //   UpdateMessageComponent,
  //   AddMessageOptionsComponent,
  //   AddPlanMessageFromLibraryComponent,
  //   ReplaceLogoComponent,
  //   UploadLogoComponent,
  //   AssignLogoComponent,
  //   ChangePlanLogoOptionsComponent,
  //   ChangePlanLogoFromLibraryComponent,
  //   ChangePlanLogoFromUploadComponent,
  //   RemoveMessagePlanAssignmentComponent,
  //   RemoveLogoPlanAssignmentComponent
  // ]
//  ,bootstrap: [AppComponent]
})
export class SmbAppModule { }
