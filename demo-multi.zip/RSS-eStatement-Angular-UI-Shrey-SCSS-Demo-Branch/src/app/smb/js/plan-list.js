
	<script>


  var dialog = document.querySelector('#dialog-message');
  var showDialogButton = document.querySelector('#show-dialog1');

  if (!dialog.showModal) {
    dialogPolyfill.registerDialog(dialog);
  }
  showDialogButton.addEventListener('click', function removeMessage() {
    dialog.showModal();
  });
  dialog.querySelector('.close').addEventListener('click', function () {
    dialog.close();
  });

  // duped above script above with modifications to demonstrate the second logo alert

  var dialog2 = document.querySelector('#dialog-logo');
  var showDialogButton2 = document.querySelector('#show-dialog-logo');
  if (!dialog2.showModal) {
    dialogPolyfill.registerDialog(dialog2);
  }
  showDialogButton2.addEventListener('click', function removeMessage() {
    dialog2.showModal();
  });
  dialog2.querySelector('.close').addEventListener('click', function () {
    dialog2.close();
  });
  dialog2.querySelector('.removeLogofromPlan').addEventListener('click', function () {
    dialog2.close();
  });

// Dialog script similar to above with modifications to
// demonstrate the  alert to confirm LOGO Edits

      $(document).on('show.bs.modal','#uploadLogo', function () {
        // When the modal widow has been added to the dom

    // change logo modal  - activate the save button after changing inputs
    console.log('upload logo model is open');
    $('input').change(function () {
        console.log("The input  has been changed.");
        $('button[disabled]').removeAttr('disabled');
      });


      var dialog3 = document.querySelector('#dialog-confirm-logo-edit');
    //	console.log(dialog2)
      var showDialogButton3 = document.querySelector('#uploadLogoButton');
      console.log(showDialogButton3)
      if (!dialog3.showModal) {
        dialogPolyfill.registerDialog(dialog3);
      }
      showDialogButton3.addEventListener('click', function removeMessage() {
        dialog3.showModal();
      });
      dialog3.querySelector('.close').addEventListener('click', function () {
        dialog3.close();
      });
      dialog3.querySelector('.confirmEdit').addEventListener('click', function () {
        dialog3.close();
         $('.modal').modal('hide'); // hide all modals
      });
      $(showDialogButton3).click(function(){
        $(this).attr('disabled', 'disabled');
      })
    });

    // Dialog script similar to above with modifications to demonstrate
    // the alert to confirm message Edits

    $(document).on('show.bs.modal','#Beneficiaries', function () {
        // When the modal widow has been added to the dom

      var dialog4 = document.querySelector('#dialog-confirm-edit');
    //	console.log(dialog4)
      var showDialogButton4 = document.querySelector('#saveEdit');
      console.log(showDialogButton4)
      if (!dialog4.showModal) {
        dialogPolyfill.registerDialog(dialog4);
      }
      showDialogButton4.addEventListener('click', function removeMessage() {
        dialog4.showModal();
      });
      dialog4.querySelector('.close').addEventListener('click', function () {
        dialog4.close();
      });
      dialog4.querySelector('.confirmEdit').addEventListener('click', function () {
        dialog4.close();
         $('.modal').modal('hide'); // hide all modals
      });
      $(showDialogButton4).click(function(){
        $(this).attr('disabled', 'disabled');
      })
    });



</script>
