import { Component, OnInit, AfterViewChecked, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { Message } from '../shared/message';
import { Plan } from '../shared/plan';
import { MessageService } from './message.service';
import { PlanService } from '../plans/plan.service';
//import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription, Observable } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { HttpResponse } from '@angular/common/http';
import { ErrorHandlingService } from '../shared/services/error/error-handling.service';
import { catchError } from 'rxjs/operators';
import { SpinnerService } from '../shared/services/spinner-service.service';

declare var jQuery: any;

declare var $: any;

@Component({
  selector: 'app-remove-message-plan-assignment',
  templateUrl: './remove-message-plan-assignment.component.html',
  styleUrls: ['./remove-message-plan-assignment.component.css']
})

export class RemoveMessagePlanAssignmentComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  currentRemoveAssignMessageCompleteSubscription: Subscription;
  private appCache;
  provId: any;
  errorMessage: string;
  _listFilter: string;
  filteredMessages: Message[] = [];
  messages: Message[] = [];
  _messagesToDelete: any = [];
  _messageIdToDelete: any = [];
  clientId: number;
  editorValue: string = '';
  fullPage: false;
  chosenMessageId: string;
  myToken: any;
  mySessionToken: any;
  theDate = new Date();
  theYear = this.theDate.getFullYear();
  _planListFilter: string;
  filteredPlans: Plan[] = [];
  plans: Plan[] = [];
  uneditedOriginalMessage: string;
  newMessageId: string;
  newMessageName: string;
  _plansToRemoveMessage: any = [];
  _plansToRemoveMessageDisplay: any = [];


  constructor(private _messageService: MessageService
    //, private localStorage: LocalStorageService
    , private _planService: PlanService, _appCacheService: AppcacheService, private _myEventsService: MyEventsService, private _errorHandlingService: ErrorHandlingService, private spinnerService: SpinnerService) {

    this.provId = _appCacheService.getAppCache().providerId;
    this.filteredMessages = this.messages;
    this.listFilter = '';
    this.uneditedOriginalMessage = '';

  }


  ngOnInit(): void {
    this.spinnerService.show();
    // setup subscription for remove message assignment complete event. When true emit close event for modal or do something else if false
    this.currentRemoveAssignMessageCompleteSubscription = this._myEventsService.currentMessageRemoveAssignmentComplete.subscribe(
      (removeAssignMessageComplete: MyEvent) => {
        if (removeAssignMessageComplete.success) {
          window.alert(removeAssignMessageComplete.message);
          this.closeModal();
        } else {
          window.alert(removeAssignMessageComplete.message);
        }
      }
    );

    this.chosenMessageId = this.componentData;

    // call to get plans. Service will handle if it needs to call the server or not
    this._planService.getMessagePlans(this.provId, this.chosenMessageId).pipe(
      catchError(this._errorHandlingService.handleHttpErrorResponse)
    ).subscribe((resp: any) => {
      this.plans = resp.body;
      this.filteredPlans = resp.body;
      this.spinnerService.hide();
    });

  }

  ngAfterViewChecked(): any {
    // alert('In ngAfterViewChecked');
    this.shortenMessage();
  }

  shortenMessage() {
    $.shorten.setDefaults({
      namespace: 'shorten',
      chars: 300,
      ellipses: '...',
      more: '<p>SHOW MORE</p>',
      less: '<p>SHOW LESS</p>'
    });

    $('.addReadMore').shorten();
  }


  get listFilter(): string {
    return this._listFilter;
  }

  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredMessages = this._listFilter ? this.performFilter(this.listFilter) : this.messages;
  }

  get planListFilter(): string {
    return this._planListFilter;
  }

  set planListFilter(value: string) {
    this._planListFilter = value;
    this.filteredPlans = this._planListFilter ? this.performPlanFilter(this._planListFilter) : this.plans;
  }


  performFilter(filterBy: string): Message[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.messages.filter((message: Message) =>
      // Need to first check for messageName being NULL to avoid an error because it isn't a required field and may be NULL
      (message.messageName !== null && message.messageName.toLocaleLowerCase().indexOf(filterBy) !== -1)
      || message.messageId.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  performPlanFilter(filterBy: string): Plan[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.plans.filter((plan: Plan) =>
      (plan.planName1 !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
      || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
      || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
  }

  updateMessagePlansList(PlanName1, PlanName2, PlanID): void {

    if (this._plansToRemoveMessage.indexOf(PlanID) === -1) {
      this._plansToRemoveMessage.push(PlanID);
      this._plansToRemoveMessageDisplay.push(
        { 'PlanName1': PlanName1, 'PlanName2': PlanName2, 'PlanID': PlanID }
      );
    }

    this.toggleSubmitButton();
  }


  RemovePlanFromAssignmentList(planID) {

    const removePlanIndex = this._plansToRemoveMessage.indexOf(planID);

    if (removePlanIndex > -1) {
      this._plansToRemoveMessage.splice(removePlanIndex, 1);
      this._plansToRemoveMessageDisplay.splice(removePlanIndex, 1);
    }

    this.toggleSubmitButton();

  }


  toggleSubmitButton() {
    if (this._plansToRemoveMessageDisplay.length > 0) {
      (<HTMLFormElement>document.getElementById('RemoveMessageToPlansBtn')).disabled = false;
    } else {
      (<HTMLFormElement>document.getElementById('RemoveMessageToPlansBtn')).disabled = true;
    }
  }



  SelectAllPlans() {
    for (let i = 0; i < this.plans.length; i++) {
      this.updateMessagePlansList(this.plans[i].planName1, this.plans[i].planName2, this.plans[i].externalPlanId);
    }
  }

  removeMessageFromPlans(): void {

    const confirmRemoveMessageToPlans = confirm('Are you sure you wish to remove Message ID ' + this.chosenMessageId + ' from the selected plan(s)?');

    if (confirmRemoveMessageToPlans === true) {
      this._messageService.planMessageRemoval(this.provId, this.chosenMessageId, this._plansToRemoveMessage);
    } else {
      // this.closeModal();
    }
  }


  closeModal() {
    this.closeEvent.emit(true);
  }

  ngOnDestroy() {
    this.currentRemoveAssignMessageCompleteSubscription.unsubscribe();
    
  }


}
