import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, map} from 'rxjs/operators';

import { TestMessage } from '../shared/testmessage';
import { environment } from '../../../environments/environment.dev';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})

export class TestmessageService {

  // private messageUrl = 'api/messages/testmessages.json';

  private messageUrl = environment.MMApiURL + 'statement/msgs/97?id=RETIRE';
  //private messageUrl = 'https://localhost:44361/api/v1/statement/msgs/97?id=RETIRE';
  private newMessageUrl = environment.MMApiURL + 'statement/msgs/97?id=NEWMESS1';


  constructor(private _http: HttpClient) {}


  getMessages(): Observable<HttpResponse<TestMessage[]>> {

    console.log(this.messageUrl);
    // let headers = new HttpHeaders();
    // headers = headers.set('Authorization', 'Bearer ' + environment.sessionJWT);

    // return this._http.get<TestMessage[]>(this.messageUrl, { headers: headers }).pipe(
    return this._http.get<TestMessage[]>(this.messageUrl, {observe: 'response'}).pipe(
                // tap(data => console.log('All: ' + JSON.stringify(data))),
                // catchError(this.handleError)
    );
  }



  updateMessage(updatedMessage): Observable<any> {

    console.log('Updating with the following message: ' + JSON.stringify(updatedMessage));


    // const body = new HttpParams()
    //   .set('Message', updatedMessage);


    return this._http.put<any>(this.messageUrl, JSON.stringify(updatedMessage), httpOptions).pipe(
                catchError(this.handleError)
              );
  }



  addMessage(newMessage): Observable<any> {

    console.log('New Message: ' + newMessage);

    // const headers = new HttpHeaders()
    //   .set('Content-Type', 'application/json');


    // const body = new HttpParams()
    //   .set('Message', newMessage);

      // Need to add Message Name but I don't think it is available in the .NET API yet


    // return this._http.get<TestMessage[]>(this.messageUrl, { headers: headers }).pipe(
    return this._http.post<any>(this.newMessageUrl, JSON.stringify(newMessage), httpOptions).pipe(
                 catchError(this.handleError)
              );
  }


  getAuthenticationToken(authData): Observable<any> {

    console.log('Auth Data: ' + JSON.stringify(authData));

    return this._http.post<any>('https://qa1.newkirkone.com/MMApi/api/account/auth', JSON.stringify(authData), httpOptions).pipe(
     // return this._http.post<any>('https://dev1.newkirkone.com/MMApi/api/account/auth', JSON.stringify(authData), httpOptions).pipe(
     // return this._http.post<any>('https://localhost:44361/api/account/auth', JSON.stringify(authData), httpOptions).pipe(
      // catchError(this.handleError)
   );
}

  deleteMessage(messageToDelete): Observable<any> {

    console.log(this.messageUrl);

    return this._http.delete<TestMessage[]>(this.messageUrl).pipe(
                 catchError(this.handleError)
    );

  }


  private handleError(err: HttpErrorResponse) {
      // in a real world app, we may send the server to some remote logging infrastructure
      // instead of just logging it to the console
      let errorMessage = '';
      if (err.error instanceof ErrorEvent) {
        // A client-side or network error occurred. Handle it accordingly.
        errorMessage = `An error occurred: ${err.error.message}`;
      } else {
        // The backend returned an unsuccessful response code.
        // The response body may contain clues as to what went wrong,
        errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
      }
      console.error(errorMessage);
      return throwError(errorMessage);
  }

}

