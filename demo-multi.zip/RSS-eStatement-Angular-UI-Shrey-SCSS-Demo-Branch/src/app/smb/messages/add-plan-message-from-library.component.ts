import { Component, OnInit, Input, EventEmitter, Output, AfterViewChecked, OnDestroy } from '@angular/core';
import { Message } from '../shared/message';
import { MessageService } from './message.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';


declare var jQuery: any;

declare var $: any;


@Component({
  selector: 'app-add-plan-message-from-library',
  templateUrl: './add-plan-message-from-library.component.html',
  styleUrls: ['./add-plan-message-from-library.component.css']
})
export class AddPlanMessageFromLibraryComponent implements OnInit, AfterViewChecked, OnDestroy {
  @Input() componentData: string;
  @Input() componentData2: string = '';
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  currentAssignMessageCompleteSubscription: Subscription;
  currentMessagesSubscription: Subscription;

  // provId = environment.providerId;
  provId: any;
  errorMessage: string;
  messages: Message[] = [];
  ExternalPlanID: any = [];
  MessageLocation: string = '';
  _listFilter: string;
  filteredMessages: Message[] = [];


  constructor(private _messageService: MessageService, _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {
      this.provId = _appCacheService.getAppCache().providerId;
      this.filteredMessages = this.messages;
      this.listFilter = '';

  }

  ngOnInit() {
    // setup subscription for AssignMessageComplete event. When true emit close event for modal or do something else if false
    this.currentAssignMessageCompleteSubscription = this._myEventsService.currentMessageAssignmentComplete.subscribe(
          (assignMessageComplete: MyEvent) => {
              if (assignMessageComplete.success) {
                  window.alert(assignMessageComplete.message);
                  this.closeModal();
              } else {
                  window.alert(assignMessageComplete.message);
              }
          }
      );


      // subscribe to messages observable which will be emitted from service and set return to local messages
      this.currentMessagesSubscription = this._messageService.messages.subscribe(messages => {
        this.messages = messages;
        this.filteredMessages = messages;
      });

      //call to get messages. Service will handle if it needs to call the server or not
      this._messageService.getAllMessages(this.provId);


      if (this.componentData !== '' && this.componentData2 !== '') {
          this.ExternalPlanID.push(this.componentData);
          this.MessageLocation = this.componentData2;
      }

  }


  ngAfterViewChecked(): any {
    // commenting out the call to shortenMessage as the 3rd. party node_modules\jquery-shorten tool is stripping out formatting.
    // this.shortenMessage();
  }


  shortenMessage() {

    $.shorten.setDefaults({
        namespace: 'shorten',
        chars: 300,
        ellipses: '...',
        more: '<p>SHOW MORE</p>',
        less: '<p>SHOW LESS</p>'
    });

    $('.addReadMore').shorten();
    //  alert('after shorten in shortenMessage');
  }


  get listFilter(): string {
      return this._listFilter;
  }

  set listFilter(value: string) {
      this._listFilter = value;
      this.filteredMessages = this._listFilter ? this.performFilter(this.listFilter) : this.messages;
  }

  performFilter(filterBy: string): Message[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.messages.filter((message: Message) =>
        // Need to first check for messageName being NULL to avoid an error because it isn't a required field and may be NULL
        (message.messageName !== null && message.messageName.toLocaleLowerCase().indexOf(filterBy) !== -1)
        || (message.messageId !== null && message.messageId.toLocaleLowerCase().indexOf(filterBy) !== -1));
  }



  planMessageAssignment(messageId) {

    const confirmAddMessageToPlan = confirm('Are you sure you wish to assign Message ID ' + messageId + ' to Plan ID ' + this.ExternalPlanID + '?');

    if (confirmAddMessageToPlan === true) {
          // alert('Making a new logo assignment...');
          this._messageService.planMessageAssignment(this.provId, messageId, this.ExternalPlanID, this.MessageLocation);
          // this.closeModal();
      }

  }


  closeModal() {
    this.closeEvent.emit(true);
  }

  ngOnDestroy() {
    this.currentAssignMessageCompleteSubscription.unsubscribe();
    this.currentMessagesSubscription.unsubscribe();
  }


}
