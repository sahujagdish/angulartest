import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { catchError, tap, map} from 'rxjs/operators';
import { Message } from '../shared/message';
import { environment } from '../../../environments/environment';
import { ErrorHandlingService } from '../shared/services/error/error-handling.service';
import { MyEventType } from '../shared/model/myenums.enum';
import { MyEventsService } from '../shared/services/events/myevents.service';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization' : 'Bearer ' + sessionStorage.getItem('token')
  })
};


@Injectable({
  providedIn: 'root'
})

export class MessageService {
  messages: Observable<Message[]>;
  private _messages: BehaviorSubject<Message[]>;
  private messageUrl: string;
  private dataStore: {
    messages: Message[]
};



  constructor(private _http: HttpClient, private _errorHandlingService: ErrorHandlingService, private _myEventsService: MyEventsService) {
    this.messageUrl = environment.MMApiURL;
    this.dataStore = { messages: [] };
     // Observable Message source...Use BehaviorSubject so value is available immediatly when subscribed too and after next is called.
     this._messages = <BehaviorSubject<Message[]>>new BehaviorSubject([]);
     // Observable Message stream
     this.messages = this._messages.asObservable();
  }



  getAllMessages(provId: any) {
    // if local observable source is empty...call to get from server..Otherwise its already available in observable stream
    if (!this._messages.getValue().length){
        this._http.get<Message[]>(this.messageUrl + 'msgs/' + provId, { headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization' : 'Bearer ' + sessionStorage.getItem('token')
        }), observe: 'response' }).pipe(
            catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(resp => {
            const status = resp.status;
            console.log('getAllMessages Status Code: ' + status);
            // Need to use spread operator to create a copy of itself. Otherwise the value of messages is still actually the same and view doesn't refresh
            this.dataStore.messages = [...this.dataStore.messages];
            // set messsages data returned to dataStore
            this.dataStore.messages = resp.body;
            //create a copy and emit to observable
            this._messages.next(Object.assign({}, this.dataStore).messages);
        }
        );
    }
  }


   getProviderMessage(provId, messageId) {
    return this._http.get<Message>(this.messageUrl + 'msgs/' + provId + '/' + messageId, { observe: 'response' });
  }


  getPlanMessages(provid, planId) {
    return this._http.get<any>(this.messageUrl + 'msgs/' + provid + '/plans/' + planId);
  }

  // updateMessage(provId, messageId, messageName, updatedMessage): Observable<HttpResponse<any>> {

  updateMessage(provId, messageId, messageName, updatedMessage) {

    const updatedMsg = {
      'Message': updatedMessage,
      'MessageName': messageName
    };

    // return this._http.put<any>(this.messageUrl + 'msgs/' + provId + '?id=' + messageId, JSON.stringify(updatedMsg), {
    //               headers: new HttpHeaders({
    //                 'Content-Type': 'application/json'
    //                 }), observe: 'response'
    //             })
    //             .pipe(map(res => res));

    this._http.put<any>(this.messageUrl + 'msgs/' + provId + '?id=' + messageId, JSON.stringify(updatedMsg), httpOptions).pipe(
      catchError(this._errorHandlingService.handleHttpErrorResponse)
    ).subscribe(
        resp => {
            console.log('Response from updateMessage: ' + JSON.stringify(resp));
            // Need to use spread operator to create a copy of itself. Otherwise the value of messages is still actually the same and view doesnt refresh
            this.dataStore.messages = [...this.dataStore.messages];

            // push new message to dataStore that was returned from server
            // this.dataStore.messages.push(resp);

           // The data points returned from the REST Service are named differently than what is returned from the HttpGet for provider messages
           // so I am setting the response data to correspond to the appropriate model names.
            const messageToUpdate = {
              'providerId': provId,
              'messageId': messageId,
              'messageName': messageName,
              'originalMessage': updatedMessage
            };
            // this.dataStore.messages.push(messageToUpdate);
            // remove original message from dataStore and replace with the updated message
              this.dataStore.messages.forEach((t, i) => {
                if (t.messageId === messageId) {
                    this.dataStore.messages.splice(i, 1, messageToUpdate);
                }
            });

            //create a copy and emit to observable
            this._messages.next(Object.assign({}, this.dataStore).messages);
            this._myEventsService.triggerMyEvent(true, MyEventType.UpdateMessageComplete, 'Message has been updated!');
        },
        err => {
            this._myEventsService.triggerMyEvent(false, MyEventType.UpdateMessageComplete, 'Update message has failed!');
        }
    );


  }



  addMessage(provId, newMessageId, newMessageName, newMessage) {

    const newMsg = {
      'Message': newMessage,
      'MessageName': newMessageName
    };


    this._http.post<any>(this.messageUrl + 'msgs/' + provId + '?id=' + newMessageId, JSON.stringify(newMsg), httpOptions).pipe(
      catchError(this._errorHandlingService.handleHttpErrorResponse)
    ).subscribe(
        resp => {
            console.log('Response from create addMessage: ' + JSON.stringify(resp));
            // Need to use spread operator to create a copy of itself. Otherwise the value of messages is still actually the same and view doesnt refresh
            this.dataStore.messages = [...this.dataStore.messages];

            // push new message to dataStore that was returned from server
            // this.dataStore.messages.push(resp);

           // The data points returned from the REST Service are named differently than what is returned from the HttpGet for provider messages
           // so I am setting the response data to correspond to the appropriate model names.
            const messageToAdd = {
              'providerId': resp.providerId,
              'messageId': resp.id,
              'messageName': resp.messageName,
              'originalMessage': resp.newMessage
            };
            this.dataStore.messages.push(messageToAdd);

            //create a copy and emit to observable
            this._messages.next(Object.assign({}, this.dataStore).messages);
            this._myEventsService.triggerMyEvent(true, MyEventType.CreateMessageComplete, 'Message has been created!');
        },
        err => {
            this._myEventsService.triggerMyEvent(false, MyEventType.CreateMessageComplete, 'Create message has failed!');
        }
    );

  }



  async addMessageAndAssign(provId, newMessageId, newMessageName, newMessage, externalPlanID, messageLocation) {


    const newMsg = {
      'Message': newMessage,
      'MessageName': newMessageName
      };

      const _plansToAddMessage: any = [];
      _plansToAddMessage.push(externalPlanID);

    let resp = await this._http.post<any>(this.messageUrl + 'msgs/' + provId + '?id=' + newMessageId, JSON.stringify(newMsg), httpOptions).toPromise();

    // add to the messages dataStore
    this.dataStore.messages = [...this.dataStore.messages];

    // push new message to dataStore that was returned from server
    // this.dataStore.messages.push(resp);

    // The data points returned from the REST Service are named differently than what is returned from the HttpGet for provider messages
    // so I am setting the response data to correspond to the appropriate model names.
      const messageToAdd = {
        'providerId': resp.providerId,
        'messageId': resp.id,
        'messageName': resp.messageName,
        'originalMessage': resp.newMessage
      };
      this.dataStore.messages.push(messageToAdd);

      //create a copy and emit to observable
      this._messages.next(Object.assign({}, this.dataStore).messages);


    console.log('Response creating message in addMessageAndAssign: ' + JSON.stringify(resp));

    this.planMessageAssignment(provId, newMessageId, _plansToAddMessage, messageLocation);

  }



  deleteMessage(provId, messageID) {

        this._http.delete<Message[]>(this.messageUrl + 'msgs/' + provId + '/' + messageID).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
          resp => {
              // console.log('Response for deleting a message: ' + resp);
              // Need to use spread operator (i.e., "[...]") to create a copy of itself. Otherwise the value of messages is still actually the same and view doesnt refresh
              this.dataStore.messages = [...this.dataStore.messages];
              // remove message from dataStore that was deleted from server
              this.dataStore.messages.forEach((t, i) => {
                  if (t.messageId === messageID) {
                      this.dataStore.messages.splice(i, 1);
                  }
              });
              //create a copy and emit to observable
              this._messages.next(Object.assign({}, this.dataStore).messages);
              this._myEventsService.triggerMyEvent(true, MyEventType.DeleteMessageComplete, 'Message has been deleted!');
          },
          err => {
              this._myEventsService.triggerMyEvent(false, MyEventType.DeleteMessageComplete, 'Message delete has failed!');
          }
      );

  }



  deletePlanMessage(provId, planId, location): any {

        this._http.delete(this.messageUrl + 'msgs/' + provId + '/' + planId + '?location=' + location).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
        ).subscribe(
          resp => {
            this._myEventsService.triggerMyEvent(true, MyEventType.DeletePlanMessageComplete, 'Plan message has been deleted!');
          },
          err => {
              this._myEventsService.triggerMyEvent(false, MyEventType.DeletePlanMessageComplete, 'Plan message delete has failed!');
          }
      );
  }



  planMessageAssignment(provId, messageId, planIds, messagePosition) {
      this._http.post<any>(this.messageUrl + 'msgs/' + provId + '/plans/' + messagePosition + '?id=' + messageId,JSON.stringify(planIds), httpOptions).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
          ).subscribe(
              resp => {
                  console.log('Response for assigning message to plan(s): ' + resp);

                  this._myEventsService.triggerMyEvent(true, MyEventType.AssignMessageComplete , 'Message has been assigned to selected plan(s)!');
              },
              err => {
                  this._myEventsService.triggerMyEvent(false, MyEventType.AssignMessageComplete, 'Message assignment has failed!');
              }
          );
    }

    planMessageRemoval(provId, messageId, planIds) {
      this._http.post<any>(this.messageUrl + 'msgs/' + provId + '/' + messageId + '/plans/delete', JSON.stringify(planIds), httpOptions).pipe(
          catchError(this._errorHandlingService.handleHttpErrorResponse)
          ).subscribe(
              resp => {
                  this._myEventsService.triggerMyEvent(true, MyEventType.RemoveAssignMessageComplete, 'Message has been removed from selected plan(s)!');
              },
              err => {
                  this._myEventsService.triggerMyEvent(false, MyEventType.RemoveAssignMessageComplete, 'Message removal has failed!');
              }
          );
    }

    planMessageAssignmentReport( provId: number ) 
    {
      return this._http.get( this.messageUrl + 'msgs/' + provId + '/Plans/Report',   { responseType: 'blob' } );
    }

    private handleError(err: HttpErrorResponse) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          // A client-side or network error occurred. Handle it accordingly.
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
    }

}

