import { Component, OnInit, AfterViewChecked, Input, EventEmitter, Output, OnDestroy} from '@angular/core';
import { Message } from '../shared/message';
import { Plan } from '../shared/plan';
import { MessageService } from './message.service';
import { PlanService } from '../plans/plan.service';
//import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';
//import { JsonPipe } from '@angular/common/src/pipes/json_pipe';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';

declare var jQuery: any;

declare var $: any;

@Component({
  selector: 'app-assign-message',
  templateUrl: './assign-message.component.html',
  styleUrls: ['./assign-message.component.css']
})

export class AssignMessageComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  currentAssignMessageCompleteSubscription: Subscription;
  currentPlansSubscription: Subscription;
  private appCache;
  provId: any;
  errorMessage: string;
  _listFilter: string;
  filteredMessages: Message[] = [];
  messages: Message[] = [];
  _messagesToDelete: any = [];
  _messageIdToDelete: any = [];
  clientId: number;
  editorValue: string = '';
  fullPage: false;
  chosenMessageId: string;
  myToken: any;
  mySessionToken: any;
  theDate = new Date();
  theYear = this.theDate.getFullYear();
  _planListFilter: string;
  filteredPlans: Plan[] = [];
  plans: Plan[] = [];
  uneditedOriginalMessage: string;
  newMessageId: string;
  newMessageName: string;
  _plansToAddMessage: any = [];
  _plansToAddMessageDisplay: any = [];
  messagePosition: number;


  constructor(private _messageService: MessageService
    //, private localStorage: LocalStorageService
      , private _planService: PlanService, _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {

      this.provId = _appCacheService.getAppCache().providerId;
      this.filteredMessages = this.messages;
      this.listFilter = '';
      this.uneditedOriginalMessage = '';

  }


  ngOnInit(): void {
     // setup subscription for message assignment complete event. When true emit close event for modal or do something else if false
     this.currentAssignMessageCompleteSubscription = this._myEventsService.currentMessageAssignmentComplete.subscribe(
          (assignMessageComplete: MyEvent) => {
              if (assignMessageComplete.success) {
                window.alert(assignMessageComplete.message);
                this.closeModal();
              } else {
                  window.alert(assignMessageComplete.message);
              }
          }
      );

      this.chosenMessageId = this.componentData;

      // subscribe to plans observable which will be emitted from service and set return to local plans
      this.currentPlansSubscription = this._planService.plans.subscribe(plans => {
          this.plans = plans;
          this.filteredPlans = plans;
      });

      // call to get plans. Service will handle if it needs to call the server or not
      this._planService.getAllPlans(this.provId);

      // this._messageService.getAllMessages(this.provId).subscribe(
      //     resp => {
      //         const status = resp.status;
      //         console.log('Status Code for getAllMessages called in ngOnInit: ' + status);
      //         this.messages = resp.body;
      //         this.filteredMessages = this.messages;
      //     },
      //     error => this.errorMessage = <any>error
      // );


      // (<HTMLFormElement>document.getElementById('DeleteMessagesButton')).disabled = true;

  }

  ngAfterViewChecked(): any {
      // alert('In ngAfterViewChecked');
      this.shortenMessage();
  }

  shortenMessage() {

      //  alert('before shorten in shortenMessage');

      $.shorten.setDefaults({
          namespace: 'shorten',
          chars: 300,
          ellipses: '...',
          more: '<p>SHOW MORE</p>',
          less: '<p>SHOW LESS</p>'
      });

      $('.addReadMore').shorten();
      //  alert('after shorten in shortenMessage');
  }


  get listFilter(): string {
      return this._listFilter;
  }

  set listFilter(value: string) {
      this._listFilter = value;
      this.filteredMessages = this._listFilter ? this.performFilter(this.listFilter) : this.messages;
  }

  get planListFilter(): string {
      return this._planListFilter;
  }

  set planListFilter(value: string) {
      this._planListFilter = value;
      this.filteredPlans = this._planListFilter ? this.performPlanFilter(this._planListFilter) : this.plans;
  }


  performFilter(filterBy: string): Message[] {
      filterBy = filterBy.toLocaleLowerCase();
      return this.messages.filter((message: Message) =>
          // Need to first check for messageName being NULL to avoid an error because it isn't a required field and may be NULL
          (message.messageName !== null && message.messageName.toLocaleLowerCase().indexOf(filterBy) !== -1)
          || message.messageId.toLocaleLowerCase().indexOf(filterBy) !== -1);
  }

  performPlanFilter(filterBy: string): Plan[] {
      filterBy = filterBy.toLocaleLowerCase();
      return this.plans.filter((plan: Plan) =>
        (plan.planName1  !== null && plan.planName1.toLocaleLowerCase().indexOf(filterBy) !== -1)
        || (plan.planName2 !== null && plan.planName2.toLocaleLowerCase().indexOf(filterBy) !== -1)
        || (plan.externalPlanId !== null && plan.externalPlanId.toLocaleLowerCase().indexOf(filterBy) !== -1));
  }


  removeChosenMessage(data: any) {
      // alert(data.target.parentElement.value);
      const confirmMessageRemoval = confirm('Are you sure you wish to delete Message ID ' + data.target.parentElement.value + '?');

      if (confirmMessageRemoval === true) {
         this._messageService.deleteMessage(this.provId, data.target.parentElement.value);
        // Need to add code to refresh the display
        // alert('Message has been deleted!');
      }
    }



  // saveNewMessage() {

  //     var re = /&nbsp;/gi;
  //     var str = this.editorValue
  //     var msg = str.replace(re, ' ');

  //     this._messageService.addMessage(this.provId, this.newMessageId, this.newMessageName, msg);

  // }


  updateMessagePlansList(PlanName1, PlanName2, PlanID): void {

    if (this._plansToAddMessage.indexOf(PlanID) === -1) {
          this._plansToAddMessage.push(PlanID);
          this._plansToAddMessageDisplay.push(
            {'PlanName1': PlanName1,'PlanName2': PlanName2,'PlanID': PlanID}
          );
    }

    this.toggleSubmitButton();
}


  RemovePlanFromAssignmentList(planID) {

    const removePlanIndex = this._plansToAddMessage.indexOf(planID);

    if (removePlanIndex > -1) {
        this._plansToAddMessage.splice(removePlanIndex, 1);
        this._plansToAddMessageDisplay.splice(removePlanIndex, 1);
      }

      this.toggleSubmitButton();

  }


  toggleSubmitButton() {
      if (this._plansToAddMessageDisplay.length > 0 && this.messagePosition > 0) {
        (<HTMLFormElement>document.getElementById('AddMessageToPlansBtn')).disabled = false;
      } else {
        (<HTMLFormElement>document.getElementById('AddMessageToPlansBtn')).disabled = true;
    }
  }



  SelectAllPlans() {
      for (let i = 0; i < this.plans.length; i++) {
          this.updateMessagePlansList(this.plans[i].planName1, this.plans[i].planName2, this.plans[i].externalPlanId);
      }
  }

  assignMessageToPlans(): void {

    const confirmAddMessageToPlans = confirm('Are you sure you wish to assign Message ID ' + this.chosenMessageId + ' to the selected plan(s)?');

    if (confirmAddMessageToPlans === true) {
          // alert('Making a new message assignment...');
          this._messageService.planMessageAssignment(this.provId, this.chosenMessageId, this._plansToAddMessage, this.messagePosition);
      } else {
        // this.closeModal();
      }
    }


  closeModal() {
        this.closeEvent.emit(true);
    }

  ngOnDestroy() {
      this.currentAssignMessageCompleteSubscription.unsubscribe();
      this.currentPlansSubscription.unsubscribe();
  }


}
