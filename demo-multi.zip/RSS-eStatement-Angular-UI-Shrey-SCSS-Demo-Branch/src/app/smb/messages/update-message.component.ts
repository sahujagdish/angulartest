import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { Message } from '../shared/message';
import { MessageService } from './message.service';
import { AppcacheService } from '../shared/services/appcache.service';
import { Subscription } from 'rxjs';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';
import { SpinnerService } from '../shared/services/spinner-service.service';

@Component({
  selector: 'app-update-message',
  templateUrl: './update-message.component.html',
  styleUrls: ['./update-message.component.css']
})
export class UpdateMessageComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  // provId = environment.providerId;
  provId: any;
  errorMessage: string;
  messages: Message[] = [];
  EditMessage: string = '';
  EditMessageId: string = '';
  EditMessageName: string = '';
  clientId: number;
  editorValue: string = '';
  fullPage: false;
  CkeditorConfig = {};
  uneditedOriginalMessage: string;
  newMessageId: string = '';
  newMessageName: string = '';
  currentUpdateMessageCompleteSubscription: Subscription;


  constructor(private _messageService: MessageService, _appCacheService: AppcacheService, private _myEventsService: MyEventsService, private spinnerService: SpinnerService) {

      this.provId = _appCacheService.getAppCache().providerId;

      this.CkeditorConfig = {
        height: 400,
        disableNativeSpellChecker: false,
        allowedContent: true,
        disableAutoInline: true,
        //extraPlugins: 'sourcedialog',
        // removePlugins: 'sourcearea',
        toolbar: [
            { name: 'editing', groups: ['find', 'selection'], items: ['Find', 'Replace', '-', 'SelectAll', '-'] },
            { name: 'basicstyles', groups: ['basicstyles', 'cleanup'], items: ['Bold', 'Italic', 'Underline', '-', 'RemoveFormat'] }
        ],
        font_names: 'Arial/Aria'

    };

    }



    ngOnInit(): void {
      // (<HTMLFormElement>document.getElementById('SaveUpdatedMsgButton')).disabled = true;
      // (<HTMLFormElement>document.getElementById('SaveUpdatedMsgButton')).style.color = '#C7C2C2';

       // setup subscription for UploadComplete event. When true emit close event for modal or do something else if false
        this.currentUpdateMessageCompleteSubscription = this._myEventsService.currentMessageUpdateComplete.subscribe(
           (updateMessageComplete: MyEvent) => {
               if (updateMessageComplete.success) {
                   window.alert(updateMessageComplete.message);
                   this.closeEvent.emit(true);
               } else {
                   window.alert(updateMessageComplete.message);
               }
           }
        );

        // this._messageService.getProviderMessage(this.provId, this.componentData)
        //   .subscribe(
        //     resp => {
        //       const status = resp.status;
        //       console.log('Status Code: ' + status);
        //       this.message = resp.body;
        //     }
        //     ,
        //     error => this.errorMessage = <any>error
        //   );
        this.spinnerService.show();
        this._messageService.getProviderMessage(this.provId, this.componentData)
        .subscribe(
          resp => {
            console.log(resp);
            const status = resp.status;
            console.log('Status Code: ' + status);
            this.EditMessage = resp.body.originalMessage;
            this.EditMessageId = resp.body.messageId;
            this.EditMessageName = resp.body.messageName;
            this.spinnerService.hide();
          }
          ,
          error => this.errorMessage = <any>error
        );

   }



   saveEditedMessage() {

        var re = /&nbsp;/gi;
        // var str = data.controls.editor1.value;
        var str = this.EditMessage;
        var msg = str.replace(re, ' ');
        this._messageService.updateMessage(this.provId, this.EditMessageId, this.EditMessageName.trim(), msg);
    }


    toggleNewSaveButton() {
      // Put code here to enable/disable Save button

    }


    onSubmit(editMessageForm) {
        console.log('editeMessageForm: ' + editMessageForm);
        alert('Form submitted!');
    }

    closeModal() {
          this.closeEvent.emit(true);
      }

    ngOnDestroy() {
        this.currentUpdateMessageCompleteSubscription.unsubscribe();
    }


 }

