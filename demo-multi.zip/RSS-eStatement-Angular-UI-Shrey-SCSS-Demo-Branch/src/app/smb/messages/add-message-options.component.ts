import { Component, OnInit, Input, EventEmitter, Output, OnDestroy} from '@angular/core';
import { AppcacheService } from '../shared/services/appcache.service';
import { MyEvent } from '../shared/model/myevent.model';
import { MyEventsService } from '../shared/services/events/myevents.service';

@Component({
  selector: 'app-add-message-options',
  templateUrl: './add-message-options.component.html',
  styleUrls: ['./add-message-options.component.css']
})

export class AddMessageOptionsComponent implements OnInit, OnDestroy {
  @Input() componentData: string;
  @Input() componentData2: string;
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

  private appCache;
  provId: any;
  errorMessage: string;
  ExternalPlanID: string = '';
  MessageLocation: string = '';




  constructor( _appCacheService: AppcacheService, private _myEventsService: MyEventsService) {
    this.provId = _appCacheService.getAppCache().providerId;
  }

  ngOnInit() {
    this.ExternalPlanID = this.componentData;
    this.MessageLocation = this.componentData2;
  }


  closeModal() {
    this.closeEvent.emit(true);
  }

  ngOnDestroy() {

  }

}
