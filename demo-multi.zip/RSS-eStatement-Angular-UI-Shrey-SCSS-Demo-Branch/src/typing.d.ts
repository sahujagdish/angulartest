declare var System: any;
declare var require: any;