export = ckeditor;
declare const ckeditor: any;
