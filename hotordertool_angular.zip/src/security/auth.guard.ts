import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AuthenticateService } from 'src/services/authenticate.service';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate {
  token: any;
  //loading = false;
  url = environment.hostName;
  appName = environment.appName;
  userSession: any;
  //alertInfo: boolean = false;
  hostURL = environment.hostName + '/oauth2/authorize/'+ environment.appName +'?response_type=code&redirect_uri='
  redirectURL: string = '';
  redirectHost: string = '';
  dashboardURL: any;
  
  constructor(public router: Router, private route: ActivatedRoute) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const token = localStorage.getItem('TokenInfo');
        if (token) {
            return true;
        } 
        // else{
        //   this.route.queryParamMap.subscribe((params) => {
        //     this.token = { ...params };
        //     this.redirectHost = window.location.protocol + "//" + window.location.host;
        //     this.redirectURL = this.hostURL + this.redirectHost + '/customlogin/login&scope=oauth';
        //    // this.getAccessToken();


        //    const body = new HttpParams().set('code', this.token.params['code']).set('grant_type', 'authorization_code').set('redirect_uri', this.redirectHost + '/customlogin/login');
        //    this.dashboardService.getUserSessionInfo(body).subscribe((res) => {
        //        console.log(res);
        //      //  this.loading = false;
        //        if (res['access_token']) {
        //      //      this.loading = true;
        //            this.userSession = res;
        //            localStorage.setItem('TokenInfo', JSON.stringify(this.userSession));
        //            this.router.navigate(['/']);
        //        } else {
        //      //      this.loading = false;
        //      //      this.alertInfo = true;
        //            localStorage.clear();
        //        }
        //    }, (error) => {
        //      //  this.loading = false;

        //      //  this.alertInfo = true;
        //        localStorage.clear();
        //    })
        // });

        // }
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        //this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
       // return false;
    }
 
}