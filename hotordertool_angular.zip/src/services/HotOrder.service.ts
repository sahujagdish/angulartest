import { Injectable, Inject } from '@angular/core';
import { environment } from '../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class HotOrderService {
  baseUrl: any;
  respo: any;
  serviceData: any;
  options: any = {
      headers: new HttpHeaders().set('Content-Type', 'application/json')
          .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
          .set('Access-Control-Allow-Origin', '*')
          .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS,PUT,DELETE'),
  };

constructor(private httpClient: HttpClient) { // @Inject(root) env:any, , 
    this.baseUrl = environment.API_URL;
}

  public getMillsList(param:any) {
   //  return this.httpClient.post(this.baseUrl + "/GetMillsDetail", param, this.options);
    return this.httpClient.post(this.baseUrl + "/GetMillsDetail", param, this.options);
  }

  public getMills() {  
    return this.httpClient.get(this.baseUrl + "/Mills", this.options);
  }

  // public getMill(id: number) {
  //   return this.httpClient.get(this.baseUrl + "/Mill/" + id);
  // }

  public InsertUpdateMill(MillsModel) {   
    return this.httpClient.post(this.baseUrl  + "/InsertUpdateMill", MillsModel, this.options);
  }

 public DeleteMill(id: number){
    return this.httpClient.post(this.baseUrl  + "/DeleteMill/" + id,"", this.options);
  }

  public GetOrderTypesDetail(param:any) {  
    return this.httpClient.post(this.baseUrl  + "/OrderTypesDetail", param, this.options);
  }

  public GetOrderTypes() {  
    return this.httpClient.get(this.baseUrl + "/OrderTypes", this.options);
  }

  public GetOrderType(id: number) {
    return this.httpClient.get(this.baseUrl + "/OrderType/" + id, this.options);
  }

  public InsertUpdateOrderType(OrderTypeModel) {   
    return this.httpClient.post(this.baseUrl + "/InsertUpdateOrderType", OrderTypeModel, this.options);
  }

 public DeleteOrderType(id: number){
    return this.httpClient.post(this.baseUrl + "/DeleteOrderType/" + id,"", this.options);
 }

 public getMailingList(param:any) {  
  return this.httpClient.post(this.baseUrl + "/MailingList", param, this.options);
}

public getMailing(id: number) {
  return this.httpClient.get(this.baseUrl + "/MailingList/" + id, this.options);
}

public InsertUpdateMailingList(MillsModel) {   
  return this.httpClient.post(this.baseUrl + "/InsertUpdateMailingList", MillsModel, this.options);
}

public DeleteMailingList(id: number){
  return this.httpClient.post(this.baseUrl + "/DeleteMailingList/" + id,"", this.options);
}

public GetCustomerServiceEmails() {
  return this.httpClient.get(this.baseUrl + "/CustomerServiceEmails", this.options);
}

public GetExceptionReason() {
  return this.httpClient.get(this.baseUrl + "/ExceptionReason", this.options);
}

public GetExceptionDetail(id: number){
  return this.httpClient.get(this.baseUrl + "/ExceptionDetail/" + id, this.options);
}

public GetExceptionDetailList(exceptionModel){
  return this.httpClient.post(this.baseUrl + "/ExceptionDetailList", exceptionModel, this.options);
}

public ExportHotOrders1(ids: any){
  let option: any = {
    headers: new HttpHeaders().set('Content-Type', 'application/json')
        .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
        .set('Access-Control-Allow-Origin', '*')
        .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS,PUT,DELETE')
        .set('responseType', 'blob'),
    };
  return this.httpClient.get(this.baseUrl + "/Export?exceptionids="+ids, option);
}

public ExportHotOrders(ids:any){
  let option: any = {
    headers: new HttpHeaders().set('Content-Type', 'application/json')
        .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
        .set('Access-Control-Allow-Origin', '*')
        .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS,PUT,DELETE'),
        responseType: 'blob'
       
    };
  return this.httpClient.get(this.baseUrl + "/Export?exceptionids="+ids, option)
}

public DeleteHotOrders(id: number){
  return this.httpClient.post(this.baseUrl + "/DeleteException/" + id,"", this.options);
}

public InsertUpdateExceptionDetail(orderExceptionModel){
  return this.httpClient.post(this.baseUrl + "/InsertUpdateExceptionDetail", orderExceptionModel, this.options);
}

public getOtherConfig() {
  return this.httpClient.get(this.baseUrl + "/OtherConfig", this.options);  
}

public EnableOtherConfig(isEnable){
  return this.httpClient.post(this.baseUrl + "/EnableOtherConfig", isEnable, this.options);
}
}


