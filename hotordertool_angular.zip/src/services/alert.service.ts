import { Injectable } from "@angular/core";
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AlertService {

    constructor(private toastr: ToastrService) {}

    public showSuccess(message: any, success: any = "Success") {
        this.toastr.success(message, success,{ closeButton: true, timeOut: 3000, progressBar: true, enableHtml: true });
    }

    public showError(message: any) {
      this.toastr.error(message, 'Error',{ easing:'ease-in', timeOut: 3000, closeButton: true,  progressBar: true, enableHtml: true });
    }

    public showWarning(message: any) {
      this.toastr.warning(message, 'Warn',{ closeButton: true, timeOut: 3000, progressBar: true, enableHtml: true });
    }

    public information(message: any) {
      this.toastr.info(message, 'Information',{ closeButton: true,  timeOut: 3000, progressBar: true, enableHtml: true });
    }
}