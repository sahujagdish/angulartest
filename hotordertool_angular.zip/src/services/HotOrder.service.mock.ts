import { Injectable, Inject } from '@angular/core';
import { DataService } from './data.service';
import { environment } from '../environments/environment';
import { observable, EMPTY, of } from 'rxjs';

// export class Mills {

// }

@Injectable()
export class HotOrderServiceMock {
  baseUrl: any;

  constructor() { // @Inject(root) env:any
    this.baseUrl = environment.API_URL;
  }


  

  public getMillsList(param:any) {
    let mills = "{\"PagedDataModel\":[{\"MillId\":9,\"Millnumber\":\"aa\",\"Millname\":\"aa\",\"Createdby\":\"jagdish\",\"Createddate\":\"2020-09-06T09:09:47.753\",\"Modifiedby\":\"jagdish\",\"Modifieddate\":\"2020-09-06T09:09:47.753\"},{\"MillId\":8,\"Millnumber\":\"9991\",\"Millname\":\"ECO1\",\"Createdby\":\"jagdish\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"jagdish\",\"Modifieddate\":\"2020-09-06T09:09:25.717\"},{\"MillId\":1,\"Millnumber\":\"0241\",\"Millname\":\"Texarkana\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"},{\"MillId\":2,\"Millnumber\":\"0525\",\"Millname\":\"Prosperity\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"},{\"MillId\":3,\"Millnumber\":\"0660\",\"Millname\":\"Augusta\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"}],\"page\":{\"TotalCount\":5,\"PageSelected\":0,\"PageSize\":10}}";
    return of(mills); //this.dataService.post(this.baseUrl + "/GetMillsDetail", param);
  }

  public getMills() {  
    return of();  //this.dataService.get(this.baseUrl + "/Mills");
  }

  public getMill(id: number) {
    return of();  //this.dataService.get(this.baseUrl + "/Mill/" + id);
  }

  public InsertUpdateMill(MillsModel) {   
    return of();  //this.dataService.post(this.baseUrl  + "/InsertUpdateMill", MillsModel);
  }

 public DeleteMill(id: number){
    return of();  //this.dataService.post(this.baseUrl  + "/DeleteMill/" + id,"");
  }

  public GetOrderTypesDetail(param:any) {  
    return of();  //this.dataService.post(this.baseUrl  + "/OrderTypesDetail", param);
  }

  public GetOrderTypes() {  
    return of();  //this.dataService.get(this.baseUrl + "/OrderTypes");
  }

  public GetOrderType(id: number) {
    return of();  //this.dataService.get(this.baseUrl + "/OrderType/" + id);
  }

  public InsertUpdateOrderType(OrderTypeModel) {   
    return of();  //this.dataService.post(this.baseUrl + "/InsertUpdateOrderType", OrderTypeModel);
  }

 public DeleteOrderType(id: number){
    return of();  //this.dataService.post(this.baseUrl + "/DeleteOrderType/" + id,"");
 }

 public getMailingList(param:any) {  
  return of();  //this.dataService.post(this.baseUrl + "/MailingList", param);
}

public getMailing(id: number) {
  return of();  //this.dataService.get(this.baseUrl + "/MailingList/" + id);
}

public InsertUpdateMailingList(MillsModel) {   
  return of();  //this.dataService.post(this.baseUrl + "/InsertUpdateMailingList", MillsModel);
}

public DeleteMailingList(id: number){
  return of();  //this.dataService.post(this.baseUrl + "/DeleteMailingList/" + id,"");
}

public GetCustomerServiceEmails() {
  return of();  //this.dataService.get(this.baseUrl + "/CustomerServiceEmails");
}

public GetExceptionReason() {
  return of();  //this.dataService.get(this.baseUrl + "/ExceptionReason");
}

public GetExceptionDetail(id: number){
  return of();  //this.dataService.get(this.baseUrl + "/ExceptionDetail/" + id);
}

public GetExceptionDetailList(exceptionModel){
  return of();  //this.dataService.post(this.baseUrl + "/ExceptionDetailList/", exceptionModel);
}

public ExportHotOrders(ids: any[]){
  return of();  //this.dataService.post(this.baseUrl + "/Export",ids);
}

public DeleteHotOrders(id: number){
  return of();  //this.dataService.post(this.baseUrl + "/DeleteException/" + id,"");
}

public InsertUpdateExceptionDetail(orderExceptionModel){
  return of();  //this.dataService.post(this.baseUrl + "/InsertUpdateExceptionDetail", orderExceptionModel);
}

public getOtherConfig() {
  return of();  //this.dataService.get(this.baseUrl + "/OtherConfig");  
}

public EnableOtherConfig(isEnable){
  return of();  //this.dataService.post(this.baseUrl + "/EnableOtherConfig", isEnable);
}

}


