import { Injectable, Inject } from "@angular/core";
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { StorageService } from '../services/storage.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class DataService {

    respo: any;
    serviceData: any;
    baseUrl: string;
    options: any = {
        headers: new HttpHeaders().set('Content-Type', 'application/json')
            .set('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization')
            .set('Access-Control-Allow-Origin', '*')
            .set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS,PUT,DELETE'),
    };
    
    constructor(private SpinnerService: NgxSpinnerService, private httpClient: HttpClient) {
       
    }

    get(endpoint): Observable<any> {
        return this.httpClient.get(endpoint, this.options)
        // .pipe(
        //     catchError(
        //         err => { 
        //             console.log(err);
        //             return of(null);
        //         }
        //     ));
    }

    post(endpoint, body): Observable<any> { 
        return this.httpClient.post(endpoint, body, this.options)
            // .pipe(
            //     catchError(err => {
            //         setTimeout(() => { this.SpinnerService.hide()},500);  
            //         this.router.navigate(['/error']);
            //         return of(null);
            //     }))
    };

    async postpromise(endpoint, body) {
        let resp: any;

        let promise = await new Promise((resolve, reject) => {
            this.httpClient.post(endpoint, body,)
                .toPromise()
                .then(res => { // Success
                    resp = res
                    console.log(res);
                    resolve();
                }) ;
        });
        return resp;
    }
}
