import { Injectable, isDevMode } from '@angular/core';
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
} from '@angular/common/http';
import { environment } from '../environments/environment';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class AuthenticateService {
  private options: any;
  private headers: any;
  url = environment.hostName;
  appName = environment.appName;

  constructor(private httpClient: HttpClient) {
    if (localStorage.getItem('Authorization')) {
      this.headers = new Headers({
        Authorization: 'Bearer ' + localStorage.getItem('Authorization'),
        'Content-Type': 'application/json',
        'Cache-control': 'no-cache,no-store',
        Expires: '0',
        Pragma: 'no-cache',
      });
    }

    this.options = new HttpHeaders({
      headers: this.headers,
    });
  }

  getClientDetails(): Observable<any> {
    return this.httpClient
      .get('https://ipapi.co/json')
      .pipe(catchError(this.handleError));
  }

  getUserSessionInfo(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    return this.httpClient.post(this.url + '/oauth2/token/' + this.appName, data.toString(), { headers })
      .pipe(catchError(this.handleError));
  }

  getUserInfo(): Observable<any> {
    return this.httpClient.get(this.url + '/Security/WhoAmI')
      .pipe(catchError(this.handleError));
  }

  postlogout(): Observable<any> {
    let data = {}
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'X-CENTRIFY-NATIVE-CLIENT': 'true',
      'X-IDAP-NATIVE-CLIENT': 'true'
    });
    return this.httpClient.post(this.url + '/Security/Logout' ,data , { headers })
      .pipe(catchError(this.handleError));
  }

  public get getSessionToken() {
    const data = JSON.parse(localStorage.getItem('TokenInfo'));
    return data;
  }

  handleError(error) {
    let errorMessage = {};
    if (error instanceof HttpErrorResponse) {
      // Get client-side error
      errorMessage = error.error;
    } else {
      // Get server-side error
      errorMessage = error;
    }
    return throwError(errorMessage);
  }
}
