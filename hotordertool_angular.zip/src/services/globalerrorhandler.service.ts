import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgZone } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalErrorHandlerService implements ErrorHandler {
  constructor(private SpinnerService: NgxSpinnerService, private injector: Injector, private zone: NgZone) {
   
  }

  handleError(error: any) {
   const router = this.injector.get(Router);
   
    this.SpinnerService.hide();
    debugger;
    console.error("Error occured: " + error.error);
    if (error instanceof HttpErrorResponse) {
      if(error.status == 401) {
        this.zone.run(() => router.navigate(["/accessdenied"]))
      } else {      
        this.zone.run(() => router.navigate(["/error"]))
      }
      console.error("HTTP Status code: " + error.status);
      console.error("HTTP Response body: " + error.message);
    } else {
      console.log("Error occured: " + error.message);
    }
  }
}