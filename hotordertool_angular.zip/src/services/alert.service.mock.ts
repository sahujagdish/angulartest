import { Injectable } from "@angular/core";
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class AlertServiceMock {

    constructor(private toastr: ToastrService) {}

    public showSuccess(message: any, success: any = "Success") {
        
    }

    public showError(message: any) {
      
    }

    public showWarning(message: any) {
      
    }

    public information(message: any) {
      
    }
}