import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticateService } from './authenticate.service';

@Injectable()
export class CustomAuthInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticateService) { }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const tokenInfo = this.authenticationService.getSessionToken;
        if (tokenInfo && tokenInfo.access_token) {
            request = request.clone({
                setHeaders: { 
                    Authorization: `${tokenInfo.token_type} ${tokenInfo.access_token}`
                }
            });
        }
        return next.handle(request);
    }    
}



// import { Injectable } from '@angular/core';
// import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
// import { Observable } from "rxjs";
// import { StorageService } from './storage.service';
// import { Router, ActivatedRoute } from '@angular/router';

// @Injectable({providedIn: 'root'})
// export class AuthInterceptor //implements HttpInterceptor 
// {
//   constructor(private storage: StorageService, private activeRoute: ActivatedRoute) {
//   }
//   intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
//     const bareartoken = this.storage.$SessionStorageGet('globalAuth');
//     if (this.storage.$SessionStorageGet('globalAuth') == '') {      
//       const token = 'get token from Idaptave';      
//       this.storage.$SessionStorageSet('globalAuth',token); 
//       req = req.clone({
//         setHeaders: {
//           Authorization: `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
//     } else {
//       req = req.clone({
//         setHeaders: {
//           Authorization: `Bearer ${bareartoken.Token}`,
//           'Content-Type': 'application/json'
//         }
//       });
//     }
//     return next.handle(req);
//   }
// }
