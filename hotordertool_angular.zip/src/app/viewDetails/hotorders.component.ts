import { OnInit, Component, ElementRef, ViewChild, Renderer2, ViewChildren } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { environment } from '../../environments/environment';
import { HotOrderService } from '../../services/HotOrder.service';
import { NgxSpinnerService } from "ngx-spinner";
import { saveAs as importedSaveAs } from "file-saver";

@Component({
    selector: 'hotorders',
    templateUrl: './hotorders.component.html'
})

export class hotordersComponent  implements OnInit {
    items: any;    
    private route: ActivatedRoute;
    reverse: boolean = false;
    selectexception = [];
    isAllSelected:boolean = false;
    @ViewChildren('chkrowSelect') chkrowSelect: ElementRef;
    @ViewChild('chkSelectAll') chkSelectAll: ElementRef;
    
    config = {
        id: 'hotorders',
        itemsPerPage: environment.pagination.pagesize,
        currentPage: 1,
        totalItems: 0,
        pagerowcount:0
    };
    

    param = environment.pagination;    
    constructor( private renderer: Renderer2, private SpinnerService: NgxSpinnerService, private alertService : AlertService,  private storage: StorageService, private _HotOrderService: HotOrderService, private activerouter: ActivatedRoute) {

    }

    allchecked($event){ 
        this.selectexception = [];
       
        for (var i = 0; i <  this.items.length; i++) {
            this.items[i].isSelected = this.isAllSelected;
            this.selectexception.push(this.items[i].Id);      
        } 
        
        if(this.isAllSelected == false){
            this.selectexception = [];
        }
    }

    itemchecked($event:any, id:number){
        if($event.currentTarget.checked == true){
            this.selectexception.push(id);
        } else {
            this.isAllSelected = false;
            const index = this.selectexception.indexOf(id);
            if (index > -1) {
                this.selectexception.splice(index, 1);
            }
        }

        if(this.items.length == this.selectexception.length){
            this.isAllSelected = true;
        }
        console.log(this.selectexception);
    }

    SortOder(sortBy){
        if (this.param.SortOrder === "ASC") {
          this.reverse = !this.reverse;
          this.param.SortOrder = "DESC"
        } else{
          this.param.SortOrder = "ASC"
        }
        this.param.SortColumnName = sortBy;
        this.GetHotOrder();
    }

    pageChanged(event){
        this.config.currentPage = event;
        this.param.PageSelected = event;
        this.GetHotOrder();
        this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
        this.config.pagerowcount  = this.config.pagerowcount > this.config.totalItems ? this.config.totalItems : this.config.pagerowcount;
    }
    // export(){          
    //         if(this.selectexception.length == 0){
    //             this.alertService.showError("Please select atleast one SOLI to export");
    //             return;
    //         }
    //     var selectedException = this.selectexception.join(',');
    //     var url = environment.API_URL + "/Export?exceptionids=" + selectedException;
    //     window.open(url, "_blank");
    // }

    // export(){          
    //     if(this.selectexception.length == 0){
    //         this.alertService.showError("Please select atleast one SOLI to export");
    //         return;
    //     }
    //     var selectedException = this.selectexception.join(',');       

    //     var url = environment.API_URL + "/Export?exceptionids=" + selectedException;
    //     window.open(url, "_blank");
    // }

    export(){
        debugger;
        this._HotOrderService.ExportHotOrders(this.selectexception).subscribe((data:any) => {
            const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            // const url= window.URL.createObjectURL(blob);
            // window.open(url);

            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.setAttribute('download', "HotOrderTool.xlsx");
            document.body.appendChild(link);    
            link.click();
            document.body.removeChild(link);

           // importedSaveAs(blob, "HootOrderTool.xlsx");
        }) ;
    } 

    GetHotOrder() {
        this.SpinnerService.show();  
        this._HotOrderService.GetExceptionDetailList(this.param).subscribe((data: any) => {
          this.items = data.PagedDataModel;      
          this.config.totalItems = data.page.TotalCount;
          setTimeout(() => { this.SpinnerService.hide()},500);  
       });
    }
    ngOnInit(){
        this.param.SortColumnName = "Createddate";
        this.GetHotOrder();
        this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
    }
}
