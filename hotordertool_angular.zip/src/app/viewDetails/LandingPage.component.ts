import { HttpParams } from '@angular/common/http';
import { OnInit, Component, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
@Component({
    selector: 'Landing',
    templateUrl: './LandingPage.component.html'
})

export class LandingComponent {
   
}

