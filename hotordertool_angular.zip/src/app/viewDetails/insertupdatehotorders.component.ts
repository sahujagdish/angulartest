import { OnInit, AfterViewInit, OnChanges, Component, Input, Output, EventEmitter, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError, debounce } from 'rxjs/operators';
import { of } from 'rxjs';
import { HotOrderService } from 'src/services/HotOrder.service';
import { ReturnStatement } from '@angular/compiler';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    selector: 'insertupdatehotorders',
    templateUrl: './insertupdatehotorders.component.html'
})

export class insertupdatehotordersComponent implements OnInit, AfterViewInit {

    @ViewChild('salesorder') salesorder: ElementRef;
    @ViewChild('lineitemnumber') lineitem: ElementRef;

    public frmOrdersException: FormGroup;
    public transferSOLIList: FormArray;
    requirerolls: boolean;
    reqmodeshift: boolean;
    public exceptionId: string;
    public isEditable: boolean = false;
    phonepattern = new RegExp("/^[(]\d{3}[)]\d{3}-\d{4}$");
    public desireddeliverydatetime: string;

    constructor(private SpinnerService: NgxSpinnerService, private route: Router, private activatedRoute: ActivatedRoute, private renderer: Renderer2, private fb: FormBuilder, private _HotOrderService: HotOrderService, private alertService: AlertService, private storage: StorageService) {

    }

    ngOnInit() {
        this.SpinnerService.show();
        this.frmOrdersException = this.fb.group({
            salesorder: new FormControl('', [Validators.required, Validators.minLength(1)]),
            lineitemnumber: new FormControl('', [Validators.required, Validators.minLength(1)]),
            desireddeliverydate: new FormControl('', [Validators.required, Validators.minLength(1)]),
            desireddeliverytime: new FormControl('', [Validators.required, Validators.minLength(1)]),
            hotweight: new FormControl('', [Validators.required, Validators.minLength(1)]),
            exceptionreason: new FormControl('', [Validators.required, Validators.minLength(1)]),
            customerserviceemail: new FormControl('', [Validators.required, Validators.minLength(1)]),
            afterhoursreceiver: new FormControl('', [Validators.required, Validators.minLength(1)]),
            afterhoursphone: new FormControl('', [Validators.required]), // Validators.pattern(this.phonepattern)
            requirerolls: new FormControl(''),
            transferSOLI: this.fb.array([this.AddionalTransferSOLI()]),
            reqmodeshift: new FormControl(''),
            modeshift: new FormControl(''),
            remainingbalanceshiftmode: new FormControl(''),
            requestcomments: new FormControl('')
        });

        this.transferSOLIList = this.frmOrdersException.get('transferSOLI') as FormArray;

        if (this.activatedRoute.params["value"].id == 0) {
            this.isEditable = false;
            this.exceptionId = this.activatedRoute.params["value"].id;
        } else {
            this.isEditable = true;
            this.exceptionId = this.activatedRoute.params["value"].id;
            this.GetExceptionDetail(parseInt(this.exceptionId));
        }
        this.GetExceptionReason();
        this.GetCustomerServiceEmails();
        setTimeout(() => { this.SpinnerService.hide() }, 500);
    }

    ngAfterViewInit() {
        if (this.activatedRoute.params["value"].id == 0) {
            this.renderer.removeAttribute(this.salesorder.nativeElement, 'disabled');
            this.renderer.removeAttribute(this.lineitem.nativeElement, 'disabled');
        } else {
            this.renderer.setAttribute(this.salesorder.nativeElement, 'disabled', 'disabled');
            this.renderer.setAttribute(this.lineitem.nativeElement, 'disabled', 'disabled');
        }
    }

    Cancel() {
        this.route.navigateByUrl("/hotorders");
    }

    AddionalTransferSOLI(): FormGroup {
        return this.fb.group({
            transfersalesorder: ['', Validators.compose([Validators.required])],
            transferlineitem: ['', Validators.compose([Validators.required])]
        });
    }

    AddSOLI() {
        this.transferSOLIList.push(this.AddionalTransferSOLI());
    }

    RemoveSOLI(index) {
        this.transferSOLIList.removeAt(index);
    }

    exceptionDetails: any[];
    GetExceptionDetail(id: number) {
        this._HotOrderService.GetExceptionDetail(id).subscribe((data: any) => {
            this.requirerolls = data.Rollstransferfromanothersoli;
            this.reqmodeshift = data.Modeshiftrequired;
            this.transferSOLIList.removeAt(0);
            this.exceptionDetails = data.Exceptiondetails;
            var transsoliarr = [];
            data.TransferSoli.forEach(item => {
                if (!transsoliarr.some(x => x.Salesordernumber == item.Salesordernumber && x.Lineitemnumber == item.Lineitemnumber)) {
                    transsoliarr.push({ Salesordernumber: item.Salesordernumber, Lineitemnumber: item.Lineitemnumber });
                }
            });
            if (transsoliarr.length > 0) {
                transsoliarr.forEach(item => {
                    let fg = this.fb.group({
                        transfersalesorder: [item.Salesordernumber, Validators.compose([Validators.required])],
                        transferlineitem: [item.Lineitemnumber, Validators.compose([Validators.required])]
                    });

                    // this.frmOrdersException.setValue({transferSOLI: fg});
                    this.transferSOLIList.push(fg);
                });
            } else {
                this.transferSOLIList.push(this.AddionalTransferSOLI());
            }

            this.desireddeliverydatetime = this.formatDate(data.Desireddeliverydatetime);

            this.frmOrdersException.patchValue({
                salesorder: data.Salesordernumber,
                lineitemnumber: data.Lineitemnumber,
                desireddeliverydate: this.formatDate(data.Desireddeliverydatetime),
                desireddeliverytime: this.formatTime(data.Desireddeliverydatetime),
                hotweight: data.Hotweightrollcount,
                exceptionreason: data.Exceptionreasonid,
                customerserviceemail: data.Customerserviceemailid,
                afterhoursreceiver: data.Afterhoursreceivername,
                afterhoursphone: data.Afterhoursreceiverphone,
                requirerolls: data.Rollstransferfromanothersoli,
                reqmodeshift: data.Modeshiftrequired,
                modeshift: data.Shiftedmode,
                remainingbalanceshiftmode: data.Modeforbalance,
                requestcomments: data.Requestcomments
            });

        });
    }


    formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }


    formatTime(date) {
        var d = new Date(date),
            hours = '' + (d.getHours()),
            minute = '' + d.getMinutes();

        if (hours.length < 2)
            hours = '0' + hours;
        if (minute.length < 2)
            minute = '0' + minute;

        return [hours, minute].join(':');
    }

    ExceptionReasonList: any[];
    CustomerServiceList: any[];

    GetExceptionReason() {
        this._HotOrderService.GetExceptionReason().subscribe((data: any) => {
            this.ExceptionReasonList = data;
        });
    }

    GetCustomerServiceEmails() {
        this._HotOrderService.GetCustomerServiceEmails().subscribe((data: any) => {
            this.CustomerServiceList = data;
        });
    }

    DeleteHotOrders(id: number) {
        var meet = confirm("Are you sure. You want to delete the record?");
        if (meet) {
            this._HotOrderService.DeleteHotOrders(id).subscribe((data: any) => {
                if (data === "1") {
                    this.alertService.showSuccess("Record deleted successfully");
                } else {
                    this.alertService.showError("Error while deleteing successfully");
                }
            });
        }
    }

    Validation(frmM: FormGroup) {

        let invalidfield: String = '';

        Object.keys(frmM.controls).forEach((key) => {
            if (frmM.get(key).invalid == true) {
                if (key === "salesorder") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter Sales Order #" + "<br/>";
                    } else {
                        invalidfield += "Please enter Sales Order #" + "<br/>";
                    }
                }
                if (key === "lineitemnumber") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter Line Item #" + "<br/>";
                    } else {
                        invalidfield += "Please enter Line Item #" + "<br/>";
                    }
                }
                if (key === "desireddeliverydate") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter Desired Delivery Date" + "<br/>";
                    } else {
                        invalidfield += "Please enter Desired Delivery Date" + "<br/>";
                    }
                }
                if (key === "desireddeliverytime") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter Desired Delivery Time" + "<br/>";
                    } else {
                        invalidfield += "Please enter Desired Delivery Time" + "<br/>";
                    }
                }
                if (key === "hotweight") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter Hot Weight / Roll Count" + "<br/>";
                    } else {
                        invalidfield += "Please enter Hot Weight / Roll Count" + "<br/>";
                    }
                }
                if (key === "exceptionreason") {
                    if (invalidfield == '') {
                        invalidfield = "Please select Exception Reason" + "<br/>";
                    } else {
                        invalidfield += "Please select Hot Exception Reason" + "<br/>";
                    }
                }
                if (key === "customerserviceemail") {
                    if (invalidfield == '') {
                        invalidfield = "Please select Customer Service Email" + "<br/>";
                    } else {
                        invalidfield += "Please select Customer Service Email" + "<br/>";
                    }
                }
                if (key === "afterhoursreceiver") {
                    if (invalidfield == '') {
                        invalidfield = "Please enter After Hours/Weekend Receiver Name" + "<br/>";
                    } else {
                        invalidfield += "Please enter After Hours/Weekend Receiver Name" + "<br/>";
                    }
                }
                if (key === "afterhoursphone") {
                    if (this.frmOrdersException.get('afterhoursphone').value === '') {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Phone Number" + "<br/>";
                        } else {
                            invalidfield += "Please enter Phone Number" + "<br/>";
                        }
                    }

                    if (this.frmOrdersException.get('afterhoursphone').value !== '') {
                        if (invalidfield == '') {
                            invalidfield = "Please enter Phone Number with (XXX) XXX-XXXX format" + "<br/>";
                        } else {
                            invalidfield += "Please enter Phone Number with (XXX) XXX-XXXX format" + "<br/>";
                        }
                    }
                }
            }

            if (key === 'requirerolls') {
                if (this.frmOrdersException.get('requirerolls').value === true) {
                    var arrSOLI = this.transferSOLIList.value;
                    arrSOLI.forEach((k, index) => {
                        if (k.transfersalesorder == '') {
                            if (invalidfield == '') {
                                invalidfield = `Please enter Transfer sales order ${index + 1}` + "<br/>";
                            } else {
                                invalidfield += `Please enter Transfer sales order ${index + 1}` + "<br/>";
                            }
                        }
                        if (k.transferlineitem == '') {
                            if (invalidfield == '') {
                                invalidfield = `Please enter Transfer Line Item ${index + 1}` + "<br/>";
                            } else {
                                invalidfield += `Please enter Transfer Line Item ${index + 1}` + "<br/>";
                            }
                        }

                    });
                }
            }

            if (key === "reqmodeshift") {
                if (this.frmOrdersException.get('reqmodeshift').value === true) {
                    if (this.frmOrdersException.get('modeshift').value == '') {
                        if (invalidfield == '') {
                            invalidfield = `Please enter Mode` + "<br/>";
                        } else {
                            invalidfield += `Please enter Mode` + "<br/>";
                        }
                    }

                    if (this.frmOrdersException.get('remainingbalanceshiftmode').value == '') {
                        if (invalidfield == '') {
                            invalidfield = `Please enter Mode for remaining balance` + "<br/>";
                        } else {
                            invalidfield += `Please enter Mode for remaining balance` + "<br/>";
                        }
                    }
                }
            }
        });
        if (this.activatedRoute.params["value"].id == 0) {
            if (this.frmOrdersException.get('desireddeliverydate').value != '') {

                var currentDate = this.formatDate(new Date());
                var ddd = this.frmOrdersException.get('desireddeliverydate').value;

                if (new Date(ddd) < new Date(currentDate)) {
                    if (invalidfield == '') {
                        invalidfield = "Desire delivery date cannot be less than current date" + "<br/>";
                    } else {
                        invalidfield += "Desire delivery date cannot be less than current date" + "<br/>";
                    }
                }
            }
        }

        if (this.activatedRoute.params["value"].id != 0) {

            if (this.frmOrdersException.get('desireddeliverydate').value != '') {

                var currentDate = this.formatDate(new Date());
                var ddd = this.frmOrdersException.get('desireddeliverydate').value;

                if (this.formatDate(this.desireddeliverydatetime) != this.formatDate(ddd)) {

                    if (new Date(ddd) < new Date(currentDate)) {
                        if (invalidfield == '') {
                            invalidfield = "Desire delivery date cannot be less than current date" + "<br/>";
                        } else {
                            invalidfield += "Desire delivery date cannot be less than current date" + "<br/>";
                        }
                    }
                }
            }
        }

        if (invalidfield !== '') {
            this.alertService.showError(invalidfield);
        }

        return invalidfield;
    }

    CreateHotOrderException() {

        var isvalid = this.Validation(this.frmOrdersException);
        if (isvalid != '') {
            return;
        }
        var transferSoli = [];

        Object.keys(this.transferSOLIList.value).forEach((key, index) => {
            transferSoli.push({
                VBELN: this.transferSOLIList.value[index].transfersalesorder,
                POSNR: this.transferSOLIList.value[index].transferlineitem
            });
        });

        let orderExceptionModel = {
            "Id": 0,
            "Status": true,
            "Salesordernumber": this.frmOrdersException.get('salesorder').value,
            "Lineitemnumber": this.frmOrdersException.get('lineitemnumber').value,
            "Desireddeliverydatetime": this.frmOrdersException.get('desireddeliverydate').value,
            "Desireddeliverytime": this.frmOrdersException.get('desireddeliverytime').value,
            "Hotweightrollcount": this.frmOrdersException.get('hotweight').value,
            "Exceptionreasonid": this.frmOrdersException.get('exceptionreason').value,
            "Customerserviceemailid": this.frmOrdersException.get('customerserviceemail').value,
            "Afterhoursreceivername": this.frmOrdersException.get('afterhoursreceiver').value,
            "Afterhoursreceiverphone": this.frmOrdersException.get('afterhoursphone').value,
            "Rollstransferfromanothersoli": this.frmOrdersException.get('requirerolls').value == undefined ? false : this.frmOrdersException.get('requirerolls').value,
            "OrderDetailList": transferSoli,
            "Modeshiftrequired": this.frmOrdersException.get('reqmodeshift').value == undefined ? false : this.frmOrdersException.get('reqmodeshift').value,
            "Shiftedmode": this.frmOrdersException.get('modeshift').value,
            "Modeforbalance": this.frmOrdersException.get('remainingbalanceshiftmode').value,
            "Requestcomments": this.frmOrdersException.get('requestcomments').value
            //,"Createdby": "jagdish"
        }

        this.SpinnerService.show();
        let retvalue = this._HotOrderService.InsertUpdateExceptionDetail(orderExceptionModel);
        retvalue.pipe(
            catchError(err => {
                setTimeout(() => { this.SpinnerService.hide() }, 500);
                this.alertService.showError("Error while creating record");
                return of(null);
            })).subscribe((value: any) => {
                setTimeout(() => { this.SpinnerService.hide() }, 500);
                if (value == "salesorderandlineitemnumberexists") {
                    this.alertService.information("An open exception already exists with the same SO# and LI# !!");
                    return;
                }

                if (value == "primaryortransfersolinotpresent") {
                    this.alertService.information("Either primary or transfer SOLI is invalid !!");
                    return;
                }

                if (value == "BAPIError") {
                    this.alertService.information("Webmethod did not returned any record !!");
                    return;
                }
                if (parseInt(value) > 1) {
                    this.alertService.showSuccess("Record created successfully");
                    setTimeout("", 1000);
                    this.route.navigateByUrl("/hotorders");
                }
            })
    }

    UpdateHotOrderException() {
        var isvalid = this.Validation(this.frmOrdersException);
        if (isvalid != '') {
            return;
        }
        var transferSoli = [];

        Object.keys(this.transferSOLIList.value).forEach((key, index) => {
            transferSoli.push({
                VBELN: this.transferSOLIList.value[index].transfersalesorder,
                POSNR: this.transferSOLIList.value[index].transferlineitem
            });
        });

        let orderExceptionModel = {
            "Id": parseInt(this.exceptionId),
            "Status": true,
            "Salesordernumber": this.frmOrdersException.get('salesorder').value,
            "Lineitemnumber": this.frmOrdersException.get('lineitemnumber').value,
            "Desireddeliverydatetime": this.frmOrdersException.get('desireddeliverydate').value,
            "Desireddeliverytime": this.frmOrdersException.get('desireddeliverytime').value,
            "Hotweightrollcount": this.frmOrdersException.get('hotweight').value,
            "Exceptionreasonid": this.frmOrdersException.get('exceptionreason').value,
            "Customerserviceemailid": this.frmOrdersException.get('customerserviceemail').value,
            "Afterhoursreceivername": this.frmOrdersException.get('afterhoursreceiver').value,
            "Afterhoursreceiverphone": this.frmOrdersException.get('afterhoursphone').value,
            "Rollstransferfromanothersoli": this.frmOrdersException.get('requirerolls').value == undefined ? false : this.frmOrdersException.get('requirerolls').value,
            "OrderDetailList": transferSoli,
            "Modeshiftrequired": this.frmOrdersException.get('reqmodeshift').value == undefined ? false : this.frmOrdersException.get('reqmodeshift').value,
            "Shiftedmode": this.frmOrdersException.get('modeshift').value,
            "Modeforbalance": this.frmOrdersException.get('remainingbalanceshiftmode').value,
            "Requestcomments": this.frmOrdersException.get('requestcomments').value
            //,"Modifiedby": "jagdish"
        }

        this.SpinnerService.show();
        let retvalue = this._HotOrderService.InsertUpdateExceptionDetail(orderExceptionModel);

        retvalue.pipe(
            catchError(err => {
                alert("Error while updating record!!!");
                return of(null);
            })).subscribe((value: any) => {
                setTimeout(() => { this.SpinnerService.hide() }, 500);

                if (value == "salesorderandlineitemnumberexists") {
                    this.alertService.information("An open exception already exists with the same SO# and LI# !!");
                    return;
                }

                if (value == "primaryortransfersolinotpresent") {
                    this.alertService.information("Either primary or transfer SOLI is invalid !!");
                    return;
                }

                if (value == "BAPIError") {
                    this.alertService.information("Webmethod did not returned any record !!");
                    return;
                }

                if (parseInt(value) > 1) {
                    this.alertService.showSuccess("Record updated successfully");
                    setTimeout("", 1000);
                    this.route.navigateByUrl("/hotorders");
                }
            })
    }

    DeleteException() {
        var exception = confirm("Are you sure. You want to delete the record?");
        if (exception) {
            this._HotOrderService.DeleteHotOrders(parseInt(this.exceptionId)).subscribe((data: any) => {                
                if (data === 1) {
                    this.alertService.showSuccess("Record deleted successfully");
                    setTimeout("", 1000);
                    this.route.navigateByUrl("/hotorders");
                } else {
                    this.alertService.showError("Error while deleteing successfully");
                }
            });
        }
    }
}