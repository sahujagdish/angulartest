import { Component, OnInit, Input } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

 errormessage: string;

  constructor(private SpinnerService: NgxSpinnerService, private router:Router) {
   }

  ngOnInit() {   
    this.errormessage = " Error accessing the portal. Please contact to admin.";
    this.SpinnerService.hide();
  }

}
