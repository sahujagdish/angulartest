import { Component} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Hot Order Tool';
  // config: any;
  // baseurl: any;
  // loggedIn: boolean;
  // isPreview: boolean;
  // href: any;

  constructor() { }
}
