import { OnInit, OnChanges, Component, Input, Output} from '@angular/core';
import { Router, ActivatedRoute, UrlSegment  } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { AuthService } from '../../security/auth.service'; 
import { StorageService } from '../../services/storage.service'; 
import { BehaviorSubject } from 'rxjs';
import jwt_decode from "jwt-decode";
@Component({   
    selector: 'header',
    templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit, OnChanges{
    username : any;        
    isLoggedIn$: Observable<boolean>;
    groups : any;
    isAdmin:boolean = false;
    isUser:boolean = false;
    hotUser:boolean = false;
    constructor(private router: Router, private activatedRoute: ActivatedRoute, public storage: StorageService, private authService: AuthService) {        
       
        const items = { ...localStorage };
        if(items.TokenInfo != undefined) {
            var clienttoken = jwt_decode(JSON.parse(items.TokenInfo).access_token); 
            console.log(clienttoken);      
            this.username = "Welcome, " + clienttoken["firstname"] + " " + clienttoken["lastname"];
            this.groups = clienttoken["groups"].split(',');
            this.isAdmin = this.groups.indexOf("GPI - HOT- Admin",0) != -1;
            this.isUser = this.groups.indexOf("GPI - HOT- User",0) != -1;
            this.hotUser = this.isAdmin || this.isUser;
            if(!this.hotUser){
                this.router.navigate(['/accessdenied']);
            }
        }   
    }

    onLogout() {
        this.authService.logout();
    }

    ngOnInit() { 
    }   

    ngOnChanges() {   
         
    }
}