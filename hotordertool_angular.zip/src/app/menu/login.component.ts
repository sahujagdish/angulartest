import { HttpParams } from '@angular/common/http';
import { OnInit, Component, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { AuthenticateService } from 'src/services/authenticate.service';
@Component({
    selector: 'login',
    templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit {
token: any;
loading = false;
url = environment.hostName;
appName = environment.appName;
userSession: any;
alertInfo: boolean = false;
hostURL = environment.hostName + '/oauth2/authorize/' + this.appName + '?response_type=code&redirect_uri=';
redirectURL: string = '';
redirectHost: string = '';
dashboardURL: any;
constructor(public router: Router, private zone: NgZone, private route: ActivatedRoute, private authenticateService: AuthenticateService) {  
    this.route.queryParamMap.subscribe((params) => {
        this.token = { ...params };
        this.redirectHost = window.location.protocol + "//" + window.location.host;
        this.redirectURL = this.hostURL + this.redirectHost + '/login&scope=oauth';
        if(this.token.params['code']){
            this.getAccessToken();
        } else {
            window.location.href = this.redirectURL;
        }
    });
}
ngOnInit() {
    this.dashboardURL =  '/'; //this.route.snapshot.queryParams['returnUrl'] ||
  
}

getAccessToken() {
    this.loading = true;
    const body = new HttpParams().set('code', this.token.params['code']).set('grant_type', 'authorization_code').set('redirect_uri', this.redirectHost + '/login');
    this.authenticateService.getUserSessionInfo(body).subscribe((res) => {
        console.log(res);
        this.loading = false;
        if (res['access_token']) {
            this.loading = true;
            this.userSession = res;
            localStorage.setItem('TokenInfo', JSON.stringify(this.userSession));
            this.router.navigate(['/home']);
        } else {
            this.loading = false;
            this.alertInfo = true;
            localStorage.clear();
        }
    }, (error) => {
        console.log(error);
         this.router.navigate(["/error"]);
        this.loading = false;
        this.alertInfo = true;
        localStorage.clear();
    })

}

}