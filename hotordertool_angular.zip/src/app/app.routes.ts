import { NgModule } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';
import { APP_BASE_HREF } from '@angular/common'; 
import { LandingComponent } from './viewDetails/LandingPage.component'; 
import { AuthGuard } from '../security/auth.guard';
//import { MeetingResolver } from '../services/Meetingresolver';
import { hotordersComponent } from './viewDetails/hotorders.component';
import { ErrorComponent } from './error/error.component';
import { insertupdatehotordersComponent } from './viewDetails/insertupdatehotorders.component'; 
import { LogoutComponent } from './menu/logout.component';
import { LoginComponent } from './menu/login.component';
import { homelayoutcomponent } from './layout/homelayout.component';
import { loginlayoutcomponent } from './layout/loginlayout.component';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';

export const appRoutes: Routes = [
{
    path: '',
    component: homelayoutcomponent,
    children:[
    { path: '', redirectTo: 'home', pathMatch: 'full'},
    { path: 'home', component: LandingComponent, canActivate: [AuthGuard]},
    { path: 'hotorders', component: hotordersComponent, canActivate: [AuthGuard]},
    { path: 'insertupdate/:id', component: insertupdatehotordersComponent, canActivate: [AuthGuard]},
    { path: 'administration', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule), canActivate: [AuthGuard]},        
    { path: 'error', component: ErrorComponent, pathMatch:'full'},
    ]
},{
    path: '',
    component: loginlayoutcomponent,
    children:[
        { path: 'login', component: LoginComponent},
        { path: 'logout', component: LogoutComponent},         
        { path: 'accessdenied', component: AccessdeniedComponent}
        
    ]
},
{ path: '**', redirectTo: '' }   
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)], 
    exports: [RouterModule]
})

export class AppRoutingModule {
     
}