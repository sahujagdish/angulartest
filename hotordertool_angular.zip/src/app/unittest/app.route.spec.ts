import { TestBed, async, ComponentFixture, tick, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { environment } from '../../environments/environment';
import { CommonModule, Location } from '@angular/common';
import { AdminRoutingModule } from '../admin/admin.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { AppRoutingModule,appRoutes } from '../app.routes';
import { MillsComponent } from '../admin/mills.component';
import { OrderTypesComponent } from '../admin/ordertypes.component';
import { OtherConfigComponent } from '../admin/otherconfig.component';
import { MailingListComponent } from '../admin/mailinglist.component';
import { hotordersComponent } from '../viewDetails/hotorders.component';
import { HotOrderService } from 'src/services/HotOrder.service';
import { AlertService } from 'src/services/alert.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { StorageService } from 'src/services/storage.service';
import { HotOrderServiceMock } from 'src/services/HotOrder.service.mock';
import { AlertServiceMock } from 'src/services/alert.service.mock';
import { AuthService } from 'src/security/auth.service';
import { AuthGuard } from 'src/security/auth.guard';
import { GlobalErrorHandlerService } from 'src/services/globalerrorhandler.service';
import { ErrorHandler } from '@angular/core';
import { DataService } from 'src/services/data.service';


describe('routing', () => {

let location: Location;
let router: Router;
let fixture;
 
beforeEach(fakeAsync(() => {

    // declaring Mills component 
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,CommonModule
      ],
      declarations: [AppComponent,hotordersComponent,MillsComponent,OrderTypesComponent,OtherConfigComponent,MailingListComponent],
    providers: [AuthService, AuthGuard, DataService,HotOrderServiceMock, AlertService,
        HotOrderService,
      { provide:ErrorHandler, useClass:GlobalErrorHandlerService}]
    });   
    
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    fixture = TestBed.get(AppComponent);
    router.initialNavigation();

  }));

  xit('Navigate "" to /home', () => {    
   router.navigate([""]).then(() => {
        expect(location.path()).toBe("/home");
   });
  });

  xit('Navigate "" to /hotorders', () => {    
    router.navigate(["/hotorders"]).then(() => {
         expect(location.path()).toBe("/hotorders");
    });
   });

});