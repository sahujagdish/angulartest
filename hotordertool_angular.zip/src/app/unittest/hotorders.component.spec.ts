
import { TestBed, async, ComponentFixture, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { HotOrderServiceMock } from '../../services/HotOrder.service.mock';
import { MillsComponent } from '../admin/mills.component';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from '../admin/admin.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { DebugElement, Renderer2 } from '@angular/core';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { LocalStorageService, SessionStorageService } from 'angular-web-storage';
import { AlertServiceMock } from '../../services/alert.service.mock';
import { Observable } from 'rxjs';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { HttpClientModule } from '@angular/common/http';
import { By } from '@angular/platform-browser';
import { element } from 'protractor';
import { hotordersComponent } from '../viewDetails/hotorders.component';

describe('hotordersComponent', () => {

  let component:hotordersComponent;
  let fixture: ComponentFixture<hotordersComponent>;
  let hotOrderService: HotOrderService;
  let alertService: AlertService;
  let toastService: ToastrService;


  beforeEach(async(() => {

    // declaring Mills component 
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AdminRoutingModule,
        CommonModule,
        FormsModule,
        ToastrModule.forRoot(),
        ReactiveFormsModule,
        NgxPaginationModule,
        HttpClientModule
      ],
      declarations: [hotordersComponent],
      providers: [HotOrderService, AlertService, NgxSpinnerService, StorageService]
    }
    );

    // Configuring component with mock services

    TestBed.overrideComponent(
        hotordersComponent,
      {
        set: {
          providers: [{ provide: HotOrderService, useClass: HotOrderServiceMock },
          { provide: AlertService, useClass: AlertServiceMock }]
        }
      }
    );

    // creating component fixture
    fixture = TestBed.createComponent(hotordersComponent);

    // get the component from fixturew
    component = fixture.componentInstance;

    hotOrderService = fixture.debugElement.injector.get(HotOrderService);
    alertService = fixture.debugElement.injector.get(AlertService);
    fixture.autoDetectChanges(true);
  }));

  it('hotordersComponent', () => {    
    expect(component).toBeTruthy;
  });

  it('Hot Order Service injected via componentshould be instace of Hot Order Service Mock', () => {    
    expect(hotOrderService instanceof HotOrderServiceMock);
  });

  it('hot orders title', () => {
      const bannerDe: DebugElement = fixture.debugElement;
      const bannerEl: HTMLElement = bannerDe.nativeElement;
      const p = bannerEl.querySelector('h4');
      console.log(p.textContent);
      fixture.detectChanges();
      expect(p.textContent).toEqual('Hot Orders');
  });

// xit('Add HotOrders', () => {  
//   const btnAddMill = fixture.debugElement.query(By.css(".btn.btn-success.float-right"));
//   let addMill: HTMLElement = btnAddMill.nativeElement;
//   let divAddMill = fixture.debugElement.query(By.css("#CreateNew"));
//   let divMill: HTMLElement = divAddMill.nativeElement;
//   addMill.click();
//   fixture.whenRenderingDone().then(() => {
//    // expect(divMill.className).toBe("collapse show");
//   });  

//   console.log('className ' + divMill.className);
// });

// xit('Get HotOrder list', () => {   
//     component.param = environment.pagination;
//     let out:any;   

//     hotOrderService.GetExceptionDetailList(component.param).subscribe((data: any) => {   
//       out = data;
//       component.items = JSON.parse(data).PagedDataModel;
//       component.config.totalItems = JSON.parse(data).page.TotalCount;     
//     });
//     component.GetHotOrder();
//     //console.log('GetHotOrder: ' +   JSON.parse(out).PagedDataModel);   
//     expect(JSON.parse(out).PagedDataModel).toBeDefined;    
//   });

// xit('hotorder total page count', () => {   
//     component.param = environment.pagination;
//     let txt:any;
//     hotOrderService.GetExceptionDetailList(component.param).subscribe((data: any) => {   
//       txt = data;
//       component.items = JSON.parse(data).PagedDataModel;
//       component.config.totalItems = JSON.parse(data).page.TotalCount;     
//     });
//     component.GetHotOrder();
//    // console.log('total page count: ' +  JSON.parse(txt).page.TotalCount);

//     expect(JSON.parse(txt).page.TotalCount).toEqual(5);
//   });

});
