import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { HotOrderServiceMock } from '../../services/HotOrder.service.mock';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from '../admin/admin.route';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { DebugElement, Renderer2 } from '@angular/core';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { LocalStorageService, SessionStorageService } from 'angular-web-storage';
import { AlertServiceMock } from '../../services/alert.service.mock';
import { By } from 'protractor';
import { MailingListComponent } from '../admin/mailinglist.component';

describe('MailingListComponent', () => {

    let component: MailingListComponent;
    let fixture: ComponentFixture<MailingListComponent>;
    let hotOrderService: HotOrderService;
    let alertService: AlertService;
    let toastService: ToastrService;

    beforeEach(async(() => {

        // declaring Mills component 
        TestBed.configureTestingModule({
            imports: [
                RouterTestingModule,
                AdminRoutingModule,
                CommonModule,
                FormsModule,
                ToastrModule.forRoot(),
                ReactiveFormsModule,
                NgxPaginationModule
            ],
            declarations: [MailingListComponent],
            providers: [HotOrderService, AlertService, NgxSpinnerService, StorageService]
        }
        );
        // Configuring component with mock services

        TestBed.overrideComponent(
            MailingListComponent,
            {
                set: {
                    providers: [{ provide: HotOrderService, useClass: HotOrderServiceMock },
                    { provide: AlertService, useClass: AlertServiceMock }]
                }
            }
        );

        // creating component fixture
        fixture = TestBed.createComponent(MailingListComponent)

        // get the component from fixturew
        component = fixture.componentInstance;

        hotOrderService = fixture.debugElement.injector.get(HotOrderService);
        alertService = fixture.debugElement.injector.get(AlertService);
    }));

    it('Hot Order Service injected via componentshould be instace of Hot Order Service Mock', () => {
        console.log('XXXX -76');
        expect(hotOrderService instanceof HotOrderServiceMock);
    });

    it('Email Configuration', () => {
        const bannerDe: DebugElement = fixture.debugElement;
        const bannerEl: HTMLElement = bannerDe.nativeElement;
        const p = bannerEl.querySelector('h4');
        console.log(p.textContent);
        fixture.detectChanges();
        expect(p.textContent).toEqual('Email Configuration');
    });

    // it('fetch mills list', () => {   
    //   component.param = environment.pagination;
    //   component.GetMills();
    //   hotOrderService.getMillsList(param).subscribe()

    //   expected

    // });

});
