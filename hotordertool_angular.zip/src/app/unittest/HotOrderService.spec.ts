import { TestBed, inject } from '@angular/core/testing';
import { HotOrderService } from '../../services/HotOrder.service';
import { HttpClientModule } from '@angular/common/http';
import { environment } from '../../environments/environment';

import {
    HttpClientTestingModule,
    HttpTestingController
} from "@angular/common/http/testing";
import { Observable, of } from 'rxjs';

describe('HotOrderService', () => {
    let hotOrderService: HotOrderService;
    let httpTestingController: HttpTestingController;    

    beforeEach(() => {   
      TestBed.configureTestingModule({
        imports: [HttpClientTestingModule,HttpClientModule],
        providers: [HotOrderService]
      });      
      httpTestingController = TestBed.get(HttpTestingController);      
    });
    afterEach(() => {
        httpTestingController.verify();
    });

    it('should be created', () => {        
          hotOrderService = TestBed.get(HotOrderService); // Add this
          expect(HotOrderService).toBeTruthy();
    });

    it('should return a collection of mills', () => {    
        let mills = "{\"PagedDataModel\":[{\"MillId\":8,\"Millnumber\":\"9991\",\"Millname\":\"ECO1\",\"Createdby\":\"jagdish\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"jagdish\",\"Modifieddate\":\"2020-09-06T09:09:25.717\"},{\"MillId\":1,\"Millnumber\":\"0241\",\"Millname\":\"Texarkana\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"},{\"MillId\":2,\"Millnumber\":\"0525\",\"Millname\":\"Prosperity\",\"Createdby\":\"NA\\\\Surya.Nandury\",\"Createddate\":\"2020-07-31T00:00:00\",\"Modifiedby\":\"NA\\\\Surya.Nandury\",\"Modifieddate\":\"2020-07-31T00:00:00\"}],\"page\":{\"TotalCount\":5,\"PageSelected\":0,\"PageSize\":10}}";    
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.getMillsList(environment.pagination).subscribe((response:any) => {
            //console.log('response ' +  response);
            expect(mills).toEqual(response); 
        });
        
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/GetMillsDetail";
        expect(controller.request.url).toEqual(url);
        controller.flush(mills);
    });

    it('should return a mills', () => {
        let mills = "[{Id:1,Name:'Tekarna'},{Id:1,Name:'Tekarna1'},{Id:1,Name:'Tekarna2'}]";
       // console.log('response mills ' + JSON.parse(mills));
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.getMills().subscribe((resp:any) => {           
           expect(mills).toEqual(resp); 
        });
        
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/Mills";
        expect(controller.request.url).toEqual(url);
        controller.flush(mills);
    });

   it('delete a mill', () => {
        let returnValue:any = '1';
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.DeleteMill(1).subscribe((response:any) => {
           // console.log('response ' +  response);
           expect(returnValue).toEqual(response);
        });        
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL  + "/DeleteMill/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });         

    it('Insert Update Mill', () => {
        let returnValue:any = '1';
        hotOrderService = TestBed.get(HotOrderService);
        let model:any = {};
        hotOrderService.InsertUpdateMill(model).subscribe((response:any) => {
           // console.log('response ' +  response);
            expect(returnValue).toEqual(response);
        });        
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL  + "/InsertUpdateMill";       
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    }); 

    it('Get OrderTypes Detail', () => {
        let returnValue:any ="[{Id:1, Name:'ZDOM'},{Id:2, Name:'ZDOM'}]";
        hotOrderService = TestBed.get(HotOrderService);
        let model:any = environment.pagination;
        hotOrderService.GetOrderTypesDetail(model).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL  + "/OrderTypesDetail";  
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    }); 

    it('Get Order Types', () => {
        let returnValue:any ="[{Id:1, Name:'ZDOM'}]";
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.GetOrderType(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/OrderType/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('Insert Update OrderType', () => {
        let returnValue:any ="1";
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.InsertUpdateOrderType(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/InsertUpdateOrderType";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('Delete OrderType', () => {
        let returnValue:any ="1";
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.DeleteOrderType(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/DeleteOrderType/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('get Mailing List', () => {
        let returnValue:any ='{"PagedDataModel":[{"Id":1,"MillId":1,"Millnumber":"0241","Millname":"Texarkana","OrdertypeId":3,"Ordertype":"ZEXP","Planningteamdl":"Jagdish.Sahu@graphicpkg.com, Surya.Nandury@graphicpkg.com","Executionteamdl":"Jagdish.Sahu@graphicpkg.com, Surya.Nandury@graphicpkg.com","Createdby":"NA\\Surya.Nandury","Createddate":"2020-05-30T15:00:00","Modifiedby":"NA\\Surya.Nandury","Modifieddate":"2020-05-30T15:00:00"}';
        let params = environment.pagination;
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.getMailingList(params).subscribe((response:any) => {
            expect(returnValue).toEqual(JSON.parse(response));
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/MailingList";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('Insert Update MailingList', () => {
        let returnValue:any ='1';
        let params = environment.pagination;
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.InsertUpdateMailingList(params).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/InsertUpdateMailingList";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('DeleteMailingList', () => {
        let returnValue:any ='1';
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.DeleteMailingList(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/DeleteMailingList/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('CustomerServiceEmails', () => {
        let returnValue:any ='1';
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.GetCustomerServiceEmails().subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/CustomerServiceEmails";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('ExceptionReason', () => {
        let returnValue:any ='[{id:1,"Name":"mills"}]';
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.GetExceptionReason().subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/ExceptionReason";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('ExceptionDetail', () => {
        let returnValue:any ='[{id:1,"Name":"mills"}]';
        hotOrderService = TestBed.get(HotOrderService);
        hotOrderService.GetExceptionDetail(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/ExceptionDetail/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('ExceptionDetailList', () => {
        let returnValue:any ='[{id:1,"Name":"mills"}]';
        hotOrderService = TestBed.get(HotOrderService);
        let exceptionModel = {};
        hotOrderService.GetExceptionDetailList(exceptionModel).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/ExceptionDetailList";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('ExportHotOrders', () => {
        let returnValue:any = {};
        let params:any[] = [1,2];
        hotOrderService = TestBed.get(HotOrderService);
        let exceptionModel = {};
        hotOrderService.ExportHotOrders(params).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL +"/Export";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    }); 

    it('DeleteHotOrders', () => {
        let returnValue:any ='1';
        hotOrderService = TestBed.get(HotOrderService);
        let exceptionModel = {};
        hotOrderService.DeleteHotOrders(1).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/DeleteException/1";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('InsertUpdateExceptionDetail', () => {
        let returnValue:any ='1';
        hotOrderService = TestBed.get(HotOrderService);
        let orderExceptionModel = {};
        hotOrderService.InsertUpdateExceptionDetail(orderExceptionModel).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/InsertUpdateExceptionDetail";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('getOtherConfig', () => {
        let returnValue:any ={};
        hotOrderService = TestBed.get(HotOrderService);       
        hotOrderService.getOtherConfig().subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'GET'});
        let url = environment.API_URL + "/OtherConfig";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });

    it('EnableOtherConfig', () => {
        let returnValue:any ={};
        let param:any = true;
        hotOrderService = TestBed.get(HotOrderService);       
        hotOrderService.EnableOtherConfig(param).subscribe((response:any) => {
            expect(returnValue).toEqual(response);
        });
        let controller = httpTestingController.expectOne({method:'POST'});
        let url = environment.API_URL + "/EnableOtherConfig";
        expect(controller.request.url).toEqual(url);
        controller.flush(returnValue);
    });
});