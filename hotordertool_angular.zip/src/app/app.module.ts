import { BrowserModule} from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule,ErrorHandler, NO_ERRORS_SCHEMA} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app.routes';
import { AppComponent } from './app.component';  
import { HeaderComponent } from './menu/header.component';
import { FooterBarComponent} from './menu/footer.component';
import { HttpClientModule } from '@angular/common/http';
import { AngularWebStorageModule } from 'angular-web-storage'; 
import { ToastrModule } from 'ngx-toastr';
import { AuthGuard } from '../security/auth.guard';
import { AuthService } from '../security/auth.service';
import { AlertService } from '../services/alert.service';
import { GlobalErrorHandlerService } from '../services/globalerrorhandler.service';
import { ErrorComponent } from './error/error.component';
import { hotordersComponent } from './viewDetails/hotorders.component'; 
import { insertupdatehotordersComponent } from './viewDetails/insertupdatehotorders.component'; 
import { DataService } from '../services/data.service';
import { HotOrderService } from '../services/HotOrder.service';
import { CustomAuthInterceptor } from '../services/custom-auth.interceptor';
import { HTTP_INTERCEPTORS} from '@angular/common/http';
import { LandingComponent } from './viewDetails/LandingPage.component';
import { LogoutComponent } from './menu/logout.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { NgxSpinnerModule } from "ngx-spinner";
import { HotOrderServiceMock } from '../services/HotOrder.service.mock';
import { NgxPermissionsModule } from 'ngx-permissions';
import { loginlayoutcomponent } from './layout/loginlayout.component';
import { homelayoutcomponent } from './layout/homelayout.component';
import { LoginComponent } from './menu/login.component';
import jwt_decode from "jwt-decode";
import { AuthenticateService } from 'src/services/authenticate.service';
import { AccessdeniedComponent } from './accessdenied/accessdenied.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterBarComponent,
    ErrorComponent,
    LandingComponent,
    hotordersComponent,
    insertupdatehotordersComponent,
    LogoutComponent,
    loginlayoutcomponent,
    homelayoutcomponent,
    LoginComponent,
    AccessdeniedComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, 
    ReactiveFormsModule,
    AngularWebStorageModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    OrderModule,
    NgxSpinnerModule,
    NgxPermissionsModule.forRoot()
    
  ],
  exports: [   
    FormsModule,
    ReactiveFormsModule,
    NgxPermissionsModule
  ],
  providers: [AuthService, DataService,HotOrderServiceMock, AlertService,
              HotOrderService,AuthenticateService,
              AuthGuard,{ provide: HTTP_INTERCEPTORS, useClass: CustomAuthInterceptor, multi: true },
            { provide:ErrorHandler, useClass:GlobalErrorHandlerService}],
            schemas:[NO_ERRORS_SCHEMA],
              bootstrap: [AppComponent]
})
export class AppModule { 
}
