import { Component } from '@angular/core';

@Component({
    selector: 'app-login-layout',
    template: `<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand logo" href="#"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
        aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button></nav><main role="main" class="flex-shrink-0">
    <div class="container-fluid mt-5 mb-4">
        <router-outlet></router-outlet>
    </div>
    </main>
    <footerBar></footerBar>`
    //<ngx-spinner bdColor="rgba(140,140,140,0.8)" size="medium"></ngx-spinner>
})

export class loginlayoutcomponent {

}
