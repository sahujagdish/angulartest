import {Component} from '@angular/core';

@Component({
    selector:'app-home-layout',
    template:`<header></header><main role="main" class="flex-shrink-0">
    <div class="container-fluid mt-5 mb-4">
        <router-outlet></router-outlet>
    </div>
    </main>
    <footerBar></footerBar>
    <ngx-spinner bdColor="rgba(140,140,140,0.8)" size="medium">
    </ngx-spinner>`
})

export class homelayoutcomponent{

}