import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MillsComponent } from './mills.component';
import { OrderTypesComponent } from './ordertypes.component';
import { MailingListComponent } from './mailinglist.component';
import { ErrorComponent } from '../../app/error/error.component';
import { OtherConfigComponent } from '../../app/admin/otherconfig.component';
export const adminRoutes: Routes = [
    {
        path:'', children:[
            {path:'mills', component: MillsComponent},
            {path: 'ordertypes', component: OrderTypesComponent},
            {path: 'mailinglist', component: MailingListComponent},
            {path: 'otherconfig', component: OtherConfigComponent},
            { path: 'error', component: ErrorComponent},
        ]
    } 
];

@NgModule({
    imports: [RouterModule.forChild(adminRoutes)],
    exports: [RouterModule]
})
export class AdminRoutingModule {}