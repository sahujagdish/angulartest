import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { AdminRoutingModule } from './admin.route';
import { OrderTypesComponent } from './ordertypes.component';
import { MillsComponent } from './mills.component';
import { MailingListComponent } from './mailinglist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule} from 'ngx-pagination';
import { OtherConfigComponent } from '../../app/admin/otherconfig.component';
@NgModule({
  imports: [    
    AdminRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule    
  ],
  declarations:[
    OrderTypesComponent,
    MillsComponent,
    MailingListComponent,
    OtherConfigComponent
  ]
})
export class AdminModule {}