import { OnInit, Component, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'mills',
  templateUrl: './mills.component.html'
})
export class MillsComponent implements OnInit {
  items: any;
  @ViewChild('addMill') elMill: ElementRef;
  private route: ActivatedRoute;
  MillId: number;
  AddShowHide: boolean = true;
  EditShowHide: boolean = true;
  CreateShowHide: boolean = false;
  UpdateShowHide: boolean = false;
  CancelShowHide = false;
  reverse: boolean = false;
  frmMill = new FormGroup({
    Millnumber: new FormControl('', [Validators.required, Validators.minLength(1)]),
    Millname: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'mill',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
    pagerowcount:0
  };
  param = environment.pagination;
  constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _HotOrderService: HotOrderService, private alertService: AlertService, private storage: StorageService) {
  }

  ngOnInit() {
   this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
   //this.config.pagerowcount  = this.config.pagerowcount > this.config.totalItems ? this.config.totalItems : this.config.pagerowcount;

    console.log(this.param);
    this.GetMills();
  }

  SortOder(sortBy) {
    if (this.param.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.param.SortOrder = "DESC"
    } else {
      this.param.SortOrder = "ASC"
    }
    this.param.SortColumnName = sortBy;
    this.GetMills();
  }

  Cancel() {
    this.MillId = 0;
    this.frmMill.setValue({ Millnumber: "", Millname: "" });
    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide = false;
    this.CancelShowHide = false;
  }

  GetMills() {
    this.SpinnerService.show();
    this._HotOrderService.getMillsList(this.param).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;
      this.config.totalItems = JSON.parse(data).page.TotalCount;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.param.PageSelected = event;
    this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
    this.config.pagerowcount  = this.config.pagerowcount > this.config.totalItems ? this.config.totalItems : this.config.pagerowcount;

    this.GetMills();
  }

  EditMill(item) {
    this.MillId = item.MillId;
    this.frmMill.setValue({
      Millnumber: item.Millnumber,
      Millname: item.Millname
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide = true;
    this.CancelShowHide = true;
  }

  DeleteMill(millid) {
    var meet = confirm("Are you sure. You want to delete the record?");
    if (meet) {
      this.SpinnerService.show();
      this._HotOrderService.DeleteMill(millid).subscribe((data: any) => {
        if (data == "MailingExists") {
          this.alertService.information("Cannot delete record. Records from Email Configuration corresponding to the Mill should be deleted first.");
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          return;
        }
        if (data === "1") {
          this.param.SortOrder = "DESC";
          this.GetMills();
          this.alertService.showSuccess("Record deleted successfully");
        } else {
          this.alertService.showError("Error while deleteing successfully");
        }
        setTimeout(() => { this.SpinnerService.hide() }, 500);
      });
    }
  }

  AddMill() {
    this.MillId = 0;
    this.AddShowHide = false;
    this.EditShowHide = false;
    this.CreateShowHide = true;
    this.UpdateShowHide = false;
    this.CancelShowHide = true;
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';

    if (frmM.invalid) {
      Object.keys(frmM.controls).forEach((key) => {
        if (frmM.get(key).invalid == true) {

          if (key === "Millnumber") {
            if (invalidfield == '') {
              invalidfield = "Please enter Mill ID" + "<br/>";
            } else {
              invalidfield += "Please enter Mill ID" + "<br/>";
            }
          }

          if (key === "Millname") {
            if (invalidfield == '') {
              invalidfield = "Please enter Mill Name" + "<br/>";
            } else {
              invalidfield += "Please enter Mill Name" + "<br/>";
            }
          }
          // if(invalidfield == ''){
          //     invalidfield = "Please enter " +  key.charAt(0).toUpperCase() + key.substr(1).toLowerCase()+ "<br/>";   
          // } else {
          //     invalidfield += "Please enter " + key.charAt(0).toUpperCase() + key.substr(1).toLowerCase() + "<br/> ";
          // }                 
        }
      });
      this.alertService.showError(invalidfield);
    }
  }

  CreateMill() {
    if (this.frmMill.invalid) {
      this.Validation(this.frmMill);
      return;
    }
    let MillsModel = {
      Millnumber: this.frmMill.get('Millnumber').value,
      Millname: this.frmMill.get('Millname').value
      //,Createdby: "jagdish"
    }
    this.SpinnerService.show();
    let retvalue = this._HotOrderService.InsertUpdateMill(MillsModel);
    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        this.alertService.showError("Error while creating record");
        return of(null);
      })).subscribe((value: any) => {
        if (value == "millexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Mill already exists");
          return;
        }
        if (value == "1") {
          this.param.SortOrder = "DESC";
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record created successfully");
          this.GetMills();
          this.renderer.setAttribute(this.elMill.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showError("Error while creating record");
        }
      })
  }

  UpdateMill() {
    if (this.frmMill.invalid) {
      this.Validation(this.frmMill);
      return;
    }

    let MillsModel = {
      MillId: this.MillId,
      Millnumber: this.frmMill.get('Millnumber').value,
      Millname: this.frmMill.get('Millname').value
      //,Modifiedby: "jagdish"
    }

    this.SpinnerService.show();
    let retvalue = this._HotOrderService.InsertUpdateMill(MillsModel);

    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        alert("Error while creating record!!!");
        return of(null);
      })).subscribe((value: any) => {
        if (value == "millexists") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.information("Mill already exists");
          return;
        }

        if (value == "1") {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Record updated successfully");
          this.param.SortOrder = "DESC";
          this.GetMills();
          this.renderer.setAttribute(this.elMill.nativeElement, 'class', 'collapse');
          this.Cancel();
        } else {
          setTimeout(() => { this.SpinnerService.hide() }, 500);
          this.alertService.showSuccess("Error while creating record");
        }
      })
  }
}