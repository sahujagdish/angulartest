import { OnInit, Component, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'mailinglist',
  templateUrl: './mailinglist.component.html'
})

export class MailingListComponent implements OnInit {
  items: any;
  OrderTypeList: any[];
  MillList: any[];
  mill: any;
  @ViewChild('addEmailConfig') el: ElementRef;
  private route: ActivatedRoute;
  MaillingListId: number;
  AddShowHide: boolean = true;
  EditShowHide: boolean = true;
  CreateShowHide: boolean = false;
  UpdateShowHide: boolean = false;
  CancelShowHide = false;
  reverse: boolean = false;

  frmEmailConfig = new FormGroup({
    MillId: new FormControl('', [Validators.required]),
    Ordertype: new FormControl('', [Validators.required]),
    Planningteamdl: new FormControl('', [Validators.required]),
    Executionteamdl: new FormControl('', [Validators.required])
  });

  config = {
    id: 'emailconfig',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
    pagerowcount:0
  };

  mailingParam = environment.pagination;

  constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _HotOrderService: HotOrderService,
    private alertService: AlertService, private storage: StorageService) { }

  validateEmail(email) {
    const regularExpression = /^([\w+-.%]+@[\w.-]+\.[A-Za-z]{2,4})([\W]*,{1}[\W]*[\w+-.%]+@[\w.-]+\.[A-Za-z]{2,4})*$/;
    
    ///^([\w+-.%]+@[\w-.]+\.[A-Za-z ]{2,4},?)+$/;
    
    ///^[\W]*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4}[\W]*,{1}[\W]*)*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4})[\W]*$/ ;
    
    
    return regularExpression.test(String(email).toLowerCase());
  }

  ngOnInit() {
    this.GetOrderTypes();
    this.GetMills();
    this.GetEmailConfig();
    this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
  }

  SortOder(sortBy) {
    if (this.mailingParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.mailingParam.SortOrder = "DESC"
    } else {
      this.mailingParam.SortOrder = "ASC"
    }
    this.mailingParam.SortColumnName = sortBy;
    this.GetEmailConfig();
  }

  onMillChange(event) {
    //console.log(this.frmEmailConfig.get("MillId").value);
  }

  Cancel() {
    this.MaillingListId = 0;
    this.frmEmailConfig.setValue({
      MillId: "",
      Ordertype: "",
      Planningteamdl: "",
      Executionteamdl: ""
    });

    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide = false;
    this.CancelShowHide = false;
  }

  GetEmailConfig() {
    this.SpinnerService.show();
    this._HotOrderService.getMailingList(this.mailingParam).subscribe((data: any) => {
      this.items = data.PagedDataModel;
      this.config.totalItems = data.page.TotalCount;
      setTimeout(() => { this.SpinnerService.hide() }, 500);
    });
  }

  GetMills() {
    this._HotOrderService.getMills().subscribe((data: any) => {
      this.MillList = JSON.parse(data);
    });
  }

  GetOrderTypes() {
    this._HotOrderService.GetOrderTypes().subscribe((data: any) => {
      this.OrderTypeList = JSON.parse(data);
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
    this.mailingParam.PageSelected = event;
    this.GetEmailConfig();
    this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
    this.config.pagerowcount  = this.config.pagerowcount > this.config.totalItems ? this.config.totalItems : this.config.pagerowcount;
  }

  EditEmailConfig(item) {
    this.MaillingListId = item.Id;

    this.frmEmailConfig.setValue({
      MillId: item.MillId,
      Ordertype: item.OrdertypeId,
      Planningteamdl: item.Planningteamdl,
      Executionteamdl: item.Executionteamdl
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide = true;
    this.CancelShowHide = true;
  }

  DeleteEmailConfig(Id) {

    var meet = confirm("Are you sure. You want to delete the record?");
    if (meet) {
      this.SpinnerService.show();
      this._HotOrderService.DeleteMailingList(Id).subscribe((data: any) => {
        if (data == "1") {
          this.mailingParam.SortOrder = "DESC";
          this.GetEmailConfig();
          this.alertService.showSuccess("Record deleted successfully");
        } else {
          this.alertService.showError("Error while deleteing successfully");
        }
        setTimeout(() => { this.SpinnerService.hide() }, 500);
      });
    }
  }

  AddEmailConfig() {
    this.MaillingListId = 0;
    this.AddShowHide = false;
    this.EditShowHide = false;
    this.CreateShowHide = true;
    this.UpdateShowHide = false;
    this.CancelShowHide = true;
  }

  Validation(frmM: FormGroup) {
    let invalidfield: String = '';
    ///if (frmM.invalid) {
      Object.keys(frmM.controls).forEach((key) => {     
          if (key === "MillId") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Mill" + "<br/>";
              } else {
                invalidfield += "Please select Mill" + "<br/>";
              }
            }
          }

          if (key === "Ordertype") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please select Order Type" + "<br/>";
              } else {
                invalidfield += "Please select  Order Type" + "<br/>";
              }
            }
          }

          if (key === "Planningteamdl") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please enter Planning Team DL" + "<br/>";
              } else {
                invalidfield += "Please enter Planning Team DL" + "<br/>";
              }
            }
            if (frmM.get(key).value != "") {
              if (!this.validateEmail(frmM.get(key).value)) {
                if (invalidfield == '') {
                  invalidfield = "Please enter correct emailid in Planning Team DL" + "<br/>";
                } else {
                  invalidfield += "Please enter correct emailid in Planning Team DL" + "<br/>";
                }
              }
            }
          } 

          if (key === "Executionteamdl") {
            if (frmM.get(key).value == "") {
              if (invalidfield == '') {
                invalidfield = "Please enter Execution Team DL" + "<br/>";
              } else {
                invalidfield += "Please enter Execution Team DL" + "<br/>";
              }
            }
            if (frmM.get(key).value != "") {
              if (!this.validateEmail(frmM.get(key).value)) {
                if (invalidfield == '') {
                  invalidfield = "Please enter correct emailid in Execution Team DL" + "<br/>";
                } else {
                  invalidfield += "Please enter correct emailid in Execution Team DL" + "<br/>";
                }
              }
            }
          }
      });
     
      if(invalidfield != ""){
        this.alertService.showError(invalidfield);
      }

      return invalidfield;
    //}
  }

  CreateEmailConfig() {
    var isvalid = this.Validation(this.frmEmailConfig);
    if(isvalid != ""){
      return;
    }

    let Emailconfig = {
      Id: 0,
      MillId: parseInt(this.frmEmailConfig.get('MillId').value),
      OrdertypeId: parseInt(this.frmEmailConfig.get('Ordertype').value),
      Planningteamdl: this.frmEmailConfig.get('Planningteamdl').value,
      Executionteamdl: this.frmEmailConfig.get('Executionteamdl').value
      //,Createdby: "jagdish"
    }
    this.SpinnerService.show();
    let retvalue = this._HotOrderService.InsertUpdateMailingList(Emailconfig);
    retvalue.pipe(
      catchError(err => {
        this.alertService.showError("Error while creating record");
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        return of(null);
      })).subscribe((value: any) => {

        if (value === "CombinationAllreadyExists") {
          this.alertService.information("Email configuration already exists !!");
        }
        if (value === "1") {
          this.mailingParam.SortOrder = "DESC";
          this.GetEmailConfig();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
          this.alertService.showSuccess("Record created successfully");
        }
        setTimeout(() => { this.SpinnerService.hide() }, 500);
      })
  }

  UpdateEmailConfig() {
    var isvalid = this.Validation(this.frmEmailConfig);
    if(isvalid != ""){
      return;
    }
    let Emailconfig = {
      Id: this.MaillingListId,
      MillId: parseInt(this.frmEmailConfig.get('MillId').value),
      OrdertypeId: parseInt(this.frmEmailConfig.get('Ordertype').value),
      Planningteamdl: this.frmEmailConfig.get('Planningteamdl').value,
      Executionteamdl: this.frmEmailConfig.get('Executionteamdl').value
      //,Modifiedby: 'jagdish'
    }

    this.SpinnerService.show();
    let retvalue = this._HotOrderService.InsertUpdateMailingList(Emailconfig);

    retvalue.pipe(
      catchError(err => {
        alert("Error while updating record !!");
        setTimeout(() => { this.SpinnerService.hide() }, 500);
        return of(null);
      })).subscribe((value: any) => {
        if (value === "CombinationAllreadyExists") {
          this.alertService.information("Email configuration already exists");
        }

        if (value === "1") {
          this.mailingParam.SortOrder = "DESC";
          this.GetEmailConfig();
          this.renderer.setAttribute(this.el.nativeElement, 'class', 'collapse');
          this.Cancel();
          setTimeout("", 1000);
          this.alertService.showSuccess("Record updated successfully");
        }
        setTimeout(() => { this.SpinnerService.hide() }, 500);
      })
  }
}
