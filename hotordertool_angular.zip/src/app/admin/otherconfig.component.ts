import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'otherconfig',
  templateUrl: './otherconfig.component.html'
})
export class OtherConfigComponent implements OnInit {
  isEnable: boolean = false;
    constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _HotOrderService: HotOrderService, private alertService : AlertService, private storage: StorageService) { 

    }

    ngOnInit(): void {
      this.GetOtherConfig();
    }

    GetOtherConfig(){
      this._HotOrderService.getOtherConfig().subscribe((data: any) => {
        this.isEnable = data;
     });
    }

    enableconfig(){
      this.SpinnerService.show();
     this._HotOrderService.EnableOtherConfig(this.isEnable).subscribe((data: any) => {
      if(data){
        this.alertService.showSuccess("Record updated successfully");
        this.GetOtherConfig();        
      } else{        
        this.alertService.showError("Error while updating record");
        return of(null);
      }
      });
      this.SpinnerService.hide();
    }
}