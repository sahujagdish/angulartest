import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { HotOrderService } from '../../services/HotOrder.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StorageService } from '../../services/storage.service';
import { AlertService } from '../../services/alert.service';
import { ActivatedRoute } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'ordertypes',
  templateUrl: './ordertypes.component.html'
})
export class OrderTypesComponent implements OnInit {
  items: any;
  @ViewChild('addOrderType') el:ElementRef;
  private route: ActivatedRoute;
  OrderTypeId:number;
  AddShowHide:boolean = true;
  EditShowHide:boolean = true;
  CreateShowHide:boolean = false;
  UpdateShowHide:boolean = false;  
  CancelShowHide = false;
  reverse: boolean = false;
  frmOrderType = new FormGroup({
    OrderType: new FormControl('', [Validators.required, Validators.minLength(1)])
  });

  config = {
    id: 'ordertype',
    itemsPerPage: environment.pagination.pagesize,
    currentPage: 1,
    totalItems: 0,
    pagerowcount:0
  };

  orderTypeParam = environment.pagination;

  constructor(private SpinnerService: NgxSpinnerService, private renderer: Renderer2, private _HotOrderService: HotOrderService, private alertService : AlertService, private storage: StorageService) { }

  ngOnInit() {  
    this.GetOrderType();
    this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
  }

  SortOder(sortBy){
    if (this.orderTypeParam.SortOrder === "ASC") {
      this.reverse = !this.reverse;
      this.orderTypeParam.SortOrder = "DESC"
    } else{
      this.orderTypeParam.SortOrder = "ASC"
    }
    this.orderTypeParam.SortColumnName = sortBy;
    this.GetOrderType();
  }

  Cancel(){    
    this.OrderTypeId = 0;
    this.frmOrderType.setValue({OrderType:""});
    this.AddShowHide = true;
    this.EditShowHide = true;
    this.CreateShowHide = false;
    this.UpdateShowHide =false;
    this.CancelShowHide = false;
  }

  GetOrderType() {
    this.SpinnerService.show();
    this._HotOrderService.GetOrderTypesDetail(this.orderTypeParam).subscribe((data: any) => {
      this.items = JSON.parse(data).PagedDataModel;      
      this.config.totalItems = JSON.parse(data).page.TotalCount;
      setTimeout(() => { this.SpinnerService.hide()},500);
   });
  }

  pageChanged(event){
    this.config.currentPage = event;
    this.orderTypeParam.PageSelected = event;
    this.GetOrderType();
    this.config.pagerowcount =  this.config.itemsPerPage * (this.config.currentPage == 0 ? this.config.currentPage + 1 : this.config.currentPage);
    this.config.pagerowcount  = this.config.pagerowcount > this.config.totalItems ? this.config.totalItems : this.config.pagerowcount;
  }

  EditOrderType(item){
    this.OrderTypeId = item.OrdertypeId;
    this.frmOrderType.setValue({
      OrderType:item.Ordertype
    });

    this.EditShowHide = false;
    this.AddShowHide = false;
    this.CreateShowHide = false;
    this.UpdateShowHide =true;
    this.CancelShowHide = true;
  }

  DeleteOrderType(OrdertypeId){
    var meet = confirm("Are you sure. You want to delete the record?");
    if(meet) {
      this.SpinnerService.show();
    this._HotOrderService.DeleteOrderType(OrdertypeId).subscribe((data: any) => { 
         if(data == "MailingExists") {
          setTimeout(() => { this.SpinnerService.hide()},500);
          this.alertService.information("Cannot delete record. Records from Email Configuration corresponding to the OrderTpye should be deleted first."); 
          return ;
         }
         if(data == "1") {
          setTimeout(() => { this.SpinnerService.hide()},500);
          this.alertService.showSuccess("Record deleted successfully");
          this.orderTypeParam.SortOrder = "DESC";
         this.GetOrderType();         
         } else {
          setTimeout(() => { this.SpinnerService.hide()},500);
          this.alertService.showError("Error while deleteing record");
         }
    });    
  }
}

AddOrderType(){
  this.OrderTypeId = 0;   
  this.AddShowHide = false;
  this.EditShowHide = false;
  this.CreateShowHide = true;
  this.UpdateShowHide =false;
  this.CancelShowHide = true;
}

Validation(frmM:FormGroup){
  let invalidfield : String = '';
      
if (frmM.invalid) {
    Object.keys(frmM.controls).forEach((key) => {
      if (key === "OrderType") {
        if (invalidfield == '') {
            invalidfield = "Please enter Order Type" + "<br/>";
        } else {
            invalidfield += "Please enter Order Type" + "<br/>";
        }
      }
    });
    this.alertService.showError(invalidfield);
  }
}

CreateOrdertype() {  
  if (this.frmOrderType.invalid) {
    this.Validation(this.frmOrderType);
    return;
  }
  let OrderTypeModel = {
    Ordertype: this.frmOrderType.get('OrderType').value
    //,Createdby: "jagdish"
  }  
  this.SpinnerService.show();
  let retvalue = this._HotOrderService.InsertUpdateOrderType(OrderTypeModel);
  retvalue.pipe(
    catchError(err => {
      setTimeout(() => { this.SpinnerService.hide()},500);
      this.alertService.showError("Error while creating record");
      return of(null);
    })).subscribe((value: any) => {
      if(value == "ordertypeexists"){
        setTimeout(() => { this.SpinnerService.hide()},500);
        this.alertService.information("Ordertype already exists");
        return;
      }    
      if(value == "1"){
      setTimeout(() => { this.SpinnerService.hide()},500);
      this.alertService.showSuccess("Record created successfully");
      this.orderTypeParam.SortOrder = "DESC";
      this.GetOrderType();          
      this.renderer.setAttribute(this.el.nativeElement, 'class','collapse');
      this.Cancel();
    } else {
      setTimeout(() => { this.SpinnerService.hide()},500);
      this.alertService.showError("Error while creating record");
    }
    })      
  }

  UpdateOrdertype() {
    if (this.frmOrderType.invalid) { 
      this.Validation(this.frmOrderType);
      return;
    }

    let OrderTypeModel = {
      OrdertypeId: this.OrderTypeId,
      Ordertype: this.frmOrderType.get('OrderType').value
      //,Modifiedby: "jagdish"
    }

    this.SpinnerService.show();
    let retvalue = this._HotOrderService.InsertUpdateOrderType(OrderTypeModel);

    retvalue.pipe(
      catchError(err => {
        setTimeout(() => { this.SpinnerService.hide()},500);
        alert("Error while creating record!!!");
        return of(null);
      })).subscribe((value: any) => {
        if(value == "ordertypeexists"){
          setTimeout(() => { this.SpinnerService.hide()},500);
          this.alertService.information("Ordertype already exists");
          return;
        }    
        if(value == "1"){
        setTimeout(() => { this.SpinnerService.hide()},500);
        this.alertService.showSuccess("Record updated successfully");
        this.orderTypeParam.SortOrder = "DESC";  
        this.GetOrderType();      
        this.renderer.setAttribute(this.el.nativeElement, 'class','collapse');
        this.Cancel();
      } else {
        setTimeout(() => { this.SpinnerService.hide()},500);
        this.alertService.showError("Error while creating record");
      }
      })      
  }
}