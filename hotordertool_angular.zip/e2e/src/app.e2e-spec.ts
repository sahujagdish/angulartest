import { AppPage } from './app.po';
import { browser, logging, element, By, protractor } from 'protractor';
import { SSL_OP_NO_TICKET } from 'constants';

xdescribe('Landing ', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize;
    page = new AppPage();
  });

  it('should display welcome message and menu for ', () => {
    page.navigateTo();
    expect(page.getTitleText()).toEqual('Welcome to the Hot Order Tool (H.O.T)');
  });

  it('Home', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[1]/a')).getText()).toContain("Home");
  });

  it('Hot Orders', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[2]/a')).getText()).toEqual("Hot Orders");
  });

  it('Welcome, User', () => {
    expect(element(By.xpath('//*[@id="navbarDropdown"]')).getText()).toEqual("Welcome, User");
    element(By.xpath('//*[@id="navbarDropdown"]')).click();
  });

  it('Mills', () => {
    expect(element(By.xpath('/html/body/app-root/header/nav/div/ul/li[3]/div/a[1]')).getText()).toEqual("Mills");
  });
  it('Order Types', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[3]/div/a[2]')).getText()).toEqual("Order Types");
  });
  it('Email Configuration', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[3]/div/a[3]')).getText()).toEqual("Email Configuration");
  });
  it('Other Configurations', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[3]/div/a[4]')).getText()).toEqual("Other Configurations");
  });
  it('Logout', () => {
    expect(element(By.xpath('//*[@id="navbarCollapse"]/ul/li[3]/div/a[5]')).getText()).toEqual("Logout");
  });

  afterAll(async () => {
    //browser.re;
    // Assert that there are no errors emitted from the browser
    // const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    // expect(logs).not.toContain(jasmine.objectContaining({
    //   level: logging.Level.SEVERE,
    // } as logging.Entry));
  });
});

xdescribe('Mills test', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize();
    page = new AppPage();
  });

  it('View Mills', () => {
    page.navigateTo();
    element(By.xpath('//*[@id="navbarDropdown"]')).click();
    element(By.xpath('/html/body/app-root/header/nav/div/ul/li[3]/div/a[1]')).click().then(function () {
      browser.getTitle().then(function (title) {
        var elem = element(By.xpath('/html/body/app-root/main/div/mills/div[1]/div/h4'));
        expect(elem.getText()).toEqual('Mills');
      });
    });
  });

  it('check mills Update button ', () => {    
    //var el = element(By.className('collapse show'));
    var el = element(By.xpath('/html/body/app-root/main/div/mills/div[3]'));
    element(By.xpath('/html/body/app-root/main/div/mills/div[4]/div/div/table/tbody/tr[1]/td[1]/button[1]/span')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse show');
    });    
  });

  it('check mills cancel', () => {
    //var el = element(By.className('collapse show'));
    var el = element(By.xpath('/html/body/app-root/main/div/mills/div[3]'));
    element(By.xpath('/html/body/app-root/main/div/mills/div[3]/div/div/div/form/div[2]/div/button[2]')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse');
    });    
  });  

  xit('mills submit', () => {    
    element(By.xpath('/html/body/app-root/main/div/mills/div[2]/div/button')).click().then(function () {
      browser.sleep(1000);
      var elem = element(By.id('millId')).sendKeys('9999');
      var elem = element(By.id('millName')).sendKeys('newMills');
      element(By.id('btnAdd')).click();
      var alerttext = element.all(By.id('toast-container'));
      var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
      expect(errorexists).toContain("Success");
    });
  });

  it('record already exists on mills submit', () => {    
    browser.refresh();
    element(By.xpath('/html/body/app-root/main/div/mills/div[2]/div/button')).click().then(function () {
      browser.sleep(1000);
      var elem = element(By.id('millId')).sendKeys('0241');
      var elem = element(By.id('millName')).sendKeys('Texarkana');
      browser.executeScript('window.scrollTo(0,50)').then(function(){
        element(By.id('btnAdd')).click();
      });
      var alerttext = element.all(By.id('toast-container'));
      var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
      expect(errorexists).toContain("Information");
    });
  });

  afterAll(async () => {
   // browser.close();
    // Assert that there are no errors emitted from the browser
    // const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    // expect(logs).not.toContain(jasmine.objectContaining({
    //   level: logging.Level.SEVERE,
    // } as logging.Entry));
  });
});

xdescribe('ordertypes test', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize();
    page = new AppPage();
  });

  it('View OrderTyes', () => {
    page.navigateTo();
    element(By.xpath('//*[@id="navbarDropdown"]')).click();
    element(By.xpath('/html/body/app-root/header/nav/div/ul/li[3]/div/a[2]')).click().then(function () {
      browser.getTitle().then(function (title) {
        var elem = element(By.xpath('/html/body/app-root/main/div/ordertypes/div[1]/div/h4'));
        expect(elem.getText()).toEqual('Order Types');
      });
    });
  });

  it('check order types Update button', () => {    
    //var el = element(By.className('collapse show'));
    var el = element(By.id('addOrderType'));
    element(By.xpath('/html/body/app-root/main/div/ordertypes/div[4]/div/div/table/tbody/tr[1]/td[1]/button[1]')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse show');
    });    
  });

  it('check ordertypes cancel', () => {    
    //var el = element(By.className('collapse show'));
    var el = element(By.id('addOrderType'));
    element(By.xpath('/html/body/app-root/main/div/ordertypes/div[3]/div/div/div/form/div[2]/div/button[2]')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse');
    });    
  });

  xit('ordertypes submit', () => {    
    element(By.xpath('/html/body/app-root/main/div/ordertypes/div[2]/div/button')).click().then(function () {
      browser.sleep(1000);
      var elem = element(By.id('txtOrderType')).sendKeys('newOrder');
      element(By.id('btnAdd')).click();
      var alerttext = element.all(By.id('toast-container'));
      var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
      expect(errorexists).toContain("Success");
    });
  });

  it('record already exists on mills submit', () => {    
    browser.refresh();
    element(By.xpath('/html/body/app-root/main/div/ordertypes/div[2]/div/button')).click().then(function () {
      browser.sleep(1000);
      var elem = element(By.id('txtOrderType')).sendKeys('ZDOM');
      browser.executeScript('window.scrollTo(0,50)').then(function(){
        element(By.id('btnAdd')).click();
      });
      var alerttext = element.all(By.id('toast-container'));
      var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
      expect(errorexists).toContain("Information");
    });
  });

  afterAll(async () => {
    //browser.close();
    // Assert that there are no errors emitted from the browser
    // const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    // expect(logs).not.toContain(jasmine.objectContaining({
    //   level: logging.Level.SEVERE,
    // } as logging.Entry));
  });
});

xdescribe('mailinglist test', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize();
    page = new AppPage();
  });

  it('View Email Configuration', () => {
    page.navigateTo();
    element(By.xpath('//*[@id="navbarDropdown"]')).click();
    element(By.xpath('/html/body/app-root/header/nav/div/ul/li[3]/div/a[3]')).click().then(function () {
      browser.getTitle().then(function (title) {
        var elem = element(By.xpath('/html/body/app-root/main/div/mailinglist/div[1]/div/h4'));
        expect(elem.getText()).toEqual('Email Configuration');
      });
    });
  });

  it('check Email Configuration Update exists', () => {    
    //var el = element(By.className('collapse show'));
    var el = element(By.id('addEmailConfig'));
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[4]/div/div/table/tbody/tr[1]/td[1]/button[1]')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse show');
    });    
  });

  it('check Email Configuration cancel', () => {    
    //var el = element(By.className('collapse show'));
    browser.sleep(1000);    
    var el = element(By.id('addEmailConfig'));
    browser.executeScript('window.scrollTo(0,100)').then(function(){
    //browser.actions().mouseMove(element(By.id('btnCancel'))).perform();
      element(By.id('btnCancel')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse');
    });    
    });
  });

  it('check Email Configuration Add exists', () => {  
    browser.refresh();  
    //var el = element(By.className('collapse show'));
    var el = element(By.id('addEmailConfig'));
    
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[2]/div/button')).click().then(function () {
      browser.sleep(1000);
      browser.executeScript('window.scrollTo(0,100)').then(function(){
      var add = element(By.xpath('/html/body/app-root/main/div/mailinglist/div[3]/div/form/div[5]/div/button[1]'));      
      expect(add.getText()).toEqual('Add');
      });
      expect(el.getAttribute("class")).toEqual('collapse show');
   // });
  });
  });

  it('check Email Configuration Mill dropdownlist filled', () => {
    
    var el = element(By.id('ddlMill'));
    expect(element.all(By.tagName('option')).count()).toBeGreaterThan(1);
  });

  it('check Email Configuration ordertype dropdownlist filled', () => {
    var el = element(By.id('ddlordertype'));
    expect(element.all(By.tagName('option')).count()).toBeGreaterThan(1);
  });  
  
  it('check Email Configuration Error on submit', () => {    
    browser.refresh();  
    browser.sleep(1000);
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[2]/div/button')).click();
    browser.sleep(100);
    element.all(By.id('ddlMill')).then(function(Item){Item[0].click();});
    element.all(By.id('ddlordertype')).then(function(Item){Item[0].click();});
    var txtPlanningTeamDL = element(By.id('txtPlanningTeamDL')).sendKeys("aaa");
    var txtExecutionTeamDL = element(By.id('txtExecutionTeamDL')).sendKeys("exe");
    browser.executeScript('window.scrollTo(0,100)').then(function(){
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[3]/div/form/div[5]/div/button[1]')).click();
    browser.sleep(500);   
    var alerttext = element.all(By.id('toast-container'));
    var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();
    expect(errorexists).toContain("Error"); 
  });
  });

  xit('Submit email Configuration', () => {    
    browser.refresh();
    browser.sleep(1000);
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[2]/div/button')).click();
    browser.sleep(100);
    var ddlMill = element.all(By.id('ddlMill'));
    ddlMill.all(By.xpath("//option[text()='newMills']")).click();
    var ddlordertype = element.all(By.id('ddlordertype'));
    ddlordertype.all(By.xpath("//option[text()='newOrder']")).click();
    var txtPlanningTeamDL = element(By.id('txtPlanningTeamDL')).sendKeys("aaa@aa.com");
    var txtExecutionTeamDL = element(By.id('txtExecutionTeamDL')).sendKeys("exe@aa.com");
    browser.executeScript('window.scrollTo(0,100)').then(function(){
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[3]/div/form/div[5]/div/button[1]')).click();
    browser.sleep(500);
    var alerttext = element.all(By.id('toast-container'));
    var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
    expect(errorexists).toContain("Success");
  });
  });

  it('check record already exists on Submit email configuration', () => {
    browser.refresh();
    browser.sleep(1000);
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[2]/div/button')).click();
    browser.sleep(100);
    var ddlMill = element.all(By.id('ddlMill'));
    ddlMill.all(By.xpath("//option[text()='Texarkana']")).click();
    var ddlordertype = element.all(By.id('ddlordertype'));
    ddlordertype.all(By.xpath("//option[text()='ZKB']")).click();
    var txtPlanningTeamDL = element(By.id('txtPlanningTeamDL')).sendKeys("aaa@aa.com");
    var txtExecutionTeamDL = element(By.id('txtExecutionTeamDL')).sendKeys("exe@aa.com");
    browser.executeScript('window.scrollTo(0,100)').then(function(){
    element(By.xpath('/html/body/app-root/main/div/mailinglist/div[3]/div/form/div[5]/div/button[1]')).click();
    browser.sleep(500);
    var alerttext = element.all(By.id('toast-container'));
    var errorexists = alerttext.all(By.xpath('/html/body/div/div/div/div[1]')).getText();    
    expect(errorexists).toContain("Information"); 
  });
  });

  it('check Email Configuration cancel', () => {    
    //var el = element(By.className('collapse show'));
    var el = element(By.id('addEmailConfig'));    
      element(By.id('btnCancel')).click().then(function () {
      browser.sleep(1000);
      expect(el.getAttribute("class")).toEqual('collapse');
    });    
  });

  afterAll(async () => {

    
    // Assert that there are no errors emitted from the browser
    // const logs = await browser.manage().logs().get(logging.Type.BROWSER);
    // expect(logs).not.toContain(jasmine.objectContaining({
    //   level: logging.Level.SEVERE,
    // } as logging.Entry));
  });
});

xdescribe('Other Configurations test', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize();
    page = new AppPage();
  });

  it('View Other Configurations', () => {
    page.navigateTo();
    element(By.xpath('//*[@id="navbarDropdown"]')).click();
    element(By.xpath('/html/body/app-root/header/nav/div/ul/li[3]/div/a[4]')).click().then(function () {
      browser.getTitle().then(function (title) {
        var elem = element(By.xpath('/html/body/app-root/main/div/otherconfig/div[1]/div/h4'));
        expect(elem.getText()).toEqual('Other Configurations');
      });
    });
  });
});

describe('Hot Order tet', () => {
  let page: AppPage;

  beforeAll(() => {
    browser.driver.manage().window().maximize();
    page = new AppPage();
  });

  it('View Hot Order', () => {
    //browser.refresh();
    page.navigateTo();
    element(By.xpath('/html/body/app-root/header/nav/div/ul/li[2]/a')).click().then(function () {
      browser.getTitle().then(function (title) {
        var elem = element(By.xpath('/html/body/app-root/main/div/hotorders/div[1]/div/h4'));
        expect(elem.getText()).toEqual('Hot Orders');
      });
    });
  });

  it('Create Hot Order', () => {   
    element(By.xpath('/html/body/app-root/main/div/hotorders/div[2]/div/a/button')).click().then(function () {
      browser.sleep(100);
      expect(browser.getCurrentUrl()).toEqual(browser.baseUrl+ "insertupdate/0");
      var title = element(By.xpath("/html/body/app-root/main/div/insertupdatehotorders/div/div/h4")).getText();
      expect(browser.getCurrentUrl()).toEqual(browser.baseUrl+ "insertupdate/0");
      expect(title).toEqual("Create New Hot Order");      
    });
  });

  it('check ExceptionReason dropdown count', () => {
    var el = element(By.id('ddlExceptionReason'));
    expect(element.all(By.tagName('option')).count()).toBeGreaterThan(1);
  });

  it('check CustomerServiceEmail dropdown count', () => {
    var el = element(By.id('ddlCustomerServiceEmail'));
    expect(element.all(By.tagName('option')).count()).toBeGreaterThan(1);
  });

  it('Cancel Hot Order', () => {
    browser.executeScript('window.scrollTo(0,200)').then(function(){
    element(By.xpath('/html/body/app-root/main/div/insertupdatehotorders/form/div[5]/div/a/button')).click().then(function () {
      browser.sleep(100);      
      var title = element(By.xpath('/html/body/app-root/main/div/hotorders/div[1]/div/h4')).getText();
      expect(browser.getCurrentUrl()).toEqual(browser.baseUrl+ "hotorders");
      expect(title).toEqual("Hot Orders");
    });
  });
  });

  

});

var SelectValueFromDropDown = function selectDropdownByNumber(element, index) {
  element.all(By.tagName('option')).then(function(options) {
      return options[index];
  });      
}
